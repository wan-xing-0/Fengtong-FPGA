# 11-03 round 3: TD "TimingUltra" (official_strategy_ph1.json) MINUS the two
# post-place items.  Round 2 with full TimingUltra crashed TD (coredump) inside
# the post-place "phys_opt -post_place -hfn_opt -effort high", i.e. what
# post_place_opt high + hfn_opt_effort high add; the default flow never runs
# that step.  Everything else verbatim.
source ./settings.cfg
set phyWildParams {
  place effort high
  place opt_timing high
  place logic_level_opt on
  place aggressive_opt 21
  place aggr_neighbor_dist 5
  place enhanced_beeline_opt 3
  place timing_driven_mode on
  place shifter_opt on
  place crit_path_opt on
  place split_data_from_clock on
  route post_route_opt high
  route postrt_opt_extra_round 4
}
# DefaultFlow.tcl is located from the running td_commands_prompt.exe, so this
# script works wherever the project folder is placed.
source [file join [file dirname [info nameofexecutable]] .. scripts DefaultFlow.tcl]
