create_clock -name {SYSCLK_25M} -period 40.000 -waveform {0.000 20.000} [get_ports {I_sysclk_25m}]
create_clock -name {SYSCLK100M} -period 10.000 -waveform {0.000 5.000} [get_ports {I_ddr_clk}]

#---------------------------------------------------------------------------
# S_hs_rx_clk : MIPI D-PHY byte clock out of the hard macro (2026-09-15, new).
#
# WHY THIS APPEARS ONLY NOW
#   Up to v2 this clock was never constrained, and derive_clocks does not
#   infer it -- it comes off a hard-macro pin, not a PLL.  Check the v2 area
#   report (rollback/area_full8_20260908_1633.area, "Report Clock Domain
#   Luts"): cam_clk_24m, cpu_clk_70m, pclkx1 and the two DDR clocks are
#   listed, and the camera domain is simply absent.  The SC500AI front end was
#   therefore never timed.  It worked, because it is three shallow counters,
#   but "it worked" is not a timing report.  The 4-lane front end doubles the
#   byte clock, so it gets constrained properly.
#
# WHY 6.000ns WHEN THE REAL CLOCK IS ABOUT 111MHz
#   uiimx415reg selects the 891Mbps/lane mode: 0x3033 SYS_MODE=5 with
#   INCKSEL2=0x23, INCKSEL3=0x00C6, INCKSEL4=0x00E7, INCKSEL5=0x23,
#   TXCLKESC_FREQ=0x06C0 is the INCK=24MHz / 891Mbps entry.  D-PHY byte clock
#   = 891/8 = 111.375MHz, and our INCK is 23.81MHz rather than 24, so about
#   110.5MHz.  6.000ns (166.67MHz) is deliberately a ~50% guard band, copied
#   from the vendor's IMX415 demo so that the number is one somebody has
#   actually built against.  It also covers us if the mode deduction is wrong
#   and the link is really running at 1440Mbps (180MHz byte clock) -- at that
#   point the report would show a near-miss instead of nothing at all.
#
#   Cross-checks that the 891Mbps reading is self-consistent: 1932 px/line at
#   RAW10 = 2415 bytes = 604 bytes/lane = 604 byte clocks of HS burst, against
#   a 2H output line period of 2*542/72MHz = 15.06us = about 1677 byte clocks.
#   So the inter-line gap is roughly 1000 clocks, which is what makes
#   image_correction's GAP_CYCLES=10 line detector safe by three orders of
#   magnitude.
#
#   The pin path is the same one fpga_pin.adc already pins to site X5Y0Z0, so
#   it resolves against this netlist.
#---------------------------------------------------------------------------
create_clock -name {S_hs_rx_clk} -period 6.000 -waveform {0.000 3.000} [get_pins {u_mipi_dphy_rx_ph1a_mipiio_wrapper/u_ph1a_mipiio_wrapper/u_PH1_PHY_MIPIIO.hsrx_byteclk_to_fabric}]

rename_clock -name {pclkx1}      [get_clocks {u_pll/pll_inst.clkc[0]}]
rename_clock -name {pclkx5}      [get_clocks {u_pll/pll_inst.clkc[1]}]
rename_clock -name {cpu_clk_70m} [get_clocks {u_pll/pll_inst.clkc[2]}]
rename_clock -name {cam_clk_24m} [get_clocks {u_pll/pll_inst.clkc[3]}]

derive_clocks

#---------------------------------------------------------------------------
# ETHA (2026-10-04, re-grafted 10-09; ETHERNET_V1.md).  Clock definitions and
# RGMII I/O delays are verbatim from the board-verified with_udp v1.0 and
# new_with_udp timing.sdc.
#
# eth_tx_clk is the 125 MHz transmit/packetizer clock generated from the
# dedicated Ethernet PLL; it only exists after derive_clocks, which is why
# this block sits after it (v1.0: the P&R database import requires that
# order).  eth_rxc is recovered by the external PHY.
#
# WHY A SEPARATE set_clock_groups AND NOT THREE MORE -group ON THE ONE BELOW
#   The -exclusive line below fails as a whole in TD: u_ddr_phy/dfi_clk
#   matches no clock (phy_1/run.log, USR-8130 + USR-8208 + USR-8159 on that
#   line), so none of its groups take effect.  Appending the Ethernet clocks
#   there would silently leave every pclkx1 <-> eth_tx_clk CDC path timed as
#   synchronous.  This line names only clocks that certainly exist, so it
#   cannot fail the same way, and it leaves the existing line's behaviour
#   exactly as it was.  The Ethernet clocks have no path to any domain other
#   than pclkx1, so nothing else needs listing.  The existing line is NOT
#   repaired here; that changes how the image design itself is timed and is
#   the image side's decision.  new_with_udp's 10-05 build confirmed this
#   form: no pclkx1 <-> eth_tx_clk path appeared in final_timing.rpt.
#---------------------------------------------------------------------------
rename_clock -name {eth_tx_clk} [get_clocks {u_eth_a_video/u_eth_pll/pll_inst.clkc[0]}]
create_clock -name {eth_rxc} -period 8.000 -waveform {0.000 4.000} [get_ports {I_eth_rgmii_rxc}]
set_clock_groups -exclusive -group [get_clocks {pclkx1}] -group [get_clocks {eth_tx_clk}] -group [get_clocks {eth_rxc}]

# RGMII source-synchronous I/O timing.  The board PHY provides RXC and consumes
# a forwarded TXC.  Values are inherited from the vendor UDP reference design
# and were checked against the v1.0 post-route report and board traffic test.
set_input_delay -clock [get_clocks eth_rxc] -max 2.800 [get_ports {{I_eth_rgmii_rxd[*]} I_eth_rgmii_rx_ctl}]
set_input_delay -clock [get_clocks eth_rxc] -min 1.200 [get_ports {{I_eth_rgmii_rxd[*]} I_eth_rgmii_rx_ctl}]
set_input_delay -clock [get_clocks eth_rxc] -max -clock_fall -add_delay 2.800 [get_ports {{I_eth_rgmii_rxd[*]} I_eth_rgmii_rx_ctl}]
set_input_delay -clock [get_clocks eth_rxc] -min -clock_fall -add_delay 1.200 [get_ports {{I_eth_rgmii_rxd[*]} I_eth_rgmii_rx_ctl}]
create_generated_clock -name {eth_txc} -source [get_pins {u_eth_a_video/u_eth_pll/pll_inst.clkc[0]}] -master_clock {eth_tx_clk} -multiply_by 1.000 -duty_cycle 50.000 -phase 0.000 [get_ports {O_eth_rgmii_txc}]
set_output_delay -clock [get_clocks eth_txc] -max 3.500 [get_ports {O_eth_rgmii_tx_ctl {O_eth_rgmii_txd[*]}}]
set_output_delay -clock [get_clocks eth_txc] -min 0.500 [get_ports {O_eth_rgmii_tx_ctl {O_eth_rgmii_txd[*]}}]
set_output_delay -clock [get_clocks eth_txc] -max -clock_fall -add_delay 3.500 [get_ports {O_eth_rgmii_tx_ctl {O_eth_rgmii_txd[*]}}]
set_output_delay -clock [get_clocks eth_txc] -min -clock_fall -add_delay 0.500 [get_ports {O_eth_rgmii_tx_ctl {O_eth_rgmii_txd[*]}}]

# S_hs_rx_clk added to the group list 2026-09-15.  The camera-to-pclkx1 and
# camera-to-dfi_clk crossings both go through uidbuf's async write FIFO, so
# there is nothing here for the tool to time.  Kept as -exclusive rather than
# switching to the strictly more accurate -asynchronous: v2 closed at +0.10ns
# under -exclusive and both forms suppress inter-clock checks in TD, so
# changing it would risk the one number this design has no slack on, for no
# functional gain.
set_clock_groups -exclusive -group [get_clocks {cam_clk_24m}] -group [get_clocks {cpu_clk_70m}] -group [get_clocks {pclkx1}] -group [get_clocks {pclkx5}] -group [get_clocks {S_hs_rx_clk}] -group [get_clocks {u_ddr_phy/dfi_clk}]

#---------------------------------------------------------------------------
# ddr_init_cal_done: power-up reset release, not a synchronous transfer.
#
# WHAT THIS FIXES
#   Before this exception the design reported SWNS -4.535ns / STNS -420.6ns /
#   103 violating endpoints, and every single one of them lived in ONE path
#   group: pll0.clkc[3] -> pll1.clkc[0].  Both of those clocks are inside the
#   DDR3 hard PHY, so the old note in HANDOFF.md called the whole thing "hard
#   IP internal, don't touch".  That was half right.  The LAUNCH point is
#   inside the IP -- u_mcu/u_cpu/system_gpioCtrl/data_write_reg[31], the
#   calibration MCU's GPIO register at 50MHz -- but the CAPTURE points are
#   ours: uidbuf_u0 and uiFDMA_inst, clocked at 200MHz.  The net between them
#   is u_ddr_phy/ddr_init_cal_done, which system_top uses as M_AXI_ARESETN
#   (:484), uidbuf's I_ui_rstn (:588) and the async reset of fifowait (:646).
#
#   TD derives both clocks from I_ddr_clk, so it classifies the crossing as
#   "Same Domain" and budgets one 200MHz edge minus the 50MHz edge = 0.236ns
#   for it.  Nothing can meet that, and nothing needs to: the signal rises
#   once when DDR3 calibration finishes and never changes again, long before
#   the camera has produced a frame or fifowait has counted its 128 clocks.
#
# WHY IT IS WORTH DOING AND NOT JUST IGNORING
#   Those 103 endpoints and -420ns of TNS were what the timing-driven placer
#   and router were grinding on, and they were unfixable by construction, so
#   the effort was pure waste -- place 7m18s + route 5m14s.  Removing them
#   also makes design-wide SWNS positive, which is what lets a reduced-effort
#   flow (tools/td_build.tcl fast) be safe to use for function-only rebuilds.
#
# WHY THIS EXACT FORM
#   Scoped to the one offending clock pair and one direction, because that
#   group provably carries nothing but ddr_init_cal_done (verified by
#   enumerating all begin/end points in phy_1/final_timing.rpt, 2026-09-05).
#   Clock names come from derive_clocks so they survive netlist renaming --
#   a -from [get_regs data_write_reg[31]*] version would match TD's
#   replication suffixes today and silently match nothing after a re-synth.
#   -nowarn so a future DDR IP revision that renames these clocks degrades to
#   a no-op (the 103 endpoints reappear in the report) instead of adding a
#   critical warning.
#
# THE STRICTLY-CORRECT FIX, NOT DONE HERE
#   A 2-flop reset synchronizer on ddr_init_cal_done in the dfi_clk domain
#   (dfi_clk is available at system_top:226) would leave only the 2
#   synchronizer flops needing this exception instead of 103 endpoints.  Not
#   done in this round on purpose: it is surgery on the DDR3/AXI reset, the
#   highest-blast-radius net in the design, and the board is currently good.
#   See HANDOFF.md 6.6.
#---------------------------------------------------------------------------
# Deliberately one long line, no backslash continuation: every command in this
# file and in the vendor's ddr_ip.sdc is single-line, and it is not worth
# betting a 20-minute build on TD's SDC reader being a full Tcl parser rather
# than a line-based one.
set_false_path -nowarn -from [get_clocks -nowarn {u_ddr_phy/u_ph1_logic_standard_phy/u_clk/u_pll0/pll_inst.clkc[3]}] -to [get_clocks -nowarn {u_ddr_phy/u_ph1_logic_standard_phy/u_clk/u_pll1/pll_inst.clkc[0]}]

#---------------------------------------------------------------------------
# S_hs_rx_clk <-> DDR PLL domains : the same reset CDC, one domain further
#   Added 2026-09-15 after the FIRST build that constrained S_hs_rx_clk.
#
# WHAT THAT BUILD REPORTED
#   Three cross-domain path groups, and every violating endpoint in the whole
#   design was in one of them:
#     S_hs_rx_clk        -> u_pll1/pll_inst.clkc[0]   SWNS -4.080ns,  9 eps
#     u_pll0/clkc[3]     -> S_hs_rx_clk               SWNS -0.695ns, 11 eps
#     u_pll1/clkc[0]     -> S_hs_rx_clk               HWNS -1.590ns, 12 eps
#
#   Every one of them is "Check Type: recovery" (or the removal half), the
#   endpoint is a .asr async-set/reset pin inside uidbuf's wdbuf_fifo, and the
#   launch point is either uidbuf's own wrst_cnt or -- for the clkc[3] group --
#   u_mcu/u_cpu/system_gpioCtrl/data_write_reg[31] inside the DDR hard macro.
#   That is the exact same reset family as the 103-endpoint case above: the
#   DDR init/soft-reset handshake landing on FIFO reset pins.  It is a reset
#   release, not a data path; the FIFO is held in reset across it by
#   construction, so there is no per-edge timing relationship to meet.
#
# WHY set_clock_groups DID NOT ALREADY COVER IT
#   The -exclusive group list above names clocks by their derive_clocks
#   aliases (cam_clk_24m / pclkx1 / u_ddr_phy/dfi_clk).  The two DDR PLL
#   output clocks that show up in these reports -- u_pll1/clkc[0] (the 200MHz
#   user-interface clock) and u_pll0/clkc[3] -- are NOT in any group under any
#   name the reader resolved, which is the same reason the 103-endpoint fix
#   above had to be written against raw pin paths.  So: raw pin paths here
#   too, matching the line above verbatim, and both directions on each pair
#   so a future P&R draw that exposes the mirror check is a no-op instead of
#   another 16-minute round trip.
#
# EXPECTED EFFECT, to be checked against the next report
#   All 32 violating endpoints gone, as in the 103-endpoint case.  Build time
#   should also drop back toward v2's ~10min from this round's 16m44s: the
#   11m44s P&R was largely the router grinding on endpoints that can never
#   close (HANDOFF 7.6).  pclkx1's own -0.290ns is a SEPARATE problem, see
#   the block below.
#---------------------------------------------------------------------------
set_false_path -nowarn -from [get_clocks -nowarn {S_hs_rx_clk}] -to [get_clocks -nowarn {u_ddr_phy/u_ph1_logic_standard_phy/u_clk/u_pll1/pll_inst.clkc[0]}]
set_false_path -nowarn -from [get_clocks -nowarn {u_ddr_phy/u_ph1_logic_standard_phy/u_clk/u_pll1/pll_inst.clkc[0]}] -to [get_clocks -nowarn {S_hs_rx_clk}]
set_false_path -nowarn -from [get_clocks -nowarn {u_ddr_phy/u_ph1_logic_standard_phy/u_clk/u_pll0/pll_inst.clkc[3]}] -to [get_clocks -nowarn {S_hs_rx_clk}]
set_false_path -nowarn -from [get_clocks -nowarn {S_hs_rx_clk}] -to [get_clocks -nowarn {u_ddr_phy/u_ph1_logic_standard_phy/u_clk/u_pll0/pll_inst.clkc[3]}]

#---------------------------------------------------------------------------
# pclkx1 intra-domain -0.290ns : det_binarize's block-accumulator RMW
#   NOT ENABLED THIS ROUND -- read before uncommenting.
#
# The same first build reported pclkx1 at Fmax 143.761MHz / SWNS -0.290ns /
# STNS -1.404ns over 12 endpoints, against v2's +0.103ns.  The worst path is
#   u_det_binarize/ramread0.clkb -> u_det_binarize/ramread1.dia[6]
#   Logic Level 10 (ADDER=6 LUT3=2 LUT2=1 ERAM=1), 6.489ns of which 63% is
#   cell delay -- a combinational depth problem, not routing.
#
# That is the read-modify-write of the per-block accumulator added 2026-09-09
# (HANDOFF 3.-4 A).  Note this is its FIRST P&R ever: the 09-09 round was
# never compiled, so "pclkx1 can only regress by P&R draw, no LUT was added"
# in HANDOFF 3.-5-H.3 does not apply -- real new arithmetic went in.
#
# The RMW fires 15 times per 1920-pixel line, i.e. once every 128 clocks, so
# it has ~127 idle cycles the timer knows nothing about.  A multicycle
# exception is therefore free and correct, and is far cheaper than pipelining
# the adder chain (which would need dtb re-verified, and dtb does not even
# build right now -- HANDOFF 3.-5-F).
#
# Deliberately NOT enabled in this round: the round's job is to confirm the
# Bayer phase, and the four set_false_path lines above are expected to pull
# pclkx1 back on their own (when the 103-endpoint exception went in, the
# router stopped grinding and even the 3 unrelated JTAG hold violations
# closed).  -0.290ns over 12 endpoints only perturbs one block's threshold in
# the F9 detection layer; it does not touch the displayed picture.  Enable
# these two lines only if pclkx1 is still negative in the NEXT report, and
# verify TD accepts the syntax before trusting the result.
#
# set_multicycle_path 2 -setup -from [get_cells -nowarn {u_det_binarize/ramread0*}] -to [get_cells -nowarn {u_det_binarize/ramread1*}]
# set_multicycle_path 1 -hold  -from [get_cells -nowarn {u_det_binarize/ramread0*}] -to [get_cells -nowarn {u_det_binarize/ramread1*}]

#---------------------------------------------------------------------------
# 2026-11-02 timing cleanup -- constraint-only, no RTL / netlist change.
#
# (A) DDR calibration MCU clock -> pclkx1 : ddr_init_cal_done -> fifowait
#   The 11-01 build's only setup violations (SWNS -1.730ns, 9 of 27
#   endpoints) are all "recovery" checks on fifowait_reg[*].asr, launched by
#   u_mcu/u_cpu/system_gpioCtrl/data_write_reg[31] -- the same
#   ddr_init_cal_done net already false-pathed to the DDR UI clock above.
#   In the pclkx1 domain it feeds exactly one thing, the async clear of the
#   fifowait power-up counter (system_top.v:777).  It rises once after DDR
#   calibration and never toggles again; when it releases, every fifowait
#   bit except [0] has D=0, so the release edge cannot change any value,
#   and a late release of bit 0 only delays the 128-clock count by one.
#   All 27 endpoints of this clock pair were enumerated on 11-02 and every
#   one is a fifowait register or a TD replica of fifowait[7].
set_false_path -nowarn -from [get_clocks -nowarn {u_ddr_phy/u_ph1_logic_standard_phy/u_clk/u_pll0/pll_inst.clkc[3]}] -to [get_clocks -nowarn {pclkx1}]

# (B) Ethernet PHY-reset clock (eth PLL clkc[2], 25MHz from the board
#   oscillator) <-> eth_rxc (recovered by the external PHY from the link
#   partner).  The two have no phase relationship at all, so the removal
#   check TD made between them (HWNS -0.238ns, phy_rst_req -> mac_rx
#   rst_cnt.asr) has no physical meaning.  eth_rxc is already declared
#   exclusive to pclkx1 / eth_tx_clk above; this adds the one eth PLL
#   output that line did not name.
set_false_path -nowarn -from [get_clocks -nowarn {u_eth_a_video/u_eth_pll/pll_inst.clkc[2]}] -to [get_clocks -nowarn {eth_rxc}]
set_false_path -nowarn -from [get_clocks -nowarn {eth_rxc}] -to [get_clocks -nowarn {u_eth_a_video/u_eth_pll/pll_inst.clkc[2]}]
