`timescale 1ns/1ps
// linhtb -- light_inhibit.  2026-10-05.
// vs is a free-running 100-clock frame (80 high).  inhibit is sampled once per
// frame, right after the vs rising edge has had time to update it, into
// samp[]; every check is then a statement about that frame sequence.
//  I1 no change -> never inhibits.
//  I2 a change mid-frame: the frame it happens in is NOT inhibited (inhibit
//     is stable across a frame), the next N frames are, then it drops.
//  I3 inhibit only ever changes on a vs rising edge.
//  I4 a change during the hold restarts the count.
//  I5 two changes before one edge = one hold, not two.
//  I6 a change on the very clock of the vs rising edge, and one clock before
//     it, are both caught.
module linhtb;
reg clk = 0, rst_n = 0;
always #5 clk = ~clk;
localparam N = 4, PER = 100, HI = 80;

reg  vs = 0, chg = 0;
wire inh;
light_inhibit #(.N(N)) dut (.clk(clk), .rst_n(rst_n), .vs(vs), .chg(chg), .inhibit(inh));

integer errs = 0, ph = 0, fi = 0, bad_edge = 0;
reg samp [0:199];
always @(posedge clk) begin
    ph <= (ph == PER - 1) ? 0 : ph + 1;
    vs <= (ph < HI) ? 1'b1 : 1'b0;           // vs is first high when ph == 1
    if (ph == 5) begin samp[fi] = inh; fi = fi + 1; end
end
// inhibit may only change on the clock after the one where vs is first high
reg inh_q = 0;
always @(posedge clk) begin
    inh_q <= inh;
    if (rst_n && inh !== inh_q && ph != 2) bad_edge = bad_edge + 1;
end

task chk(input c, input [8*48-1:0] msg); begin
    if (!c) begin errs = errs + 1; $display("FAIL %0s", msg); end
    else $display("pass %0s", msg);
end endtask

task frames(input integer n); integer i; begin
    for (i = 0; i < n; i = i + 1) begin wait (ph == 50); wait (ph == 51); end
end endtask

task chg_at(input integer p); begin       // one-clock chg during the cycle ph == p
    wait (ph == p - 1);
    @(posedge clk) chg <= 1;
    @(posedge clk) chg <= 0;
end endtask

// count ones in samp[a .. a+len-1]
function integer ones(input integer a, input integer len); integer i; begin
    ones = 0; for (i = 0; i < len; i = i + 1) if (samp[a+i]) ones = ones + 1;
end endfunction

integer k0, k1;
initial begin
    #52 rst_n = 1;
    frames(10);
    chk(ones(0, fi) == 0, "I1 idle: never inhibits");

    // I2: change at ph 50
    chg_at(50);                     // after this frame's ph==5 sample
    k0 = fi;                        // first frame NOT yet sampled
    frames(N + 4);
    chk(samp[k0] == 1, "I2a next frame boundary raises it");
    chk(ones(k0, N) == N && samp[k0+N] == 0, "I2b held exactly N frames");
    chk(ones(k0 + N, 4) == 0, "I2c stays down afterwards");

    // I4: change, then another 2 frames into the hold
    frames(4);
    chg_at(30);
    k0 = fi;
    frames(2);                      // now in frame T+1, one boundary into the hold
    chg_at(60);
    frames(N + 6);
    chk(ones(k0, N + 1) == N + 1 && samp[k0+N+1] == 0, "I4 change inside hold restarts the count");

    // I5: two changes before the same edge
    frames(4);
    chg_at(20); chg_at(50);
    k0 = fi;
    frames(N + 4);
    chk(ones(k0, N) == N && samp[k0+N] == 0, "I5 two changes, one edge = one hold");

    // I6a: chg during the cycle just before vs rises (ph == 0)
    frames(4);
    k0 = fi;
    chg_at(100);                     // waits for ph == 99; chg is high while ph == 0
    frames(N + 4);
    chk(ones(k0, N) == N && samp[k0+N] == 0, "I6a change one clock before the vs edge");

    // I6b: chg during the cycle where vs is first high (ph == 1)
    frames(4);
    k0 = fi;
    chg_at(1);
    frames(N + 4);
    chk(ones(k0, N) == N && samp[k0+N] == 0, "I6b change on the vs edge clock");

    chk(bad_edge == 0, "I3 inhibit changed only on vs edges");
    if (errs == 0) $display("LINHTB ALL PASS"); else $display("LINHTB %0d FAIL", errs);
    $finish;
end
endmodule
