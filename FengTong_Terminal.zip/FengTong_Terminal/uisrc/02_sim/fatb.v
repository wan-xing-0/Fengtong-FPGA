`timescale 1ns/1ps
// fatb -- face_assoc.  2026-10-05 evening.
//  Tracker box (600..900, 500..800), margins MX=128 / MY_UP=216 / MY_DN=72
//  -> accepted face centres x 472..1028, y 284..872.
//  A. face centre inside the grown box -> person, fx/fy = centre
//  B. head ABOVE the box (inside MY_UP) -> person   (the arm-moves case)
//  C. face far away -> no person; just outside each edge -> no person
//  D. two faces, one far one near -> person, centre of the near one
//  E. box_v = 0 -> no person; use_box = 0 -> any face; !en -> 0
//  F. decision only changes on the vs rising edge
module fatb;
reg clk = 0, rst_n = 0;
always #5 clk = ~clk;
integer errs = 0;

reg vs = 0, en = 1, use_box = 1, box_v = 1;
reg [11:0] bx0 = 600, bx1 = 900, by0 = 500, by1 = 800;
reg [47:0] fx0 = 0, fx1 = 0, fy0 = 0, fy1 = 0;
reg [3:0]  f_vld = 0;
wire person; wire [11:0] fx, fy;

face_assoc #(.NROI(4)) dut (
    .clk(clk), .rst_n(rst_n), .vs(vs), .en(en), .use_box(use_box),
    .box_v(box_v), .bx0(bx0), .bx1(bx1), .by0(by0), .by1(by1),
    .fx0(fx0), .fx1(fx1), .fy0(fy0), .fy1(fy1), .f_vld(f_vld),
    .person(person), .fx(fx), .fy(fy));

// G. 10-06 PERSON_HOLD = 3 instance
wire p3; wire [11:0] fx3, fy3;
face_assoc #(.NROI(4), .PERSON_HOLD(3)) dut3 (
    .clk(clk), .rst_n(rst_n), .vs(vs), .en(en), .use_box(1'b0),
    .box_v(box_v), .bx0(bx0), .bx1(bx1), .by0(by0), .by1(by1),
    .fx0(fx0), .fx1(fx1), .fy0(fy0), .fy1(fy1), .f_vld(f_vld),
    .person(p3), .fx(fx3), .fy(fy3));

task frame; begin
    repeat (3) @(posedge clk); vs <= 1; repeat (3) @(posedge clk); vs <= 0;
    repeat (3) @(posedge clk);
end endtask
// face i with centre (cx, cy), 100 px square
task face(input integer i, input integer cx, input integer cy); begin
    fx0[i*12 +: 12] = cx - 50; fx1[i*12 +: 12] = cx + 50;
    fy0[i*12 +: 12] = cy - 50; fy1[i*12 +: 12] = cy + 50;
    f_vld[i] = 1;
end endtask
task chk(input c, input [8*56-1:0] msg); begin
    if (!c) begin errs = errs + 1; $display("FAIL %0s (person=%b fx=%0d fy=%0d)", msg, person, fx, fy); end
    else $display("pass %0s", msg);
end endtask

initial begin
    #50 rst_n = 1;
    frame; chk(!person, "A0 no face -> no person");
    face(0, 750, 650); frame;
    chk(person && fx == 750 && fy == 650, "A1 face inside box -> person, centre");
    face(0, 750, 320); frame;
    chk(person && fy == 320, "B1 head 180 px above box -> person");
    face(0, 1500, 300); frame;
    chk(!person, "C1 far face -> no person");
    face(0, 470, 650); frame; chk(!person, "C2 just left of margin");
    face(0, 1030, 650); frame; chk(!person, "C3 just right of margin");
    face(0, 750, 282); frame; chk(!person, "C4 just above MY_UP");
    face(0, 750, 874); frame; chk(!person, "C5 just below MY_DN");
    face(0, 474, 286); frame; chk(person, "C6 inside corner -> person");
    face(0, 1500, 300); face(2, 800, 600); frame;
    chk(person && fx == 800 && fy == 600, "D1 far + near face -> the near one");
    box_v = 0; frame; chk(!person, "E1 no tracker box -> no person");
    use_box = 0; f_vld = 4'b0001; frame;
    chk(person && fx == 1500, "E2 use_box=0 -> any face");
    use_box = 1; box_v = 1; face(0, 750, 650); frame;
    chk(person, "F0 setup");
    f_vld = 0; repeat (20) @(posedge clk);
    chk(person, "F1 holds until the next vs edge");
    frame; chk(!person, "F2 updates on the vs edge");
    face(0, 750, 650); frame; en = 0; @(posedge clk); @(posedge clk);
    chk(!person, "E3 !en -> 0");
    en = 1; f_vld = 0; frame; frame; frame; frame;
    chk(!p3, "G0 hold instance idle");
    face(1, 300, 400); frame;
    chk(p3 && fx3 == 300, "G1 face -> person");
    f_vld = 0; frame; frame; frame;
    chk(p3 && fx3 == 300 && fy3 == 400, "G2 held 3 frames, position frozen");
    chk(!person, "G3 the no-hold instance dropped at once");
    frame;
    chk(!p3, "G4 drops on the 4th empty frame");
    face(1, 300, 400); frame; f_vld = 0; frame; frame;
    face(1, 500, 600); frame; f_vld = 0; frame; frame; frame;
    chk(p3 && fx3 == 500, "G5 a new sighting reloads the hold");
    if (errs == 0) $display("FATB ALL PASS"); else $display("FATB %0d FAIL", errs);
    $finish;
end
endmodule
