`timescale 1ns/1ps
// alrtb -- i2s_player + alert_ctrl.  2026-10-04.
//  A. I2S decode: a receiver samples DIN on BCLK rising edges, splits on LRC,
//     and every decoded left/right word must equal ROM byte<<8 in order,
//     for the whole clip, then silence.  Also checks the bit clock period.
//  B. busy drops after exactly LEN samples; a play while busy is ignored.
//  C. alert_ctrl: greeting once, escalation after ESC_S, repeat after
//     REPEAT_S, no re-greeting on a flicker shorter than REARM_S, re-greeting
//     after a long absence, everything off when !en.  (Fill light: lmtb.v.)
//     C runs with person = 1 = "confirmed on arrival", the pre-10-05 behaviour.
//  D. 10-05 three levels: motion alone = spot, silent, level 1; NOFACE_S s of
//     motion -> greeting, level 3; ⭐ a dropout + re-acquire does NOT restart
//     that clock; a later face upgrades to level 2; a face confirms at once.
module alrtb;
reg clk = 0, rst_n = 0;
always #3.333 clk = ~clk;          // 150 MHz

localparam HALF = 4;               // fast BCLK for sim
localparam L0 = 40, L1 = 25;
integer errs = 0;

// ROM file: clip0 = 0..39 ramp*3, clip1 = negative pattern
integer fd, i;
reg [7:0] ref [0:L0+L1-1];
initial begin
    fd = $fopen("alrtb_rom.hex", "w");
    for (i = 0; i < L0 + L1; i = i + 1) begin
        ref[i] = (i < L0) ? (i * 3 + 1) : (8'h80 + i * 5);
        $fwrite(fd, "%02x\n", ref[i]);
    end
    $fclose(fd);
end

reg  play = 0; reg [1:0] clip = 0;
wire busy, bclk, lrc, din;
i2s_player #(.BCLK_HALF(HALF), .ROM_AW(16), .ROM_DEPTH(L0+L1),
             .VOICE_FILE("alrtb_rom.hex"),
             .START0(0), .LEN0(L0), .START1(L0), .LEN1(L1)) dut (
    .clk(clk), .rst_n(rst_n), .play(play), .clip(clip),
    .busy(busy), .o_bclk(bclk), .o_lrc(lrc), .o_din(din));

// ---- I2S receiver (Philips: MSB 1 BCLK after LRC edge, 16 bits) ----
reg        lrc_q = 1;
reg [15:0] sh = 0;
reg [15:0] wl;
integer    nframes = 0;
reg [15:0] frames_l [0:9999];
reg [15:0] frames_r [0:9999];
// Philips: the LSB of a slot is the bit sampled on the edge where LRC has
// already flipped, so the 16 most recent bits INCLUDING this one are the word.
wire [15:0] word = {sh[14:0], din};
always @(posedge bclk) begin
    sh    <= word;
    lrc_q <= lrc;
    if (lrc != lrc_q && lrc_q == 0) wl <= word;
    if (lrc != lrc_q && lrc_q == 1) begin
        if (nframes < 10000) begin frames_l[nframes] = wl; frames_r[nframes] = word; end
        nframes = nframes + 1;
    end
end

// ---- BCLK period check ----
realtime tb_last = 0; integer bad_per = 0;
always @(posedge bclk) begin
    if (tb_last != 0 && ($realtime - tb_last) > 6.67*2*HALF + 0.5) bad_per = bad_per + 1;
    tb_last = $realtime;
end

// ---- alert_ctrl ----
reg en = 0, target = 0, person = 1;
wire a_play, spot; wire [1:0] a_clip, lvl;
reg  pbusy = 0;
alert_ctrl #(.TICK_CLKS(100), .ESC_S(6), .REPEAT_S(8), .REARM_S(5), .NOFACE_S(2)) actl (
    .clk(clk), .rst_n(rst_n), .en(en), .target(target), .person(person),
    .player_busy(pbusy), .play(a_play), .clip(a_clip), .spot_en(spot), .level(lvl));
// E. 10-06 SPOT_HOLD_CLKS: a second instance, same inputs except its own target.
reg  t2 = 0, en2 = 0;
wire spot2; wire p2; wire [1:0] c2, l2;
alert_ctrl #(.TICK_CLKS(100), .SPOT_HOLD_CLKS(50)) actl2 (
    .clk(clk), .rst_n(rst_n), .en(en2), .target(t2), .person(1'b1),
    .player_busy(1'b0), .play(p2), .clip(c2), .spot_en(spot2), .level(l2));
reg  spot2_q = 0; integer sp2_edges = 0;
always @(posedge clk) begin spot2_q <= spot2; if (spot2 != spot2_q) sp2_edges = sp2_edges + 1; end
integer n0 = 0, n1 = 0;
always @(posedge clk) if (a_play) begin
    if (a_clip == 0) n0 = n0 + 1; else n1 = n1 + 1;
end
task secs(input integer s); begin repeat (s * 100) @(posedge clk); end endtask
task csec(input integer c); begin repeat (c) @(posedge clk); end endtask   // 1/100 s
task chk(input c, input [8*48-1:0] msg); begin
    if (!c) begin errs = errs + 1; $display("FAIL %0s  (n0=%0d n1=%0d spot=%b)", msg, n0, n1, spot); end
    else $display("pass %0s", msg);
end endtask

integer f0, k, m, d0;
initial begin
    #100 rst_n = 1;
    // ---------------- A/B
    repeat (2000) @(posedge clk);
    f0 = nframes;
    @(posedge clk) begin play <= 1; clip <= 0; end
    @(posedge clk) play <= 0;
    @(posedge clk);
    chk(busy, "A0 busy after play");
    repeat (500) @(posedge clk);
    @(posedge clk) begin play <= 1; clip <= 1; end     // must be ignored
    @(posedge clk) play <= 0;
    wait (!busy);
    repeat (64 * 2 * HALF * 4) @(posedge clk);
    // find the clip in the decoded stream: first nonzero frame
    k = f0; while (k < nframes && frames_l[k] == 0) k = k + 1;
    m = 0;
    for (i = 0; i < L0; i = i + 1)
        if (frames_l[k+i] !== {ref[i], 8'h00} || frames_r[k+i] !== {ref[i], 8'h00}) begin
            if (m < 4) $display("  sample %0d: got L=%h R=%h want %h00", i, frames_l[k+i], frames_r[k+i], ref[i]);
            m = m + 1;
        end
    chk(m == 0, "A1 all clip0 samples decoded bit-exact (L and R)");
    chk(frames_l[k+L0] == 0 && frames_l[k+L0+3] == 0, "A2 silence after clip");
    chk(bad_per == 0, "A3 BCLK period steady");
    // B: second play during busy was ignored -> no clip1 pattern anywhere
    m = 0; for (i = f0; i < nframes && i < 10000; i = i + 1) if (frames_l[i] == {ref[L0], 8'h00}) m = m + 1;
    chk(m == 0, "B1 play while busy ignored");
    // clip1 plays when idle
    f0 = nframes;
    @(posedge clk) begin play <= 1; clip <= 1; end
    @(posedge clk) play <= 0;
    @(posedge clk);
    wait (!busy); repeat (64 * 2 * HALF * 4) @(posedge clk);
    k = f0; while (k < nframes && frames_l[k] == 0) k = k + 1;
    m = 0; for (i = 0; i < L1; i = i + 1) if (frames_l[k+i] !== {ref[L0+i], 8'h00}) begin
        if (m < 4) $display("  c1 sample %0d: got %h want %h00", i, frames_l[k+i], ref[L0+i]); m = m + 1; end
    chk(m == 0, "B2 clip1 decoded bit-exact");

    // ---------------- C
    en = 1; secs(1);
    chk(!spot && n0 == 0, "C0 idle: spot off, silent");
    target = 1; secs(1);
    chk(n0 == 1 && n1 == 0 && spot, "C1 greeting once, spot on");
    secs(6);
    chk(n1 == 1, "C2 escalation after ESC_S");
    secs(8);
    chk(n1 == 2 && n0 == 1, "C3 repeat after REPEAT_S, no re-greeting");
    target = 0; secs(2);
    chk(!spot, "C4 short absence: spot off");
    target = 1; secs(1);
    chk(n0 == 1, "C5 flicker < REARM_S does not re-greet");
    target = 0; secs(7);
    target = 1; secs(1);
    chk(n0 == 2, "C6 re-greeting after long absence");
    target = 0; secs(2);
    en = 0; target = 1; secs(3);
    chk(!spot && n0 == 2, "C9 !en: nothing");
    // busy blocks requests
    en = 1; target = 0; secs(6); pbusy = 1; target = 1; secs(2);
    chk(n0 == 2, "C10 no request while player busy");
    pbusy = 0; secs(1);
    chk(n0 == 3, "C11 request issued once busy drops");

    // ---------------- D (person = 0 unless stated)
    person = 0; target = 0; secs(7);
    chk(lvl == 0, "D0 episode over after REARM_S");
    d0 = n0;
    target = 1; csec(150);
    chk(n0 == d0 && spot && lvl == 1, "D1 motion only: spot on, silent, level 1");
    target = 0; csec(100);                   // box drops out for 1 s ...
    chk(!spot && lvl == 1 && n0 == d0, "D2 dropout: spot off, episode kept");
    target = 1; csec(120);                   // ... and re-acquires
    // 1.5 s + up to 1 tick before the gap + 1.2 s after: >= 2 s of target.
    // A clock that restarted on re-acquire would still be at 1.2 s here.
    chk(n0 == d0 + 1 && lvl == 3, "D3 NOFACE_S reached across a dropout -> greet, level 3");
    person = 1; csec(5); person = 0; csec(5);
    chk(lvl == 2 && n0 == d0 + 1, "D4 a later face upgrades to level 2, no re-greet");
    target = 0; secs(7);
    chk(lvl == 0, "D5 rearmed");
    target = 1; csec(50);
    chk(n0 == d0 + 1 && lvl == 1, "D6 new episode, 0.5 s, no face yet: silent");
    person = 1; csec(3);
    chk(n0 == d0 + 2 && lvl == 2, "D7 face confirms immediately (before NOFACE_S)");
    person = 0; target = 0; secs(7);
    d0 = n0;
    target = 1; csec(190);
    chk(n0 == d0, "D8 1.9 s of motion: not yet");
    csec(20);
    chk(n0 == d0 + 1, "D9 2.1 s: greeted (tick restarted at episode start)");
    en = 0; csec(2);
    chk(lvl == 0 && !spot, "D10 !en: level 0");

    // ---------------- E
    en2 = 1; csec(1);
    chk(!spot2, "E0 idle: spot off");
    sp2_edges = 0;
    repeat (40) begin t2 = 1; repeat (7) @(posedge clk); t2 = 0; repeat (20) @(posedge clk); end
    chk(spot2 && sp2_edges == 1, "E1 target flickering (gaps < hold): spot on once, never strobes");
    repeat (25) @(posedge clk);          // the loop already ended with 20 off
    chk(spot2, "E2 still on 45 clocks after the last target (hold 50)");
    repeat (10) @(posedge clk);
    chk(!spot2 && sp2_edges == 2, "E3 off once the hold runs out");
    t2 = 1; @(posedge clk); @(posedge clk); t2 = 0; en2 = 0; @(posedge clk); @(posedge clk);
    chk(!spot2, "E4 !en: off at once, no hold");

    if (errs == 0) $display("ALRTB ALL PASS"); else $display("ALRTB %0d FAIL", errs);
    $finish;
end
endmodule
