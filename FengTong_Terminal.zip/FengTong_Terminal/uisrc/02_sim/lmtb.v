`timescale 1ns/1ps
// lmtb -- light_meter (ambient-driven fill light).  2026-10-05 (metric: mean - lo).
// A small synthetic "frame" (W x H) whose G level = ambient + (light_on ?
// LIGHT : 0), i.e. the light really feeds back into what is measured --
// the case that makes a plain threshold oscillate.
//  M  mean is exact for a flat frame; a short frame is ignored.
//  D  bright room -> stays off; dark room -> on after DARK_FR frames.
//  F  with the light adding a lot (LIGHT = 60 >> ON_TH+HYST) it STAYS on
//     (no oscillation: counts toggles over many frames).
//  R  room light comes back -> off after BRIGHT_FR (and MIN_ON) frames.
//  H  ambient hovering right at ON_TH does not chatter.
//  E  en = 0 forces off; re-enabled in the dark -> on again.
module lmtb;
reg clk = 0, rst_n = 0;
always #5 clk = ~clk;

localparam W = 64, H = 32;             // 2048 px -> SUM_SHIFT 11
integer errs = 0;

reg        en = 1;
reg        vs = 0, de = 0;
reg  [7:0] g = 0;
reg  [7:0] lo = 0;
wire       on;
wire [7:0] mean, sig, amb;

light_meter #(.ON_TH(20), .HYST(8), .DARK_FR(5), .BRIGHT_FR(6),
              .SETTLE_FR(3), .MIN_ON_FR(10), .MIN_OFF_FR(4),
              .SUM_SHIFT(11), .MIN_PIX(1024)) dut (
    .clk(clk), .rst_n(rst_n), .en(en), .in_vs(vs), .in_de(de), .in_g(g), .lo(lo),
    .light_on(on), .mean(mean), .sig(sig), .ambient(amb));

integer ambient_lvl = 100, LIGHT = 60, toggles = 0;
reg on_q = 0;
always @(posedge clk) begin on_q <= on; if (on != on_q) toggles = toggles + 1; end

task frame(input integer h); integer x, y, lv; begin
    lv = ambient_lvl + (on ? LIGHT : 0); if (lv > 255) lv = 255;
    @(posedge clk) vs <= 1;
    for (y = 0; y < h; y = y + 1) begin
        for (x = 0; x < W; x = x + 1) begin @(posedge clk) begin de <= 1; g <= lv; end end
        @(posedge clk) de <= 0;
    end
    @(posedge clk) vs <= 0;
    repeat (4) @(posedge clk);
end endtask
task frames(input integer n); integer i; begin for (i = 0; i < n; i = i + 1) frame(H); end endtask

task chk(input c, input [8*56-1:0] msg); begin
    if (!c) begin errs = errs + 1; $display("FAIL %0s  (on=%b mean=%0d amb=%0d toggles=%0d)", msg, on, mean, amb, toggles); end
    else $display("pass %0s", msg);
end endtask

integer t0;
initial begin
    #50 rst_n = 1;
    ambient_lvl = 100; frames(2);
    chk(mean == 100, "M1 flat frame mean exact");
    frame(8);                                    // 512 px < MIN_PIX
    chk(mean == 100, "M2 short frame ignored");
    frames(20);
    chk(!on, "D1 bright room: off");
    ambient_lvl = 10; frames(4);
    chk(!on, "D2 dark < DARK_FR frames: still off");
    frames(2);
    chk(on, "D3 dark DARK_FR frames: on");
    t0 = toggles; frames(60);
    chk(on && toggles == t0, "F1 light feeds back (+60) but stays on, no toggling");
    chk(amb >= 8 && amb <= 12, "F2 ambient estimate = mean - learned light");
    ambient_lvl = 15; frames(20);
    chk(on, "F3 room a bit brighter but still dark: stays on");
    ambient_lvl = 120; frames(5);
    chk(on, "R1 room light back < BRIGHT_FR frames: still on");
    frames(3);
    chk(!on, "R2 room light back: off");
    t0 = toggles; frames(30);
    chk(!on && toggles == t0, "R3 stays off in a bright room");
    // hover at the threshold, +-3 frame to frame
    ambient_lvl = 21; frames(10); ambient_lvl = 18; frames(2); ambient_lvl = 22; frames(2);
    ambient_lvl = 19; frames(2); ambient_lvl = 23; frames(10);
    chk(!on, "H1 brief dips below ON_TH (< DARK_FR) ignored");
    ambient_lvl = 17; frames(8);
    t0 = toggles;
    ambient_lvl = 22; frames(4); ambient_lvl = 25; frames(4); ambient_lvl = 21; frames(30);
    chk(on && toggles == t0, "H2 once on, ambient inside the HYST band: no chatter");
    // ---- pedestal: lo = 16 is the sensor's black pedestal, mean includes it
    en = 0; frames(2); en = 1; lo = 16; ambient_lvl = 40; frames(60);
    chk(!on && sig == 24 && mean == 40, "P1 pedestal 16: mean 40 -> sig 24, not dark");
    ambient_lvl = 30; frames(3);
    chk(!on && mean == 30 && sig == 14, "P2 mean 30 > ON_TH but sig = mean - lo = 14");
    frames(4);
    chk(on, "P3 sig 14 < ON_TH: dark -> on (bare mean: bright)");
    en = 0; frames(2); lo = 0;
    chk(!on, "E1 en = 0 forces off");
    ambient_lvl = 5; frames(3); en = 1; frames(7);
    chk(on, "E2 re-enabled in the dark: on");

    if (errs == 0) $display("LMTB ALL PASS"); else $display("LMTB %0d FAIL", errs);
    $finish;
end
endmodule
