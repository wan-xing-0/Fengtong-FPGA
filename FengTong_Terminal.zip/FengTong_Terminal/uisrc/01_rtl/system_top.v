`timescale 1ns/1ns
/*******************************MILIANKE*******************************
*Company : MiLianKe Electronic Technology Co., Ltd.
*WebSite:https://www.milianke.com
*TechWeb:https://www.uisrc.com
*tmall-shop:https://milianke.tmall.com
*jd-shop:https://milianke.jd.com
*taobao-shop1: https://milianke.taobao.com
*Create Date: 2019/12/17
*Module Name:
*File Name:
*Description: 
*The reference demo provided by Milianke is only used for learning. 
*We cannot ensure that the demo itself is free of bugs, so users 
*should be responsible for the technical problems and consequences
*caused by the use of their own products.
*Copyright: Copyright (c) MiLianKe
*All rights reserved.
*Revision: 1.0
*Signal description
*1) I_ input
*2) O_ output
*3) IO_ input output
*3) _n activ low
*4) _dg debug signal 
*5) _r delay or register
*6) S_ state mechine
*********************************************************************/
`timescale 1ps/1ps

`define DRAM_BYTE_NUM 4    // 1 = x8, 2 = x16,4 = x32,8=x64
`define DRAM_SIZE    "4G"     // AP106,AP102=2G ,AP104=4G    1G , 2G , 4G = 256x16bit, 8G    ,ONE DDR particle capacity

//`define XLNX_NATIVE
//`define ALC_NATIVE  
`define MC_AXI  
 
//`define AXI_ATG  
//`define ATG   
//`define DFI
  
module system_top#(
parameter DRAM_TYPE       = "DDR3"  ,            //"DDR4" "DDR3"
parameter ECC             = "OFF",
parameter APP_ADDR_WIDTH  = (`DRAM_SIZE=="1G")?26:(`DRAM_SIZE=="2G")?27:(`DRAM_SIZE == "4G")?28:(`DRAM_SIZE == "8G")?29:28, //512Mx16bit=29 ,256Mx16bit=28 ,128Mx16bit=27,64Mx16bit = 26,
parameter AXI_ID_WIDTH    =  4,                                                                                   
parameter APP_DATA_WIDTH  = (ECC == "ON")? (`DRAM_BYTE_NUM-1)*8*8 : `DRAM_BYTE_NUM*8*8,
parameter APP_MASK_WIDTH  = (ECC == "ON")? (`DRAM_BYTE_NUM-1)*8   : `DRAM_BYTE_NUM*8,
parameter AXI_ADDR_WIDTH  = APP_ADDR_WIDTH+3,
parameter AXI_DATA_WIDTH  = APP_DATA_WIDTH,
parameter DQ_WIDTH        = `DRAM_BYTE_NUM * 8,
parameter DQS_WIDTH       = `DRAM_BYTE_NUM,
parameter DM_WIDTH        = `DRAM_BYTE_NUM,
parameter ADDR_WIDTH      = (DRAM_TYPE=="DDR4")?17:(`DRAM_SIZE=="1G")?13:(`DRAM_SIZE=="2G")?14:(`DRAM_SIZE == "4G")?15:(`DRAM_SIZE == "8G")?16:15, // 512Mx16bit=16 ,256Mx16bit=15,128Mx16bit=14,64Mx16bit=13
parameter ROW_WIDTH       = (`DRAM_SIZE=="1G")?13:(`DRAM_SIZE=="2G")?14:(`DRAM_SIZE == "4G")?15:(`DRAM_SIZE == "8G")?16:15,                        // 512Mx16bit=16 ,256Mx16bit=15,128Mx16bit=14,64Mx16bit=13
parameter COL_WIDTH       = 10,                  //
parameter BA_WIDTH        = 3,                   //
parameter BG_WIDTH        = 1,                   //
parameter ODT_WIDTH       = 1,                   // PP phy 2, single phy 1
parameter CKE_WIDTH       = 1,                   // PP phy 2, single phy 1
parameter CS_WIDTH        = 1                    // PP phy 2, single phy 1

)(
    input                           I_sysclk_25m,
    input                           I_ddr_clk     ,
    input     [3:0]                 I_button  ,
    output    [ADDR_WIDTH-1:0]      ddr_addr    , 
    output    [  BA_WIDTH-1:0]      ddr_ba      ,
    output    [ CKE_WIDTH-1:0]      ddr_cke     ,
    output    [ ODT_WIDTH-1:0]      ddr_odt     ,
    output    [  CS_WIDTH-1:0]      ddr_cs_n    ,
    output                          ddr_ras_n   ,
    output                          ddr_cas_n   ,
    output                          ddr_we_n    ,
    output                          ddr_ck_p    ,
    output                          ddr_ck_n    ,
    output                          ddr_reset_n ,
    inout     [  DM_WIDTH-1:0]      ddr_dm  ,
    inout     [  DQ_WIDTH-1:0]      ddr_dq      ,
    inout     [ DQS_WIDTH-1:0]      ddr_dqs_n   ,
    inout     [ DQS_WIDTH-1:0]      ddr_dqs_p    ,
    output                          O_uart_txd    ,
    input                           I_uart_rxd    ,
    inout                           IO_cam_sda    ,
    output                          O_cam_scl     ,
    output                          O_clk_24m     ,
    output    [2:0]                 O_hdmi_tx_p ,
    output                          O_hdmi_clk_p,

    // 2026-09-23: the SG90 pan/tilt head.  50 Hz PWM, 1000-2000 us.
    //
    // T19 / T18 -- the board's LED2 / LED3 pins, BANK12, LVCMOS33.  Each
    // carries only a red LED and a 2.2 K to VCC_3V3, so they are genuinely
    // free, and the LED becomes a free indicator that the loop is running.
    // The bank-voltage proof and the wiring caveats are in fpga_pin.adc.
    //
    // ⚠ NOT an 1.8 V pin: an SG90 at 5 V needs ~2.5 V for a logic one, and
    // the four I_button lines are on an 1.8 V bank -- copying them is the
    // obvious mistake.
    output                          O_servo_pan  ,
    output                          O_servo_tilt ,

    // 2026-09-25: VL53L1X time-of-flight ranger (Waveshare module), I2C.
    // P16 = LED4 (BANK12) and AC22 = LED1 (BANK11), both 3.3 V, both carrying
    // only an LED + 2.2 K to VCC_3V3 -- the same kind of pin the servos use.
    // Open drain: 0 or Z, never a driven 1.  See vl53l1x_ctrl.v for why the
    // module must be powered from 3.3 V and never from the servos' 5 V.
    // ⚠ 2026-09-30: moved to CEP J14 pins 5/6 (AD6/AD5, 1.8 V) through the
    // BSS138 board's channels 3/4; see fpga_pin.adc.
    inout                           IO_tof_scl   ,
    inout                           IO_tof_sda   ,
    // 2026-09-30: constant 1 on J14 pin 7 (AC4) = the 1.8 V LV-side reference
    // for the BSS138 shifter board (J14 has no 1.8 V power pin).
    output                          O_lvref      ,

    // 2026-10-04: intruder reaction (alert_ctrl / i2s_player), all on J14 at
    // 1.8 V.  Lights go through the second BSS138 board to JZ-MOS modules
    // (need >= 3.3 V); I2S goes straight to a MAX98357A.  See
    // the hardware wiring README.
    output                          O_flood_en   ,   // J14-8  AC3
    output                          O_spot_en    ,   // J14-9  V2
    output                          O_i2s_bclk   ,   // J14-11 Y6
    output                          O_i2s_lrc    ,   // J14-12 Y5
    output                          O_i2s_din    ,   // J14-13 AF5
    // J14 pins 1-7 are all taken by the first BSS138 board, so the second
    // board gets its own constant-1 1.8 V LV reference here (J14-10, V1).
    output                          O_lvref2     ,   // J14-10 V1

    // 2026-10-04 / re-grafted 10-09: ETHA (YT8531, RGMII) for the UDP video
    // preview, the QC workpiece record and full-resolution bursts --
    // ethernet_video/, ETHERNET_V1.md.  Same pins and constraints as the
    // board-verified with_udp v1.0 and new_with_udp.
    output                          O_eth_phy_rst_n,
    input     [3:0]                 I_eth_rgmii_rxd,
    input                           I_eth_rgmii_rx_ctl,
    input                           I_eth_rgmii_rxc,
    output    [3:0]                 O_eth_rgmii_txd,
    output                          O_eth_rgmii_tx_ctl,
    output                          O_eth_rgmii_txc

);                                    

wire        pclkx1;//synthesis keep
wire        pclkx5;//synthesis keep
wire        S_pll_lock;
wire        S_rst = ~S_pll_lock;
wire        S_clk_70m;   // 71.43MHz MIPI D-PHY low power clock

//PLLʱ�ӹ���IP ��� pclkx1��pclkx5�Լ�locked�ź�
pll u_pll(
.refclk   ( I_sysclk_25m  ),//ϵͳʱ������
.lock     ( S_pll_lock    ),//PLL LOCKED
.clk0_out ( pclkx1      ),//����ʱ��
.clk1_out ( pclkx5      ),
.clk2_out ( S_clk_70m   ),// 71.43MHz : MIPI D-PHY low power clock
.clk3_out ( O_clk_24m   ) // 23.81MHz : sensor MCLK / I2C / AE
);

//---------------------------------------------------------------------------
// Camera front end : Sony IMX415 (MLK-CAM002-MIPI-4LANE), MIPI CSI-2 4-lane
// RAW10 -> RAW8, packed 4 pixels per 32-bit word, cropped to 1920x1080 and
// written into the DDR3 frame buffer.
//
// 2026-09-15: replaced the SmartSens SC500AI 2-lane front end.  Everything
// from the DDR3 read side onwards is untouched -- same 32-bit words of 4
// packed RAW8 pixels, same 480 words x 1080 lines geometry in uidbuf, so
// raw8_2_rgb888 / isp_auto_level / isp_gamma / the four algorithm blocks /
// OSD / the L5 detection layer all see exactly what they saw before.  The
// one exception is the demosaic's Bayer phase (see below), which is a sensor
// property and is now a parameter rather than hard-wired.
//
// WHAT CHANGED, AND WHY EACH PIECE HAD TO
//   2 lanes -> 4 lanes.  The module is wired for 4; LANEMODE=3 in the
//     register table.  Same D-PHY hard macro, same site X5Y0Z0, so the pin
//     constraints do not change at all -- lanes 2 and 3 are inside the macro.
//     O_hs_rx_data widens from 16 to 32 bits (LANE_NUM*BYTE_NUM*8).
//   csi_unpacket_2lane -> csi_unpacket_4lane.  Not a parameter change: the
//     2-lane module gates on a 3-deep valid history ({v2d,v1d,v} == 3'b101)
//     because the 2-lane PHY presents a word every other clock.  At 4 lanes
//     every clock carries a word, so the framing logic is a different shape.
//   raw10_unpacket_2lane -> raw8_unpacket_4lane.  New file, 4-lane byte
//     positions, same 32-bit RAW8 output format and byte order.
//   image_correction added.  This is the piece with no counterpart before:
//     SC500AI delivered exactly 1920x1080, IMX415 in 2x2 binning delivers
//     about 1932x1096 and has to be cropped, and the crop also gives us real
//     tuser/tlast instead of the derived line counter that used to live here.
//
// SENSOR CLOCK
//   O_clk_24m is PLL clk3 = 1500MHz/63 = 23.81MHz, and the register table's
//   INCKSEL group assumes 24MHz.  -0.79% scales the sensor's internal timing,
//   so the frame comes out at about 57.7fps instead of 58.2 and the link rate
//   is 0.79% low.  Nothing cares.  The read side runs at 60.6Hz regardless
//   and the triple buffer absorbs the difference by repeating a buffer.
//---------------------------------------------------------------------------
wire        cam_cfg_done;//synthesis keep
wire        ae_cfg_done;//synthesis keep

// AE is wired off, not wired up.  All four buttons are spent on the algorithm
// chain (D8 wheel / D9 morphology / F8 affine / F9 overlays), so there is no
// input left to drive a gain up/down -- the demo's ae_set + key pair would
// synthesise away to nothing, which is why they are not in this tree.  The
// gain that actually takes effect is the one in the register table
// (0x3090..0x3097 GAIN_PGC_0..3).  To get a live knob back: free a button,
// bring ae_set.v + key.v over from the demo, and drive I_ae_req/I_ae_data.
localparam [7:0] SENSOR_GAIN = 8'h30;   // matches uiimx415reg's 0x3090

uicfgimx415#(
.CLK_DIV(24_000_000/100_000-1)      // 100kHz I2C off the 23.81MHz clock
)u_uicfgimx415(
.I_clk         ( O_clk_24m    ),
.I_rst_n       ( S_pll_lock   ),
.I_ae_req      ( 1'b0         ),
.I_ae_data     ( SENSOR_GAIN  ),
.O_cam_scl     ( O_cam_scl    ),
.IO_cam_sda    ( IO_cam_sda   ),
.O_cfg_done    ( cam_cfg_done ),
.O_ae_cfg_done ( ae_cfg_done  )
);

wire        S_hs_rx_clk;   //synthesis keep
wire        S_hs_rx_valid; //synthesis keep
wire [31:0] S_hs_rx_data;  //synthesis keep
wire [3:0]  S_lane_error;  //synthesis keep

// All four idelay taps stay at 0.  The SC500AI front end ran at zero delay
// and the vendor's IMX415 demo also ends up at zero (it assigns 100 to an
// *undeclared* net, which Verilog makes a 1-bit wire, so nothing reaches the
// PHY).  If the 4-lane link turns out to be marginal these are the knob --
// sweep I_clk_lane_in_delay first, it moves all four data lanes at once.
mipi_dphy_rx_ph1a_mipiio_wrapper#(
.LANE_NUM ( 4 ),
.BYTE_NUM ( 1 )
)u_mipi_dphy_rx_ph1a_mipiio_wrapper(
.I_lp_clk              ( S_clk_70m     ),
.I_rst                 ( S_rst         ),
.I_clk_lane_in_delay   ( 9'd0          ),
.I_data_lane0_in_delay ( 9'd0          ),
.I_data_lane1_in_delay ( 9'd0          ),
.I_data_lane2_in_delay ( 9'd0          ),
.I_data_lane3_in_delay ( 9'd0          ),
.I_lane_invert         ( 4'b0000       ),
.O_hs_rx_clk           ( S_hs_rx_clk   ),
.O_hs_rx_valid         ( S_hs_rx_valid ),
.O_hs_rx_data          ( S_hs_rx_data  ),
.I_lp_tx_en            ( 1'b0          ),
.I_lp_tx_lane0_p       ( 1'b0          ),
.I_lp_tx_lane0_n       ( 1'b0          ),
.O_lane_error          ( S_lane_error  )
);

wire        S_csi_frame_start;//synthesis keep
wire        S_csi_frame_end;
wire        S_csi_valid;//synthesis keep
wire [31:0] S_csi_data;//synthesis keep

csi_unpacket_4lane u_csi_unpacket(
.I_clk             ( S_hs_rx_clk       ),
.I_rst_n           ( ~S_rst            ),
.I_hs_valid        ( S_hs_rx_valid     ),
.I_hs_data         ( S_hs_rx_data      ),
.O_csi_frame_start ( S_csi_frame_start ),
.O_csi_frame_end   ( S_csi_frame_end   ),
.O_csi_valid       ( S_csi_valid       ),
.O_csi_data        ( S_csi_data        )
);

wire        S_raw8_frame_start;//synthesis keep
wire        S_raw8_frame_end;//synthesis keep
wire        S_raw8_valid;//synthesis keep
wire [31:0] S_raw8_data;//synthesis keep

raw8_unpacket_4lane u_raw8_unpacket(
.I_clk              ( S_hs_rx_clk        ),
.I_rst_n            ( ~S_rst             ),
.I_csi_frame_start  ( S_csi_frame_start  ),
.I_csi_frame_end    ( S_csi_frame_end    ),
.I_csi_valid        ( S_csi_valid        ),
.I_csi_data         ( S_csi_data         ),
.O_raw8_frame_start ( S_raw8_frame_start ),
.O_raw8_frame_end   ( S_raw8_frame_end   ),
.O_raw8_valid       ( S_raw8_valid       ),
.O_raw8_data        ( S_raw8_data        )
);

// Crop about 1932x1096 down to exactly 480 words x 1080 lines and emit the
// AXI-stream framing uidbuf's write side wants.  X_SKIP/Y_SKIP are the
// demo's values; Y_SKIP=1 is why the delivered Bayer phase is RGGB rather
// than the sensor's native GBRG, which is what sets BAYER_X_ODD below.
// Do not retune the Bayer phase from here -- see raw8_2_rgb888's header.
wire        cam_tuser; //synthesis keep
wire        cam_tvalid;//synthesis keep
wire        cam_tlast; //synthesis keep
wire [31:0] cam_tdata; //synthesis keep

image_correction#(
.DATA_WIDTH ( 32   ),
.X_SKIP     ( 1    ),
.X_WORDS    ( 480  ),   // 480 * 4 px = 1920
.Y_SKIP     ( 1    ),
.Y_LINES    ( 1080 ),
.GAP_CYCLES ( 10   )
)u_image_correction(
.I_clk             ( S_hs_rx_clk        ),
.I_rst_n           ( ~S_rst             ),
.I_raw_data        ( S_raw8_data        ),
.I_raw_valid       ( S_raw8_valid       ),
.I_raw_frame_start ( S_raw8_frame_start ),
.I_raw_frame_end   ( S_raw8_frame_end   ),
.O_raw_tdata       ( cam_tdata          ),
.O_raw_tlast       ( cam_tlast          ),
.O_raw_tvalid      ( cam_tvalid         ),
.O_raw_tuser       ( cam_tuser          )
);


//-------- User Clock --------//
wire                           pll_locked ;
wire                           ddr_init_cal_done  ;
wire                           dfi_clk;
wire    [  3:0]                dfi_reset_n ;
wire    [  CKE_WIDTH*4-1:0]    dfi_cke;
wire    [  ODT_WIDTH*4-1:0]    dfi_odt;
wire    [  CS_WIDTH *4-1:0]    dfi_cs_n;
wire    [  3:0]                dfi_ras_n;
wire    [  3:0]                dfi_cas_n;
wire    [  3:0]                dfi_act_n;
wire    [  3:0]                dfi_we_n;
wire    [  BA_WIDTH*4-1 :0]    dfi_bank;
wire    [  BG_WIDTH*4-1 :0]    dfi_bg;
wire    [  ADDR_WIDTH*4-1:0]   dfi_address;
wire    [  DQS_WIDTH*4-1:0]    dfi_wrdata_en;
wire    [  DQ_WIDTH*8-1:0]     dfi_wrdata;
wire    [  DM_WIDTH*8-1:0]     dfi_wrdata_mask;
wire    [  DQS_WIDTH*4-1:0]    dfi_rddata_en;
wire    [  DQS_WIDTH*4-1:0]    dfi_rddata_valid;
wire    [  DQ_WIDTH*8-1:0]     dfi_rddata;
wire    [  DM_WIDTH*8-1:0]     dfi_rddata_dbi_n;

reg                            init_cal_done_d;
reg                            init_cal_done;

//����APP�ӿ�תAXI�ӿ�

// AXI Write Addr
wire [AXI_ADDR_WIDTH-1:0]      axi_awaddr  ;
wire                           axi_awvalid ;
wire                           axi_awready ;
wire   [AXI_ID_WIDTH-1:0]      axi_awid    ;
wire                [7:0]      axi_awlen   ; 
wire                [2:0]      axi_awsize  ; 
wire                [1:0]      axi_awburst ; 
wire                [0:0]      axi_awlock  ; 
wire                [3:0]      axi_awcache ; 
wire                [2:0]      axi_awprot  ; 
wire                [3:0]      axi_awqos   ;
// AXI Write Data              
wire [APP_DATA_WIDTH-1:0]      axi_wdata   ;
wire [APP_MASK_WIDTH-1:0]      axi_wstrb   ;
wire                           axi_wvalid  ;
wire                           axi_wlast   ;
wire                           axi_wready  ;
// Write Response Port         
wire   [AXI_ID_WIDTH-1:0]      axi_bid     ;    
wire                [1:0]      axi_bresp   ;    
wire                           axi_bvalid  ;    
wire                           axi_bready  ;    
                               
// AXI Read Addr               
wire [AXI_ADDR_WIDTH-1:0]      axi_araddr  ;
wire                           axi_arvalid ;
wire                           axi_arready ;
wire [  AXI_ID_WIDTH-1:0]      axi_arid    ;
wire                [7:0]      axi_arlen   ;
wire                [2:0]      axi_arsize  ;
wire                [1:0]      axi_arburst ;
wire                [0:0]      axi_arlock  ;
wire                [3:0]      axi_arcache ;
wire                [2:0]      axi_arprot  ;
wire                [3:0]      axi_arqos   ;
// AXI Read Data               
wire [APP_DATA_WIDTH-1:0]      axi_rdata   ;
wire                           axi_rlast   ;
wire                           axi_rvalid  ;
wire                           axi_rready  ;
wire   [AXI_ID_WIDTH-1:0]      axi_rid     ;
wire                [1:0]      axi_rresp   ;

//����DDR IP
//===== DDR3 PHY INS =====//
ddr_ip u_ddr_phy (
`ifndef DFI
        .sys_clk                    ( I_ddr_clk      ),
        .sys_rst_n                  ( S_pll_lock        ),
`else
        .sys_clk_p                  ( I_ddr_clk      ),
        .sys_rstn                   ( S_pll_lock        ),
`endif
        .dfi_clk                    ( dfi_clk          ), 
        .pll_locked                 ( pll_locked       ),
//        .user_clk0                  (                  ),
         //DDR bus signals                             
        .ddr_addr                   ( ddr_addr         ),
        .ddr_ba                     ( ddr_ba           ),
        //.ddr_bg                     ( ddr_bg           ),
        .ddr_ck_n                   ( ddr_ck_n         ),
        .ddr_ck_p                   ( ddr_ck_p         ),
        .ddr_ras_n                  ( ddr_ras_n        ),
        .ddr_cas_n                  ( ddr_cas_n        ),
        .ddr_we_n                   ( ddr_we_n         ),  
        //.ddr_act_n                  ( ddr_act_n        ),
        .ddr_cke                    ( ddr_cke          ),
        .ddr_cs_n                   ( ddr_cs_n         ),
        .ddr_dm                     ( ddr_dm ),        
        .ddr_odt                    ( ddr_odt          ),
        .ddr_reset_n                ( ddr_reset_n      ),
        .ddr_dq                     ( ddr_dq           ),
        .ddr_dqs_n                  ( ddr_dqs_n        ),
        .ddr_dqs_p                  ( ddr_dqs_p        ),  

        .uart_txd                   ( O_uart_txd         ),
        .uart_rxd                   ( I_uart_rxd         ),
        .ddr_init_cal_done          ( ddr_init_cal_done    ),

`ifdef DFI
         // DFI bus signals, between hard 
         // controller and users or top-level systems  
        .dfi_reset_n                ( dfi_reset_n      ),
        .dfi_cke                    ( dfi_cke          ),
        .dfi_odt                    ( dfi_odt          ),
        .dfi_cs_n                   ( dfi_cs_n         ),
        .dfi_ras_n                  ( dfi_ras_n        ),
        .dfi_cas_n                  ( dfi_cas_n        ),
        .dfi_we_n                   ( dfi_we_n         ),
        //.dfi_act_n                  ( dfi_act_n        ),
        .dfi_bank                   ( dfi_bank         ),
        //.dfi_bg                     ( dfi_bg           ),
        .dfi_address                ( dfi_address      ),
        .dfi_wrdata_en              ( dfi_wrdata_en    ),
        .dfi_wrdata                 ( dfi_wrdata       ),
        .dfi_wrdata_mask            ( dfi_wrdata_mask  ), 
        .dfi_rddata_en              ( dfi_rddata_en    ),
        .dfi_rddata_valid           ( dfi_rddata_valid ),
        .dfi_rddata                 ( dfi_rddata       ),
        .dfi_rddata_dbi_n           ( dfi_rddata_dbi_n ), 
        .dfi_ctrlupd_req            ( 2'b00            ),
        .dfi_ctrlupd_ack            (                  ),
        .dfi_phyupd_req             (                  ),
        .dfi_phyupd_ack             ( 2'h0             ),
        .dfi_phyupd_type            (                  )

`elsif MC_AXI  
 // Write Addr Ports                            
        .axi_awaddr                 ( axi_awaddr       ),
        .axi_awvalid                ( axi_awvalid      ),
        .axi_awready                ( axi_awready      ),
                                          
        .axi_awid                   ( axi_awid         ),
        .axi_awlen                  ( axi_awlen        ),
        .axi_awsize                 ( axi_awsize       ),
        .axi_awburst                ( axi_awburst      ),
        .axi_awlock                 ( axi_awlock       ),
        .axi_awcache                ( axi_awcache      ),
        .axi_awprot                 ( axi_awprot       ),
        .axi_awqos                  ( axi_awqos        ),
                                                
        // Write Data Port                             
        .axi_wdata                  ( axi_wdata        ),
        .axi_wstrb                  ( axi_wstrb        ),
        .axi_wvalid                 ( axi_wvalid       ),
        .axi_wlast                  ( axi_wlast        ),
        .axi_wready                 ( axi_wready       ),
        // Write Response Port                         
        .axi_bid                    ( axi_bid          ),
        .axi_bresp                  ( axi_bresp        ),
        .axi_bvalid                 ( axi_bvalid       ),
        .axi_bready                 ( axi_bready       ),
        // Read Address Ports                          
        .axi_araddr                 ( axi_araddr       ),
        .axi_arvalid                ( axi_arvalid      ),
        .axi_arready                ( axi_arready      ),
                                          
        .axi_arid                   ( axi_arid         ),
        .axi_arlen                  ( axi_arlen        ),
        .axi_arsize                 ( axi_arsize       ),
        .axi_arburst                ( axi_arburst      ),
        .axi_arlock                 ( axi_arlock       ),
        .axi_arcache                ( axi_arcache      ),
        .axi_arprot                 ( axi_arprot       ),
        .axi_arqos                  ( axi_arqos        ),
                                                 
        // Read Data Ports                                                         
        .axi_rid                    ( axi_rid          ),
        .axi_rresp                  ( axi_rresp        ),                                       
        .axi_rdata                  ( axi_rdata        ),
        .axi_rlast                  ( axi_rlast        ),
        .axi_rvalid                 ( axi_rvalid       ),
        .axi_rready                 ( axi_rready       )
  `else
        // Native
        .paxi_awaddr        ( axi_awaddr       ),
        .paxi_awvalid       ( axi_awvalid      ),
        .paxi_awready       ( axi_awready      ),
        
        .paxi_wdata         ( axi_wdata        ),
        .paxi_wstrb         ( axi_wstrb        ),
        .paxi_wvalid        ( axi_wvalid       ),
        .paxi_wlast         ( axi_wlast        ),
        .paxi_wready        ( axi_wready       ),
        
         // Write Response Port
        .paxi_bid           ( axi_bid          ),
        .paxi_bresp         ( axi_bresp        ),
        .paxi_bvalid        ( axi_bvalid       ),
        .paxi_bready        ( axi_bready       ),
         // Read Address Ports
        .paxi_araddr        ( axi_araddr       ),
        .paxi_arvalid       ( axi_arvalid      ),
        .paxi_arready       ( axi_arready      ),
        
         // Read Data Ports
        .paxi_rdata         ( axi_rdata        ),
        .paxi_rlast         ( axi_rlast        ),
        .paxi_rvalid        ( axi_rvalid       ),
        .paxi_rready        ( axi_rready       )

`endif 
);

wire [AXI_ADDR_WIDTH-1:  0]      fdma_waddr;   //FDMAдͨ����ַ
wire                             fdma_wareq;   //FDMAдͨ������
wire [15: 0]                     fdma_wsize;   //FDMAдͨ��һ��FDMA�Ĵ����С                                       
wire                             fdma_wbusy;   //FDMA����BUSY״̬��AXI��������д���� 		
wire [AXI_DATA_WIDTH-1 : 0]      fdma_wdata;   //FDMAд����
wire                             fdma_wvalid;  //FDMA д��Ч
wire                             fdma_wready;  //FDMAд׼���ã��û�����д����

wire [AXI_ADDR_WIDTH-1:  0]      fdma_raddr;   //FDMA��ͨ����ַ
wire                             fdma_rareq;   //FDMA��ͨ������
wire [15: 0]                     fdma_rsize;   //FDMA��ͨ��һ��FDMA�Ĵ����С                                       
wire                             fdma_rbusy;   //FDMA����BUSY״̬��AXI�������ڶ����� 			
wire [AXI_DATA_WIDTH-1 : 0]      fdma_rdata;   //FDMA������
wire                             fdma_rvalid;  //FDMA ����Ч
wire                             fdma_rready;  //FDMA��׼���ã��û����Զ�����	
wire                             test_error;   //�����Ƿ��д���1�д���0û����

//����������uiFDMA AXI ������ IP
uiFDMA#
(
.M_AXI_B2B_SET(1),
.M_AXI_ID_WIDTH(AXI_ID_WIDTH)           ,//IDλ��
.M_AXI_ADDR_WIDTH(AXI_ADDR_WIDTH)		,//�ڴ��ַλ��
.M_AXI_DATA_WIDTH(AXI_DATA_WIDTH)		,//AXI���ߵ�����λ��
.M_AXI_MAX_BURST_LEN (16)                //AXI���ߵ�burst ��С������AXI4��֧�����ⳤ�ȣ�����AXI3�������16
)
uiFDMA_inst
(
.I_fdma_waddr(fdma_waddr)          ,//FDMAдͨ����ַ
.I_fdma_wareq(fdma_wareq)          ,//FDMAдͨ������
.I_fdma_wsize(fdma_wsize)          ,//FDMAдͨ��һ��FDMA�Ĵ����С                                            
.O_fdma_wbusy(fdma_wbusy)          ,//FDMA����BUSY״̬��AXI��������д����  
				
.I_fdma_wdata(fdma_wdata)		   ,//FDMAд����
.O_fdma_wvalid(fdma_wvalid)        ,//FDMA д��Ч
.I_fdma_wready(1'b1)		       ,//FDMAд׼���ã��û�����д����

.I_fdma_raddr(fdma_raddr)          ,// FDMA��ͨ����ַ
.I_fdma_rareq(fdma_rareq)          ,// FDMA��ͨ������
.I_fdma_rsize(fdma_rsize)          ,// FDMA��ͨ��һ��FDMA�Ĵ����С                                      
.O_fdma_rbusy(fdma_rbusy)          ,// FDMA����BUSY״̬��AXI�������ڶ����� 
				
.O_fdma_rdata(fdma_rdata)		   ,// FDMA������
.O_fdma_rvalid(fdma_rvalid)        ,// FDMA ����Ч
.I_fdma_rready(1'b1)		       ,// FDMA��׼���ã��û����Զ�����

//����ΪAXI�����ź�		
.M_AXI_ACLK                             (dfi_clk),
.M_AXI_ARESETN                          (ddr_init_cal_done),
// Master Interface Write Address Ports
.M_AXI_AWID                             (axi_awid),
.M_AXI_AWADDR                           (axi_awaddr),
.M_AXI_AWLEN                            (axi_awlen),
.M_AXI_AWSIZE                           (axi_awsize),
.M_AXI_AWBURST                          (axi_awburst),
.M_AXI_AWLOCK                           (),
.M_AXI_AWCACHE                          (axi_awcache),
.M_AXI_AWPROT                           (axi_awprot),
.M_AXI_AWQOS                            (),
.M_AXI_AWVALID                          (axi_awvalid),
.M_AXI_AWREADY                          (axi_awready),
// Master Interface Write Data Ports
.M_AXI_WDATA                            (axi_wdata),
.M_AXI_WSTRB                            (axi_wstrb),
.M_AXI_WLAST                            (axi_wlast),
.M_AXI_WVALID                           (axi_wvalid),
.M_AXI_WREADY                           (axi_wready),
// Master Interface Write Response Ports
.M_AXI_BID                              (axi_bid),
.M_AXI_BRESP                            (axi_bresp),
.M_AXI_BVALID                           (axi_bvalid),
.M_AXI_BREADY                           (axi_bready),
// Master Interface Read Address Ports
.M_AXI_ARID                             (axi_arid),
.M_AXI_ARADDR                           (axi_araddr),
.M_AXI_ARLEN                            (axi_arlen),
.M_AXI_ARSIZE                           (axi_arsize),
.M_AXI_ARBURST                          (axi_arburst),
.M_AXI_ARLOCK                           (),
.M_AXI_ARCACHE                          (axi_arcache),
.M_AXI_ARPROT                           (),
.M_AXI_ARQOS                            (),
.M_AXI_ARVALID                          (axi_arvalid),
.M_AXI_ARREADY                          (axi_arready),
// Master Interface Read Data Ports
.M_AXI_RID                              (axi_rid),
.M_AXI_RDATA                            (axi_rdata),
.M_AXI_RRESP                            (axi_rresp),
.M_AXI_RLAST                            (axi_rlast),
.M_AXI_RVALID                           (axi_rvalid),
.M_AXI_RREADY                           (axi_rready)		
);


wire [7:0] wbuf_sync,rbuf_sync;
wire   vtc_rstn ;
wire   vtc_clk;
wire   vtc_vs;//synthesis keep
wire   vtc_hs;//synthesis keep
wire   vtc_user;//synthesis keep
wire   vtc_de_valid;//synthesis keep
wire   vtc_last;
wire ud_wclk, ud_wtuser, ud_wtvalid, ud_wtlast, ud_wtready;  //synthesis keep
wire [31:0] ud_wtdata;
wire ud_rclk;
reg  ud_rfifo_en;//synthesis keep  // read-side tready, 1 of every 4 pixel clocks
wire ud_rtuser;
wire ud_rtvalid;
wire [31:0] ud_rtdata;  //synthesis keep
wire ud_rtlast;

// The write side is the camera now: MIPI byte-clock domain, RAW8 packed
// 4 pixels per 32-bit word.
//
// 2026-09-15: these come from image_correction rather than straight off the
// unpacker.  Two real changes, not just renames:
//   tuser was the MIPI frame-start short packet, which lands in the blanking
//     BEFORE any data; it is now coincident with the first stored word.  Both
//     satisfy uidbuf (one pulse per frame), and coincident is what the
//     vendor's IMX415 demo feeds it.
//   tlast was derived by counting 480 valid words; it is now the real end of
//     the cropped line.  The counter version silently desynchronised if the
//     sensor's line was not exactly 480 words -- which, with IMX415 emitting
//     483, it no longer is.
assign ud_wclk    = S_hs_rx_clk;
assign ud_wtuser  = cam_tuser;
assign ud_wtvalid = cam_tvalid;
assign ud_wtlast  = cam_tlast;
assign ud_wtdata  = cam_tdata;


assign ud_rclk   = pclkx1;


//����uidbuf ������
uidbuf# (
 
.AXI_DATA_WIDTH(AXI_DATA_WIDTH),
.AXI_ADDR_WIDTH(AXI_ADDR_WIDTH),

.W_BUFDEPTH(2048),
.W_DATAWIDTH(32),
.W_BASEADDR(0),
.W_DSIZEBITS(25),
.W_XSIZE(480),   // 1920 RAW8 px = 480 words of 32 bit
.W_XSTRIDE(480),
.W_YSIZE(1080),
.W_XDIV(1),      // 480*32/256 = 60 AXI beats, one burst per line
.W_BUFSIZE(3),

.R_BUFDEPTH(2048),
.R_DATAWIDTH(32),
.R_BASEADDR(0),
.R_DSIZEBITS(25),
.R_XSIZE(480),
.R_XSTRIDE(480),
.R_YSIZE(1080),
.R_XDIV(1),
.R_BUFSIZE(3)
)
uidbuf_u0
(
.I_ui_clk(dfi_clk),
.I_ui_rstn(ddr_init_cal_done),

.I_W_en      (1'b1),
.I_Wsync_en  (1'b1),
.I_W_wclk    (ud_wclk),
.I_W_tuser   (ud_wtuser),
.I_W_tvalid  (ud_wtvalid),
.I_W_tdata   (ud_wtdata),
.I_W_tlast   (ud_wtlast),
.O_W_tready  (),
.O_W_sync_cnt(wbuf_sync),
.I_W_buf     (wbuf_sync),

.I_R_en      (1),
.I_R_rclk    (ud_rclk),
.I_R_tready  (ud_rfifo_en),
.O_R_tuser   (ud_rtuser),
.O_R_tvalid  (ud_rtvalid),
.O_R_tdata   (ud_rtdata),
.O_R_tlast   (ud_rtlast),
.O_R_sync_cnt(),
.I_R_buf     (rbuf_sync),

.O_fdma_waddr (fdma_waddr),
.O_fdma_wareq (fdma_wareq),
.O_fdma_wsize (fdma_wsize),
.I_fdma_wbusy (fdma_wbusy),
.O_fdma_wdata (fdma_wdata),
.I_fdma_wvalid(fdma_wvalid),
.O_fdma_wready(fdma_wready),
.O_fdma_raddr (fdma_raddr),
.O_fdma_rareq (fdma_rareq),
.O_fdma_rsize (fdma_rsize),
.I_fdma_rbusy (fdma_rbusy),
.I_fdma_rdata (fdma_rdata),
.I_fdma_rvalid(fdma_rvalid),
.O_fdma_rready(fdma_rready)
//.O_fmda_wbuf  	(fdma_wbuf	),	
//.O_fdma_wirq  	(fdma_wirq	),		
//.O_fmda_rbuf  	(fdma_rbuf	),	
//.O_fdma_rirq  	(fdma_rirq	)
);

//---------------------------------------------------------------------------
// Triple buffer, read lagging write by ONE frame.
//
// ⚠ BUF_DELAY WAS 2 UNTIL 2026-09-17, AND THAT IS THE TEAR.  In a ring of
// three, "lag 2" is the same thing as "lead 1":
//
//   BUF_DELAY=2:  r = (w-2) mod 3 = (w+1) mod 3   <- the one written NEXT
//   BUF_DELAY=1:  r = (w-1) mod 3 = (w+2) mod 3   <- the one just finished
//
// uidbuf latches the read index ONCE per read frame (state S_RST), so a read
// frame is committed to whichever buffer it started on.  At delay 2 the writer
// reaches that same buffer on its very next frame boundary -- ZERO frames of
// margin -- and the two sides are not locked: the sensor delivers ~57.7 fps
// while the display timing runs at 60.6 Hz.  That boundary therefore drifts
// through the read frame at the ~2.9 Hz beat and lands mid-picture several
// times a second.  Above the crossing the reader sees the old frame, below it
// the new one, and the two differ only by the scene's own motion -- a faint
// horizontal seam that slides vertically.  That is the reported symptom.
//
// At delay 1 the writer needs TWO frame boundaries to reach the buffer being
// read, and only one can occur per read frame, so the seam cannot form.
//
// This is also strictly LOWER latency -- the just-finished frame instead of
// the one before it -- so the LATENCY readout should fall by about one frame
// (~17 ms) and nothing is traded away for the fix.  Note the original Chinese
// comment here read "3 frame buffer, read lags write by 1 frame" while the
// parameter said 2: the comment had the intent right.
//---------------------------------------------------------------------------
uisetvbuf#(
.BUF_DELAY(1),
.BUF_LENTH(3)
)
uisetvbuf_u
(
.I_bufn(wbuf_sync),
.O_bufn(rbuf_sync)
);

//��Ƶʱ������
// (write-side uivtc + uitpg removed: the write side is the camera now)

reg [7:0] fifowait; //synthesis keep ?
always @(posedge pclkx1 or negedge ddr_init_cal_done) begin
 if (ddr_init_cal_done == 'b0) fifowait <= 'b0;
 else if (fifowait[7] == 0) fifowait <= fifowait + 1;
 else fifowait <= fifowait;
 end

uivtc#(
//1080P @ 150M
.H_ActiveSize       (1920), //��Ƶʱ�����,����Ƶ�źţ�һ����Ч(��Ҫ��ʾ�Ĳ���)������ռ��ʱ������һ��ʱ�Ӷ�Ӧһ����Ч����
.H_SyncStart        (1920+88), //��Ƶʱ�����,��ͬ����ʼ��������ʱ������ʼ������ͬ���ź� 
.H_SyncEnd          (1920+88+44),//��Ƶʱ�����,��ͬ��������������ʱ������ֹͣ������ͬ���źţ�֮���������Ч���ݲ���
.H_FrameSize        (1920+88+44+148), //��Ƶʱ�����,����Ƶ�źţ�һ����Ƶ�ź��ܼ�ռ�õ�ʱ����

.V_ActiveSize       (1080),//��Ƶʱ�����,����Ƶ�źţ�һ֡ͼ����ռ�õ���Ч(��Ҫ��ʾ�Ĳ���)��������ͨ��˵����Ƶ�ֱ��ʼ�H_ActiveSize*V_ActiveSize
.V_SyncStart        (1080+4),//��Ƶʱ�����,��ͬ����ʼ��������������ʼ������ͬ���ź� 
.V_SyncEnd          (1080+4+5), //��Ƶʱ�����,��ͬ�������������к�ֹͣ������ͬ���ź�  
.V_FrameSize        (1080+4+5+36)  //��Ƶʱ�����,����Ƶ�źţ�һ֡��Ƶ�ź��ܼ�ռ�õ�������    
)
uivtc_r_inst
(
.I_vtc_clk(pclkx1),  //ϵͳʱ�� 
.I_vtc_rstn(fifowait[7]),//ϵͳ��λ
.O_vtc_vs  (vtc_vs),
.O_vtc_hs  (vtc_hs),
.O_vtc_de_valid(vtc_de_valid),
.O_vtc_user(vtc_user),
.O_vtc_last(vtc_last)
);

//---------------------------------------------------------------------------
// Read side : one 32-bit word holds 4 packed RAW8 pixels, so pull a new word
// out of uidbuf every 4th pixel clock, unpack it byte by byte, then run the
// 3x3 bilinear demosaic (GRBG) before handing RGB888 to hdmi_tx.
// Same structure as fpga_cs5000_demo/uisrc/01_rtl/system_top.v.
//---------------------------------------------------------------------------
reg [1:0]  ud_rdata_cnt;    //synthesis keep
reg [7:0]  ud_rdata_d1;     //synthesis keep
reg        vtc_de_valid_d1; //synthesis keep

always @(posedge pclkx1) begin
    if (vtc_de_valid) ud_rdata_cnt <= ud_rdata_cnt + 2'd1;
    else              ud_rdata_cnt <= 2'd0;
end

// tready is registered, so it is high while ud_rdata_cnt == 3; the show-ahead
// FIFO then presents the next word exactly at ud_rdata_cnt == 0.
always @(posedge pclkx1) ud_rfifo_en <= (ud_rdata_cnt == 2'd2);

always @(posedge pclkx1) vtc_de_valid_d1 <= vtc_de_valid;

always @(posedge pclkx1) begin
    if (vtc_de_valid) begin
        case (ud_rdata_cnt)
        2'd0: ud_rdata_d1 <= ud_rtdata[31:24];
        2'd1: ud_rdata_d1 <= ud_rtdata[23:16];
        2'd2: ud_rdata_d1 <= ud_rtdata[15: 8];
        2'd3: ud_rdata_d1 <= ud_rtdata[ 7: 0];
        endcase
    end
    else ud_rdata_d1 <= 8'd0;
end

//---------------------------------------------------------------------------
// ISP tuning toggles on the spare buttons.
//   I_button[1] (D9) : sRGB gamma encode        -- default ON
//   I_button[2] (F8) : auto black/white point   -- default ON
//   I_button[3] (F9) : overlay selector         -- default OFF (see below)
//
// The first two now default ON rather than OFF.  The earlier "default to the
// bench-verified picture" choice was the right instinct but the wrong result:
// that picture is the washed-out one, and gamma on its own made it worse
// (Curve_Gamma_Encode maps the pedestal at code 16 to 71, so a residual black
// floor becomes a 28% grey haze).  Gamma is only correct downstream of a real
// black/white point correction, so the two belong on together.  Either button
// still bypasses its stage for an on-the-spot A/B.
//
// key_filter is the same debouncer color_convert uses; Key_P_Flag is a
// one-cycle press pulse, so each press flips the latch once.
//---------------------------------------------------------------------------
// 2026-08-09: I_button[1] and [2] now drive morphology_3x3 and
// affine_transform, so the sRGB encode and the auto black/white point are both
// permanently on.  Both switches were only ever diagnostic A/Bs -- the
// on-board check confirmed the picture is correct with them enabled, and four
// buttons are worth more spent on the ported effects than on toggles nobody
// needs again.  isp_gamma and isp_auto_level keep their enable ports; they are
// simply tied high.  The button map is now the source project's, plus the
// histogram:
//     D8 I_button[0]  13-position effect wheel
//     D9 I_button[1]  morphology   pass / erode / dilate / dark lift
//     F8 I_button[2]  affine       pass / rot90 / rot180 / rot270 / mirror /
//                                  shear R / shear L / zoom 2x / zoom 4x /
//                                  shrink 2x / shrink 4x   (11 positions)
//     F9 I_button[3]  overlays: off / histogram / detect boxes / both
//
// 2026-09-05 (evening): F9 became FOUR states rather than two, to give the L5
// detection overlay a control surface.  All four buttons were already
// allocated, so the alternative was two more color_convert wheel positions --
// which would have read better on the OSD but means touching the module the
// pixel-clock group's worst path ends inside (u_guided_5x5_g), for a feature
// that needs one enable bit.  This costs that path nothing.
//
//     00  both off        10  detection boxes
//     01  histogram       11  both
//
// The detection PIPELINE runs regardless -- only the drawing is gated.  That
// keeps the OSD's TARGETS reading live for threshold tuning without yellow
// boxes over the effect demos, and it is what the L6 statistics layer will
// need when it starts accumulating pass rates across a whole session.
//
// 2026-09-08: osd_state also goes to text_osd as an OVERLAY row.  The 09-08
// bench report was that F9 "seems to only have two positions", and it is worth
// recording why that was a rational reading rather than a mistake: positions
// 00 and 10 differ ONLY by detection boxes, as do 01 and 11, and the detector
// was finding nothing that week -- so two of the four were pixel-identical to
// the other two and the button looked like a 2-state toggle.  Any future
// overlay hung off a shared selector wants the same treatment: if a position
// can legitimately draw nothing, the panel has to say which position it is.
wire isp_osd_key;
wire isp_gamma_en = 1'b1;
wire isp_sat_en;            // 2026-09-17, chroma gain -- see isp_saturate; off in FACE CAP (below)
// 10-04 (user): OFF.  isp_auto_level's three per-frame per-channel black/
// white points are this design's only AWB, and re-normalising every frame
// made the boxes jump.  en=0 is a same-latency pass-through; 1 = restore.
wire isp_alvl_en  = 1'b0;

//---------------------------------------------------------------------------
// ⭐ 2026-10-01 KEY REMAP (user).  F9 / key4 is now the APPLICATION MODE,
// three positions, cycling:
//     0  TRACK  security: green motion boxes + per-box ToF distance / size
//               labels + ALARM (aim_sched / aim_label); the head points the
//               ToF at each box.
//     1  BOX    inspection: yellow ccl_blob boxes; the head parks at centre,
//               so tof_size's DIST / SIZE / PIX rows measure the centre box.
//     2  FACE   red face boxes (the face pipeline runs only here).
// The histogram moved to key1's last wheel position (cc_hist_en), and key2's
// ERODE / DILATE / DARKLIFT to key1 positions 12..14 -- key2 (D9) is free.
// Power-up is TRACK.  10-01 evening: TRACK has two views on key2 (trk_view,
// below) -- MAGENTA tracker box + trk_range (power-up) / MULTI green boxes +
// aim_sched (the 10-01 afternoon behaviour).
// The old 3-bit combination selector is osd_state in system_top.v.pre_keymap.
//
// ⭐ 10-03 evening (user): FOUR positions -- 原图 -> 安防 -> 质检 -> 人脸 ->
// 原图 ...  RAW is encoded 3 so the three existing modes keep their codes
// (every "osd_state == 2'dN" below is unchanged) and the 2-bit increment
// wraps by itself.  Power-up is RAW.  RAW draws no overlay and no readout
// page; the detectors keep running, the head parks (neither scheduler is
// enabled), key2 does nothing.
//---------------------------------------------------------------------------
localparam [1:0] OSD_RAW = 2'd3;
reg  [1:0] osd_state = OSD_RAW;
// ⭐ 10-30 (user, final demo): the 人脸 mode (2) is gone -- the face chain,
// staff recognition and liveness all run in 安防 (face_run = sec_mode), so
// FACE only added the CAP / DBG views for recording training data.  key4 is
// now 原图 -> 安防 -> 质检 -> 原图, and the GUI's 人脸 command is ignored.
// Every "osd_state == 2'd2" below is simply never true.  1 = the 10-29 cycle.
localparam integer FACE_MODE = 0;

//---------------------------------------------------------------------------
// ⭐ 10-29 (user): the receiver's GUI switches modes as the keys do.  EVCMD
// datagrams come out of u_eth_a_video (evs_cmd_rx) as one strobe + a held
// {cmd, arg} on pclkx1.  Commands, the GUI's mode numbers (原图 first, as on
// its buttons) mapped onto osd_state's codes:
//   1  application mode  arg 0 原图 / 1 安防 / 2 质检 / 3 人脸
//   2  key2 short press  (whatever key2 does in the current mode)
//   3  standard part     arg 0 任意 / 1 标准件 (11-03: 2 三棱柱 removed, ignored) (qc_std_mode, below u_affine)
// A key and a command act on the same registers; the later one wins.  The
// mode announcement (md_ann_*) watches osd_state, so it speaks either way.
// ETH_CMD = 0: the strobe is tied low and nothing here exists.
//---------------------------------------------------------------------------
localparam integer ETH_CMD = 1;
wire       eth_cmd_stb_raw;
wire [7:0] eth_cmd, eth_arg;
wire       eth_cmd_stb = (ETH_CMD != 0) && eth_cmd_stb_raw;
wire       eth_set_mode = eth_cmd_stb && (eth_cmd == 8'd1)
                       && (eth_arg < ((FACE_MODE != 0) ? 8'd4 : 8'd3));   // 10-30: 3 = 人脸
wire [1:0] eth_mode_osd = (eth_arg[1:0] == 2'd0) ? OSD_RAW : (eth_arg[1:0] - 2'd1);

wire cc_hist_en;                      // key1 wheel, position 15
wire isp_osd_en  = cc_hist_en;        // hist_osd
wire det_ovl_en  = (osd_state == 2'd1);   // det_overlay  (yellow, object boxes)
wire face_ovl_en = (osd_state == 2'd2);   // face_overlay (red, face boxes)

key_filter u_key_osd(
.Clk        ( pclkx1      ),
.Reset_n    ( fifowait[7] ),
.Key        ( I_button[3] ),
.Key_P_Flag ( isp_osd_key ),
.Key_R_Flag (             ),
.Key_state  (             )
);

always @(posedge pclkx1 or negedge fifowait[7]) begin
    if (!fifowait[7])
        osd_state <= OSD_RAW;
    else if (isp_osd_key)
        osd_state <= (FACE_MODE == 0 && osd_state == 2'd1) ? OSD_RAW   // 10-30: BOX -> RAW
                   : osd_state + 2'd1;     // 3 RAW -> 0 TRACK -> 1 BOX -> 2 FACE -> 3
    else if (eth_set_mode)
        osd_state <= eth_mode_osd;         // 10-29: the GUI
end

//---------------------------------------------------------------------------
// ⭐ 2026-10-01 evening (user): key2 / D9 picks the TRACK view.
//   trk_view = 1 (power-up)  MAGENTA: the single-target tracker box, the ToF
//                            follows it continuously (trk_range), one label.
//   trk_view = 0             MULTI: the green per-frame boxes, the ToF polls
//                            them (aim_sched), one label each.
// The 10-01 afternoon bit was MULTI only; the board report against it was
// "flicker / fragments on a shake / box incomplete" -- every one of which the
// tracker was built to fix (gate, grow-fast-shrink-slow, IIR, confirm, coast).
// Both schedulers always run; only their outputs are muxed (below aim_sched).
//---------------------------------------------------------------------------
wire trk_view_key;
reg  trk_view = 1'b1;
wire k2_rel, k2_up;

key_filter u_key_view(
.Clk        ( pclkx1       ),
.Reset_n    ( fifowait[7]  ),
.Key        ( I_button[1]  ),
.Key_P_Flag ( trk_view_key ),
.Key_R_Flag ( k2_rel       ),   // 10-04: BOX tare on release
.Key_state  ( k2_up        )    // 0 = held
);

// 10-02 evening: key2 means something different per key4 mode, so each flag
// only toggles in its own mode -- a key2 press in FACE no longer flips the
// TRACK view behind the user's back.
//   TRACK: trk_view (above)
//   FACE : face_hide -- the red boxes are hidden, the face chain keeps running
//          and FACES keeps counting.  This is the CAPTURE view: training frames
//          recorded off HDMI must not carry the boxes the chain itself drew
//          (the CNN would learn "a red rectangle = a face", and on the board it
//          never sees one -- it taps the picture upstream of the overlays).
//          OSD MODE reads "FACE CAP".
//   BOX  : qc_tare -- one-clock pulse, qc_thick's next still reading is the
//          table (see qc_thick.v; normally it learns the table by itself).
//          ⭐ 10-04 (user): HELD QC_CAL_CLK (1 s) = qc_cal, the one-key
//          calibration with the reference workpiece (qc_thick.v header),
//          fired on the 1 s mark while still held so the 质检 row answers
//          before the key comes up.  So the tare moved from the press to a
//          SHORT press's release -- a long press must not also tare.
reg  face_hide = 1'b0;
// 10-04 evening: FACE DBG, the third press of key2 in FACE (FACE -> FACE CAP ->
// FACE DBG -> FACE; FACE_DBG_VIEW = 0 keeps the old two-state toggle).  Red
// boxes AND the four ROIs face_roi_buf classified this sweep (cyan squares);
// the 人脸 row carries each ROI's CNN score; isp_saturate is bypassed as in
// CAP so a recording of it is the face chain's input.  For recording the
// board-vs-simulator comparison, not for showing off.
localparam integer FACE_DBG_VIEW = 1;
reg  face_dbg  = 1'b0;
reg  qc_tare   = 1'b0;
reg  qc_cal    = 1'b0;
localparam integer QC_CAL_CLK = 150_000_000;
reg  [27:0] k2_hold = 28'd0;
reg         k2_box  = 1'b0;         // this press began in BOX
reg         k2_trk  = 1'b0;         // 10-30: ... in TRACK (with GD_BG_LEARN)
// ⭐ 10-30: in TRACK, key2 HELD QC_CAL_CLK (1 s) = gd_bg_req, grid_det's
// background learning (the door that got a blue box on a still scene, see
// grid_det.v and u_gd_bg below).  So the trk_view toggle moved from the press
// to a SHORT press's release, exactly as the BOX tare did on 10-04 -- a long
// press must not also flip the view.  EVCMD 2 (the GUI's 切换视图) is a short
// press, so it still toggles.  GD_BG_LEARN = 0: the toggle is on the press and
// nothing learns -- the 10-29 behaviour.
localparam integer GD_BG_LEARN = 1;
reg         gd_bg_req = 1'b0;
reg         k2_long = 1'b0;         // ... and has passed 1 s
// 10-29: EVCMD 2 = a SHORT key2 press -- a press, then a release 4 clocks
// later, never held (so never the 1 s BOX calibration; that stays on the key).
reg  [2:0]  k2c_cnt = 3'd0;
wire        k2c_press = eth_cmd_stb && (eth_cmd == 8'd2);
wire        k2c_rel   = (k2c_cnt == 3'd1);
wire        k2_p_any  = trk_view_key || k2c_press;
wire        k2_r_any  = k2_rel || k2c_rel;
always @(posedge pclkx1 or negedge fifowait[7]) begin
    if (!fifowait[7])          k2c_cnt <= 3'd0;
    else if (k2c_press)        k2c_cnt <= 3'd4;
    else if (k2c_cnt != 3'd0)  k2c_cnt <= k2c_cnt - 3'd1;
end

// FACE CAP also bypasses isp_saturate, the one stage between the face chain's
// tap (af_out_*) and HDMI that changes colour: then a captured frame IS the
// face chain's input, chroma included, apart from the OSD panel, and
// tools/face_cnn/board_sim.py can re-run the skin chain on it faithfully.
assign isp_sat_en = !((osd_state == 2'd2) && (face_hide || face_dbg));

always @(posedge pclkx1 or negedge fifowait[7]) begin
    if (!fifowait[7]) begin
        trk_view  <= 1'b1;
        face_hide <= 1'b0;
        face_dbg  <= 1'b0;
        qc_tare   <= 1'b0;
        qc_cal    <= 1'b0;
        gd_bg_req <= 1'b0;
        k2_hold   <= 28'd0;
        k2_box    <= 1'b0;
        k2_trk    <= 1'b0;
        k2_long   <= 1'b0;
    end else begin
        qc_tare <= k2_r_any && k2_box && !k2_long && (osd_state == 2'd1);
        qc_cal  <= 1'b0;
        gd_bg_req <= 1'b0;
        if (k2_p_any) begin
            k2_box  <= (osd_state == 2'd1);
            k2_trk  <= (GD_BG_LEARN != 0) && (osd_state == 2'd0);   // 10-30: its own flag, so a
            k2_hold <= 28'd0;                                        // TRACK press can never tare
            k2_long <= 1'b0;
        end else if (!k2_up && (k2_box || k2_trk) && !k2_long) begin
            if (k2_hold == QC_CAL_CLK - 1) begin
                k2_long <= 1'b1;
                qc_cal  <= k2_box && (osd_state == 2'd1);
                gd_bg_req <= k2_trk && (osd_state == 2'd0);          // 10-30
            end else begin
                k2_hold <= k2_hold + 28'd1;
            end
        end
        // 10-30: with GD_BG_LEARN the view flips on a short press's release
        if (k2_r_any && k2_trk && !k2_long && (osd_state == 2'd0))
            trk_view <= ~trk_view;
        if (k2_p_any) begin
            if (GD_BG_LEARN == 0 && osd_state == 2'd0) trk_view  <= ~trk_view;
            if (osd_state == 2'd2) begin
                if (FACE_DBG_VIEW == 0) begin
                    face_hide <= ~face_hide;
                end else begin                  // FACE -> CAP -> DBG -> FACE
                    face_hide <= !face_hide && !face_dbg;
                    face_dbg  <= face_hide;
                end
            end
        end
    end
end

//---------------------------------------------------------------------------
// ⭐ 10-04: TOF_ROI_SCAN -- the narrow ranging cone, BOX mode only.
// Board: "at rest it reads 10-20 mm long, nudge the module and it is right"
// = the 27 deg cone (73 mm at 15 cm) blending the 28 mm top face with the
// table.  1 = key2 held 1 s in BOX first SCANS a 3 x 3 grid of 8 x 8 ROI
// centres for the shortest reading (the workpiece, wherever the ranger's
// axis lands -- tof_roi_scan.v), locks it, waits QC_ROI_SETTLE_MS for the
// readings to settle, then calibrates as before (qc_thick / tof_size) on the
// new ROI.  The 距离 row shows " S3/9" while scanning, " R199" (the locked
// centre SPAD) after.  Every other mode keeps 16 x 16 (TRACK needs the cone
// at 1 m); BOX keeps 16 x 16 until the first scan.  Readings taken during a
// scan are not passed on (they come from nine different cones).
// 0 = no scanner, vl53l1x_ctrl RUNTIME_ROI 0, the long press calibrates at
// once: bit-exact with the 10-04 evening build.
//---------------------------------------------------------------------------
localparam integer TOF_ROI_SCAN      = 1;
// ⭐ 10-20: 1 = the narrow ROI is FIXED at the array centre (SPAD 199) from
// power-up in BOX, and key2 held calibrates at once -- no scan.  Why: the
// scan re-aims the ROI with the workpiece in place, and a new ROI reads a
// different zero (board: 175 -> 166 on the part AND 192 -> 183 on the
// backdrop, -9 both).  BASE is only learnt with no box, so the calibration
// right after the scan paired the OLD ROI's BASE with the new ROI's TOP and
// folded the 9 mm into z_ofs; once the part was taken away BASE was relearnt
// on the new ROI and Z was off by it again -- the "标定后好了一会又坏了"
// report.  Two of the last three board scans chose 199 anyway.  0 = the 10-04
// scan-then-calibrate sequence.
localparam integer TOF_ROI_FIXED     = 1;
localparam integer QC_ROI_SETTLE_MS  = 3000;    // after the scan: new blocks, new TOP
localparam integer QC_ROI_STABLE_MS  = 10000;   // then wait this long for 稳定 at most

// 10-04: TOF_ROI_SCAN puts the ROI scan in front of the calibration.
//   0 idle -> (qc_cal) 1 scan running -> 2 settle QC_ROI_SETTLE_MS -> 3 wait
//   for qc_stable (<= QC_ROI_STABLE_MS) -> qc_cal_req.  At the timeout the
//   request goes out anyway, so qc_thick answers 标定错1 rather than nothing.
//   Leaving BOX aborts.  TOF_ROI_SCAN = 0: qc_cal_req is qc_cal.
localparam [31:0] QC_SETTLE_CLK = 150_000 * QC_ROI_SETTLE_MS;
localparam [31:0] QC_STABLE_CLK = 150_000 * QC_ROI_STABLE_MS;
localparam [31:0] QC_SCANUP_CLK = 150_000;      // scan must start within 1 ms
reg  [1:0]  qcs_st = 2'd0;
reg  [31:0] qcs_t  = 32'd0;
reg         qcs_seen = 1'b0;                     // the scan was seen running
reg         qc_cal_req = 1'b0;
reg         qc_roi_go  = 1'b0;               // -> tof_roi_scan (ToF section)
wire        qc_stable;
wire        tof_roi_scanning;

always @(posedge pclkx1 or negedge fifowait[7]) begin
    if (!fifowait[7]) begin
        qcs_st <= 2'd0; qcs_t <= 32'd0; qcs_seen <= 1'b0;
        qc_roi_go <= 1'b0; qc_cal_req <= 1'b0;
    end else if (TOF_ROI_SCAN == 0 || TOF_ROI_FIXED != 0) begin
        qc_roi_go  <= 1'b0;
        qc_cal_req <= qc_cal;
    end else begin
        qc_roi_go  <= 1'b0;
        qc_cal_req <= 1'b0;
        if (osd_state != 2'd1) begin
            qcs_st <= 2'd0;
        end else case (qcs_st)
        2'd0: if (qc_cal) begin
            qc_roi_go <= 1'b1; qcs_seen <= 1'b0; qcs_t <= 32'd0; qcs_st <= 2'd1;
        end
        2'd1: begin
            qcs_t <= qcs_t + 32'd1;
            if (tof_roi_scanning) qcs_seen <= 1'b1;
            if ((qcs_seen && !tof_roi_scanning) || (!qcs_seen && qcs_t >= QC_SCANUP_CLK)) begin
                qcs_t <= 32'd0; qcs_st <= 2'd2;
            end
        end
        2'd2: if (qcs_t >= QC_SETTLE_CLK) begin
            qcs_t <= 32'd0; qcs_st <= 2'd3;
        end else qcs_t <= qcs_t + 32'd1;
        default: if (qc_stable || (qcs_t >= QC_STABLE_CLK)) begin
            qc_cal_req <= 1'b1; qcs_st <= 2'd0;
        end else qcs_t <= qcs_t + 32'd1;
        endcase
    end
end

wire sec_mode = (osd_state == 2'd0);
// 2026-10-07: one pclkx1 pulse on entry to SECURITY -> servo_pantilt.aim_home.
reg  sec_mode_d = 1'b0;
always @(posedge pclkx1) sec_mode_d <= sec_mode;
wire sec_enter = sec_mode && !sec_mode_d;
// 2026-10-05 evening: the face chain also runs in SECURITY mode -- it is the
// confirmation stage of the intruder alert (face_assoc / alert_ctrl).
wire face_run = face_ovl_en || sec_mode;

// Black level, applied in the Bayer domain -- it is a sensor pedestal, so it
// has to come off before the demosaic starts mixing neighbouring pixels.  A
// RAW sensor does not read 0 on black; leaving the pedestal in lifts the
// whole shadow end and the frame carries a permanent haze.
//
// Unconditional now, and it has to stay upstream of the demosaic: the Q4.4
// white balance inside raw8_2_rgb888 multiplies blue by 1.625, so a pedestal
// that survives to that point comes out blue-tinted and no longer looks like a
// pedestal to anything downstream.  Removing it here keeps it neutral.
//
// Still subtract-only -- a multiplier here would land in the 150MHz path
// feeding the line buffers.  The stretch that used to be missing now happens
// in isp_auto_level, after the demosaic, where there is pipeline room for it.
// Purely combinational, so vtc_de_valid_d1 and ~vtc_vs keep their existing
// alignment with the data.
// 2026-09-15: 16 -> 12 for IMX415.  The pedestal is a sensor property, not a
// tuning knob: uiimx415reg sets 0x30E2 BLKELVEL = 0x32 = 50 in RAW10 units,
// and 50 >> 2 = 12 in RAW8.  (SC500AI sat at 64/1024 -> 16.)  The vendor's
// demo subtracts the same 50 in its own BLC stage, so this is not a guess.
// Too high clips shadow detail to black; too low leaves the haze that the
// sRGB encode then lifts into visible grey -- see the isp_gamma note below.
localparam [7:0] SENSOR_BLACK_LEVEL = 8'd12;   // 50/1024 in RAW10 -> 12 in RAW8

wire [7:0] raw8_isp = (ud_rdata_d1 > SENSOR_BLACK_LEVEL)
                    ? (ud_rdata_d1 - SENSOR_BLACK_LEVEL) : 8'd0;

wire       w_rgb_vsync, w_rgb_href;
wire [7:0] w_rgb_r, w_rgb_g, w_rgb_b;

// WB_* is the fixed-gain white balance (Q4.4). A RAW sensor has no AWB, so
// without it white comes out yellow. Tune WB_B (24..28) against a white sheet.
//
// 2026-09-15, IMX415: WB_* left at the SC500AI values on purpose, as the
// starting point rather than the answer.  A different sensor has a different
// native channel balance, so these are expected to be wrong -- but they are
// wrong in a self-limiting way, because isp_auto_level downstream measures
// THREE independent per-channel black/white points from the previous frame
// and absorbs most of a constant cast (including the pedestal that WB_B
// scales).  So: bring the board up first, judge the white sheet after, and
// only then move WB_B.  Do not pre-compensate by guessing.
//
// ⭐ 2026-10-11 (user OK): WB = 39 / 16 / 43, MEASURED.  The "self-limiting"
// premise above died on 10-04 when isp_alvl_en went to 0: nothing absorbed
// the cast any more, and the whole picture -- monitor, ethernet, OBS -- has
// been green since (ethernet means R55 G87 B66).  Fitted by tools/wb_fit.py
// on 126 ethernet snapshots of the lab (10-10 23:24, FACE CAP view, so
// isp_saturate bypassed): each code inverted through the exact sRGB LUT of
// Curve_Gamma_Encode.v, gains iterated on the near-grey pixels (walls,
// ceiling, floor; lamps and OSD excluded).  R needed x2.457 (p10..p90 2.455..
// 2.462), B x1.640 (1.596..1.654) on top of 16/16/26 -> 39.3 / 42.6, rounded.
// After: near-grey R/G 0.992, B/G 1.005; reference pixels newly clipped 0.03 %.
// WB_G stays 16, so light_meter (reads w_rgb_g) and ON_TH are untouched.
// Lab fluorescent light; under another light re-run wb_fit.py on new
// snapshots.  Rollback = 16 / 16 / 26 (system_top.v.pre_wb).
//
// Bayer phase.  The derivation below turned out to be WRONG on silicon; the
// measured value is BAYER_X_ODD=1 / BAYER_Y_ODD=1 (GBRG).  Both the reasoning
// and the measurement are kept, because the measurement is what narrowed the
// search from four candidates to two.
//
// WHAT THE FIRST BUILD LOOKED LIKE (2026-09-15, first bitstream of v3)
//   Every frame carried a flat magenta/violet cast and the picture had
//   essentially NO chroma: skin, tiles and white paper all came out grey, and
//   the strength of the cast tracked the scene (strong violet with a light
//   source in frame, near-neutral grey when the lens was covered).
//
//   That signature is diagnostic, and it is NOT the "red and blue exchanged"
//   case.  Being off by ONE pixel of mosaic phase (row or column, either one)
//   lands the R and the B sample sites on true-green pixels, so the chain
//   emits R = B = G_true and G = (R_true + B_true)/2.  Three highly correlated
//   channels = a grey image, and R = B > G = a magenta cast.  The scene
//   dependence is isp_auto_level on top of it: three independent per-frame
//   black/white points are a crude AWB, so a low-dynamic-range scene gets the
//   cast normalised away (grey) while a scene pinned by a highlight cannot
//   (violet).  Red/blue exchange is the off-by-TWO case and keeps chroma.
//
//   So the phase is off by an odd number of positions, which leaves exactly
//   two candidates out of four: GRBG (0,0) and GBRG (1,1).  Those two differ
//   from each other by two positions, i.e. by an R/B swap -- if this build
//   comes up correctly coloured, we are done; if it comes up with red and
//   blue exchanged but properly saturated, the answer is (0,0).  Picked (1,1)
//   first because the column arithmetic is the solid half: image_correction
//   drops X_SKIP=1 *word* = 4 pixels, an even shift that cannot move the
//   column phase, whereas the row phase rides on v_cnt/Y_SKIP, which is the
//   fragile part (it depends on which MIPI packets terminate a line -- see
//   HANDOFF 3.-5-A) and is exactly where the vendor demo already had a bug.
//
// THE DERIVATION THAT FAILED, for the record
//   IMX415 is GBRG natively (Linux imx415.c reports SGBRG10; independently
//   the vendor demo sets BAYER_MODE("BGGR") and then swaps R/B in
//   isp_top.v:175, whose net effect is RGGB off the same crop), and
//   image_correction's Y_SKIP=1 drops one line, which flips the row phase:
//   GBRG -> RGGB.  The measurement says one line is NOT what gets dropped.
//
// Do not touch WB_R/WB_G/WB_B until the phase is confirmed: with R = B = G
// the white balance gains are being applied to the wrong planes, so any
// value tuned now is tuned against an artefact.  The table of all four
// combinations is in raw8_2_rgb888's header.  (Phase confirmed GBRG on
// 09-15; the WB values are the 10-11 measurement above.)
raw8_2_rgb888#(
.H_SIZE      ( 1920  ),
.V_SIZE      ( 1080  ),
.WB_R        ( 8'd39 ),   // 10-11: was 16
.WB_G        ( 8'd16 ),
.WB_B        ( 8'd43 ),   // 10-11: was 26
.BAYER_X_ODD ( 1'b1  ),
.BAYER_Y_ODD ( 1'b1  )   // 2026-09-15: was 1'b0 (RGGB); measured magenta -> GBRG
)u_raw8_2_rgb888(
.I_clk      ( pclkx1          ),
.I_rst_n    ( fifowait[7]     ),
.I_raw_vs   ( ~vtc_vs         ),
.I_raw_de   ( vtc_de_valid_d1 ),
.I_raw_data ( raw8_isp        ),
.O_rgb_vs   ( w_rgb_vsync     ),
.O_rgb_de   ( w_rgb_href      ),
.O_rgb_r    ( w_rgb_r         ),
.O_rgb_g    ( w_rgb_g         ),
.O_rgb_b    ( w_rgb_b         )
);

//---------------------------------------------------------------------------
// isp_auto_level : the piece the chain was missing.  Black-level subtraction
// alone only darkens; without a matching white-point stretch the frame keeps
// its haze, and the sRGB encode below then lifts whatever floor is left into
// visible grey.  Three independent per-frame black/white points (one per
// channel, so it also absorbs the fixed WB's blue-scaled pedestal) measured
// from the previous frame's histogram.
//
// Deliberately upstream of isp_gamma: pedestal removal and range expansion
// belong in linear light.  3 clocks, vs/de ride along.
//
// There is no exposure headroom to fall back on -- ae_set never raises
// O_ae_req (I_btn is tied high), so the sensor is frozen at ~1123 of 1127
// lines of integration.  The correction has to be digital.
//---------------------------------------------------------------------------
wire       a_rgb_vsync, a_rgb_href;
wire [7:0] a_rgb_r, a_rgb_g, a_rgb_b;

wire [7:0]  osd_bin_level;//synthesis keep
wire        osd_bin_valid;//synthesis keep
wire [21:0] osd_cnt_r, osd_cnt_g, osd_cnt_b;
wire [7:0]  osd_lo_g, osd_hi_g;//synthesis keep

isp_auto_level#(
.LO_COUNT ( 22'd10368   ),   // 0.5% of 1920*1080
.HI_COUNT ( 22'd2063232 ),   // 99.5%
.GAIN_MAX ( 12'd1024    )    // 4.00x ceiling
)u_isp_auto_level(
.clk      ( pclkx1       ),
.rst_n    ( fifowait[7]  ),
.en       ( isp_alvl_en  ),
.in_vs    ( w_rgb_vsync  ),
.in_de    ( w_rgb_href   ),
.in_r     ( w_rgb_r      ),
.in_g     ( w_rgb_g      ),
.in_b     ( w_rgb_b      ),
.out_vs   ( a_rgb_vsync  ),
.out_de   ( a_rgb_href   ),
.out_r    ( a_rgb_r      ),
.out_g    ( a_rgb_g      ),
.out_b    ( a_rgb_b      ),
.osd_bin_level ( osd_bin_level ),
.osd_bin_valid ( osd_bin_valid ),
.osd_cnt_r     ( osd_cnt_r     ),
.osd_cnt_g     ( osd_cnt_g     ),
.osd_cnt_b     ( osd_cnt_b     ),
.osd_lo_g      ( osd_lo_g      ),
.osd_hi_g      ( osd_hi_g      )
);

//---------------------------------------------------------------------------
// isp_gamma : linear RAW -> sRGB.  The display decodes with ~2.2 gamma, so
// without this the midtones are crushed and every wheel position downstream
// inherits a flat, murky input.  1 clock of latency, vs/de ride along.
//---------------------------------------------------------------------------
wire       g_rgb_vsync, g_rgb_href;
wire [7:0] g_rgb_r, g_rgb_g, g_rgb_b;

isp_gamma u_isp_gamma(
.clk      ( pclkx1       ),
.rst_n    ( fifowait[7]  ),
.gamma_en ( isp_gamma_en ),
.in_vs    ( a_rgb_vsync  ),
.in_de    ( a_rgb_href   ),
.in_r     ( a_rgb_r      ),
.in_g     ( a_rgb_g      ),
.in_b     ( a_rgb_b      ),
.out_vs   ( g_rgb_vsync  ),
.out_de   ( g_rgb_href   ),
.out_r    ( g_rgb_r      ),
.out_g    ( g_rgb_g      ),
.out_b    ( g_rgb_b      )
);

//---------------------------------------------------------------------------
// One plain register stage between the ISP chain and color_convert, purely
// for placement.
//
// color_convert's first arithmetic stage lands in a DSP column far from where
// the ISP logic places, and TD absorbs isp_gamma's output flop straight into
// that DSP's input register.  That leaves the gamma LUT driving ~3.2ns of raw
// routing inside a single 6.666ns period -- 87% of the worst path was net
// delay, and pclkx1 slack fell from +0.738ns to +0.166ns.  With a flop of its
// own here the haul splits in two and the router has somewhere to land.
//
// Uniform on data, de and vs, so nothing downstream notices; color_convert's
// internal delay compensation is untouched.
//---------------------------------------------------------------------------
reg       p_rgb_vsync, p_rgb_href;
reg [7:0] p_rgb_r, p_rgb_g, p_rgb_b;

always @(posedge pclkx1 or negedge fifowait[7]) begin
    if (!fifowait[7]) begin
        p_rgb_vsync <= 1'b0; p_rgb_href <= 1'b0;
        p_rgb_r <= 8'd0; p_rgb_g <= 8'd0; p_rgb_b <= 8'd0;
    end else begin
        p_rgb_vsync <= g_rgb_vsync; p_rgb_href <= g_rgb_href;
        p_rgb_r <= g_rgb_r; p_rgb_g <= g_rgb_g; p_rgb_b <= g_rgb_b;
    end
end

//---------------------------------------------------------------------------
// morphology_5x5 : I_button[1], ported from the competition project's second
// key.  One press advances PASS -> ERODE -> DILATE -> DARK -> PASS.
//
// 2026-08-10: was morphology_3x3, then a single 5x5 pass, now two cascaded
// 5x5 passes.  A rank filter moves an edge by the radius of its structuring
// element, and on a 1080p TV that displacement IS the effect: 3x3 gave 1 px
// ("nothing happened"), one 5x5 pass gave 2 px ("could be more obvious"), two
// passes give 4 px.  All of it reuses Matrix_Generate_5X5_8Bit, which the
// guided filter already runs at this resolution -- 24 eram instead of 6, and
// no added combinational depth.  morphology_3x3.v is still on disk and still
// listed in the project, but nothing instantiates it, so it is pruned.
//
// Placed here, ahead of the effect wheel, for the same reason it sat ahead of
// color_convert in the source project: it is a neighbourhood operator, and
// running it on the wheel's output would mean eroding a negative or a sepia
// tint rather than the picture.
//
// Feeds on frame-active-high vs, which is what p_rgb_vsync already is -- the
// inversion for color_convert happens below, on this module's output instead.
// Adds 12 clocks to data, vs and de alike.
//---------------------------------------------------------------------------
wire        mp_out_hs;//synthesis keep
wire        mp_out_vs;//synthesis keep
wire        mp_out_de;//synthesis keep
wire [7:0]  mp_out_r, mp_out_g, mp_out_b;
wire [1:0]  mp_mode;//synthesis keep

// 2026-10-01: driven by color_convert below (key1 wheel 12..14).  Declared
// here, at its first use, for the same reason as sv_md_inhibit.
wire [1:0]  cc_morph_sel;//synthesis keep

morphology_5x5#(
.IMG_HDISP ( 11'd1920 ),
.IMG_VDISP ( 11'd1080 )
)u_morphology(
.clk        ( pclkx1      ),
.rst_n      ( fifowait[7] ),
.mode_key   ( 1'b1        ),   // 2026-10-01: key2 freed, MODE_SRC = 1
.mode_ext   ( cc_morph_sel ),  // key1 wheel ERODE / DILATE / DARKLIFT

.in_hs      ( 1'b0        ),   // hdmi_tx reads vs/de/data only; hs is unused
.in_vs      ( p_rgb_vsync ),
.in_de      ( p_rgb_href  ),
.in_r       ( p_rgb_r     ),
.in_g       ( p_rgb_g     ),
.in_b       ( p_rgb_b     ),

.out_hs     ( mp_out_hs   ),
.out_vs     ( mp_out_vs   ),
.out_de     ( mp_out_de   ),
.out_r      ( mp_out_r    ),
.out_g      ( mp_out_g    ),
.out_b      ( mp_out_b    ),
.morph_mode ( mp_mode     )
);

//---------------------------------------------------------------------------
// affine_transform : I_button[2], the competition project's third key.
// PASS -> ROT90 -> ROT270 -> HMIRROR -> SHEAR_R -> SHEAR_L -> ZOOM_IN ->
// ZOOM_OUT -> PASS.
//
// Eight of the source's twelve modes are here (2026-08-10; it was four).  The
// two shears are pure x remaps, so the line buffer HMIRROR already runs
// answers them by changing one read address.  The two zooms act on the
// 512x512 centre window rather than the whole frame: that buffer is already
// double-buffered and already reads the previous frame, which is what makes
// scaling causal inside it.  Full-frame zoom and 180 rotation still are not
// possible -- they need the lines in a different order, and uidbuf streams
// DDR3 out in fixed raster order with no read-address hook.  See
// affine_transform.v and rot_frame_buf_888.v for the full reasoning.
//
// Sits between morphology and the wheel, matching the source's ordering, and
// adds 4 clocks to data, vs and de alike.
//---------------------------------------------------------------------------
wire        af_out_hs;//synthesis keep
wire        af_out_vs;//synthesis keep
wire        af_out_de;//synthesis keep
wire [7:0]  af_out_r, af_out_g, af_out_b;
wire [3:0]  af_mode;//synthesis keep
wire        af_key_p;

//---------------------------------------------------------------------------
// ⭐ 10-20 (user): in BOX the affine key (key3) is LENT to qc_std -- the
// affine is forced to pass there (its boxes must be measured on the real
// picture; tof_size already refused to size anything but pass) and each press
// cycles qc_std_mode: 0 任意 -> 1 方块 -> 2 圆柱 -> 3 三棱柱 -> 0.  The 仿射
// row reads 关 in BOX; the selected affine mode comes back on leaving BOX.
// qc_std_mode is kept across modes (power-up 任意).
// ⭐ 10-28 (user): two states only, 0 任意 <-> 1 标准件 (= the P1 cube; qc_std
// names it 标准件).  The demo: the good cube, a cube of another size, a cube
// with a black dot (stain -> 不合格), and colours / shapes in 任意.
// QC_STD_NMODE 4 = the 10-20 cycle back.
// ⭐ 10-31 (user, Anlogic_update): 3 = 任意 -> 标准件 (P1 cube) -> 三棱柱 (P5, now
// printed YELLOW, qc_std STD_COLOR_MASK3) -> 任意; qc_std_mode takes 0 / 1 / 3
// (2 圆柱 stays unreached).  The GUI's EVCMD 3 arg 2 = 三棱柱.  Calibrate (key2
// held) in 标准件: the triangle's lost tips make it a poor W x H reference.
// ⭐ 11-03 (user: "把三棱柱模式去掉，标准件只有一个方块"): back to 2 =
// 任意 <-> 标准件 (the cube) only.  qc_std_mode never leaves 0 / 1, so the
// TRI_D_ADD_MM block below is dead (tri_adj needs NMODE 3) and a GUI EVCMD 3
// arg 2 is ignored (eth_arg < QC_STD_NMODE).  The PC side already dropped the
// 三棱柱 button on 11-01.  3 = the 10-31 triangle back.
//---------------------------------------------------------------------------
localparam integer QC_STD_NMODE = 2;
reg  [1:0]  qc_std_mode = 2'd0;
wire [7:0]  qs_w_depth;              // qc_std -> tof_size: 圆柱 radius, else 0
// 10-20: key2 held in 方块 calibrates on the P1 cube (60 x 60 face, 30 deep)
// instead of the charger -- the 10-20 board report was 标定错5 with the cube,
// i.e. the 55 mm charger reference refusing a 30 mm part.
wire        qc_cal_cube = (qc_std_mode == 2'd1);
localparam integer QC_P1_W = 60, QC_P1_H = 60, QC_P1_Z = 30;   // tools/qc_parts P1
always @(posedge pclkx1 or negedge fifowait[7]) begin
    if (!fifowait[7])
        qc_std_mode <= 2'd0;
    else if (af_key_p && (osd_state == 2'd1))
        qc_std_mode <= (QC_STD_NMODE == 3) ? ((qc_std_mode == 2'd0) ? 2'd1 : (qc_std_mode == 2'd1) ? 2'd3 : 2'd0)
                     : (qc_std_mode == QC_STD_NMODE - 1) ? 2'd0 : qc_std_mode + 2'd1;
    else if (eth_cmd_stb && (eth_cmd == 8'd3) && (eth_arg < QC_STD_NMODE))
        qc_std_mode <= (QC_STD_NMODE == 3 && eth_arg[1:0] == 2'd2) ? 2'd3   // 10-31: arg 2 = 三棱柱
                     : eth_arg[1:0];       // 10-29: the GUI, in any mode (kept across modes anyway)
end

affine_transform#(
.IMG_HDISP ( 1920 ),
.IMG_VDISP ( 1080 ),
.CENTER_W  ( 1024 ),
.CENTER_H  ( 1024 )
)u_affine(
.clk         ( pclkx1      ),
.rst_n       ( fifowait[7] ),
.mode_key    ( I_button[2] ),
.bypass      ( osd_state == 2'd1 ),   // 10-20: BOX
.key_press   ( af_key_p    ),

.in_hs       ( mp_out_hs   ),
.in_vs       ( mp_out_vs   ),
.in_de       ( mp_out_de   ),
.in_r        ( mp_out_r    ),
.in_g        ( mp_out_g    ),
.in_b        ( mp_out_b    ),

.out_hs      ( af_out_hs   ),
.out_vs      ( af_out_vs   ),
.out_de      ( af_out_de   ),
.out_r       ( af_out_r    ),
.out_g       ( af_out_g    ),
.out_b       ( af_out_b    ),
.affine_mode ( af_mode     )
);

//---------------------------------------------------------------------------
// L5 ANALYSIS LAYER -- detection branch (2026-09-05 evening)
//
// A PARALLEL BRANCH off the affine output.  It consumes af_out_* and drives
// nothing on the picture path, so no revision of it can change what reaches
// hdmi_tx; the only thing it feeds forward is a list of bounding boxes that
// det_overlay draws and a count that text_osd prints.  That containment is
// deliberate -- this is the largest new block in the design and it is going in
// on top of a working board.
//
// WHY THE TAP IS HERE and not at the head or the tail of the chain: the three
// properties are argued out in det_binarize.v's header, but in short --
// downstream of morphology so the erode/dilate key doubles as detection
// pre-processing, downstream of affine so the coordinates are DISPLAY
// coordinates and the boxes need no transform to undo, and upstream of the
// wheel so HISTEQ/MARBLE/WOOD/NEG cannot rewrite the pixel values the
// threshold is measuring.
//
// TIMING BETWEEN THE TWO HALVES.  ccl_blob publishes in vertical blanking and
// det_overlay latches through the whole of it, so there is no handshake.  The
// margin: ccl_blob's frame-end passes take at most ~80,900 clocks (~71,700
// before MAX_ROUNDS went to 5, ~67,600 before pass D grew the two shape-test
// states on 09-07), against 45 blanking lines x 2200 = 99,000.
//
// ⚠⚠ THAT 99,000 WAS NOT TRUE UNTIL 2026-09-18, AND THE WHOLE "detected but
// no box drawn" COMPLAINT WAS THIS.  The passes used to be gated on the LOW
// period of mop_vs, and mop_vs is ~vtc_vs -- the inverted FIVE-LINE sync
// pulse, not a frame-active flag.  It is high across both porches too, so the
// real window was 5 x 2200 = 11,000 clocks, nine times short, and any frame
// past ~500 labels overran.  ccl_blob now derives its own frame edges from de
// (its [1]) and gets the whole interval.  Everything below that reads "45
// blanking lines" is true as of that change and was optimistic before it.
//
// If a pathological frame ever does run over, ovf_time goes high, the OSD
// marks the reading with a T, the previous frame's boxes stay on screen for
// STALE_HOLD frames and are then blanked -- it does not publish half a
// result.
//
// Everything marked `synthesis keep` below is bring-up instrumentation for
// ChipWatcher.  The first question on the bench will be "is the threshold
// producing speckle", and det_label_max answers it directly instead of being
// inferred from how the boxes look.
//---------------------------------------------------------------------------
localparam integer DET_NBLOB = 8;

// Face detector geometry, 2026-09-18.  Declared here rather than beside the
// face chain because FACE_NROI also sizes motion_frame_drawer's exported box
// ports, and that instance is above it.
//
// FACE_NROI being motion_frame_drawer's NBOX is not a coincidence to be tidied
// away: the motion boxes are one of the two candidate sources and they arrive
// exactly one per ROI slot.
//
// FACE_BUFN / FACE_WIN / FACE_STEP must agree with tools/gen_lbp_rom.py, which
// bakes the same three numbers into the bench vectors it generates.  WIN=24 is
// not a choice at all -- it is the window size in the OpenCV cascade XML.
localparam integer FACE_NROI  = 4;
localparam integer FACE_NSKIN = 8;      // ccl_blob NBLOB on the skin chain
localparam integer FACE_BUFN  = 32;
localparam integer FACE_WIN   = 24;

// ⭐ FACE_STEP 4 -> 1 on 09-19 late, and this is the round's recall fix.
//
// The classifier's accept region is about ONE PIXEL wide -- measured, see
// MIN_NEIGHBORS in face_detect.v for the numbers.  A 4-pixel slide grid
// therefore visits 9 of the 81 reachable positions and lands on the accepting
// one roughly one time in eight, which is precisely the board's "a face is
// only occasionally detected, and only from certain distances" report.  At
// STEP=1 every position in the 9x9 range is visited, so a face that is framed
// at all is found.
//
// Cost: 81 windows instead of 9.  fctb measures 6416 clocks for 9, so a ROI is
// ~58k and four ROIs ~236k, against 2.47M clocks of frame -- under 10%, and
// the chain has no deadline anyway (it reads last frame's snapshot).  Watch the
// OSD's 'H' flag on the board: a standing H would mean the sweep no longer
// finishes inside a frame, and that is the one number that would say so.
localparam integer FACE_STEP  = 1;

// ⭐ FACE_CLS, 2026-10-02: which classifier reads the ROI patches.
//   0 = face_cascade (OpenCV LBP, bit-exact, the 09-18..09-19 work)
//   1 = face_cnn     (INT8 CNN, weights from tools/face_cnn/train_export.py)
// The board read FACES n>0 / m=0 with a face in front of the camera: candidates
// arrive and the cascade accepts none of them.  Its accept region is ~1 px wide
// and ~+-12% in scale, and a skin-blob ROI is not framed that precisely -- the
// CNN is trained on face_roi_buf's own framing jitter instead.  Same port, same
// handshake, so face_detect does not know which one it is driving; 0 restores
// the cascade bit-exactly.
localparam integer FACE_CLS   = 1;

// ⭐ FACE_SKIN_REL, 2026-10-02 night: the first lab recording of the CNN build
// missed 30/30 faces offline, 27 of them with NO skin ROI -- the lab picture is
// green, the face reads Cr 128 against the fixed box's Cr >= 133.  1 = face_skin
// judges chroma relative to the previous frame's mean (its header has the
// numbers), and the skin candidate ceiling goes 720 -> 1080 px, because close
// faces (face+neck blob > 720 tall) were the other no-ROI misses.  Offline on
// that recording: hit 0% -> 83%.  0 = the 10-02 evening bit exactly.
localparam integer FACE_SKIN_REL = 1;

// ⭐ 10-03 evening, from the 14:47 recording + "dark = no box" report (0 = the
// 10-03 noon behaviour, bit-exact; backups *.pre_conf / face_skin.v.pre_ysc):
//   FACE_SKIN_YSC  face_skin's REL offsets scale with the pixel's luma.  In dim
//                  light a face is only a few counts off grey and the fixed
//                  +6/-4 offsets lost it: offline hit at 0.6x light 33% -> 92%.
//   FACE_CONFIRM   face_detect only ACQUIRES a box after this many consecutive
//                  sweeps accept the same place (~0.1 s at 6); a box on screen
//                  follows without it.  Hands / T-shirt print / ears fire for
//                  1-2 sweeps.  No-face clips: 0.22 -> 0.00-0.03 of frames
//                  showing a false box.
localparam integer FACE_SKIN_YSC = 1;
localparam integer FACE_CONFIRM  = 6;
// 10-05: face_skin SKIN_HAVG -- Y/Cb/Cr averaged over 4 pixels of the row before
// the skin decision (sensor noise at 1080p fragments the face mask; see [2d]
// in face_skin.v).  0 = 10-04 exactly (face_skin.v.pre_havg).
localparam integer FACE_SKIN_HAVG = 1;

// ⭐ 10-11: face_skin REL_CR_D 6 -> 12, with the WB fix (raw8_2_rgb888 note).
// Neutral picture: a face's Cr sits a median 10 above the frame mean (was 4
// in the green cast), so +6 let neck / arms / wood join the face blob, ROIs
// grew ~5x the face and the CNN refused far faces.  Offline, new-WB frames
// (tools/face_cnn/wb_face_ab.py, wb_holdout.py, wb_confirm.py):
//                       ethernet 10-10   hold-out   faces <250 px (ethernet)
//   old WB, +6              0.730          0.833        36/76
//   new WB, +6              0.564          0.805         5/76
//   new WB, +12             0.890          0.927        61/76
// +10 0.742 / 0.943, +14 0.552 / 0.854, +16 collapses.  Shown boxes on the
// no-face clips after CONFIRM: 11 / 805 frames old, 13 / 805 at +12; shown-box
// hit on the face clips after CONFIRM: 0.861 old, 0.903 at +12.
// Pinned here, not as face_skin's default, so fsrtb & co. keep their DUT.
// board_sim.py REL_CR_D follows this value.  Rollback = 6 (with WB 16/16/26).
localparam [7:0]   FACE_SKIN_CR_D = 8'd12;
// ⭐ 10-04, user: "make the face box glide like the magenta box".  1 = the red
// boxes go through face_smooth (in face_detect.v): a box that matches one shown
// last sweep moves 1/2^FACE_SM_SC (centre) / 1/2^FACE_SM_SS (size) of the way
// to the new regression, else snaps.  23:57 recording: the raw box jumped 24 px
// median / 66 px p90 per frame on a still face.  Offline (all held-out clips):
// p90 jump centre 58 -> 31, size 67 -> 17 px, no added lag.  Only the drawn
// boxes change -- which boxes exist (CONFIRM / HOLD) and the OSD count do not.
// 0 = the 10-03 bit exactly.
localparam integer FACE_SMOOTH   = 1;

// ⭐ 10-04 evening, from the 12:13 recording ("far faces hardly ever get a box").
// 1 = face_roi_buf: skin candidates compete for the four slots in TOP-EDGE order,
// except blobs under 1/16 of the biggest one's box go last (RANK_TOP,
// RANK_FLOOR 4 -- without the floor a ceiling-light speck took a close face's
// slots), the aspect gate widens to 4:1 (AR_SHIFT 2), and no ROI starts in the
// first 8 lines (Y_TOP 8, SIDE_MAX 1072) -- those lines are not picture on this
// board and a ROI at y0 = 0 drew a box 5-16% of the time against 43% below.
// All held-out clips, YuNet ground truth, CONFIRM 6, current weights: frontal
// faces < 250 px 0.00 -> 0.58 boxed, 250-400 px 0.58 -> 0.78, >= 400 px
// 0.74 -> 0.85; frames with a false box, face clips 0.013 -> 0.013, no-face
// clips 0.049 -> 0.038.  0 = the 10-04 noon bit exactly.  board_sim.py mirrors
// it (RANK_TOP / RANK_FLOOR / Y_TOP / AR_SHIFT).
localparam integer FACE_ROI2     = 1;
// ⭐ 10-04 evening: v9 weights (YuNet head-pose labels: three-quarter views are
// faces, profiles are not) at 1.5 logits instead of the trained point.  The
// trained point (0) gained the recall but doubled the false boxes; 6144 (v9's
// report.txt: 4096 units per logit) beats v8 @ 0 on every held-out column --
// strong 3/4 views 0.45 -> 0.65, false-box frames on no-face clips 0.038 ->
// 0.020.  v8 is in face/hex_v8/; with v8 put this back to 0.
localparam signed [31:0] FACE_THR = 32'sd6144;
// 10-05: u_face_ccl merge-list fix (ccl_blob SEEN_LOG2 8 + PA_HOOK 1).  0 = 10-04.
localparam integer FACE_CCL_SEEN = 1;
localparam integer FACE_SM_SC    = 2;
localparam integer FACE_SM_SS    = 3;
// 10-30: face_roi_buf PB_HEAD -- head ROIs from the person boxes (gd_*), security
// mode only.  Far faces (1.1-2 m) the skin chain cannot frame, and lit faces
// whose skin blob swallowed the chest: 2 = two head slots (face_roi_buf
// header has the numbers).  0 = the 10-29 bit exactly.
localparam integer FACE_PB_HEAD  = 2;

wire        det_vs, det_de, det_bin;
wire [11:0] det_px;//synthesis keep
wire [11:0] det_py;//synthesis keep
wire [7:0]  det_thresh;//synthesis keep
wire        det_fg_dark;//synthesis keep
wire [20:0] det_dk_cnt;//synthesis keep
wire [20:0] det_bt_cnt;//synthesis keep
wire        det_fg_over;//synthesis keep
wire [7:0]  det_margin;//synthesis keep

det_binarize#(
.IMG_HDISP  ( 1920  ),
.IMG_VDISP  ( 1080  ),

// 2026-09-08: MARGIN became MARGIN_MIN, the FLOOR of a per-frame servo rather
// than the operating point -- see THE MARGIN IS A SERVO NOW in its header.  The
// 09-07 bench run is what forced it: a fixed 32 left a frame-wide lace in the
// mask, everything fused into one component, and the shape tests then threw
// that component out along with the real object inside it -- "0 TARGETS" with
// a target plainly in frame.  No constant can be right here, because what it
// has to clear is isp_auto_level's output noise floor, and that moves several
// times over between a lit surface and a dim one.
//
// 2026-09-17: FLOOR LOWERED 32 -> 16.  The old floor was sized against a
// reference that was an EXTREME of ~83,000 samples and therefore already sat
// ~9 counts above the true background; the margin had to pay for that offset
// before it bought any selectivity.  The reference is a MEAN of 294,912
// pixels now, which is noiseless by comparison, so the whole margin is
// available and 16 counts of it clears the per-pixel grain.  This is the lever
// for "objects are only detected under plenty of light" -- it halves the
// minimum object-to-background contrast the detector can see, and if that
// turns out to be too sensitive the servo RAISES it by itself within 0.4s.
.MARGIN_MIN  ( 8'd16  ),
.MARGIN_MAX  ( 8'd112 ),   // ~44% of full scale; past that the compares clamp
.MARGIN_STEP ( 8'd2   ),   // whole range in 48 frames, 0.8s
// 2026-09-17: FG_HI 1/8 -> 1/5 frame, FG_MAX 3/8 -> 2/5, together.  With the
// halo gone (see below) fg_cnt is the object area and nothing else, and three
// ordinary desk objects already exceed 1/8 of a 1080p frame -- the old band
// would have read a successful multi-object demo as "the mask is a field" and
// tightened until the objects vanished.  That is the "multiple objects are
// worse than one" complaint, second cause.
// 2026-09-18: FG_HI 1/5 -> 1/3, FG_MAX 2/5 -> 1/2, and this time it is not a
// guess about how big three objects are.  With OBJ_EXCL on, a solid object no
// longer reads as a ring, so fg_cnt is its WHOLE area rather than its outline
// -- the same scene produces several times more foreground than it did on
// 09-17 and the old band would read the fix itself as "the mask is a field".
// An object held close to the lens legitimately covers 40% of the picture;
// that was over FG_MAX, so the brake blanked the frame and the bench read it
// as "too close does not work".  1/2 is the honest ceiling: past half the
// frame the majority-is-background assumption this whole module rests on has
// already failed, so there is nothing to protect.
.FG_HI       ( 21'd691200 ),  // 1/3 frame: above this the mask is a field, not
                              // objects -- tighten
.FG_LO       ( 21'd2025   ),  // 1/1024 frame (~45x45): below this there is room
                              // to loosen
.ADAPT_EN    ( 1      ),   // 0 = pin at MARGIN_MIN, i.e. exact 09-07 behaviour
.MEAN_SHIFT ( 21    ),   // log2 ceiling of 1920*1080 -- the mean is a shift
.POL_FLOOR  ( 256   ),   // LOCAL_EN=0 path only; the live polarity vote is
                         // POL_GAP/POL_BLK below
.FG_MAX     ( 21'd1036800 ), // 1/2 frame: the ONE-FRAME cutout for a sudden
                             // scene change.  Not redundant with the servo --
                             // that is an integrator and needs tens of frames.
.FORCE_POL  ( 0     ),

// 2026-09-17: THE REFERENCE IS A WIDE BOX MEAN.  Third and, on the argument
// in the module header, last shape for this statistic.
//
// 09-08 compared every pixel to ONE frame mean.  The lens has a vignette worth
// tens of counts corner to centre, so the servo had no operating point and
// walked to MARGIN_MAX; boxes landed on the dark corners of a white desk.
// 09-09 replaced that with the pixel's own block mean -- but a block is 9216
// px, anything bigger covers blocks whole, and a covered block's mean IS the
// object, so objects came out as outlines.
// 09-10 replaced THAT with a 3x3-block max/min OR'd with the frame mean.  A
// max over 83,000 samples is pinned at 255 by one bright object across a
// region a block LARGER than the object, so the ordinary background around
// every bright thing read as dark foreground -- a HALO bigger than its cause.
// The pixel-count polarity rule then elected DARK while looking at bright
// objects (every 09-16 photo reads "112 D"), two halos pushed fg_cnt past
// FG_MAX and the brake published "0 TARGETS" with objects plainly in frame.
// All three of the 09-16 complaints -- needs bright light, centre worse than
// edge, multiple objects worse than one -- are that one mechanism.
//
// The reference now is the mean of the block means over WIN_NX x WIN_NY
// blocks: a coarse Bradley threshold against a heavily low-passed copy of the
// frame, which is what det_binarize's own header has named as the real fix
// since 09-07.  A mean cannot be moved by one glint, and a support much larger
// than the object cannot be captured by it.
//
// Grid unchanged and still shared with motion_frame_drawer: 15 columns of 128,
// 15 rows of 72, 1080 = 15*72 exactly so no ragged last row, and the column
// index is a bit slice.
//
// ⚠ THE RECIPROCAL IS BACK.  MEAN_PRE/MEAN_MUL/MEAN_POST encode 1/9216 and
// Verilog cannot derive them from BLK_W*BLK_H -- reshaping the grid means
// recomputing all three.  The 09-09 note that said there was no longer a
// reciprocal to keep in step was true only while the statistic was max/min.
//
// Expect MARGIN on the OSD to come off its 112 rail, and the polarity letter
// to read "B" on a dark desk with bright objects.  Still "112 D" means the
// block reference did not take effect at all, which is a different fault.
.BLK_W      ( 128   ),
.BLK_W_LOG2 ( 7     ),
.BLK_H      ( 72    ),
.N_COLS     ( 15    ),
.N_ROWS     ( 15    ),

// 4 wide x 8 tall = 512 x 576 PIXELS, nearly square on screen because the
// block is not.  ⚠ WIN_NX*WIN_NY must equal 1<<WIN_SH and both must stay <= 8
// (cv_kx/cv_ky are 3-bit).  Which way to tune it is in the module header --
// bigger if a large object still comes out as a ring, smaller if the mask
// lights up in a band beside a shadow edge.
.WIN_NX     ( 4     ),
.WIN_NY     ( 8     ),
.WIN_SH     ( 5     ),   // log2(4*8)
.WIN_OX     ( 2     ),
.WIN_OY     ( 4     ),

// 1/9216 as ((sum>>10)*57)>>9.  57 = 32+16+8+1, error under one count over
// the whole range.  Tied to BLK_W*BLK_H, not to the window.
.MEAN_PRE   ( 10    ),
.MEAN_MUL   ( 7'd57 ),
.MEAN_POST  ( 9     ),

// The polarity is voted on BLOCKS now, not pixels -- a pixel count is
// contaminated by the wrong-polarity side's own artefacts, which is how the
// 09-16 build ended up reporting "D" on bright objects.  A block mean 12
// counts clear of the frame mean votes; one side needs a 1-block lead to take
// the decision, on top of the two-frame agreement the module already wanted.
.POL_GAP    ( 8'd12 ),
.POL_BLK    ( 8'd1  ),

// 2026-09-18: OBJECT-BLOCK EXCLUSION.  The 09-17 window mean is still an
// average OVER THE OBJECT wherever the object is, so the contrast it can see
// is (1 - coverage) and the three bench complaints -- "one object must be far
// enough away", "two must be kept apart", "three barely work" -- are one
// number, that coverage.  A block that has already moved object-wards by more
// than OBJ_GAP now contributes bg_lvl to every window that taps it instead of
// its own mean.
//
// ⚠ OBJ_GAP IS NOT POL_GAP AND MUST STAY LARGER.  POL_GAP only clears the
// wobble of a 9216-sample mean; this one has to clear the LENS VIGNETTE, which
// is tens of counts on this lens.  Set them equal and dark corners get
// excluded as "objects", the global level goes back into the corner reference,
// and the 09-08 vignette failure comes back.  48 is above the shading, well
// under what an object does to a block it covers.
//
// BG_TRACK=1 makes the substituted value a tracked MEDIAN of the non-object
// block means rather than the frame mean -- the frame mean is itself dragged
// by a large object, which is exactly the case that has to work.  BG_RATE=3
// settles an 80-count lighting step in about five frames.
.OBJ_EXCL   ( 1     ),   // 0 = exact 09-17 datapath, for an A/B
.OBJ_GAP    ( 8'd48 ),
.BG_TRACK   ( 1     ),   // 0 = substitute the plain frame mean instead
.BG_RATE    ( 3     ),

.LOCAL_EN   ( 1     )    // 0 = the 09-08 scalar datapath, for an A/B
)u_det_binarize(
.clk          ( pclkx1      ),
.rst_n        ( fifowait[7] ),

.in_vs        ( af_out_vs   ),
.in_de        ( af_out_de   ),
.in_r         ( af_out_r    ),
.in_g         ( af_out_g    ),
.in_b         ( af_out_b    ),

.out_vs       ( det_vs      ),
.out_de       ( det_de      ),
.out_bin      ( det_bin     ),
.out_px       ( det_px      ),
.out_py       ( det_py      ),

.dbg_thresh   ( det_thresh  ),
.dbg_fg_dark  ( det_fg_dark ),
.dbg_dk_count ( det_dk_cnt  ),
.dbg_bt_count ( det_bt_cnt  ),
.dbg_fg_over  ( det_fg_over ),
.dbg_margin   ( det_margin  )
);

//---------------------------------------------------------------------------
// det_morph_open : binary opening on the mask, between the threshold and the
// labeller (2026-09-07).
//
// This is the change that clears the '*'.  On the first bench run ccl_blob
// raised ovf_label or ovf_merge on EVERY frame, which means the boxes on screen
// were assembled from a label space that had already run out -- and no amount
// of tuning downstream of that can help, because the connectivity information
// was already thrown away.  An erode-then-dilate removes the isolated pixels
// and 1px filaments that were eating the label budget and leaves solid regions
// their own size.
//
// It consumes det_binarize's bit and produces ccl_blob's, and it also produces
// the px/py ccl_blob uses -- det_binarize's own pair is now instrumentation
// only, hence the `synthesis keep` above.  Feeding ccl_blob the UPSTREAM
// coordinates with the DOWNSTREAM mask would put every box six pixels left of
// its object, and nothing in the picture would look wrong.
//
// 6 clocks and a (+2,+2) shift of the mask; see det_bin3x3's GEOMETRY note.
//---------------------------------------------------------------------------
wire        mop_vs, mop_de, mop_bin;
wire [11:0] mop_px, mop_py;

//---------------------------------------------------------------------------
// ⭐ 10-04: DET_CNN -- which mask the labeller gets.
//   0  det_binarize (above): block-mean reference, adapts to the scene.
//   1  black_color_detect_cnn: the teammate's colour CNN (Anlogic7), re-
//      pipelined (one adder per clock, bit-exact with theirs, 21 clocks) and
//      RETRAINED on this board's QC picture -- black foam backdrop,
//      isp_auto_level off.  Its mask is 1 = backdrop; the labeller gets the
//      rest.  It is a FIXED colour classifier: it works for the scene it was
//      trained on and nowhere else (the header of black_color_detect_cnn.v
//      has the numbers).  The teammate's own weights are cnn_weights.vh.a7;
//      on this picture they call the white charger black.
// Anlogic7's own wiring had in_de = bk_det_de, a name declared nowhere --
// HDL-1007 made it a floating implicit wire, so in their build the CNN fed
// the labeller no de at all and was optimised away.
// det_binarize stays built either way: the OSD and ChipWatcher read it.  0
// removes the CNN entirely (bit-exact with the 10-04 evening build).
//---------------------------------------------------------------------------
localparam integer DET_CNN = 1;

wire mop_in_vs, mop_in_de, mop_in_bin;

// 10-11: the CNN's own outputs for obj_color_detect (camera RGB and the mask,
// same clock, 1 = backdrop).  Without the CNN there is no mask to vote on:
// de 0, so the colour reads "--".
wire        ocd_in_vs, ocd_in_de, ocd_in_mask;
wire [23:0] ocd_in_rgb;

generate if (DET_CNN != 0) begin : g_det_cnn
    wire cnn_vs, cnn_de, cnn_mask;
    wire [23:0] cnn_rgb;
    black_color_detect_cnn#(
    .IMG_HDISP        ( 1920   ),
    .IMG_VDISP        ( 1080   ),
    .POST_FILTER      ( 1      ),
    .HYST_START       ( 6'd6   ),
    .HYST_END         ( 6'd8   ),
    .MIN_HITS_PER_ROW ( 12'd24 )
    )u_det_cnn(
    .clk       ( pclkx1                         ),
    .rst_n     ( fifowait[7]                    ),
    .in_vs     ( af_out_vs                      ),   // ~vtc_vs: high across the frame
    .in_de     ( af_out_de                      ),
    .in_rgb    ( {af_out_r, af_out_g, af_out_b} ),
    .view_mode ( 2'b00                          ),   // obj_color_detect needs the camera RGB
    .out_vs    ( cnn_vs                         ),
    .out_de    ( cnn_de                         ),
    .out_rgb   ( cnn_rgb                        ),
    .out_mask  ( cnn_mask                       )
    );
    assign mop_in_vs  = cnn_vs;
    assign mop_in_de  = cnn_de;
    assign mop_in_bin = cnn_de & ~cnn_mask;          // not backdrop = object
    assign ocd_in_vs   = cnn_vs;
    assign ocd_in_de   = cnn_de;
    assign ocd_in_rgb  = cnn_rgb;
    assign ocd_in_mask = cnn_mask;
end else begin : g_det_bin
    assign mop_in_vs  = det_vs;
    assign mop_in_de  = det_de;
    assign mop_in_bin = det_bin;
    assign ocd_in_vs   = det_vs;
    assign ocd_in_de   = 1'b0;
    assign ocd_in_rgb  = 24'd0;
    assign ocd_in_mask = 1'b1;
end endgenerate

det_morph_open#(
.IMG_HDISP ( 1920 ),
.IMG_VDISP ( 1080 )
)u_det_morph_open(
.clk     ( pclkx1      ),
.rst_n   ( fifowait[7] ),

.in_vs   ( mop_in_vs   ),
.in_de   ( mop_in_de   ),
.in_bin  ( mop_in_bin  ),

.out_vs  ( mop_vs      ),
.out_de  ( mop_de      ),
.out_bin ( mop_bin     ),
.out_px  ( mop_px      ),
.out_py  ( mop_py      )
);

//---------------------------------------------------------------------------
// 10-09 shape_cnn (teammate's Anlogic7, ported): the mask BEFORE the opening
// -- the object pixels the labeller's input had, holes and corners intact --
// delayed to line up with mop_* (det_morph_open is a fixed 6 clocks), then
// carried through ccl_blob's MASK pass-through into box coordinates.
// mask_align_err must read 0 in ChipWatcher; 1 means MOP_LAT is wrong.
//---------------------------------------------------------------------------
localparam integer MOP_LAT = 6;
reg  [MOP_LAT-1:0] dmask_dl, dmde_dl;
always @(posedge pclkx1) begin
    dmask_dl <= {dmask_dl[MOP_LAT-2:0], mop_in_bin};
    dmde_dl  <= {dmde_dl[MOP_LAT-2:0],  mop_in_de};
end
wire dmask_al       = dmask_dl[MOP_LAT-1];
wire mask_align_err = dmde_dl[MOP_LAT-1] ^ mop_de;//synthesis keep

wire                 blk_vs, blk_de, blk_mask;
wire [11:0]          blk_px, blk_py;
wire [DET_NBLOB-1:0] blk_inbox;

wire [DET_NBLOB*12-1:0] blob_x0, blob_x1, blob_y0, blob_y1;
wire [DET_NBLOB-1:0]    blob_valid;
wire [7:0]  blob_count;//synthesis keep
wire        det_ovf_lbl;//synthesis keep
wire        det_ovf_mrg;//synthesis keep
wire        det_ovf_tim;//synthesis keep
wire [11:0] det_label_max;//synthesis keep
wire [11:0] det_merge_cnt;//synthesis keep
wire [2:0]  det_rounds;//synthesis keep
wire [11:0] det_reject;//synthesis keep

ccl_blob#(
.IMG_HDISP  ( 1920      ),
.IMG_VDISP  ( 1080      ),
.LBW        ( 11        ),   // 2047 provisional labels
.NBLOB      ( DET_NBLOB ),
.MERGE_N    ( 1024      ),
.MIDX       ( 10        ),   // must stay log2(MERGE_N)

// 256 -> 1024 after 09-07.  256 is 16x16, which on a 1080p frame is 0.01% of
// the picture -- small enough that the dark seam of a window sill came through
// as a row of "targets".  1024 is 32x32 and still an order of magnitude under
// anything anyone would put on the bench to be detected.
// 1024 -> 2048 on 2026-09-18 (~45x45 px).  With MARGIN_MIN at 16 and the
// object no longer inside its own reference, the mask is far more sensitive
// than it was when 1024 was chosen, and 32x32 of bright speckle is now a
// plausible accident.  Still two orders of magnitude under anything put on the
// bench to be detected.  This is the first knob to try if small real objects
// stop being reported.
.MIN_AREA   ( 2048      ),

// Shape rejects, new on 09-07.  These are what remove the frame-spanning
// vignette ring; MIN_AREA cannot, because the ring has plenty of pixels.
.MAX_W      ( 1680      ),   // 7/8 of the frame
.MAX_H      ( 945       ),
.FILL_SHIFT ( 2         ),   // a target must fill >= 1/4 of its own bbox

// 4 -> 5 on 2026-09-18.  Affordable now that the duplicate filter has taken
// the merge list down by orders of magnitude, and worth spending: a round that
// does not converge splits ONE object into two boxes, which reads on screen as
// a false detection.  Budget, worst case, against 45 blanking lines x 2200 =
// 99,000 clocks -- pass A is 9 clocks per recorded pair per round, B/C/D are
// 5/7/5 clocks per label:
//     A  9 x 1024 x 5 = 46,080
//     B  5 x 2047     = 10,235
//     C  7 x 2047     = 14,329
//     D  5 x 2047     = 10,235
//     E  8 x 8 x 2    =    128   <- the box merge, new 09-18
//                     = 81,007, i.e. ~18,000 clocks spare.
// Raising it to 6 costs another 9,216 and still fits; 7 does not.
.MAX_ROUNDS ( 5         ),

// ⚠ OVF_TRIM WENT 1 -> 0 ON 2026-09-18 (second round).  It is THE fix for
// "two objects, only one box" and "three objects, sometimes no box".
//
// The 1 was reasoned from "a frame that overflowed has lost equivalences, so
// all but the largest box are fiction".  That is false: losing a merge pair
// SPLITS a component, it does not move it, so every surviving box is still a
// union of real foreground runs.  See the parameter's own comment in
// ccl_blob.v for the full argument.
//
// The board evidence is unusually clean.  In every photo with an M, blob_count
// read the CORRECT number of objects (2, 2, 3) -- so the real objects' merges
// all survived, and the pressure on the 1024-entry list came from background
// speckle, whose hundreds of tiny blobs MIN_AREA discards anyway.  The
// detector was right, the count on screen was right, and this parameter was
// suppressing the boxes.
//
// STALE_HOLD: 2 frames of "the passes overran" may keep the previous boxes;
// past that they are blanked, which is the "a box stayed behind after the
// object left" complaint.  Unchanged, and no longer expected to fire now that
// the passes have the whole vertical interval (see the note above).
.OVF_TRIM   ( 0         ),
.STALE_HOLD ( 2         ),

// The merge-list duplicate filter, and the ONE thing this round puts in the
// pixel path -- a 22-bit equality compare in front of the list's write
// enable.  It is what takes 'M' off the OSD: the scan records one merge pair
// per PIXEL of a horizontal overlap between two components, so a 100-pixel
// overlap used 100 of the 1024 entries with the identical word.  Step it down
// to 1 then 0 if pclkx1 goes negative and a re-seed does not recover it.
.DUP_DEPTH  ( 2         ),

// New on 2026-09-18 (second round).  The frame-end passes are gated on a
// vertical blank derived from de instead of on mop_vs's low period, because
// mop_vs is the inverted 5-line sync pulse and gave them 11,000 clocks of the
// 99,000 every budget above assumes.  VB_GUARD is in CLOCKS and must sit
// between the horizontal blanking (2200-1980 = 220) and the vertical one
// (99,000).  VS_EDGES=1 puts the old gating back bit-exactly -- that is the
// A/B for "was the frame-edge change what fixed the boxes".
.VB_GUARD   ( 512       ),
.VS_EDGES   ( 0         ),

// BOX MERGE -- new on 2026-09-18 (second round), the fix for "ONE object
// reads as two or three boxes that jump about", worst near the frame edge and
// at the top border.  The mask really is disconnected there: the shadow bands
// crossing the bright objects in the board photos are tens of pixels wide, so
// each side of a band is its own 8-connected component and the labeller is
// right.  This is the same complaint, cause and cure that
// motion_frame_drawer has carried as MERGE_GAP since 09-10; the detect chain
// simply never had an equivalent.  Full argument in ccl_blob's [9b].
//
// ⚠ 64 PIXELS IS THE ONE NUMBER HERE THAT IS A JUDGEMENT, AND IT IS THE KNOB
// THAT TRADES THE TWO FAILURES AGAINST EACH OTHER.  Sized off the 09-18
// photos: the shadow bands to bridge are ~30-80 px, while two objects a
// viewer calls separate are 150-250 px apart there.  64 sits between, nearer
// the bridging end.
//   - "two objects still share one box"  -> LOWER it (48, 32).
//   - "one object still splits"          -> RAISE it (96), and expect the
//     two-object case to fuse sooner.
// 0 turns the pass off bit-exactly, which is the A/B for "was it this".
.BOX_GAP    ( 64        ),
.BOX_ROUNDS ( 2         ),
.MASK_EN    ( 1         ),      // 10-09: shape_cnn's mask pass-through
.MASK_SHIFT ( 2         )
)u_ccl_blob(
.clk           ( pclkx1        ),
.rst_n         ( fifowait[7]   ),

.in_vs         ( mop_vs        ),
.in_de         ( mop_de        ),
.in_bin        ( mop_bin       ),
.in_px         ( mop_px        ),
.in_py         ( mop_py        ),

.blob_x0       ( blob_x0       ),
.blob_x1       ( blob_x1       ),
.blob_y0       ( blob_y0       ),
.blob_y1       ( blob_y1       ),
.blob_valid    ( blob_valid    ),
.blob_count    ( blob_count    ),

.ovf_label     ( det_ovf_lbl   ),
.ovf_merge     ( det_ovf_mrg   ),
.ovf_time      ( det_ovf_tim   ),

.dbg_label_max ( det_label_max ),
.dbg_merge_cnt ( det_merge_cnt ),
.dbg_rounds    ( det_rounds    ),
.dbg_reject    ( det_reject    ),

.in_mask       ( dmask_al      ),
.out_vs        ( blk_vs        ),
.out_de        ( blk_de        ),
.out_px        ( blk_px        ),
.out_py        ( blk_py        ),
.out_mask      ( blk_mask      ),
.out_inbox     ( blk_inbox     )
);

//---------------------------------------------------------------------------
// shape_cnn (2026-10-09, teammate's Anlogic7, ported unchanged) -- classifies
// the mask inside ccl_blob's slot 0 box (the largest, ccl_blob orders by
// area) as 0 other / 1 circle / 2 rect / 3 triangle (10-10: the 4-class
// version from contain/shape_tri; 3-class copy in shape_cnn.v.pre_tri).  About 270k clocks after the frame's active area,
// one frame behind the boxes, like det_overlay.  shape_vote turns the
// per-frame guess into the label the OSD 识别 row and qc_ext carry.
//---------------------------------------------------------------------------
wire        sc_done;//synthesis keep
wire [1:0]  sc_class;//synthesis keep
wire        sc_valid;//synthesis keep
wire signed [31:0] sc_logit0, sc_logit1, sc_logit2, sc_logit3;//synthesis keep

shape_cnn #(
.IMG_HDISP ( 1920 ),
.IMG_VDISP ( 1080 ),
.VB_GUARD  ( 512  )
) u_shape_cnn (
.clk         ( pclkx1        ),
.rst_n       ( fifowait[7]   ),
.in_vs       ( blk_vs        ),
.in_de       ( blk_de        ),
.in_px       ( blk_px        ),
.in_py       ( blk_py        ),
.in_mask     ( blk_mask      ),   // object = 1 (mop_in_bin's polarity)
.bbox_valid  ( blob_valid[0] ),
.bbox_x0     ( blob_x0[11:0] ),
.bbox_y0     ( blob_y0[11:0] ),
.bbox_x1     ( blob_x1[11:0] ),
.bbox_y1     ( blob_y1[11:0] ),
.done        ( sc_done       ),
.shape_class ( sc_class      ),
.logit0      ( sc_logit0     ),
.logit1      ( sc_logit1     ),
.logit2      ( sc_logit2     ),
.logit3      ( sc_logit3     ),
.class_valid ( sc_valid      )
);

wire [1:0]  sv_class;//synthesis keep
wire        sv_valid;//synthesis keep
wire [3:0]  sv_conf;//synthesis keep

shape_vote #(
.CMAX ( 15 ),
.ON_N ( 4  )
) u_shape_vote (
.clk       ( pclkx1            ),
.rst_n     ( fifowait[7]       ),
.en        ( osd_state == 2'd1 ),   // BOX
.done      ( sc_done           ),
.cls       ( sc_class          ),
.cls_valid ( sc_valid          ),
.vcls      ( sv_class          ),
.vvalid    ( sv_valid          ),
.vconf     ( sv_conf           )
);

//---------------------------------------------------------------------------
// 10-11 obj_color_detect (teammate's contain/Anlogic7, ported): the colour of
// the same slot 0 box shape_cnn looks at.  Pixels the CNN calls "not
// backdrop" inside the box (shrunk by BOX_MARGIN, eroded L4/R10 against the
// CNN's hysteresis leak) are each named by hue/saturation/brightness and the
// frame votes; the result must repeat CONFIRM frames.  Read-only, nothing in
// the picture path.  stable_id: 0 black 1 gray 2 white 3 red 4 orange
// 5 yellow 6 green 7 cyan 8 blue 9 purple, 15 none.  Goes to the 识别 row
// and to qc_ext [117:113] (the card's 颜色).
// V_WHITE is pinned at 96 here, not the module's 160: on the two QC pictures
// the CNN was trained on (new WB), the white charger's brightest channel has
// median 209 in one and 106 in the other (auto exposure, ~2x apart); 160
// names the second GRAY (94 %), 96 names it WHITE (86 %).  The cost: a mid-
// gray part under a bright exposure reads WHITE.  Bench script and numbers:
// C:/tmp/color_1011/oc_sweep.py.
// 0 removes it: qc_ext [117:113] back to 0 and the 识别 row as before.
//---------------------------------------------------------------------------
localparam integer OBJ_COLOR = 1;

wire [3:0]  oc_id;//synthesis keep
wire        oc_valid;//synthesis keep
wire [3:0]  oc_stable_id;
wire        oc_stable_valid;
wire [20:0] oc_win, oc_tot;//synthesis keep
wire [7:0]  oc_mean_r, oc_mean_g, oc_mean_b;//synthesis keep

generate if (OBJ_COLOR != 0) begin : g_obj_color
    obj_color_detect #(
    .BOX_MARGIN   ( 8       ),
    .ERODE_L      ( 4       ),
    .ERODE_R      ( 10      ),   // > HYST_START(6) + the 3x3 causal conv's 1 px
    .V_BLACK      ( 8'd48   ),
    .V_WHITE      ( 8'd96   ),   // see above
    .SAT_MIN      ( 8'd24   ),
    .SAT_Q4       ( 5'd5    ),   // saturation >= 5/16
    .MIN_PIX      ( 21'd256 ),
    .PURITY_SHIFT ( 1       ),
    // ⭐ 10-28: light blue / light yellow paper read WHITE on the board (red was
    // right).  MEAN_MODE 1: a strong per-pixel winner is kept; otherwise the
    // voters' MEAN colour x the QC lamp's white balance is named with a low
    // saturation gate (obj_color_detect header has the numbers: offline on the
    // 21:51 video folded back to the board's colours, white / red / blue 100 %,
    // yellow 93 %).  The 表面 row now shows the raw mean (RGB:...) -- to re-fit
    // WB_* at a new place, put white paper in and WB = 256 * max / channel.
    // CONFIRM 3 -> 6 (~0.1 s): a hand placing the part no longer flickers it.
    // MEAN_MODE 0 + CONFIRM 3 = the 10-11 behaviour bit for bit.
    .CONFIRM      ( 6       ),
    .MEAN_MODE    ( 1       ),
    .WB_R         ( 9'd291  ),
    .WB_G         ( 9'd281  ),
    .WB_B         ( 9'd256  ),
    .M_SAT_MIN    ( 8'd10   ),
    .M_SAT_Q7     ( 8'd15   )
    ) u_obj_color (
    .clk          ( pclkx1          ),
    .rst_n        ( fifowait[7]     ),
    .in_vs        ( ocd_in_vs       ),
    .in_de        ( ocd_in_de       ),
    .in_rgb       ( ocd_in_rgb      ),
    .in_mask      ( ocd_in_mask     ),   // 1 = backdrop
    .box_valid    ( blob_valid[0]   ),   // the largest box, as shape_cnn
    .box_x0       ( blob_x0[11:0]   ),
    .box_y0       ( blob_y0[11:0]   ),
    .box_x1       ( blob_x1[11:0]   ),
    .box_y1       ( blob_y1[11:0]   ),
    .color_id     ( oc_id           ),
    .color_valid  ( oc_valid        ),
    .stable_id    ( oc_stable_id    ),
    .stable_valid ( oc_stable_valid ),
    .res_stb      (                 ),
    .win_cnt      ( oc_win          ),
    .tot_cnt      ( oc_tot          ),
    .mean_r       ( oc_mean_r       ),
    .mean_g       ( oc_mean_g       ),
    .mean_b       ( oc_mean_b       ),
    .color_text   (                 )
    );
end else begin : g_no_obj_color
    assign oc_id = 4'd15;            assign oc_valid = 1'b0;
    assign oc_stable_id = 4'd15;     assign oc_stable_valid = 1'b0;
    assign oc_win = 21'd0;           assign oc_tot = 21'd0;
    assign oc_mean_r = 8'd0;  assign oc_mean_g = 8'd0;  assign oc_mean_b = 8'd0;
end endgenerate

//---------------------------------------------------------------------------
// ⭐ 10-27 stain_detect (teammate's contain/Anlogic7, v4 of 10-25, copied
// unchanged with stain_cnn.vh): stains on a WHITE part.  The slot 0 box
// (>= 128 x 128) is cut into 64 x 64 cells; a cell is hot when its mean luma
// is >= SCNN_T darker than the white around it (grey closing of the cell
// means), inside the part (closed + eroded "whole cell is part" map).
// >= SCNN_MIN_CELLS hot cells = this judgement positive; 5 of the last 8 ->
// stain_out.  One judgement about every 2 frames (accumulate one frame,
// post-process in the next).  The teammate's calibration on real camera
// captures: clean <= 4, stained >= 42 grey levels, T = 23, 108/108.
// Fed exactly like obj_color_detect: the colour CNN's own RGB + mask (same
// clock, 1 = backdrop; Anlogic7's bk_out_*), the box from ccl_blob on mop_*,
// which is the box det_overlay draws -- so the hot cells u_stain_overlay
// paints line up with the yellow box.
// Read-only side branch.  Goes to the BOX page's 污渍 row (text_osd
// STAIN_ROW) and, painted red at 50 %, to the picture (u_stain_overlay after
// u_qd_overlay).  st_out is the signal for the Ethernet card / QR code.
// 0 = not built: outputs tied off, the overlay is a wire, the OSD row gone.
//---------------------------------------------------------------------------
localparam integer STAIN_DET = 1;

wire        st_out;//synthesis keep       // voted: 5 of the last 8 judgements
wire        st_frame;//synthesis keep     // the last judgement, not voted
wire        st_valid;//synthesis keep     // judged at least once
wire        st_busy;//synthesis keep      // post-processing
wire [7:0]  st_hot;//synthesis keep       // hot cells of the last judgement (sat. 255)
wire [5:0]  st_hx0, st_hx1, st_hy0, st_hy1;//synthesis keep   // hot-cell bbox, 64x64 grid; none: x0 > x1
// hot-cell bitmap read port, for u_stain_overlay (synchronous read)
wire [11:0] st_hmap_ra;
wire        st_hmap_q, st_hmap_vld;
wire [11:0] st_hmap_x0, st_hmap_y0, st_hmap_x1, st_hmap_y1;

generate if (STAIN_DET != 0) begin : g_stain
    stain_detect #(
    .IMG_HDISP ( 1920 ),
    .IMG_VDISP ( 1080 )
    ) u_stain_detect (
    .clk         ( pclkx1          ),
    .rst_n       ( fifowait[7]     ),
    .in_vs       ( ocd_in_vs       ),
    .in_de       ( ocd_in_de       ),
    .in_rgb      ( ocd_in_rgb      ),
    .in_mask     ( ocd_in_mask     ),   // 1 = backdrop
    .box_x0      ( blob_x0[11:0]   ),   // the largest box, as shape_cnn / obj_color
    .box_x1      ( blob_x1[11:0]   ),
    .box_y0      ( blob_y0[11:0]   ),
    .box_y1      ( blob_y1[11:0]   ),
    .box_valid   ( blob_valid[0]   ),
    .stain_out   ( st_out          ),
    .stain_frame ( st_frame        ),
    .stain_valid ( st_valid        ),
    .hot_cells   ( st_hot          ),
    .busy        ( st_busy         ),
    .hot_x0      ( st_hx0          ),
    .hot_x1      ( st_hx1          ),
    .hot_y0      ( st_hy0          ),
    .hot_y1      ( st_hy1          ),
    .hmap_ra     ( st_hmap_ra      ),
    .hmap_q      ( st_hmap_q       ),
    .hmap_vld    ( st_hmap_vld     ),
    .hmap_x0     ( st_hmap_x0      ),
    .hmap_y0     ( st_hmap_y0      ),
    .hmap_x1     ( st_hmap_x1      ),
    .hmap_y1     ( st_hmap_y1      )
    );
end else begin : g_no_stain
    assign st_out = 1'b0;   assign st_frame = 1'b0;  assign st_valid = 1'b0;
    assign st_busy = 1'b0;  assign st_hot = 8'd0;
    assign st_hx0 = 6'd63;  assign st_hx1 = 6'd0;    assign st_hy0 = 6'd63;  assign st_hy1 = 6'd0;
    assign st_hmap_q = 1'b0;  assign st_hmap_vld = 1'b0;
    assign st_hmap_x0 = 12'd0;  assign st_hmap_y0 = 12'd0;  assign st_hmap_x1 = 12'd0;  assign st_hmap_y1 = 12'd0;
end endgenerate

// The three flags travel to the OSD SEPARATELY now.  They were OR'd into one
// bit and drawn as '*' until 2026-09-07, and the bench run that followed showed
// why that was the wrong trade: the star was up in every single photograph and
// said nothing about which budget had blown, so the first hour on the board
// went into re-deriving from the pictures what one character could have stated.
// text_osd turns this into L / M / T.
wire [2:0] det_ovf = { det_ovf_tim, det_ovf_mrg, det_ovf_lbl };

//---------------------------------------------------------------------------
// color_convert : 13-position effect wheel driven by I_button[0]
//   ORG GRAY NEG SEPIA HISTEQ CONTRAST GAMMA BILAT GUIDED HDR MARBLE WOOD MOTION
// Ported from the jcs source project (was RGB565 1280x720 behind an SDRAM
// frame store); here it sits in the pixel-clock domain between the demosaic
// and hdmi_tx, which is the same place it occupied there (HDMI domain).
//
// vsync polarity: the module's filters take ~in_vs and Matrix_Generate_*
// counts lines while that is high, so in_vs must be LOW across the visible
// frame -- the inverse of what raw8_2_rgb888 emits.  Getting this backwards
// leaves ORG looking perfect while HISTEQ/BILAT/GUIDED silently go black.
//---------------------------------------------------------------------------
wire        cc_in_vs = ~af_out_vs;
wire        cc_out_hs;//synthesis keep
wire        cc_out_vs;//synthesis keep
wire        cc_out_de;//synthesis keep
wire [23:0] cc_out_rgb;//synthesis keep
wire [1:0]  cc_texture_mode;//synthesis keep
// 2026-10-01: from key4 (osd_state), no longer from the wheel.
// 10-01 evening: split by key2 (trk_view).  cc_track_en also reaches the
// servo, where AIM_MODE = 1 ignores it (only the closed loop reads it).
wire        cc_motion_frame_en = sec_mode && !trk_view;//synthesis keep
wire        cc_track_en        = sec_mode &&  trk_view;//synthesis keep
wire [3:0]  cc_wheel_mode;//synthesis keep

color_convert u_color_convert(
.clk             ( pclkx1             ),
.rst_n           ( fifowait[7]        ),
.ctrl_key        ( I_button[0]        ),

// hdmi_tx's parallel RGB port consumes vs/de/data only, so in_hs is a
// pass-through the design never reads back -- tie it off rather than fake
// an alignment that does not exist.
.in_hs           ( 1'b0               ),
.in_vs           ( cc_in_vs           ),
.in_de           ( af_out_de          ),
.in_r            ( af_out_r           ),
.in_g            ( af_out_g           ),
.in_b            ( af_out_b           ),

.out_hs          ( cc_out_hs          ),
.out_vs          ( cc_out_vs          ),
.out_de          ( cc_out_de          ),
.out_rgb         ( cc_out_rgb         ),

.texture_mode    ( cc_texture_mode    ),
.morph_sel       ( cc_morph_sel       ),
.hist_en         ( cc_hist_en         ),
.wheel_mode      ( cc_wheel_mode      )
);

//---------------------------------------------------------------------------
// color_replace : wheel positions MARBLE (10) and WOOD (11).  Those two slots
// pass the picture through inside color_convert and export texture_mode; the
// substitution happens here, on red regions only.
//
// Downstream of the wheel rather than upstream, which is where the source
// project had it -- the enable comes out of color_convert, and taking it
// backwards would be a loop across a frame boundary.  In the two modes where
// it does anything the wheel is in its pass-through sync path, so nothing
// downstream sees a latency change when it engages.
//
// Fed frame-active-high vs (the inverse of what the wheel emits).  3 clocks.
//---------------------------------------------------------------------------
wire        cr_out_vs;//synthesis keep
wire        cr_out_de;//synthesis keep
wire [23:0] cr_out_rgb;//synthesis keep

color_replace#(
.IMG_HDISP ( 1920 ),
.IMG_VDISP ( 1080 )
)u_color_replace(
.clk          ( pclkx1          ),
.rst_n        ( fifowait[7]     ),
.in_vs        ( ~cc_out_vs      ),
.in_de        ( cc_out_de       ),
.in_rgb       ( cc_out_rgb      ),
.texture_mode ( cc_texture_mode ),
.out_vs       ( cr_out_vs       ),
.out_de       ( cr_out_de       ),
.out_rgb      ( cr_out_rgb      )
);

//---------------------------------------------------------------------------
// motion_frame_drawer : wheel position MOTION (12).  15x15 blocks of 128x72,
// each block's average against its own IIR background, the moving blocks
// grouped into connected clusters and drawn as green rectangles on the next
// frame.  (Up to 2026-08-10 it tinted the changed blocks instead, which paints
// the outline of a moving object rather than the object -- that is what block
// differencing does, and the bench test read it as edge detection.)  Silent in
// every other wheel position.  2 clocks.
//
// 2026-09-09: "reduced to one bounding box" until today, and that was the
// whole of the bench complaint about the box being too big -- one box around
// the union of all motion spans an object's old position and its new one while
// the IIR forgets the old.  It is a CCL over the block grid now, up to NBOX
// rectangles; see [5c] in the module.  No parameter here changes, and
// MIN_BOX_BLK's default of 2 is the per-cluster floor.
//
// 2026-09-20: two additions, both at their module defaults here.  SIZE_FLOOR
// stops a decelerating object ending on a box smaller than itself, and
// MAX_BLOCKS vetoes a frame in which so many blocks moved that it can only be
// the CAMERA that moved.  The veto also re-seeds the background model, which
// is the part that makes recovery 2 frames instead of 16 -- see the module's
// 09-20 header.
//
// 2026-09-23: md_inhibit IS NO LONGER TIED LOW -- the SG90 head arrived and
// servo_pantilt drives it.  The placeholder note that used to be here said
// "the input a pan-tilt controller drives while it is stepping the head",
// and that is exactly what is connected: u_servo_pantilt's settle window.
//
// ⚠ IT IS A COMBINATIONAL LOOP ON PAPER AND NOT ONE IN FACT, and anyone
// reading this file will notice the cycle before they notice why it is safe:
//
//   motion -> target_x/y, trk_state -> servo -> md_inhibit -> motion
//
// Every arc in that loop crosses a FRAME BOUNDARY.  servo_pantilt samples
// its inputs only on the vs rising edge and md_inhibit is a register, so the
// loop is a two-register feedback path clocked once per frame, the same
// shape as any sampled control loop.  Static timing sees two FF-to-FF paths
// with 16.7 ms of slack, not a cycle.
//
// MAX_BLOCKS still covers the camera being shaken or bumped: this one covers
// the motion we commanded, MAX_BLOCKS covers the motion we did not.
//
// target_x/target_y are the dominant box's centre in PIXELS -- the error term
// a tracking loop servos on.  Unlike md_box_*, which are block indices.
//---------------------------------------------------------------------------
wire        md_out_vs;//synthesis keep
wire        md_out_de;//synthesis keep
wire [23:0] md_out_rgb;//synthesis keep
wire [7:0]  md_blocks;//synthesis keep

wire [11:0] md_target_x;//synthesis keep
wire [11:0] md_target_y;//synthesis keep
wire        md_target_valid;//synthesis keep
wire        md_cam_motion;//synthesis keep
wire        md_cam_soft;//synthesis keep
wire [1:0]  md_trk_state;//synthesis keep

wire [FACE_NROI*4-1:0] md_box_x0, md_box_x1, md_box_y0, md_box_y1;
wire [FACE_NROI-1:0]   md_box_valid;

// ⚠ DECLARED HERE, NOT DOWN AT THE SERVO BLOCK, AND THE FIX IS WORTH A NOTE.
// The head's inhibit runs BACKWARDS through the loop -- servo -> motion --
// so its first use is this instance, about forty lines above the servo that
// drives it.  Declared at the driver it would be a USE BEFORE DECLARATION:
// Verilog invents an implicit 1-bit net at the first use, and the explicit
// declaration further down is then a REDECLARATION of that net.  iverilog
// only warns ("implicit definition of wire 'sv_md_inhibit'"), which is how
// this shipped on 09-23 -- but the design has never been through TD with it,
// and TD's elaborator is the tool that turns "logically unreachable" into a
// hard HDL-xxxx error (see the handoff's out-of-range-index entry).  Any
// feedback signal added to this loop in future belongs in this block.
wire        sv_md_inhibit;//synthesis keep
// 2026-10-05: lamp-edge blanking (alert/light_inhibit), OR'd into the same
// port.  Declared here for the same use-before-declaration reason.
wire        lt_md_inhibit;//synthesis keep

// 2026-10-01: same rule -- aim_sched drives these from below the servo.
// Evening: they are now the MUX of aim_sched (MULTI) and trk_range (MAGENTA),
// selected by trk_view; the two sources are asp_aim_* / tr_aim_*.
wire [11:0] as_aim_x;//synthesis keep
wire [11:0] as_aim_y;//synthesis keep
wire        as_aim_go;

// 2026-10-05 evening: face_assoc (below the face chain) drives these; the
// aim mux into trk_range and alert_ctrl read them above it.  Declared here
// for the same use-before-declaration reason.
wire        fa_person;//synthesis keep
wire [11:0] fa_x, fa_y;
// 1 = once a face is associated with the magenta box, the spotlight aims at
// the FACE centre instead of the box centre.  0 = box centre, as before.
localparam SEC_AIM_FACE = 1;
// 10-22 (user): "舵机射灯追踪接入到轮廓识别" -- with no associated face the head
// follows the BLUE person box (grid_det -> grid_post -> gd_aim, picked in
// gd_aim: sticky to the box holding the last aim point, else the biggest;
// aim point = chest, y0 + h/4).  Priority: face > blue box > motion tracker.
// 0 = the 10-21 wiring bit for bit (face > motion tracker).
localparam SEC_AIM_GD = 1;
// What the blue box does to the SPOT (alert_ctrl.target).  0 = nothing (10-21);
// 1 = it keeps an alarm that is already up -- motion still wakes it, so a
// false blue box in an empty room cannot start the lamp/voice, but a person
// who walked in and then stood still stays lit; 2 = it starts one by itself
// (only on a site the weights were trained on -- HANDOFF_1022 §3).
localparam SEC_SPOT_GD = 1;
// ⭐ 10-23 night (user, 22:05 video): "画面中没有任何框也报警了，人走远了有框但是没有
// 报警" -- the alarm woke on the MOTION tracker, which is not drawn (MD_DRAW = 0)
// and loses slow / far people.  1 = alert_ctrl target / person, the 报警 banner
// and the Ethernet "present" follow what is on screen: a red face box, or the
// blue person box held AS_START_MS (alarm_src, alert_ctrl.v).  The motion
// tracker still aims the head when there is neither.  0 = the 10-22 wiring.
localparam SEC_ALARM_SRC = 1;
// ⭐ 10-23 night (user): the spot during staff verification (spot_seq,
// alert_ctrl.v) -- 3 flashes with the liveness prompt, then dark for the rest
// of the challenge (the red light made recognition worse); a pass keeps the
// alert off SS_QUIET_S s after it falls; a fail gives the spot back to the
// alarm.  0 = the spot is alert_ctrl's throughout (10-12).
// 10-26: no longer dark -- lit after the flashes (spot_seq CHAL_LIT, below).
localparam SEC_STAFF_SPOT = 1;
wire        as_target;//synthesis keep   // alarm_src  (instanced after staff_ctrl)
wire        ss_quiet;                    // spot_seq   (same place): pass + quiet time
wire        ss_mute;                     // 10-28: spot_seq, the alarm voice's quiet (ss_quiet is the 3 s dark)
wire        sec_face;                    // |face_vld  (same place)
wire        ga_v;//synthesis keep
wire [11:0] ga_x, ga_y;

// The tracker's drawn rectangle, pixels (motion_frame_drawer -> trk_range).
wire [11:0] md_trk_x0, md_trk_x1, md_trk_y0, md_trk_y1;
wire        md_trk_v;

// 10-21, user: "暂时把运动框失能，太杂了".  0 = the green/magenta motion boxes
// and their aim_label distance/size tags are not drawn.  Detection, tracker,
// alarm banner, spotlight, voice and the face/servo consumers all still run
// on the same boxes -- only the pixels are gone.  1 = 10-21 behaviour.
localparam integer MD_DRAW = 0;

motion_frame_drawer#(
.IMG_HDISP ( 1920 ),
.IMG_VDISP ( 1080 ),
.BLK_W     ( 128  ),
.BLK_H     ( 72   ),
.N_COLS    ( 15   ),
// 2026-10-05 evening: quicker magenta acquisition (and so a quicker spot).
// The camera is FIXED now (the head carries the spotlight), so the pan
// defences these two were raised for are less of a cost; the dispersion /
// soft-frame gates still stand.  Module defaults untouched on purpose --
// testbenches that do not pin them keep testing the same thing.
// Rollback = delete these two lines (defaults 3 / 4).
.TRK_ACQ     ( 3'd2 ),
.TRK_ACQ_BLK ( 8'd3 ),
// 10-05 night, second board round: a hand near the lens still got no box.
// It lights a big compact patch, and the three CAMERA-MOTION vetoes read
// that as a pan: MAX_BLOCKS 64 (whole frame blind), DISP 9x9 (blind), and
// the soft 7x7 (acquire only >= TRK_ACQ_BLK_SOFT).  The camera is fixed now,
// so they mostly kill the near target.  Kept, but pushed to "almost the
// whole frame moves" (15 x 15 blocks, 225 total); soft level off (0 = the
// 09-22 morning tracker policy, documented rollback).  The density test
// (BOX_FILL_SHIFT) still guards acquisition.  Rollback = delete these four.
.MAX_BLOCKS  ( 8'd160 ),
.DISP_NC     ( 4'd13  ),
.DISP_NR     ( 4'd13  ),
.DISP_ACQ_NC ( 4'd0   ),
.DRAW_EN     ( MD_DRAW )
)u_motion_frame_drawer(
.clk             ( pclkx1             ),
.rst_n           ( fifowait[7]        ),
.in_vs           ( cr_out_vs          ),
.in_de           ( cr_out_de          ),
.in_rgb          ( cr_out_rgb         ),
.motion_frame_en ( cc_motion_frame_en ),

// 2026-09-22: wheel position TRACK (13).  The single-target tracker's
// magenta box -- one box, gated association, bounded size, coasting.  It
// answers the two complaints the per-frame boxes structurally cannot: the
// box that shrinks as the target decelerates, and the fragment storm during
// a pan.  MOTION (12) still draws the raw per-frame clusters, so the board
// A/B is one key press apart.
.track_en        ( cc_track_en        ),

.md_inhibit      ( sv_md_inhibit | lt_md_inhibit ),
.out_vs          ( md_out_vs          ),
.out_de          ( md_out_de          ),
.out_rgb         ( md_out_rgb         ),
.moved_blocks    ( md_blocks          ),

.target_x        ( md_target_x        ),
.target_y        ( md_target_y        ),
.target_valid    ( md_target_valid    ),
.cam_motion      ( md_cam_motion      ),
.cam_soft        ( md_cam_soft        ),
.trk_state       ( md_trk_state       ),

// 09-18: the same published boxes the green overlay draws, handed to the face
// detector as fallback candidate regions.  BLOCK INDICES, not pixels.
.box_x0          ( md_box_x0          ),
.box_x1          ( md_box_x1          ),
.box_y0          ( md_box_y0          ),
.box_y1          ( md_box_y1          ),
.box_valid       ( md_box_valid       ),

.trk_box_x0      ( md_trk_x0          ),
.trk_box_x1      ( md_trk_x1          ),
.trk_box_y0      ( md_trk_y0          ),
.trk_box_y1      ( md_trk_y1          ),
.trk_box_v       ( md_trk_v           )
);

//---------------------------------------------------------------------------
// servo_pantilt : the SG90 two-axis head, closing the loop on the tracker.
//
// Two SG90s on a plastic pan/tilt frame, 90 deg of travel per axis.  The
// loop is one proportional step per video frame, clamped at both ends, and
// it gates the detector's background re-seed while the head is settling.
//
// ⚠ THREE THINGS THAT ARE NOT IN THIS FILE AND WILL BREAK THE HARDWARE IF
// SKIPPED -- separate 5 V supply with a common ground, 3.3 V signal bank,
// and finding mechanical centre with the supplied tester BEFORE powering
// this.  They are written out in servo_pantilt.v's header, next to the code
// that assumes them.
//
// ⚠ PAN_INVERT / TLT_INVERT CANNOT BE KNOWN UNTIL THE HEAD IS BOLTED UP.
// Wrong sign = positive feedback = the head slews to its travel limit.  The
// clamp makes that survivable rather than destructive, and the bench test is
// one sentence: a hand entering from one side must make the head turn
// TOWARDS it.  If it turns away, flip that axis's parameter.
//
// CLK_HZ is pclkx1, which the PLL report gives as exactly 150.000 MHz.
//---------------------------------------------------------------------------
// sv_md_inhibit is declared up at the motion block -- see the note there.
wire [11:0] sv_pw_pan;//synthesis keep
wire [11:0] sv_pw_tilt;//synthesis keep
wire        sv_moving;//synthesis keep

servo_pantilt #(
.CLK_HZ    ( 150000000 ),
.IMG_HDISP ( 1920      ),
.IMG_VDISP ( 1080      ),

//---------------------------------------------------------------------------
// ⚠⚠ 2026-09-28: SERVO_EN BACK TO 0 UNTIL THE LEVEL SHIFTER ARRIVES.  With
// no head attached the loop cannot know it is not turning anything: it steps
// toward every LOCKED target outside the dead band, raises md_inhibit for
// SETTLE frames, the target never reaches the centre, and it steps again --
// forever, and on past the PWM clamp.  /c/tmp/sltb.v measured it on a static
// camera with an off-centre object: 30 of 60 frames 'C', 10 of 60 LOCKED,
// magenta on 10 of 60.  Every static-scene reading taken on the 09-24 21:48
// bit is contaminated by this.  ⭐ SET IT BACK TO 1 THE BUILD THE HEAD IS
// WIRED, and not before.
//
// (09-25: SERVO_EN = 1.  The user asked for the head to go live with that
// build.  Everything below this line up to the parameter is the 09-23
// reasoning for keeping it off, left in place because its "TO TURN IT ON"
// paragraph and the LED side effect are still what matters on the bench.)
//
// ⚠⚠ (09-23) SERVO_EN = 0 FOR THIS BUILD, AND IT IS A SCHEDULING DECISION, NOT A
// DOUBT ABOUT THE CODE.  The pins ARE known now (AE6/AE5, CEP J14 pins 3/4 -- see fpga_pin.adc);
// what is deliberate is:
//
//   ⭐ ONE NEW VARIABLE PER BURN.  This build's job is to answer whether
//   TRK_FOLLOW_SPARSE fixed the '?'-on-a-static-object complaint.  With the
//   head live the camera moves ITSELF, so every photograph would carry two
//   new variables and could attribute neither -- which is the same mistake
//   §-5.0's clean pan/static split let us avoid making again.
//
// TO TURN IT ON: THIS PARAMETER TO 1.  That is the whole edit.  The pins are
// constrained, the module, the loop, md_inhibit and the OSD row are wired,
// and svtb's 41 checks cover them.
//
// At 0 the divider, both PWM counters and the whole loop fold away, both
// outputs sit at a static 0 (a servo with no pulses is LIMP, which is the
// safe failure -- a limp head cannot fight its end stop), and md_inhibit is
// tied low, so the detector behaves exactly as it did last night.
//
// ⚠ VISIBLE SIDE EFFECT OF THE 0: both outputs sit at a static 0, which the
// inverting off-board shifter turns into a constant HIGH at the servo signal
// pin -- no pulses, so the head is limp.  LED2/LED3 are NOT the pins anymore
// (2026-09-24: moved to CEP J14 pins 3/4) and stay dark.
//---------------------------------------------------------------------------
.SERVO_EN  ( 1         ),

// ⚠ 2026-09-24: PWM IS ACTIVE-LOW.  The servo signals leave on CEP J14 pins
// 3/4 (1.8 V bank, see fpga_pin.adc) and feed an off-board single N-MOSFET
// level shifter, which INVERTS -- so the FPGA emits the pulse low and the
// servo sees the active-high 0.5-2.5 ms pulse it wants.  If the head ever
// moves back to the 3.3 V LED pads (T19/T18) driven directly, set this to 0.
// ⚠⚠ 2026-09-30: NOW 0.  The shifter actually fitted is the BSS138 4-channel
// bidirectional board (LV=1.8 V from O_lvref, HV=3.3 V), which is NON-inverting.
// Active-low PWM through it gave the servo a 18 ms-high pulse = no valid
// command, the head never centred and the loop's md_inhibit blinded detection.
.PWM_ACTIVE_LOW ( 0         ),

// ⚠ THE FIRST TWO KNOBS TO REACH FOR, and in this order.  If the head hunts
// left-right across the target, DEAD_X/DEAD_Y go UP (the limit cycle lives
// at the STEP_MIN clamp, not in the gain -- see the stability note).  If it
// crawls, KP_SHIFT goes DOWN.  Do not start with KP_SHIFT.
// ⚠ 2026-10-01: 96/54 -> 160/90.  The target is a block-level box (128 x 72),
// so its centre jitters by up to a block on a still scene; a dead band
// narrower than one block turns that jitter into steps, and every step costs
// SETTLE blind frames = the "static box flicker" first seen on the board.
// q = 30 px <= 2*DEAD_X = 320 px, invariant holds with more margin.
.DEAD_X    ( 12'd160   ),
.DEAD_Y    ( 12'd90    ),
.KP_SHIFT  ( 4         ),
.STEP_MIN  ( 12'd12    ),
.STEP_MAX  ( 12'd40    ),
.SETTLE    ( 4'd3      ),

.PAN_INVERT ( 1 ),   // 10-05 board: pan followed the wrong way, tilt right
.TLT_INVERT ( 0 ),

// ⭐ 2026-10-01: AIM_MODE = 1 -- the head carries the VL53L1X, NOT the camera
// (HANDOFF §-9).  Open-loop pointing at aim_sched's target, md_inhibit tied
// low, so the detector is never blinded again.  0 = the closed tracking loop
// above, bit-exact (eqsvtb).  The DEAD/KP/STEP/SETTLE knobs above only act
// at 0.  ⚠ Board check: aim at something on ONE side; if the ToF turns away,
// flip PAN_INVERT / TLT_INVERT.  AIM_KX/KY are us per px in Q8 (defaults are
// for the guessed 70 deg lens); AIM_OFS_X/Y absorb parallax and off-centre.
.AIM_MODE   ( 1      ),
.AIM_KX     ( 10'd104 ),
.AIM_KY     ( 10'd113 ),
.AIM_OFS_X  ( 0      ),
.AIM_OFS_Y  ( 0      )
) u_servo_pantilt (
.clk          ( pclkx1          ),
.rst_n        ( fifowait[7]     ),

// ⚠ cr_out_vs, THE SAME vs THE DETECTOR SEES, and not a downstream copy.
// The module edge-detects it, so the "vs is a 5-line sync pulse, not a
// frame-valid" trap this project has already been bitten by does not apply
// -- a rising edge is one per frame under either reading.
.vs           ( cr_out_vs       ),

// Wheel position TRACK arms the head.  No new key: selecting the tracker's
// display IS the operator saying "follow this", and the A/B against MOTION
// stays one key press.
.track_en     ( cc_track_en     ),

.target_x     ( md_target_x     ),
.target_y     ( md_target_y     ),
.target_valid ( md_target_valid ),
.cam_motion   ( md_cam_motion   ),
.trk_state    ( md_trk_state    ),

// AIM_MODE = 1: aim_sched (below, after the ranger) drives these.
.aim_x        ( as_aim_x        ),
.aim_y        ( as_aim_y        ),
.aim_go       ( as_aim_go       ),
// 2026-10-07 (user): entering SECURITY re-centres the head (straight ahead).
.aim_home     ( sec_enter       ),

.o_pan_pwm    ( O_servo_pan     ),
.o_tilt_pwm   ( O_servo_tilt    ),
.md_inhibit   ( sv_md_inhibit   ),
.pw_pan       ( sv_pw_pan       ),
.pw_tilt      ( sv_pw_tilt      ),
.loop_moving  ( sv_moving       )
);

//---------------------------------------------------------------------------
// ToF ranger + workpiece size (2026-09-25) -- the group's scheme 1.
//
//   vl53l1x_ctrl   brings the VL53L1X up over I2C (ST ULD sequence, no CPU)
//                  and publishes one distance per measurement, ~16 Hz
//   tof_size       takes the detection box under the aim point and that
//                  distance, W = w_px * D / F_PX, and formats three OSD rows
//
// ⭐ F_PX IS A GUESS UNTIL CALIBRATED -- one photograph of a known object and
// one division, the procedure is at the top of tof_size.v.  Until then every
// size is off by a constant ratio; DIST and PIX are right regardless.
//
// The detection boxes are the F9 BOXES chain's (yellow), so the workpiece has
// to be something ccl_blob finds: the plain backdrop the scheme calls for is
// what makes that reliable.  The boxes exist whatever F9 shows -- only their
// drawing is gated -- so SIZE works with the overlay off too.
//
// TOF_EN = 0 removes the ranger and ties its outputs, so the DIST row reads
// OFF and SIZE reads NO DIST; PIX keeps working (it needs no ranger), and the
// two pins float at their pull-ups.  That is the rollback.
//---------------------------------------------------------------------------
localparam integer TOF_EN = 1;

// TOF_ROI_SCAN / QC_ROI_*: see the calibration sequencer (key2 block)

wire [7:0]  tof_roi_ctr, tof_roi_xy;            // request -> vl53l1x_ctrl
wire [7:0]  tof_rc, tof_rxy;//synthesis keep    // the ROI each measurement used
wire [7:0]  tof_roi_opt;//synthesis keep        // factory optical centre (0x013E)
// tof_roi_scanning / qc_roi_go: declared with the calibration sequencer (key2 block)
wire [3:0]  tof_roi_col, tof_roi_row;//synthesis keep
wire [39:0] tof_roi_text;

wire [2:0]  tof_state;//synthesis keep
wire [15:0] tof_dist_raw;//synthesis keep
wire [7:0]  tof_code;//synthesis keep
wire        tof_stb_raw;
wire [7:0]  tof_errs;//synthesis keep
wire [13:0] tof_sigma;//synthesis keep
wire [15:0] tof_id;//synthesis keep

generate if (TOF_EN != 0) begin : g_tof
vl53l1x_ctrl #(
.CLK_HZ    ( 150000000 ),
.I2C_HZ    ( 100000    ),

// Short mode (to ~1.3 m) is the bench case and has the best ambient-light
// immunity.  2 = long mode, to ~4 m.
.DIST_MODE ( 1         ),
.TB_MS     ( 50        ),
.IM_MS     ( 60        ),

// ⭐ THE FIRST KNOB if DIST reads the backdrop and not the workpiece: 8 / 8
// narrows the cone from 27 deg to about 20 deg.
.ROI_W     ( 16        ),
.ROI_H     ( 16        ),

// 2026-10-01: read the sigma estimate too -- aim_sched's confidence gate.
.READ_SIGMA ( 1        ),
.RUNTIME_ROI ( TOF_ROI_SCAN ),
.ROI_SKIP  ( 1         )
) u_vl53l1x (
.clk       ( pclkx1      ),
.rst_n     ( fifowait[7] ),
.io_scl    ( IO_tof_scl  ),
.io_sda    ( IO_tof_sda  ),
.state     ( tof_state   ),
.dist_mm   ( tof_dist_raw ),
.dist_code ( tof_code    ),
.dist_stb  ( tof_stb_raw ),
.dist_sigma( tof_sigma   ),
.err_cnt   ( tof_errs    ),
.id_rb     ( tof_id      ),
.roi_ctr_req  ( tof_roi_ctr ),
.roi_xy_req   ( tof_roi_xy  ),
.dist_roi_ctr ( tof_rc      ),
.dist_roi_xy  ( tof_rxy     ),
.roi_opt      ( tof_roi_opt )
);
end else begin : g_no_tof
assign tof_state = 3'd0;
assign tof_dist_raw = 16'd0;
assign tof_code  = 8'd255;
assign tof_stb_raw  = 1'b0;
assign tof_errs  = 8'd0;
assign tof_sigma = 14'd0;
assign tof_id    = 16'd0;
assign tof_rc    = 8'd199;
assign tof_rxy   = 8'hFF;
assign tof_roi_opt = 8'd0;
assign IO_tof_scl = 1'bz;
assign IO_tof_sda = 1'bz;
end endgenerate

generate if (TOF_ROI_SCAN != 0) begin : g_roi_scan
tof_roi_scan #(
.NARROW0   ( TOF_ROI_FIXED ),   // 10-20: fixed at CTR_COL0 / CTR_ROW0 = 8 / 8 (SPAD 199)
.CTR_COL0  ( 8         ),
.CTR_ROW0  ( 8         ),
.ROI_W     ( 8         ),
.ROI_H     ( 8         ),
.GRID      ( 3         ),
.STEP      ( 3         ),
.CLK_HZ    ( 150000000 )
) u_tof_roi_scan (
.clk          ( pclkx1            ),
.rst_n        ( fifowait[7]       ),
.en           ( osd_state == 2'd1 ),   // BOX
.scan_go      ( qc_roi_go         ),
.dist_stb     ( tof_stb_raw       ),
.dist_mm      ( tof_dist_raw      ),
.dist_code    ( tof_code          ),
.dist_roi_ctr ( tof_rc            ),
.dist_roi_xy  ( tof_rxy           ),
.roi_ctr      ( tof_roi_ctr       ),
.roi_xy       ( tof_roi_xy        ),
.scanning     ( tof_roi_scanning  ),
.roi_col      ( tof_roi_col       ),
.roi_row      ( tof_roi_row       ),
.osd_text     ( tof_roi_text      )
);
end else begin : g_no_roi_scan
assign tof_roi_ctr      = 8'd199;
assign tof_roi_xy       = 8'hFF;
assign tof_roi_scanning = 1'b0;
assign tof_roi_col      = 4'd8;
assign tof_roi_row      = 4'd8;
assign tof_roi_text     = "     ";
end endgenerate

//---------------------------------------------------------------------------
// ⭐ 10-03 evening: the ranger's own bias, taken off ONCE, here, so every
// consumer (tof_size, qc_thick, aim_sched, trk_range) sees the same number.
// Bench (black foam backdrop): hand 133 mm read 139, the backdrop at
// 133 + 55 = 188 read 193 -> +5..+6; the 09-24 wall check read +4 at 500 and
// ~0 at 1000.  -5 is right for the 10..30 cm inspection range.  qc_thick's Z
// is a difference of two readings and does not move; DIST and 台面 do.
// 10-04: -5 -> -7.  New mount, hand-measured ToF -> workpiece top 160 read
// 162, -> table 219 read 222 (with -5).  Both consumers' D_OFS_MM below moved
// +2 with it, so every size is what it was apart from tof_size's refit.
// It must NOT go into tof_size alone: qc_thick compares tof_size's distance
// with its own TOP within XY_TOL_MM = 3.
//
// Registered (one adder, then a fan-out to four modules) with the strobe
// delayed to match.  vl53l1x_ctrl's dist / code / sigma are held registers
// that change only on the strobe clock, so one clock later code and sigma
// still belong to this distance.
//---------------------------------------------------------------------------
localparam integer TOF_OFS_MM = -7;

wire signed [17:0] tof_dist_s = $signed({2'b00, tof_dist_raw}) + TOF_OFS_MM;
reg  [15:0] tof_dist = 16'd0;//synthesis keep
reg         tof_stb  = 1'b0;

always @(posedge pclkx1 or negedge fifowait[7]) begin
    if (!fifowait[7]) begin
        tof_dist <= 16'd0;
        tof_stb  <= 1'b0;
    end else begin
        tof_dist <= tof_dist_s[17] ? 16'd0 : tof_dist_s[15:0];
        tof_stb  <= tof_stb_raw && !tof_roi_scanning;   // 10-04: not the scan's
    end
end

// BSS138 shifter LV-side reference (J14 pin 7).  Loaded only by the board's
// 10 K LV pull-ups, < 1 mA total.
assign O_lvref = 1'b1;
assign O_lvref2 = 1'b1;   // LV reference of the second BSS138 board (lights)

wire [63:0] tof_dist_text, tof_size_text, tof_pix_text;
wire [15:0] tof_w_mm;//synthesis keep
wire [15:0] tof_h_mm;//synthesis keep
wire        tof_size_ok;//synthesis keep
wire        tof_box_found, tof_pub_stb;
wire        tof_box_any;                 // 10-23: tof_size -> qc_thick, a box anywhere in the frame
wire [11:0] tof_box_x0, tof_box_y0, tof_box_w, tof_box_h;
wire [15:0] tof_size_d;
wire [1:0]  tof_size_why;
wire        tof_cal_go, tof_cal_done, tof_cal_ok;     // 10-04 calibration
wire [1:0]  tof_cal_why;
wire signed [9:0] tof_xy_ofs;//synthesis keep


//---------------------------------------------------------------------------
// ⭐ 10-31 night (user: "三棱柱的厚度误差较大"; 10-31 21:39 video, after the board
// calibration 标定+36-13): the 60 x 60 x 30 cube reads 60 x 60 x 30, the yellow
// triangle 55 x 48 x 42..44 -- every axis off together.  Its yellow box is as
// many pixels wide as the cube's, so its face is where the cube's was; the ToF
// reads it ~13 mm NEARER (its 27 deg cone sees much less of the triangle than
// of the cube's face, and more of whatever else is in it).  A nearer reading
// is exactly "Z too big AND W / H too small": +13 mm on the distance gives
// 30 and 58 x 51.  So in the 三棱柱 mode, with the part's box found (its own
// readings; BASE is learnt from the backdrop and keeps the raw ones), tof_size and
// qc_thick get distance + TRI_D_ADD_MM.  One register and a delayed strobe, so
// the add is not on tof_size's subtract path (dist_mm holds ~60 ms anyway).
// [board-tune] measured on one rig: if the triangle still reads off, put
// (三棱柱 Z - 30) on top of this (with the cube calibrated first); 0 = none.
// To drop the mode instead: QC_STD_NMODE 2 (key3 -> 任意 / 标准件 only).
// Every other ToF consumer (aim_sched, trk_range, gd_tof_gate) keeps tof_dist.
//---------------------------------------------------------------------------
localparam integer TRI_D_ADD_MM = 13;
reg  [15:0] tof_dist_qc = 16'd0;//synthesis keep
reg         tof_stb_qc  = 1'b0;
// Gated on tof_box_found, NOT tof_box_any: qc_thick learns BASE from blocks with
// no box_found (a box elsewhere -- a hand, a speck on the foam -- does not stop
// it), and a corrected reading in one of those would move BASE 13 mm back and
// every Z after it with it.  box_found is what makes a reading TOP (box_db).
wire        tri_adj = (QC_STD_NMODE == 3) && (qc_std_mode == 2'd3) && tof_box_found;
always @(posedge pclkx1 or negedge fifowait[7]) begin
    if (!fifowait[7]) begin
        tof_dist_qc <= 16'd0;
        tof_stb_qc  <= 1'b0;
    end else begin
        tof_dist_qc <= tof_dist + (tri_adj ? TRI_D_ADD_MM[15:0] : 16'd0);
        tof_stb_qc  <= tof_stb;
    end
end

tof_size #(
.NBLOB     ( DET_NBLOB ),
.AIM_X     ( 960       ),
.AIM_Y     ( 540       ),

// 10-03 evening refit (three bench shots, white charger 28 x 54.5 on black
// foam, DIST 125 / 139 / 188), on the bias-corrected distance above: one F
// left a worst error of 6.8 % (H always low), separate x / y focal lengths
// 2.2 %.  The residual is the ranger's own noise (+-3 mm at 13 cm = 2 %).
// Was F_PX 1680 / D_OFS -17 (= -12 on the corrected distance).
// 10-04: D_OFS 3 -> 17 (ToF re-mounted).  Two shots of the same charger on
// today's rig, 289 x 540 px at 164 and 300 x 555 at 160 (on -7): the four
// axis estimates of D = W * F / px less the reading are 18.1 / 17.7 / 15.5 /
// 16.8, and agree with each other -- x and y needed the same distance, so the
// F_PX / F_PX_Y ratio is right and only the offset moved.  Shown as 26 x 51,
// now 28 x 54..55 (true 28 x 54.5).  key2 held 1 s in BOX refits it on the
// board (qc_thick.v header) -- copy the 质检 row's first number back here.
// 10-04 16:54 board calibration read 标定+12+04 -> 12 (showed 28 x 55 x 55).
// ⭐ 10-20: 1880 / 1800 -> 1840 / 1840.  The 60 x 60 P1 cube boxed 560 x 563
// px -- square -- and was shown 53 x 56: the 4 % x / y split was fitted on
// the 28 mm charger only, whose narrow axis a white halo inflates by more
// (same px of glow on half the width).  The sensor's pixels are square.  The
// geometric mean keeps the overall scale, so D_OFS 12 still holds until the
// next key2 calibration; the charger now reads ~1 mm wide on x (inside the
// calibration's 6 % agreement gate).  Revert = the two old numbers.
.F_PX      ( 1840      ),
.F_PX_Y    ( 1840      ),
// ⭐ 10-20: 12 -> 34.  Three standard parts on today's rig, F 1840:
// P1 cube 536 x 535 px at 172 needs 172 + 34 for 60 x 60; P2 cylinder 542 x
// 325 at 139 needs 139 + 34 (+30 radius on the width, w_add_mm) for 60 x 30;
// P5 triangle 518 x 455 at 168 -> 57 x 50 (60 x 52; its printed tips are
// lost to the threshold).  With 12 all three read ~10 % small.  The rig was
// re-mounted since 10-04.  key2 held in 方块 refits it; copy the number back.
// ⭐ 10-31: 34 -> 37, the 10-30 23:25 board calibration (OSD 标定+37-16) on the
// 60 cube: before it the cube read 59-60, after 60-61.  Valid for THIS rig --
// moving the camera or the backdrop means key2 held again and copy back.
// ⭐ 10-31 night: 37 -> 36, the 10-31 21:39 calibration (标定+36-13).  Two
// sessions apart the offsets moved 1 / 3 mm: re-calibrate on the day.
.D_OFS_MM  ( 36        ),
// the calibration reference: the white charger's top face, 54.5 x 28.0
.CAL_L_D10 ( 545       ),
.CAL_S_D10 ( 280       ),
// 10-20: the second one, while qc_cal_cube: the P1 cube's face
.CAL2_L_D10 ( QC_P1_W * 10 ),
.CAL2_S_D10 ( QC_P1_H * 10 ),
// Rounded IIR step: truncation biased the filtered distance ~1.5 mm low.
.DIST_RND  ( 1         ),

// 10-02: a jump of more than 15 mm is a new object, taken at once.  At 100
// (the module default) a workpiece arriving 28 mm proud of the table was
// IIR-filtered, and SIZE crept to its value over ~10 readings -- qc_thick
// would have waited that long for X / Y to agree with its TOP.  Reading
// noise at bench range is a few mm, well inside 15.
.SNAP_MM   ( 15        )
) u_tof_size (
.clk         ( pclkx1        ),
.rst_n       ( fifowait[7]   ),

// The same vs the servo loop samples, for the same reason: one rising edge
// per frame under either reading of vs.  The boxes it snapshots only change
// on ccl_blob's single S_PUB clock, so any instant gives one frame's set.
.vs          ( cr_out_vs     ),
.tof_state   ( tof_state     ),
.dist_mm     ( tof_dist_qc   ),   // 10-31 night: TRI_D_ADD_MM (just above)
.dist_code   ( tof_code      ),
.dist_stb    ( tof_stb_qc    ),
.tof_id      ( tof_id        ),
.blob_x0     ( blob_x0       ),
.blob_x1     ( blob_x1       ),
.blob_y0     ( blob_y0       ),
.blob_y1     ( blob_y1       ),
.blob_valid  ( blob_valid    ),
.affine_pass ( af_mode == 4'd0 ),
.head_moving ( sv_moving     ),
.dist_text   ( tof_dist_text ),
.size_text   ( tof_size_text ),
.pix_text    ( tof_pix_text  ),
.size_w_mm   ( tof_w_mm      ),
.size_h_mm   ( tof_h_mm      ),
.size_ok     ( tof_size_ok   ),
.box_found   ( tof_box_found ),
.box_any     ( tof_box_any   ),   // 10-23
.box_x0      ( tof_box_x0    ),
.box_y0      ( tof_box_y0    ),
.box_w_px    ( tof_box_w     ),
.box_h_px    ( tof_box_h     ),
.size_d_mm   ( tof_size_d    ),
.size_why    ( tof_size_why  ),
.pub_stb     ( tof_pub_stb   ),
.cal_go      ( tof_cal_go    ),
.cal_ref2    ( qc_cal_cube   ),
.w_add_mm    ( qs_w_depth    ),
.cal_done    ( tof_cal_done  ),
.cal_ok      ( tof_cal_ok    ),
.cal_why     ( tof_cal_why   ),
.xy_ofs_mm   ( tof_xy_ofs    )
);

//---------------------------------------------------------------------------
// qc_thick (2026-10-02) -- QC MODE, the third dimension + the stable flag.
//
// Z = BASE - TOP: BASE is the ToF reading of the empty table, learnt by
// itself (a still block of readings with no box under the aim point) or by a
// key2 press in BOX (tare); TOP is a still block with the box present.  X / Y
// are tof_size's.  Procedure: BOX mode, table empty, wait for THICK to show
// "B<table mm>", push the workpiece in, wait for QC to read STABLE.
//
// ⭐ ETHERNET TRIGGER (teammate): qc_trig is one clock on the rising edge of
// qc_stable, once per workpiece; qc_rec is latched on that clock and held to
// the next trigger -- 128 bits, layout in qc_thick.v's header (X/Y/Z/TOP/BASE
// mm, box px, seq).  qc_stable is the level.  All on pclkx1.
// 10-03: a re-rise for the SAME workpiece (nudged, a box dropout, a ToF
// spike) does not trigger -- only removal, entering BOX, tare, or X/Y/Z
// changing by > CHG_MM re-arms it.  OSD: 尺寸 row = W x H x Z, 台面 row = BASE,
// 质检 row = state / 稳定 + record number.
//---------------------------------------------------------------------------
// qc_stable: declared with the 10-04 calibration sequencer (key2 block)
wire         qc_trig;//synthesis keep
wire [7:0]   qc_seq;//synthesis keep
wire [127:0] qc_rec;//synthesis keep
wire [15:0]  qc_thick_mm;//synthesis keep
wire [15:0]  qc_base_mm;//synthesis keep
wire         qc_base_ok;//synthesis keep
wire signed [7:0] qc_z_ofs;//synthesis keep
wire [95:0]  qc_size_text;
wire [63:0]  qc_base_text, qc_state_text;
wire         qc_text_cal, qc_text_stb;   // 10-30

qc_thick #(
// Same gate as aim_sched's confidence check, at its suggested looser value:
// at 10-30 cm on a black table sigma is a few mm, so this only rejects
// readings that are really broken.
.SIG_MAX_MM ( 40 ),
// 10-04: Z read 61 for the 55 mm charger (BASE 222 / TOP 162 on -5).  The
// hand-measured table-to-top is 59: 4 of the 6 mm are the creased cloth
// table, not the ranger -- on a flat board this over-corrects by ~4, so
// recalibrate (key2 held 1 s) and copy the 质检 row's second number here.
// 10-04 16:54 board calibration: +04.
// ⭐ 10-20: 4 -> -10.  Raw BASE - TOP on the board (fixed ROI): P1 cube 19,
// P5 triangle 22, P2 cylinder 55 for 30 / 30 / 60 -> -11 / -8 / -5; -10 is
// within 5 of all three.  The cloth backdrop is the spread (BASE is learnt
// with it hanging free; a part pushed against it moves it) -- a rigid board
// behind the parts, then key2 held in 方块, then copy the second number here.
// ⭐ 10-31: -10 -> -16, the same 10-30 23:25 calibration (标定+37-16): before
// it the 30 mm cube read Z 22-28 (厚-7 / -8 fails), after 29-34.
// ⭐ 10-31 night: -16 -> -13, the 10-31 21:39 calibration (标定+36-13): with
// -16 the cube read 33-34 (user: "33-35，可能不通过"), after it 30-31.
// Parts thinner than MIN_RAW_MM - Z_OFS_MM = 21 mm cannot be measured.
.Z_OFS_MM   ( -13 ),
.CAL_Z_MM   ( 55 ),
.CAL2_Z_MM  ( QC_P1_Z ),
// ⭐ 10-23: every wrong Z in the 10-22 23:50 recording (Z ~10 = 0 - Z_OFS_MM)
// was BASE learnt from the part's own face: a short key2 (tare) with the part
// in front, and a triangle left 3.5 s without a box of its own while the hand
// beside it was boxed (the nearer-BASE follow).  1 / 1 / 8: the tare and the
// follow only learn from frames with nothing in the picture, and BASE - TOP
// < 8 with the box present shows 台面异常 instead of a Z (qc_thick.v header).
// 8: the face-learnt cases read BASE - TOP -2..+3, the real parts 16..55, so
// at Z_OFS_MM -10 a part under 18 mm cannot be measured.
// 0 / 0 / 0 = the 10-20 behaviour.
.TARE_EMPTY ( 1 ),
.NEAR_EMPTY ( 1 ),
.MIN_RAW_MM ( 8 )
) u_qc_thick (
.clk        ( pclkx1          ),
.rst_n      ( fifowait[7]     ),
.en         ( osd_state == 2'd1 ),   // BOX
.tare       ( qc_tare         ),
.tof_state  ( tof_state       ),
.dist_mm    ( tof_dist_qc     ),   // 10-31 night: TRI_D_ADD_MM
.dist_code  ( tof_code        ),
.dist_stb   ( tof_stb_qc      ),
.dist_sigma ( tof_sigma       ),
.pub_stb    ( tof_pub_stb     ),
.box_found  ( tof_box_found   ),
.scene_any  ( tof_box_any     ),   // 10-23
.box_x0     ( tof_box_x0      ),
.box_y0     ( tof_box_y0      ),
.box_w_px   ( tof_box_w       ),
.box_h_px   ( tof_box_h       ),
.size_ok    ( tof_size_ok     ),
.size_w_mm  ( tof_w_mm        ),
.size_h_mm  ( tof_h_mm        ),
.size_d_mm  ( tof_size_d      ),
.size_why   ( tof_size_why    ),
.size_text  ( tof_size_text   ),
.head_moving( sv_moving       ),
.cal_req    ( qc_cal_req      ),
.cal_ref2   ( qc_cal_cube     ),
.cal_go     ( tof_cal_go      ),
.cal_done   ( tof_cal_done    ),
.cal_ok     ( tof_cal_ok      ),
.cal_why    ( tof_cal_why     ),
.xy_ofs_mm  ( tof_xy_ofs      ),
.z_ofs_mm   ( qc_z_ofs        ),
.qc_stable  ( qc_stable       ),
.qc_trig    ( qc_trig         ),
.qc_seq     ( qc_seq          ),
.qc_rec     ( qc_rec          ),
.thick_mm   ( qc_thick_mm     ),
.base_mm    ( qc_base_mm      ),
.base_ok    ( qc_base_ok      ),
.size3_text( qc_size_text    ),
.base_text  ( qc_base_text    ),
.qc_text    ( qc_state_text   ),
.qc_text_cal( qc_text_cal     ),   // 10-30: for text_osd's 状态 / 判定 rows
.qc_text_stb( qc_text_stb     )
);

//---------------------------------------------------------------------------
// qc_std (10-20) -- 任意 + three standard workpieces (P1 方块 / P2 圆柱 / P5
// 三棱柱, tools/qc_parts): the BOX page's 工件 / 体积 / 判定 rows.  Judges the
// numbers the 尺寸 row shows (snapshot on the same pub_stb), only while
// qc_stable; tolerance XY +-3 / Z +-5 mm.  OSD only -- not in qc_rec / qc_ext.
//---------------------------------------------------------------------------
wire [103:0] qs_part_text, qs_vol_text, qs_judge_text, qs_reason_text;   // 10-30: + 原因
wire         qs_valid;//synthesis keep
wire         qs_pass;//synthesis keep

qc_std #(
.TOL_XY_MM ( 3 ),
.TOL_Z_MM  ( 5 ),
.P1_W      ( QC_P1_W ), .P1_H ( QC_P1_H ), .P1_Z ( QC_P1_Z ),
// ⭐ 10-30 (user): the standard part must also be the right colour and shape;
// 原因 lists every failing one.  The standard cube is WHITE (the demo cube):
// bit n = obj_color class n passes (0 黑 1 灰 2 白 3 红 .. 9 紫).  If the good
// cube reads 灰 under the demo lighting -- obj_color calls a white part 灰 in
// ~14% of dim frames (fpga_obj_color_1011) -- so 白 AND 灰 pass: 16'h0006.
// 16'h0004 = 白 only.  ethernet_video/host/qc_rules.py judge_fpga does not
// know about colour / shape yet (it prints 见屏幕判定 for those).
.CS_JUDGE  ( 1 ),
.STD_COLOR_MASK ( 16'h0006 ),
// 10-31: the 三棱柱 standard is yellow; 橙 passes too for the same reason 灰 does
// for the white cube (the classifier's yellow/orange line moves with the light).
.STD_COLOR_MASK3 ( 16'h0030 )
) u_qc_std (
.clk         ( pclkx1        ),
.rst_n       ( fifowait[7]   ),
.mode        ( qc_std_mode   ),
.pub_stb     ( tof_pub_stb   ),
.stable      ( qc_stable     ),
.stain       ( st_out        ),   // 10-28: a stained part in size = 不合格 污渍
.w_mm        ( tof_w_mm      ),
.h_mm        ( tof_h_mm      ),
.z_mm        ( qc_thick_mm   ),
.color       ( oc_stable_id  ),   // 10-30: 15 when OBJ_COLOR = 0 -> always 测量中
.shape       ( sv_class      ),
.shape_v     ( sv_valid      ),
.part_text   ( qs_part_text  ),
.vol_text    ( qs_vol_text   ),
.judge_text  ( qs_judge_text ),
.reason_text ( qs_reason_text ),
.judge_valid ( qs_valid      ),
.judge_pass  ( qs_pass       ),
.w_depth_mm  ( qs_w_depth    )
);

//---------------------------------------------------------------------------
// qc_defect (2026-10-06) -- surface defects on the workpiece, BOX mode only.
// 16x16 px cells, the part is its own reference (see the module header).
// Colour = the picture det_binarize sees; mask = its bit after the opening.
// Result is its own interface for the teammate (not in qc_rec -- adding it
// there would re-open qc_thick's 84-check bench): qd_bad level, qd_stb pulse
// per judgement (~every other frame), counts, and the bounding box of the
// flagged cells.  Boxes drawn in red (u_qd_overlay, after the yellow ones).
//---------------------------------------------------------------------------
wire         qd_stb;//synthesis keep
wire         qd_obj;//synthesis keep
wire         qd_bad;//synthesis keep
wire [15:0]  qd_cnt, qd_hole, qd_stain, qd_edge, qd_int;//synthesis keep
wire [11:0]  qd_x0, qd_y0, qd_x1, qd_y1;//synthesis keep
wire [79:0]  qd_text;
wire         qd_ovl_flag;
wire [7:0]   qd_mR, qd_mG, qd_mB;//synthesis keep

qc_defect #(
.IMG_HDISP ( 1920 ),
.IMG_VDISP ( 1080 ),
.CAW       ( 13   )
) u_qc_defect (
.clk       ( pclkx1        ),
.rst_n     ( fifowait[7]   ),
.en        ( osd_state == 2'd1 ),   // BOX
.in_vs     ( af_out_vs     ),
.in_de     ( af_out_de     ),
.in_r      ( af_out_r      ),
.in_g      ( af_out_g      ),
.in_b      ( af_out_b      ),
.m_vs      ( mop_vs        ),
.m_de      ( mop_de        ),
.m_bin     ( mop_bin       ),
.def_stb   ( qd_stb        ),
.def_obj   ( qd_obj        ),
.def_bad   ( qd_bad        ),
.def_cnt   ( qd_cnt        ),
.def_hole  ( qd_hole       ),
.def_stain ( qd_stain      ),
.def_edge  ( qd_edge       ),
.def_x0    ( qd_x0         ),
.def_y0    ( qd_y0         ),
.def_x1    ( qd_x1         ),
.def_y1    ( qd_y1         ),
.def_int   ( qd_int        ),
.def_text  ( qd_text       ),
.def_mR    ( qd_mR         ),
.def_mG    ( qd_mG         ),
.def_mB    ( qd_mB         ),
.ovl_raddr ( 13'd0         ),
.ovl_flag  ( qd_ovl_flag   )
);

//---------------------------------------------------------------------------
// aim_sched (2026-10-01) -- SECURITY MODE, HANDOFF §-9.3.  Points the head-
// mounted ToF at each green motion box in turn (oldest reading first), waits
// SETTLE_MS, takes NMEAS readings, keeps the ones with RangeStatus 0 and
// sigma <= SIG_MAX_MM, and binds their median to that box by position.
// Every box gets a label (aim_label below): distance, W x H by the pinhole
// model with ITS OWN distance, or '?' when nothing trusted.  ALARM flashes
// while any box is up.
//
// en = wheel position MOTION (12): the green boxes are drawn there, so that
// is where their labels belong.  Leaving MOTION parks the head at centre --
// which is also where tof_size's centre-box SIZE row wants it.
//
// ⭐ res_tab is the result table for the Ethernet / SD side (teammates):
// NBOX x 128-bit records written on res_stb's one clock; format in
// aim_sched.v's port list.  Read the latched copy, never the live table.
//---------------------------------------------------------------------------
wire [FACE_NROI*4-1:0]  al_x0, al_y0;
wire [FACE_NROI-1:0]    al_valid, al_dok, al_aim;
wire [FACE_NROI*16-1:0] al_d_bcd, al_w_bcd, al_h_bcd;
wire                    al_alarm;//synthesis keep
wire [FACE_NROI*128-1:0] as_res_tab;//synthesis keep
wire [7:0]              as_res_seq;//synthesis keep
wire                    as_res_stb;//synthesis keep
wire                    as_res_mode;
wire [2:0]              as_ms_state;//synthesis keep
wire [7:0]              as_ms_count;//synthesis keep

// aim_sched's own outputs; as_aim_* / as_res_* are the trk_view muxes below.
wire [11:0]              asp_aim_x, asp_aim_y;
wire                     asp_aim_go;
wire [FACE_NROI*128-1:0] asp_res_tab;
wire [7:0]               asp_res_seq;
wire                     asp_res_stb;

aim_sched #(
.NBOX        ( FACE_NROI ),
.BLK_W       ( 128       ),
.BLK_H       ( 72        ),
.IMG_HDISP   ( 1920      ),
.IMG_VDISP   ( 1080      ),
.CLK_HZ      ( 150000000 ),

// ⚠ Same GUESS as tof_size's -- calibrate both together.
.F_PX        ( 1680      ),
.D_OFS_MM    ( -10       ),   // -17 on the raw reading = -10 after TOF_OFS_MM (-7 since 10-04)

.SETTLE_MS   ( 150       ),
.DISCARD     ( 1         ),
.NMEAS       ( 3         ),
.SIG_MAX_MM  ( 25        ),
.MEAS_TMO_MS ( 600       )
) u_aim_sched (
.clk         ( pclkx1        ),
.rst_n       ( fifowait[7]   ),

// cr_out_vs: the vs motion_frame_drawer itself sees, so the rising-edge
// snapshot holds exactly the boxes the green overlay is about to draw.
.vs          ( cr_out_vs     ),
.en          ( cc_motion_frame_en ),

.box_x0      ( md_box_x0     ),
.box_x1      ( md_box_x1     ),
.box_y0      ( md_box_y0     ),
.box_y1      ( md_box_y1     ),
.box_valid   ( md_box_valid  ),

.tof_state   ( tof_state     ),
.dist_mm     ( tof_dist      ),
.dist_code   ( tof_code      ),
.dist_sigma  ( tof_sigma     ),
.dist_stb    ( tof_stb       ),

.aim_x       ( asp_aim_x     ),
.aim_y       ( asp_aim_y     ),
.aim_go      ( asp_aim_go    ),

.lb_x0       ( al_x0         ),
.lb_y0       ( al_y0         ),
.lb_valid    ( al_valid      ),
.lb_dok      ( al_dok        ),
.lb_aim      ( al_aim        ),
.lb_d_bcd    ( al_d_bcd      ),
.lb_w_bcd    ( al_w_bcd      ),
.lb_h_bcd    ( al_h_bcd      ),
.alarm       ( al_alarm      ),

.res_tab     ( asp_res_tab   ),
.res_seq     ( asp_res_seq   ),
.res_stb     ( asp_res_stb   ),
.res_mode    ( as_res_mode   ),

.ms_state    ( as_ms_state   ),
.ms_count    ( as_ms_count   )
);

//---------------------------------------------------------------------------
// trk_range (2026-10-01 evening) -- the MAGENTA view of security mode: the
// ToF follows the single-target tracker's box and ranges it continuously;
// one label at its corner.  See trk_range.v's header for why this is not
// aim_sched with NBOX = 1 (identity vs position-keyed polling).
//
// trk_held = trk_state != 0: a coasting track is still ranged -- with the
// camera fixed, a coast is an object that paused, and its position is valid.
//---------------------------------------------------------------------------
wire [11:0] tr_aim_x, tr_aim_y;
wire        tr_aim_go;
wire [11:0] tr_px0, tr_py0;
wire        tr_valid, tr_dok, tr_aim;
wire [15:0] tr_d_bcd, tr_w_bcd, tr_h_bcd;
wire        tr_alarm;//synthesis keep
wire [127:0] tr_rec;
wire [7:0]  tr_seq;
wire        tr_stb;

trk_range #(
.IMG_HDISP  ( 1920      ),
.IMG_VDISP  ( 1080      ),
.CLK_HZ     ( 150000000 ),
// ⚠ Same GUESS as tof_size / aim_sched -- calibrate all three together.
.F_PX       ( 1680      ),
.D_OFS_MM   ( -10       ),   // -17 on the raw reading = -10 after TOF_OFS_MM (-7 since 10-04)
.SIG_MAX_MM ( 25        ),
.SETTLE_MS  ( 150       ),
.FRESH_MS   ( 600       ),
// 10-05: 90 -> 45 frames (~1.5 s -> ~0.75 s at ~58 fps): the spot goes off
// sooner.  Voice escalation does not depend on it -- alert_ctrl's episode
// clock bridges longer dropouts on its own (REARM_S).
.ALARM_HOLD ( 8'd45     )
) u_trk_range (
.clk        ( pclkx1        ),
.rst_n      ( fifowait[7]   ),
.vs         ( cr_out_vs     ),
.en         ( cc_track_en   ),
// 10-05 night: a visible face also holds the aim (someone standing still
// and talking has no magenta box, the spot must stay on the face).
.trk_held   ( md_trk_state != 2'd0 || (SEC_AIM_FACE != 0 && fa_person) || (SEC_AIM_GD != 0 && ga_v) ),
.box_v      ( md_trk_v      ),
.cx         ( (SEC_AIM_FACE != 0 && fa_person) ? fa_x : (SEC_AIM_GD != 0 && ga_v) ? ga_x : md_target_x ),
.cy         ( (SEC_AIM_FACE != 0 && fa_person) ? fa_y : (SEC_AIM_GD != 0 && ga_v) ? ga_y : md_target_y ),
.bx0        ( md_trk_x0     ),
.bx1        ( md_trk_x1     ),
.by0        ( md_trk_y0     ),
.by1        ( md_trk_y1     ),
.dist_mm    ( tof_dist      ),
.dist_code  ( tof_code      ),
.dist_sigma ( tof_sigma     ),
.dist_stb   ( tof_stb       ),
.aim_x      ( tr_aim_x      ),
.aim_y      ( tr_aim_y      ),
.aim_go     ( tr_aim_go     ),
.lb_px0     ( tr_px0        ),
.lb_py0     ( tr_py0        ),
.lb_valid   ( tr_valid      ),
.lb_dok     ( tr_dok        ),
.lb_aim     ( tr_aim        ),
.lb_d_bcd   ( tr_d_bcd      ),
.lb_w_bcd   ( tr_w_bcd      ),
.lb_h_bcd   ( tr_h_bcd      ),
.alarm      ( tr_alarm      ),
.res_rec    ( tr_rec        ),
.res_seq    ( tr_seq        ),
.res_stb    ( tr_stb        )
);

// The trk_view muxes.  Head command, label table, result table: one source
// each, never a blend.  In MAGENTA the result table is slot 0 only.
assign as_aim_x   = trk_view ? tr_aim_x  : asp_aim_x;
assign as_aim_y   = trk_view ? tr_aim_y  : asp_aim_y;
assign as_aim_go  = trk_view ? tr_aim_go : asp_aim_go;
assign as_res_tab = trk_view ? {{(FACE_NROI-1)*128{1'b0}}, tr_rec} : asp_res_tab;
assign as_res_seq = trk_view ? tr_seq : asp_res_seq;
assign as_res_stb = trk_view ? tr_stb : asp_res_stb;

wire [FACE_NROI-1:0]    lbm_valid = trk_view ? {{(FACE_NROI-1){1'b0}}, tr_valid} : al_valid;
wire [FACE_NROI-1:0]    lbm_dok   = trk_view ? {{(FACE_NROI-1){1'b0}}, tr_dok}   : al_dok;
wire [FACE_NROI-1:0]    lbm_aim   = trk_view ? {{(FACE_NROI-1){1'b0}}, tr_aim}   : al_aim;
wire [FACE_NROI*16-1:0] lbm_d_bcd = trk_view ? {{(FACE_NROI-1)*16{1'b0}}, tr_d_bcd} : al_d_bcd;
wire [FACE_NROI*16-1:0] lbm_w_bcd = trk_view ? {{(FACE_NROI-1)*16{1'b0}}, tr_w_bcd} : al_w_bcd;
wire [FACE_NROI*16-1:0] lbm_h_bcd = trk_view ? {{(FACE_NROI-1)*16{1'b0}}, tr_h_bcd} : al_h_bcd;
wire                    lbm_alarm = trk_view ? tr_alarm : al_alarm;

//---------------------------------------------------------------------------
// 2026-10-04: intruder reaction.  Security mode only (sec_mode); "someone is
// there" = lbm_alarm, which already carries the ~90-frame ALARM_HOLD.
//   spot  : on while the alarm is up        (red tracking spotlight, J14-9)
//   (the fill light, J14-8, is light_meter below: ambient-driven, both modes)
//   voice : clip 0 on arrival, clip 1 after 6 s and every 8 s while it stays;
//           re-armed after 5 s of absence.  Clips: tools/voice/make_voice_rom.py
//           (re-run it and paste the START/LEN lines it prints if the
//           sentences change).  voice_rom.hex sits next to i2s_player.v because
//           $readmemh resolves relative to the caller and fails silently.
// Tested by uisrc/02_sim/alrtb.v (I2S bit-exact decode + the state machine).
//---------------------------------------------------------------------------
// Lamp polarity at the pin.  0 = a high pin lights the lamp (XY-MOS trigger is
// assumed active-high -- UNVERIFIED on the board; the 30-second hand test is in
// the hardware wiring README, section 2.4).  The BSS138 board is non-inverting.
localparam FLOOD_ACTIVE_LOW = 0;
localparam SPOT_ACTIVE_LOW  = 0;
wire       sp_on;            // alert_ctrl's spot
wire       sp_pin;//synthesis keep   // 10-23: the lamp, after spot_seq (SEC_STAFF_SPOT)
assign O_spot_en = sp_pin ^ (SPOT_ACTIVE_LOW != 0);

wire       vo_play, vo_busy;
wire [1:0] sec_level;//synthesis keep  0 idle / 1 motion / 2 face / 3 no-face timeout
wire [1:0] vo_clip;

// 2026-10-12: staff verification (staff_ctrl, instanced after face_detect).
// staff_pass = face recognised as the staff member AND the liveness challenge
// answered.  While it is up: alert_ctrl is disabled (spot off, no alarm voice,
// sec_level 0), aim_label draws "员工 PASS" instead of 报警.  The Ethernet
// log of a pass is the Ethernet teammate's: staff_pass is the signal to use.
wire       staff_pass;//synthesis keep
wire       st_play;
wire [3:0] st_clip;
wire       st_hold;          // challenge running / staff clip queued: alarm voice waits

//---------------------------------------------------------------------------
// 2026-10-07 (user): announce the mode on every key4 change -- clip 2 +
// osd_state ("安防/质检/人脸/原图模式").  Not at power-up (no change).
// Arbitration with alert_ctrl, which drops a clip it could not start:
//   * alert_ctrl sees busy (md_ann_hold) from the key press on, so it never
//     fires a clip that the announcement would shadow;
//   * on the one cycle where both fire (alert decided from last cycle's busy)
//     the alert wins and the announcement waits for it to end (<= 2.6 s).
// Fast presses: only the latest mode is announced.
//---------------------------------------------------------------------------
reg  [1:0] md_ann_prev = OSD_RAW;
reg        md_ann_pend = 1'b0;
reg  [1:0] md_ann_mode = 2'd0;
wire       md_ann_go   = md_ann_pend && !vo_busy && !vo_play && !st_play;
always @(posedge pclkx1 or negedge fifowait[7]) begin
    if (!fifowait[7]) begin
        md_ann_prev <= OSD_RAW;
        md_ann_pend <= 1'b0;
        md_ann_mode <= 2'd0;
    end else begin
        md_ann_prev <= osd_state;
        if (osd_state != md_ann_prev) begin
            md_ann_pend <= 1'b1;
            md_ann_mode <= osd_state;
        end else if (md_ann_go)
            md_ann_pend <= 1'b0;
    end
end
// alert_ctrl's busy: also high on the cycle osd_state changes, before
// md_ann_pend is registered -- otherwise an intruder already in view on
// entry to SECURITY gets clip 0 out ahead of "安防模式".
wire       md_ann_hold = vo_busy || md_ann_pend || (osd_state != md_ann_prev);
wire       pl_play = vo_play | md_ann_go | st_play;
wire [3:0] pl_clip = vo_play ? {2'b00, vo_clip} : st_play ? st_clip : (4'd2 + {2'b00, md_ann_mode});

// 10-22: SEC_SPOT_GD = 1 reads the spot one clock late (sp_on_d), so the
// "already up" term is a register, not a loop through alert_ctrl's spot_en.
reg  sp_on_d = 1'b0;
always @(posedge pclkx1) sp_on_d <= sp_on;
wire ga_spot = trk_view && ga_v && (SEC_SPOT_GD == 2 || (SEC_SPOT_GD == 1 && sp_on_d));

alert_ctrl #(
// 10-06: the spot never switches faster than this -- 1 s after the last
// "someone is there".  Floor under every upstream dropout.
.SPOT_HOLD_CLKS ( 150_000_000 )
) u_alert_ctrl(
.clk         ( pclkx1        ),
.rst_n       ( fifowait[7]   ),
// 10-12: a verified staff member switches the whole alert off (spot, voice,
// level -> 0 so the Ethernet side sends no alarm pictures either).
.en          ( sec_mode && !ss_quiet ),   // 10-23: ss_quiet = staff_pass when SEC_STAFF_SPOT = 0
// 10-05 night: a face counts as "someone is there" too (MAGENTA view), so
// the spot stays lit on a person who stopped moving.
.target      ( (SEC_ALARM_SRC != 0) ? as_target :
                lbm_alarm || (trk_view && fa_person) || ga_spot ),   // 10-22: + blue box, SEC_SPOT_GD
.person      ( (SEC_ALARM_SRC != 0) ? sec_face : fa_person ),
.player_busy ( md_ann_hold || st_hold || ss_mute ),   // 10-12: staff prompt / answer; 10-28: + voice quiet after a pass
.play        ( vo_play       ),
.clip        ( vo_clip       ),
.spot_en     ( sp_on         ),
.level       ( sec_level     )
);

//---------------------------------------------------------------------------
// 2026-10-05: fill light (J14-8) = "the room is too dark", in SECURITY and
// INSPECTION mode (osd_state 0 / 1), not tied to intruders.  Metered at the
// auto-level input (w_rgb_*): fixed exposure + gain, so its mean is linear
// in illuminance -- the ISP histogram overlay shows the same signal, which is
// how to pick ON_TH on the board.  light_meter learns the light's own
// contribution when it switches on so the light cannot switch itself off.
//---------------------------------------------------------------------------
wire [7:0] lm_mean, lm_sig, lm_ambient;//synthesis keep
wire       lm_on;//synthesis keep

// ⭐ 10-30: 0 = the fill light never comes on in 质检 (INSPECTION).  The
// 18:48 board video: with the room lights ON the lamp still came on there,
// because the meter reads the black backdrop that fills the 质检 picture
// (dark by design, not because the room is dark).  Lit, the backdrop goes
// from black to grey-violet (~68/66/77) and the colour CNN's mask -- trained
// on a black background -- stops separating the parts from it: no box on the
// parts, boxes jumping on the foam strip, "测不准".  The same video with the
// lamp off measured and classified fine.  1 = the 10-05 behaviour (both
// modes); retrain the colour CNN on lit-backdrop frames before going back.
localparam integer QC_FLOOD = 0;

light_meter #(
.ON_TH      ( 8'd6   ),   // 10-05: 12 -> 6, it came on at a slight dimming   // [board-tune] sig = mean - black point below which it is "dark"
.HYST       ( 8'd10  )
) u_light_meter(
.clk      ( pclkx1                          ),
.rst_n    ( fifowait[7]                     ),
.en       ( osd_state == 2'd0 || (QC_FLOOD != 0 && osd_state == 2'd1) ),   // 10-30: QC_FLOOD
.in_vs    ( w_rgb_vsync                     ),
.in_de    ( w_rgb_href                      ),
.in_g     ( w_rgb_g                         ),
.lo       ( osd_lo_g                        ),
.light_on ( lm_on                           ),
.mean     ( lm_mean                         ),
.sig      ( lm_sig                          ),
.ambient  ( lm_ambient                      )
);
assign O_flood_en = lm_on ^ (FLOOD_ACTIVE_LOW != 0);

// Blank the motion detector around every lamp edge (see light_inhibit.v):
// the fill light steps the whole picture (12 frames covers auto-level's 1/4
// IIR settling), the spotlight lights/un-lights a patch of wall (4 frames =
// 1 vetoed + 2 re-seeding + 1 margin).
reg lm_on_q = 1'b0, sp_on_q = 1'b0;
always @(posedge pclkx1) begin lm_on_q <= lm_on; sp_on_q <= sp_pin; end   // 10-23: the lamp itself
wire lt_inh_flood, lt_inh_spot;
light_inhibit #(.N(8'd12)) u_lt_inh_flood(
.clk(pclkx1), .rst_n(fifowait[7]), .vs(cr_out_vs),
.chg(lm_on != lm_on_q), .inhibit(lt_inh_flood));
light_inhibit #(.N(8'd4)) u_lt_inh_spot(
.clk(pclkx1), .rst_n(fifowait[7]), .vs(cr_out_vs),
.chg(sp_pin != sp_on_q), .inhibit(lt_inh_spot));
assign lt_md_inhibit = lt_inh_flood | lt_inh_spot;

i2s_player #(
.BCLK_HALF  ( 293             ),   // 150 MHz / 586 = 256 kHz BCLK, fs = 8 kHz
.ROM_AW     ( 18              ),   // 10-24: 17 -> 18, clip 10 pushed the ROM past 128 K
.ROM_DEPTH  ( 139264          ),   // 10-24: 136326 used (10-12 night: 120810, 10-12: 106496 / 104579, 10-07: 65536 / 64315)
.VOICE_FILE ( "voice_rom.hex" ),
.START0 ( 18'd0     ), .LEN0 ( 18'd20800 ),   // 2.60 s  clip 0: "you have entered a monitored area, please leave"
.START1 ( 18'd20800 ), .LEN1 ( 18'd18107 ),   // 2.26 s  clip 1: "warning, leave immediately"
.START2 ( 18'd38907 ), .LEN2 ( 18'd6293  ),   // 0.79 s  clip 2: 安防模式  (osd_state 0)
.START3 ( 18'd45200 ), .LEN3 ( 18'd6399  ),   // 0.80 s  clip 3: 质检模式  (1)
.START4 ( 18'd51599 ), .LEN4 ( 18'd6183  ),   // 0.77 s  clip 4: 人脸模式  (2)
.START5 ( 18'd57782 ), .LEN5 ( 18'd6533  ),   // 0.82 s  clip 5: 原图模式  (3)
.START6 ( 18'd64315 ), .LEN6 ( 18'd10514 ),   // 1.31 s  clip 6: staff verified    (staff_ctrl)
.START7 ( 18'd74829 ), .LEN7 ( 18'd9426  ),   // 1.18 s  clip 7: open your mouth 3 times  (staff_ctrl MOUTH_EV)
.START8 ( 18'd84255 ), .LEN8 ( 18'd23991 ),   // 3.00 s  clip 8: blink twice, glasses off (BLINK_EV)
.START9 ( 18'd108246), .LEN9 ( 18'd12564 ),   // 1.57 s  clip 9: verification failed      (staff_ctrl)
.START10( 18'd120810), .LEN10( 18'd15516 ),   // 1.94 s  clip 10: 身份核验，请走近          (staff_ctrl NEAR, 10-24)
.VOL_SHIFT  ( 1               )    // -6 dB: the 5 V rail is shared with the servos
) u_i2s_player(
.clk    ( pclkx1      ),
.rst_n  ( fifowait[7] ),
.play   ( pl_play     ),
.clip   ( pl_clip     ),
.busy   ( vo_busy     ),
.o_bclk ( O_i2s_bclk  ),
.o_lrc  ( O_i2s_lrc   ),
.o_din  ( O_i2s_din   )
);

//---------------------------------------------------------------------------
// hist_osd : draws the ISP input histogram, so picture tuning stops being a
// guess-synthesise-burn loop.  Sits downstream of the effect wheel, so the
// overlay reads the same in every wheel position.  (It was the last stage
// before the OSD text engine went in; det_overlay and text_osd are now below
// it -- both deliberately drawn ON TOP of it.)
//
// It is fed frame-active-high vs -- color_replace already flipped the wheel's
// polarity back, so nothing is inverted here any more -- and adds 2 clocks to
// data, de and vs alike.
//---------------------------------------------------------------------------
wire        osd_out_vs;//synthesis keep
wire        osd_out_de;//synthesis keep
wire [23:0] osd_out_rgb;//synthesis keep

hist_osd u_hist_osd(
.clk       ( pclkx1        ),
.rst_n     ( fifowait[7]   ),
.en        ( isp_osd_en    ),
.bin_valid ( osd_bin_valid ),
.bin_level ( osd_bin_level ),
.cnt_r     ( osd_cnt_r     ),
.cnt_g     ( osd_cnt_g     ),
.cnt_b     ( osd_cnt_b     ),
.lo_g      ( osd_lo_g      ),
.hi_g      ( osd_hi_g      ),
.in_vs     ( md_out_vs     ),
.in_de     ( md_out_de     ),
.in_rgb    ( md_out_rgb    ),
.out_vs    ( osd_out_vs    ),
.out_de    ( osd_out_de    ),
.out_rgb   ( osd_out_rgb   )
);

//---------------------------------------------------------------------------
// det_overlay : the detection bounding boxes, in yellow.
//
// AFTER hist_osd and BEFORE text_osd, which is the only position that works:
// the histogram is a tuning aid and can be covered, but the status panel and
// the vendor logo are scored items and have to stay on top of everything.
//
// Yellow because motion_frame_drawer already owns green, and the two overlays
// can be up together -- MOTION on the wheel plus F9 in a detect state.  A demo
// where the judge cannot tell the motion box from the detection box has thrown
// away the distinction between two separate scored items.
//
// Gated by det_ovl_en (F9 bit 1); the detection pipeline above runs either way.
// 3 clocks on data, de and vs alike.  latency_meter MEASURES the chain rather
// than assuming it, so the OSD's latency reading follows this by itself.
//---------------------------------------------------------------------------
wire        dov_out_vs;//synthesis keep
wire        dov_out_de;//synthesis keep
wire [23:0] dov_out_rgb;//synthesis keep

det_overlay#(
.NBLOB     ( DET_NBLOB    ),
.BOX_RGB   ( 24'hFFFF00   ),
.BOX_THICK ( 3            ),

// Same de-derived vertical blank as ccl_blob, for the same reason: this
// module's box latch was open over mop_vs's low period, which is the 5-line
// sync pulse and not the interval its own comment reasons about.  ccl_blob
// now publishes anywhere in the real 45 lines, so the latch has to be open
// for all of them or the boxes lag a frame.  VS_LATCH=1 restores the old
// window bit-exactly.
.VB_GUARD  ( 512          ),
.VS_LATCH  ( 0            )
)u_det_overlay(
.clk        ( pclkx1      ),
.rst_n      ( fifowait[7] ),
.en         ( det_ovl_en  ),

.blob_x0    ( blob_x0     ),
.blob_x1    ( blob_x1     ),
.blob_y0    ( blob_y0     ),
.blob_y1    ( blob_y1     ),
.blob_valid ( blob_valid  ),

.in_vs      ( osd_out_vs  ),
.in_de      ( osd_out_de  ),
.in_rgb     ( osd_out_rgb ),

.out_vs     ( dov_out_vs  ),
.out_de     ( dov_out_de  ),
.out_rgb    ( dov_out_rgb )
);

// 10-06: qc_defect's box, red, over the yellow object boxes (same BOX gate).
// qd_x1/qd_y1 are exclusive; det_overlay wants inclusive.
wire        qdo_out_vs;//synthesis keep
wire        qdo_out_de;//synthesis keep
wire [23:0] qdo_out_rgb;//synthesis keep
localparam integer QD_DRAW = 0;          // 10-28: old qc_defect red box off

det_overlay#(
.NBLOB     ( 1           ),
.BOX_RGB   ( 24'hFF2020  ),
.BOX_THICK ( 3           ),
.VB_GUARD  ( 512         ),
.VS_LATCH  ( 0           )
)u_qd_overlay(
.clk        ( pclkx1      ),
.rst_n      ( fifowait[7] ),
.en         ( det_ovl_en  ),

.blob_x0    ( qd_x0           ),
.blob_x1    ( qd_x1 - 12'd1   ),
.blob_y0    ( qd_y0           ),
.blob_y1    ( qd_y1 - 12'd1   ),
// ⭐ 10-28 (user): the old qc_defect's red box is retired (stain_detect's red
// cells below are the stain display now).  The overlay stays in the chain with
// valid 0, so the picture's latency and alignment are unchanged.  QD_DRAW 1 =
// the box back.
.blob_valid ( qd_bad && (QD_DRAW != 0) ),

.in_vs      ( dov_out_vs  ),
.in_de      ( dov_out_de  ),
.in_rgb     ( dov_out_rgb ),

.out_vs     ( qdo_out_vs  ),
.out_de     ( qdo_out_de  ),
.out_rgb    ( qdo_out_rgb )
);

// ⭐ 10-27: stain_detect's hot cells, red at 50 % (teammate's stain_overlay,
// unchanged), over the yellow / red boxes and under the text -- same BOX
// gate.  Its cell map is the same expression as stain_detect's, bit for bit,
// so a red cell is a judged cell.  3 clocks on data, de and vs alike.
// STAIN_DET = 0: a wire (no extra latency).
wire        sto_out_vs;//synthesis keep
wire        sto_out_de;//synthesis keep
wire [23:0] sto_out_rgb;//synthesis keep

generate if (STAIN_DET != 0) begin : g_stain_ovl
    stain_overlay #(
    .IMG_HDISP ( 1920       ),
    .IMG_VDISP ( 1080       ),
    .G         ( 128        ),   // must equal stain_cnn.vh SCNN_G
    .HG        ( 64         ),   // must equal stain_cnn.vh SCNN_HG
    .HOT_RGB   ( 24'hFF0000 )
    ) u_stain_overlay (
    .clk        ( pclkx1      ),
    .rst_n      ( fifowait[7] ),
    .en         ( det_ovl_en  ),
    .hmap_ra    ( st_hmap_ra  ),
    .hmap_q     ( st_hmap_q   ),
    .hmap_vld   ( st_hmap_vld ),
    .hmap_x0    ( st_hmap_x0  ),
    .hmap_y0    ( st_hmap_y0  ),
    .hmap_x1    ( st_hmap_x1  ),
    .hmap_y1    ( st_hmap_y1  ),
    .in_vs      ( qdo_out_vs  ),
    .in_de      ( qdo_out_de  ),
    .in_rgb     ( qdo_out_rgb ),
    .out_vs     ( sto_out_vs  ),
    .out_de     ( sto_out_de  ),
    .out_rgb    ( sto_out_rgb )
    );
end else begin : g_no_stain_ovl
    assign st_hmap_ra  = 12'd0;
    assign sto_out_vs  = qdo_out_vs;
    assign sto_out_de  = qdo_out_de;
    assign sto_out_rgb = qdo_out_rgb;
end endgenerate

//---------------------------------------------------------------------------
// 2026-10-12: grid_det, the static-person detector (stage A/B by GPT in
// Anlogic5_v4/tools/grid_det; RTL rewritten by Claude, bit-exact to its
// integer golden, see the module header).  A 7-layer int8 CNN on a 160x90
// gray thumbnail of cr_out_*, 20x12 grid, up to 4 boxes.  One result every
// two frames (~3.75M clocks from frame start to pub).
//
// Side branch like every other detector: the only thing in the display path
// is another det_overlay, blue, after the qc box and UNDER the red face boxes
// (a face box inside a person box is the legible picture).  Security mode
// only.  NOT in the alarm: motion detection keeps that job until it is
// removed (user, 10-12).  gd_person is the signal the fusion will use.
//
// Weights (10-23): grid_rec_20261014/models/v11a_s1, threshold 1066 = v9any_s1
// fine-tuned on dataset_v11 (+ the 10-22 23:50 video's hard negatives: hands /
// arms / bottle / coat sleeves / black curtain, board blue boxes inpainted out).
// User 10-23: "胳膊甚至杯子都会框".  With CONFIRM 4 below, on held-out stretches
// of that video: frames showing a false person box 46% -> 9% (bottle 44/53 -> 0,
// coat 34/37 -> 0, curtain 93/218 -> 0); a HAND right at the lens is NOT fixed
// (51/68 -> 44/68).  10-22 22:01 video (real person, untrained): IoU>=0.5 near
// 58 -> 56%, mid 65 -> 64%, far 19 -> 22%; empty-frame false 15 -> 3 of 473.
// dataset test 70.1 -> 64.7% (B03 light clothes seated 5 m 334 -> 116 of 338),
// val 75.5 -> 79.7%.  Previous (10-21): v9any_s1, threshold 1104 (*.pre_v11).
// 10-21 notes on v9any_s1, threshold 1104 (val only;
// seed by val recall).  v9 = v8 + the 10-21 board video's raw-mode half (light
// clothes, 5-6 m, stand/squat/bend).  dataset_v8 test IoU>=0.5 62% -> 75%,
// B03 light clothes seated 5 m 60 -> 334 of 338 frames; LOST: B06 half body
// behind the podium (50 -> 9) and E13 dark clothes at the door (18 -> 1).
// Previous (10-20): v8c2_s3, threshold 1155 (files *.pre_v9).
// 10-20 notes on v8c2_s3:  Fixes all-light clothing (B03/B04
// 0% -> 100%) and the old weights' constant box at the back door on empty
// frames; people >= ~6 m (box < ~0.35 frame height) are still mostly missed.
// Previous: v3_20261013/models/stem4_new_near025, threshold 1158.  Retrain = replace
// uisrc/03_ip/grid_det/packed_*.hex AND THRESHOLD_Q8 below together
// (tools/grid_det/export_rtl_v3.py writes both into rtl_export.json).
//
// GRID_DET = 0 removes it (gdo_* = qdo_*, gd_* = 0).
//---------------------------------------------------------------------------
localparam integer GRID_DET = 1;
// 10-21: grid_post (in grid_det.v) between grid_det and the blue overlay:
// grow each person box up/down over cells with score >= LOW_Q8, merge boxes
// stacked on one body, then a 4-slot IIR tracker (CONFIRM 2 / HOLD 4 pubs at
// 15 Hz) -- the 10-20 board recording's "boxes broken up and jumpy".  Replayed
// offline: >1 box on one person 41% -> 3% of frames, edge jitter 41 -> 18 px,
// top/bottom edges +113/-108 px -> 0/-6 px vs YOLOX, empty-room boxes unchanged.
// gd_* / gd_person are the post-processed boxes.  0 = the 10-20 wiring exactly.
localparam integer GRID_POST = 1;
// 10-23: ToF occlusion gate after grid_post (g_tofgate below).  0 = the
// 10-23 morning wiring exactly.
localparam integer SEC_TOF_GATE = 1;
wire [47:0] gd_x0, gd_y0, gd_x1, gd_y1;   // 4 x 12 bit, x1/y1 exclusive
wire [7:0]  gd_cls;                       // 4 x 2 bit: 1 person, 2 animal
wire [3:0]  gd_valid;
wire        gd_bg_busy;                   // 10-30: outside g_grid -- text_osd reads it
wire        gd_pub;//synthesis keep
wire        gd_person;//synthesis keep    // a person box is up (held between pubs)
wire [95:0] gd_tof_txt;                   // 10-23: gd_tof_gate debug -> security page TOF: row
wire        gdo_out_vs;//synthesis keep
wire        gdo_out_de;//synthesis keep
wire [23:0] gdo_out_rgb;//synthesis keep

genvar gd_i;
generate if (GRID_DET != 0) begin : g_grid
wire [47:0] gd_x1i, gd_y1i;
wire [47:0] gdr_x0, gdr_y0, gdr_x1, gdr_y1;   // raw grid_det boxes
wire [7:0]  gdr_cls;
wire [3:0]  gdr_valid;
wire [3:0]  gdp_valid;                        // grid_post boxes before the ToF gate
wire        gdr_pub;
wire [239:0] gdr_low;                         // cells: argmax person, score >= LOW_Q8
for (gd_i = 0; gd_i < 4; gd_i = gd_i + 1) begin : g_gdi
    assign gd_x1i[gd_i*12 +: 12] = gd_x1[gd_i*12 +: 12] - 12'd1;
    assign gd_y1i[gd_i*12 +: 12] = gd_y1[gd_i*12 +: 12] - 12'd1;
end
assign gd_person = (gd_valid[0] && gd_cls[1:0] == 2'd1) || (gd_valid[1] && gd_cls[3:2] == 2'd1) ||
                   (gd_valid[2] && gd_cls[5:4] == 2'd1) || (gd_valid[3] && gd_cls[7:6] == 2'd1);

//---------------------------------------------------------------------------
// ⭐ 10-30: background learning for grid_det (see its header).  gd_bg_req (key2
// held 1 s in 安防) -> GD_BG_WAIT_MS for the person who pressed to walk out of
// shot -> GD_BG_LEARN_MS with bg_learn high (every frame grid_det accepts in
// that window is learnt; ~15 Hz, so ~75 frames) -> done.  The 轮廓数 row reads
// 学习中 for the whole 8 s.  Leaving 安防 aborts (what was learnt stays).
// The floors are lost at power-off -- re-learn after moving the camera.
//---------------------------------------------------------------------------
localparam integer GD_BG_WAIT_MS  = 3000;
localparam integer GD_BG_LEARN_MS = 5000;
localparam integer GD_MS_CLK      = 150_000;
reg  [15:0] gdb_ms  = 16'd0;
reg  [17:0] gdb_div = 18'd0;
reg  [1:0]  gdb_st  = 2'd0;             // 0 idle, 1 wait, 2 learn
wire        gd_bg_learn = (gdb_st == 2'd2);
assign      gd_bg_busy  = (gdb_st != 2'd0);
wire [7:0]  gd_bg_cells;//synthesis keep
always @(posedge pclkx1 or negedge fifowait[7]) begin
    if (!fifowait[7]) begin
        gdb_st <= 2'd0; gdb_ms <= 16'd0; gdb_div <= 18'd0;
    end else if (GD_BG_LEARN == 0 || !sec_mode) begin
        gdb_st <= 2'd0; gdb_ms <= 16'd0; gdb_div <= 18'd0;
    end else if (gd_bg_req) begin
        gdb_st <= 2'd1; gdb_ms <= GD_BG_WAIT_MS - 1; gdb_div <= 18'd0;
    end else if (gdb_st != 2'd0) begin
        if (gdb_div == GD_MS_CLK - 1) begin
            gdb_div <= 18'd0;
            if (gdb_ms != 16'd0) gdb_ms <= gdb_ms - 16'd1;
            else if (gdb_st == 2'd1) begin gdb_st <= 2'd2; gdb_ms <= GD_BG_LEARN_MS - 1; end
            else gdb_st <= 2'd0;
        end else gdb_div <= gdb_div + 18'd1;
    end
end

grid_det #(
.THRESHOLD_Q8 ( 32'sd1066 ),
.LOW_Q8       ( 32'sd700  ),
.BG_LEARN     ( GD_BG_LEARN ),   // 10-30
.BG_M         ( 32'sd150  ),
.BG_CAP       ( 32'sd600  )
) u_grid_det (
.clk             ( pclkx1      ),
.rst_n           ( fifowait[7] ),
.en              ( 1'b1        ),   // always computing: no stale boxes on entering security mode
.in_vs           ( cr_out_vs   ),
.in_de           ( cr_out_de   ),
.in_rgb          ( cr_out_rgb  ),
.obj_x0          ( gdr_x0      ),
.obj_y0          ( gdr_y0      ),
.obj_x1          ( gdr_x1      ),
.obj_y1          ( gdr_y1      ),
.obj_cls         ( gdr_cls     ),
.obj_score       (             ),
.obj_valid       ( gdr_valid   ),
.obj_low         ( gdr_low     ),
.pub             ( gdr_pub     ),
.bg_learn        ( gd_bg_learn ),   // 10-30
.bg_cells        ( gd_bg_cells ),
.busy            (             ),
.result_frame_id (             ),
.cycles_last     (             )
);

if (GRID_POST != 0) begin : g_gpost
grid_post #(
.GAP_Y   ( 1 ),
// 10-22: 2/3 -> 1/2, box follows a walker ~0.2 s sooner (video: lag 3 -> 0
// publishes, mid-range IoU>=0.5 61.6 -> 64.2%; far 25.7 -> 21.6%, empty 12 -> 15/473).
.SC      ( 1 ),
.SS      ( 2 ),
.HOLD    ( 4 ),
// 10-23: 2 -> 4 (~0.27 s at 15 Hz before a box shows).  Hard-negative video,
// held-out stretches: false-box frames 20% -> 9% (bottle 27/53 -> 0, coat
// 21/37 -> 0); real-person IoU unchanged, misses near 12 -> 16%, mid 23 -> 28%.
.CONFIRM ( 4 ),
// 10-22: near-range people (cut by the frame) broke into 2-3 side-by-side
// strips; merge those too (grid_post header: near split 11% -> 1%, but two
// people standing shoulder to shoulder become one box).  GAP_X = -1 = 10-21.
.GAP_X   ( 1 ),
.MG_OV   ( 2 )
) u_grid_post (
.clk     ( pclkx1      ),
.rst_n   ( fifowait[7] ),
.pub     ( gdr_pub     ),
.in_x0   ( gdr_x0      ),
.in_y0   ( gdr_y0      ),
.in_x1   ( gdr_x1      ),
.in_y1   ( gdr_y1      ),
.in_cls  ( gdr_cls     ),
.in_vld  ( gdr_valid   ),
.in_low  ( gdr_low     ),
.out_x0  ( gd_x0       ),
.out_y0  ( gd_y0       ),
.out_x1  ( gd_x1       ),
.out_y1  ( gd_y1       ),
.out_cls ( gd_cls      ),
.out_vld ( gdp_valid   ),
.out_pub ( gd_pub      )
);
// 10-23: ToF occlusion gate (gd_tof_gate, grid_det.v; rules in its header).
// The ranger reads something nearer than NEAR_MM -> the person boxes go, so
// the blue overlay, gd_person and gd_aim (the spot) drop together, switched
// only on gd_pub.  Board 17:04 video: blue boxes on 54% (hand) / 63% (sleeve)
// / 57% (bottle) of frames; the cone (27 deg, the 16 x 16 ROI every mode but
// BOX uses) meets ~85% of those boxes.  Cost: no blue box on a person within
// NEAR_MM (the red face box is not touched).  Near for MAX_MS on end (a fixed
// obstacle in the cone) -> lets go; no readings at all -> lets go.
if (SEC_TOF_GATE != 0) begin : g_tofgate
gd_tof_gate #(
.CLK_HZ   ( 150000000 ),
.NEAR_MM  ( 800       ),
.HOLD_MS  ( 600       ),   // > grid_post HOLD 4 pubs (0.27 s) + one ranging period
.MAX_MS   ( 10000     )
) u_gd_tof_gate (
.clk      ( pclkx1      ),
.rst_n    ( fifowait[7] ),
.en       ( sec_mode    ),
.tof_stb  ( tof_stb     ),
.tof_mm   ( tof_dist    ),
.tof_code ( tof_code    ),
.pub      ( gd_pub      ),
.in_vld   ( gdp_valid   ),
.out_vld  ( gd_valid    ),
.blk      (             ),
.dbg_txt  ( gd_tof_txt  )
);
end else begin : g_notofgate
assign gd_valid = gdp_valid;
assign gd_tof_txt = {12{8'h20}};
end
end else begin : g_graw
assign gd_x0 = gdr_x0; assign gd_y0 = gdr_y0; assign gd_x1 = gdr_x1; assign gd_y1 = gdr_y1;
assign gd_cls = gdr_cls; assign gd_valid = gdr_valid; assign gd_pub = gdr_pub;
end

// 10-22: one person box for the head (SEC_AIM_GD / SEC_SPOT_GD above).
// gd_aim lives in grid_det.v, so the TD file list does not change.
gd_aim u_gd_aim (
.clk     ( pclkx1      ),
.rst_n   ( fifowait[7] ),
.in_pub  ( gd_pub      ),
.in_x0   ( gd_x0       ),
.in_y0   ( gd_y0       ),
.in_x1   ( gd_x1       ),
.in_y1   ( gd_y1       ),
.in_cls  ( gd_cls      ),
.in_vld  ( gd_valid    ),
.aim_x   ( ga_x        ),
.aim_y   ( ga_y        ),
.aim_v   ( ga_v        ),
.aim_pub (             )
);

det_overlay#(
.NBLOB     ( 4           ),
.BOX_RGB   ( 24'h3080FF  ),
.BOX_THICK ( 3           ),
.VB_GUARD  ( 512         ),
.VS_LATCH  ( 0           )
)u_grid_overlay(
.clk        ( pclkx1      ),
.rst_n      ( fifowait[7] ),
.en         ( sec_mode    ),

.blob_x0    ( gd_x0       ),
.blob_x1    ( gd_x1i      ),
.blob_y0    ( gd_y0       ),
.blob_y1    ( gd_y1i      ),
.blob_valid ( gd_valid    ),

.in_vs      ( sto_out_vs  ),   // 10-27: was qdo_out_*, stain_overlay in between
.in_de      ( sto_out_de  ),
.in_rgb     ( sto_out_rgb ),

.out_vs     ( gdo_out_vs  ),
.out_de     ( gdo_out_de  ),
.out_rgb    ( gdo_out_rgb )
);
end else begin : g_nogrid
assign gd_bg_busy = 1'b0;   // 10-30
assign gd_x0 = 48'd0; assign gd_y0 = 48'd0; assign gd_x1 = 48'd0; assign gd_y1 = 48'd0;
assign gd_cls = 8'd0; assign gd_valid = 4'd0; assign gd_pub = 1'b0; assign gd_person = 1'b0;
assign gd_tof_txt = {12{8'h20}};
assign ga_x = 12'd960; assign ga_y = 12'd540; assign ga_v = 1'b0;
assign gdo_out_vs  = sto_out_vs;
assign gdo_out_de  = sto_out_de;
assign gdo_out_rgb = sto_out_rgb;
end endgenerate

//===========================================================================
// FACE DETECTION (2026-09-18).  Four new modules plus two reused ones, all of
// it a SIDE BRANCH -- nothing below is in the display path except the red
// overlay, which is another instance of the det_overlay already on it.
//
//   af_out_* --> face_skin --> det_morph_open --> ccl_blob --> skin boxes
//                                                                  |
//   af_out_* --> face_roi_buf <-- motion boxes <--------------------+
//                    |  32x32 grayscale patches, double-banked
//                    v
//               face_cascade  (OpenCV LBP, bit-exact -- fctb, 168 checks)
//                    |
//               face_detect --> red boxes --> face_overlay --> text_osd
//
// WHY THE SKIN CHAIN GETS ITS OWN ccl_blob AND det_morph_open
// The L5 chain's pair is busy with the luma mask, and the two masks mean
// different things -- a skin pixel is not a foreground pixel.  Sharing would
// need the labeller time-multiplexed across two masks inside one frame, which
// is a new scheduling problem bought with 11 ERAMs.  Two instances is the same
// trade this project already made inside det_morph_open, where erode and
// dilate are two copies of det_bin3x3 rather than one reused twice.
//
// RESOURCE NOTE.  This is the largest single addition the project has made.
// The second ccl_blob is the big item -- section 4.2's measured table puts one
// at 11 ERAM + 1024 dram LUT -- plus 4 ERAM for the patches and about 4 for the
// cascade ROMs.  Against 366 free that is comfortable, but CHECK THE ERAM COUNT
// IN THE SYNTHESIS LOG BEFORE BURNING, and expect the P&R seed to want
// re-drawing: new modules always do.
//===========================================================================

wire        fsk_vs, fsk_de, fsk_bin;

face_skin#(
.SKIN_REL    ( FACE_SKIN_REL ),
.SKIN_YSCALE ( FACE_SKIN_YSC ),
.SKIN_HAVG   ( FACE_SKIN_HAVG ),
.REL_CR_D    ( FACE_SKIN_CR_D )
)u_face_skin(
.clk     ( pclkx1      ),
.rst_n   ( fifowait[7] ),

// Same tap as det_binarize: after the affine stage, before the effect wheel.
// So the skin decision sees the picture geometry the boxes get drawn in, and
// does NOT see a false-colour wheel position.
.in_vs   ( af_out_vs   ),
.in_de   ( af_out_de   ),
.in_r    ( af_out_r    ),
.in_g    ( af_out_g    ),
.in_b    ( af_out_b    ),

.out_vs  ( fsk_vs      ),
.out_de  ( fsk_de      ),
.out_bin ( fsk_bin     )
);

wire        fmop_vs, fmop_de, fmop_bin;
wire [11:0] fmop_px, fmop_py;

// Opening on the skin mask, for the reason it went on the luma mask in section
// 3.-3: single-pixel chroma specks are common -- demosaic fringes on any sharp
// edge land inside the skin box often enough -- and each one costs a label, a
// merge-table entry and a blob slot that the real face then has to outrank.
det_morph_open#(
.IMG_HDISP ( 1920 ),
.IMG_VDISP ( 1080 )
)u_face_morph(
.clk     ( pclkx1      ),
.rst_n   ( fifowait[7] ),
.in_vs   ( fsk_vs      ),
.in_de   ( fsk_de      ),
.in_bin  ( fsk_bin     ),
.out_vs  ( fmop_vs     ),
.out_de  ( fmop_de     ),
.out_bin ( fmop_bin    ),
.out_px  ( fmop_px     ),
.out_py  ( fmop_py     )
);

wire [FACE_NSKIN*12-1:0] skin_x0, skin_x1, skin_y0, skin_y1;
wire [FACE_NSKIN-1:0]    skin_valid;
wire [7:0] skin_count;//synthesis keep

ccl_blob#(
.IMG_HDISP  ( 1920       ),
.IMG_VDISP  ( 1080       ),
.LBW        ( 11         ),
.NBLOB      ( FACE_NSKIN ),
.MERGE_N    ( 1024       ),
.MIDX       ( 10         ),

// MIN_AREA is a quarter of the luma chain's 2048.  A face at the far side of a
// room is a few thousand skin pixels, and at 2048 it would have to be 45px
// across before it registered at all -- which would throw away exactly the
// detections the chroma chain exists to make.  The opening above is what keeps
// the speck count down instead of a high area floor.
.MIN_AREA   ( 512        ),

// A skin-coloured region covering most of the frame is a wall painted the
// wrong colour or a lampshade, not a face.  Tighter than the luma chain's 7/8
// for that reason.
// 10-03: 800 -> 1080 with FACE_SKIN_REL.  On the 11:31 recording a face at
// 0.5 m makes a face+neck blob 816..1053 tall (fill 0.6) and was dropped here
// -- the last no-ROI misses.  Held-out: hit 76% -> 84%, no-face false boxes
// unchanged (0 and 5).  roi_buf's AR_SHIFT (long <= 2x short) and MAX_W still
// reject a frame-tall wall strip.
.MAX_W      ( 1200       ),
.MAX_H      ( FACE_SKIN_REL ? 1080 : 800 ),

.FILL_SHIFT ( 2          ),
.MAX_ROUNDS ( 5          ),
.OVF_TRIM   ( 0          ),
.STALE_HOLD ( 2          ),
.DUP_DEPTH  ( 2          ),
.VB_GUARD   ( 512        ),
.VS_EDGES   ( 0          ),

// ⭐ 09-19 night, section 3.-14: 0 -> 48.  The sentence this replaces said
// "if single faces do arrive as two blobs, face_roi_buf's dedup already
// collapses them into one ROI", and that was simply WRONG about what dedup
// does.  Dedup DISCARDS the second blob -- it does not union the two.  So a
// face cut in half by brows, glasses or a specular highlight enrols at the
// size of its LARGEST FRAGMENT, and since ccl_blob hands blobs over sorted by
// area, the fragment that wins is a cheek.
//
// That is the board photograph of a red box sitting on one eye: box width 205
// against a face 560 wide.  Work it backwards -- the drawn box is 0.75 x side
// and side is 1.5 x the candidate, so the candidate was 182px.  A third of the
// face, classified at a third of the right scale.
//
// The old comment's worry is real and is the reason this is 48 and not the
// luma chain's 64: a gap merge will fuse two people standing shoulder to
// shoulder into one box.  48px at 1920 wide is under a head's width, so two
// faces have to be nearly touching before it happens, and one box on two
// touching faces is a better failure than one box on a cheek.
//
// ⚠️ If the board starts showing ONE box spanning TWO people, this is the
// parameter -- lower it or put it back to 0.  It is not an NMS problem and it
// is not a threshold problem.
.BOX_GAP    ( 48         ),
.BOX_ROUNDS ( 2          ),

// 10-05: on the board recording the skin mask's merge list overflowed on 82%
// of face frames (median 3,945 pushes of 366 distinct pairs, row-periodic
// repeats the depth-2 filter cannot see), and the pass A shortcut writes do
// not converge once the list is deduplicated.  See SEEN_LOG2 / PA_HOOK in
// ccl_blob.v.  FACE_CCL_SEEN = 0 = the 10-04 build exactly (fcceqtb).
.SEEN_LOG2  ( FACE_CCL_SEEN ? 8 : 0 ),
.PA_HOOK    ( FACE_CCL_SEEN ? 1 : 0 )
)u_face_ccl(
.clk           ( pclkx1      ),
.rst_n         ( fifowait[7] ),
.in_vs         ( fmop_vs     ),
.in_de         ( fmop_de     ),
.in_bin        ( fmop_bin    ),
.in_px         ( fmop_px     ),
.in_py         ( fmop_py     ),
.blob_x0       ( skin_x0     ),
.blob_x1       ( skin_x1     ),
.blob_y0       ( skin_y0     ),
.blob_y1       ( skin_y1     ),
.blob_valid    ( skin_valid  ),
.blob_count    ( skin_count  ),
.ovf_label     (             ),
.ovf_merge     (             ),
.ovf_time      (             ),
.dbg_label_max (             ),
.dbg_merge_cnt (             ),
.dbg_rounds    (             ),
.dbg_reject    (             ),
.in_mask       ( 1'b0          )    // 10-09: MASK_EN is 0 here
);

//---------------------------------------------------------------------------
// The patch buffer, the classifier and the sequencer.
//---------------------------------------------------------------------------
wire [11:0] fc_buf_ra;
wire [7:0]  fc_buf_q;
wire        fc_start, fc_busy, fc_done, fc_found;
wire [1:0]  fc_roi;
wire [5:0]  fc_ox, fc_oy;
wire [5:0]  fc_w;                   // box side in patch pixels (face_cnn's box head)
wire [3:0]  fc_nacc;
wire        frb_rd_busy;

wire [FACE_NROI*12-1:0] froi_x0, froi_y0;
wire [FACE_NROI*12-1:0] froi_side;
wire [FACE_NROI-1:0]    froi_valid;
wire        froi_ready;
wire [3:0]  froi_n;//synthesis keep
wire        froi_held;//synthesis keep
wire [3:0]  froi_rej;//synthesis keep
wire        froi_flat;//synthesis keep

face_roi_buf#(
.IMG_HDISP ( 1920       ),
.IMG_VDISP ( 1080       ),
.BUFN      ( FACE_BUFN  ),
.NROI      ( FACE_NROI  ),
.NSKIN     ( FACE_NSKIN ),
.BLK_W     ( 128        ),
.BLK_H     ( 72         ),
// SIDE_MAX is the frame HEIGHT, not the width: the ROI is square, so the
// shorter axis is what bounds it.  The largest detectable face is therefore
// WIN/BUFN x 1080 = 810 px wide -- continuous now, where the power-of-two
// version could only reach 768 and 384 and nothing between them.
.SIDE_MIN  ( 32         ),
.SIDE_MAX  ( FACE_ROI2 ? 1072 : 1080 ),   // 1080 - Y_TOP: a ROI must fit below the guard
.Y_TOP     ( FACE_ROI2 ? 8 : 0 ),
.RANK_TOP  ( FACE_ROI2 ),
.NSCALE    ( 2          ),
.MIN_SIDE  ( 24         ),

// 09-19 night, section 3.-14.  Four geometry rejects that answer the shaken-
// camera false box; the parameter block in face_roi_buf.v has the measurements
// each number came from and says which of them catches which photograph.
// Listed here rather than left defaulted because these are the knobs the next
// board session will want to move, and a default is not discoverable.
.MAX_SIDE     ( FACE_SKIN_REL ? 1080 : 720 ),   // skin candidate long edge, px
.MB_MAX_SIDE  ( 400 ),   // motion candidate long edge -- 0 disables motion ROIs
.AR_SHIFT     ( FACE_ROI2 ? 2 : 1 ),   // long <= 2 x short (FACE_ROI2: 4 x)
.MIN_CONTRAST ( 24  ),   // patch max-min floor, out of 255

.VB_GUARD  ( 512        ),

// 10-02 evening: with the CNN, rung 1 frames the TOP SQUARE of the skin blob at
// 1.5x its short edge (the face), rung 2 keeps the old 1.5x-long-edge framing.
// See FRAME_MODE in face_roi_buf.v.  The cascade keeps the geometry it was
// tuned on.
.FRAME_MODE ( FACE_CLS   ),
.PB_HEAD    ( FACE_PB_HEAD ),
.PB_MIN_W   ( 64         )
)u_face_roi_buf(
.clk        ( pclkx1      ),
.rst_n      ( fifowait[7] ),

// Luma from the same tap as the skin mask, so the patch and the box that framed
// it describe the same picture.
.in_vs      ( af_out_vs   ),
.in_de      ( af_out_de   ),
.in_r       ( af_out_r    ),
.in_g       ( af_out_g    ),
.in_b       ( af_out_b    ),

.skin_x0    ( skin_x0     ),
.skin_x1    ( skin_x1     ),
.skin_y0    ( skin_y0     ),
.skin_y1    ( skin_y1     ),
.skin_valid ( skin_valid  ),

.mb_x0      ( md_box_x0    ),
.mb_x1      ( md_box_x1    ),
.mb_y0      ( md_box_y0    ),
.mb_y1      ( md_box_y1    ),
.mb_valid   ( md_box_valid ),

// 10-30 PB_HEAD: person boxes only (cls 1), security mode only.
.pb_x0      ( gd_x0       ),
.pb_y0      ( gd_y0       ),
.pb_x1      ( gd_x1       ),
.pb_valid   ( sec_mode ? {gd_valid[3] && (gd_cls[7:6] == 2'd1), gd_valid[2] && (gd_cls[5:4] == 2'd1),
                          gd_valid[1] && (gd_cls[3:2] == 2'd1), gd_valid[0] && (gd_cls[1:0] == 2'd1)} : 4'd0 ),

.rd_addr    ( fc_buf_ra   ),
.rd_data    ( fc_buf_q    ),
.rd_busy    ( frb_rd_busy ),

.roi_x0     ( froi_x0     ),
.roi_y0     ( froi_y0     ),
.roi_side   ( froi_side   ),
.roi_valid  ( froi_valid  ),
.roi_ready  ( froi_ready  ),
.dbg_nroi   ( froi_n      ),
.dbg_swap_held ( froi_held ),
.dbg_nrej   ( froi_rej    ),
.dbg_flat   ( froi_flat   )
);

wire signed [31:0] fc_score;//synthesis keep

generate if (FACE_CLS == 0) begin : g_face_lbp

assign fc_score = 32'sd0;
assign fc_w     = FACE_WIN[5:0];

face_cascade#(
.BUFN   ( FACE_BUFN ),
.WIN    ( FACE_WIN  ),
.STEP   ( FACE_STEP ),
.NSTAGE ( 20        ),
.NWEAK  ( 139       ),
.NRECT  ( 136       )
)u_face_cascade(
.clk        ( pclkx1      ),
.rst_n      ( fifowait[7] ),
.buf_ra     ( fc_buf_ra   ),
.buf_q      ( fc_buf_q    ),
.start      ( fc_start    ),
.roi_sel    ( fc_roi      ),
.busy       ( fc_busy     ),
.done       ( fc_done     ),
.face_found ( fc_found    ),
.face_ox    ( fc_ox       ),
.face_oy    ( fc_oy       ),
.face_nacc  ( fc_nacc     ),
.win_done   (             ),
.win_accept (             ),
.win_stages (             ),
.win_code   (             )
);

end else begin : g_face_cnn

// Reports the centred WIN window of the ROI as the box (face_ox = face_oy =
// (BUFN-WIN)/2), i.e. what the cascade drew at its middle slide position, and
// nacc = 1 on accept so MIN_NEIGHBORS = 1 passes it.  ~101k clocks per ROI
// (fcnntb), so four ROIs are ~16% of a frame; face_detect holds the bank swap
// while it runs, there is no deadline.  ⚠ This and its five cnn_*.hex must stay
// together in uisrc/03_ip/face/.
face_cnn#(
.BUFN   ( FACE_BUFN ),
.WIN    ( FACE_WIN  ),
.THR    ( FACE_THR  )    // see FACE_THR
)u_face_cnn(
.clk        ( pclkx1      ),
.rst_n      ( fifowait[7] ),
.buf_ra     ( fc_buf_ra   ),
.buf_q      ( fc_buf_q    ),
.start      ( fc_start    ),
.roi_sel    ( fc_roi      ),
.busy       ( fc_busy     ),
.done       ( fc_done     ),
.face_found ( fc_found    ),
.face_ox    ( fc_ox       ),
.face_oy    ( fc_oy       ),
.face_w     ( fc_w        ),
.face_nacc  ( fc_nacc     ),
.score      ( fc_score    )
);

end endgenerate

wire [FACE_NROI*12-1:0] face_x0, face_x1, face_y0, face_y1;
wire [FACE_NROI-1:0]    face_vld;
wire       face_pub;
wire [7:0] face_count;//synthesis keep
wire [3:0] face_hits;//synthesis keep
wire [3:0] face_nacc;//synthesis keep

face_detect#(
.NROI        ( FACE_NROI ),
.BUFN        ( FACE_BUFN ),
.WIN         ( FACE_WIN  ),
.STEP        ( FACE_STEP ),
.HOLD_FRAMES ( 6'd16     ),

// 1 = no cut, and that is measured rather than lazy: this cascade accepts a
// true face at only one to three of 81 slide positions, so a threshold of 2
// would reject half the real faces.  The vote machinery and its OSD readout
// are kept as instrumentation.  Full numbers in the parameter's header in
// face_detect.v -- read them before raising this.
.MIN_NEIGHBORS ( 4'd1    ),

// 10-02 evening, CNN only (all 0 = the cascade-era behaviour):
//   VAR_W      draw the CNN's regressed box, not the fixed 24/32 window
//   NMS_SCORE  overlapping boxes -> keep the higher confidence (the "ear gets
//              its own box" report: a second ROI's box overlapped the face's
//              without being concentric with it, so the old rule kept both)
//   CLIP_*     clamp the far edge to the frame (a regressed box can run off it)
.VAR_W       ( FACE_CLS                     ),
.NMS_SCORE   ( FACE_CLS                     ),
.CLIP_W      ( (FACE_CLS != 0) ? 1920 : 0   ),
.CLIP_H      ( (FACE_CLS != 0) ? 1080 : 0   ),
.CONFIRM     ( (FACE_CLS != 0) ? FACE_CONFIRM : 1 )
)u_face_detect(
.clk        ( pclkx1      ),
.rst_n      ( fifowait[7] ),

// Gated by the overlay selector, so a position that draws nothing also costs
// nothing.  face_detect clears its boxes when disabled rather than freezing
// them, so re-enabling cannot flash a stale frame.
.en         ( face_run    ),

.roi_x0     ( froi_x0     ),
.roi_y0     ( froi_y0     ),
.roi_side   ( froi_side   ),
.roi_valid  ( froi_valid  ),
.roi_ready  ( froi_ready  ),

.cas_start  ( fc_start    ),
.cas_roi    ( fc_roi      ),
.cas_busy   ( fc_busy     ),
.cas_done   ( fc_done     ),
.cas_found  ( fc_found    ),
.cas_ox     ( fc_ox       ),
.cas_oy     ( fc_oy       ),
.cas_nacc   ( fc_nacc     ),
.cas_w      ( fc_w        ),

.rd_busy    ( frb_rd_busy ),

.face_x0    ( face_x0     ),
.face_x1    ( face_x1     ),
.face_y0    ( face_y0     ),
.face_y1    ( face_y1     ),
.face_vld   ( face_vld    ),
.face_count ( face_count  ),
.pub        ( face_pub    ),
.dbg_hits   ( face_hits   ),
.dbg_nacc   ( face_nacc   )
);

// 2026-10-05 evening: is the magenta target a person?  See face_assoc.v.
// Raw (unsmoothed) boxes: smoothing is for drawing, not for deciding.
face_assoc #(
.NROI        ( FACE_NROI ),
// 10-06: ~1 s at ~58 fps.  The face box drops out for a few frames at a
// time on the board; without this the spot strobed (see face_assoc.v).
.PERSON_HOLD ( 8'd60     )
) u_face_assoc (
.clk     ( pclkx1        ),
.rst_n   ( fifowait[7]   ),
.vs      ( cr_out_vs     ),
.en      ( sec_mode      ),
// 10-05 night: 0 = ANY face counts.  The board showed the hand waving a
// face-width or two beside the head: the magenta box sits on the hand and
// the grown-box test missed the face, so the spot lit the hand.  False faces
// are rare since FACE_CONFIRM, so "face visible while something moves" is
// the better rule.  1 = the association geometry (face_assoc.v / fatb).
.use_box ( 1'b0          ),
.box_v   ( md_trk_v      ),
.bx0     ( md_trk_x0     ),
.bx1     ( md_trk_x1     ),
.by0     ( md_trk_y0     ),
.by1     ( md_trk_y1     ),
.fx0     ( face_x0       ),
.fx1     ( face_x1       ),
.fy0     ( face_y0       ),
.fy1     ( face_y1       ),
.f_vld   ( face_vld      ),
.person  ( fa_person     ),
.fx      ( fa_x          ),
.fy      ( fa_y          )
);

//---------------------------------------------------------------------------
// 2026-10-12: staff verification, on board.  tools/staff_id/ is the whole
// story (the script headers there); in one line each:
//   staff_cap   the widest face_detect box -> a 64x64 area-averaged gray patch
//               of the square s + s/16 around it (raw boxes, not face_smooth's:
//               smoothing is for drawing)
//   staff_cnn   patch -> cos^2 to the staff template (Q12) + eyes-closed /
//               mouth-open logits; ~1.84 M clocks = 12 ms, one per frame
//   staff_ctrl  recognised 8 times -> random challenge (voice clip 7 open the
//               mouth / clip 8 blink, glasses off) -> PASS (clip 6, alarm off)
// Same picture tap as face_roi_buf (af_out_*), so the patch and the face box
// describe the same frame geometry.  Runs in SECURITY and FACE (face_run).
// The ROMs (staff_*.hex) and the thresholds below come from one training run,
// tools/staff_id/export_hex.py q_g16j: retrain = replace the hex files AND
// paste the LTHR_* it prints.
//---------------------------------------------------------------------------
wire [11:0] sc_ra;
wire [7:0]  sc_q;
wire        sc_ready, scn_busy, scn_done;
wire [11:0] sc_px0, sc_py0, sc_side;//synthesis keep
wire        sc_held;//synthesis keep
wire [12:0] scn_score;//synthesis keep
wire signed [31:0] scn_live0, scn_live1;//synthesis keep
wire [7:0]  st_cos_bcd;
wire        st_cos_v;
wire [2:0]  st_state;//synthesis keep

staff_cap #(
.IMG_HDISP ( 1920      ),
.IMG_VDISP ( 1080      ),
.NROI      ( FACE_NROI ),
.Y_TOP     ( 8         ),
.SIDE_MAX  ( 1072      ),
// ⭐ 10-27 (17:12 video): in a challenge, bridge face_detect drop-outs with the
// last square, up to 4 s (240 frames).  [board-tune] 0 = no hold.
.HOLD_FR   ( 240       )
) u_staff_cap (
.clk         ( pclkx1      ),
.rst_n       ( fifowait[7] ),
.hold_en     ( st_state == 3'd1 || st_state == 3'd2 ),   // mouth / blink challenge
.in_vs       ( af_out_vs   ),
.in_de       ( af_out_de   ),
.in_r        ( af_out_r    ),
.in_g        ( af_out_g    ),
.in_b        ( af_out_b    ),
.box_x0      ( face_x0     ),
.box_x1      ( face_x1     ),
.box_y0      ( face_y0     ),
.box_y1      ( face_y1     ),
.box_vld     ( face_run ? face_vld : {FACE_NROI{1'b0}} ),
.rd_addr     ( sc_ra       ),
.rd_data     ( sc_q        ),
.rd_busy     ( scn_busy    ),
.patch_ready ( sc_ready    ),
.patch_x0    ( sc_px0      ),
.patch_y0    ( sc_py0      ),
.patch_side  ( sc_side     ),
.dbg_held    ( sc_held     )
);

staff_cnn #(
.SV ( 5 )
) u_staff_cnn (
.clk    ( pclkx1      ),
.rst_n  ( fifowait[7] ),
.buf_ra ( sc_ra       ),
.buf_q  ( sc_q        ),
.start  ( sc_ready    ),
.busy   ( scn_busy    ),
.done   ( scn_done    ),
.score  ( scn_score   ),
.live0  ( scn_live0   ),
.live1  ( scn_live1   )
);

staff_ctrl #(
.TICK_CLKS  ( 15_000_000   ),       // 0.1 s
.THR_REC    ( 13'd2622     ),       // cos 0.80 -- [board-tune] never below 2008 (0.70)
.THR_LIVE   ( 13'd1024     ),       // 10-27: cos 0.60 -> 0.50 (board 0.50-0.66 on an open mouth; the teammate already reaches 0.65)
.LTHR_EYE   ( 32'sd54470   ),       // q_g16j/q_live.npz lthr[0]
.LTHR_MOUTH ( 32'sd5290    ),       // q_g16j/q_live.npz lthr[1]
// 10-12 night (user): 3 opens / 2 blinks, each re-armed by OPEN_N consecutive
// closed results; the counts are spoken in clips 7 / 8 (make_voice_rom.py) --
// change both together.  "身份核验未通过" (clip 9) on a failed challenge and
// on an unrecognised face, at most once per FAIL_GAP (10 s).
.MOUTH_EV   ( 3            ),
.BLINK_EV   ( 2            ),
.OPEN_N     ( 8            ),       // 0.13 s at 60 results/s
// ⭐ 10-27: mouth only.  17:12 video offline (staff_q golden, YuNet boxes): the
// mouth logit clears LTHR_MOUTH on every open (+70k..+138k vs 5.3k); the eye
// logit cleared LTHR_EYE twice in the whole 9 s blink challenge, and the
// "take your glasses off" in clip 8 is what lost the face.  [board-tune] 0 = random.
.CH_MODE    ( 1            ),
// 10-27: a THR_LIVE result keeps the face in a challenge; the alarm waits 5 s
// after "未通过" is issued (clip 9 1.57 s + ~3.4 s of silence).  0 / 0 = 10-24.
.LOST_LIVE  ( 1            ),
.FAIL_QUIET ( 50           ),
// ⭐ 10-28 (user, 20:35 video: the teammate got "未通过" every ~11 s with the spot
// on and no "请走近"): every face is verified first -- spot dark + clip 10; not
// recognised 4 s after clip 10 -> "未通过" ONCE, then the alarm; again only
// after 5 s without any result (the face left).  [board-tune] 0 = 10-27.
// ⭐ 10-28 night (21:54 video: "请走近 ... 没有让张嘴，直接失败"): mode 2 -- the
// stranger also gets "请张嘴三次" (and the flashes) 3 s after clip 10, and
// "未通过" after the 3 opens / the window.  1 = the 10-28 21:49 bit.
.VERIFY_ALL ( 2            ),
.VER_T      ( 30           ),
.STR_REARM  ( 50           ),
// ⭐ 10-31 (user, 10-30 23:25 video: after a pass, back in shot with spot + red box
// but no prompt for a long time): an unrecognised face's challenge waits until it
// is close (NEAR_SIDE), never close for 12 s -> "未通过"; a face judged far away
// is verified once more when it comes close.  Before, the stranger's challenge
// started 3 s after clip 10 at any distance: the returning staff member failed it
// at 3 m and was then locked out (str_done) under the alarm spot.  0 = 10-30.
.NV_CLOSE   ( 1            ),
.VER_FAR_T  ( 120          ),
.FAR_REVERIFY ( 1          ),
// ⭐ 10-31 night (user, 21:39 video: PASS held 30 s with the face close and no new
// liveness check -- it only ended when the head turned away): a PASS lasts at
// most 10 s, then the face is verified again; a recognised face that is already
// close skips "身份核验，请走近" and gets "请张嘴三次" at once.  [board-tune]
// PASS_MAX_T 0 / NEAR_SKIP_CLOSE 0 = the 10-31 behaviour.
.PASS_MAX_T ( 100          ),
.NEAR_SKIP_CLOSE ( 1       ),
// ⭐ 10-24 (user, 23:00 video): the challenge only starts within ~2 m; farther
// away "身份核验，请走近" (clip 10) and wait (state NEAR), no "未通过".
// sc_side = box width + 1/16; box width x distance ~ 300 px m on that video
// (ToF), so 160 ~ 2 m.  [board-tune] 0 = the 10-12 behaviour.
.NEAR_SIDE  ( 12'd160      ),
.NEAR_N     ( 3            ),
.NEAR_GAP   ( 100          )        // 10 s between two clip 10s
) u_staff_ctrl (
.clk         ( pclkx1      ),
.rst_n       ( fifowait[7] ),
.en          ( face_run    ),
// the grace: alarm voice waits ~12 results after a face appears (staff_ctrl)
.face_any    ( |face_vld   ),
.res_v       ( scn_done    ),
.score       ( scn_score   ),
.live0       ( scn_live0   ),
.live1       ( scn_live1   ),
.side        ( sc_side     ),   // staff_cap updates it only with the patch staff_cnn reads
// everybody else who can start the player in the same clock (see staff_ctrl)
.player_busy ( vo_busy || vo_play || md_ann_pend || (osd_state != md_ann_prev) ),
.play        ( st_play     ),
.clip        ( st_clip     ),
.pass        ( staff_pass  ),
.hold_voice  ( st_hold     ),
.state       ( st_state    ),
.cos_bcd     ( st_cos_bcd  ),
.cos_v       ( st_cos_v    )
);

// 10-23 night: SEC_ALARM_SRC / SEC_STAFF_SPOT (declared with SEC_SPOT_GD).
assign sec_face = |face_vld;
generate if (SEC_ALARM_SRC != 0) begin : g_asrc
alarm_src #(
.CLK_HZ   ( 150_000_000 ),
// a blue box must be up this long, no gap, to START an alarm (22:05 video:
// the near-object boxes left at the frame edge last 0.07..0.27 s, one 1.5 s)
.START_MS ( 500         )
) u_alarm_src (
.clk      ( pclkx1                  ),
.rst_n    ( fifowait[7]             ),
.en       ( sec_mode && !ss_quiet   ),
.box      ( gd_person               ),
.face     ( sec_face                ),
.episode  ( sec_level != 2'd0       ),
.target   ( as_target               )
);
end else begin : g_noasrc
assign as_target = 1'b0;
end endgenerate
generate if (SEC_STAFF_SPOT != 0) begin : g_sspot
spot_seq #(
.CLK_HZ   ( 150_000_000 ),
.FLASH_N  ( 3           ),
.ON_MS    ( 200         ),   // 3 x 0.4 s = 1.2 s ~ the mouth prompt (clip 7, 1.18 s)
.OFF_MS   ( 200         ),
.QUIET_S  ( 30          ),   // [board-tune] alert off this long after a pass falls
// ⭐ 10-26 (25 23:40 video): after the flashes the spot stays LIT for the rest
// of the challenge.  Dark, face_detect lost the 0.5 m face in < 1 s on all 12
// challenges (LOST_T -> "未通过" -> alarm -> prompt again: the voice loop);
// lit, offline recognition is better, not worse.  0 = dark (10-23).
.CHAL_LIT ( 1           ),
// ⭐ 10-27 (user: "开始识别射灯仍亮"): spot OFF from recognition (NEAR) through
// the challenge, only the prompt's 3 flashes.  Overrides CHAL_LIT.  0 = 10-26.
.STAFF_DARK ( 1         ),
// ⭐ 10-28 (user, 10-28 00:00 video: after a pass the spot never came back):
// dark 3 s from the pass, then alert_ctrl's spot follows the blue box / face
// again; the alarm VOICE stays held (ss_mute: pass + QUIET_S).  0 = 10-27.
.PASS_DARK_MS ( 3000    )
) u_spot_seq (
.clk      ( pclkx1                                  ),
.rst_n    ( fifowait[7]                             ),
.en       ( sec_mode                                ),
.spot_in  ( sp_on                                   ),
.chal     ( st_state == 3'd1 || st_state == 3'd2   ),   // mouth / blink challenge
.near     ( st_state == 3'd5                        ),   // recognised, waiting to come close
.prompt   ( st_play && (st_clip == 4'd7 || st_clip == 4'd8) ),
.pass     ( staff_pass                              ),
.spot_out ( sp_pin                                  ),
.quiet    ( ss_quiet                                ),
.mute     ( ss_mute                                 )
);
end else begin : g_nosspot
assign sp_pin = sp_on;
assign ss_quiet = staff_pass;
assign ss_mute  = staff_pass;
end endgenerate

// face_smooth: the drawn boxes only (see FACE_SMOOTH).  Bypassed at 0.
wire [FACE_NROI*12-1:0] fdraw_x0, fdraw_x1, fdraw_y0, fdraw_y1;
wire [FACE_NROI-1:0]    fdraw_vld;

generate if (FACE_SMOOTH != 0) begin : g_face_smooth
face_smooth#(
.NROI   ( FACE_NROI  ),
.SC     ( FACE_SM_SC ),
.SS     ( FACE_SM_SS ),
.CLIP_W ( 1920       ),
.CLIP_H ( 1080       )
)u_face_smooth(
.clk     ( pclkx1      ),
.rst_n   ( fifowait[7] ),
.en      ( face_run    ),
.pub     ( face_pub    ),
.in_x0   ( face_x0     ),
.in_x1   ( face_x1     ),
.in_y0   ( face_y0     ),
.in_y1   ( face_y1     ),
.in_vld  ( face_vld    ),
.out_x0  ( fdraw_x0    ),
.out_x1  ( fdraw_x1    ),
.out_y0  ( fdraw_y0    ),
.out_y1  ( fdraw_y1    ),
.out_vld ( fdraw_vld   )
);
end else begin : g_face_raw
assign fdraw_x0  = face_x0;
assign fdraw_x1  = face_x1;
assign fdraw_y0  = face_y0;
assign fdraw_y1  = face_y1;
assign fdraw_vld = face_vld;
end endgenerate

//---------------------------------------------------------------------------
// face_overlay : the face boxes, in red.  Another det_overlay -- yellow is the
// object detector's and green is motion's, so red is both what is left and the
// conventional colour for this.
//
// Drawn AFTER the yellow boxes, so where a face box and an object box coincide
// the red wins.  That is the right way round: the face box is the more specific
// claim, and a red box inside a yellow one is a legible picture.
//---------------------------------------------------------------------------
wire        fov_out_vs;//synthesis keep
wire        fov_out_de;//synthesis keep
wire [23:0] fov_out_rgb;//synthesis keep

det_overlay#(
.NBLOB     ( FACE_NROI  ),
.BOX_RGB   ( 24'hFF2020 ),
.BOX_THICK ( 3          ),
.VB_GUARD  ( 512        ),
.VS_LATCH  ( 0          )
)u_face_overlay(
.clk        ( pclkx1      ),
.rst_n      ( fifowait[7] ),
.en         ( (face_ovl_en && !face_hide) || sec_mode ),   // key2 in FACE: capture view

.blob_x0    ( fdraw_x0    ),
.blob_x1    ( fdraw_x1    ),
.blob_y0    ( fdraw_y0    ),
.blob_y1    ( fdraw_y1    ),
.blob_valid ( fdraw_vld   ),

.in_vs      ( gdo_out_vs  ),   // 10-12: after the blue grid_det boxes
.in_de      ( gdo_out_de  ),
.in_rgb     ( gdo_out_rgb ),

.out_vs     ( fov_out_vs  ),
.out_de     ( fov_out_de  ),
.out_rgb    ( fov_out_rgb )
);

//---------------------------------------------------------------------------
// FACE DBG (10-04 evening, see face_dbg): the four ROIs this sweep classified,
// cyan, and each one's CNN score for the OSD.  froi_* is published at the bank
// swap in the vertical blank, which is inside det_overlay's latch window, and
// the sweep over that bank finishes ~180 lines into the frame -- above the
// 人脸 row -- so the squares, the scores and the red boxes on one recorded
// frame all describe the same sweep.
//---------------------------------------------------------------------------
reg  [31:0] fsc_q;                  // per slot: score >>> 11 (half logits at report.txt's 4096 units/logit), clamped +-99
reg  [3:0]  fsc_v;                  // per slot: classified in this sweep
wire signed [31:0] fsc_s = fc_score >>> 11;
wire [7:0]  fsc_c = (fsc_s >  32'sd99) ? 8'sd99  :
                    (fsc_s < -32'sd99) ? -8'sd99 : fsc_s[7:0];
always @(posedge pclkx1 or negedge fifowait[7]) begin
    if (!fifowait[7]) begin
        fsc_q <= 32'd0;
        fsc_v <= 4'd0;
    end else begin
        if (froi_ready)
            fsc_v <= 4'd0;
        else if (fc_done) begin
            fsc_q[fc_roi*8 +: 8] <= fsc_c;
            fsc_v[fc_roi]        <= 1'b1;
        end
    end
end

wire [FACE_NROI*12-1:0] fdg_x1, fdg_y1;
genvar fdg_i;
generate for (fdg_i = 0; fdg_i < FACE_NROI; fdg_i = fdg_i + 1) begin : g_fdg
    assign fdg_x1[fdg_i*12 +: 12] = froi_x0[fdg_i*12 +: 12] + froi_side[fdg_i*12 +: 12] - 12'd1;
    assign fdg_y1[fdg_i*12 +: 12] = froi_y0[fdg_i*12 +: 12] + froi_side[fdg_i*12 +: 12] - 12'd1;
end endgenerate

wire        fdg_out_vs;//synthesis keep
wire        fdg_out_de;//synthesis keep
wire [23:0] fdg_out_rgb;//synthesis keep

det_overlay#(
.NBLOB     ( FACE_NROI  ),
.BOX_RGB   ( 24'h20E0FF ),
.BOX_THICK ( 2          ),
.VB_GUARD  ( 512        ),
.VS_LATCH  ( 0          )
)u_face_dbg_overlay(
.clk        ( pclkx1      ),
.rst_n      ( fifowait[7] ),
.en         ( face_ovl_en && face_dbg ),

.blob_x0    ( froi_x0     ),
.blob_x1    ( fdg_x1      ),
.blob_y0    ( froi_y0     ),
.blob_y1    ( fdg_y1      ),
.blob_valid ( froi_valid  ),

.in_vs      ( fov_out_vs  ),
.in_de      ( fov_out_de  ),
.in_rgb     ( fov_out_rgb ),

.out_vs     ( fdg_out_vs  ),
.out_de     ( fdg_out_de  ),
.out_rgb    ( fdg_out_rgb )
);

//---------------------------------------------------------------------------
// FACE DBG, 10-05: the skin chain's own blobs (u_face_ccl, all FACE_NSKIN),
// orange, 2 px, under the cyan squares' layer order (drawn after them, so on
// top -- the two rarely coincide).  The 10-05 recording showed the board's
// ROIs smaller and off the face where the simulator, fed the recorded
// picture, framed the whole face; everything from face_skin to face_roi_buf
// was then shown bit-exact against board_sim on a recorded frame, so the
// difference is in the PIXELS (the recording is 720p H.264 -- the 1080p
// sensor noise is gone from it).  These boxes are the board's mask
// fragmentation, measured directly instead of inferred.  FACE_DBG_BLOBS = 0
// removes the instance (fbl_* = fdg_*).
//---------------------------------------------------------------------------
localparam integer FACE_DBG_BLOBS = 1;
wire        fbl_out_vs;//synthesis keep
wire        fbl_out_de;//synthesis keep
wire [23:0] fbl_out_rgb;//synthesis keep
generate if (FACE_DBG_BLOBS != 0) begin : g_fbl
det_overlay#(
.NBLOB     ( FACE_NSKIN ),
.BOX_RGB   ( 24'hFF8000 ),
.BOX_THICK ( 2          ),
.VB_GUARD  ( 512        ),
.VS_LATCH  ( 0          )
)u_face_blob_overlay(
.clk        ( pclkx1      ),
.rst_n      ( fifowait[7] ),
.en         ( face_ovl_en && face_dbg ),

.blob_x0    ( skin_x0     ),
.blob_x1    ( skin_x1     ),
.blob_y0    ( skin_y0     ),
.blob_y1    ( skin_y1     ),
.blob_valid ( skin_valid  ),

.in_vs      ( fdg_out_vs  ),
.in_de      ( fdg_out_de  ),
.in_rgb     ( fdg_out_rgb ),

.out_vs     ( fbl_out_vs  ),
.out_de     ( fbl_out_de  ),
.out_rgb    ( fbl_out_rgb )
);
end else begin : g_nofbl
assign fbl_out_vs  = fdg_out_vs;
assign fbl_out_de  = fdg_out_de;
assign fbl_out_rgb = fdg_out_rgb;
end endgenerate

//---------------------------------------------------------------------------
// aim_label (2026-10-01): aim_sched's per-box distance / size labels and the
// ALARM banner.  After every box layer, before text_osd, so the labels sit on
// top of all boxes and only the status panel covers them.  5 clocks.
//---------------------------------------------------------------------------
wire        alb_out_vs;//synthesis keep
wire        alb_out_de;//synthesis keep
wire [23:0] alb_out_rgb;//synthesis keep

aim_label #(
.NBOX      ( FACE_NROI ),
.BLK_W     ( 128       ),
.BLK_H     ( 72        ),
.IMG_HDISP ( 1920      )
) u_aim_label (
.clk       ( pclkx1      ),
.rst_n     ( fifowait[7] ),
.lb_x0     ( al_x0       ),
.lb_y0     ( al_y0       ),
// 10-01 evening: MAGENTA labels the tracker box, in pixels, slot 0.
.lb_pix    ( trk_view    ),
.lb_px0    ( {{(FACE_NROI-1)*12{1'b0}}, tr_px0} ),
.lb_py0    ( {{(FACE_NROI-1)*12{1'b0}}, tr_py0} ),
.lb_valid  ( MD_DRAW != 0 ? lbm_valid : {FACE_NROI{1'b0}} ),   // 10-21: tags go with the boxes
.lb_dok    ( lbm_dok     ),
.lb_aim    ( lbm_aim     ),
.lb_d_bcd  ( lbm_d_bcd   ),
.lb_w_bcd  ( lbm_w_bcd   ),
.lb_h_bcd  ( lbm_h_bcd   ),
// 10-31 night: no 报警 banner while the alarm voice is muted (ss_mute: a staff
// pass, and QUIET_S s after it) -- with PASS_MAX_T the staff member standing
// there is verified again, and 报警 flashed over them while they were
// (21:39 video, 301.5 s).  Same window as the muted voice and the Ethernet
// alarm pictures (sec_level stays 1).
.alarm     ( ((SEC_ALARM_SRC != 0) ? sp_on : lbm_alarm) && !ss_mute ),   // 10-23: the banner is the spot's "someone is there"
.pass      ( staff_pass  ),   // 10-12: "员工 PASS" replaces 报警
.in_vs     ( fbl_out_vs  ),
.in_de     ( fbl_out_de  ),
.in_rgb    ( fbl_out_rgb ),
.out_vs    ( alb_out_vs  ),
.out_de    ( alb_out_de  ),
.out_rgb   ( alb_out_rgb )
);

//---------------------------------------------------------------------------
// text_osd : status panel + Anlogic logo.  Last in the chain, so the text sits
// over every effect, the histogram and the detection boxes alike.
//
// This closes two scored items at once: the brief requires an OSD carrying the
// vendor logo, and it requires the active algorithm to be named on screen for
// the multi-algorithm switching item.  It also removes a real bench cost --
// until now the live wheel position could only be inferred by counting button
// presses since power-up, which has already produced one misdiagnosis.
//
// Held on permanently rather than behind a key: it is the evidence for two
// scored items, and there are no spare buttons -- all four are allocated
// (see the key map at the top of this file).
//
// Fed frame-active-high vs, same as hist_osd.  Adds 2 clocks to data, de and
// vs alike, so hdmi_tx sees the same relationship it always did.
//---------------------------------------------------------------------------
wire        txt_out_vs;//synthesis keep
wire        txt_out_de;//synthesis keep
wire [23:0] txt_out_rgb;//synthesis keep

//---------------------------------------------------------------------------
// latency_meter : end-to-end capture-to-display latency, measured on chip.
//
// Scored advanced item "处理延迟可视化", and the evidence behind the whole
// deterministic-real-time claim in the report.  No video path -- it taps the
// head of the chain (vtc_de_valid), the tail (txt_out_de) and the sensor's
// frame start, and drives nothing but two rows of OSD text.
//
// It has to be declared here, after txt_out_de exists, because the chain
// depth is measured between vtc_de_valid and txt_out_de rather than assumed
// from a hand-counted pipeline table.  That measurement is what keeps the
// reading honest when a later revision adds pipeline stages.
//
// cam_sof/cam_clk are the MIPI byte-clock domain; the crossing is handled
// inside the module (toggle plus two synchroniser flops -- see its header).
//---------------------------------------------------------------------------
wire [15:0] lat_bcd;
wire [3:0]  lat_frames;
wire [25:0] lat_clks;//synthesis keep      // exact, for ChipWatcher / report
wire [15:0] lat_chain_clks;//synthesis keep

latency_meter u_latency_meter(
.clk        ( pclkx1              ),
.rst_n      ( fifowait[7]         ),
.cam_clk    ( S_hs_rx_clk         ),
.cam_sof    ( S_raw8_frame_start  ),
.vtc_vs     ( vtc_vs              ),
.vtc_de     ( vtc_de_valid        ),
.out_de     ( txt_out_de          ),
.lat_bcd    ( lat_bcd             ),
.lat_frames ( lat_frames          ),
.lat_clks   ( lat_clks            ),
.chain_clks ( lat_chain_clks      )
);

// ⭐ 10-30 (user, final demo): the bottom-left block is the final OSD -- 安防
// 人脸数 / 轮廓数, 质检 任意 6 rows / 标准件 4 (text_osd [PAGES]).  The debug
// rows (运动 云台 LUM TOF 识别 / 距离 像素 台面 体积 RGB 阈值 / the 人脸 page)
// are gone; rollback = system_top / text_osd / osd_cn.hex *.pre_1030.
// 10-31: the production count, counted with eth_qc_trig further down (declared
// here because u_text_osd reads it)
reg  [11:0] qcn_tot_bcd = 12'd0, qcn_pas_bcd = 12'd0;

// 10-30: the security page's counts -- exactly what the two overlays draw
// (u_face_overlay: fdraw_vld; u_grid_overlay: gd_valid).
wire [3:0] sec_n_faces  = fdraw_vld[0] + fdraw_vld[1] + fdraw_vld[2] + fdraw_vld[3];
wire [3:0] sec_n_bodies = gd_valid[0]  + gd_valid[1]  + gd_valid[2]  + gd_valid[3];

text_osd #(
.LTROW        ( 7             ),     // the longest page (质检 任意; 10-31 + 检数)
.LTY0         ( 12'd840       )      // 840 + 7*32 = 1064, the same bottom margin
) u_text_osd(
.clk          ( pclkx1        ),
.rst_n        ( fifowait[7]   ),
.en           ( 1'b1          ),
.wheel_mode   ( cc_wheel_mode ),
.affine_mode  ( af_mode       ),
.moved_blocks ( md_blocks     ),
.cam_motion   ( md_cam_motion ),
.cam_soft     ( md_cam_soft   ),
.trk_state    ( md_trk_state  ),

// 09-23: the head's two commanded widths.  COMMANDED, not measured -- an
// SG90 has no feedback -- which is what makes the pair diagnostic: numbers
// moving with a still head is wiring or power, numbers frozen is the loop.
.pw_pan       ( sv_pw_pan     ),
.pw_tilt      ( sv_pw_tilt    ),
.lat_bcd      ( lat_bcd       ),
.lat_frames   ( lat_frames    ),
.det_count    ( blob_count    ),
.det_ovf      ( det_ovf       ),
.det_margin   ( det_margin    ),
.det_fg_dark  ( det_fg_dark   ),
.shape_class  ( sv_class      ),
.shape_valid  ( sv_valid      ),
.obj_color    ( oc_stable_id  ),

// The RAW selector value, not the gated enables.  The row is there to say what
// F9 is set to even when the thing that position draws is empty -- which is
// the exact confusion it was added for (see NROW in text_osd).
.ovl_mode     ( (osd_state == OSD_RAW)             ? 3'd5 :
                 (sec_mode && !trk_view)            ? 3'd3 :
                 ((osd_state == 2'd2) && face_hide) ? 3'd4 :
                 ((osd_state == 2'd2) && face_dbg)  ? 3'd6 :
                 {1'b0, osd_state} ),   // 0 TRACK / 1 BOX / 2 FACE / 3 MULTI / 4 FACE CAP / 5 RAW
.face_rois    ( froi_n        ),
.face_count   ( face_count    ),
.face_held    ( froi_held     ),
.face_nacc    ( face_nacc     ),
.face_rej     ( froi_rej      ),
.face_flat    ( froi_flat     ),
.face_sc      ( fsc_q         ),
.face_sc_v    ( fsc_v         ),
.staff_cos_bcd( st_cos_bcd    ),
.staff_cos_v  ( st_cos_v      ),
.staff_st     ( st_state      ),
.tof_dist_text( tof_dist_text ),
.tof_roi_text ( tof_roi_text  ),
.tof_pix_text ( tof_pix_text  ),
.qc_size_text ( qc_size_text  ),
.qc_base_text ( qc_base_text  ),
.qc_state_text( qc_state_text ),
.qc_def_text  ( qd_text       ),
.qc_part_text ( qs_part_text  ),
.qc_vol_text  ( qs_vol_text   ),
.qc_judge_text( qs_judge_text ),
.stain_out    ( st_out        ),     // 10-27 (STAIN_ROW)
.stain_valid  ( st_valid      ),
.stain_hot    ( st_hot        ),
.oc_mean_r    ( oc_mean_r     ),     // 10-28 (RGB_ROW)
.oc_mean_g    ( oc_mean_g     ),
.oc_mean_b    ( oc_mean_b     ),
.lum_sig      ( lm_sig        ),
.lum_mean     ( lm_mean       ),
.lum_amb      ( lm_ambient    ),
.lum_on       ( lm_on         ),
.tof_txt      ( gd_tof_txt    ),
.sec_faces    ( sec_n_faces   ),     // 10-30: red boxes drawn
.sec_bodies   ( sec_n_bodies  ),     //        blue boxes drawn
.sec_learning ( gd_bg_busy    ),     //        轮廓数 row + 学习中
.qc_std_on    ( qc_std_mode != 2'd0 ),
.qc_stable    ( qc_text_stb   ),
.qc_cal_show  ( qc_text_cal   ),
.qc_reason_text( qs_reason_text ),
.qc_cnt_bcd   ( qcn_tot_bcd   ),     // 10-31: production count
.qc_pass_bcd  ( qcn_pas_bcd   ),
.in_vs        ( alb_out_vs    ),
.in_de        ( alb_out_de    ),
.in_rgb       ( alb_out_rgb   ),
.out_vs       ( txt_out_vs    ),
.out_de       ( txt_out_de    ),
.out_rgb      ( txt_out_rgb   )
);

//---------------------------------------------------------------------------
// isp_saturate : chroma gain about the luma axis (2026-09-17).
//
// The bench report was "the picture is basically right but GREY, the vendor
// example is vivid".  Two causes, and this addresses both:
//
//   * THE CHAIN HAD NO SATURATION CONTROL ANYWHERE.  The 09-15 A-vs-B analysis
//     measured the vendor example's real ISP increment over ours as "AWB plus
//     saturation 1.13 / contrast 1.09 / brightness -5" (§3.-5).  We took the
//     AWB -- isp_auto_level stands in for it -- and left the other three on
//     the table.  This is the 1.13.
//   * isp_auto_level ACTIVELY DESATURATES.  It runs three INDEPENDENT
//     per-channel black/white point stretches, which is a grey-world
//     correction: a scene with any dominant hue has that hue defined away,
//     because the channel carrying it is stretched by exactly the factor that
//     removes it.  That is wanted for the cast the fixed WB_R/G/B leaves
//     behind and unwanted on the scene's own colour, and one histogram cannot
//     tell them apart.  Paying for it here is cheaper and much safer than
//     weakening the module that is also doing the white balance.
//
// Shift only -- out = gray + (1 + 2^-SAT_SHIFT)*(in - gray) -- so no
// multiplier and no DSP, two shallow registered stages.  SAT_SHIFT=2 is 1.25x;
// raise it to 1 (1.5x) if the TV still reads flat.
//
// ⚠ WHY IT IS AT THE VERY END OF THE CHAIN AND NOT IN THE ISP.
//   The obvious home is next to isp_gamma, and the argument for putting it
//   there was that this transform preserves luma exactly -- so det_binarize
//   and motion_frame_drawer, which both threshold luma and both sit
//   downstream of the ISP, would not notice it.  THAT ARGUMENT IS WRONG, and
//   stb.v TEST 2 is what showed it: luma is preserved exactly only while no
//   channel CLAMPS.  A saturated dark colour drives one channel negative, the
//   clamp at 0 puts the removed amount back into the luma, and the measured
//   drift reaches 14 counts -- against a MARGIN_MIN of 16.  A priority-3
//   cosmetic change would have been perturbing the priority-1 detector by
//   most of its noise budget, on exactly the coloured-object-on-a-dark-desk
//   scenes the bench is shooting.
//
//   Here there is nothing downstream but hdmi_tx, so det_binarize, ccl_blob,
//   motion_frame_drawer, color_replace, the latency meter and every
//   delay-compensated consumer in the chain are all untouched, and no
//   coordinate can shift relative to any other.
//
//   It costs 2 clocks of latency (13ns, unmeasurable) and it does saturate the
//   OSD and the boxes as well as the picture. Neither matters, and stb.v
//   proves why rather than assuming it: NEUTRAL GREY IS BIT-EXACT (T1), so the
//   white-on-black text is untouched, and a SATURATED PRIMARY CLAMPS BACK TO
//   ITSELF (T5), so the green motion boxes and yellow detect boxes come out
//   the colours they went in. The Anlogic logo gets slightly more vivid, and
//   the SEPIA wheel position slightly less sepia -- both cosmetic and both in
//   the direction asked for.
//---------------------------------------------------------------------------
wire        sat_out_vs, sat_out_de;
wire [23:0] sat_out_rgb;

isp_saturate#(
.SAT_SHIFT ( 2 )          // 1.25x -- see the table in the module header
)u_isp_saturate(
.clk      ( pclkx1            ),
.rst_n    ( fifowait[7]       ),
.en       ( isp_sat_en        ),
.in_vs    ( txt_out_vs        ),
.in_de    ( txt_out_de        ),
.in_r     ( txt_out_rgb[23:16]),
.in_g     ( txt_out_rgb[15:8] ),
.in_b     ( txt_out_rgb[7:0]  ),
.out_vs   ( sat_out_vs        ),
.out_de   ( sat_out_de        ),
.out_r    ( sat_out_rgb[23:16]),
.out_g    ( sat_out_rgb[15:8] ),
.out_b    ( sat_out_rgb[7:0]  )
);

//---------------------------------------------------------------------------
// ETHA UDP preview + QC record + full-resolution bursts (2026-10-04, re-
// grafted onto this tree 2026-10-09; ETHERNET_V1.md, PROTOCOL.md)
//
// ETHA is a read-only observer of the final display stream -- the very wires
// hdmi_tx takes below, so the PC sees exactly the HDMI picture, OSD and all.
// It never applies backpressure to the HDMI path: when the network side
// cannot keep up, the preview branch drops complete frames and HDMI remains
// authoritative.
//
// qc_trig / qc_rec are qc_thick's ethernet interface (qc_thick.v header):
// the EVQC1 record, and a four-frame full-resolution burst for the card.
// In security mode a burst goes out every 60 frames: an ALARM picture while
// alert_ctrl's sec_level is 2 (a face was seen) or 3 (motion >= NOFACE_S s,
// no face) AND someone is there right now (lbm_alarm || fa_person, the same
// "someone is there" the spot uses, faces in either view), a NORMAL one while
// nobody is, none during an unconfirmed level 1.  The PC keeps every alarm
// picture and one normal picture a minute (evs_burst_ctrl.v header).
// Inside the endpoint all three are seen on pclkx1 only by a few flops that
// act on VS edges; nothing here adds logic to a pixel path.
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
// qc_ext (2026-10-09) -- the rest of the workpiece card, sent as EVQC2 bytes
// 28..43 next to qc_rec (evs_aux_tx QC_V2).  ⭐ 10-29: the layout below is
// layout 2, kept for reference; what is latched now is LAYOUT 3 (after
// eth_qc_trig, further down), on eth_qc_trig rather than qc_trig.
// Layout 2 was latched on qc_trig, the clock
// qc_thick latches qc_rec, and held to the next trigger, so it crosses to the
// Ethernet side exactly as qc_rec does.  What the card shows per field:
//   [127]     1 = qc_ext present
//   [126]     shape valid (shape_vote confident)   [125:124] shape class
//             0 other / 1 circle / 2 rect / 3 triangle
//   [123:120] shape vote confidence (0..15)
//   [119]     qc_defect saw an object   [118] surface defect -- 10-28: the
//             voted stain_detect result (st_out); was the retired qc_defect's
//             debounced qd_bad, whose false flags failed every part on the card
//   [117]     colour class valid        [116:113] colour class -- 10-11:
//             obj_color_detect's stable_id (0 black 1 gray 2 white 3 red
//             4 orange 5 yellow 6 green 7 cyan 8 blue 9 purple, 15 none);
//             while [117] is 0 the PC names the colour from [71:48]
//   [111:104] hole cells  [103:96] stain cells  [95:88] edge cells (<= 255)
//   [87:72]   interior cells (16x16 px each)
//   [71:48]   mean R, G, B of the clean interior (qc_defect's reference)
//   [47:0]    defect box x0, y0, x1, y1 px (meaningful when a count is > 0)
//---------------------------------------------------------------------------
wire       qc_color_v   = (OBJ_COLOR != 0) ? oc_stable_valid : 1'b0;   // 10-11 obj_color_detect
wire [3:0] qc_color_cls = (OBJ_COLOR != 0) ? oc_stable_id    : 4'd0;   // 0..9, 15 = none
function [7:0] sat8; input [15:0] v; sat8 = (v > 16'd255) ? 8'd255 : v[7:0]; endfunction

//---------------------------------------------------------------------------
// ⭐ 10-29 (user): the card follows the BOX page's two modes -- 任意 shows
// colour / shape / size, 标准件 adds the deviations and qc_std's verdict.  So
// the record must carry qc_std_mode and qc_std's verdict, and the verdict must
// be the one for THIS part.  qc_trig fires a few clocks after qc_stable rises,
// but qc_std only takes `stable` at the next tof_pub_stb and needs ~100
// clocks to run: at qc_trig, qs_valid / qs_pass still describe the last part.
// eth_qc_trig = the second tof_pub_stb after qc_trig + QC_ETH_WAIT clocks (a
// frame of margin on top of qc_std's run), or QC_ETH_TMO (0.22 s) if the
// publishes stop.  A new qc_trig while waiting restarts the wait -- qc_thick
// holds qc_rec from one trigger to the next, so the record sent is the
// newest.  eth_qc_trig drives everything on the Ethernet side: qc_ext below,
// the EVQC2 record, and the burst for the card's picture, which therefore
// shows the 判定 row with this same verdict.
//---------------------------------------------------------------------------
localparam integer QC_ETH_WAIT = 1024;
localparam [24:0]  QC_ETH_TMO  = 25'h1FF_FFFF;
reg        qe_run  = 1'b0;
reg [1:0]  qe_pubs = 2'd0;
reg [9:0]  qe_w    = 10'd0;
reg [24:0] qe_tmo  = 25'd0;
reg        eth_qc_trig = 1'b0;//synthesis keep
always @(posedge pclkx1 or negedge fifowait[7]) begin
    if (!fifowait[7]) begin
        qe_run <= 1'b0; qe_pubs <= 2'd0; qe_w <= 10'd0; qe_tmo <= 25'd0;
        eth_qc_trig <= 1'b0;
    end else begin
        eth_qc_trig <= 1'b0;
        if (qc_trig) begin
            qe_run <= 1'b1; qe_pubs <= 2'd0; qe_w <= 10'd0; qe_tmo <= 25'd0;
        end else if (qe_run) begin
            qe_tmo <= qe_tmo + 25'd1;
            if (tof_pub_stb && qe_pubs != 2'd2) qe_pubs <= qe_pubs + 2'd1;
            if (qe_pubs == 2'd2) qe_w <= qe_w + 10'd1;
            if ((qe_pubs == 2'd2 && qe_w == QC_ETH_WAIT - 1) || qe_tmo == QC_ETH_TMO) begin
                qe_run <= 1'b0;
                eth_qc_trig <= 1'b1;
            end
        end
    end
end

//---------------------------------------------------------------------------
// ⭐ 10-31 (user, Anlogic_update): production count.  One per eth_qc_trig (one
// per workpiece, qc_thick's trigger rule), counted only once judged: in 任意
// every trigger, in a standard mode only when qs_valid (a part still waiting
// for its colour / shape -- 测量中 -- is not counted).  Passed = qs_pass.  Both
// in BCD for the OSD (3 digits, no divider) and in binary for qc_ext; 999 max.
// A new batch -- both zero -- on power-up and whenever key3 / the GUI changes
// the standard part.
//---------------------------------------------------------------------------
function [11:0] bcd_inc3;                    // +1 on 3 BCD digits, holds at 999
    input [11:0] v;
    begin
        if (v == 12'h999)            bcd_inc3 = v;
        else if (v[3:0] != 4'd9)     bcd_inc3 = {v[11:4], v[3:0] + 4'd1};
        else if (v[7:4] != 4'd9)     bcd_inc3 = {v[11:8], v[7:4] + 4'd1, 4'd0};
        else                         bcd_inc3 = {v[11:8] + 4'd1, 8'd0};
    end
endfunction
reg  [1:0]  qcn_mode = 2'd0;
// (qcn_tot_bcd / qcn_pas_bcd are declared above u_text_osd, their reader)
reg  [9:0]  qcn_tot = 10'd0, qcn_pas = 10'd0;
wire        qcn_judged = (qc_std_mode == 2'd0) || qs_valid;
wire        qcn_inc    = eth_qc_trig && qcn_judged;
wire        qcn_pinc   = qcn_inc && (qc_std_mode != 2'd0) && qs_pass;
wire [9:0]  qcn_tot_nx = (qcn_inc  && qcn_tot != 10'd999) ? qcn_tot + 10'd1 : qcn_tot;
wire [9:0]  qcn_pas_nx = (qcn_pinc && qcn_pas != 10'd999) ? qcn_pas + 10'd1 : qcn_pas;
always @(posedge pclkx1 or negedge fifowait[7]) begin
    if (!fifowait[7]) begin
        qcn_mode <= 2'd0; qcn_tot_bcd <= 12'd0; qcn_pas_bcd <= 12'd0; qcn_tot <= 10'd0; qcn_pas <= 10'd0;
    end else begin
        qcn_mode <= qc_std_mode;
        if (qc_std_mode != qcn_mode) begin           // a new batch
            qcn_tot_bcd <= 12'd0; qcn_pas_bcd <= 12'd0; qcn_tot <= 10'd0; qcn_pas <= 10'd0;
        end else begin
            qcn_tot <= qcn_tot_nx;
            qcn_pas <= qcn_pas_nx;
            if (qcn_inc)  qcn_tot_bcd <= bcd_inc3(qcn_tot_bcd);
            if (qcn_pinc) qcn_pas_bcd <= bcd_inc3(qcn_pas_bcd);
        end
    end
end

//---------------------------------------------------------------------------
// qc_ext LAYOUT 3 (10-29; EVQC2 byte 5 = 3).  Fields the retired qc_defect
// filled are gone; [119], [118] and [103:96] are stain_detect's now.
//   [127]     1 = qc_ext present
//   [126]     shape valid (shape_vote confident)   [125:124] shape class
//             0 other / 1 circle / 2 rect / 3 triangle
//   [123:120] shape vote confidence (0..15)
//   [119]     stain judged at least once (st_valid)  [118] stain (st_out, voted)
//   [117]     colour class valid        [116:113] colour class (as layout 2)
//   [112]     standard-part mode (qc_std_mode != 0: 标准件)
//   [111]     qc_std verdict valid (qs_valid)   [110] 合格 (qs_pass)
//   [109:108] 10-31: qc_std_mode -- 0 任意, 1 标准件 (cube), 3 三棱柱
//   [103:96]  stain hot cells of the last judgement (st_hot, <= 255)
//   [95:86]   10-31: parts judged in this batch, this one included (binary)
//   [85:76]   10-31: of them passed
//   [71:48]   mean R, G, B of the part (obj_color_detect; qc_defect's if
//             OBJ_COLOR = 0)
//   everything else 0
// The nominal sizes and tolerances the PC prints next to the verdict are
// qc_std's (QC_P1_* above, TOL_XY_MM / TOL_Z_MM at u_qc_std): change them
// together with host/qc_record.py STD_PART.
//---------------------------------------------------------------------------
wire [23:0] qc_mean_rgb = (OBJ_COLOR != 0) ? {oc_mean_r, oc_mean_g, oc_mean_b}
                                           : {qd_mR, qd_mG, qd_mB};
reg [127:0] qc_ext;//synthesis keep
always @(posedge pclkx1 or negedge fifowait[7]) begin
    if (!fifowait[7])
        qc_ext <= 128'd0;
    else if (eth_qc_trig)
        qc_ext <= {1'b1, sv_valid, sv_class, sv_conf,
                   st_valid, st_out, qc_color_v, qc_color_cls,
                   (qc_std_mode != 2'd0), qs_valid, qs_pass, qc_std_mode, 4'd0,
                   st_hot, qcn_tot_nx, qcn_pas_nx, 4'd0,
                   qc_mean_rgb,
                   48'd0};
end

wire eth_video_frame_dropped;//synthesis keep
wire eth_fifo_overflow;//synthesis keep
wire eth_packetizer_error;//synthesis keep

//---------------------------------------------------------------------------
// ⭐ 10-29 (user): security pictures and staff verification.
//   * while a face is being verified -- staff_ctrl NEAR ("请走近") and the
//     mouth / blink challenges -- no security picture at all;
//   * a pass: ONE picture, a couple of frames after staff_pass rises, i.e.
//     with aim_label's green "员工 PASS" banner on it (evs_burst_ctrl);
//   * from the pass until 30 s after staff_pass falls (spot_seq's `mute`,
//     ss_mute: pass, or < QUIET_S s since it fell): none.  NOT ss_quiet:
//     since 10-28 (PASS_DARK_MS) that is only the 3 s dark after the pass,
//     after which alert_ctrl runs again and its level would give alarm
//     pictures of the staff member.  With SEC_STAFF_SPOT = 0, ss_mute =
//     staff_pass.
// The normal record's interval (30 min) is the PC's, not set here.
// VERIFY_ALL = 2 puts a stranger through NEAR and a challenge too, so a
// stranger's verification is not recorded either; the alarm pictures start
// with "未通过" (staff_ctrl COOL).
//---------------------------------------------------------------------------
wire       eth_sec_hold = (st_state == 3'd1) || (st_state == 3'd2) || (st_state == 3'd5)
                          || ss_mute;
// EVDBG1 byte 11 bits 7:1 for the GUI (layout: eth_a_video_endpoint header).
// osd_state + 1 is the GUI's numbering: 3 RAW -> 0, 0 TRACK -> 1, 1 BOX -> 2,
// 2 FACE -> 3.
// 10-31: bit 5 was face_dbg (always 0 since FACE_MODE 0) -- now 三棱柱.
wire [6:0] eth_ui_state = {staff_pass, (qc_std_mode == 2'd3), face_hide, trk_view,
                           (qc_std_mode != 2'd0), osd_state + 2'd1};

eth_a_video_endpoint u_eth_a_video(
.I_clk_25m            ( I_sysclk_25m           ),
.O_eth_phy_rst_n      ( O_eth_phy_rst_n        ),
.I_eth_rgmii_rxd      ( I_eth_rgmii_rxd        ),
.I_eth_rgmii_rx_ctl   ( I_eth_rgmii_rx_ctl     ),
.I_eth_rgmii_rxc      ( I_eth_rgmii_rxc        ),
.O_eth_rgmii_txd      ( O_eth_rgmii_txd        ),
.O_eth_rgmii_tx_ctl   ( O_eth_rgmii_tx_ctl     ),
.O_eth_rgmii_txc      ( O_eth_rgmii_txc        ),
.I_video_clk          ( pclkx1                 ),
.I_video_rst_n        ( fifowait[7]            ),
.I_video_vs           ( sat_out_vs             ),
.I_video_de           ( sat_out_de             ),
.I_video_rgb          ( sat_out_rgb            ),
.I_qc_trig            ( eth_qc_trig            ),   // 10-29: was qc_trig (see eth_qc_trig)
.I_qc_rec             ( qc_rec                 ),
.I_qc_ext             ( qc_ext                 ),
.I_burst_timer_en     ( sec_mode               ),
.I_alarm_level        ( sec_level              ),
.I_present            ( (SEC_ALARM_SRC != 0) ? as_target : (lbm_alarm || fa_person) ),
.I_sec_hold           ( eth_sec_hold           ),
.I_staff_pass         ( staff_pass             ),
.I_ui_state           ( eth_ui_state           ),
.O_cmd_stb            ( eth_cmd_stb_raw        ),
.O_cmd                ( eth_cmd                ),
.O_arg                ( eth_arg                ),
.O_video_frame_dropped( eth_video_frame_dropped),
.O_fifo_overflow      ( eth_fifo_overflow      ),
.O_packetizer_error   ( eth_packetizer_error   )
);

//hdmi ���IP
hdmi_tx#(
 //HDMI��Ƶ��������       
.H_ActiveSize       (1920), //��Ƶʱ�����,����Ƶ�źţ�һ����Ч(��Ҫ��ʾ�Ĳ���)������ռ��ʱ������һ��ʱ�Ӷ�Ӧһ����Ч����
.H_SyncStart        (1920+88), //��Ƶʱ�����,��ͬ����ʼ��������ʱ������ʼ������ͬ���ź� 
.H_SyncEnd          (1920+88+44),//��Ƶʱ�����,��ͬ��������������ʱ������ֹͣ������ͬ���źţ�֮���������Ч���ݲ���
.H_FrameSize        (1920+88+44+148), //��Ƶʱ�����,����Ƶ�źţ�һ����Ƶ�ź��ܼ�ռ�õ�ʱ����

.V_ActiveSize       (1080),//��Ƶʱ�����,����Ƶ�źţ�һ֡ͼ����ռ�õ���Ч(��Ҫ��ʾ�Ĳ���)��������ͨ��˵����Ƶ�ֱ��ʼ�H_ActiveSize*V_ActiveSize
.V_SyncStart        (1080+4),//��Ƶʱ�����,��ͬ����ʼ��������������ʼ������ͬ���ź� 
.V_SyncEnd          (1080+4+5), //��Ƶʱ�����,��ͬ�������������к�ֹͣ������ͬ���ź�  
.V_FrameSize        (1080+4+5+36),  //��Ƶʱ�����,����Ƶ�źţ�һ֡��Ƶ�ź��ܼ�ռ�õ�������        

.VIDEO_VIC          ( 16       ),
.VIDEO_TPG          ( "Disable"),//����disable���û���������HDMI�ӿڣ���������eable�����ڲ�����ͼ��
.VIDEO_FORMAT       ( "RGB444" )//�����������ݸ�ʽΪRGB��ʽ
)u_hdmi_tx
(
.I_pixel_clk        ( pclkx1           ),//����ʱ��
.I_serial_clk       ( pclkx5           ),//���з���ʱ��
.I_rst              ( ~S_pll_lock      ),//�첽��λ�źţ��ߵ�ƽ��Ч

.I_video_rgb_enable ( 1'b1             ),// use the parallel RGB port, not the stream port
.I_video_in_vs      ( sat_out_vs       ),// already frame-active-high out of text_osd
.I_video_in_de      ( sat_out_de       ),// RGB data enable
.I_video_in_data    ( sat_out_rgb      ),

.O_hdmi_clk_p       ( O_hdmi_clk_p     ),//HDMIʱ��ͨ��
.O_hdmi_tx_p        ( O_hdmi_tx_p      )//HDMI����ͨ��
);

endmodule

