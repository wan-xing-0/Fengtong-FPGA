//---------------------------------------------------------------------------
// isp_gamma -- switchable sRGB gamma encode, sits in the ISP chain between
//              raw8_2_rgb888 and color_convert.
//
// WHY
//   The SC500AI delivers LINEAR RAW.  A display decodes whatever it is fed
//   with sRGB's ~2.2 gamma, so feeding it linear data crushes the midtones
//   and the picture reads flat and murky.  Every wheel position downstream
//   inherits that: HISTEQ sees a histogram bunched into a narrow band and
//   stretches it into banding, and CONTRAST's steep S-curve (code 96 -> 32,
//   64 -> 2) drops most of the frame to black.
//
//   Direction matters.  color_convert/Curve_Gamma_2P2 is x^2.2 and DARKENS --
//   that is the artistic GAMMA wheel position, not a correction.  This module
//   is its inverse and belongs in the ISP chain.
//
// gamma_en is a runtime toggle so the board can be compared against the
// un-encoded path without a rebuild.  Held low, this module is transparent
// apart from its one register stage.
//
// Latency: 1 clock.  vs/de ride the same register, so the relative alignment
// color_convert depends on is unchanged.
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module isp_gamma
(
input   wire        clk,
input   wire        rst_n,
input   wire        gamma_en,       // 1 = encode, 0 = pass through

input   wire        in_vs,
input   wire        in_de,
input   wire[7:0]   in_r,
input   wire[7:0]   in_g,
input   wire[7:0]   in_b,

output  reg         out_vs,
output  reg         out_de,
output  reg [7:0]   out_r,
output  reg [7:0]   out_g,
output  reg [7:0]   out_b
);

wire [7:0] enc_r, enc_g, enc_b;

Curve_Gamma_Encode u_enc_r (.Pre_Data(in_r), .Post_Data(enc_r));
Curve_Gamma_Encode u_enc_g (.Pre_Data(in_g), .Post_Data(enc_g));
Curve_Gamma_Encode u_enc_b (.Pre_Data(in_b), .Post_Data(enc_b));

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        out_vs <= 1'b0;
        out_de <= 1'b0;
        out_r  <= 8'd0;
        out_g  <= 8'd0;
        out_b  <= 8'd0;
    end else begin
        out_vs <= in_vs;
        out_de <= in_de;
        out_r  <= gamma_en ? enc_r : in_r;
        out_g  <= gamma_en ? enc_g : in_g;
        out_b  <= gamma_en ? enc_b : in_b;
    end
end

endmodule
