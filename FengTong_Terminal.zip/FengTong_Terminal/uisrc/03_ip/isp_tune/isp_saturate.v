//---------------------------------------------------------------------------
// isp_saturate -- chroma gain about the luma axis.  Shift only, no multiplier.
//
// WHY THIS EXISTS -- 2026-09-17
//   The bench report was "the picture is basically right but GREY, the vendor
//   example is vivid".  The chain had no saturation control anywhere, and the
//   09-15 A/B-vs-B analysis measured the vendor example's real ISP increment
//   over ours as "AWB plus saturation 1.13 / contrast 1.09 / brightness -5".
//   We have isp_auto_level standing in for the AWB.  This is the 1.13.
//
//   And it is not merely a missing nicety -- the chain ACTIVELY desaturates.
//   isp_auto_level runs three INDEPENDENT per-channel black/white point
//   stretches, so it drives each channel's 0.5% point to 0 and its 99.5% point
//   to 255 separately.  That is a grey-world correction: a scene with any
//   dominant hue has that hue defined away, because the channel carrying it is
//   stretched by exactly the factor that removes it.  Its own header says it
//   "doubles as a white balance", which is the same statement read the other
//   way round.  We want that for the cast the fixed WB_R/G/B leaves behind; we
//   do not want it applied to the scene's own colour, and one histogram cannot
//   tell those apart.  So the pull-to-grey is paid for here rather than by
//   weakening the thing that is also doing the white balance.
//
// WHAT IT DOES
//   out_c = gray + K*(in_c - gray),  clamped to 0..255
//
//   with gray the luma and K = 1 + 2^-SAT_SHIFT, so the multiply is a SHIFT:
//
//     SAT_SHIFT   K       note
//         0      2.00     far too much, here for completeness
//         1      1.50     vivid; use if 1.25 still reads flat on the TV
//         2      1.25     default -- a little past the example's 1.13, because
//                         we are also undoing auto_level's pull to grey
//         3      1.125    essentially the example's number
//
//   EN low is a bit-exact bypass through the same two stages, so toggling it
//   cannot shift the picture by a pixel -- the same property isp_auto_level's
//   en has, and for the same reason.
//
// ⚠ IT PRESERVES LUMA ONLY WHILE NOTHING CLAMPS -- THE FIRST PLACEMENT OF THIS
//   MODULE WAS WRONG BECAUSE OF IT.  Unclamped, luma is the exact fixed point:
//
//     luma(out) = gray + K*(luma(in) - gray) = gray + K*(gray - gray) = gray
//
//   provided the SAME weights are used, which is why the adder tree below is
//   copied from det_binarize's section [1] rather than written fresh with
//   nicer coefficients.  stb.v TEST 2 confirms it exactly on the whole cube.
//
//   BUT A CLAMP BREAKS IT.  A saturated dark colour drives one or two channels
//   negative -- pure-ish blue at (0,0,45) wants R and G at -2.75 -- and the
//   clamp at 0 puts that removed amount straight back into the luma.  stb.v
//   TEST 2b measures the drift at up to 14 counts.
//
//   That killed the original plan of putting this next to isp_gamma.  From
//   there it is upstream of det_binarize (which taps af_out_*) and of
//   motion_frame_drawer, both of which threshold luma -- so a purely cosmetic
//   change would have been moving the detector's input by 14 counts against a
//   MARGIN_MIN of 16, on exactly the coloured-object-on-a-dark-desk scenes the
//   bench shoots.  A 14-count perturbation that only appears on saturated
//   colours is also about the worst thing to have to debug from a photograph.
//
//   SO IT LIVES AT THE VERY END, between text_osd and hdmi_tx, where nothing
//   is downstream.  The luma-preservation property is still worth having and
//   still worth testing -- it is what proves the arithmetic is right -- it is
//   just no longer load-bearing.
//
// WHY IT IS IN THE sRGB DOMAIN
//   A fixed chroma gain applied in LINEAR light stretches highlights far more
//   than shadows, so a scene with a bright object gets a coloured fringe on
//   the highlight and no more colour in the midtones.  Saturation after the
//   gamma encode is what consumer ISPs do and what the eye judges.  At the tail
//   of the chain that is automatic.
//
// TIMING
//   Two registered stages.  The deepest combinational path is stage 2: one
//   9-bit subtract, then a 10-bit add, then the clamp mux -- shallower than
//   the 3x3 demosaic already in this domain, and there is no multiplier and
//   no DSP.  Stage 1 is the 3-input adder tree, which is the same one
//   det_binarize runs at this rate today.
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module isp_saturate #(
// 1 + 2^-SAT_SHIFT is the chroma gain.  See the table in the header.
parameter integer SAT_SHIFT = 2
)(
input  wire        clk,
input  wire        rst_n,
input  wire        en,

input  wire        in_vs,       // rides along, any polarity
input  wire        in_de,
input  wire [7:0]  in_r,
input  wire [7:0]  in_g,
input  wire [7:0]  in_b,

output reg         out_vs,
output reg         out_de,
output reg  [7:0]  out_r,
output reg  [7:0]  out_g,
output reg  [7:0]  out_b
);

//-------------------------------------------------------------------
// Stage 1 : luma, in two balanced adder stages, and the bypass copies.
//
// gray = (R + 2G + B) >> 2.  Same weights as det_binarize section [1] -- see
// the luma-preservation note in the header for why that is a requirement and
// not a coincidence.
//-------------------------------------------------------------------
reg [7:0] s1_r, s1_g, s1_b;
reg [7:0] s1_gray;
reg       s1_vs, s1_de;

wire [8:0] sum_rb = {1'b0, in_r} + {1'b0, in_b};
wire [8:0] sum_g2 = {in_g, 1'b0};
wire [9:0] sum_y  = {1'b0, sum_rb} + {1'b0, sum_g2};

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        s1_r <= 8'd0; s1_g <= 8'd0; s1_b <= 8'd0;
        s1_gray <= 8'd0;
        s1_vs <= 1'b0; s1_de <= 1'b0;
    end else begin
        s1_r <= in_r; s1_g <= in_g; s1_b <= in_b;
        s1_gray <= sum_y[9:2];
        s1_vs <= in_vs; s1_de <= in_de;
    end
end

//-------------------------------------------------------------------
// Stage 2 : out = in + ((in - gray) >>> SAT_SHIFT), clamped.
//
// SIGNED, and the arithmetic shift is the whole reason: (in - gray) is
// negative wherever the channel is below the luma -- which for any coloured
// pixel is at least one of the three -- and a logical shift there would wrap a
// small negative difference into a large positive one.  The symptom would be
// bright confetti on saturated edges, which reads as a link or memory fault
// rather than as an arithmetic one.  Written with $signed() on both operands
// so the widths cannot silently make it unsigned.
//
// 10 bits: in is 0..255 and the shifted difference is -255..+255 at
// SAT_SHIFT=0, so the sum spans -255..+510 and needs a sign bit plus 9.
//-------------------------------------------------------------------
function [7:0] sat_ch;
    input [7:0] pix;
    input [7:0] gry;
    reg signed [9:0] diff;
    reg signed [10:0] sum;
    begin
        diff = $signed({2'b00, pix}) - $signed({2'b00, gry});
        sum  = $signed({1'b0, 2'b00, pix}) + $signed(diff >>> SAT_SHIFT);
        if      (sum[10])          sat_ch = 8'd0;      // negative
        else if (sum > 11'sd255)   sat_ch = 8'd255;
        else                       sat_ch = sum[7:0];
    end
endfunction

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        out_r <= 8'd0; out_g <= 8'd0; out_b <= 8'd0;
        out_vs <= 1'b0; out_de <= 1'b0;
    end else begin
        out_r <= en ? sat_ch(s1_r, s1_gray) : s1_r;
        out_g <= en ? sat_ch(s1_g, s1_gray) : s1_g;
        out_b <= en ? sat_ch(s1_b, s1_gray) : s1_b;
        out_vs <= s1_vs;
        out_de <= s1_de;
    end
end

endmodule
