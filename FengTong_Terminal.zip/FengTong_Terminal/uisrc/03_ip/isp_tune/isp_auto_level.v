//---------------------------------------------------------------------------
// isp_auto_level -- automatic black/white point stretch, three channels.
//
// Sits between raw8_2_rgb888 and isp_gamma, i.e. in the LINEAR domain, which
// is the only correct place for it: the pedestal has to be gone and the range
// has to be opened up before the sRGB encode, otherwise the encode lifts the
// residual floor into a grey haze (code 16 -> 71).
//
// Per channel: out = clamp( (in - lo) * gain >> 8 , 0, 255 )
// with lo and gain measured from the previous frame by auto_level_ch.
//
// PER CHANNEL, NOT GLOBAL -- deliberate.  raw8_2_rgb888 applies a fixed Q4.4
// white balance (currently 16/16/26) BEFORE this point, so the sensor pedestal
// reaches here scaled by 1.625x on blue and 1.0x on red/green: a plain grey
// pedestal has already turned into a blue-tinted one.  A shared lo/gain cannot
// remove that; three independent ones do, and they double as a white balance
// that tracks the scene instead of a constant baked in at compile time.
//
// Pixel path is three registered stages (subtract / multiply / clamp).  The
// multiply is 8x12 and maps to one DSP per channel; everything else -- the
// histograms, the percentile search, the reciprocal lookup, the IIR -- happens
// during vertical blanking and never touches the 150MHz timing.
//
// en低 gives a bit-exact bypass through the same three stages, so toggling it
// cannot shift the picture by a pixel.
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module isp_auto_level #(
parameter [21:0] LO_COUNT = 22'd10368,     // 0.5% of 1920*1080
parameter [21:0] HI_COUNT = 22'd2063232,   // 99.5%
parameter [11:0] GAIN_MAX = 12'd1024       // 4.00x ceiling, keeps shadow noise
                                           // amplification bounded
)(
input  wire        clk,
input  wire        rst_n,
input  wire        en,

input  wire        in_vs,       // HIGH across the visible frame
input  wire        in_de,
input  wire [7:0]  in_r,
input  wire [7:0]  in_g,
input  wire [7:0]  in_b,

output reg         out_vs,
output reg         out_de,
output reg  [7:0]  out_r,
output reg  [7:0]  out_g,
output reg  [7:0]  out_b,

// taps for hist_osd -- lets the bench see the input histogram and the two
// decision points instead of guessing at them
output wire [7:0]  osd_bin_level,
output wire        osd_bin_valid,
output wire [21:0] osd_cnt_r,
output wire [21:0] osd_cnt_g,
output wire [21:0] osd_cnt_b,
output wire [7:0]  osd_lo_g,
output wire [7:0]  osd_hi_g
);

//-------------------------------------------------------------------
// Statistics -- measured on the INPUT, so this is a closed loop on the thing
// that is actually wrong, and the OSD shows the problem rather than the cure.
//-------------------------------------------------------------------
wire [7:0]  lo_r, lo_g, lo_b;
wire [7:0]  hi_r, hi_g, hi_b;
wire [11:0] gain_r, gain_g, gain_b;
wire [7:0]  lvl_r, lvl_g, lvl_b;
wire        vld_r, vld_g, vld_b;

auto_level_ch #(.LO_COUNT(LO_COUNT), .HI_COUNT(HI_COUNT), .GAIN_MAX(GAIN_MAX))
u_ch_r(
    .clk(clk), .rst_n(rst_n),
    .stat_vs(in_vs), .stat_de(in_de), .stat_pix(in_r),
    .lo_out(lo_r), .hi_out(hi_r), .gain_out(gain_r),
    .bin_level(lvl_r), .bin_count(osd_cnt_r), .bin_valid(vld_r)
);

auto_level_ch #(.LO_COUNT(LO_COUNT), .HI_COUNT(HI_COUNT), .GAIN_MAX(GAIN_MAX))
u_ch_g(
    .clk(clk), .rst_n(rst_n),
    .stat_vs(in_vs), .stat_de(in_de), .stat_pix(in_g),
    .lo_out(lo_g), .hi_out(hi_g), .gain_out(gain_g),
    .bin_level(lvl_g), .bin_count(osd_cnt_g), .bin_valid(vld_g)
);

auto_level_ch #(.LO_COUNT(LO_COUNT), .HI_COUNT(HI_COUNT), .GAIN_MAX(GAIN_MAX))
u_ch_b(
    .clk(clk), .rst_n(rst_n),
    .stat_vs(in_vs), .stat_de(in_de), .stat_pix(in_b),
    .lo_out(lo_b), .hi_out(hi_b), .gain_out(gain_b),
    .bin_level(lvl_b), .bin_count(osd_cnt_b), .bin_valid(vld_b)
);

// The three channels run in lockstep off the same vsync, so any one of them
// carries the burst timing for all three.
assign osd_bin_level = lvl_g;
assign osd_bin_valid = vld_g;
assign osd_lo_g      = lo_g;
assign osd_hi_g      = hi_g;

//-------------------------------------------------------------------
// Stage 1 : subtract the black point (saturating at 0)
//-------------------------------------------------------------------
reg [7:0] d1_r, d1_g, d1_b;
reg [7:0] by1_r, by1_g, by1_b;   // bypass copies ride the same pipeline
reg       vs1, de1;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        d1_r <= 8'd0; d1_g <= 8'd0; d1_b <= 8'd0;
        by1_r<= 8'd0; by1_g<= 8'd0; by1_b<= 8'd0;
        vs1  <= 1'b0; de1  <= 1'b0;
    end else begin
        d1_r  <= (in_r > lo_r) ? (in_r - lo_r) : 8'd0;
        d1_g  <= (in_g > lo_g) ? (in_g - lo_g) : 8'd0;
        d1_b  <= (in_b > lo_b) ? (in_b - lo_b) : 8'd0;
        by1_r <= in_r;  by1_g <= in_g;  by1_b <= in_b;
        vs1   <= in_vs; de1   <= in_de;
    end
end

//-------------------------------------------------------------------
// Stage 2 : apply the gain.  8 x 12 -> 20 bits, exactly what the product
// needs (255 * 1024 = 261120, 18 bits used).
//-------------------------------------------------------------------
reg [19:0] p2_r, p2_g, p2_b;
reg [7:0]  by2_r, by2_g, by2_b;
reg        vs2, de2;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        p2_r <= 20'd0; p2_g <= 20'd0; p2_b <= 20'd0;
        by2_r<= 8'd0;  by2_g<= 8'd0;  by2_b<= 8'd0;
        vs2  <= 1'b0;  de2  <= 1'b0;
    end else begin
        p2_r  <= d1_r * gain_r;
        p2_g  <= d1_g * gain_g;
        p2_b  <= d1_b * gain_b;
        by2_r <= by1_r; by2_g <= by1_g; by2_b <= by1_b;
        vs2   <= vs1;   de2   <= de1;
    end
end

//-------------------------------------------------------------------
// Stage 3 : >>8 and clamp.  Anything set above bit 15 means the Q8 result
// passed 255.  With lo=0 and gain=256 this is bit-exact identity.
//-------------------------------------------------------------------
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        out_r <= 8'd0; out_g <= 8'd0; out_b <= 8'd0;
        out_vs<= 1'b0; out_de<= 1'b0;
    end else begin
        out_r  <= en ? ((|p2_r[19:16]) ? 8'hFF : p2_r[15:8]) : by2_r;
        out_g  <= en ? ((|p2_g[19:16]) ? 8'hFF : p2_g[15:8]) : by2_g;
        out_b  <= en ? ((|p2_b[19:16]) ? 8'hFF : p2_b[15:8]) : by2_b;
        out_vs <= vs2;
        out_de <= de2;
    end
end

endmodule
