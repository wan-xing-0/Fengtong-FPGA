//---------------------------------------------------------------------------
// hist_osd -- draws the ISP input histogram over the picture.
//
// WHY
//   Every picture problem on this board so far has been diagnosed by looking
//   at a phone photo of a TV and arguing about what "washed out" means.  That
//   costs a full synthesis + P&R + burn cycle per guess.  This puts the actual
//   256-bin histogram of what the ISP is being fed on screen, plus markers for
//   the two numbers isp_auto_level derived from it, so the next tuning
//   decision is read off the screen instead of inferred.
//
// LAYOUT
//   512 x 256 box at (64,64).  Two screen pixels per bin, bars grow up from
//   the bottom.  R/G/B are drawn in their own colour and overlap additively,
//   so a channel offset (i.e. a white balance error) shows up as three
//   separated humps instead of one.
//
//   Magenta column = the black point isp_auto_level chose (lo).
//   Cyan column    = the white point it chose (hi).
//   Everything between them is what gets stretched across the full 0..255.
//
// SCALE
//   Bar height is logarithmic -- no divider and no per-frame max tracking, the
//   height is just the index of the top set bit.  A linear scale is useless
//   here: 1920x1080 over 256 bins averages 8100 counts per bin, and a bunched
//   histogram peaks two orders of magnitude above that, which would flatten
//   every tail to nothing.  The tails are exactly what matters when the
//   question is "where does the black floor actually sit".
//
//   The first version spread all 22 octaves over the box at 11px each, which
//   overcorrected: a bin holding a SINGLE pixel still drew 11px, so in a phone
//   photo of the TV every bin looked occupied and the shape carried no
//   information.  LOG_FLOOR now discards everything below 2^LOG_FLOOR counts
//   and spreads the octaves above it at PX_PER_OCT each, so a bar means "this
//   bin holds a meaningful share of the frame".
//
//   Sizing at LOG_FLOOR=8: the 8100-count average bin lands at 90px, a bin
//   holding 1% of the frame (20736) at 126px, one holding half the frame at
//   234px.  The worst case, a whole frame in one bin, is 21-8=13 octaves =
//   234px, so nothing overflows the 256px box.
//
// MARKERS AND GRID
//   The lo/hi columns were one bin (2 screen px) wide, too thin to pick out in
//   a phone photo.  MARK_HALF widens each to 2*MARK_HALF+1 bins.  A dim
//   gridline every 32 codes gives the eye something to count against, so a
//   hump reads as "sits around code 96" without a ruler.
//
// Latency 2 clocks, applied equally to data, de and vs.
//---------------------------------------------------------------------------

`timescale 1ns/1ns

//---------------------------------------------------------------------------
// log_height -- PX_PER_OCT pixels per binary octave above a floor.
//
//   k      = index of the most significant set bit, + 1  (0 => bin is empty)
//   height = (k - FLOOR) * PX_PER_OCT, clamped to 0 below the floor
//
// Bins holding fewer than 2^FLOOR counts draw nothing at all.  Without that
// floor a bin holding one single pixel drew a bar a twelfth of the box high
// and the display read as solid.
//---------------------------------------------------------------------------
module log_height #(
parameter [7:0] FLOOR = 8'd8      // octaves below 2^FLOOR are not drawn
)
(
input  wire [21:0] cnt,
output reg  [7:0]  height
);

integer   i;
reg [7:0] k;      // msb index + 1, so 0 means "bin is empty"
reg [7:0] d;      // octaves above the floor

always @(*) begin
    k = 8'd0;
    // later iterations win, which makes this the index of the TOP set bit
    for (i = 0; i < 22; i = i + 1)
        if (cnt[i]) k = i + 1;
    d = (k > FLOOR) ? (k - FLOOR) : 8'd0;
    // d * 18 as shift-and-add: stays LUT logic, never asks for a DSP.
    // Keep it a shift-add if PX_PER_OCT is retuned -- a generic multiply here
    // is small enough that the tool may hand it to a DSP, and DSPs on this
    // part are wanted by the pixel path.
    // d maxes out at 22-8 = 14, so 14*18 = 252 and the 8-bit maths is exact.
    height = (d << 4) + (d << 1);
end

endmodule


module hist_osd #(
parameter [11:0] X0        = 12'd64,
parameter [11:0] X1        = 12'd576,   // X0 + 512
parameter [11:0] Y0        = 12'd64,
parameter [11:0] Y1        = 12'd320,   // Y0 + 256
parameter [7:0]  LOG_FLOOR = 8'd8,      // bins under 2^8 = 256 counts draw nothing
parameter [7:0]  MARK_HALF = 8'd1,      // lo/hi columns are 2*MARK_HALF+1 bins wide
parameter [7:0]  GRID_MASK = 8'd31      // dim gridline wherever (bin & MASK) == 0
)(
input  wire        clk,
input  wire        rst_n,
input  wire        en,

// histogram burst from isp_auto_level, arrives during vertical blanking
input  wire        bin_valid,
input  wire [7:0]  bin_level,
input  wire [21:0] cnt_r,
input  wire [21:0] cnt_g,
input  wire [21:0] cnt_b,
input  wire [7:0]  lo_g,
input  wire [7:0]  hi_g,

// video
input  wire        in_vs,        // HIGH across the visible frame
input  wire        in_de,
input  wire [23:0] in_rgb,       // {R,G,B}

output reg         out_vs,
output reg         out_de,
output reg  [23:0] out_rgb
);

//-------------------------------------------------------------------
// Write side : burst -> bar heights.  Split across three stages so neither
// the 22-bit subtract feeding this nor the priority encoder has to share a
// 150MHz clock period with the RAM write.
//-------------------------------------------------------------------
reg [21:0] cr_a, cg_a, cb_a;
reg [7:0]  lvl_a;
reg        vld_a;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) vld_a <= 1'b0;
    else        vld_a <= bin_valid;
end
always @(posedge clk) begin
    cr_a <= cnt_r; cg_a <= cnt_g; cb_a <= cnt_b;
    lvl_a <= bin_level;
end

wire [7:0] h_r, h_g, h_b;
log_height #(.FLOOR(LOG_FLOOR)) u_lh_r(.cnt(cr_a), .height(h_r));
log_height #(.FLOOR(LOG_FLOOR)) u_lh_g(.cnt(cg_a), .height(h_g));
log_height #(.FLOOR(LOG_FLOOR)) u_lh_b(.cnt(cb_a), .height(h_b));

reg [7:0] hw_r, hw_g, hw_b, addr_w;
reg       we_w;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) we_w <= 1'b0;
    else        we_w <= vld_a;
end
always @(posedge clk) begin
    hw_r <= h_r; hw_g <= h_g; hw_b <= h_b;
    addr_w <= lvl_a;
end

// No reset on the arrays or the output registers -- that is what keeps them
// inferrable as block RAM.
reg [7:0] h_mem_r [0:255];
reg [7:0] h_mem_g [0:255];
reg [7:0] h_mem_b [0:255];

integer k;
initial begin
    for (k = 0; k < 256; k = k + 1) begin
        h_mem_r[k] = 8'd0;
        h_mem_g[k] = 8'd0;
        h_mem_b[k] = 8'd0;
    end
end

always @(posedge clk) begin
    if (we_w) begin
        h_mem_r[addr_w] <= hw_r;
        h_mem_g[addr_w] <= hw_g;
        h_mem_b[addr_w] <= hw_b;
    end
end

//-------------------------------------------------------------------
// Read side : pixel coordinates straight off de/vs
//-------------------------------------------------------------------
reg [11:0] px, py;
reg        de_prev;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        px <= 12'd0; py <= 12'd0; de_prev <= 1'b0;
    end else begin
        de_prev <= in_de;
        if (!in_vs) begin
            // vs is low only during the sync pulse, deep in blanking
            px <= 12'd0;
            py <= 12'd0;
        end
        else if (in_de) begin
            px <= px + 1'b1;
        end
        else begin
            px <= 12'd0;
            if (de_prev) py <= py + 1'b1;   // falling edge of de ends a line
        end
    end
end

wire [11:0] bx     = px - X0;
wire [7:0]  rd_bin = bx[8:1];               // two screen pixels per bin

reg [7:0] q_r, q_g, q_b;
always @(posedge clk) begin
    q_r <= h_mem_r[rd_bin];
    q_g <= h_mem_g[rd_bin];
    q_b <= h_mem_b[rd_bin];
end

reg [23:0] rgb_d1;
reg        vs_d1, de_d1;
reg [11:0] px_d1, py_d1;
reg [7:0]  bin_d1;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        vs_d1 <= 1'b0; de_d1 <= 1'b0;
    end else begin
        vs_d1 <= in_vs; de_d1 <= in_de;
    end
end
always @(posedge clk) begin
    rgb_d1 <= in_rgb;
    px_d1  <= px;  py_d1 <= py;  bin_d1 <= rd_bin;
end

//-------------------------------------------------------------------
// Compose
//-------------------------------------------------------------------
wire in_box = (px_d1 >= X0) && (px_d1 < X1)
           && (py_d1 >= Y0) && (py_d1 < Y1);

wire [11:0] byv = py_d1 - Y0;
wire [7:0]  inv = 8'd255 - byv[7:0];   // 0 at the bottom row of the box

wire bar_r = (inv < q_r);
wire bar_g = (inv < q_g);
wire bar_b = (inv < q_b);
wire any_bar = bar_r | bar_g | bar_b;

// Absolute bin distance rather than a +/- window, so the marker cannot wrap
// around when lo_g sits at 0 or hi_g at 255.
wire [7:0] d_lo = (bin_d1 > lo_g) ? (bin_d1 - lo_g) : (lo_g - bin_d1);
wire [7:0] d_hi = (bin_d1 > hi_g) ? (bin_d1 - hi_g) : (hi_g - bin_d1);
wire near_lo = (d_lo <= MARK_HALF);
wire near_hi = (d_hi <= MARK_HALF);

// Gridline every GRID_MASK+1 codes.  Drawn under the bars, so it marks the
// axis without ever hiding data.
wire grid = ((bin_d1 & GRID_MASK) == 8'd0);

wire [23:0] osd_rgb = near_lo ? 24'hFF00FF :            // black point
                      near_hi ? 24'h00FFFF :            // white point
                      any_bar ? { bar_r ? 8'hFF : 8'h20,
                                  bar_g ? 8'hFF : 8'h20,
                                  bar_b ? 8'hFF : 8'h20 }
                              : (grid ? 24'h505050 : 24'h202020);

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        out_rgb <= 24'd0;
        out_vs  <= 1'b0;
        out_de  <= 1'b0;
    end else begin
        out_rgb <= (en && in_box) ? osd_rgb : rgb_d1;
        out_vs  <= vs_d1;
        out_de  <= de_d1;
    end
end

endmodule
