//---------------------------------------------------------------------------
// auto_level_ch -- per-frame black/white point measurement for ONE channel.
//
// WHY THIS EXISTS
//   The ISP chain had black-level subtraction but no white-point stretch (the
//   earlier note in system_top says "subtract only, no re-stretch"), so the
//   picture kept a permanent haze: subtracting a pedestal makes the frame
//   darker without making it any more contrasty.  Worse, the sRGB encode
//   downstream maps code 16 to 71, i.e. a pedestal that survives into the
//   encode becomes a 28% grey floor -- turning the gamma switch ON made the
//   fog worse, not better, which is exactly what the bench photos showed.
//
//   Exposure cannot rescue this either: ae_set's O_ae_req never asserts (I_btn
//   is tied high), so exposure sits frozen at ~1123 of 1127 lines -- already
//   essentially the full frame time.  There is no headroom left upstream, so
//   the correction has to be digital and it has to be measured, not guessed.
//
// WHAT IT DOES
//   Reuses the proven hist_stat block (same one color_convert's HISTEQ uses)
//   to get a 256-bin histogram plus its running CDF once per frame, picks the
//   LO_COUNT / HI_COUNT percentiles off the CDF, and hands out a black point
//   and a Q8 gain.  The caller applies out = (in - lo) * gain >> 8.
//
//   Percentiles rather than min/max: a percentile lands on the fog floor when
//   the frame has no true black, and lands on ~0 when it does, which is the
//   behaviour wanted in both cases.  Min/max would be set by a single hot
//   pixel or specular highlight.
//
// SAFETY
//   Everything here runs during vertical blanking, never in the pixel path.
//   Reset state is lo=0 / gain=256 (identity), and a range narrower than 16
//   codes also collapses to identity -- so if the statistics are wrong or have
//   not settled, the picture degrades to "unchanged", never to garbage.
//
// TIMING NOTE
//   hist_stat wants img_vsync HIGH across the visible frame; it reads out and
//   clears on the falling edge.  Fed from the camera-side vsync, that edge
//   lands ~35 lines deep in vertical blanking, and readout is 256+6 clocks --
//   about 300x of margin.
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module auto_level_ch #(
parameter [21:0] LO_COUNT  = 22'd10368,     // 0.5% of 1920*1080
parameter [21:0] HI_COUNT  = 22'd2063232,   // 99.5%
parameter [11:0] GAIN_MAX  = 12'd1024,      // 4.00x in Q8 (256 = 1.00x)
parameter        SMOOTH_SH = 2              // frame-to-frame IIR, 1/4 step
)(
input  wire        clk,
input  wire        rst_n,

input  wire        stat_vs,     // HIGH across the visible frame
input  wire        stat_de,
input  wire [7:0]  stat_pix,    // channel value being measured

output reg  [7:0]  lo_out,      // smoothed black point
output reg  [7:0]  hi_out,      // smoothed white point (OSD marker only)
output reg  [11:0] gain_out,    // smoothed gain, Q8

// histogram tap for the on-screen display
output wire [7:0]  bin_level,
output wire [21:0] bin_count,
output wire        bin_valid
);

//-------------------------------------------------------------------
// 256-bin histogram + CDF, one readout burst per frame
//-------------------------------------------------------------------
wire [7:0]  pixel_level;
wire [21:0] pixel_level_acc_num;
wire        pixel_level_valid;

hist_stat u_hist_stat(
    .clk                 ( clk                 ),
    .rst_n               ( rst_n               ),
    .img_vsync           ( stat_vs             ),
    .img_href            ( stat_de             ),
    .img_gray            ( stat_pix            ),
    .pixel_level         ( pixel_level         ),
    .pixel_level_acc_num ( pixel_level_acc_num ),
    .pixel_level_valid   ( pixel_level_valid   )
);

// hist_stat hands out the CDF; the OSD wants the per-bin count, which is just
// the first difference.  Level 0 is the first beat of a burst, so acc_prev is
// still holding last frame's tail there and has to be ignored.
reg [21:0] acc_prev;
always @(posedge clk) begin
    if (pixel_level_valid) acc_prev <= pixel_level_acc_num;
end

assign bin_level = pixel_level;
assign bin_valid = pixel_level_valid;
assign bin_count = (pixel_level == 8'd0) ? pixel_level_acc_num
                                         : (pixel_level_acc_num - acc_prev);

//-------------------------------------------------------------------
// Percentile search across the readout burst
//-------------------------------------------------------------------
reg [7:0] lo_raw, hi_raw;
reg       lo_done, hi_done;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        lo_raw  <= 8'd0;
        hi_raw  <= 8'd255;
        lo_done <= 1'b0;
        hi_done <= 1'b0;
    end
    else if (pixel_level_valid) begin
        if (pixel_level == 8'd0) begin
            // first beat of a burst: arm the search, and handle the case where
            // bin 0 alone already carries the whole percentile
            lo_raw  <= 8'd0;
            lo_done <= (pixel_level_acc_num >= LO_COUNT);
            hi_raw  <= (pixel_level_acc_num >= HI_COUNT) ? 8'd0 : 8'd255;
            hi_done <= (pixel_level_acc_num >= HI_COUNT);
        end
        else begin
            if (!lo_done && (pixel_level_acc_num >= LO_COUNT)) begin
                lo_raw  <= pixel_level;
                lo_done <= 1'b1;
            end
            if (!hi_done && (pixel_level_acc_num >= HI_COUNT)) begin
                hi_raw  <= pixel_level;
                hi_done <= 1'b1;
            end
        end
    end
end

//-------------------------------------------------------------------
// Range -> gain -> IIR, spread over three clocks.
//
// Done in one combinational lump this would be subtract -> compare -> mux ->
// 256-entry LUT -> compare -> mux -> subtract -> shift -> add -> mux, which is
// easily the longest path in the design and would land on the 150MHz pixel
// clock for no reason: it only has to produce an answer once per frame, and
// the vertical sync pulse alone is ~11000 clocks wide.  So it gets pipelined
// on a walking commit strobe and stays far away from timing closure.
//
// The last beat of the readout burst is level 255; lo_raw/hi_raw settle one
// clock after that, which is exactly when cm1 arrives.
//-------------------------------------------------------------------
reg cm1, cm2, cm3;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        cm1 <= 1'b0; cm2 <= 1'b0; cm3 <= 1'b0;
    end else begin
        cm1 <= pixel_level_valid & (pixel_level == 8'd255);
        cm2 <= cm1;
        cm3 <= cm2;
    end
end

// --- c1 : latch the percentiles.  A degenerate range collapses to identity
// rather than to a huge gain, so a flat scene or an unsettled first frame
// changes nothing instead of exploding.
wire [7:0] range_raw  = (hi_raw > lo_raw) ? (hi_raw - lo_raw) : 8'd0;
wire       degenerate = (range_raw < 8'd16);

reg [7:0] range_q, lo_q, hi_q;
always @(posedge clk) begin
    if (cm1) begin
        range_q <= degenerate ? 8'd255 : range_raw;
        lo_q    <= degenerate ? 8'd0   : lo_raw;
        hi_q    <= degenerate ? 8'd255 : hi_raw;
    end
end

// --- c2 : reciprocal lookup
wire [11:0] gain_lut;
Recip_Gain u_recip(.range(range_q), .gain(gain_lut));

reg [11:0] gain_q;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n)   gain_q <= 12'd256;
    else if (cm2) gain_q <= (gain_lut > GAIN_MAX) ? GAIN_MAX : gain_lut;
end

// --- c3 : frame-to-frame IIR.  Without it the gain pumps visibly whenever
// anything moves through the frame.  The +1 term keeps the step from stalling
// on small differences, so it converges exactly instead of parking a few codes
// short of the target.
wire [7:0]  lo_delta = (lo_q > lo_out) ? (lo_q - lo_out) : (lo_out - lo_q);
wire [7:0]  lo_step  = (lo_delta >> SMOOTH_SH) + 8'd1;
wire [7:0]  lo_next  = (lo_q == lo_out) ? lo_out
                     : (lo_q >  lo_out) ? (lo_out + lo_step)
                                        : (lo_out - lo_step);

wire [7:0]  hi_delta = (hi_q > hi_out) ? (hi_q - hi_out) : (hi_out - hi_q);
wire [7:0]  hi_step  = (hi_delta >> SMOOTH_SH) + 8'd1;
wire [7:0]  hi_next  = (hi_q == hi_out) ? hi_out
                     : (hi_q >  hi_out) ? (hi_out + hi_step)
                                        : (hi_out - hi_step);

wire [11:0] gn_delta = (gain_q > gain_out) ? (gain_q - gain_out)
                                           : (gain_out - gain_q);
wire [11:0] gn_step  = (gn_delta >> SMOOTH_SH) + 12'd1;
wire [11:0] gn_next  = (gain_q == gain_out) ? gain_out
                     : (gain_q >  gain_out) ? (gain_out + gn_step)
                                            : (gain_out - gn_step);

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        lo_out   <= 8'd0;
        hi_out   <= 8'd255;
        gain_out <= 12'd256;   // identity
    end
    else if (cm3) begin
        lo_out   <= lo_next;
        hi_out   <= hi_next;
        gain_out <= gn_next;
    end
end

endmodule
