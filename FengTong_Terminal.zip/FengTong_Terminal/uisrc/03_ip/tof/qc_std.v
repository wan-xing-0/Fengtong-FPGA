//---------------------------------------------------------------------------
// qc_std -- 10-20: one "any size" mode + three standard workpieces on the
// inspection (BOX) page: the 工件 / 体积 / 判定 rows (text_osd STD_ROWS).
//
// WHAT (user, 10-20).  The affine key (key3) has nothing to do in BOX --
// affine_transform is forced to pass there so the boxes are measured on the
// real picture -- so in BOX it cycles this module's mode:
//     0 任意    any object: W x H x Z and the BOUNDING-BOX volume (外接);
//               no verdict
//     1 方块    P1, 60 x 60 x 30, a 60 x 60 face to the camera
//     2 圆柱    P2, D60 x 30 lying with a FLAT END to the camera (10-28,
//               user; was standing on its end, side to the camera): the
//               camera sees a D x D circle, Z is the length 30.  Like 方块:
//               the ToF ranges a flat face, so wherever its spot lands the
//               depth is the same, and the face it ranges IS the plane the
//               silhouette lies in -- no radius correction (w_depth_mm 0).
//     3 三棱柱  P5, side 60, 30 long, a triangle face to the camera: the box
//               is 60 x 52, Z = 30
// (tools/qc_parts/drawings/工件参数.md).  The camera looks horizontally at
// the backdrop: W / H are the face it sees, Z = backdrop - front face
// (qc_thick), part against the backdrop.  The nominal is shown in that same
// W x H x Z order so the 工件 row reads straight against the 尺寸 row.
//
// VOLUME (cm3, rounded):  任意 / 方块  W*H*Z;  圆柱  pi/4 * W*H * Z (the
// end face is a circle of diameter W = H; both measured diameters are used,
// so an ellipse-shaped error averages);  三棱柱  W*H/2 * Z (a triangle standing on its
// base has area base x height / 2 whatever its shape, so the box is enough).
//
// VERDICT (modes 1..3, only while qc_stable): every axis within tolerance =
// 合格, else 不合格 + the axis with the largest excess (宽 / 高 / 厚 = W / H
// / Z) and its signed deviation from nominal, e.g. "不合格 厚-13".
// TOL_XY_MM 3: once calibrated XY is ~1 mm (0.1 mm / px at 15 cm; the error
// is the distance).  TOL_Z_MM 5: Z is two ToF readings and a cloth backdrop.
// The parts are printed to +-0.5.  Not stable: "测量中".  Mode 0: "---".
// ⭐ 10-28 (user's demo: a good cube, a cube of other size = 不合格, a cube
// with a black dot = 不合格 by stain): `stain` (stain_detect's voted
// stain_out) also fails the part.  Size first -- a part out of size shows the
// axis as before; in size but stained shows "不合格 污渍".  Mode 1 is now
// named 标准件 (it is still P1, the 60 x 60 x 30 cube), and system_top's key
// only cycles 0 <-> 1; modes 2 / 3 stay here, unreached.
//
// TIMING.  Inputs snapshot on pub_stb -- the clock qc_thick snapshots the 尺寸
// row's text on, so the verdict judges exactly the numbers on screen.  A mode
// change re-runs on the last snapshot, so the rows follow the key at once.
// The arithmetic is serial (shift-add multiplies, a double-dabble): ~30..70
// clocks per run, no DSP, nothing deeper than one adder; frames are 5 M
// clocks apart.  All three texts publish on ONE clock (a reader sampling
// mid-update would otherwise pair a new 工件 with an old 判定).
//
// ⭐ 10-30 (user, final demo): the standard part is judged on COLOUR and
// SHAPE too, and every failing reason is listed, not just the first:
//     判定  合格 / 不合格 [厚-13] / 测量中        (judge_text, as before but the
//                                                stain no longer shares it)
//     原因  颜色 形状 尺寸 污渍                    (reason_text: the failing ones,
//                                                in this order, blank if none)
// Colour = obj_color_detect's stable_id, accepted iff STD_COLOR_MASK has its
// bit (default 白 only); shape = shape_vote's class, which must be the mode's
// own (方块 RECT / 圆柱 CIRCLE / 三棱柱 TRI).  Both snapshot on pub_stb with
// the numbers.  A part that is stable but has no colour (15) or no confident
// shape vote yet reads 测量中 -- it is waiting to be classified, not passed.
// CS_JUDGE = 0: colour / shape ignored (the 10-28 verdict; the stain then
// shows in 原因 rather than in 判定).
//
// OSD fields, 13 chars each (the row is a 3-cell label + 13):
//   part_text   "任意" / "标准件 60X60X30" / "圆柱 60X60X30" / "三棱柱 60X52X30"
//   vol_text    "  108CM3"  (+ " 外接" in mode 0)  or  "  ---"
//   judge_text  "合格" / "不合格 厚-13" / "不合格" / "测量中" / "---"
//   reason_text "颜色 形状 尺寸 污渍" (the failing ones) / blank
// Chinese codes >= 0x80 and 0x01..0x1F (the second table) are
// tools/gen_cn_font.py's -- the CN_* list below must match it.
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module qc_std #(
parameter integer TOL_XY_MM = 3,
parameter integer TOL_Z_MM  = 5,
// W x H x Z as the camera sees each standard part
parameter integer P1_W = 60,  parameter integer P1_H = 60,  parameter integer P1_Z = 30,   // 方块
parameter integer P2_W = 60,  parameter integer P2_H = 60,  parameter integer P2_Z = 30,   // 圆柱 (10-28: end face on)
parameter integer P3_W = 60,  parameter integer P3_H = 52,  parameter integer P3_Z = 30,   // 三棱柱
parameter integer CS_JUDGE = 1,                // 10-30: colour + shape are part of the verdict
parameter [15:0]  STD_COLOR_MASK = 16'h0004,   // obj_color classes that pass: bit 2 = 白
parameter [15:0]  STD_COLOR_MASK3 = 16'h0030   // 10-31: mode 3 (三棱柱, the yellow part): 5 黄 + 4 橙
)(
input  wire         clk,
input  wire         rst_n,
input  wire [1:0]   mode,          // 0 任意, 1 方块, 2 圆柱, 3 三棱柱
input  wire         pub_stb,       // tof_size's publish strobe
input  wire         stable,        // qc_thick's qc_stable
input  wire         stain,         // 10-28: stain_detect's stain_out (level)
input  wire [15:0]  w_mm,          // tof_size's size_w_mm
input  wire [15:0]  h_mm,
input  wire [15:0]  z_mm,          // qc_thick's thick_mm
input  wire [3:0]   color,         // 10-30: obj_color_detect stable_id (15 = none)
input  wire [1:0]   shape,         // 10-30: shape_vote class (0 other 1 circle 2 rect 3 tri)
input  wire         shape_v,       //        ... and its valid
output reg  [103:0] part_text,
output reg  [103:0] vol_text,
output reg  [103:0] judge_text,
output reg  [103:0] reason_text,   // 10-30
output reg          judge_valid,   // mode 1..3 and stable
output reg          judge_pass,
// 10-20: -> tof_size's w_add_mm.  Was the radius in 圆柱 (side on, the width
// silhouette lay at the axis, behind the front the ToF ranges).  10-28: end
// face on, the silhouette is the ranged face itself -> 0 in every mode.  The
// port stays so tof_size and system_top are untouched.
output reg  [7:0]   w_depth_mm
);

localparam [7:0] CN_CE    = 8'h82, CN_ZHONG = 8'h93, CN_BU   = 8'h9C, CN_LIANG = 8'h9F,
                 CN_HOU   = 8'hA3, CN_FANG2 = 8'hB4, CN_GAO  = 8'hC1, CN_KUAI  = 8'hE7,
                 CN_REN2  = 8'h01, CN_YI3   = 8'h02, CN_YUAN4 = 8'h03, CN_ZHU  = 8'h04,
                 CN_SAN2  = 8'h05, CN_LENG  = 8'h06, CN_HE   = 8'h0A, CN_GE    = 8'h0B,
                 CN_WAI   = 8'h0C, CN_JIE   = 8'h0D, CN_KUAN = 8'h0E,
                 CN_BIAO  = 8'hE3, CN_ZHUN3 = 8'h11, CN_JIAN2 = 8'h98,   // 10-28 标准件
                 CN_STAIN = 8'hBF, CN_ZI4   = 8'h0F,                     // 10-28 污渍
                 CN_YAN2  = 8'hEC, CN_SE    = 8'hB0, CN_XING = 8'h1B,    // 10-30 颜色 形
                 CN_ZHUANG = 8'h1F, CN_CHI  = 8'h85, CN_CUN  = 8'h86;    //       状 尺寸
localparam [7:0] SP = 8'h20;

//---------------------------------------------------------------------------
// 工件 field.  Built from the parameters by functions called with constants
// only, so it folds to four constant strings and a 4:1 mux.
//---------------------------------------------------------------------------
function [103:0] app;                    // shift one char in on the right
    input [103:0] s; input [7:0] c;
    app = {s[95:0], c};
endfunction

function [103:0] app_n;                  // v as 1..3 digits, no leading zeros
    input [103:0] s; input integer v;
    begin
        app_n = s;
        if (v >= 100) app_n = app(app_n, 8'h30 + (v / 100) % 10);
        if (v >= 10)  app_n = app(app_n, 8'h30 + (v / 10) % 10);
        app_n = app(app_n, 8'h30 + v % 10);
    end
endfunction

function integer len_n;
    input integer v;
    len_n = (v >= 100) ? 3 : (v >= 10) ? 2 : 1;
endfunction

// nn (2 or 3) glyphs from nm, a space, "AXBXC", padded to 13 with spaces
function [103:0] part_str;
    input [23:0] nm; input integer nn;
    input integer a, b, c;
    reg [103:0] s; integer n, i;
    begin
        s = 104'd0;
        if (nn == 3) s = app(s, nm[23:16]);
        s = app(s, nm[15:8]); s = app(s, nm[7:0]); s = app(s, SP);
        s = app_n(s, a); s = app(s, "X"); s = app_n(s, b); s = app(s, "X"); s = app_n(s, c);
        n = nn + 3 + len_n(a) + len_n(b) + len_n(c);
        for (i = 0; i < 13; i = i + 1)
            if (i >= n) s = app(s, SP);
        part_str = s;
    end
endfunction

function [9:0] clamp999;
    input [15:0] v;
    clamp999 = (v > 16'd999) ? 10'd999 : v[9:0];
endfunction

//---------------------------------------------------------------------------
// Snapshot.  n_* are the next run's inputs; the run copies them into c_* at
// its start, so a pub_stb arriving mid-run cannot change a run's operands.
//---------------------------------------------------------------------------
reg  [9:0] n_w, n_h, n_z;
reg        n_ok, n_st;
reg  [3:0] n_col;
reg  [1:0] n_shp;
reg        n_shv;
reg  [1:0] r_mode;
reg        pend;
wire       start;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        n_w <= 10'd0; n_h <= 10'd0; n_z <= 10'd0; n_ok <= 1'b0; n_st <= 1'b0;
        n_col <= 4'd15; n_shp <= 2'd0; n_shv <= 1'b0;
        r_mode <= 2'd0; pend <= 1'b1; w_depth_mm <= 8'd0;
    end else begin
        r_mode <= mode;
        w_depth_mm <= 8'd0;              // 10-28: was (mode == 2'd2) ? P2_W / 2 : 0
        if (start) pend <= 1'b0;
        if (mode != r_mode) pend <= 1'b1;
        if (pub_stb) begin
            n_w <= clamp999(w_mm); n_h <= clamp999(h_mm); n_z <= clamp999(z_mm);
            n_ok <= stable; n_st <= stain; pend <= 1'b1;
            n_col <= color; n_shp <= shape; n_shv <= shape_v;
        end
    end
end

//---------------------------------------------------------------------------
// Volume: serial multiplies into acc, then +500 and a 30-bit double-dabble;
// cm3 = the decimal digits above the units of mm3.
//   step 0: W*H   step 1: *Z   step 2 (圆柱 only): *3217 >> 12
//   (pi/4 = 0.785398, 3217/4096 = 0.785400).  Max 999^3 * 3217 < 2^42.
//---------------------------------------------------------------------------
localparam [2:0] F_IDLE = 3'd0, F_MUL = 3'd1, F_NEXT = 3'd2, F_BCD = 3'd3, F_PUB = 3'd4;

reg  [2:0]  st;
reg  [1:0]  step;
reg  [1:0]  c_mode;
reg  [9:0]  c_w, c_h, c_z;
reg         c_ok, c_st;
reg  [3:0]  c_col;
reg  [1:0]  c_shp;
reg         c_shv;
reg  [43:0] ma, acc;
reg  [11:0] mb;
reg  [29:0] bin;
reg  [35:0] bcd;
reg  [4:0]  bi;

assign start = (st == F_IDLE) && pend;

function [35:0] dd_adj;                  // double-dabble: +3 to every digit >= 5
    input [35:0] b;
    integer k;
    begin
        dd_adj = b;
        for (k = 0; k < 9; k = k + 1)
            if (dd_adj[4*k +: 4] >= 4'd5) dd_adj[4*k +: 4] = dd_adj[4*k +: 4] + 4'd3;
    end
endfunction

wire [35:0] bcd_a = dd_adj(bcd);
// the run's volume in mm3, before rounding (step 1 / 2 results)
wire [43:0] v_mm3 = (c_mode == 2'd2) ? (acc >> 12) : (c_mode == 2'd3) ? (acc >> 1) : acc;

//---------------------------------------------------------------------------
// Verdict: a free-running pipeline on c_*.  c_* hold for the whole run (at
// least the 30 double-dabble clocks), so it has settled long before F_PUB.
//---------------------------------------------------------------------------
reg  signed [10:0] dw, dh, dz;           // measured - nominal
reg         [10:0] aw, ah, az;           // |d|
reg  signed [11:0] ew, eh, ez;           // |d| - tolerance: > 0 = out
reg                fail;
reg         [1:0]  wax;                  // worst axis: 0 W, 1 H, 2 Z
reg  signed [10:0] wd;                   // its deviation
reg         [6:0]  wm;                   // |wd| clamped to 99
reg         [3:0]  wt, wo;               // tens, ones

wire [9:0] nw = (c_mode == 2'd1) ? P1_W : (c_mode == 2'd2) ? P2_W : P3_W;
wire [9:0] nh = (c_mode == 2'd1) ? P1_H : (c_mode == 2'd2) ? P2_H : P3_H;
wire [9:0] nz = (c_mode == 2'd1) ? P1_Z : (c_mode == 2'd2) ? P2_Z : P3_Z;
wire [14:0] wm205 = wm * 8'd205;         // /10 for 0..99: (v * 205) >> 11

always @(posedge clk) begin
    dw <= $signed({1'b0, c_w}) - $signed({1'b0, nw});
    dh <= $signed({1'b0, c_h}) - $signed({1'b0, nh});
    dz <= $signed({1'b0, c_z}) - $signed({1'b0, nz});
    aw <= dw[10] ? -dw : dw;
    ah <= dh[10] ? -dh : dh;
    az <= dz[10] ? -dz : dz;
    ew <= $signed({1'b0, aw}) - TOL_XY_MM;
    eh <= $signed({1'b0, ah}) - TOL_XY_MM;
    ez <= $signed({1'b0, az}) - TOL_Z_MM;
    fail <= (ew > 0) || (eh > 0) || (ez > 0);
    if ((ew >= eh) && (ew >= ez))  begin wax <= 2'd0; wd <= dw; end
    else if (eh >= ez)             begin wax <= 2'd1; wd <= dh; end
    else                           begin wax <= 2'd2; wd <= dz; end
    wm <= wd[10] ? ((-wd > 11'sd99) ? 7'd99 : -wd) : ((wd > 11'sd99) ? 7'd99 : wd[6:0]);
    wt <= wm205[14:11];
    wo <= wm - wm205[14:11] * 4'd10;
end

// 10-30: colour / shape.  Settled long before F_PUB like the above (c_* hold).
wire [1:0] ns     = (c_mode == 2'd2) ? 2'd1 : (c_mode == 2'd3) ? 2'd3 : 2'd2;   // the mode's shape
wire       cs_wait = (CS_JUDGE != 0) && ((c_col == 4'd15) || !c_shv);           // not classified yet
wire [15:0] cmask = (c_mode == 2'd3) ? STD_COLOR_MASK3 : STD_COLOR_MASK;   // 10-31
wire       f_col  = (CS_JUDGE != 0) && !cmask[c_col];
wire       f_shp  = (CS_JUDGE != 0) && (c_shp != ns);
wire       f_any  = f_col || f_shp || fail || c_st;

// the failing reasons, packed left in a fixed order, a blank after each
function [103:0] why_str;
    input fc, fs, fz, ft;
    reg [103:0] r; integer n, i;
    begin
        r = 104'd0; n = 0;
        if (fc) begin r = app(app(app(r, CN_YAN2),  CN_SE),  SP); n = n + 3; end
        if (fs) begin r = app(app(app(r, CN_XING),  CN_ZHUANG), SP); n = n + 3; end
        if (fz) begin r = app(app(app(r, CN_CHI),   CN_CUN), SP); n = n + 3; end
        if (ft) begin r = app(app(app(r, CN_STAIN), CN_ZI4), SP); n = n + 3; end
        for (i = 0; i < 13; i = i + 1)
            if (i >= n) r = app(r, SP);
        why_str = r;
    end
endfunction

//---------------------------------------------------------------------------
// The run.
//---------------------------------------------------------------------------
wire [3:0] d8 = bcd[35:32], d7 = bcd[31:28], d6 = bcd[27:24], d5 = bcd[23:20],
           d4 = bcd[19:16], d3 = bcd[15:12];
wire       ovf = (d8 != 4'd0);           // >= 100000 cm3: show 99999
wire       b7 = (d7 == 4'd0), b6 = b7 && (d6 == 4'd0), b5 = b6 && (d5 == 4'd0),
           b4 = b5 && (d4 == 4'd0);
function [7:0] dg;                       // digit, or a space where blanked
    input [3:0] d; input blank;
    dg = blank ? SP : (8'h30 + d);
endfunction
wire [39:0] vol5 = ovf ? "99999"
                 : {dg(d7, b7), dg(d6, b6), dg(d5, b5), dg(d4, b4), dg(d3, 1'b0)};
wire [7:0]  ax_c = (wax == 2'd0) ? CN_KUAN : (wax == 2'd1) ? CN_GAO : CN_HOU;
wire [7:0]  sg_c = wd[10] ? "-" : "+";
wire [23:0] dev3 = (wt == 4'd0) ? {sg_c, 8'h30 + wo, SP} : {sg_c, 8'h30 + wt, 8'h30 + wo};

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        st <= F_IDLE; step <= 2'd0; c_mode <= 2'd0;
        c_w <= 10'd0; c_h <= 10'd0; c_z <= 10'd0; c_ok <= 1'b0; c_st <= 1'b0;
        c_col <= 4'd15; c_shp <= 2'd0; c_shv <= 1'b0;
        reason_text <= {13{SP}};
        ma <= 44'd0; acc <= 44'd0; mb <= 12'd0; bin <= 30'd0; bcd <= 36'd0; bi <= 5'd0;
        part_text  <= {CN_REN2, CN_YI3, {11{SP}}};
        vol_text   <= {"  ---", {8{SP}}};
        judge_text <= {"---", {10{SP}}};
        judge_valid <= 1'b0; judge_pass <= 1'b0;
    end else begin
        case (st)
        F_IDLE: if (start) begin
            c_mode <= mode; c_w <= n_w; c_h <= n_h; c_z <= n_z; c_ok <= n_ok; c_st <= n_st;
            c_col <= n_col; c_shp <= n_shp; c_shv <= n_shv;
            ma <= {34'd0, n_w}; mb <= {2'b00, n_h}; acc <= 44'd0;
            step <= 2'd0; st <= F_MUL;
        end
        F_MUL: if (mb == 12'd0) st <= F_NEXT;
        else begin
            if (mb[0]) acc <= acc + ma;
            ma <= ma << 1;
            mb <= mb >> 1;
        end
        F_NEXT: if (step == 2'd0) begin
            ma <= acc; acc <= 44'd0; mb <= {2'b00, c_z};   // 10-28: 圆柱 too (was c_w)
            step <= 2'd1; st <= F_MUL;
        end else if (step == 2'd1 && c_mode == 2'd2) begin
            ma <= acc; acc <= 44'd0; mb <= 12'd3217;
            step <= 2'd2; st <= F_MUL;
        end else begin
            bin <= v_mm3[29:0] + 30'd500; bcd <= 36'd0; bi <= 5'd0;
            st <= F_BCD;
        end
        F_BCD: begin
            bcd <= {bcd_a[34:0], bin[29]};
            bin <= bin << 1;
            bi  <= bi + 5'd1;
            if (bi == 5'd29) st <= F_PUB;
        end
        F_PUB: begin
            st <= F_IDLE;
            case (c_mode)
            2'd0:    part_text <= {CN_REN2, CN_YI3, {11{SP}}};
            2'd1:    part_text <= part_str({CN_BIAO, CN_ZHUN3, CN_JIAN2}, 3, P1_W, P1_H, P1_Z);
            2'd2:    part_text <= part_str({8'h00, CN_YUAN4, CN_ZHU},  2, P2_W, P2_H, P2_Z);
            default: part_text <= part_str({CN_SAN2, CN_LENG, CN_ZHU}, 3, P3_W, P3_H, P3_Z);
            endcase
            if (!c_ok)
                vol_text <= {"  ---", {8{SP}}};
            else if (c_mode == 2'd0)
                vol_text <= {vol5, "CM3", SP, CN_WAI, CN_JIE, SP, SP};
            else
                vol_text <= {vol5, "CM3", {5{SP}}};
            if (c_mode == 2'd0)
                judge_text <= {"---", {10{SP}}};
            else if (!c_ok || cs_wait)                       // 10-30: + not classified yet
                judge_text <= {CN_CE, CN_LIANG, CN_ZHONG, {10{SP}}};
            else if (fail)
                judge_text <= {CN_BU, CN_HE, CN_GE, SP, ax_c, dev3, {5{SP}}};
            else if (f_any)                                  // 10-30: the reasons are in 原因
                judge_text <= {CN_BU, CN_HE, CN_GE, {10{SP}}};
            else
                judge_text <= {CN_HE, CN_GE, {11{SP}}};
            reason_text <= ((c_mode != 2'd0) && c_ok && !cs_wait && f_any)
                         ? why_str(f_col, f_shp, fail, c_st) : {13{SP}};
            judge_valid <= (c_mode != 2'd0) && c_ok && !cs_wait;
            judge_pass  <= (c_mode != 2'd0) && c_ok && !cs_wait && !f_any;
        end
        default: st <= F_IDLE;
        endcase
    end
end

endmodule
