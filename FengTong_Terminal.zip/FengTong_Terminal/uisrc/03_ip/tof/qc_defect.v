//---------------------------------------------------------------------------
// qc_defect -- surface-defect check for the BOX (quality inspection) mode.
//
// IDEA  Use the workpiece itself as the reference.  The picture is cut into
//   16x16 px cells; each cell gets mean R/G/B, an edge count and a mask
//   coverage (how much of it det_binarize called "object").  A second pass,
//   one frame later and off the pixel path, takes the cells that are inside
//   the object, computes their mean, throws away the cells that disagree and
//   recomputes (ROUNDS=2), then flags cells that:
//     HOLE   are inside the object's outline but the mask is missing (a hole
//            or a deep dent shows the dark table; also a very dark stain the
//            mask dropped -- the camera cannot tell those apart, a ranger can)
//     STAIN  are in the mask but differ from the mean in brightness / colour
//     EDGE   are in the mask, same colour, but carry far more edges (scratch,
//            crack, rough patch)
//   Nothing is compared with a stored golden image, so the part may sit
//   anywhere and at any angle, and global brightness changes cancel.
//
// WHAT "INSIDE" MEANS  A cell is interior when, in its own cell row AND cell
//   column, it lies strictly between the first and last mask-covered cell
//   (MARGIN cells in).  That fills holes (a hole is still inside the row's
//   span) and works for circles; the margin keeps the outline's partly
//   covered cells from reading as defects.
//
// WHY ONE FRAME LATER  Accumulation writes ping-pong banks (one bank per
//   frame parity); the judge reads the finished bank while the next frame
//   accumulates into the other one.  The judge is ~5 sweeps of the cell RAM
//   (~45k clocks for 1080p, a frame is 2.2M), so nothing here is time
//   critical and nothing is combinational across more than a few adders.
//
// STREAMS  Two independent pixel streams, each counted by its own de/vs:
//   colour  in_*   what the picture shows (gamma/auto-level output)
//   mask    m_*    det_binarize's bit, which is a few lines later than colour.
//   Each stream toggles its own bank on its own vs rising edge.  The judge
//   starts on the MASK stream's next vs rising edge: the mask bank just
//   completed is the old m_bank, and because colour leads, the colour bank
//   just completed is ~c_bank -- so reset releasing mid-frame (which can leave
//   the two parities off by one) cannot pair frame k with frame k-1.  vs is a sync pulse, not
//   a frame-valid window (see fpga_vs_is_sync_pulse) -- only its rising edge
//   is used, rows are counted on de falling edges.
//
// OUTPUT  def_* are registered on def_stb (one clk) and then held.
//   def_bad is debounced: it changes only after CONFIRM judgements in a row
//   disagree with it.  ovl_flag is a 1-bit sync read port of the published
//   flag map for an overlay (cell index = cy*NCX + cx, 1 clk latency).
//
// PARAMETER NOTES (all thresholds are on 8-bit cell means)
//   ON_T   mask coverage (of 256 px) that counts as "object" for a cell
//   TY/TC  stain: |dY| or |dR|+|dG|+|dB| from the interior mean
//   TE     edge-count excess (of 256 px)
//   EDGE_T horizontal luminance step that counts as an edge pixel
//   CAW    must be ceil(log2(NCX*NCY)) -- 13 for 1080p
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module qc_defect #(
parameter integer IMG_HDISP = 1920,
parameter integer IMG_VDISP = 1080,
parameter integer CAW       = 13,
parameter integer ON_T      = 192,
parameter integer TY        = 24,
parameter integer TC        = 64,
parameter integer TE        = 40,
parameter integer EDGE_T    = 16,
parameter integer MARGIN    = 1,
parameter integer ROUNDS    = 2,      // 1 or 2
parameter integer MIN_INT   = 16,     // interior cells needed to call it an object
parameter integer MIN_DEF   = 2,      // flagged cells needed to call it bad
parameter integer CONFIRM   = 3
)(
input  wire        clk,
input  wire        rst_n,
input  wire        en,

input  wire        in_vs,
input  wire        in_de,
input  wire [7:0]  in_r,
input  wire [7:0]  in_g,
input  wire [7:0]  in_b,

input  wire        m_vs,
input  wire        m_de,
input  wire        m_bin,

output reg         def_stb,
output reg         def_obj,
output reg         def_bad,
output reg  [15:0] def_cnt,
output reg  [15:0] def_hole,
output reg  [15:0] def_stain,
output reg  [15:0] def_edge,
output reg  [11:0] def_x0,
output reg  [11:0] def_y0,
output reg  [11:0] def_x1,
output reg  [11:0] def_y1,
output reg  [15:0] def_int,
output reg  [79:0] def_text,      // 10 OSD chars, see OSD TEXT below
// 10-09: the interior reference the judgement used -- mean R/G/B of the
// object's cells after the outlier round, i.e. the workpiece's own colour
// with the defects taken out.  0 when no object.  For the QC card (qc_ext).
output reg  [7:0]  def_mR,
output reg  [7:0]  def_mG,
output reg  [7:0]  def_mB,

input  wire [CAW-1:0] ovl_raddr,
output reg         ovl_flag
);

localparam integer NCX   = IMG_HDISP / 16;
localparam integer NCY   = IMG_VDISP / 16;
localparam integer NCELL = NCX * NCY;
localparam [7:0]   NONE  = 8'd255;

//---------------------------------------------------------------------------
// Cell memories (bank bit on top) and flag maps
//---------------------------------------------------------------------------
reg [31:0] cellA [0:(2<<CAW)-1];     // {R,G,B,E} 8 bit each
reg [7:0]  cellM [0:(2<<CAW)-1];     // mask coverage, saturated 255
reg        fl0   [0:(1<<CAW)-1];
reg        fl1   [0:(1<<CAW)-1];

//---------------------------------------------------------------------------
// Colour stream accumulation
//---------------------------------------------------------------------------
reg         c_vs_d, c_de_d, c_bank;
reg  [11:0] c_x, c_y;
reg  [CAW-1:0] c_rowbase;
reg  [7:0]  c_yprev;
reg  [11:0] c_aR, c_aG, c_aB;
reg  [4:0]  c_aE;
reg  [56:0] c_lb [0:127];
reg  [56:0] c_lb_rd;

wire [9:0]  c_ysum = {2'b0,in_r} + {1'b0,in_g,1'b0} + {2'b0,in_b};
wire [7:0]  c_ypix = c_ysum[9:2];
wire [7:0]  c_yd   = (c_ypix > c_yprev) ? (c_ypix - c_yprev) : (c_yprev - c_ypix);
wire        c_first = (c_x[3:0] == 4'd0);
wire        c_last  = (c_x[3:0] == 4'd15);
wire        c_edge  = !c_first && (c_yd > EDGE_T);
wire [11:0] c_nR = (c_first ? 12'd0 : c_aR) + {4'b0,in_r};
wire [11:0] c_nG = (c_first ? 12'd0 : c_aG) + {4'b0,in_g};
wire [11:0] c_nB = (c_first ? 12'd0 : c_aB) + {4'b0,in_b};
wire [4:0]  c_nE = (c_first ? 5'd0  : c_aE) + {4'b0,c_edge};
wire        c_row0 = (c_y[3:0] == 4'd0);
wire        c_rowL = (c_y[3:0] == 4'd15);
wire [15:0] c_tR = (c_row0 ? 16'd0 : c_lb_rd[56:41]) + {4'b0,c_nR};
wire [15:0] c_tG = (c_row0 ? 16'd0 : c_lb_rd[40:25]) + {4'b0,c_nG};
wire [15:0] c_tB = (c_row0 ? 16'd0 : c_lb_rd[24:9])  + {4'b0,c_nB};
wire [8:0]  c_tE = (c_row0 ? 9'd0  : c_lb_rd[8:0])   + {4'b0,c_nE};
wire [7:0]  c_cc = c_x[11:4];
wire [CAW-1:0] c_cca = c_cc;
wire        c_grp = in_de && c_last;
wire        c_inb = (c_cc < NCX) && (c_y[11:4] < NCY);
wire        wrA   = c_grp && c_rowL && c_inb;
wire [CAW:0] wrA_a = {c_bank, c_rowbase + c_cca};
wire [31:0] wrA_d = { c_tR[15:8], c_tG[15:8], c_tB[15:8], c_tE[8] ? 8'hFF : c_tE[7:0] };

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        c_vs_d <= 1'b0; c_de_d <= 1'b0; c_bank <= 1'b0;
        c_x <= 12'd0; c_y <= 12'd0; c_rowbase <= {CAW{1'b0}};
        c_yprev <= 8'd0; c_aR <= 12'd0; c_aG <= 12'd0; c_aB <= 12'd0; c_aE <= 5'd0;
    end else begin
        c_vs_d <= in_vs;
        c_de_d <= in_de;
        if (in_vs && !c_vs_d) begin
            c_y <= 12'd0; c_rowbase <= {CAW{1'b0}}; c_bank <= ~c_bank;
        end else if (c_de_d && !in_de) begin
            c_y <= c_y + 12'd1;
            if (c_rowL) c_rowbase <= c_rowbase + NCX;
        end
        if (in_de) begin
            c_x <= c_x + 12'd1;
            c_yprev <= c_ypix;
            c_aR <= c_nR; c_aG <= c_nG; c_aB <= c_nB; c_aE <= c_nE;
        end else begin
            c_x <= 12'd0;
        end
    end
end

always @(posedge clk) begin
    c_lb_rd <= c_lb[c_cc[6:0]];
    if (c_grp && !c_rowL) c_lb[c_cc[6:0]] <= {c_tR, c_tG, c_tB, c_tE};
    if (wrA) cellA[wrA_a] <= wrA_d;
end

//---------------------------------------------------------------------------
// Mask stream accumulation (coverage count per cell)
//---------------------------------------------------------------------------
reg         m_vs_d, m_de_d, m_bank;
reg  [11:0] m_x, m_y;
reg  [CAW-1:0] m_rowbase;
reg  [4:0]  m_aC;
reg  [8:0]  m_lb [0:127];
reg  [8:0]  m_lb_rd;

wire        m_first = (m_x[3:0] == 4'd0);
wire        m_last  = (m_x[3:0] == 4'd15);
wire [4:0]  m_nC    = (m_first ? 5'd0 : m_aC) + {4'b0,m_bin};
wire        m_row0  = (m_y[3:0] == 4'd0);
wire        m_rowL  = (m_y[3:0] == 4'd15);
wire [8:0]  m_tC    = (m_row0 ? 9'd0 : m_lb_rd) + {4'b0,m_nC};
wire [7:0]  m_cc    = m_x[11:4];
wire [CAW-1:0] m_cca = m_cc;
wire        m_grp   = m_de && m_last;
wire        wrM     = m_grp && m_rowL && (m_cc < NCX) && (m_y[11:4] < NCY);
wire [CAW:0] wrM_a  = {m_bank, m_rowbase + m_cca};
wire        m_start = m_vs && !m_vs_d;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        m_vs_d <= 1'b0; m_de_d <= 1'b0; m_bank <= 1'b0;
        m_x <= 12'd0; m_y <= 12'd0; m_rowbase <= {CAW{1'b0}}; m_aC <= 5'd0;
    end else begin
        m_vs_d <= m_vs;
        m_de_d <= m_de;
        if (m_start) begin
            m_y <= 12'd0; m_rowbase <= {CAW{1'b0}}; m_bank <= ~m_bank;
        end else if (m_de_d && !m_de) begin
            m_y <= m_y + 12'd1;
            if (m_rowL) m_rowbase <= m_rowbase + NCX;
        end
        if (m_de) begin
            m_x <= m_x + 12'd1;
            m_aC <= m_nC;
        end else begin
            m_x <= 12'd0;
        end
    end
end

always @(posedge clk) begin
    m_lb_rd <= m_lb[m_cc[6:0]];
    if (m_grp && !m_rowL) m_lb[m_cc[6:0]] <= m_tC;
    if (wrM) cellM[wrM_a] <= m_tC[8] ? 8'hFF : m_tC[7:0];
end

//---------------------------------------------------------------------------
// Judge
//---------------------------------------------------------------------------
localparam [2:0] S_IDLE = 3'd0, S_CLR = 3'd1, S_A = 3'd2, S_B = 3'd3,
                 S_DIV = 3'd4, S_C = 3'd5, S_PUB = 3'd6;

reg [2:0]  st;
reg        lau;
reg        jb, jbA;
reg [1:0]  rnd;
reg [7:0]  clr_i;

// sweep engine: issue stage (sw_*) then process stage (p_*)
reg              sw_go;
reg [CAW-1:0]    sw_a;
reg [7:0]        sw_cx, sw_cy;
reg              p_v;
reg [CAW-1:0]    p_a;
reg [7:0]        p_cx, p_cy;
reg [31:0]       rdA;
reg [7:0]        rdM;
reg              rdF;

always @(posedge clk) begin
    rdA <= cellA[{jbA, sw_a}];
    rdM <= cellM[{jb, sw_a}];
    rdF <= fl0[sw_a];
end

// 2026-10-09 PIPELINE  p (RAM out) -> q (RAM words registered) -> r (compares
//   registered) -> counters / spans-free updates / flag-map writes.  Until
//   10-09 everything from the cellA read port to b_x0's enable and the fl0
//   write port was one clock: ERAM clk2q + 11 levels, pclkx1 -1.4 ns, the
//   design's worst path.  Same decisions, two clocks later per sweep
//   (10 a judgement); every "sweep finished" test waits for q and r too.
//   Bit-exact against qc_defect.v.pre_pipe, see the header of HANDOFF §-21.
reg              q_v, q_on, q_F;
reg [CAW-1:0]    q_a;
reg [7:0]        q_cx, q_cy;
reg [31:0]       q_A;
reg              r_v, r_on, r_F, r_inter, r_sx, r_ex;
reg [CAW-1:0]    r_a;
reg [7:0]        r_cx, r_cy;
reg [31:0]       r_A;
wire             sw_idle = !sw_go && !p_v && !q_v && !r_v;

// interior spans: first / last covered cell per cell row and per cell column
// (read and, in S_A, written at stage q)
reg [7:0] rowf [0:127];
reg [7:0] rowl [0:127];
reg [7:0] colf [0:127];
reg [7:0] coll [0:127];
wire [7:0] rf = rowf[q_cy[6:0]];
wire [7:0] rl = rowl[q_cy[6:0]];
wire [7:0] cf = colf[q_cx[6:0]];
wire [7:0] cl = coll[q_cx[6:0]];

wire [9:0] x10   = {2'b0, q_cx};
wire [9:0] y10   = {2'b0, q_cy};
wire       q_inter = q_v && (y10 >= {2'b0,cf} + MARGIN) && (y10 + MARGIN <= {2'b0,cl})
                         && (x10 >= {2'b0,rf} + MARGIN) && (x10 + MARGIN <= {2'b0,rl});

// reference accumulation
reg [13:0] cnt;
reg [21:0] sR, sG, sB, sE;
reg [7:0]  mR, mG, mB, mE;
wire       use_b = r_inter && r_on && !(rnd != 2'd0 && r_F);

// serial divider
reg        dv_run;
reg [1:0]  dv_sel;
reg [4:0]  dv_i;
reg [21:0] dv_num, dv_q;
reg [14:0] dv_rem;
wire [14:0] dv_r2 = {dv_rem[13:0], dv_num[21]};
wire        dv_ge = (dv_r2 >= {1'b0, cnt});
wire [21:0] dv_qn = {dv_q[20:0], dv_ge};

// classification: differences from stage q, decided at stage r
wire [7:0] qR = q_A[31:24], qG = q_A[23:16], qB = q_A[15:8], qE = q_A[7:0];
wire [7:0] cR = r_A[31:24], cG = r_A[23:16], cB = r_A[15:8], cE = r_A[7:0];
wire [9:0] cy10 = {2'b0,qR} + {1'b0,qG,1'b0} + {2'b0,qB};
wire [9:0] my10 = {2'b0,mR} + {1'b0,mG,1'b0} + {2'b0,mB};
wire [7:0] cY = cy10[9:2], mY = my10[9:2];
wire [7:0] dY = (cY > mY) ? (cY - mY) : (mY - cY);
wire [7:0] dR = (qR > mR) ? (qR - mR) : (mR - qR);
wire [7:0] dG = (qG > mG) ? (qG - mG) : (mG - qG);
wire [7:0] dB = (qB > mB) ? (qB - mB) : (mB - qB);
wire [9:0] dC = {2'b0,dR} + {2'b0,dG} + {2'b0,dB};
wire [7:0] dE = (qE > mE) ? (qE - mE) : 8'd0;
wire       inter   = r_inter;
wire       f_hole  = r_inter && !r_on;
wire       f_stain = r_inter && r_on && r_sx;
wire       f_edge  = r_inter && r_on && !r_sx && r_ex;
wire       f_any   = f_hole | f_stain | f_edge;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        q_v <= 1'b0; r_v <= 1'b0; r_inter <= 1'b0;
    end else begin
        q_v <= p_v;
        r_v <= q_v;
        r_inter <= q_inter;
    end
end

always @(posedge clk) begin
    q_a <= p_a;  q_cx <= p_cx;  q_cy <= p_cy;
    q_A <= rdA;  q_on <= (rdM >= ON_T);  q_F <= rdF;
    r_a <= q_a;  r_cx <= q_cx;  r_cy <= q_cy;
    r_A <= q_A;  r_on <= q_on;  r_F <= q_F;
    r_sx <= (dY > TY) || (dC > TC);
    r_ex <= (dE > TE);
end

reg [15:0] n_int, n_hole, n_stain, n_edge;
reg [7:0]  b_x0, b_y0, b_x1, b_y1;

always @(posedge clk) begin
    if (st == S_CLR) begin
        rowf[clr_i[6:0]] <= NONE; rowl[clr_i[6:0]] <= 8'd0;
        colf[clr_i[6:0]] <= NONE; coll[clr_i[6:0]] <= 8'd0;
    end else if (st == S_A && q_v && q_on) begin
        if (rf == NONE) rowf[q_cy[6:0]] <= q_cx;
        rowl[q_cy[6:0]] <= q_cx;
        if (cf == NONE) colf[q_cx[6:0]] <= q_cy;
        coll[q_cx[6:0]] <= q_cy;
    end
    if (st == S_C && r_v && rnd[0] == 1'b0) fl0[r_a] <= f_any;
    if (st == S_C && r_v && rnd[0] == 1'b1) fl1[r_a] <= f_any;
    ovl_flag <= (ROUNDS == 2) ? fl1[ovl_raddr] : fl0[ovl_raddr];
end

reg [7:0]  streak;

// OSD TEXT  (codes >= 0x80 are osd_cn_rom glyphs; must match tools/gen_cn_font.py)
//   no object   "   ---    "
//   object, ok  无异常 + 7 blanks
//   object, bad 孔nn污nn划nn + 1 blank   (cells, clamped to 99)
// The count shown is this judgement's; the word is the debounced flag.
localparam [7:0] CN_WU = 8'h96, CN_YI2 = 8'h9D, CN_CHANG = 8'h9E,
                 CN_STAIN = 8'hBF, CN_KONG = 8'hC0, CN_HUA3 = 8'hFF;
function [15:0] dec2;                    // two ASCII digits, clamped to 99
    input [15:0] v;
    reg [6:0] c; reg [3:0] t, u; reg [14:0] q;
    begin
        c = (v > 16'd99) ? 7'd99 : v[6:0];
        q = c * 15'd205;
        t = q[14:11] ;                   // c/10, exact for 0..99
        u = c - t * 4'd10;
        dec2 = {4'h3, t, 4'h3, u};
    end
endfunction
wire [15:0] n_tot = n_hole + n_stain + n_edge;
wire        bad_now = (n_int >= MIN_INT) && (n_tot >= MIN_DEF);
wire        bad_nx  = (n_int < MIN_INT)  ? 1'b0 :
                      (bad_now == def_bad) ? def_bad :
                      (streak + 8'd1 >= CONFIRM) ? bad_now : def_bad;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        st <= S_IDLE; lau <= 1'b0; jb <= 1'b0; jbA <= 1'b0; rnd <= 2'd0; clr_i <= 8'd0;
        sw_go <= 1'b0; sw_a <= {CAW{1'b0}}; sw_cx <= 8'd0; sw_cy <= 8'd0;
        p_v <= 1'b0; p_a <= {CAW{1'b0}}; p_cx <= 8'd0; p_cy <= 8'd0;
        cnt <= 14'd0; sR <= 22'd0; sG <= 22'd0; sB <= 22'd0; sE <= 22'd0;
        mR <= 8'd0; mG <= 8'd0; mB <= 8'd0; mE <= 8'd0;
        dv_run <= 1'b0; dv_sel <= 2'd0; dv_i <= 5'd0; dv_num <= 22'd0;
        dv_q <= 22'd0; dv_rem <= 15'd0;
        n_int <= 16'd0; n_hole <= 16'd0; n_stain <= 16'd0; n_edge <= 16'd0;
        b_x0 <= 8'd255; b_y0 <= 8'd255; b_x1 <= 8'd0; b_y1 <= 8'd0;
        def_stb <= 1'b0; def_obj <= 1'b0; def_bad <= 1'b0; def_cnt <= 16'd0;
        def_hole <= 16'd0; def_stain <= 16'd0; def_edge <= 16'd0;
        def_x0 <= 12'd0; def_y0 <= 12'd0; def_x1 <= 12'd0; def_y1 <= 12'd0;
        def_int <= 16'd0; streak <= 8'd0; def_text <= {10{8'h20}};
        def_mR <= 8'd0; def_mG <= 8'd0; def_mB <= 8'd0;
    end else begin
        def_stb <= 1'b0;

        // sweep engine
        p_v  <= sw_go;
        p_a  <= sw_a;
        p_cx <= sw_cx;
        p_cy <= sw_cy;
        if (sw_go) begin
            if (sw_a == NCELL-1) sw_go <= 1'b0;
            sw_a <= sw_a + 1'b1;
            if (sw_cx == NCX-1) begin sw_cx <= 8'd0; sw_cy <= sw_cy + 8'd1; end
            else sw_cx <= sw_cx + 8'd1;
        end

        case (st)
        S_IDLE: begin
            if (m_start && en) begin
                jb <= m_bank; jbA <= ~c_bank; rnd <= 2'd0; clr_i <= 8'd0; st <= S_CLR;
            end
        end

        S_CLR: begin
            clr_i <= clr_i + 8'd1;
            if (clr_i == 8'd127) begin st <= S_A; lau <= 1'b0; end
        end

        S_A: begin
            if (!lau) begin
                sw_a <= {CAW{1'b0}}; sw_cx <= 8'd0; sw_cy <= 8'd0; sw_go <= 1'b1; lau <= 1'b1;
            end else if (sw_idle) begin
                st <= S_B; lau <= 1'b0;
            end
        end

        S_B: begin
            if (!lau) begin
                sw_a <= {CAW{1'b0}}; sw_cx <= 8'd0; sw_cy <= 8'd0; sw_go <= 1'b1; lau <= 1'b1;
                cnt <= 14'd0; sR <= 22'd0; sG <= 22'd0; sB <= 22'd0; sE <= 22'd0;
                n_int <= 16'd0; n_hole <= 16'd0; n_stain <= 16'd0; n_edge <= 16'd0;
            end else begin
                if (use_b) begin
                    cnt <= cnt + 14'd1;
                    sR <= sR + {14'd0,cR}; sG <= sG + {14'd0,cG};
                    sB <= sB + {14'd0,cB}; sE <= sE + {14'd0,cE};
                end
                if (sw_idle) begin
                    lau <= 1'b0;
                    if (cnt == 14'd0 && !use_b) st <= S_PUB;     // no object at all
                    else begin st <= S_DIV; dv_sel <= 2'd0; dv_run <= 1'b0; end
                end
            end
        end

        S_DIV: begin
            if (!dv_run) begin
                dv_num <= (dv_sel == 2'd0) ? sR : (dv_sel == 2'd1) ? sG :
                          (dv_sel == 2'd2) ? sB : sE;
                dv_rem <= 15'd0; dv_q <= 22'd0; dv_i <= 5'd22; dv_run <= 1'b1;
            end else begin
                dv_num <= {dv_num[20:0], 1'b0};
                dv_rem <= dv_ge ? (dv_r2 - {1'b0,cnt}) : dv_r2;
                dv_q   <= dv_qn;
                dv_i   <= dv_i - 5'd1;
                if (dv_i == 5'd1) begin
                    dv_run <= 1'b0;
                    case (dv_sel)
                    2'd0: mR <= dv_qn[7:0];
                    2'd1: mG <= dv_qn[7:0];
                    2'd2: mB <= dv_qn[7:0];
                    default: mE <= dv_qn[7:0];
                    endcase
                    if (dv_sel == 2'd3) begin st <= S_C; lau <= 1'b0; end
                    else dv_sel <= dv_sel + 2'd1;
                end
            end
        end

        S_C: begin
            if (!lau) begin
                sw_a <= {CAW{1'b0}}; sw_cx <= 8'd0; sw_cy <= 8'd0; sw_go <= 1'b1; lau <= 1'b1;
                n_int <= 16'd0; n_hole <= 16'd0; n_stain <= 16'd0; n_edge <= 16'd0;
                b_x0 <= 8'd255; b_y0 <= 8'd255; b_x1 <= 8'd0; b_y1 <= 8'd0;
            end else begin
                if (inter) n_int <= n_int + 16'd1;
                if (f_hole)  n_hole  <= n_hole  + 16'd1;
                if (f_stain) n_stain <= n_stain + 16'd1;
                if (f_edge)  n_edge  <= n_edge  + 16'd1;
                if (r_v && f_any) begin
                    if (r_cx < b_x0) b_x0 <= r_cx;
                    if (r_cx > b_x1) b_x1 <= r_cx;
                    if (r_cy < b_y0) b_y0 <= r_cy;
                    if (r_cy > b_y1) b_y1 <= r_cy;
                end
                if (sw_idle) begin
                    lau <= 1'b0;
                    if (rnd + 2'd1 < ROUNDS) begin rnd <= rnd + 2'd1; st <= S_B; end
                    else st <= S_PUB;
                end
            end
        end

        S_PUB: begin
            def_stb   <= 1'b1;
            def_int   <= n_int;
            def_obj   <= (n_int >= MIN_INT);
            def_cnt   <= n_tot;
            def_hole  <= n_hole;
            def_stain <= n_stain;
            def_edge  <= n_edge;
            def_x0    <= {b_x0, 4'd0};
            def_y0    <= {b_y0, 4'd0};
            def_x1    <= {b_x1 + 8'd1, 4'd0} ;
            def_y1    <= {b_y1 + 8'd1, 4'd0} ;
            def_mR    <= (n_int < MIN_INT) ? 8'd0 : mR;
            def_mG    <= (n_int < MIN_INT) ? 8'd0 : mG;
            def_mB    <= (n_int < MIN_INT) ? 8'd0 : mB;
            if (n_int < MIN_INT) begin
                streak <= 8'd0; def_bad <= 1'b0;
            end else if (bad_now == def_bad) begin
                streak <= 8'd0;
            end else if (streak + 8'd1 >= CONFIRM) begin
                def_bad <= bad_now; streak <= 8'd0;
            end else begin
                streak <= streak + 8'd1;
            end
            def_text <= (n_int < MIN_INT) ? {{3{8'h20}}, "-", "-", "-", {4{8'h20}}} :
                        bad_nx ? {CN_KONG, dec2(n_hole), CN_STAIN, dec2(n_stain),
                                  CN_HUA3, dec2(n_edge), 8'h20} :
                                 {CN_WU, CN_YI2, CN_CHANG, {7{8'h20}}};
            st <= S_IDLE;
        end

        default: st <= S_IDLE;
        endcase
    end
end

endmodule
