//---------------------------------------------------------------------------
// tof_size -- workpiece size from one detection box and one ToF distance.
//
// THE MODEL (the group's scheme 1, "pixel mapping")
//   Pinhole camera: an object of real width W at distance D spans
//       w_px = F_PX * W / D        so        W = w_px * D / F_PX
//   F_PX is the lens focal length in PIXELS -- one number, the same for both
//   axes (square pixels), and the only calibration there is.  It is NOT the
//   per-distance "mm per pixel" table the scheme first described: that table
//   is exactly D / F_PX, so one constant replaces every entry of it.
//
// ⭐ CALIBRATING F_PX -- ONE PHOTOGRAPH, ONE DIVISION
//   Put an object of known width S (A4 landscape: 297 mm) square-on at the
//   aim point.  The PIX row gives its width in pixels P, the DIST row its
//   distance D.  Then
//       F_PX = P * D / S
//   Set the parameter, rebuild.  The default 1371 is a GUESS (70 deg
//   horizontal field of view: 960 / tan 35 deg); every size on screen is off
//   by the ratio true/guess until this is done.  Do it at the working
//   distance: D_OFS_MM (sensor face to lens) is then absorbed at that
//   distance and only shows as a slope elsewhere.
//
// WHY THE OTHER SCHEME (servo angle scanning) WAS NOT BUILT
//   It needs the ToF spot to resolve an edge.  The VL53L1X cone is 27 deg
//   (about 15 deg at the smallest ROI), i.e. a 480 mm spot at 1 m, against
//   SG90 steps of about 1 deg = 17 mm.  The spot blurs every edge by an order
//   of magnitude more than the angle can place it.
//
// WHICH BOX
//   The one containing the aim point (AIM_X, AIM_Y) -- where the ToF looks.
//   Any other box's size would be computed with a distance measured to
//   something else.  First match in ccl_blob's order, which is by area, so a
//   small box nested in a big one loses to the big one.  No box at the aim
//   point shows NO BOX rather than borrowing the largest: with the head in
//   TRACK the tracker centres the target, and without it the operator aims.
//
// ⚠ ONE SNAPSHOT PER FRAME, TAKEN ON ONE CLOCK.  All NBLOB boxes, the
// filtered distance and the flags are copied together at the frame edge and
// everything after works from the copy.  Scanning the live ccl_blob outputs
// over eight clocks would let an S_PUB land mid-scan and pick a box from one
// frame against the rule of another -- the det_overlay 09-19 lesson.
//
// NO DSP, NO DEEP PATHS.  Two shift-add multiplies per axis, 16 clocks each,
// and a double-dabble per displayed number, 14 clocks each: about 150 clocks
// a frame.  The pixel-clock domain has tens of picoseconds of slack, so
// nothing here is allowed to be wider than one adder per clock.
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module tof_size #(
parameter integer NBLOB     = 8,
parameter integer AIM_X     = 960,
parameter integer AIM_Y     = 540,

// Focal length in pixels.  ⚠ A GUESS until calibrated -- see the header.
// Must be >= 257 (RECIP has to fit 16 bits).
parameter integer F_PX      = 1371,

// 10-03 evening: the focal length for the picture's y (box HEIGHT) when it
// differs from x.  0 = F_PX (square, the pre-10-03 behaviour).  All three
// bench calibrations read the w/h pixel ratio 2..5 % above the true one, the
// same sign every time -- one F cannot fit both axes (worst error 6.8 % ->
// 2.2 % with two).  Barrel distortion compresses the longer extent more, but
// the fit does not care why.
parameter integer F_PX_Y    = 0,

// Added to the ToF reading before the size is computed: the distance from
// the sensor face to the lens.  Negative if the sensor sits behind the lens.
parameter integer D_OFS_MM  = 0,

// Distance smoothing: f += (d - f) >> DIST_IIR on each valid measurement,
// but a jump of more than SNAP_MM is a new object and is taken at once.
// 0 = no smoothing.
parameter integer DIST_IIR  = 2,
parameter integer SNAP_MM   = 100,

// 10-03 evening: 1 = the step is ROUNDED, (d - f + 2^(IIR-1)) >>> IIR.
// 0 = truncated (bit-exact with everything before).  Truncation is a dead
// zone of 0..+3 mm on one side only, so on noisy readings f creeps toward
// the low tail: simulated -1.5 mm at any noise sigma >= 1 mm (+0.5 rounded),
// i.e. -1.1 % of size at 13 cm, and it is the distance qc_thick compares
// with its block-mean TOP.
parameter integer DIST_RND  = 0,

// Frames without a valid measurement before the distance is called stale.
parameter integer STALE_FR  = 15,

// ⭐ 10-04 one-key calibration (cal_go, from qc_thick).  The reference
// workpiece's top face, 0.1 mm, longer and shorter side -- matched with the
// box's longer and shorter side, so it may lie either way round.  Each axis
// then says what distance the pinhole model needs, D = W * F / px; the mean
// minus the filtered ToF reading replaces D_OFS_MM until power-off.
// Refused when the two axes disagree by more than mean / 2^(CAL_AGREE_SH-1)
// (5 = 6 %: not the reference, or a bad box), or the offset would move more
// than CAL_MAX_MM from D_OFS_MM.  CAL_L_D10 * max(F_PX, F_PX_Y) * 1.6 must
// stay below 2^24 (the divider's numerator).
parameter integer CAL_L_D10    = 545,
parameter integer CAL_S_D10    = 280,
// ⭐ 10-20: a second reference, used while cal_ref2 is high (system_top: the
// P1 cube in qc_std's 方块 mode, 60 x 60).  0 = same as the first.
parameter integer CAL2_L_D10   = 0,
parameter integer CAL2_S_D10   = 0,
parameter integer CAL_MAX_MM   = 60,
parameter integer CAL_AGREE_SH = 5
)(
input  wire        clk,
input  wire        rst_n,
input  wire        vs,

input  wire [2:0]  tof_state,       // vl53l1x_ctrl; 0 = no ranger built
input  wire [15:0] dist_mm,
input  wire [7:0]  dist_code,
input  wire        dist_stb,
input  wire [15:0] tof_id,          // 10-03 night: vl53l1x_ctrl id_rb, shown with BAD ID

input  wire [NBLOB*12-1:0] blob_x0,
input  wire [NBLOB*12-1:0] blob_x1,
input  wire [NBLOB*12-1:0] blob_y0,
input  wire [NBLOB*12-1:0] blob_y1,
input  wire [NBLOB-1:0]    blob_valid,

// Boxes are in affine-output pixels.  Any position but pass-through rescales
// or rotates them, and the pinhole model no longer holds.
input  wire        affine_pass,

// The head was stepping.  The size is still computed -- the box and the
// distance are one frame apart at most -- but marked 'M'.
input  wire        head_moving,

// Three OSD rows' value fields, 8 characters each (bytes >= 0x80 are
// osd_cn_rom glyphs since 10-03 evening), published together.
output reg  [63:0] dist_text,
output reg  [63:0] size_text,
output reg  [63:0] pix_text,

// For ChipWatcher.
output reg  [15:0] size_w_mm,
output reg  [15:0] size_h_mm,
output reg         size_ok,

// 2026-10-02: for qc_thick (thickness + the stable flag).  The box under the
// aim point, independent of the distance (size_ok also needs a distance), and
// pub_stb = the one clock all of the above change on.
output reg         box_found,
// 10-23: some box ANYWHERE in this frame (any blob_valid bit), from the same
// snapshot and on the same pub_stb as box_found.  qc_thick only lets the
// tare / the nearer-BASE follow learn from frames where this is 0 -- board
// 10-22: a triangle at the aim point with no box of its own while the hand
// beside it WAS boxed, for 3.5 s, was learnt as the backdrop.
output reg         box_any,
output reg  [11:0] box_x0,
output reg  [11:0] box_y0,
output reg  [11:0] box_w_px,
output reg  [11:0] box_h_px,
output reg  [15:0] size_d_mm,       // the filtered ToF reading the size used (before D_OFS)
output reg  [1:0]  size_why,        // 0 ok, 1 NO DIST, 2 AFFINE, 3 NO BOX -- size_text's case
output reg         pub_stb,

// 10-04: calibration.  cal_go (one clock) -> cal_done (one clock) some 60
// clocks later; cal_ok = xy_ofs_mm was replaced, else cal_why says why not.
input  wire        cal_go,
input  wire        cal_ref2,        // 10-20: 1 = CAL2_* is the reference (sampled on cal_go)
// ⭐ 10-20: added to the distance for the WIDTH only.  A standing cylinder's
// left / right silhouette edges are its tangent lines, at the depth of the
// AXIS -- radius mm behind the front the ToF ranges -- while its top / bottom
// edges are the front generatrix at the front's depth.  Board, P2 D60 x 30:
// 542 x 325 px at 139: the front depth for both gave 44 x 27 (true 60 x 30),
// +30 on the width alone fits both axes.  0 = every other shape.
input  wire [7:0]  w_add_mm,
output reg         cal_done,
output reg         cal_ok,
output reg  [1:0]  cal_why,         // 1 no valid size, 2 x / y disagree, 3 out of range
output reg signed [9:0] xy_ofs_mm   // D_OFS_MM or the calibrated one -- what SIZE uses
);

localparam integer RSH   = 24;
localparam integer RECIP = ((1 << RSH) + F_PX / 2) / F_PX;
localparam [15:0]  RECIP16  = RECIP;
localparam integer FY      = (F_PX_Y > 0) ? F_PX_Y : F_PX;
localparam integer RECIP_Y = ((1 << RSH) + FY / 2) / FY;
localparam [15:0]  RECIP16_Y = RECIP_Y;
// calibration numerators: 16 * D = side_0.1mm * F * 1.6 / px
localparam integer CNX_L = (CAL_L_D10 * F_PX * 8 + 2) / 5;
localparam integer CNX_S = (CAL_S_D10 * F_PX * 8 + 2) / 5;
localparam integer CNY_L = (CAL_L_D10 * FY   * 8 + 2) / 5;
localparam integer CNY_S = (CAL_S_D10 * FY   * 8 + 2) / 5;
localparam integer C2L   = (CAL2_L_D10 > 0) ? CAL2_L_D10 : CAL_L_D10;
localparam integer C2S   = (CAL2_S_D10 > 0) ? CAL2_S_D10 : CAL_S_D10;
localparam integer CNX_L2 = (C2L * F_PX * 8 + 2) / 5;
localparam integer CNX_S2 = (C2S * F_PX * 8 + 2) / 5;
localparam integer CNY_L2 = (C2L * FY   * 8 + 2) / 5;
localparam integer CNY_S2 = (C2S * FY   * 8 + 2) / 5;
localparam integer IIR_RND = ((DIST_RND != 0) && (DIST_IIR > 0)) ? (1 << (DIST_IIR - 1)) : 0;
localparam [2:0]   ST_RANGE = 3'd3;

// 10-03 evening: tools/gen_cn_font.py codes (append-only table).
localparam [7:0] CN_CE   = 8'h82, CN_JU   = 8'h83, CN_GUAN = 8'h8D, CN_BI   = 8'h8E,
                 CN_GU   = 8'h8F, CN_ZHANG = 8'h90, CN_ZHONG = 8'h93, CN_WU  = 8'h96,
                 CN_JIAN2 = 8'h98, CN_DONG = 8'h9B, CN_FANG = 8'hA0, CN_SHE  = 8'hA1,
                 CN_KUANG = 8'hA2, CN_CUO = 8'hD5, CN_SHI5 = 8'hEF, CN_CHAO = 8'hF5,
                 CN_QI   = 8'hF6, CN_PEI  = 8'hF7, CN_ZHI4 = 8'hF8, CN_YING = 8'hF9,
                 CN_DA2  = 8'hFA, CN_QI2  = 8'hFB, CN_ZONG = 8'hFC, CN_XIAN = 8'hFD;

//---------------------------------------------------------------------------
// Frame edge: rising vs, one per frame whichever way vs is read.
//---------------------------------------------------------------------------
reg vs_d;
always @(posedge clk or negedge rst_n)
    if (!rst_n) vs_d <= 1'b0; else vs_d <= vs;
wire frame_edge = vs & ~vs_d;

//---------------------------------------------------------------------------
// Distance: filtered, with an age.
//---------------------------------------------------------------------------
reg [15:0] dist_f;
reg        have_d;
reg [7:0]  age;
reg [15:0] last_raw;
reg [7:0]  last_code;

// THREE STAGES, ONE CARRY CHAIN EACH.  subtract -> |x| -> compare in one
// clock is three 18-bit carry chains in series, which is how a control path
// ends up on the timing report of a domain with 34 ps to spare.  dist_mm and
// dist_code are registers in vl53l1x_ctrl that hold for a whole measurement
// period (~60 ms) after the strobe, and dist_f changes only in stage 3, so
// spreading this over three clocks reads exactly the values one clock would.
reg               stb1, stb2;
reg signed [17:0] e_r;
reg        [17:0] abs_r;
reg signed [17:0] step_r;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        dist_f <= 16'd0; have_d <= 1'b0; age <= 8'd255;
        last_raw <= 16'd0; last_code <= 8'd255;
        stb1 <= 1'b0; stb2 <= 1'b0; e_r <= 18'sd0; abs_r <= 18'd0; step_r <= 18'sd0;
    end else begin
        stb1   <= dist_stb && (dist_code == 8'd0);
        stb2   <= stb1;
        e_r    <= $signed({2'b00, dist_mm}) - $signed({2'b00, dist_f});
        abs_r  <= e_r[17] ? -e_r : e_r;
        step_r <= (e_r + IIR_RND) >>> DIST_IIR;

        if (dist_stb) begin
            last_raw  <= dist_mm;
            last_code <= dist_code;
        end
        if (stb2) begin
            have_d <= 1'b1;
            age    <= 8'd0;
            if (!have_d || (abs_r > SNAP_MM) || (DIST_IIR == 0))
                dist_f <= dist_mm;
            else
                dist_f <= dist_f + step_r[15:0];
        end
        else if (frame_edge && (age != 8'd255)) begin
            age <= age + 8'd1;
        end
    end
end

wire dist_ok = (tof_state == ST_RANGE) && have_d && (age < STALE_FR);

//---------------------------------------------------------------------------
// The per-frame sequence
//---------------------------------------------------------------------------
localparam [2:0] C_IDLE = 3'd0, C_SCAN = 3'd1, C_MUL = 3'd2, C_BCD = 3'd3,
                 C_PUB  = 3'd4, C_HX   = 3'd5;

reg [2:0]  cs;

// snapshot
reg [NBLOB*12-1:0] s_x0, s_x1, s_y0, s_y1;
reg [NBLOB-1:0]    s_v;
reg [15:0] s_dist, s_raw;
reg [7:0]  s_code;
reg [2:0]  s_state;
reg [15:0] s_id;
reg        s_dok, s_aff, s_mov;
reg        s_any;                  // 10-23: |blob_valid at the snapshot

// scan.  The snapshot SHIFTS DOWN one slot per clock and only slot 0 is
// examined, so there is no 8-way mux of 12-bit fields in front of the
// compares and the width subtract -- the snapshot is not needed after the
// scan, so consuming it costs nothing.  Same order as ccl_blob's (by area).
// j is three bits, so NBLOB <= 8, which is what ccl_blob is built with.
reg [2:0]  j;
reg        found;
reg [11:0] bw, bh, bx, by;

wire [11:0] jx0 = s_x0[11:0];
wire [11:0] jx1 = s_x1[11:0];
wire [11:0] jy0 = s_y0[11:0];
wire [11:0] jy1 = s_y1[11:0];
wire        j_hit = s_v[0] && (jx0 <= AIM_X) && (jx1 >= AIM_X)
                           && (jy0 <= AIM_Y) && (jy1 >= AIM_Y);

// multiply: m_acc = m_a * m_b, one bit of m_b per clock
reg [1:0]  mstep;                  // 0: w*d  1: *RECIP  2: h*d  3: *RECIP
reg [40:0] m_a, m_acc;
reg [15:0] m_b;
reg [4:0]  m_i;
reg [12:0] dc;
reg [12:0] dcw;                    // 10-20: dc + w_add_mm, the width's distance
reg [15:0] w_mm, h_mm;

// double dabble
reg [2:0]  bi;                     // which value
reg [13:0] bb;
reg [15:0] bcd;
reg [3:0]  bk;
reg [15:0] bcd_d, bcd_w, bcd_h, bcd_pw, bcd_ph;

wire [15:0] bcd_adj = { (bcd[15:12] >= 4'd5) ? bcd[15:12] + 4'd3 : bcd[15:12],
                        (bcd[11:8]  >= 4'd5) ? bcd[11:8]  + 4'd3 : bcd[11:8],
                        (bcd[7:4]   >= 4'd5) ? bcd[7:4]   + 4'd3 : bcd[7:4],
                        (bcd[3:0]   >= 4'd5) ? bcd[3:0]   + 4'd3 : bcd[3:0] };

// What each BCD slot converts, clamped to what its field can show.
wire [15:0] disp_d = (s_code == 8'd0) ? s_dist : s_raw;
reg  [13:0] bsrc;
always @(*) begin
    case (bi)
    3'd0:    bsrc = (disp_d > 16'd9999) ? 14'd9999 : disp_d[13:0];
    3'd1:    bsrc = (w_mm   > 16'd999)  ? 14'd999  : w_mm[13:0];
    3'd2:    bsrc = (h_mm   > 16'd999)  ? 14'd999  : h_mm[13:0];
    3'd3:    bsrc = {2'b00, bw};
    default: bsrc = (bh > 12'd999) ? 14'd999 : {2'b00, bh};
    endcase
end

// The offset (D_OFS_MM, or the calibrated one) applied and clamped to
// 1..8191 so the product stays in 24 bits.
wire signed [17:0] dc_s = $signed({2'b00, s_dist}) + xy_ofs_mm;
wire        [12:0] dc_c = (dc_s < 1)    ? 13'd1 :
                          (dc_s > 8191) ? 13'd8191 : dc_s[12:0];
// 10-20: the width's.  ofs_w is registered (both terms change only on a
// calibration or a mode key), so dcw_c is the same depth as dc_c.
reg  signed [10:0] ofs_w;
always @(posedge clk) ofs_w <= xy_ofs_mm + $signed({3'b000, w_add_mm});
wire signed [17:0] dcw_s = $signed({2'b00, s_dist}) + ofs_w;
wire        [12:0] dcw_c = (dcw_s < 1)    ? 13'd1 :
                           (dcw_s > 8191) ? 13'd8191 : dcw_s[12:0];

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        cs <= C_IDLE;
        s_x0 <= 0; s_x1 <= 0; s_y0 <= 0; s_y1 <= 0; s_v <= 0;
        s_dist <= 0; s_raw <= 0; s_code <= 8'd255; s_state <= 3'd0; s_id <= 16'd0;
        s_dok <= 1'b0; s_aff <= 1'b0; s_mov <= 1'b0; s_any <= 1'b0;
        j <= 0; found <= 1'b0; bw <= 0; bh <= 0; bx <= 0; by <= 0;
        mstep <= 0; m_a <= 0; m_acc <= 0; m_b <= 0; m_i <= 0; dc <= 0;
        w_mm <= 0; h_mm <= 0;
        bi <= 0; bb <= 0; bcd <= 0; bk <= 0;
        bcd_d <= 0; bcd_w <= 0; bcd_h <= 0; bcd_pw <= 0; bcd_ph <= 0;
    end else begin
        case (cs)
        C_IDLE: if (frame_edge) begin
            s_x0 <= blob_x0; s_x1 <= blob_x1;
            s_y0 <= blob_y0; s_y1 <= blob_y1;
            s_v  <= blob_valid;
            s_dist  <= dist_f;
            s_raw   <= last_raw;
            s_code  <= last_code;
            s_state <= tof_state;
            s_id    <= tof_id;
            s_dok   <= dist_ok;
            s_aff   <= affine_pass;
            s_mov   <= head_moving;
            s_any   <= |blob_valid;
            j <= 0; found <= 1'b0;
            cs <= C_SCAN;
        end

        C_SCAN: begin
            s_x0 <= s_x0 >> 12;  s_x1 <= s_x1 >> 12;
            s_y0 <= s_y0 >> 12;  s_y1 <= s_y1 >> 12;
            s_v  <= s_v  >> 1;
            if (!found && j_hit) begin
                found <= 1'b1;
                bw    <= jx1 - jx0 + 12'd1;
                bh    <= jy1 - jy0 + 12'd1;
                bx    <= jx0;
                by    <= jy0;
            end
            if (j == NBLOB - 1) begin
                dc    <= dc_c;
                dcw   <= dcw_c;
                mstep <= 2'd0;
                m_i   <= 5'd0;
                m_acc <= 41'd0;
                cs    <= C_MUL;
            end
            j <= j + 3'd1;
        end

        C_MUL: begin
            // Load the operands on bit 0, accumulate on every bit.  The
            // *RECIP steps start the accumulator at half an LSB of the >>RSH
            // instead of adding it at the end, so rounding costs no adder;
            // the result is read out one clock later (next load, or C_HX),
            // so no clock ever carries more than the one 41-bit add.
            if (m_i == 5'd0) begin
                case (mstep)
                2'd0: begin m_a <= {28'd0, dcw}; m_b <= {4'd0, bw}; end
                2'd2: begin m_a <= {28'd0, dc}; m_b <= {4'd0, bh}; end
                default: begin m_a <= m_acc; m_b <= mstep[1] ? RECIP16_Y : RECIP16; end
                endcase
                if (mstep == 2'd2) w_mm <= m_acc[RSH+15:RSH];
                m_acc <= mstep[0] ? (41'd1 << (RSH-1)) : 41'd0;
                m_i   <= 5'd1;
            end else begin
                if (m_b[0]) m_acc <= m_acc + m_a;
                m_a <= {m_a[39:0], 1'b0};
                m_b <= {1'b0, m_b[15:1]};
                if (m_i == 5'd16) begin
                    m_i   <= 5'd0;
                    mstep <= mstep + 2'd1;
                    if (mstep == 2'd3) cs <= C_HX;
                end else begin
                    m_i <= m_i + 5'd1;
                end
            end
        end

        C_HX: begin
            h_mm <= m_acc[RSH+15:RSH];
            bi <= 3'd0; bk <= 4'd0;
            cs <= C_BCD;
        end

        C_BCD: begin
            if (bk == 4'd0) begin
                bb  <= bsrc;
                bcd <= 16'd0;
                bk  <= 4'd1;
            end else begin
                bcd <= {bcd_adj[14:0], bb[13]};
                bb  <= {bb[12:0], 1'b0};
                if (bk == 4'd14) begin
                    bk <= 4'd0;
                    case (bi)
                    3'd0: bcd_d  <= {bcd_adj[14:0], bb[13]};
                    3'd1: bcd_w  <= {bcd_adj[14:0], bb[13]};
                    3'd2: bcd_h  <= {bcd_adj[14:0], bb[13]};
                    3'd3: bcd_pw <= {bcd_adj[14:0], bb[13]};
                    default: bcd_ph <= {bcd_adj[14:0], bb[13]};
                    endcase
                    if (bi == 3'd4) cs <= C_PUB;
                    bi <= bi + 3'd1;
                end else begin
                    bk <= bk + 4'd1;
                end
            end
        end

        default: cs <= C_IDLE;          // C_PUB: the text block below fires
        endcase
    end
end

//---------------------------------------------------------------------------
// ⭐ 10-04 one-key calibration.  Runs while cs sits in C_IDLE, where bw / bh
// / s_dist are still the ones size_ok was published with (a new frame_edge
// overwrites them, so the operands are copied on the start clock).  Restoring
// divider, one quotient bit per clock, then one carry chain per clock.
//---------------------------------------------------------------------------
localparam [2:0] K_IDLE = 3'd0, K_DX = 3'd1, K_DY = 3'd2, K_S1 = 3'd3,
                 K_S2   = 3'd4, K_S3 = 3'd5, K_S4 = 3'd6;

reg  [2:0]  ks;
reg         cal_pend, c_land, c_ref2, p_ref2;
reg  [11:0] c_bh;
reg  [15:0] c_d;
reg  [23:0] dv_n, dv_q, c_qx, c_qy;
reg  [11:0] dv_d, dv_r;
reg  [4:0]  dv_k;
reg  [24:0] c_sum, c_adif;
reg signed [24:0] c_dif;
reg  [20:0] c_davg;
reg         c_agree;
reg signed [21:0] c_tot;

wire [12:0] dv_rs  = {dv_r, dv_n[23]};
wire [13:0] dv_sub = {1'b0, dv_rs} - {2'b00, dv_d};
wire [23:0] dv_qn  = {dv_q[22:0], !dv_sub[13]};
wire [11:0] dv_rn  = dv_sub[13] ? dv_rs[11:0] : dv_sub[11:0];

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        ks <= K_IDLE; cal_pend <= 1'b0; c_land <= 1'b0; c_ref2 <= 1'b0; p_ref2 <= 1'b0;
        cal_done <= 1'b0; cal_ok <= 1'b0; cal_why <= 2'd0;
        xy_ofs_mm <= D_OFS_MM;
        c_bh <= 12'd0; c_d <= 16'd0;
        dv_n <= 24'd0; dv_q <= 24'd0; dv_d <= 12'd1; dv_r <= 12'd0; dv_k <= 5'd0;
        c_qx <= 24'd0; c_qy <= 24'd0; c_sum <= 25'd0; c_dif <= 25'sd0; c_adif <= 25'd0;
        c_davg <= 21'd0; c_agree <= 1'b0; c_tot <= 22'sd0;
    end else begin
        cal_done <= 1'b0;
        if (cal_go) begin cal_pend <= 1'b1; p_ref2 <= cal_ref2; end

        case (ks)
        K_IDLE: if (cal_pend && (cs == C_IDLE) && !frame_edge) begin
            cal_pend <= 1'b0;
            if (!size_ok) begin
                cal_done <= 1'b1; cal_ok <= 1'b0; cal_why <= 2'd1;
            end else begin
                c_land <= (bw >= bh);
                c_ref2 <= p_ref2;
                c_bh   <= bh;
                c_d    <= s_dist;
                dv_n   <= p_ref2 ? ((bw >= bh) ? CNX_L2[23:0] : CNX_S2[23:0])
                                 : ((bw >= bh) ? CNX_L[23:0]  : CNX_S[23:0]);
                dv_d   <= bw;
                dv_r   <= 12'd0;
                dv_k   <= 5'd0;
                ks     <= K_DX;
            end
        end

        K_DX, K_DY: begin
            dv_q <= dv_qn;
            dv_r <= dv_rn;
            dv_n <= {dv_n[22:0], 1'b0};
            if (dv_k == 5'd23) begin
                dv_k <= 5'd0;
                if (ks == K_DX) begin
                    c_qx <= dv_qn;
                    dv_n <= c_ref2 ? (c_land ? CNY_S2[23:0] : CNY_L2[23:0])
                                   : (c_land ? CNY_S[23:0]  : CNY_L[23:0]);
                    dv_d <= c_bh;
                    dv_r <= 12'd0;
                    ks   <= K_DY;
                end else begin
                    c_qy <= dv_qn;
                    ks   <= K_S1;
                end
            end else begin
                dv_k <= dv_k + 5'd1;
            end
        end

        K_S1: begin                     // 16 * (Dx + Dy), 16 * (Dx - Dy)
            c_sum <= {1'b0, c_qx} + {1'b0, c_qy};
            c_dif <= $signed({1'b0, c_qx}) - $signed({1'b0, c_qy});
            ks    <= K_S2;
        end
        K_S2: begin                     // |Dx - Dy|, round((Dx + Dy) / 2)
            c_adif <= c_dif[24] ? -c_dif : c_dif;
            c_davg <= ({1'b0, c_sum} + 26'd16) >> 5;
            ks     <= K_S3;
        end
        K_S3: begin
            c_agree <= (c_adif <= (c_sum >> CAL_AGREE_SH));
            c_tot   <= $signed({1'b0, c_davg}) - $signed({6'd0, c_d});
            ks      <= K_S4;
        end
        default: begin                  // K_S4: the verdict
            cal_done <= 1'b1;
            if (!c_agree) begin
                cal_ok <= 1'b0; cal_why <= 2'd2;
            end else if ((c_tot > D_OFS_MM + CAL_MAX_MM) || (c_tot < D_OFS_MM - CAL_MAX_MM)) begin
                cal_ok <= 1'b0; cal_why <= 2'd3;
            end else begin
                cal_ok <= 1'b1; cal_why <= 2'd0;
                xy_ofs_mm <= c_tot[9:0];
            end
            ks <= K_IDLE;
        end
        endcase
    end
end

//---------------------------------------------------------------------------
// Text.  Built from registers that are all stable during C_PUB and latched
// on that one clock, so the three rows always describe the same frame.
//---------------------------------------------------------------------------
function [7:0] dg;                      // digit, or blank
    input [3:0] d;
    input       blank;
    dg = blank ? 8'h20 : (8'h30 + {4'd0, d});
endfunction

wire [31:0] d4 = { dg(bcd_d[15:12], bcd_d[15:12] == 4'd0),
                   dg(bcd_d[11:8],  bcd_d[15:8]  == 8'd0),
                   dg(bcd_d[7:4],   bcd_d[15:4]  == 12'd0),
                   dg(bcd_d[3:0],   1'b0) };
wire [23:0] w3 = { dg(bcd_w[11:8], bcd_w[11:8] == 4'd0),
                   dg(bcd_w[7:4],  bcd_w[11:4] == 8'd0),
                   dg(bcd_w[3:0],  1'b0) };
wire [23:0] h3 = { dg(bcd_h[11:8], bcd_h[11:8] == 4'd0),
                   dg(bcd_h[7:4],  bcd_h[11:4] == 8'd0),
                   dg(bcd_h[3:0],  1'b0) };
wire [31:0] pw4 = { dg(bcd_pw[15:12], bcd_pw[15:12] == 4'd0),
                    dg(bcd_pw[11:8],  bcd_pw[15:8]  == 8'd0),
                    dg(bcd_pw[7:4],   bcd_pw[15:4]  == 12'd0),
                    dg(bcd_pw[3:0],   1'b0) };
wire [23:0] ph3 = { dg(bcd_ph[11:8], bcd_ph[11:8] == 4'd0),
                    dg(bcd_ph[7:4],  bcd_ph[11:4] == 8'd0),
                    dg(bcd_ph[3:0],  1'b0) };

// ULD status as two BCD digits, by table: the codes are 0..14, so a lookup
// is two LUT levels where a general divide-by-ten is a compare chain and a
// subtract.  Anything else -- 255, "no name in ULD" -- shows as 99.
function [7:0] hx;                      // one hex digit, uppercase
    input [3:0] d;
    hx = (d < 4'd10) ? (8'h30 + {4'd0, d}) : (8'h37 + {4'd0, d});
endfunction

reg [7:0] code_bcd;
always @(*) begin
    case (s_code)
    8'd0 : code_bcd = 8'h00;  8'd1 : code_bcd = 8'h01;  8'd2 : code_bcd = 8'h02;
    8'd3 : code_bcd = 8'h03;  8'd4 : code_bcd = 8'h04;  8'd5 : code_bcd = 8'h05;
    8'd6 : code_bcd = 8'h06;  8'd7 : code_bcd = 8'h07;  8'd8 : code_bcd = 8'h08;
    8'd9 : code_bcd = 8'h09;  8'd10: code_bcd = 8'h10;  8'd11: code_bcd = 8'h11;
    8'd12: code_bcd = 8'h12;  8'd13: code_bcd = 8'h13;  8'd14: code_bcd = 8'h14;
    default: code_bcd = 8'h99;
    endcase
end

reg [63:0] t_dist, t_size, t_pix;
always @(*) begin
    case (s_state)
    // 10-03 evening: Chinese (user).  Same states, one-to-one:
    3'd0:    t_dist = {CN_GUAN, CN_BI,             {6{8'h20}}};  // OFF     关闭
    3'd1:    t_dist = {CN_QI, CN_DONG,             {6{8'h20}}};  // BOOT    启动
    3'd2:    t_dist = {CN_PEI, CN_ZHI4, CN_ZHONG,  {5{8'h20}}};  // INIT    配置中
    3'd4:    t_dist = {CN_WU, CN_YING, CN_DA2,     {5{8'h20}}};  // NO ACK  无应答
    3'd5:    t_dist = {CN_QI2, CN_JIAN2, CN_CUO,               // BAD ID  器件错EACD
                       hx(s_id[15:12]), hx(s_id[11:8]), hx(s_id[7:4]), hx(s_id[3:0]), 8'h20};
    3'd6:    t_dist = {CN_CHAO, CN_SHI5,           {6{8'h20}}};  // TIMEOUT 超时
    3'd7:    t_dist = {CN_ZONG, CN_XIAN, CN_GU, CN_ZHANG, {4{8'h20}}};  // BUS ERR 总线故障
    default: t_dist = (s_code == 8'd0)
                    ? {d4, "    "}
                    : {d4, " ", CN_CUO, 8'h30 + {4'd0, code_bcd[7:4]}, 8'h30 + {4'd0, code_bcd[3:0]}};  // E02 -> 错02
    endcase

    if (!s_dok)       t_size = {CN_WU, CN_CE, CN_JU,       {5{8'h20}}};  // 无测距
    else if (!s_aff)  t_size = {CN_FANG, CN_SHE, CN_ZHONG, {5{8'h20}}};  // 仿射中
    else if (!found)  t_size = {CN_WU, CN_KUANG,           {6{8'h20}}};  // 无框
    else              t_size = {w3, "X", h3, s_mov ? CN_DONG : " "};     // 'M' -> 动

    t_pix = found ? {pw4, "X", ph3} : {CN_WU, CN_KUANG, {6{8'h20}}};
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        dist_text <= {CN_GUAN, CN_BI, {6{8'h20}}};
        size_text <= {CN_WU, CN_CE, CN_JU, {5{8'h20}}};
        pix_text  <= {CN_WU, CN_KUANG, {6{8'h20}}};
        size_w_mm <= 16'd0; size_h_mm <= 16'd0; size_ok <= 1'b0;
        box_found <= 1'b0; box_any <= 1'b0; box_x0 <= 12'd0; box_y0 <= 12'd0;
        box_w_px  <= 12'd0; box_h_px <= 12'd0; pub_stb <= 1'b0;
        size_d_mm <= 16'd0; size_why <= 2'd1;
    end else begin
        pub_stb <= (cs == C_PUB);
        if (cs == C_PUB) begin
            dist_text <= t_dist;
            size_text <= t_size;
            pix_text  <= t_pix;
            size_w_mm <= w_mm;
            size_h_mm <= h_mm;
            size_ok   <= s_dok && s_aff && found;
            box_found <= found && s_aff;
            box_any   <= s_any;
            box_x0    <= bx;
            box_y0    <= by;
            box_w_px  <= bw;
            box_h_px  <= bh;
            size_d_mm <= s_dist;
            size_why  <= !s_dok ? 2'd1 : !s_aff ? 2'd2 : !found ? 2'd3 : 2'd0;
        end
    end
end

endmodule
