//---------------------------------------------------------------------------
// aim_sched -- security mode (HANDOFF §-9.3): point the head-mounted VL53L1X
// at each motion box in turn, range it, and bind the reading to that box.
//
// 2026-10-01.  The camera is fixed; the SG90 head carries only the ToF
// (servo_pantilt AIM_MODE = 1), so moving it never disturbs the detector.
//
// ONE TARGET, START TO FINISH (the measure sequencer, ms_*)
//   pick the box measured longest ago (never-measured first)
//   -> aim_go at its centre                       servo_pantilt maps px -> us
//   -> wait SETTLE_MS                             PWM latch 20 ms + SG90 slew
//   -> drop DISCARD readings                      their integration may have
//                                                 straddled the slew
//   -> take NMEAS readings, keep the trusted ones RangeStatus == 0 AND
//                                                 sigma <= SIG_MAX_MM
//   -> median of the kept ones, if at least half survived; else "?"
//   -> write {centre, distance, ok} into the table, age 0
// At the defaults that is 150 + 60 + 3*60 ~ 400 ms a target: 2-3 targets a
// second, which is the budget §-9.3 item 4 set.
//
// WHY THE TABLE IS KEYED BY POSITION, NOT BY BOX SLOT
//   motion_frame_drawer's NBOX slots are re-filled every frame and a slot
//   index is not an identity.  So a reading is stored with the box CENTRE it
//   was aimed at (half-block units, x0 + x1), and every frame each box picks
//   up the nearest entry within GATE_X2 / GATE_Y2.  An entry nobody refreshes
//   ages out; an entry older than STALE_FR shows "?" rather than a number.
//
// ⚠ ONE FRAME'S WORK IS DONE FROM ONE SNAPSHOT, AND PUBLISHED ON ONE CLOCK.
//   At the vs rising edge the boxes AND the table are copied; association,
//   size, BCD and target selection all run on the copy; the label table and
//   the result table are written together in F_PUB.  The det_overlay 09-19
//   lesson: a reader must never see this frame's boxes next to last frame's
//   distances.  Timing: the chain's vs is ~vtc_vs, so its rising edge is the
//   END of the 5-line sync pulse, 35 lines (~77,000 clocks) before active
//   video, and motion_frame_drawer publishes its boxes ~80 clocks after the
//   FALLING edge -- so this snapshot holds exactly the boxes the green
//   overlay is about to draw, and the ~600-clock sequence is done long
//   before line 0.
//
// ⚠ A SELECTION COMPUTED BEFORE A TABLE WRITE IS NOT USED AFTER IT.  The
//   measure sequencer finishes asynchronously to frames; a selection made
//   from a snapshot that predates the write would pick the target just
//   measured (it still looked never-measured).  tgen counts writes and a
//   selection is accepted only if its snapshot saw the current tgen.
//
// SIZE: the pinhole model of tof_size, W = w_px * D / F_PX, with D = THIS
// box's own distance.  Motion boxes are block-quantised (128 x 72 px), so the
// size is block-quantised too: ~190 mm steps in W at 2 m.  It is a coarse
// size class, not a measurement -- §-9.4 says the same of the workpiece mode.
//
// NO DSP, ONE CARRY CHAIN PER CLOCK.  Shift-add multiplies, double-dabble
// BCD, two clocks per association pair.
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module aim_sched #(
parameter integer NBOX      = 4,          // <= 8 (3-bit indices)
parameter integer BLK_W     = 128,
parameter integer BLK_H     = 72,
parameter integer IMG_HDISP = 1920,
parameter integer IMG_VDISP = 1080,
parameter integer CLK_HZ    = 150000000,

// Focal length in pixels, ⚠ a GUESS until calibrated (tof_size.v header has
// the A4 procedure).  Must match tof_size's.
parameter integer F_PX      = 1371,
parameter integer D_OFS_MM  = 0,

parameter integer SETTLE_MS = 150,
parameter integer DISCARD   = 1,
parameter integer NMEAS     = 3,          // 1..7
// 0 = no sigma gate.  ULD's own sigma-fail threshold is much looser; this is
// the "don't print a number you would not bet on" gate (§-9.5).
parameter integer SIG_MAX_MM  = 25,
// Per-target give-up, from the end of the settle: a ranger that is not
// ranging must not stall the round-robin.
parameter integer MEAS_TMO_MS = 600,

parameter [4:0]  GATE_X2    = 5'd4,       // half-blocks: 2 blocks = 256 px
parameter [4:0]  GATE_Y2    = 5'd4,       //              2 blocks = 144 px
parameter [7:0]  STALE_FR   = 8'd180,     // 3 s at 60 Hz
parameter [7:0]  ALARM_HOLD = 8'd90,      // ALARM stays 1.5 s after the last box
parameter [7:0]  PARK_FR    = 8'd120,     // no box this long -> aim at centre
// The box being measured has been gone this many frames in a row: abandon
// it WITHOUT writing.  Otherwise the reading -- of whatever is behind where
// the object was -- lands in the table at that position, and the next box
// to appear there inherits a wall's distance.  >1 so a one-frame detector
// dropout does not throw a measurement away.
parameter [2:0]  LOST_FR    = 3'd3
)(
input  wire        clk,
input  wire        rst_n,
input  wire        vs,
input  wire        en,                    // security mode selected

// motion_frame_drawer's published boxes, BLOCK INDICES
input  wire [NBOX*4-1:0] box_x0,
input  wire [NBOX*4-1:0] box_x1,
input  wire [NBOX*4-1:0] box_y0,
input  wire [NBOX*4-1:0] box_y1,
input  wire [NBOX-1:0]   box_valid,

input  wire [2:0]  tof_state,
input  wire [15:0] dist_mm,
input  wire [7:0]  dist_code,
input  wire [13:0] dist_sigma,
input  wire        dist_stb,

// to servo_pantilt (AIM_MODE = 1)
output reg  [11:0] aim_x,
output reg  [11:0] aim_y,
output reg         aim_go,

// LABEL TABLE, for aim_label.  Published together in F_PUB.
output reg  [NBOX*4-1:0]  lb_x0,
output reg  [NBOX*4-1:0]  lb_y0,
output reg  [NBOX-1:0]    lb_valid,
output reg  [NBOX-1:0]    lb_dok,       // distance trusted -> numbers, else '?'
output reg  [NBOX-1:0]    lb_aim,       // the head is on this box right now
output reg  [NBOX*16-1:0] lb_d_bcd,     // 4 BCD digits each, mm
output reg  [NBOX*16-1:0] lb_w_bcd,
output reg  [NBOX*16-1:0] lb_h_bcd,
output reg                alarm,

//---------------------------------------------------------------------------
// ⭐ RESULT TABLE FOR THE ETHERNET / SD SIDE (teammates).  Read it on res_stb
// or any time after -- it is written on that one clock and holds a whole
// frame.  One 128-bit record per box slot, slot b at [b*128 +: 128]:
//   [127]     valid          [126] dist_ok        [125] aiming now
//   [124]     alarm (global copy)
//   [123:120] class          0 = unclassified (stage-3 CNN fills this)
//   [119:108] x0 px          [107:96] x1 px (inclusive)
//   [95:84]   y0 px          [83:72]  y1 px (inclusive)
//   [71:56]   distance mm    [55:40]  width mm      [39:24] height mm
//   [23:16]   age, frames since this box's distance was measured (255 never)
//   [15:0]    reserved, 0
// res_mode: 0 = security.  res_seq increments on every publish.
//---------------------------------------------------------------------------
output reg  [NBOX*128-1:0] res_tab,
output reg  [7:0]          res_seq,
output reg                 res_stb,
output wire                res_mode,

// diagnostics (ChipWatcher / OSD)
output wire [2:0]  ms_state,
output reg  [7:0]  ms_count            // targets ranged since power-up, wraps
);

localparam integer NT     = NBOX;
localparam integer MS_DIV = CLK_HZ / 1000;
localparam [2:0]   ST_RANGE = 3'd3;
localparam [11:0]  CX = IMG_HDISP / 2;
localparam [11:0]  CY = IMG_VDISP / 2;

// W = nbx * BLK_W * D / F_PX  =  (nbx * KW * D + 2^15) >> 16
localparam integer RSH = 16;
localparam integer KW  = ((BLK_W << RSH) + F_PX / 2) / F_PX;
localparam integer KH  = ((BLK_H << RSH) + F_PX / 2) / F_PX;

localparam integer NMIN = (NMEAS + 1) / 2;          // at least half kept

assign res_mode = 1'b0;

//---------------------------------------------------------------------------
// Edges and ticks
//---------------------------------------------------------------------------
reg vs_d;
always @(posedge clk or negedge rst_n)
    if (!rst_n) vs_d <= 1'b0; else vs_d <= vs;
wire frame_edge = vs & ~vs_d;

reg  [17:0] msdiv;
wire        ms_tick = (msdiv == MS_DIV - 1);
always @(posedge clk or negedge rst_n)
    if (!rst_n) msdiv <= 18'd0; else msdiv <= ms_tick ? 18'd0 : msdiv + 18'd1;

//---------------------------------------------------------------------------
// The live table -- owned by the measure sequencer, aged at frame_edge.
//---------------------------------------------------------------------------
reg        tu   [0:NT-1];               // used
reg [4:0]  tcx  [0:NT-1];               // centre, half-blocks (x0 + x1)
reg [4:0]  tcy  [0:NT-1];
reg [15:0] tdst [0:NT-1];
reg        tok  [0:NT-1];
reg [7:0]  tage [0:NT-1];
reg [7:0]  tgen;

// Selection handed over by the frame sequencer (F_PUB)
reg        sel_pub;                     // one clock
reg        sel_any;
reg        sel_busy, sel_thit;          // snapshot was mid-measurement / its box seen
reg [4:0]  sel_cx, sel_cy;
reg [7:0]  sel_gen;                     // tgen the selection's snapshot saw

//---------------------------------------------------------------------------
// Measure sequencer
//---------------------------------------------------------------------------
localparam [2:0] M_IDLE = 3'd0, M_GO = 3'd1, M_SETTLE = 3'd2, M_DISC = 3'd3,
                 M_COLL = 3'd4, M_MED = 3'd5, M_FIND = 3'd6, M_WRITE = 3'd7;

reg [2:0]  ms;
reg        have_sel;
reg [4:0]  h_cx, h_cy;                  // the accepted selection
reg [4:0]  acx, acy;                    // centre being measured
reg        parked;
reg [7:0]  noobj;
// ⚠ 16 bits: a 10-bit timer silently truncated MEAS_TMO_MS = 1500 to 476
// (astb T8).  The build's 150 / 600 fit either way; the parameters may not.
reg [15:0] tmr;                         // ms
reg [2:0]  ndisc;
reg [2:0]  natt, nv;
reg [15:0] buf_d [0:6];
reg [2:0]  mi, mj;
reg [2:0]  rank;
reg [15:0] med;
reg        m_ok;
reg [2:0]  widx;
reg [2:0]  lost_n;

assign ms_state = ms;

wire busy = (ms != M_IDLE);

wire trusted = (dist_code == 8'd0)
            && ((SIG_MAX_MM == 0) || (dist_sigma <= SIG_MAX_MM));

// M_FIND: an entry already at this position, else a free one, else the
// oldest.  Combinational over NT entries; registered into widx.
reg [2:0] f_hit_i, f_free_i, f_old_i;
reg       f_hit, f_free;
reg [7:0] f_old_age;
integer   fi;
always @(*) begin
    f_hit = 1'b0; f_hit_i = 3'd0;
    f_free = 1'b0; f_free_i = 3'd0;
    f_old_age = 8'd0; f_old_i = 3'd0;
    for (fi = NT - 1; fi >= 0; fi = fi - 1) begin
        if (tu[fi] && (((tcx[fi] > acx) ? (tcx[fi] - acx) : (acx - tcx[fi])) <= GATE_X2)
                   && (((tcy[fi] > acy) ? (tcy[fi] - acy) : (acy - tcy[fi])) <= GATE_Y2)) begin
            f_hit = 1'b1; f_hit_i = fi;
        end
        if (!tu[fi]) begin
            f_free = 1'b1; f_free_i = fi;
        end
    end
    for (fi = 0; fi < NT; fi = fi + 1)
        if (tage[fi] >= f_old_age) begin
            f_old_age = tage[fi]; f_old_i = fi;
        end
end

integer ti;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        ms <= M_IDLE; have_sel <= 1'b0; h_cx <= 5'd0; h_cy <= 5'd0;
        acx <= 5'd0; acy <= 5'd0; parked <= 1'b0; noobj <= 8'd0;
        tmr <= 16'd0; ndisc <= 3'd0; natt <= 3'd0; nv <= 3'd0;
        mi <= 3'd0; mj <= 3'd0; rank <= 3'd0; med <= 16'd0; m_ok <= 1'b0;
        widx <= 3'd0; tgen <= 8'd0; ms_count <= 8'd0; lost_n <= 3'd0;
        aim_x <= CX; aim_y <= CY; aim_go <= 1'b0;
        for (ti = 0; ti < NT; ti = ti + 1) begin
            tu[ti] <= 1'b0; tcx[ti] <= 5'd0; tcy[ti] <= 5'd0;
            tdst[ti] <= 16'd0; tok[ti] <= 1'b0; tage[ti] <= 8'd255;
        end
        for (ti = 0; ti < 7; ti = ti + 1) buf_d[ti] <= 16'd0;
    end else begin
        aim_go <= 1'b0;

        // Ageing.  An entry that saturates is dropped.  A write on the same
        // clock (M_WRITE below) comes later in this block and wins.
        if (frame_edge) begin
            for (ti = 0; ti < NT; ti = ti + 1)
                if (tage[ti] != 8'd255) tage[ti] <= tage[ti] + 8'd1;
                else                    tu[ti]   <= 1'b0;
            noobj <= (|box_valid) ? 8'd0 : ((noobj == 8'd255) ? noobj : noobj + 8'd1);
        end

        // A fresh selection, if no write has happened since its snapshot.
        if (sel_pub) begin
            have_sel <= sel_any && (sel_gen == tgen);
            h_cx <= sel_cx; h_cy <= sel_cy;
        end

        case (ms)
        M_IDLE: begin
            if (!en || (noobj >= PARK_FR)) begin
                if (!parked) begin
                    aim_x <= CX; aim_y <= CY; aim_go <= 1'b1;
                    parked <= 1'b1;
                end
            end else if (have_sel && !sel_pub) begin
                have_sel <= 1'b0;
                acx <= h_cx; acy <= h_cy;
                aim_x <= ({7'd0, h_cx} + 12'd1) * (BLK_W / 2);
                aim_y <= ({7'd0, h_cy} + 12'd1) * (BLK_H / 2);
                parked <= 1'b0;
                ms <= M_GO;
            end
        end

        M_GO: begin
            aim_go <= 1'b1;
            lost_n <= 3'd0;
            tmr <= SETTLE_MS;
            ms <= M_SETTLE;
        end

        M_SETTLE: if (ms_tick) begin
            if (tmr <= 16'd1) begin
                tmr <= MEAS_TMO_MS; ndisc <= 3'd0; natt <= 3'd0; nv <= 3'd0;
                ms <= (DISCARD == 0) ? M_COLL : M_DISC;
            end else
                tmr <= tmr - 16'd1;
        end

        M_DISC: begin
            if (dist_stb) begin
                ndisc <= ndisc + 3'd1;
                if (ndisc == DISCARD - 1) ms <= M_COLL;
            end
            if (ms_tick) begin
                if (tmr <= 16'd1) ms <= M_MED; else tmr <= tmr - 16'd1;
            end
        end

        M_COLL: begin
            if (dist_stb) begin
                natt <= natt + 3'd1;
                if (trusted) begin
                    buf_d[nv] <= dist_mm;
                    nv <= nv + 3'd1;
                end
                if (natt == NMEAS - 1) begin
                    ms <= M_MED; mi <= 3'd0; mj <= 3'd0; rank <= 3'd0; m_ok <= 1'b0;
                end
            end
            if (ms_tick) begin
                if (tmr <= 16'd1) begin
                    ms <= M_MED; mi <= 3'd0; mj <= 3'd0; rank <= 3'd0; m_ok <= 1'b0;
                end else tmr <= tmr - 16'd1;
            end
        end

        // Median by rank: buf[i] is the median when exactly (nv-1)/2 of the
        // kept readings sort before it (ties broken by index).  nv^2 clocks.
        M_MED: begin
            if (nv < NMIN) begin
                m_ok <= 1'b0;
                ms <= M_FIND;
            end else begin
                if (mj < nv) begin
                    if ((buf_d[mj] < buf_d[mi]) || ((buf_d[mj] == buf_d[mi]) && (mj < mi)))
                        rank <= rank + 3'd1;
                    mj <= mj + 3'd1;
                end else begin
                    if (rank == ((nv - 3'd1) >> 1)) begin
                        med  <= buf_d[mi];
                        m_ok <= 1'b1;
                        ms   <= M_FIND;
                    end else if (mi == nv - 3'd1) begin
                        m_ok <= 1'b0;           // cannot happen: ranks are
                        ms   <= M_FIND;         // a permutation.  Never hang.
                    end
                    mi <= mi + 3'd1; mj <= 3'd0; rank <= 3'd0;
                end
            end
        end

        M_FIND: begin
            widx <= f_hit ? f_hit_i : (f_free ? f_free_i : f_old_i);
            ms <= M_WRITE;
        end

        default: begin                  // M_WRITE
            tu[widx]   <= 1'b1;
            tcx[widx]  <= acx;
            tcy[widx]  <= acy;
            tdst[widx] <= m_ok ? med : 16'd0;
            tok[widx]  <= m_ok;
            tage[widx] <= 8'd0;
            tgen       <= tgen + 8'd1;
            have_sel   <= 1'b0;
            ms_count   <= ms_count + 8'd1;
            ms <= M_IDLE;
        end
        endcase

        // Target gone: count consecutive frames whose snapshot was taken
        // mid-measurement (so its aim point is this target's) and found no
        // box there.  A write between snapshot and sel_pub leaves ms in
        // IDLE, so a stale verdict can never hit the next target -- the next
        // target needs a sel_pub of its own to start.
        if (sel_pub && sel_busy
            && ((ms == M_SETTLE) || (ms == M_DISC) || (ms == M_COLL))) begin
            if (sel_thit)
                lost_n <= 3'd0;
            else if (lost_n >= LOST_FR - 3'd1) begin
                ms <= M_IDLE; lost_n <= 3'd0; have_sel <= 1'b0;
            end else
                lost_n <= lost_n + 3'd1;
        end

        // Leaving security mode abandons the target at once; the head parks
        // on the next clock.
        if (!en && (ms != M_IDLE) && (ms != M_FIND) && (ms != M_WRITE)) begin
            ms <= M_IDLE; parked <= 1'b0;
        end
    end
end

//---------------------------------------------------------------------------
// Frame sequencer
//---------------------------------------------------------------------------
localparam [2:0] F_IDLE = 3'd0, F_ASSOC = 3'd1, F_SEL = 3'd2, F_MUL = 3'd3,
                 F_BCD  = 3'd4, F_PUB   = 3'd5;

reg [2:0]  cs;

// snapshot
reg [3:0]  sx0 [0:NBOX-1];
reg [3:0]  sx1 [0:NBOX-1];
reg [3:0]  sy0 [0:NBOX-1];
reg [3:0]  sy1 [0:NBOX-1];
reg [NBOX-1:0] sv;
reg        stu  [0:NT-1];
reg [4:0]  stcx [0:NT-1];
reg [4:0]  stcy [0:NT-1];
reg [15:0] stds [0:NT-1];
reg        stok [0:NT-1];
reg [7:0]  stag [0:NT-1];
reg        s_busy, s_en;
reg [4:0]  s_acx, s_acy;
reg [7:0]  s_gen;

// association
reg [2:0]  ab, at;
reg        aph;                         // 0: differences, 1: compare
reg [4:0]  adx, ady;
reg        mh  [0:NBOX-1];
reg [2:0]  mt  [0:NBOX-1];
reg [5:0]  mdd [0:NBOX-1];

// per-box results
reg [15:0] vd   [0:NBOX-1];
reg        vok  [0:NBOX-1];
reg        vaim [0:NBOX-1];
reg [7:0]  vage [0:NBOX-1];
reg [15:0] vw   [0:NBOX-1];
reg [15:0] vh   [0:NBOX-1];
reg [15:0] bd   [0:NBOX-1];
reg [15:0] bw   [0:NBOX-1];
reg [15:0] bh   [0:NBOX-1];

// selection
reg        f_any;
reg [7:0]  f_age;
reg [4:0]  f_cx, f_cy;

// multiply: m_acc += m_a while m_b != 0, one bit of m_b per clock
reg [2:0]  ub;
reg [1:0]  ustep;                       // 0: nbx*KW  1: *D -> W  2: nby*KH  3: *D -> H
reg        urun;
reg [31:0] m_a, m_acc;
reg [15:0] m_b;

// double dabble
reg [2:0]  kb;
reg [1:0]  kv;
reg [13:0] bb;
reg [15:0] bcd;
reg [3:0]  bk;

reg [7:0]  alarm_cnt;

wire [15:0] bcd_adj = { (bcd[15:12] >= 4'd5) ? bcd[15:12] + 4'd3 : bcd[15:12],
                        (bcd[11:8]  >= 4'd5) ? bcd[11:8]  + 4'd3 : bcd[11:8],
                        (bcd[7:4]   >= 4'd5) ? bcd[7:4]   + 4'd3 : bcd[7:4],
                        (bcd[3:0]   >= 4'd5) ? bcd[3:0]   + 4'd3 : bcd[3:0] };

wire [15:0] k_val = (kv == 2'd0) ? vd[kb] : (kv == 2'd1) ? vw[kb] : vh[kb];
wire [13:0] k_src = (k_val > 16'd9999) ? 14'd9999 : k_val[13:0];

// association, phase 0 operands
wire [4:0]  b_cx = {1'b0, sx0[ab]} + {1'b0, sx1[ab]};
wire [4:0]  b_cy = {1'b0, sy0[ab]} + {1'b0, sy1[ab]};

// selection / aim flag, per box kb in F_SEL
wire [4:0]  k_cx = {1'b0, sx0[kb]} + {1'b0, sx1[kb]};
wire [4:0]  k_cy = {1'b0, sy0[kb]} + {1'b0, sy1[kb]};
wire [4:0]  k_dax = (k_cx > s_acx) ? (k_cx - s_acx) : (s_acx - k_cx);
wire [4:0]  k_day = (k_cy > s_acy) ? (k_cy - s_acy) : (s_acy - k_cy);
wire        k_hit = mh[kb];
wire [2:0]  k_t   = mt[kb];
wire        k_ok  = sv[kb] && k_hit && stok[k_t] && (stag[k_t] <= STALE_FR);
wire [7:0]  k_age = k_hit ? stag[k_t] : 8'd255;

// D_OFS applied and clamped to 1..8191 so the products stay in 32 bits.
wire signed [17:0] u_dcs = $signed({2'b00, vd[ub]}) + D_OFS_MM;
wire        [12:0] u_dc  = (u_dcs < 1) ? 13'd1 : (u_dcs > 8191) ? 13'd8191 : u_dcs[12:0];
wire        [3:0]  u_nbx = sx1[ub] - sx0[ub] + 4'd1;
wire        [3:0]  u_nby = sy1[ub] - sy0[ub] + 4'd1;

// Result-table pixel coordinates, sized here so no 32-bit integer ever
// lands inside the record concatenation.
wire [11:0] rx0 [0:NBOX-1];
wire [11:0] rx1 [0:NBOX-1];
wire [11:0] ry0 [0:NBOX-1];
wire [11:0] ry1 [0:NBOX-1];
genvar gb;
generate for (gb = 0; gb < NBOX; gb = gb + 1) begin : g_px
    assign rx0[gb] = sx0[gb] * BLK_W;
    assign rx1[gb] = sx1[gb] * BLK_W + (BLK_W - 1);
    assign ry0[gb] = sy0[gb] * BLK_H;
    assign ry1[gb] = sy1[gb] * BLK_H + (BLK_H - 1);
end endgenerate

wire [7:0] al_next = !s_en               ? 8'd0       :
                     (|sv)               ? ALARM_HOLD :
                     (alarm_cnt != 8'd0) ? alarm_cnt - 8'd1 : 8'd0;

reg any_aim;
integer ai;
always @(*) begin
    any_aim = 1'b0;
    for (ai = 0; ai < NBOX; ai = ai + 1) any_aim = any_aim | vaim[ai];
end

integer si;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        cs <= F_IDLE;
        for (si = 0; si < NBOX; si = si + 1) begin
            sx0[si] <= 4'd0; sx1[si] <= 4'd0; sy0[si] <= 4'd0; sy1[si] <= 4'd0;
            mh[si] <= 1'b0; mt[si] <= 3'd0; mdd[si] <= 6'd0;
            vd[si] <= 16'd0; vok[si] <= 1'b0; vaim[si] <= 1'b0; vage[si] <= 8'd255;
            vw[si] <= 16'd0; vh[si] <= 16'd0;
            bd[si] <= 16'd0; bw[si] <= 16'd0; bh[si] <= 16'd0;
        end
        for (si = 0; si < NT; si = si + 1) begin
            stu[si] <= 1'b0; stcx[si] <= 5'd0; stcy[si] <= 5'd0;
            stds[si] <= 16'd0; stok[si] <= 1'b0; stag[si] <= 8'd255;
        end
        sv <= {NBOX{1'b0}}; s_busy <= 1'b0; s_en <= 1'b0;
        s_acx <= 5'd0; s_acy <= 5'd0; s_gen <= 8'd0;
        ab <= 3'd0; at <= 3'd0; aph <= 1'b0; adx <= 5'd0; ady <= 5'd0;
        f_any <= 1'b0; f_age <= 8'd0; f_cx <= 5'd0; f_cy <= 5'd0;
        ub <= 3'd0; ustep <= 2'd0; urun <= 1'b0;
        m_a <= 32'd0; m_acc <= 32'd0; m_b <= 16'd0;
        kb <= 3'd0; kv <= 2'd0; bb <= 14'd0; bcd <= 16'd0; bk <= 4'd0;
        alarm_cnt <= 8'd0;
        sel_pub <= 1'b0; sel_any <= 1'b0; sel_cx <= 5'd0; sel_cy <= 5'd0; sel_gen <= 8'd0;
        sel_busy <= 1'b0; sel_thit <= 1'b0;
        lb_x0 <= 0; lb_y0 <= 0; lb_valid <= 0; lb_dok <= 0; lb_aim <= 0;
        lb_d_bcd <= 0; lb_w_bcd <= 0; lb_h_bcd <= 0; alarm <= 1'b0;
        res_tab <= 0; res_seq <= 8'd0; res_stb <= 1'b0;
    end else begin
        sel_pub <= 1'b0;
        res_stb <= 1'b0;

        case (cs)
        F_IDLE: if (frame_edge) begin
            for (si = 0; si < NBOX; si = si + 1) begin
                sx0[si] <= box_x0[si*4 +: 4]; sx1[si] <= box_x1[si*4 +: 4];
                sy0[si] <= box_y0[si*4 +: 4]; sy1[si] <= box_y1[si*4 +: 4];
                mh[si]  <= 1'b0; mdd[si] <= 6'd63;
            end
            sv <= box_valid;
            for (si = 0; si < NT; si = si + 1) begin
                stu[si] <= tu[si]; stcx[si] <= tcx[si]; stcy[si] <= tcy[si];
                stds[si] <= tdst[si]; stok[si] <= tok[si]; stag[si] <= tage[si];
            end
            s_busy <= busy;
            s_en   <= en;
            s_acx  <= acx; s_acy <= acy;
            s_gen  <= tgen;
            ab <= 3'd0; at <= 3'd0; aph <= 1'b0;
            cs <= F_ASSOC;
        end

        // Nearest table entry within the gate, per box.  Phase 0 takes the
        // two differences, phase 1 compares -- two short chains, two clocks.
        F_ASSOC: begin
            if (!aph) begin
                adx <= (b_cx > stcx[at]) ? (b_cx - stcx[at]) : (stcx[at] - b_cx);
                ady <= (b_cy > stcy[at]) ? (b_cy - stcy[at]) : (stcy[at] - b_cy);
                aph <= 1'b1;
            end else begin
                if (sv[ab] && stu[at] && (adx <= GATE_X2) && (ady <= GATE_Y2)
                    && (({1'b0, adx} + {1'b0, ady}) < mdd[ab])) begin
                    mh[ab]  <= 1'b1;
                    mt[ab]  <= at;
                    mdd[ab] <= {1'b0, adx} + {1'b0, ady};
                end
                aph <= 1'b0;
                if (at == NT - 1) begin
                    at <= 3'd0;
                    if (ab == NBOX - 1) begin
                        kb <= 3'd0; f_any <= 1'b0; f_age <= 8'd0;
                        cs <= F_SEL;
                    end
                    ab <= ab + 3'd1;
                end else
                    at <= at + 3'd1;
            end
        end

        // Per box: the distance it inherits, whether it is trusted, whether
        // the head is on it, and the oldest one as the next target.
        F_SEL: begin
            vd[kb]   <= k_ok ? stds[k_t] : 16'd0;
            vok[kb]  <= k_ok;
            vage[kb] <= k_age;
            vaim[kb] <= sv[kb] && s_busy && (k_dax <= GATE_X2) && (k_day <= GATE_Y2);
            if (sv[kb] && s_en && (!f_any || (k_age > f_age))) begin
                f_any <= 1'b1; f_age <= k_age; f_cx <= k_cx; f_cy <= k_cy;
            end
            if (kb == NBOX - 1) begin
                ub <= 3'd0; ustep <= 2'd0; urun <= 1'b0;
                cs <= F_MUL;
            end
            kb <= kb + 3'd1;
        end

        // Sizes, for trusted boxes only.
        F_MUL: begin
            if (!urun) begin
                if (!vok[ub]) begin
                    vw[ub] <= 16'd0; vh[ub] <= 16'd0;
                    if (ub == NBOX - 1) begin
                        kb <= 3'd0; kv <= 2'd0; bk <= 4'd0; cs <= F_BCD;
                    end
                    ub <= ub + 3'd1;
                end else begin
                    case (ustep)
                    2'd0: begin m_a <= KW;    m_b <= {12'd0, u_nbx}; m_acc <= 32'd0; end
                    2'd2: begin m_a <= KH;    m_b <= {12'd0, u_nby}; m_acc <= 32'd0; end
                    default: begin m_a <= m_acc; m_b <= {3'd0, u_dc};
                                   m_acc <= 32'd1 << (RSH - 1); end
                    endcase
                    urun <= 1'b1;
                end
            end else if (m_b != 16'd0) begin
                if (m_b[0]) m_acc <= m_acc + m_a;
                m_a <= {m_a[30:0], 1'b0};
                m_b <= {1'b0, m_b[15:1]};
            end else begin
                urun <= 1'b0;
                // < 2^32 for F_PX >= ~360: 15 * KW * 8191, KW = 128 * 2^16 / F_PX
                if (ustep == 2'd1) vw[ub] <= m_acc[RSH+15:RSH];
                if (ustep == 2'd3) begin
                    vh[ub] <= m_acc[RSH+15:RSH];
                    if (ub == NBOX - 1) begin
                        kb <= 3'd0; kv <= 2'd0; bk <= 4'd0; cs <= F_BCD;
                    end
                    ub <= ub + 3'd1;
                end
                ustep <= ustep + 2'd1;
            end
        end

        // Three numbers per box, 14 shifts each.
        F_BCD: begin
            if (bk == 4'd0) begin
                bb <= k_src; bcd <= 16'd0; bk <= 4'd1;
            end else begin
                bcd <= {bcd_adj[14:0], bb[13]};
                bb  <= {bb[12:0], 1'b0};
                if (bk == 4'd14) begin
                    bk <= 4'd0;
                    case (kv)
                    2'd0:    bd[kb] <= {bcd_adj[14:0], bb[13]};
                    2'd1:    bw[kb] <= {bcd_adj[14:0], bb[13]};
                    default: bh[kb] <= {bcd_adj[14:0], bb[13]};
                    endcase
                    if (kv == 2'd2) begin
                        kv <= 2'd0;
                        if (kb == NBOX - 1) cs <= F_PUB;
                        kb <= kb + 3'd1;
                    end else
                        kv <= kv + 2'd1;
                end else
                    bk <= bk + 4'd1;
            end
        end

        default: begin                  // F_PUB: everything on one clock
            for (si = 0; si < NBOX; si = si + 1) begin
                lb_x0[si*4 +: 4]    <= sx0[si];
                lb_y0[si*4 +: 4]    <= sy0[si];
                lb_d_bcd[si*16 +: 16] <= bd[si];
                lb_w_bcd[si*16 +: 16] <= bw[si];
                lb_h_bcd[si*16 +: 16] <= bh[si];
                lb_dok[si] <= vok[si];
                lb_aim[si] <= vaim[si];

                res_tab[si*128 +: 128] <= {
                    sv[si], vok[si], vaim[si], (al_next != 8'd0), 4'd0,
                    rx0[si], rx1[si], ry0[si], ry1[si],
                    vd[si], vw[si], vh[si], vage[si], 16'd0 };
            end
            lb_valid  <= sv & {NBOX{s_en}};
            alarm     <= (al_next != 8'd0);
            alarm_cnt <= al_next;
            res_seq <= res_seq + 8'd1;
            res_stb <= 1'b1;

            sel_pub <= 1'b1;
            sel_any <= f_any;
            sel_busy <= s_busy;
            sel_thit <= any_aim;
            sel_cx  <= f_cx; sel_cy <= f_cy;
            sel_gen <= s_gen;
            cs <= F_IDLE;
        end
        endcase
    end
end

endmodule
