//---------------------------------------------------------------------------
// vl53l1x_ctrl -- brings up an ST VL53L1X time-of-flight ranger over I2C and
// publishes one distance per measurement.  No CPU: the ST "ULD" driver's
// init and ranging loop, transcribed into a step sequencer.
//
// WHERE EVERY NUMBER CAME FROM
//   The 91-byte default table, the VHV warm-up, the distance-mode and timing-
//   budget register values, the inter-measurement formula and the range
//   status mapping are ST's VL53L1X ULD (STSW-IMG009, as shipped in
//   stm32duino/VL53L1X vl53l1x_class.cpp), cross-checked register by
//   register against VL53L1_register_map.h in the Waveshare demo package
//   (VL53L1X资料/.../Arduino/VL53L1X-Arduino-Library).  The model-ID check
//   and the 2V8 pad switch are from that same Waveshare/Pololu library, which
//   is the code the module vendor ships and therefore the one known to work
//   on this board.  Nothing here was tuned.
//
// THE SEQUENCE (pc)
//    0  wait BOOT_MS                      power-on / retry settle
//    1  bus clear: 9 clocks + STOP        frees an SDA a reset left held low
//    2  poll 0x00E5 bit0 == 1             firmware booted
//    3  read 0x010F == 0xEACC             it really is a VL53L1X
//    4  write 0x2D..0x87, 91 bytes        ULD default configuration
//    5  0x0087 = 0x40, 6 poll ready,      one throwaway measurement: the
//    7  0x0086 = 0x01, 8 0x0087 = 0x00    VHV (SPAD bias) calibration
//    9  0x0008 = 0x09, 10 0x000B = 0x00   VHV: two bounds, from last temp
//   11..16  distance mode registers       ULD SetDistanceMode
//   17..18  timing budget A/B             ULD SetTimingBudgetInMs
//   19..20  read osc cal, write 0x006C    ULD SetInterMeasurementInMs
//   21..23  ROI centre + size             ULD SetROI
//   24  0x0087 = 0x40                     start ranging -> state RANGING
//   25  poll 0x0031 bit0 == 1             data ready (active-high: 0x30 = 0x01)
//   26  read 0x0089                       range status
//   29  read 0x0092, 2 bytes              sigma, 14.2 mm (READ_SIGMA = 1 only)
//   27  read 0x0096, 2 bytes              distance, mm
//   28  0x0086 = 0x01, publish, -> 25     clear interrupt
//   30  0x007F = roi_ctr_req               10-04, RUNTIME_ROI only: after a
//   31  0x0080 = roi_xy_req, -> 25           clear, if the request changed
//
// ⚠ EVERY FAILURE RESTARTS FROM pc 0 AND IS SHOWN, NEVER SWALLOWED.  A
// NACK, a stuck SCL or a poll timeout aborts the transaction (STOP, bus
// released), latches the cause in `state`, waits RETRY_MS and starts over.
// The cause stays on screen until ranging actually resumes, so "no module",
// "wrong module", "module alive but never measures" and "wiring shorts SCL"
// are four different readings -- which is the whole point of having them on
// the OSD rather than in ChipWatcher.
//
// ⚠ POWER THE MODULE FROM 3.3 V, NOT 5 V.  The Waveshare board's level
// translator references its host side to VCC, so at VCC = 5 V both bus lines
// are pulled to 5 V -- into 3.3 V FPGA pins.  The 5 V rail the servos run
// from is exactly the wrong one to borrow.  Common ground either way.
// SHUT and INT may be left open: this module polls instead of using INT, and
// the board pulls SHUT up.  If the OSD sticks at NO ACK with the wiring
// checked, tie SHUT to VCC -- a floating SHUT holds the part in reset.
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module vl53l1x_ctrl #(
parameter integer CLK_HZ    = 150000000,
parameter integer I2C_HZ    = 100000,  // 100 k: two LED loads + flying leads

// 1 = short (to ~1.3 m, best immunity to ambient light -- the workpiece
// bench case), 2 = long (to ~4 m).  Anything else is treated as short.
parameter integer DIST_MODE = 1,

// Timing budget, ms.  Short: 15 20 33 50 100 200 500.  Long: 20 33 50 100
// 200 500.  An unsupported value silently becomes 50 -- ULD itself refuses
// it with an error code, and a register sequencer has nowhere to put one.
parameter integer TB_MS     = 50,

// Inter-measurement period, ms.  ULD's rule: must be >= TB_MS.
parameter integer IM_MS     = 60,

// Receiving-array ROI, SPADs, 4..16 each.  16x16 = the full 27 deg cone and
// is ULD's default.  ⭐ THE FIRST KNOB if DIST reads the backdrop instead of
// the workpiece: 8x8 narrows the cone to roughly 20 deg, at some loss of
// signal.  Values <= 10 use the part's own optical centre (read at pc 21).
parameter integer ROI_W     = 16,
parameter integer ROI_H     = 16,

// 1 = I2C/GPIO pads referenced to AVDD (2V8 mode).  The module pulls its
// sensor-side lines up to its own rail, and the vendor's library defaults
// this to true, so 1 is the tested setting.
parameter integer IO_2V8    = 1,

// 1 = also read RESULT__SIGMA_SD0 (0x0092, 14.2 fixed point) on every
// measurement and publish it as dist_sigma -- the ranging noise estimate,
// used by aim_sched as a confidence gate (HANDOFF §-9.3 item 6).  One extra
// 2-byte read, ~0.7 ms at 100 kHz, against a 60 ms period.
// 0 = the 09-25 sequence, bit-exact; dist_sigma then reads 0.
parameter integer READ_SIGMA = 1,

// ⭐ 10-04: 1 = the ROI is an INPUT (roi_ctr_req / roi_xy_req) and may change
// while ranging -- written after a clear-interrupt (ST's own zone-scanning
// recipe, AN5191 people counting, does the same), init writes the request
// instead of ROI_W / ROI_H.  The measurement already running when the write
// lands was configured with the OLD ROI, so the next ROI_SKIP measurements
// are read and cleared but NOT published; dist_roi_* tag every published one
// with the ROI it really used.  0 = the 10-03 sequence, bit-exact.
parameter integer RUNTIME_ROI = 0,
parameter integer ROI_SKIP  = 1,

parameter integer BOOT_MS   = 5,
parameter integer RETRY_MS  = 200,
parameter integer POLL_MS   = 1
)(
input  wire        clk,
input  wire        rst_n,

inout  wire        io_scl,
inout  wire        io_sda,

output reg  [2:0]  state,        // see ST_* below
output reg  [15:0] dist_mm,
output reg  [7:0]  dist_code,    // ULD range status: 0 = valid, 255 = unknown
output reg  [13:0] dist_sigma,   // mm (register >> 2), same strobe; 0 if READ_SIGMA = 0
output reg         dist_stb,     // one clock per new measurement
output reg  [7:0]  err_cnt,      // restarts since power-up, saturating

// 10-03 night: what 0x010F actually read on the last ID check, right or
// wrong.  Shown with BAD ID on the OSD, because the value is the diagnosis:
// FFFF = no data bit ever pulled low (SDA open after the ACK / pull-up only),
// 0000 = SDA held low, EBAA = a VL53L4CD, EAAA = a VL53L3CX, a near miss of
// EACC (one or two bits) = signal integrity on the shifter.
output reg  [15:0] id_rb,

// 10-04 (RUNTIME_ROI = 1): requested ROI -- centre SPAD (ULD's numbering, 199
// = array centre) and ((H-1) << 4) | (W-1).  16 x 16 must use centre 199.
input  wire [7:0]  roi_ctr_req,
input  wire [7:0]  roi_xy_req,
output reg  [7:0]  dist_roi_ctr,  // the ROI the published measurement used
output reg  [7:0]  dist_roi_xy,
output reg  [7:0]  roi_opt        // 0x013E, the part's factory optical centre
);

localparam [2:0] ST_BOOT  = 3'd1,   // waiting for / polling the firmware
                 ST_INIT  = 3'd2,   // writing configuration
                 ST_RANGE = 3'd3,   // measuring
                 ST_NOACK = 3'd4,   // nobody answered at 0x52
                 ST_BADID = 3'd5,   // answered, but model ID != 0xEACC
                 ST_TMO   = 3'd6,   // boot or data-ready never came
                 ST_BUS   = 3'd7;   // SCL held low (stretch watchdog)

//---------------------------------------------------------------------------
// Constants
//---------------------------------------------------------------------------
localparam integer MS_DIV = CLK_HZ / 1000;
localparam integer QDIV   = CLK_HZ / (4 * I2C_HZ);

localparam integer MODE_S = (DIST_MODE == 2) ? 0 : 1;

localparam [7:0]  M_PHASECAL = MODE_S ? 8'h14 : 8'h0A;     // 0x004B
localparam [7:0]  M_VCSEL_A  = MODE_S ? 8'h07 : 8'h0F;     // 0x0060
localparam [7:0]  M_VCSEL_B  = MODE_S ? 8'h05 : 8'h0D;     // 0x0063
localparam [7:0]  M_PHASE_HI = MODE_S ? 8'h38 : 8'hB8;     // 0x0069
localparam [15:0] M_WOI      = MODE_S ? 16'h0705 : 16'h0F0D;  // 0x0078
localparam [15:0] M_INIPH    = MODE_S ? 16'h0606 : 16'h0E0E;  // 0x007A

localparam [15:0] TB_A =
    MODE_S ? ((TB_MS ==  15) ? 16'h001D : (TB_MS ==  20) ? 16'h0051 :
              (TB_MS ==  33) ? 16'h00D6 : (TB_MS == 100) ? 16'h02E1 :
              (TB_MS == 200) ? 16'h03E1 : (TB_MS == 500) ? 16'h0591 : 16'h01AE)
           : ((TB_MS ==  20) ? 16'h001E : (TB_MS ==  33) ? 16'h0060 :
              (TB_MS == 100) ? 16'h01CC : (TB_MS == 200) ? 16'h02D9 :
              (TB_MS == 500) ? 16'h048F : 16'h00AD);
localparam [15:0] TB_B =
    MODE_S ? ((TB_MS ==  15) ? 16'h0027 : (TB_MS ==  20) ? 16'h006E :
              (TB_MS ==  33) ? 16'h006E : (TB_MS == 100) ? 16'h0388 :
              (TB_MS == 200) ? 16'h0496 : (TB_MS == 500) ? 16'h05C1 : 16'h01E8)
           : ((TB_MS ==  20) ? 16'h0022 : (TB_MS ==  33) ? 16'h006E :
              (TB_MS == 100) ? 16'h01EA : (TB_MS == 200) ? 16'h02F8 :
              (TB_MS == 500) ? 16'h04A4 : 16'h00C6);

// ULD: period = osc_cal * IM_MS * 1.075.  Done here as osc * K16 >> 4 with
// K16 rounded, so the multiplier is a compile-time constant and the product
// is 1/16 of an osc count away from ULD's float -- far inside the 10 ms of
// slack between the default IM and TB.
localparam [15:0] IM_K16 = (IM_MS * 1075 * 16 + 500) / 1000;

localparam [7:0] ROI_XY  = ((ROI_H - 1) << 4) | (ROI_W - 1);
localparam       ROI_BIG = (ROI_W > 10) || (ROI_H > 10);

localparam [7:0] PAD_V   = (IO_2V8 != 0) ? 8'h01 : 8'h00;

// ULD VL51L1X_DEFAULT_CONFIGURATION, registers 0x2D..0x87.  Only 0x2E/0x2F
// differ from ST's table, and only when IO_2V8 = 1 (ST's comment on those two
// bytes: "set bit 0 to 1 if pulled up at AVDD").
function [7:0] cfg_tab;
    input [6:0] i;
    begin
        case (i)
        7'd0 : cfg_tab = 8'h00;  7'd1 : cfg_tab = PAD_V;  7'd2 : cfg_tab = PAD_V;
        7'd3 : cfg_tab = 8'h01;  7'd4 : cfg_tab = 8'h02;  7'd5 : cfg_tab = 8'h00;
        7'd6 : cfg_tab = 8'h02;  7'd7 : cfg_tab = 8'h08;  7'd8 : cfg_tab = 8'h00;
        7'd9 : cfg_tab = 8'h08;  7'd10: cfg_tab = 8'h10;  7'd11: cfg_tab = 8'h01;
        7'd12: cfg_tab = 8'h01;  7'd13: cfg_tab = 8'h00;  7'd14: cfg_tab = 8'h00;
        7'd15: cfg_tab = 8'h00;  7'd16: cfg_tab = 8'h00;  7'd17: cfg_tab = 8'hFF;
        7'd18: cfg_tab = 8'h00;  7'd19: cfg_tab = 8'h0F;  7'd20: cfg_tab = 8'h00;
        7'd21: cfg_tab = 8'h00;  7'd22: cfg_tab = 8'h00;  7'd23: cfg_tab = 8'h00;
        7'd24: cfg_tab = 8'h00;  7'd25: cfg_tab = 8'h20;  7'd26: cfg_tab = 8'h0B;
        7'd27: cfg_tab = 8'h00;  7'd28: cfg_tab = 8'h00;  7'd29: cfg_tab = 8'h02;
        7'd30: cfg_tab = 8'h0A;  7'd31: cfg_tab = 8'h21;  7'd32: cfg_tab = 8'h00;
        7'd33: cfg_tab = 8'h00;  7'd34: cfg_tab = 8'h05;  7'd35: cfg_tab = 8'h00;
        7'd36: cfg_tab = 8'h00;  7'd37: cfg_tab = 8'h00;  7'd38: cfg_tab = 8'h00;
        7'd39: cfg_tab = 8'hC8;  7'd40: cfg_tab = 8'h00;  7'd41: cfg_tab = 8'h00;
        7'd42: cfg_tab = 8'h38;  7'd43: cfg_tab = 8'hFF;  7'd44: cfg_tab = 8'h01;
        7'd45: cfg_tab = 8'h00;  7'd46: cfg_tab = 8'h08;  7'd47: cfg_tab = 8'h00;
        7'd48: cfg_tab = 8'h00;  7'd49: cfg_tab = 8'h01;  7'd50: cfg_tab = 8'hCC;
        7'd51: cfg_tab = 8'h0F;  7'd52: cfg_tab = 8'h01;  7'd53: cfg_tab = 8'hF1;
        7'd54: cfg_tab = 8'h0D;  7'd55: cfg_tab = 8'h01;  7'd56: cfg_tab = 8'h68;
        7'd57: cfg_tab = 8'h00;  7'd58: cfg_tab = 8'h80;  7'd59: cfg_tab = 8'h08;
        7'd60: cfg_tab = 8'hB8;  7'd61: cfg_tab = 8'h00;  7'd62: cfg_tab = 8'h00;
        7'd63: cfg_tab = 8'h00;  7'd64: cfg_tab = 8'h00;  7'd65: cfg_tab = 8'h0F;
        7'd66: cfg_tab = 8'h89;  7'd67: cfg_tab = 8'h00;  7'd68: cfg_tab = 8'h00;
        7'd69: cfg_tab = 8'h00;  7'd70: cfg_tab = 8'h00;  7'd71: cfg_tab = 8'h00;
        7'd72: cfg_tab = 8'h00;  7'd73: cfg_tab = 8'h00;  7'd74: cfg_tab = 8'h01;
        7'd75: cfg_tab = 8'h0F;  7'd76: cfg_tab = 8'h0D;  7'd77: cfg_tab = 8'h0E;
        7'd78: cfg_tab = 8'h0E;  7'd79: cfg_tab = 8'h00;  7'd80: cfg_tab = 8'h00;
        7'd81: cfg_tab = 8'h02;  7'd82: cfg_tab = 8'hC7;  7'd83: cfg_tab = 8'hFF;
        7'd84: cfg_tab = 8'h9B;  7'd85: cfg_tab = 8'h00;  7'd86: cfg_tab = 8'h00;
        7'd87: cfg_tab = 8'h00;  7'd88: cfg_tab = 8'h01;  7'd89: cfg_tab = 8'h00;
        default: cfg_tab = 8'h00;   // 90 = 0x87, "don't auto-start"
        endcase
    end
endfunction
localparam [6:0] CFG_LAST = 7'd90;

// ULD VL53L1X_GetRangeStatus: hardware code -> the API's status numbering,
// which is the table in UM2356 (VL53L1X资料/.../doc).
function [7:0] uld_status;
    input [4:0] raw;
    begin
        case (raw)
        5'd9 : uld_status = 8'd0;    // range valid
        5'd6 : uld_status = 8'd1;    // sigma fail
        5'd4 : uld_status = 8'd2;    // signal fail
        5'd8 : uld_status = 8'd3;    // min range clipped
        5'd5 : uld_status = 8'd4;    // out of bounds
        5'd3 : uld_status = 8'd5;    // hardware fail
        5'd19: uld_status = 8'd6;    // valid, wrap check not done (first one)
        5'd7 : uld_status = 8'd7;    // wrap-around target
        5'd12: uld_status = 8'd9;    // crosstalk signal
        5'd18: uld_status = 8'd10;   // synchronisation
        5'd22: uld_status = 8'd11;   // merged pulse
        5'd23: uld_status = 8'd12;   // lack of signal
        5'd13: uld_status = 8'd13;   // min range fail
        default: uld_status = 8'd255;
        endcase
    end
endfunction

//---------------------------------------------------------------------------
// Byte-level master
//---------------------------------------------------------------------------
reg        i2c_go;
reg  [1:0] i2c_op;
reg  [7:0] i2c_wd;
reg        i2c_nack;
wire       i2c_busy, i2c_done, i2c_ack, i2c_err;
wire [7:0] i2c_rd;

tof_i2c #(.QDIV(QDIV)) u_i2c (
    .clk       (clk),
    .rst_n     (rst_n),
    .cmd_go    (i2c_go),
    .cmd_op    (i2c_op),
    .cmd_wdata (i2c_wd),
    .cmd_nack  (i2c_nack),
    .busy      (i2c_busy),
    .done      (i2c_done),
    .ack       (i2c_ack),
    .err       (i2c_err),
    .rdata     (i2c_rd),
    .io_scl    (io_scl),
    .io_sda    (io_sda)
);

localparam [1:0] OP_START = 2'd0, OP_WRITE = 2'd1, OP_READ = 2'd2, OP_STOP = 2'd3;

//---------------------------------------------------------------------------
// Transaction engine: one register access with a 16-bit index.
//   write:  S 0x52 idxH idxL d0 .. d(n-1) P
//   read:   S 0x52 idxH idxL Sr 0x53 d0 .. d(n-1) P     (NACK on the last)
//   clear:  2 x 9 clocks with SDA released, then P
//
// ⚠ WHY THE CLEAR IS 18 SLOTS AND NOT 9.  From an idle bus SCL is already
// high, so the first slot of a READ has no rising edge -- one 9-slot read is
// only 8 real clocks, and the 9th lands inside the STOP, whose first move is
// to pull SDA LOW.  A slave interrupted mid-read (FPGA reconfigured with the
// sensor powered) counts that 9th clock as an ACK and starts another byte,
// so the STOP fails and the part stays wedged.  Two reads give 17 clocks
// with SDA released: every phase reaches its NACK slot inside them.
// Data is big-endian both ways (ST's WrWord / RdWord), so writes take tx_wd
// LEFT-justified and reads shift into tx_rb from the right.
//---------------------------------------------------------------------------
localparam [3:0] E_IDLE = 4'd0,  E_START = 4'd1, E_DEVW = 4'd2, E_IXH = 4'd3,
                 E_IXL  = 4'd4,  E_WD    = 4'd5, E_RS   = 4'd6, E_DEVR = 4'd7,
                 E_RD   = 4'd8,  E_CLR   = 4'd9, E_STOP = 4'd10, E_FIN = 4'd11;

reg        tx_go, tx_rd, tx_clr;
reg [15:0] tx_idx;
reg [2:0]  tx_n;
reg [31:0] tx_wd;

reg [3:0]  es;
reg        iss;
reg        e_rd;
reg [15:0] e_idx;
reg [2:0]  e_cnt;
reg [31:0] e_sh;
reg [15:0] tx_rb;
reg        tx_done, tx_fail, tx_nodev, tx_bus;

wire e_is_wr = (es == E_DEVW) || (es == E_IXH) || (es == E_IXL) ||
               (es == E_WD)   || (es == E_DEVR);

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        es <= E_IDLE; iss <= 1'b0;
        e_rd <= 1'b0; e_idx <= 16'd0; e_cnt <= 3'd0; e_sh <= 32'd0;
        tx_rb <= 16'd0;
        tx_done <= 1'b0; tx_fail <= 1'b0; tx_nodev <= 1'b0; tx_bus <= 1'b0;
        i2c_go <= 1'b0; i2c_op <= OP_STOP; i2c_wd <= 8'd0; i2c_nack <= 1'b1;
    end else begin
        i2c_go  <= 1'b0;
        tx_done <= 1'b0;

        if (es == E_IDLE) begin
            if (tx_go) begin
                e_rd     <= tx_rd;
                e_idx    <= tx_idx;
                e_cnt    <= tx_clr ? 3'd2 : tx_n;
                e_sh     <= tx_wd;
                tx_fail  <= 1'b0;
                tx_nodev <= 1'b0;
                tx_bus   <= 1'b0;
                es       <= tx_clr ? E_CLR : E_START;
            end
        end
        else if (es == E_FIN) begin
            tx_done <= 1'b1;
            es      <= E_IDLE;
        end
        else if (!iss) begin
            iss    <= 1'b1;
            i2c_go <= 1'b1;
            case (es)
            E_START, E_RS: i2c_op <= OP_START;
            E_STOP:        i2c_op <= OP_STOP;
            E_RD, E_CLR:   i2c_op <= OP_READ;
            default:       i2c_op <= OP_WRITE;
            endcase
            case (es)
            E_DEVW:  i2c_wd <= 8'h52;
            E_DEVR:  i2c_wd <= 8'h53;
            E_IXH:   i2c_wd <= e_idx[15:8];
            E_IXL:   i2c_wd <= e_idx[7:0];
            default: i2c_wd <= e_sh[31:24];
            endcase
            i2c_nack <= (es == E_CLR) || (e_cnt == 3'd1);
        end
        else if (i2c_done) begin
            iss <= 1'b0;
            if (i2c_err) begin
                tx_fail <= 1'b1;
                tx_bus  <= 1'b1;
                es      <= (es == E_STOP) ? E_FIN : E_STOP;
            end
            else if (e_is_wr && !i2c_ack) begin
                tx_fail  <= 1'b1;
                tx_nodev <= (es == E_DEVW);
                es       <= E_STOP;
            end
            else begin
                case (es)
                E_START: es <= E_DEVW;
                E_DEVW:  es <= E_IXH;
                E_IXH:   es <= E_IXL;
                E_IXL:   es <= e_rd ? E_RS : E_WD;
                E_WD: begin
                    e_sh  <= {e_sh[23:0], 8'h00};
                    e_cnt <= e_cnt - 3'd1;
                    if (e_cnt == 3'd1) es <= E_STOP;
                end
                E_RS:    es <= E_DEVR;
                E_DEVR:  es <= E_RD;
                E_RD: begin
                    tx_rb <= {tx_rb[7:0], i2c_rd};
                    e_cnt <= e_cnt - 3'd1;
                    if (e_cnt == 3'd1) es <= E_STOP;
                end
                E_CLR: begin
                    e_cnt <= e_cnt - 3'd1;
                    if (e_cnt == 3'd1) es <= E_STOP;
                end
                default: es <= E_FIN;      // E_STOP
                endcase
            end
        end
    end
end

//---------------------------------------------------------------------------
// Millisecond tick for the delays and poll gaps.
//---------------------------------------------------------------------------
reg [17:0] ms_div;
reg        ms_tick;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        ms_div <= 18'd0; ms_tick <= 1'b0;
    end else begin
        ms_tick <= (ms_div == MS_DIV - 1);
        ms_div  <= (ms_div == MS_DIV - 1) ? 18'd0 : ms_div + 18'd1;
    end
end

//---------------------------------------------------------------------------
// Step sequencer
//---------------------------------------------------------------------------
localparam [4:0] P_BOOTWAIT = 5'd0,  P_CLEAR  = 5'd1,  P_BOOTPOLL = 5'd2,
                 P_ID       = 5'd3,  P_TABLE  = 5'd4,  P_VHV_GO   = 5'd5,
                 P_VHV_RDY  = 5'd6,  P_VHV_CLR = 5'd7, P_VHV_STOP = 5'd8,
                 P_VHV_B    = 5'd9,  P_VHV_I  = 5'd10, P_M_PC     = 5'd11,
                 P_M_VA     = 5'd12, P_M_VB   = 5'd13, P_M_PH     = 5'd14,
                 P_M_WOI    = 5'd15, P_M_IP   = 5'd16, P_TB_A     = 5'd17,
                 P_TB_B     = 5'd18, P_OSC    = 5'd19, P_IM       = 5'd20,
                 P_ROI_RC   = 5'd21, P_ROI_C  = 5'd22, P_ROI_XY   = 5'd23,
                 P_START    = 5'd24, P_RDY    = 5'd25, P_STAT     = 5'd26,
                 P_DIST     = 5'd27, P_CLRINT = 5'd28, P_SIGMA    = 5'd29,
                 P_RC2      = 5'd30, P_RXY2   = 5'd31;

localparam [1:0] SP_GO = 2'd0, SP_TX = 2'd1, SP_DLY = 2'd2, SP_MUL = 2'd3;

reg [4:0]  pc;
reg [1:0]  sp;
reg [6:0]  tab_i;
reg [9:0]  dly;
reg [9:0]  polls;
reg        poll_nack;
reg [25:0] osc_sh;
reg [15:0] k_sh;
reg [7:0]  roi_ctr;
reg [7:0]  roi_new_c, roi_new_xy;  // 10-04: the request being written
reg [7:0]  roi_cur_c, roi_cur_xy;  // ... and the one the part has
reg [1:0]  roi_skip;
wire       roi_diff = (roi_ctr_req != roi_cur_c) || (roi_xy_req != roi_cur_xy);
reg [25:0] im_acc;
reg [3:0]  mul_i;
reg [4:0]  st_raw;
reg [13:0] sig_raw;
reg [2:0]  last_err;

// What the current step puts on the bus.  Combinational in pc, so the step
// list reads as a table; the sequential block below only decides WHEN.
reg        s_rd;
reg [15:0] s_idx;
reg [2:0]  s_n;
reg [31:0] s_wd;
always @(*) begin
    s_rd = 1'b0; s_idx = 16'h0000; s_n = 3'd1; s_wd = 32'd0;
    case (pc)
    P_BOOTPOLL: begin s_rd = 1'b1; s_idx = 16'h00E5; end
    P_ID:       begin s_rd = 1'b1; s_idx = 16'h010F; s_n = 3'd2; end
    P_TABLE:    begin s_idx = 16'h002D + {9'd0, tab_i}; s_wd = {cfg_tab(tab_i), 24'd0}; end
    P_VHV_GO:   begin s_idx = 16'h0087; s_wd = {8'h40, 24'd0}; end
    P_VHV_RDY:  begin s_rd = 1'b1; s_idx = 16'h0031; end
    P_VHV_CLR:  begin s_idx = 16'h0086; s_wd = {8'h01, 24'd0}; end
    P_VHV_STOP: begin s_idx = 16'h0087; s_wd = {8'h00, 24'd0}; end
    P_VHV_B:    begin s_idx = 16'h0008; s_wd = {8'h09, 24'd0}; end
    P_VHV_I:    begin s_idx = 16'h000B; s_wd = {8'h00, 24'd0}; end
    P_M_PC:     begin s_idx = 16'h004B; s_wd = {M_PHASECAL, 24'd0}; end
    P_M_VA:     begin s_idx = 16'h0060; s_wd = {M_VCSEL_A,  24'd0}; end
    P_M_VB:     begin s_idx = 16'h0063; s_wd = {M_VCSEL_B,  24'd0}; end
    P_M_PH:     begin s_idx = 16'h0069; s_wd = {M_PHASE_HI, 24'd0}; end
    P_M_WOI:    begin s_idx = 16'h0078; s_n = 3'd2; s_wd = {M_WOI,   16'd0}; end
    P_M_IP:     begin s_idx = 16'h007A; s_n = 3'd2; s_wd = {M_INIPH, 16'd0}; end
    P_TB_A:     begin s_idx = 16'h005E; s_n = 3'd2; s_wd = {TB_A, 16'd0}; end
    P_TB_B:     begin s_idx = 16'h0061; s_n = 3'd2; s_wd = {TB_B, 16'd0}; end
    P_OSC:      begin s_rd = 1'b1; s_idx = 16'h00DE; s_n = 3'd2; end
    P_IM:       begin s_idx = 16'h006C; s_n = 3'd4; s_wd = {10'd0, im_acc[25:4]}; end
    P_ROI_RC:   begin s_rd = 1'b1; s_idx = 16'h013E; end
    P_ROI_C:    begin s_idx = 16'h007F;
                      s_wd = {((RUNTIME_ROI != 0) ? roi_new_c : (ROI_BIG ? 8'd199 : roi_ctr)), 24'd0}; end
    P_ROI_XY:   begin s_idx = 16'h0080;
                      s_wd = {((RUNTIME_ROI != 0) ? roi_new_xy : ROI_XY), 24'd0}; end
    P_RC2:      begin s_idx = 16'h007F; s_wd = {roi_new_c,  24'd0}; end
    P_RXY2:     begin s_idx = 16'h0080; s_wd = {roi_new_xy, 24'd0}; end
    P_START:    begin s_idx = 16'h0087; s_wd = {8'h40, 24'd0}; end
    P_RDY:      begin s_rd = 1'b1; s_idx = 16'h0031; end
    P_STAT:     begin s_rd = 1'b1; s_idx = 16'h0089; end
    P_SIGMA:    begin s_rd = 1'b1; s_idx = 16'h0092; s_n = 3'd2; end
    P_DIST:     begin s_rd = 1'b1; s_idx = 16'h0096; s_n = 3'd2; end
    P_CLRINT:   begin s_idx = 16'h0086; s_wd = {8'h01, 24'd0}; end
    default:    ;
    endcase
end

// Poll budgets, in polls of POLL_MS each.  The throwaway VHV measurement runs
// with the table's default ~100 ms budget; the ranging loop waits at most a
// few inter-measurement periods before calling the part hung.
localparam [9:0] BOOT_POLLS  = 10'd200;
localparam [9:0] VHV_POLLS   = 10'd1000;
localparam [9:0] RANGE_POLLS = (IM_MS * 4 > 1000) ? 10'd1000 : (IM_MS * 4);

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        pc <= P_BOOTWAIT; sp <= SP_GO; tab_i <= 7'd0;
        dly <= BOOT_MS; polls <= 10'd0; poll_nack <= 1'b0;
        osc_sh <= 26'd0; k_sh <= 16'd0; roi_ctr <= 8'd199; im_acc <= 26'd0; mul_i <= 4'd0;
        st_raw <= 5'd0; sig_raw <= 14'd0; last_err <= 3'd0;
        tx_go <= 1'b0; tx_rd <= 1'b0; tx_clr <= 1'b0;
        tx_idx <= 16'd0; tx_n <= 3'd1; tx_wd <= 32'd0;
        state <= ST_BOOT; dist_mm <= 16'd0; dist_code <= 8'd255; dist_sigma <= 14'd0;
        dist_stb <= 1'b0; err_cnt <= 8'd0; id_rb <= 16'd0;
        roi_new_c <= 8'd199; roi_new_xy <= 8'hFF; roi_cur_c <= 8'd199; roi_cur_xy <= 8'hFF;
        roi_skip <= 2'd0; dist_roi_ctr <= 8'd199; dist_roi_xy <= 8'hFF; roi_opt <= 8'd0;
    end else begin
        tx_go    <= 1'b0;
        dist_stb <= 1'b0;

        case (sp)
        //------------------------------------------------------------------
        SP_GO: begin
            if (pc == P_BOOTWAIT) begin
                sp <= SP_DLY;                   // dly was loaded by whoever
            end else begin                      // sent us here
                tx_go  <= 1'b1;
                tx_clr <= (pc == P_CLEAR);
                tx_rd  <= s_rd;
                tx_idx <= s_idx;
                tx_n   <= s_n;
                tx_wd  <= s_wd;
                sp     <= SP_TX;
            end
        end

        //------------------------------------------------------------------
        SP_DLY: begin
            if (ms_tick) begin
                if (dly <= 10'd1) begin
                    if (pc == P_BOOTWAIT) pc <= P_CLEAR;
                    sp <= SP_GO;
                end else begin
                    dly <= dly - 10'd1;
                end
            end
        end

        //------------------------------------------------------------------
        // osc * IM_K16, one bit per clock -- no multiplier.  Both operands
        // SHIFT rather than being indexed by mul_i: a variable shift in front
        // of the 26-bit add would be four mux levels and a carry chain in one
        // clock, in a domain with tens of picoseconds to spare.
        SP_MUL: begin
            if (k_sh[0]) im_acc <= im_acc + osc_sh;
            osc_sh <= {osc_sh[24:0], 1'b0};
            k_sh   <= {1'b0, k_sh[15:1]};
            mul_i  <= mul_i + 4'd1;
            if (mul_i == 4'd15) begin
                pc <= P_IM;
                sp <= SP_GO;
            end
        end

        //------------------------------------------------------------------
        SP_TX: if (tx_done) begin
            if (tx_fail && !((pc == P_BOOTPOLL) && tx_nodev && !tx_bus)) begin
                // Abort: remember why, and start over after RETRY_MS.
                // A NACK after the address byte is reported as NO ACK too:
                // either way the part stopped answering mid-sequence.
                last_err <= tx_bus ? ST_BUS : ST_NOACK;
                state    <= tx_bus   ? ST_BUS : ST_NOACK;
                if (err_cnt != 8'hFF) err_cnt <= err_cnt + 8'd1;
                pc  <= P_BOOTWAIT;
                dly <= RETRY_MS;
                sp  <= SP_GO;
            end
            else begin
                case (pc)
                P_CLEAR: begin
                    pc <= P_BOOTPOLL; polls <= 10'd0; poll_nack <= 1'b0;
                    if (last_err == 3'd0) state <= ST_BOOT;
                    sp <= SP_GO;
                end

                // A part still booting may NACK; that is "not yet", not "not
                // there" -- until the budget runs out, when it becomes the
                // reason shown.
                P_BOOTPOLL: begin
                    if (!tx_fail && tx_rb[0]) begin
                        pc <= P_ID; sp <= SP_GO;
                    end else if (polls == BOOT_POLLS) begin
                        last_err <= tx_fail ? ST_NOACK : ST_TMO;
                        state    <= tx_fail ? ST_NOACK : ST_TMO;
                        if (err_cnt != 8'hFF) err_cnt <= err_cnt + 8'd1;
                        pc <= P_BOOTWAIT; dly <= RETRY_MS; sp <= SP_GO;
                    end else begin
                        polls <= polls + 10'd1;
                        dly <= POLL_MS; sp <= SP_DLY;
                    end
                end

                P_ID: begin
                    id_rb <= tx_rb;
                    if (tx_rb == 16'hEACC) begin
                        pc <= P_TABLE; tab_i <= 7'd0;
                        if (last_err == 3'd0) state <= ST_INIT;
                        sp <= SP_GO;
                    end else begin
                        last_err <= ST_BADID; state <= ST_BADID;
                        if (err_cnt != 8'hFF) err_cnt <= err_cnt + 8'd1;
                        pc <= P_BOOTWAIT; dly <= RETRY_MS; sp <= SP_GO;
                    end
                end

                P_TABLE: begin
                    if (tab_i == CFG_LAST) pc <= P_VHV_GO;
                    else                   tab_i <= tab_i + 7'd1;
                    sp <= SP_GO;
                end

                P_VHV_RDY, P_RDY: begin
                    if (tx_rb[0]) begin
                        pc <= pc + 5'd1; sp <= SP_GO;
                    end else if (polls == ((pc == P_RDY) ? RANGE_POLLS : VHV_POLLS)) begin
                        last_err <= ST_TMO; state <= ST_TMO;
                        if (err_cnt != 8'hFF) err_cnt <= err_cnt + 8'd1;
                        pc <= P_BOOTWAIT; dly <= RETRY_MS; sp <= SP_GO;
                    end else begin
                        polls <= polls + 10'd1;
                        dly <= POLL_MS; sp <= SP_DLY;
                    end
                end

                P_OSC: begin
                    osc_sh <= {16'd0, tx_rb[9:0]};
                    k_sh   <= IM_K16;
                    im_acc <= 26'd0;
                    mul_i  <= 4'd0;
                    sp     <= SP_MUL;
                end

                P_ROI_RC: begin
                    roi_ctr    <= tx_rb[7:0];
                    roi_opt    <= tx_rb[7:0];
                    roi_new_c  <= roi_ctr_req;  // init writes the request (RUNTIME_ROI)
                    roi_new_xy <= roi_xy_req;
                    pc <= P_ROI_C; sp <= SP_GO;
                end

                P_START: begin
                    state    <= ST_RANGE;       // clears any shown error
                    last_err <= 3'd0;
                    if (RUNTIME_ROI != 0) begin
                        roi_cur_c  <= roi_new_c;
                        roi_cur_xy <= roi_new_xy;
                        roi_skip   <= 2'd0;     // configured before the first start
                    end
                    pc <= P_RDY; polls <= 10'd0; sp <= SP_GO;
                end

                P_STAT: begin
                    st_raw <= tx_rb[4:0];
                    pc <= (READ_SIGMA != 0) ? P_SIGMA : P_DIST; sp <= SP_GO;
                end

                P_SIGMA: begin
                    sig_raw <= tx_rb[15:2];
                    pc <= P_DIST; sp <= SP_GO;
                end

                P_CLRINT: begin
                    if ((RUNTIME_ROI != 0) && roi_diff) begin
                        roi_new_c  <= roi_ctr_req;
                        roi_new_xy <= roi_xy_req;
                        pc <= P_RC2;
                    end else begin
                        pc <= P_RDY; polls <= 10'd0;
                    end
                    sp <= SP_GO;
                end

                P_RC2: begin
                    pc <= P_RXY2; sp <= SP_GO;
                end

                P_RXY2: begin
                    roi_cur_c  <= roi_new_c;
                    roi_cur_xy <= roi_new_xy;
                    roi_skip   <= ROI_SKIP;
                    pc <= P_RDY; polls <= 10'd0; sp <= SP_GO;
                end

                P_DIST: begin
                    // Status and distance are published TOGETHER, on one
                    // clock -- a reader must never see this measurement's
                    // distance next to the previous one's verdict.
                    // 10-04: a measurement started before the last ROI
                    // write is read and cleared, never published
                    if ((RUNTIME_ROI != 0) && (roi_skip != 2'd0)) begin
                        roi_skip <= roi_skip - 2'd1;
                    end else begin
                        dist_mm      <= tx_rb;
                        dist_code    <= uld_status(st_raw);
                        dist_sigma   <= sig_raw;
                        dist_roi_ctr <= roi_cur_c;
                        dist_roi_xy  <= roi_cur_xy;
                        dist_stb     <= 1'b1;
                    end
                    pc <= P_CLRINT; sp <= SP_GO;
                end

                default: begin                  // plain writes
                    if (pc == P_VHV_RDY - 5'd1) polls <= 10'd0;
                    pc <= pc + 5'd1; sp <= SP_GO;
                end
                endcase
            end
        end
        endcase
    end
end

endmodule
