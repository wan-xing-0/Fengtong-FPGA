//---------------------------------------------------------------------------
// qc_thick -- workpiece THICKNESS (the third dimension) and the QC STABLE flag.
//
// THE MODEL
//   The ToF looks down at the table.  With nothing on it the reading is the
//   table, BASE.  With a workpiece the reading is its top face, TOP, and
//       Z = BASE - TOP
//   X / Y come from tof_size (pinhole, box under the aim point, distance =
//   TOP -- the right distance for the top face).  D_OFS does not enter Z: it
//   is a difference of two readings of the same sensor.
//
// ⭐ BASE IS LEARNT, NOT ENTERED
//   * AUTO: a block of 2^N_LOG2 readings that held still (all within D_TOL of
//     each other) while the camera saw NO box under the aim point becomes
//     BASE.  So: power up in BOX with the table empty, and BASE appears in
//     about half a second.
//   * The table is the FARTHEST thing the ToF sees.  An auto block may move
//     BASE farther freely, but nearer by at most BASE_TRK_MM -- otherwise a
//     black workpiece the camera does not box would be learnt as the table.
//   * ⭐ 10-03 night: ...UNLESS the nearer reading PERSISTS.  BASE_NEAR_BLK
//     consecutive no-box blocks that agree with each other (within
//     D_TOL_ST_MM) and are all nearer than the guard allow, and BASE follows
//     them.  Board: BASE latched 239 (one still half-second while the rig
//     was being rearranged, most likely) and the real 202 was refused for
//     good -- the guard was a one-way ratchet that only a tare could undo.
//     The cost is the case the guard was for: an unboxed workpiece left
//     ~3 s becomes the table.  Nothing is measured while it is unboxed
//     anyway, and BASE springs back the moment it is removed (farther is
//     free).  Any block that is not a clean no-box block (a box, a box
//     dropout, the head moving) starts the count over.  0 = never (the
//     10-03 behaviour, bit-exact).
//   * MANUAL (tare): the next still block becomes BASE whatever the camera
//     says.  For a camera lowered toward the table, or a backdrop that keeps
//     producing a false box at the centre.
//
// ⭐⭐ 10-23 (board recording 10-22 23:50, 质检: "偶尔厚度不对" -- every wrong Z
// in it was ~10 = 0 - Z_OFS_MM, i.e. BASE had been learnt from the PART'S OWN
// FACE).  Two ways in, both seen in the recording, plus a catch-all:
//   * TARE_EMPTY.  A short key2 press with the part in front (220.6 s: cube
//     stable 60x60x27, BASE 190 -> 174 = its face, Z 10; again at 223.3 s and
//     at 319.9 s) took that block as the backdrop.  Now the tare WAITS
//     (去皮中) for a block with nothing in the picture -- box_found and
//     scene_any (tof_size's box_any) low on every frame of it -- so it is
//     always the backdrop it learns; with the part still there nothing is
//     measured until the part is taken away.  Cost: a backdrop that keeps
//     producing a box can no longer be tared (去皮中 stays; leaving BOX
//     cancels it) -- TARE_EMPTY 0 for that rig.
//   * NEAR_EMPTY.  The BASE_NEAR_BLK follow counted any block with no box
//     UNDER THE AIM POINT.  290.3-293.9 s: the triangle sat in front of the
//     ToF (162 -> 169) with no box of its own while the hand next to it was
//     boxed; after ~3 s BASE followed 191 -> 168, and when its box appeared
//     Z was 11 (-19).  Now only blocks with nothing in the picture count --
//     the case the follow exists for is the BACKDROP moving, and then the
//     picture is empty.
//   * MIN_RAW_MM.  Whatever the path, BASE - TOP below MIN_RAW_MM with the
//     box present means BASE is that face: 台面异常 (the R_NEG row), never
//     stable.  Taking the part away relearns BASE by itself (farther is
//     free).  In the recording the face-learnt cases read BASE - TOP -2..+3
//     and the real parts 16..55; system_top uses 8.  Cost: a part thinner
//     than MIN_RAW_MM - Z_OFS_MM (18 mm on the board) cannot be measured.
//   All three 0 = the 10-20 behaviour, bit-exact.
//
// TOP is a still block taken with the box present throughout (dropouts of up
// to MISS_FR frames forgiven), so a block that straddles the object arriving
// is thrown away rather than averaged into a value between table and top.
//
// ⭐ qc_stable -- "the numbers on screen now are trustworthy".  RISES when all
// of these hold:
//   en (BOX mode) / ranger running / BASE known and no tare pending /
//   the current distance streak has completed a block / that block was taken
//   with the box present / the box (x0, y0, w, h in px) has held still for
//   K_FR frames / the distance tof_size computed X / Y with is within
//   XY_TOL_MM of TOP (its IIR lags a step, and the record must not pair a
//   settled Z with a half-settled X / Y) / the head is not moving / TOP is not
//   farther than BASE by more than NEG_TOL_MM (BASE is wrong -- tare).
//
// ⭐⭐ 10-03 (board: "a slight touch flips SETTLE/STABLE and the count goes
// up"): ONCE UP, IT IS HARD TO KNOCK DOWN, AND KNOCKING IT DOWN IS NOT A NEW
// WORKPIECE.  Four layers, each aimed at one board-side cause:
//   1. Wider tolerances once stable: D_TOL_ST_MM, PX_TOL_ST (a nudge of a
//      couple of mm is ~30 px at 15 cm), XY_TOL_ST_MM.
//   2. While the flag is up, an off reading is an OUTLIER (up to BAD_MAX in a
//      row, the same budget as rejected readings), not a new streak.  A
//      single 20 mm spike used to restart everything.
//   3. Box dropouts of up to MISS_FR frames are forgiven everywhere.
//   4. The flag FALLS only after DROP_FR consecutive frames of "not stable"
//      (en off / ranger lost / tare: at once).
//   And the trigger is separated from the flag: qc_trig fires on a rise only
//   if ARMED -- by power-up, entering BOX, tare, the workpiece being REMOVED
//   (no box for REARM_FR frames) -- or if the new X / Y / Z differ from the
//   last record by more than CHG_MM (a different workpiece swapped in without
//   the box ever going away).  A same-workpiece re-rise shows STABLE with the
//   SAME number and sends nothing.  While up, every block commit (~0.5 s,
//   block-averaged, so not a per-frame number) is compared the same way, so a
//   real drift inside the stable tolerances still updates the record.
//
// ⭐ ETHERNET INTERFACE (teammate)
//   qc_trig   one clock, once per workpiece (see above)
//   qc_rec    latched on that same clock and held until the next one:
//     [127]     1 = a record has been latched
//     [126]     BASE known (always 1 in a latched record)
//     [125:120] 0
//     [119:104] X mm   (along the picture's x)
//     [103: 88] Y mm   (along the picture's y)
//     [ 87: 72] Z mm   (thickness, clamped 0..999)
//     [ 71: 56] TOP mm (raw ToF to the top face, block mean)
//     [ 55: 40] BASE mm
//     [ 39: 28] box width  px
//     [ 27: 16] box height px
//     [ 15:  8] qc_seq (this record's)
//     [  7:  0] 0
//   qc_seq    +1 per trigger
//   qc_stable level, for "is it still sitting there"
//   All on clk (pclkx1).  Same convention as aim_sched's res_tab.
//
// OSD: three value fields with Chinese glyph codes (>= 0x80, osd_cn_rom; the
// CN_* table below must match tools/gen_cn_font.py):
//   size3_text  12 chars  " 26X 49X 28 " = tof_size's W x H, then X Z, then
//               tof_size's 'M' flag -- or the reason there is no size
//   base_text    8 chars  " 145MM  "  or "  -"
//   qc_text      8 chars  the state, or "稳定 #n" (n = qc_seq, the record number)
//                         -- or for CAL_SHOW_FR frames after a calibration
//                         "标定+17+06" (the new XY / Z offsets, copy them into
//                         system_top's D_OFS_MM / Z_OFS_MM) or "标定错N"
//
// ⭐ 10-04 ONE-KEY CALIBRATION (cal_req = key2 held 1 s in BOX mode).  With
// the reference workpiece (CAL_Z_MM thick; its top face is tof_size's CAL_*)
// stable under the aim point, Z's offset becomes BASE - TOP - CAL_Z_MM and
// tof_size's XY offset is refitted -- both or neither: tof_size is only asked
// once Z's candidate passed, and Z is only written on tof_size's cal_ok.
// Z = BASE - TOP - z_ofs; 台面 / qc_rec's TOP and BASE stay the raw readings.
// Lost at power-off (Z_OFS_MM / tof_size's D_OFS_MM are the power-up values).
//   标定错1 not stable   2 no valid size   3 X / Y disagree (not the reference,
//   or a bad box)   4 XY offset beyond tof_size's CAL_MAX_MM   5 Z offset
//   beyond CAL_Z_MAX
// 10-04 bench: hand-measured ToF -> top 160, -> table 219 = 59 for a 55 mm
// workpiece.  The 4 mm is the table (a creased cloth; the ToF averages a 10 cm
// spot of it), not the ranger -- a calibration on it bakes that in.
//
// ⚠ ACCURACY LIMIT (the sensor, not this module): the ToF cone is 27 deg, a
// 60-70 mm spot at 120-150 mm, larger than a 28 mm workpiece.  The reading is
// then a blend weighted by returned signal.  A BLACK table returns little, so
// the workpiece dominates -- keep the black backdrop.  Narrowing ROI_W/ROI_H in
// vl53l1x_ctrl is the next knob.
//
// One adder per clock everywhere: the pixel-clock domain has tens of ps of
// slack.  Distance readings come every ~60 ms and frames every ~16 ms, so the
// pipelines below are free.
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module qc_thick #(
parameter integer N_LOG2       = 3,   // readings per block = 2^N_LOG2 (8 = ~0.5 s)
parameter integer D_TOL_MM     = 5,   // a reading within ref +- this continues a fresh streak
parameter integer D_TOL_ST_MM  = 10,  // ... a committed one (beyond: an outlier)
parameter integer XY_TOL_MM    = 3,   // tof_size's distance vs TOP, to rise
parameter integer XY_TOL_ST_MM = 8,   // ... to stay up
parameter integer SIG_MAX_MM   = 40,  // ToF sigma gate, mm.  0 = off
parameter integer BAD_MAX      = 2,   // rejected / outlier readings tolerated in a row
parameter integer K_FR         = 16,  // frames the box must hold still (<= 255)
parameter integer PX_TOL       = 8,   // box x0 / y0 / w / h tolerance, px, to rise
parameter integer PX_TOL_ST    = 40,  // ... to stay up
parameter integer MISS_FR      = 5,   // box dropout frames forgiven
parameter integer DROP_FR      = 10,  // frames of "not stable" before the flag falls
parameter integer REARM_FR     = 30,  // frames with no box = removed: next rise triggers
parameter integer CHG_MM       = 4,   // or X / Y / Z differ from the last record by more
parameter integer BASE_TRK_MM  = 8,   // auto BASE may come this much nearer
parameter integer BASE_NEAR_BLK = 6,  // ... or any amount after this many agreeing blocks (2..15; 0 = never)
parameter integer NEG_TOL_MM   = 5,   // TOP may read this much beyond BASE
parameter integer TARE_EMPTY   = 0,   // 10-23: 1 = a tare waits for a block with nothing in the picture
parameter integer NEAR_EMPTY   = 0,   // 10-23: 1 = BASE_NEAR_BLK counts only such blocks
parameter integer MIN_RAW_MM   = 0,   // 10-23: BASE - TOP below this (box present) = 台面异常.  0 = off
parameter integer STALE_FR     = 15,  // frames without a good reading
parameter integer Z_OFS_MM     = 0,   // 10-04: subtracted from Z at power-up (|.| <= 127)
parameter integer CAL_Z_MM     = 55,  // the calibration reference's thickness
parameter integer CAL2_Z_MM    = 0,   // 10-20: ... the second one's (cal_ref2), 0 = CAL_Z_MM
parameter integer CAL_Z_MAX    = 30,  // |new Z offset| beyond this: refused (<= 127)
parameter integer CAL_SHOW_FR  = 150  // frames the result stays in the 质检 row (<= 255)
)(
input  wire        clk,
input  wire        rst_n,

input  wire        en,              // BOX mode
input  wire        tare,            // one-clock pulse

input  wire [2:0]  tof_state,
input  wire [15:0] dist_mm,
input  wire [7:0]  dist_code,
input  wire        dist_stb,
input  wire [13:0] dist_sigma,

// tof_size, all changing on pub_stb's clock
input  wire        pub_stb,
input  wire        box_found,
input  wire        scene_any,       // 10-23: tof_size's box_any -- a box anywhere in the frame
input  wire [11:0] box_x0,
input  wire [11:0] box_y0,
input  wire [11:0] box_w_px,
input  wire [11:0] box_h_px,
input  wire        size_ok,
input  wire [1:0]  size_why,        // 0 ok, 1 no distance, 2 affine, 3 no box
input  wire [15:0] size_w_mm,
input  wire [15:0] size_h_mm,
input  wire [15:0] size_d_mm,       // the distance tof_size computed X / Y with
input  wire [63:0] size_text,       // tof_size's "WWWXHHHf"

input  wire        head_moving,

// 10-04 calibration handshake with tof_size (see the header)
input  wire        cal_req,         // one clock
input  wire        cal_ref2,        // 10-20: the second reference (sampled on cal_req; -> tof_size)
output reg         cal_go,          // -> tof_size, once Z's candidate passed
input  wire        cal_done,        // <- tof_size
input  wire        cal_ok,
input  wire [1:0]  cal_why,
input  wire signed [9:0] xy_ofs_mm, // shown with the result
output reg  signed [7:0] z_ofs_mm,  // for ChipWatcher

output reg         qc_stable,
output reg         qc_trig,
output reg  [7:0]  qc_seq,
output reg  [127:0] qc_rec,

// committed values, for ChipWatcher
output reg  [15:0] thick_mm,
output reg  [15:0] base_mm,
output reg         base_ok,

// OSD value fields, published together
output reg  [95:0] size3_text,
output reg  [63:0] base_text,
output reg  [63:0] qc_text,
// 10-30 (final OSD): what qc_text is saying, published on the same clock, so
// text_osd's 状态 row (测量中 / 已稳定) can never disagree with the 尺寸 row
output reg         qc_text_cal,     // a key2 calibration result (标定+12+04 / 标定错3)
output reg         qc_text_stb      // 稳定 #n
);

localparam integer N  = 1 << N_LOG2;
localparam integer AW = 16 + N_LOG2;
localparam [2:0]   ST_RANGE = 3'd3;

// osd_cn_rom codes -- tools/gen_cn_font.py's table, append-only
localparam [7:0] CN_WEN   = 8'h80, CN_DING  = 8'h81, CN_CE    = 8'h82,
                 CN_JU    = 8'h83, CN_TAI   = 8'h89, CN_MIAN  = 8'h8A,
                 CN_GUAN  = 8'h8D, CN_BI    = 8'h8E, CN_GU    = 8'h8F,
                 CN_ZHANG = 8'h90, CN_QU    = 8'h91, CN_PI    = 8'h92,
                 CN_ZHONG = 8'h93, CN_XUE   = 8'h94, CN_XI    = 8'h95,
                 CN_WU    = 8'h96, CN_GONG  = 8'h97, CN_JIAN2 = 8'h98,
                 CN_YUN   = 8'h99, CN_YI    = 8'h9A, CN_DONG  = 8'h9B,
                 CN_BU    = 8'h9C, CN_YI2   = 8'h9D, CN_CHANG = 8'h9E,
                 CN_LIANG = 8'h9F, CN_FANG  = 8'hA0, CN_SHE   = 8'hA1,
                 CN_KUANG = 8'hA2;
localparam [7:0] CN_BIAO  = 8'hE3, CN_CUO   = 8'hD5;

wire tof_ok = (tof_state == ST_RANGE);
wire sig_ok = (SIG_MAX_MM == 0) || (dist_sigma <= SIG_MAX_MM);
wire rd_ok  = (dist_code == 8'd0) && sig_ok;

//---------------------------------------------------------------------------
// Frame bookkeeping, one clock after pub_stb (fr1): the box dropout counter.
// miss = consecutive published frames without a box, saturating.
//---------------------------------------------------------------------------
reg       fr1;
reg [7:0] miss;
wire      box_db   = (miss <= MISS_FR);      // a box now, or a forgiven dropout
wire      box_gone = !box_db;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        fr1 <= 1'b0; miss <= 8'hFF;
    end else begin
        fr1 <= pub_stb;
        if (pub_stb)
            miss <= box_found ? 8'd0 : ((miss == 8'hFF) ? 8'hFF : (miss + 8'd1));
    end
end

//---------------------------------------------------------------------------
// Distance pipeline: register / subtract / |x|.  dref only changes in the
// action stage, and the next reading is ~60 ms away.
//---------------------------------------------------------------------------
reg               p1, p2, p3;       // good reading
reg               q1, q2, q3;       // rejected reading
reg        [15:0] r1;
reg signed [17:0] e2;
reg        [17:0] a3;
reg        [15:0] dref;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        p1 <= 1'b0; p2 <= 1'b0; p3 <= 1'b0;
        q1 <= 1'b0; q2 <= 1'b0; q3 <= 1'b0;
        r1 <= 16'd0; e2 <= 18'sd0; a3 <= 18'd0;
    end else begin
        p1 <= en && dist_stb &&  rd_ok;
        q1 <= en && dist_stb && !rd_ok;
        if (dist_stb) r1 <= dist_mm;
        e2 <= $signed({2'b00, r1}) - $signed({2'b00, dref});
        a3 <= e2[17] ? -e2 : e2;
        p2 <= p1; p3 <= p2;
        q2 <= q1; q3 <= q2;
    end
end

//---------------------------------------------------------------------------
// Distance streak, block learner, commit.  One always block: every flag here
// is written from more than one place, and the order below is the priority.
//---------------------------------------------------------------------------
reg              run;               // a streak is open
reg              dstab_c;           // it has completed a block (committed)
reg [N_LOG2:0]   n;
reg [AW-1:0]     acc;
reg [2:0]        bad;
reg [7:0]        age;               // frames since the last good reading
reg              blk_box, blk_nobox;
reg              blk_done, bq_box, bq_nobox;
reg              blk_empty, bq_empty;   // 10-23: nothing in the picture, the whole block
reg [15:0]       blk_mean;
reg [2:0]        sq;
reg              tare_req;
reg              cmt;               // one clock after a commit

reg [15:0]       base, base_lo, top_w, thick_w;
reg [3:0]        near_n;            // agreeing nearer-than-guard no-box blocks so far
reg [15:0]       near_ref, near_lo, near_hi;
reg              top_w_ok, neg_w;
reg signed [17:0] th_s, th_z;
reg [15:0]       top_c;
reg              top_c_ok, neg_c;

wire [AW-1:0] acc_nx  = acc + {{N_LOG2{1'b0}}, r1};
wire [15:0]   mean_nx = acc_nx[AW-1:N_LOG2];
wire [17:0]   dtol    = dstab_c ? D_TOL_ST_MM : D_TOL_MM;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        run <= 1'b0; dstab_c <= 1'b0; n <= 0; acc <= 0; bad <= 3'd0;
        age <= 8'hFF; dref <= 16'd0;
        blk_box <= 1'b0; blk_nobox <= 1'b0;
        blk_done <= 1'b0; bq_box <= 1'b0; bq_nobox <= 1'b0; blk_mean <= 16'd0;
        blk_empty <= 1'b0; bq_empty <= 1'b0;
        sq <= 3'd0; tare_req <= 1'b0; cmt <= 1'b0;
        base <= 16'd0; base_lo <= 16'd0; base_ok <= 1'b0;
        near_n <= 4'd0; near_ref <= 16'd0; near_lo <= 16'd0; near_hi <= 16'd0;
        top_w <= 16'd0; top_w_ok <= 1'b0; th_s <= 18'sd0; th_z <= 18'sd0;
        thick_w <= 16'd0; neg_w <= 1'b0;
        base_mm <= 16'd0; top_c <= 16'd0; thick_mm <= 16'd0;
        top_c_ok <= 1'b0; neg_c <= 1'b0;
    end else begin
        blk_done <= 1'b0;
        cmt      <= 1'b0;
        base_lo  <= (base > BASE_TRK_MM) ? (base - BASE_TRK_MM) : 16'd0;
        // the agreement window, precomputed (near_ref is next read a whole
        // block later) so S1 is two compares, like the guard itself
        near_lo  <= (near_ref > D_TOL_ST_MM) ? (near_ref - D_TOL_ST_MM) : 16'd0;
        near_hi  <= near_ref + D_TOL_ST_MM;

        if (!en) begin
            run <= 1'b0; dstab_c <= 1'b0; bad <= 3'd0; near_n <= 4'd0;
            sq <= 3'd0; tare_req <= 1'b0;
            top_w_ok <= 1'b0; top_c_ok <= 1'b0;
        end else begin
            // ---- streak
            if (p3) begin
                // Outliers are only forgiven while the FLAG is up: before
                // that a far reading is news (a workpiece arriving moves the
                // committed table streak by its whole height, and must not
                // wait two readings or flash 测距不稳 on the way).
                if (run && (a3 > dtol) && qc_stable && (bad < BAD_MAX)) begin
                    bad <= bad + 3'd1;                 // outlier: skip it
                end else if (!run || (a3 > dtol)) begin
                    run <= 1'b1; dstab_c <= 1'b0; bad <= 3'd0;
                    dref <= r1; acc <= {{N_LOG2{1'b0}}, r1}; n <= 1;
                    blk_box   <= box_db     && !head_moving;
                    blk_nobox <= !box_found && !head_moving;
                    blk_empty <= !box_found && !scene_any && !head_moving;
                end else if (n == N - 1) begin
                    bad <= 3'd0;
                    blk_mean <= mean_nx; dref <= mean_nx; blk_done <= 1'b1;
                    bq_box   <= blk_box; bq_nobox <= blk_nobox; bq_empty <= blk_empty;
                    acc <= 0; n <= 0;
                    blk_box   <= box_db     && !head_moving;
                    blk_nobox <= !box_found && !head_moving;
                    blk_empty <= !box_found && !scene_any && !head_moving;
                end else begin
                    bad <= 3'd0;
                    acc <= acc_nx; n <= n + 1'b1;
                end
            end else if (q3) begin
                if (bad >= BAD_MAX) begin run <= 1'b0; dstab_c <= 1'b0; end
                else                bad <= bad + 3'd1;
            end

            // ---- block -> BASE / TOP -> Z, committed together on S4
            case (sq)
            3'd0: if (blk_done) sq <= 3'd1;
            3'd1: begin
                if (tare_req) begin
                    // 10-23 TARE_EMPTY: not a block the part (or anything) was
                    // seen in -- keep waiting, 去皮中 stays up
                    if ((TARE_EMPTY == 0) || bq_empty) begin
                        base <= blk_mean; base_ok <= 1'b1; tare_req <= 1'b0;
                    end
                    near_n <= 4'd0;
                end else if (bq_nobox && (!base_ok || (blk_mean >= base_lo))) begin
                    base <= blk_mean; base_ok <= 1'b1;
                    near_n <= 4'd0;
                end else if (bq_nobox && (BASE_NEAR_BLK != 0) && ((NEAR_EMPTY == 0) || bq_empty)) begin
                    // nearer than the guard: count it if it agrees with the run
                    if ((near_n != 4'd0) && (blk_mean >= near_lo) && (blk_mean <= near_hi)) begin
                        if (near_n >= BASE_NEAR_BLK - 1) begin
                            base <= blk_mean; near_n <= 4'd0;     // persisted: it IS the table
                        end else begin
                            near_n <= near_n + 4'd1;
                        end
                    end else begin
                        near_n <= 4'd1; near_ref <= blk_mean;     // first of a new run
                    end
                end else begin
                    near_n <= 4'd0;                               // box / dropout / head moving
                end
                if (bq_box) top_w <= blk_mean;
                top_w_ok <= bq_box;
                sq <= 3'd2;
            end
            3'd2: begin
                th_s <= $signed({2'b00, base}) - $signed({2'b00, top_w});
                sq <= 3'd3;
            end
            3'd3: begin
                th_z  <= th_s - z_ofs_mm;              // 10-04 calibration
                neg_w <= (th_s < -NEG_TOL_MM)          // raw: the table check
                      || ((MIN_RAW_MM != 0) && (th_s < MIN_RAW_MM));   // 10-23: BASE is this face
                sq <= 3'd4;
            end
            3'd4: begin
                thick_w <= th_z[17]      ? 16'd0   :
                           (th_z > 999)  ? 16'd999 : th_z[15:0];
                sq <= 3'd5;
            end
            default: begin
                base_mm  <= base;  top_c <= top_w;  thick_mm <= thick_w;
                top_c_ok <= top_w_ok; neg_c <= neg_w;
                dstab_c  <= run;
                cmt      <= 1'b1;
                sq <= 3'd0;
            end
            endcase

            // ---- tare: drop the open block, the next still one is BASE
            if (tare) begin
                tare_req <= 1'b1; run <= 1'b0; dstab_c <= 1'b0;
            end
        end

        // ---- per frame (last, so the clears win).  fr1: miss is current.
        if (fr1) begin
            if (!p3 && (age != 8'hFF)) age <= age + 8'd1;
            if (!p3 && (age >= STALE_FR)) begin run <= 1'b0; dstab_c <= 1'b0; end
            if (box_gone || head_moving) begin
                blk_box <= 1'b0; top_w_ok <= 1'b0; top_c_ok <= 1'b0;
            end
            if (box_found || head_moving) blk_nobox <= 1'b0;
            if (box_found || scene_any || head_moving) blk_empty <= 1'b0;
        end
        if (p3) age <= 8'd0;
    end
end

//---------------------------------------------------------------------------
// Box streak: x0 / y0 / w / h within tolerance of the streak's first frame.
// Same three stages; the refs only change in the action stage.  f3 is two
// clocks after fr1, so miss is current there too.
//---------------------------------------------------------------------------
reg               f2, f3;
reg signed [12:0] dx, dy, dw, dh;
reg        [12:0] ax, ay, aw, ah;
reg        [11:0] xref, yref, wref, href;
reg               srun, sstab;
reg        [7:0]  sn;
reg signed [16:0] dd;
reg        [16:0] ad;
reg               xy_ok;

wire [12:0] ptol  = sstab ? PX_TOL_ST : PX_TOL;
wire        s_far = (ax > ptol) || (ay > ptol) || (aw > ptol) || (ah > ptol);

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        f2 <= 1'b0; f3 <= 1'b0;
        dx <= 0; dy <= 0; dw <= 0; dh <= 0;
        ax <= 0; ay <= 0; aw <= 0; ah <= 0;
        xref <= 0; yref <= 0; wref <= 0; href <= 0;
        srun <= 1'b0; sstab <= 1'b0; sn <= 8'd0;
        dd <= 17'sd0; ad <= 17'd0; xy_ok <= 1'b0;
    end else begin
        f2 <= fr1; f3 <= f2;
        dx <= $signed({1'b0, box_x0})   - $signed({1'b0, xref});
        dy <= $signed({1'b0, box_y0})   - $signed({1'b0, yref});
        dw <= $signed({1'b0, box_w_px}) - $signed({1'b0, wref});
        dh <= $signed({1'b0, box_h_px}) - $signed({1'b0, href});
        ax <= dx[12] ? -dx : dx;
        ay <= dy[12] ? -dy : dy;
        aw <= dw[12] ? -dw : dw;
        ah <= dh[12] ? -dh : dh;
        dd <= $signed({1'b0, size_d_mm}) - $signed({1'b0, top_c});
        ad <= dd[16] ? -dd : dd;

        if (!en) begin
            srun <= 1'b0; sstab <= 1'b0; sn <= 8'd0; xy_ok <= 1'b0;
        end else if (f3) begin
            if (box_found)
                xy_ok <= (ad <= (qc_stable ? XY_TOL_ST_MM : XY_TOL_MM));

            if (box_gone || head_moving) begin
                srun <= 1'b0; sstab <= 1'b0; sn <= 8'd0;
            end else if (!box_found) begin
                // forgiven dropout: hold everything
            end else if (!size_ok) begin
                srun <= 1'b0; sstab <= 1'b0; sn <= 8'd0;
            end else if (!srun || s_far) begin
                srun <= 1'b1; sstab <= 1'b0; sn <= 8'd1;
                xref <= box_x0; yref <= box_y0; wref <= box_w_px; href <= box_h_px;
            end else if (sn >= K_FR - 1) begin
                sstab <= 1'b1;
            end else begin
                sn <= sn + 8'd1;
            end
        end
    end
end

//---------------------------------------------------------------------------
// The flag: rises on st_raw, falls after DROP_FR frames without it.
//---------------------------------------------------------------------------
wire st_raw = en && tof_ok && base_ok && !tare_req && dstab_c && top_c_ok
           && !neg_c && sstab && xy_ok && !head_moving;

reg [7:0] dcnt;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        qc_stable <= 1'b0; dcnt <= 8'd0;
    end else if (!en || !tof_ok || tare_req) begin
        qc_stable <= 1'b0; dcnt <= 8'd0;
    end else if (st_raw) begin
        qc_stable <= 1'b1; dcnt <= 8'd0;
    end else if (qc_stable && fr1) begin
        if (dcnt >= DROP_FR - 1) begin qc_stable <= 1'b0; dcnt <= 8'd0; end
        else                       dcnt <= dcnt + 8'd1;
    end
end

//---------------------------------------------------------------------------
// ⭐ 10-04 calibration: request -> Z candidate -> ask tof_size -> both or
// neither.  base_mm / top_c are the committed pair thick_mm was made from.
//---------------------------------------------------------------------------
reg  [1:0]        c_st;             // 0 idle, 1 subtract, 2 check, 3 wait for tof_size
reg signed [17:0] c_zd, z_cand;
reg               c_r2;
localparam integer CZ2 = (CAL2_Z_MM > 0) ? CAL2_Z_MM : CAL_Z_MM;
reg  [7:0]        c_show;           // frames the result stays up
reg               c_okr, c_apply;
reg  [2:0]        c_whyr;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        c_st <= 2'd0; c_zd <= 18'sd0; z_cand <= 18'sd0; c_show <= 8'd0;
        c_okr <= 1'b0; c_apply <= 1'b0; c_whyr <= 3'd0; c_r2 <= 1'b0;
        cal_go <= 1'b0; z_ofs_mm <= Z_OFS_MM;
    end else begin
        cal_go  <= 1'b0;
        c_apply <= 1'b0;
        if (fr1 && (c_show != 8'd0)) c_show <= c_show - 8'd1;

        case (c_st)
        2'd0: if (cal_req && en) begin
            if (!qc_stable) begin
                c_okr <= 1'b0; c_whyr <= 3'd1; c_show <= CAL_SHOW_FR;
            end else begin
                c_zd <= $signed({2'b00, base_mm}) - $signed({2'b00, top_c});
                c_r2 <= cal_ref2;
                c_st <= 2'd1;
            end
        end
        2'd1: begin
            z_cand <= c_zd - (c_r2 ? CZ2 : CAL_Z_MM);
            c_st   <= 2'd2;
        end
        2'd2: begin
            if ((z_cand > CAL_Z_MAX) || (z_cand < -CAL_Z_MAX)) begin
                c_okr <= 1'b0; c_whyr <= 3'd5; c_show <= CAL_SHOW_FR;
                c_st  <= 2'd0;
            end else begin
                cal_go <= 1'b1;
                c_st   <= 2'd3;
            end
        end
        default: if (cal_done) begin
            c_show <= CAL_SHOW_FR;
            c_st   <= 2'd0;
            if (cal_ok) begin
                c_okr <= 1'b1; c_whyr <= 3'd0;
                z_ofs_mm <= z_cand[7:0];
                c_apply  <= 1'b1;
            end else begin
                c_okr <= 1'b0; c_whyr <= {1'b0, cal_why} + 3'd1;
            end
        end
        endcase

        if (!en) c_show <= 8'd0;           // no stale message on re-entering BOX
    end
end

// The two offsets as sign / tens / ones, clamped to 99.  Free-running, one
// small step per clock; the values only change on a calibration.
function [3:0] tens;
    input [6:0] v;
    tens = (v >= 7'd90) ? 4'd9 : (v >= 7'd80) ? 4'd8 : (v >= 7'd70) ? 4'd7 :
           (v >= 7'd60) ? 4'd6 : (v >= 7'd50) ? 4'd5 : (v >= 7'd40) ? 4'd4 :
           (v >= 7'd30) ? 4'd3 : (v >= 7'd20) ? 4'd2 : (v >= 7'd10) ? 4'd1 : 4'd0;
endfunction

reg  [9:0] ox_a;
reg  [7:0] oz_a;
reg  [6:0] ox_c, oz_c, ox_c2, oz_c2;
reg        ox_n, oz_n, ox_n2, oz_n2, ox_n3, oz_n3;
reg  [3:0] ox_t, oz_t, ox_t3, oz_t3, ox_o, oz_o;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        ox_a <= 10'd0; oz_a <= 8'd0; ox_c <= 7'd0; oz_c <= 7'd0; ox_c2 <= 7'd0; oz_c2 <= 7'd0;
        ox_n <= 1'b0; oz_n <= 1'b0; ox_n2 <= 1'b0; oz_n2 <= 1'b0; ox_n3 <= 1'b0; oz_n3 <= 1'b0;
        ox_t <= 4'd0; oz_t <= 4'd0; ox_t3 <= 4'd0; oz_t3 <= 4'd0; ox_o <= 4'd0; oz_o <= 4'd0;
    end else begin
        ox_a  <= xy_ofs_mm[9] ? -xy_ofs_mm : xy_ofs_mm;   ox_n  <= xy_ofs_mm[9];
        oz_a  <= z_ofs_mm[7]  ? -z_ofs_mm  : z_ofs_mm;    oz_n  <= z_ofs_mm[7];
        ox_c  <= (ox_a > 10'd99) ? 7'd99 : ox_a[6:0];      ox_n2 <= ox_n;
        oz_c  <= (oz_a > 8'd99)  ? 7'd99 : oz_a[6:0];      oz_n2 <= oz_n;
        ox_t  <= tens(ox_c);  ox_c2 <= ox_c;               ox_n3 <= ox_n2;
        oz_t  <= tens(oz_c);  oz_c2 <= oz_c;               oz_n3 <= oz_n2;
        ox_o  <= ox_c2 - {ox_t, 3'd0} - {ox_t, 1'b0};      ox_t3 <= ox_t;
        oz_o  <= oz_c2 - {oz_t, 3'd0} - {oz_t, 1'b0};      oz_t3 <= oz_t;
    end
end

//---------------------------------------------------------------------------
// The trigger.  Snapshot on the rise (or, while up, on a commit), compare with
// the last record over three clocks, then fire if armed or changed.  Nothing in the snapshot can change
// in those clocks (one publish per frame, one commit per block, and the rise
// itself needed both to be settled).
//---------------------------------------------------------------------------
reg               st_d, armed, have_rec;
reg        [3:0]  tq;               // one-hot pipeline: diff / abs / compare / fire
reg        [15:0] p_w, p_h, p_z, p_top, p_base;
reg        [11:0] p_wpx, p_hpx;
reg        [15:0] l_w, l_h, l_z;
reg signed [16:0] cw, ch, cz;
reg        [16:0] gw, gh, gz;
reg               chg;
reg        [3:0]  qc_d0, qc_d1, qc_d2;     // qc_seq in BCD, for the OSD

// rise, or a fresh commit while up and every gate still open (so X / Y are
// consistent with the new Z)
wire t_go = (qc_stable && !st_d) || (cmt && qc_stable && st_d && st_raw);

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        st_d <= 1'b0; armed <= 1'b1; have_rec <= 1'b0; tq <= 4'd0;
        p_w <= 0; p_h <= 0; p_z <= 0; p_top <= 0; p_base <= 0; p_wpx <= 0; p_hpx <= 0;
        l_w <= 0; l_h <= 0; l_z <= 0;
        cw <= 0; ch <= 0; cz <= 0; gw <= 0; gh <= 0; gz <= 0; chg <= 1'b0;
        qc_trig <= 1'b0; qc_seq <= 8'd0; qc_rec <= 128'd0;
        qc_d0 <= 4'd0; qc_d1 <= 4'd0; qc_d2 <= 4'd0;
    end else begin
        st_d    <= qc_stable;
        qc_trig <= 1'b0;
        tq      <= {tq[2:0], t_go};

        if (t_go) begin
            p_w <= size_w_mm; p_h <= size_h_mm; p_z <= thick_mm;
            p_top <= top_c; p_base <= base_mm; p_wpx <= box_w_px; p_hpx <= box_h_px;
        end
        cw <= $signed({1'b0, p_w}) - $signed({1'b0, l_w});
        ch <= $signed({1'b0, p_h}) - $signed({1'b0, l_h});
        cz <= $signed({1'b0, p_z}) - $signed({1'b0, l_z});
        gw <= cw[16] ? -cw : cw;
        gh <= ch[16] ? -ch : ch;
        gz <= cz[16] ? -cz : cz;
        chg <= (gw > CHG_MM) || (gh > CHG_MM) || (gz > CHG_MM);

        if (tq[3] && (armed || chg || !have_rec)) begin
            qc_trig  <= 1'b1;
            qc_seq   <= qc_seq + 8'd1;
            qc_rec   <= {1'b1, base_ok, 6'd0, p_w, p_h, p_z, p_top, p_base,
                         p_wpx, p_hpx, qc_seq + 8'd1, 8'd0};
            l_w <= p_w; l_h <= p_h; l_z <= p_z;
            have_rec <= 1'b1;
            armed    <= 1'b0;
            // BCD increment, so the OSD never needs a divide
            if (qc_d0 != 4'd9)      qc_d0 <= qc_d0 + 4'd1;
            else begin
                qc_d0 <= 4'd0;
                if (qc_d1 != 4'd9)  qc_d1 <= qc_d1 + 4'd1;
                else begin
                    qc_d1 <= 4'd0;
                    qc_d2 <= (qc_seq == 8'd255) ? 4'd0 : (qc_d2 + 4'd1);
                end
            end
            if (qc_seq == 8'd255) begin qc_d0 <= 4'd0; qc_d1 <= 4'd0; qc_d2 <= 4'd0; end
        end

        // re-arm (after the fire block, so a removal seen on the same clock wins)
        if (!en || tare || c_apply || (fr1 && (miss >= REARM_FR))) armed <= 1'b1;
    end
end

//---------------------------------------------------------------------------
// OSD text: snapshot on pub_stb, two 10-bit double-dabbles, one publish clock.
//---------------------------------------------------------------------------
localparam [3:0] R_OFF = 4'd0, R_NOTOF = 4'd1, R_TARE = 4'd2, R_NOBASE = 4'd3,
                 R_NOOBJ = 4'd4, R_TOFBAD = 4'd5, R_MOVE = 4'd6, R_NEG = 4'd7,
                 R_SETTLE = 4'd8, R_STABLE = 4'd9;

reg [3:0] rsn;
always @(*) begin
    if      (!en)                rsn = R_OFF;
    else if (!tof_ok)            rsn = R_NOTOF;
    else if (tare_req)           rsn = R_TARE;
    else if (qc_stable)          rsn = R_STABLE;
    else if (!base_ok)           rsn = R_NOBASE;
    else if (box_gone)           rsn = R_NOOBJ;
    else if (head_moving)        rsn = R_MOVE;
    else if (!run || bad != 0)   rsn = R_TOFBAD;
    else if (top_c_ok && neg_c)  rsn = R_NEG;
    else                         rsn = R_SETTLE;
end

reg  [3:0]  s_rsn, s_d0, s_d1, s_d2;
reg         s_cs, s_cok;            // 10-04 calibration result
reg  [2:0]  s_cwhy;
reg  [63:0] s_ctxt;
reg         s_zok, s_bok;
reg  [1:0]  s_why;
reg  [63:0] s_size;
reg  [9:0]  s_v1;                   // BASE, clamped
reg         tb_run, tb_i;
reg  [3:0]  tb_k;
reg  [9:0]  tb_bin;
reg  [11:0] tb_bcd, bcd_t, bcd_b;
reg         tb_pub;

wire [11:0] tb_adj = { (tb_bcd[11:8] >= 4'd5) ? tb_bcd[11:8] + 4'd3 : tb_bcd[11:8],
                       (tb_bcd[7:4]  >= 4'd5) ? tb_bcd[7:4]  + 4'd3 : tb_bcd[7:4],
                       (tb_bcd[3:0]  >= 4'd5) ? tb_bcd[3:0]  + 4'd3 : tb_bcd[3:0] };
wire [11:0] tb_nx  = {tb_adj[10:0], tb_bin[9]};

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        s_rsn <= R_OFF; s_d0 <= 4'd0; s_d1 <= 4'd0; s_d2 <= 4'd0;
        s_zok <= 1'b0; s_bok <= 1'b0; s_why <= 2'd1; s_size <= "        ";
        s_v1 <= 10'd0;
        s_cs <= 1'b0; s_cok <= 1'b0; s_cwhy <= 3'd0; s_ctxt <= "        ";
        tb_run <= 1'b0; tb_i <= 1'b0; tb_k <= 4'd0; tb_bin <= 10'd0;
        tb_bcd <= 12'd0; bcd_t <= 12'd0; bcd_b <= 12'd0; tb_pub <= 1'b0;
    end else begin
        tb_pub <= 1'b0;
        if (pub_stb && !tb_run) begin
            s_rsn  <= rsn;
            s_d0   <= qc_d0; s_d1 <= qc_d1; s_d2 <= qc_d2;
            s_zok  <= en && top_c_ok;
            s_bok  <= base_ok;
            s_why  <= size_why;
            s_size <= size_text;
            s_v1   <= (base_mm > 16'd999) ? 10'd999 : base_mm[9:0];
            s_cs   <= (c_show != 8'd0);
            s_cok  <= c_okr;
            s_cwhy <= c_whyr;
            s_ctxt <= {CN_BIAO, CN_DING, ox_n3 ? "-" : "+", 8'h30 + {4'd0, ox_t3},
                       8'h30 + {4'd0, ox_o}, oz_n3 ? "-" : "+", 8'h30 + {4'd0, oz_t3},
                       8'h30 + {4'd0, oz_o}};
            tb_bin <= thick_mm[9:0];             // already clamped to 999
            tb_bcd <= 12'd0; tb_k <= 4'd0; tb_i <= 1'b0; tb_run <= 1'b1;
        end else if (tb_run) begin
            tb_bcd <= tb_nx;
            tb_bin <= {tb_bin[8:0], 1'b0};
            if (tb_k == 4'd9) begin
                tb_k <= 4'd0;
                if (!tb_i) begin
                    bcd_t  <= tb_nx;
                    tb_bin <= s_v1; tb_bcd <= 12'd0; tb_i <= 1'b1;
                end else begin
                    bcd_b  <= tb_nx;
                    tb_run <= 1'b0; tb_pub <= 1'b1;
                end
            end else begin
                tb_k <= tb_k + 4'd1;
            end
        end
    end
end

function [7:0] dg;                      // digit, or blank
    input [3:0] d;
    input       blank;
    dg = blank ? 8'h20 : (8'h30 + {4'd0, d});
endfunction

wire [23:0] z3 = s_zok ? { dg(bcd_t[11:8], bcd_t[11:8] == 4'd0),
                           dg(bcd_t[7:4],  bcd_t[11:4] == 8'd0),
                           dg(bcd_t[3:0],  1'b0) } : "  -";
wire [23:0] b3 = { dg(bcd_b[11:8], bcd_b[11:8] == 4'd0),
                   dg(bcd_b[7:4],  bcd_b[11:4] == 8'd0),
                   dg(bcd_b[3:0],  1'b0) };
// record number, LEFT-aligned after '#': "#1  ", "#12 ", "#123"
wire [7:0]  c2 = 8'h30 + {4'd0, s_d2};
wire [7:0]  c1 = 8'h30 + {4'd0, s_d1};
wire [7:0]  c0 = 8'h30 + {4'd0, s_d0};
wire [23:0] n3 = (s_d2 != 4'd0) ? {c2, c1, c0} :
                 (s_d1 != 4'd0) ? {c1, c0, " "} : {c0, "  "};

reg [95:0] t_size;
always @(*) begin
    case (s_why)
    2'd0:    t_size = {s_size[63:8], "X", z3, s_size[7:0]};
    2'd1:    t_size = {CN_WU, CN_CE, CN_JU, "         "};       // 无测距
    2'd2:    t_size = {CN_FANG, CN_SHE, CN_ZHONG, "         "};  // 仿射中
    default: t_size = {CN_WU, CN_KUANG, "          "};          // 无框
    endcase
end

reg [63:0] t_qc;
always @(*) begin
    if (s_cs)                                                          // 10-04
        t_qc = s_cok ? s_ctxt                                          // 标定+17+06
                     : {CN_BIAO, CN_DING, CN_CUO, 8'h30 + {5'd0, s_cwhy}, "    "};  // 标定错N
    else case (s_rsn)
    R_OFF:    t_qc = {CN_GUAN, CN_BI, "      "};                       // 关闭
    R_NOTOF:  t_qc = {CN_CE, CN_JU, CN_GU, CN_ZHANG, "    "};          // 测距故障
    R_TARE:   t_qc = {CN_QU, CN_PI, CN_ZHONG, "     "};                // 去皮中
    R_NOBASE: t_qc = {CN_XUE, CN_XI, CN_TAI, CN_MIAN, "    "};         // 学习台面
    R_NOOBJ:  t_qc = {CN_WU, CN_GONG, CN_JIAN2, "     "};              // 无工件
    R_TOFBAD: t_qc = {CN_CE, CN_JU, CN_BU, CN_WEN, "    "};            // 测距不稳
    R_MOVE:   t_qc = {CN_YUN, CN_TAI, CN_YI, CN_DONG, "    "};         // 云台移动
    R_NEG:    t_qc = {CN_TAI, CN_MIAN, CN_YI2, CN_CHANG, "    "};      // 台面异常
    R_STABLE: t_qc = {CN_WEN, CN_DING, " ", "#", n3, " "};             // 稳定 #n
    default:  t_qc = {CN_CE, CN_LIANG, CN_ZHONG, "     "};             // 测量中
    endcase
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        size3_text <= {CN_WU, CN_CE, CN_JU, "         "};
        base_text  <= "  -     ";
        qc_text    <= {CN_GUAN, CN_BI, "      "};
        qc_text_cal <= 1'b0;
        qc_text_stb <= 1'b0;
    end else if (tb_pub) begin
        size3_text <= t_size;
        base_text  <= s_bok ? {b3, "MM   "} : "  -     ";
        qc_text    <= t_qc;
        qc_text_cal <= s_cs;
        qc_text_stb <= !s_cs && (s_rsn == R_STABLE);
    end
end

endmodule
