//---------------------------------------------------------------------------
// tof_roi_scan -- which receiving-array ROI the VL53L1X ranges with, and the
// scan that finds where the workpiece sits in it (2026-10-04).
//
// WHY.  Board report: "at rest it reads 10-20 mm long (hand 150, shown
// 160-170); nudge the module's angle and it is right again".  That is the
// 27 deg cone: at 15 cm the spot is ~73 mm across against a 28 x 55 mm top
// face, so the reading is a signal-weighted blend of workpiece and table, and
// which mix you get depends on where the cone's axis happens to land.  An 8 x
// 8 SPAD ROI is roughly a 15-20 deg cone (VL53L1X UM2356 / ULD SetROI) --
// but the ranger sits beside the lens, so its axis is NOT the picture's
// centre (parallax F * base / D, ~250 px at 15 cm for a 2 cm base), and a
// narrow cone at the array centre can miss the workpiece outright.  So the
// narrow ROI's CENTRE is found on the board, by measurement.
//
// HOW.  ROI centres are SPADs on the 16 x 16 array (ULD numbering, 199 =
// array centre); the scan grid is GRID x GRID centres, STEP SPADs apart.  At
// every grid point SCAN_SKIP readings are discarded, then SCAN_N valid ones
// averaged; the SHORTEST mean wins -- the workpiece is what sticks up, so the
// ROI seeing most of it and least of the table reads shortest.  Ties keep the
// point nearer the array centre (scan order is centre-out).  Readings below
// SCAN_MIN_MM are not counted: the lens barrel or a bracket edge inside a
// cone reads a few cm and would otherwise win.
//
//   scan_go (one clock) : scan, then lock the winner (en = 1 only).
//   en = 0              : 16 x 16 at 199, the 10-03 ROI -- TRACK / FACE /
//                         RAW, where aim_sched / trk_range need the full cone
//                         out to 1 m and more.
//   en = 1              : 16 x 16 until a scan has succeeded (NARROW0 = 0:
//                         nothing changes until the user asks), then ROI_W x
//                         ROI_H at the locked centre.  NARROW0 = 1: narrow at
//                         CTR_COL0 / CTR_ROW0 from power-up.
// Lost at power-off: once the mount is final, copy roi_col / roi_row (the OSD
// shows the SPAD number; ChipWatcher the pair) into CTR_COL0 / CTR_ROW0 and
// set NARROW0 = 1.
//
// ⚠ ULD's SPAD numbering is NOT row-major: 0..127 run down the columns of the
// bottom half, 128..255 down the columns of the top half (the SPAD map in
// ST's ULD / UM2356).  For a centre (col, row), 0..15, row 15 = top:
//     row >= 8 : 128 + col * 8 + (15 - row)
//     row <  8 : (15 - col) * 8 + row
// Checks against the map: (8, 8) = 199 (ULD's default centre), (7, 7) = 71,
// (0, 15) = 128, (15, 0) = 0, (15, 15) = 248, (0, 0) = 120.  (col, row) is as
// the PART sees it; which way that is in the picture depends on the mount and
// does not matter -- the scan only needs the grid.
//
// To vl53l1x_ctrl (RUNTIME_ROI = 1): roi_ctr / roi_xy.  It tags every
// published measurement with the ROI it really used (dist_roi_*), so a
// reading is only counted for the grid point it belongs to.
//
// OSD: osd_text, 5 chars after the 距离 value -- "     " full cone (as
// before), " S3/9" scanning point 3 of 9, " R199" narrow ROI centred on SPAD
// 199, " SERR" for ERR_SHOW_MS when no grid point gave SCAN_N valid readings
// (the previous ROI is kept).
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module tof_roi_scan #(
parameter integer ROI_W       = 8,     // narrow ROI, BOX mode (4..16)
parameter integer ROI_H       = 8,
parameter integer GRID        = 3,     // grid points per axis: 3 (centre-out) or 5 (raster)
parameter integer STEP        = 3,     // SPADs between grid points
parameter integer CTR_COL0    = 8,     // NARROW0 centre (col, row); 8 / 8 = SPAD 199
parameter integer CTR_ROW0    = 8,
parameter integer NARROW0     = 0,
parameter integer SCAN_N      = 4,     // valid readings averaged per point (1, 2, 4, 8, 16)
parameter integer SCAN_SKIP   = 1,     // readings discarded first at each point
parameter integer TMO_MEAS    = 12,    // a point gives up this many strobes after the skip
parameter integer SCAN_MIN_MM = 50,    // shorter: crosstalk, not counted
parameter integer CLK_HZ      = 150000000,
parameter integer ERR_SHOW_MS = 2000
)(
input  wire        clk,
input  wire        rst_n,

input  wire        en,               // BOX mode
input  wire        scan_go,          // one clock

input  wire        dist_stb,
input  wire [15:0] dist_mm,
input  wire [7:0]  dist_code,        // 0 = valid
input  wire [7:0]  dist_roi_ctr,     // what the strobed measurement used
input  wire [7:0]  dist_roi_xy,

output reg  [7:0]  roi_ctr,
output reg  [7:0]  roi_xy,
output reg         scanning,
output reg  [3:0]  roi_col,          // the locked centre
output reg  [3:0]  roi_row,
output reg  [39:0] osd_text
);

localparam [7:0]   XY_FULL   = 8'hFF;                         // 16 x 16
localparam [7:0]   XY_NARROW = ((ROI_H - 1) << 4) | (ROI_W - 1);
localparam integer NPT       = GRID * GRID;
localparam integer HALF      = GRID / 2;
localparam integer NLOG      = (SCAN_N <= 1) ? 0 : (SCAN_N <= 2) ? 1 : (SCAN_N <= 4) ? 2 :
                               (SCAN_N <= 8) ? 3 : 4;
localparam [31:0]  ERR_CLK   = CLK_HZ / 1000 * ERR_SHOW_MS;
// the centre keeps the ROI on the array: ULD's ROI spans centre - W/2 ..
// centre + W/2 - 1
localparam integer CMIN_C = ROI_W / 2, CMAX_C = 16 - (ROI_W + 1) / 2;
localparam integer CMIN_R = ROI_H / 2, CMAX_R = 16 - (ROI_H + 1) / 2;
localparam [7:0]   CTR0   = (CTR_ROW0 >= 8) ? (128 + CTR_COL0 * 8 + (15 - CTR_ROW0))
                                            : ((15 - CTR_COL0) * 8 + CTR_ROW0);

// (col, row) -> SPAD (see the header)
function [7:0] roi_spad;
    input [3:0] col;
    input [3:0] row;
    roi_spad = row[3] ? (8'd128 + {1'b0, col, 3'b000} + {4'd0, 4'd15 - row})
                      : ({1'b0, 4'd15 - col, 3'b000} + {4'd0, row});
endfunction

// grid offset of point k, in grid steps: GRID 3 centre first, then the ring
function signed [3:0] gdx;
    input [3:0] kk;
    if (GRID == 3)
        case (kk) 4'd1, 4'd5, 4'd7: gdx = 1;  4'd2, 4'd6, 4'd8: gdx = -1;
                  default: gdx = 0; endcase
    else gdx = $signed({1'b0, kk % GRID}) - HALF;
endfunction
function signed [3:0] gdy;
    input [3:0] kk;
    if (GRID == 3)
        case (kk) 4'd3, 4'd5, 4'd6: gdy = 1;  4'd4, 4'd7, 4'd8: gdy = -1;
                  default: gdy = 0; endcase
    else gdy = $signed({1'b0, kk / GRID}) - HALF;
endfunction
function [3:0] clamp;
    input signed [7:0] v;
    input integer lo, hi;
    clamp = (v < lo) ? lo : (v > hi) ? hi : v[3:0];
endfunction

//---------------------------------------------------------------------------
// The scan
//---------------------------------------------------------------------------
reg  [3:0]  k;                      // scan point
reg  [3:0]  pc_col, pc_row;         // point k's centre, registered (k changes
reg  [7:0]  pc_spad;                // once per point, strobes are 60 ms apart)
reg  [7:0]  lock_c;
reg         locked;                 // a narrow ROI is in use
reg  [4:0]  got, seen;
reg  [19:0] acc;
reg  [15:0] best_d;
reg  [3:0]  best_c, best_r;
reg  [7:0]  best_s;
reg         best_ok;
reg         sc_run;
reg  [1:0]  fin;                    // 0 collect, 1 mean, 2 compare, 3 lock
reg  [15:0] mean_d;
reg  [31:0] err_t;

wire signed [7:0] cx = 8'sd8 + gdx(k) * STEP;
wire signed [7:0] cy = 8'sd8 + gdy(k) * STEP;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        pc_col <= 4'd8; pc_row <= 4'd8; pc_spad <= 8'd199;
    end else begin
        pc_col  <= clamp(cx, CMIN_C, CMAX_C);
        pc_row  <= clamp(cy, CMIN_R, CMAX_R);
        pc_spad <= roi_spad(pc_col, pc_row);
    end
end

wire mine = dist_stb && (dist_roi_ctr == pc_spad) && (dist_roi_xy == XY_NARROW);
wire good = (dist_code == 8'd0) && (dist_mm >= SCAN_MIN_MM);

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        lock_c <= CTR0; locked <= (NARROW0 != 0);
        roi_col <= CTR_COL0; roi_row <= CTR_ROW0;
        k <= 4'd0; got <= 5'd0; seen <= 5'd0; acc <= 20'd0;
        best_d <= 16'hFFFF; best_c <= 4'd8; best_r <= 4'd8; best_s <= 8'd199; best_ok <= 1'b0;
        sc_run <= 1'b0; fin <= 2'd0; mean_d <= 16'd0; err_t <= 32'd0;
    end else begin
        if (err_t != 32'd0) err_t <= err_t - 32'd1;
        if (!en) begin
            sc_run <= 1'b0; fin <= 2'd0;
        end else if (scan_go && !sc_run) begin
            sc_run <= 1'b1; k <= 4'd0; got <= 5'd0; seen <= 5'd0; acc <= 20'd0;
            best_d <= 16'hFFFF; best_ok <= 1'b0; fin <= 2'd0; err_t <= 32'd0;
        end else if (sc_run) begin
            case (fin)
            2'd0: if (mine) begin
                seen <= seen + 5'd1;
                if ((seen >= SCAN_SKIP) && good) begin
                    acc <= acc + {4'd0, dist_mm};
                    got <= got + 5'd1;
                    if (got + 5'd1 == SCAN_N) fin <= 2'd1;
                end
                if (seen + 5'd1 == SCAN_SKIP + TMO_MEAS) fin <= 2'd1;   // give up
            end
            2'd1: begin
                mean_d <= acc[NLOG+15:NLOG];
                fin    <= 2'd2;
            end
            2'd2: begin
                // strictly shorter wins: ties keep the earlier, more central point
                if ((got == SCAN_N) && (!best_ok || (mean_d < best_d))) begin
                    best_d <= mean_d; best_ok <= 1'b1;
                    best_c <= pc_col; best_r <= pc_row; best_s <= pc_spad;
                end
                got <= 5'd0; seen <= 5'd0; acc <= 20'd0;
                if (k == NPT - 1) fin <= 2'd3;
                else begin k <= k + 4'd1; fin <= 2'd0; end
            end
            default: begin
                sc_run <= 1'b0; fin <= 2'd0;
                if (best_ok) begin
                    lock_c <= best_s; roi_col <= best_c; roi_row <= best_r;
                    locked <= 1'b1;
                end else begin
                    err_t  <= ERR_CLK;           // nothing valid: keep the old ROI
                end
            end
            endcase
        end
    end
end

// The request.  During the scan it follows k from the clock after k moved
// (pc_spad's lag), and readings are only counted when their tag matches.
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        roi_ctr <= 8'd199; roi_xy <= XY_FULL; scanning <= 1'b0;
    end else begin
        scanning <= sc_run;
        if (!en) begin
            roi_ctr <= 8'd199;  roi_xy <= XY_FULL;
        end else if (sc_run) begin
            roi_ctr <= pc_spad; roi_xy <= XY_NARROW;
        end else if (locked) begin
            roi_ctr <= lock_c;  roi_xy <= XY_NARROW;
        end else begin
            roi_ctr <= 8'd199;  roi_xy <= XY_FULL;
        end
    end
end

//---------------------------------------------------------------------------
// OSD.  lock_c in decimal by repeated subtraction, free-running (it only
// changes on a scan); dec is written only when a conversion has finished.
//---------------------------------------------------------------------------
function [7:0] dch;
    input [3:0] d;
    dch = 8'h30 + {4'd0, d};
endfunction
reg [3:0]  h2, h1;
reg [7:0]  dv;
reg [1:0]  dvs;
reg [11:0] dec;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        h2 <= 4'd0; h1 <= 4'd0; dv <= 8'd0; dvs <= 2'd0; dec <= 12'h199;
    end else begin
        case (dvs)
        2'd0: begin dv <= lock_c; h2 <= 4'd0; h1 <= 4'd0; dvs <= 2'd1; end
        2'd1: if (dv >= 8'd100) begin dv <= dv - 8'd100; h2 <= h2 + 4'd1; end else dvs <= 2'd2;
        2'd2: if (dv >= 8'd10)  begin dv <= dv - 8'd10;  h1 <= h1 + 4'd1; end else dvs <= 2'd3;
        default: begin dec <= {h2, h1, dv[3:0]}; dvs <= 2'd0; end
        endcase
    end
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n)              osd_text <= "     ";
    else if (!en)            osd_text <= "     ";
    else if (sc_run)         osd_text <= {" S", dch(k + 4'd1), "/", dch(NPT)};
    else if (err_t != 32'd0) osd_text <= " SERR";
    else if (locked)         osd_text <= {" R", dch(dec[11:8]), dch(dec[7:4]), dch(dec[3:0])};
    else                     osd_text <= "     ";
end

endmodule
