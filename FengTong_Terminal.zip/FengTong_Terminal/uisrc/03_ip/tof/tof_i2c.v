//---------------------------------------------------------------------------
// tof_i2c -- byte-level open-drain I2C master for the VL53L1X ranger.
//
// WHY NOT uii2c (the camera's master)
//   uii2c clocks its state machine off a divided fabric signal (posedge
//   scl_clk), takes a whole transfer as one WMEN_LEN*8-bit register and counts
//   bytes in 8 bits.  The VL53L1X init is 91 register writes plus polling
//   reads, so that shape would need a 91-byte-wide port or 91 instances of its
//   sequencing.  This one is the other shape: four primitive operations
//   (START / WRITE byte / READ byte / STOP), one clock domain, a clock ENABLE
//   instead of a generated clock, and the sequencing lives in vl53l1x_ctrl.
//
// TIMING
//   One SCL period = 4 quarters of QDIV clocks.  Per bit:
//       q0  set SDA (SCL is low)
//       q1  release SCL
//       q2  SCL is high: sample SDA (read / ack), or make START/STOP's edge
//       q3  pull SCL low
//   so SDA only ever moves while SCL is low, except for the two edges START
//   and STOP exist to make.  START works from idle AND from mid-transfer (SCL
//   low), so a repeated start is just another START.
//
//   At 100 kHz a quarter is 2.5 us: SCL high and low are 5 us each, data setup
//   2.5 us.  START hold, repeated-START setup and STOP setup are ONE quarter,
//   2.5 us -- inside the Fast-mode minimum (0.6 us) the VL53L1X is rated for
//   (it is a Fast-mode Plus part), but under the 4.0 / 4.7 us that a
//   Standard-mode-only slave would demand.  Reuse this for such a part and
//   those three want two quarters.
//
// CLOCK STRETCHING and the watchdog
//   q2 does not advance until the synchronised SCL actually reads high, which
//   is all stretching support is.  The same wait is what would hang forever
//   on a shorted or unpulled SCL, so it is bounded: STRETCH_MAX quarters and
//   the operation aborts with `err`, both lines released.  The caller treats
//   err exactly like a NACK.  Without this a loose wire would freeze the
//   ranger in a state no readout could explain.
//
// ⚠ BOTH LINES ARE OPEN DRAIN -- 0 or Z, never a driven 1.  The pins this
// drives on the MLK-H10 are LED cathodes with a 2.2 K + LED to VCC_3V3, so
// "driven low" lights the LED and "released" is pulled up by the module's
// own pull-ups (and PULLTYPE = PULLUP in fpga_pin.adc as a backstop).  The
// LED is therefore a free bus-activity light.
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module tof_i2c #(
parameter integer QDIV        = 60,     // clocks per quarter SCL period
parameter integer STRETCH_MAX = 1023    // quarters SCL may be held low
)(
input  wire       clk,
input  wire       rst_n,

input  wire       cmd_go,        // one clock, only while !busy
input  wire [1:0] cmd_op,        // OP_START / OP_WRITE / OP_READ / OP_STOP
input  wire [7:0] cmd_wdata,
input  wire       cmd_nack,      // READ: 1 = NACK this byte (the last one)

output reg        busy,
output reg        done,          // one clock when an operation finishes
output reg        ack,           // WRITE: the slave pulled SDA low
output reg        err,           // the stretch watchdog fired
output reg  [7:0] rdata,

inout  wire       io_scl,
inout  wire       io_sda
);

localparam [1:0] OP_START = 2'd0,
                 OP_WRITE = 2'd1,
                 OP_READ  = 2'd2,
                 OP_STOP  = 2'd3;

reg scl_o, sda_o;                // 1 = release, 0 = pull low

assign io_scl = scl_o ? 1'bz : 1'b0;
assign io_sda = sda_o ? 1'bz : 1'b0;

// Two-flop synchronisers.  The lines are asynchronous to this clock by
// definition -- the slave moves SDA whenever it likes while SCL is low.
reg [1:0] scl_q, sda_q;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        scl_q <= 2'b11; sda_q <= 2'b11;
    end else begin
        scl_q <= {scl_q[0], io_scl};
        sda_q <= {sda_q[0], io_sda};
    end
end
wire scl_s = scl_q[1];
wire sda_s = sda_q[1];

reg [1:0]  op, ph;
reg [3:0]  bitn;                 // 0..7 data, 8 = the ack bit
reg [7:0]  sh;
reg        nack_r;
reg [15:0] qcnt;
reg [9:0]  stretch;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        scl_o <= 1'b1; sda_o <= 1'b1;
        busy  <= 1'b0; done  <= 1'b0; ack <= 1'b0; err <= 1'b0;
        rdata <= 8'd0;
        op <= 2'd0; ph <= 2'd0; bitn <= 4'd0; sh <= 8'd0; nack_r <= 1'b0;
        qcnt <= 16'd0; stretch <= 10'd0;
    end else begin
        done <= 1'b0;

        if (!busy) begin
            if (cmd_go) begin
                busy    <= 1'b1;
                err     <= 1'b0;
                op      <= cmd_op;
                sh      <= cmd_wdata;
                nack_r  <= cmd_nack;
                ph      <= 2'd0;
                bitn    <= 4'd0;
                qcnt    <= 16'd0;
                stretch <= 10'd0;
            end
        end
        else if (qcnt != QDIV - 1) begin
            qcnt <= qcnt + 16'd1;
        end
        else begin
            qcnt <= 16'd0;
            case (ph)
            2'd0: begin
                case (op)
                OP_START: sda_o <= 1'b1;
                OP_STOP : sda_o <= 1'b0;
                OP_WRITE: sda_o <= (bitn == 4'd8) ? 1'b1   : sh[7];
                OP_READ : sda_o <= (bitn == 4'd8) ? nack_r : 1'b1;
                endcase
                ph <= 2'd1;
            end

            2'd1: begin
                scl_o <= 1'b1;
                ph    <= 2'd2;
            end

            2'd2: begin
                if (scl_s) begin
                    case (op)
                    OP_START: sda_o <= 1'b0;             // the START edge
                    OP_STOP : sda_o <= 1'b1;             // the STOP edge
                    OP_WRITE: if (bitn == 4'd8) ack <= ~sda_s;
                              else              sh  <= {sh[6:0], 1'b0};
                    OP_READ : if (bitn != 4'd8) sh  <= {sh[6:0], sda_s};
                    endcase
                    ph <= 2'd3;
                end
                else if (stretch == STRETCH_MAX) begin
                    // SCL never came up.  Let go of everything and report;
                    // the caller restarts the device from its bus clear.
                    scl_o <= 1'b1;
                    sda_o <= 1'b1;
                    err   <= 1'b1;
                    ack   <= 1'b0;
                    busy  <= 1'b0;
                    done  <= 1'b1;
                end
                else begin
                    stretch <= stretch + 10'd1;
                end
            end

            2'd3: begin
                // STOP leaves SCL high: that is the idle bus.
                if (op != OP_STOP) scl_o <= 1'b0;

                if ((op == OP_START) || (op == OP_STOP) || (bitn == 4'd8)) begin
                    busy <= 1'b0;
                    done <= 1'b1;
                    if (op == OP_READ) rdata <= sh;
                end else begin
                    bitn <= bitn + 4'd1;
                    ph   <= 2'd0;
                end
            end
            endcase
        end
    end
end

endmodule
