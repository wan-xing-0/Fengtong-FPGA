//---------------------------------------------------------------------------
// trk_range -- single-target security mode (2026-10-01 evening): the ToF
// FOLLOWS the magenta tracker box and ranges it continuously.
//
// Why a second scheduler next to aim_sched.  aim_sched serves many green
// boxes by polling: aim, settle 150 ms, take 3 readings, move on.  It has to
// key its readings by POSITION because a motion slot is not an identity, and
// a target that moves more than the 2-block gate between two visits loses
// its number.  The tracker IS an identity -- one box, gated association,
// IIR-smoothed centre -- so here the head simply stays on it:
//
//   * every frame the tracker is held, re-aim at its centre if it moved more
//     than AIM_DB_PX (deadband: the centre dithers by one 1/16-block LSB and
//     an SG90 buzzes on that)
//   * a NEW track, or a re-aim larger than SLEW_PX, restarts SETTLE_MS and
//     empties the reading window -- those readings belong to the old point
//   * every trusted reading (RangeStatus 0, sigma <= SIG_MAX_MM) after the
//     settle goes into a 3-deep window; the label shows its median
//   * no trusted reading for FRESH_MS -> the window is emptied -> '?'
//   * track gone for PARK_FR frames, or !en -> head parks at centre (re-sent
//     every frame, so whichever scheduler the head is switched to finds it
//     where it expects)
//
// ⚠ trk_held, NOT box_v, drives the ranging.  With the camera fixed a hidden
// (coasting) track is an object that paused -- frame difference is a high
// pass -- and its position is still valid.  box_v only decides the label.
//
// Outputs are aim_sched's formats, one slot: lb_* for aim_label (PIXEL
// origin, aim_label's lb_pxo path), and one 128-bit res_tab record.
//
// ⚠ ONE SNAPSHOT, ONE PUBLISH CLOCK.  The vs rising edge copies the box and
// the distance; sizes and BCD run on the copy; labels and the record are
// written together in F_PUB (the det_overlay 09-19 lesson).  The tracker's
// rectangle is registered at motion_frame_drawer's TGEO, ~80 clocks after the
// vs FALLING edge, so at the rising edge it is the one being drawn.
//
// SIZE: W = (x1 - x0) * D / F_PX, H likewise, D = this target's distance.
// The span x1 - x0 is exactly trk_w * BLK_W when not clipped by the frame.
// NO DSP: shift-add, one carry chain per clock.
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module trk_range #(
parameter integer IMG_HDISP  = 1920,
parameter integer IMG_VDISP  = 1080,
parameter integer CLK_HZ     = 150000000,

// ⚠ Same GUESS as tof_size / aim_sched -- calibrate all three together.
// >= ~400, or the 34-bit product below overflows.
parameter integer F_PX       = 1371,
parameter integer D_OFS_MM   = 0,

parameter integer SIG_MAX_MM = 25,         // 0 = no sigma gate
parameter integer SETTLE_MS  = 150,
parameter integer FRESH_MS   = 600,
parameter [11:0]  AIM_DB_PX  = 12'd16,
parameter [11:0]  SLEW_PX    = 12'd192,
parameter [7:0]   ALARM_HOLD = 8'd90,
parameter [7:0]   PARK_FR    = 8'd120
)(
input  wire        clk,
input  wire        rst_n,
input  wire        vs,
input  wire        en,                    // TRACK mode, magenta view

input  wire        trk_held,              // motion_frame_drawer trk_state != 0
input  wire        box_v,                 // its box is drawn this frame
input  wire [11:0] cx,                    // target_x / target_y, pixels
input  wire [11:0] cy,
input  wire [11:0] bx0, bx1, by0, by1,    // the drawn rectangle, pixels

input  wire [15:0] dist_mm,
input  wire [7:0]  dist_code,
input  wire [13:0] dist_sigma,
input  wire        dist_stb,

output reg  [11:0] aim_x,
output reg  [11:0] aim_y,
output reg         aim_go,

output reg  [11:0] lb_px0,
output reg  [11:0] lb_py0,
output reg         lb_valid,
output reg         lb_dok,
output reg         lb_aim,
output reg  [15:0] lb_d_bcd,
output reg  [15:0] lb_w_bcd,
output reg  [15:0] lb_h_bcd,
output reg         alarm,

// aim_sched's record format (see its port list), slot 0
output reg  [127:0] res_rec,
output reg  [7:0]   res_seq,
output reg          res_stb
);

localparam integer MS_DIV = CLK_HZ / 1000;
localparam [11:0]  CX = IMG_HDISP / 2;
localparam [11:0]  CY = IMG_VDISP / 2;

// W = (span * D * KQ + 2^(RSH-1)) >> RSH,  KQ = 2^RSH / F_PX
localparam integer RSH = 18;
localparam integer KQ  = ((1 << RSH) + F_PX / 2) / F_PX;

//---------------------------------------------------------------------------
// Edges and ticks
//---------------------------------------------------------------------------
reg vs_d;
always @(posedge clk or negedge rst_n)
    if (!rst_n) vs_d <= 1'b0; else vs_d <= vs;
wire frame_edge = vs & ~vs_d;

reg  [17:0] msdiv;
wire        ms_tick = (msdiv == MS_DIV - 1);
always @(posedge clk or negedge rst_n)
    if (!rst_n) msdiv <= 18'd0; else msdiv <= ms_tick ? 18'd0 : msdiv + 18'd1;

//---------------------------------------------------------------------------
// Follow + range
//---------------------------------------------------------------------------
reg        aimed;                       // the head is on the current track
reg [15:0] settle;                      // ms left
reg [15:0] fresh;                       // ms since the last trusted reading
reg [1:0]  nw;
reg [15:0] w0, w1, w2;
reg [7:0]  age;                         // frames since the last trusted reading
reg [7:0]  noobj;

wire trusted = (dist_code == 8'd0)
            && ((SIG_MAX_MM == 0) || (dist_sigma <= SIG_MAX_MM));

wire [11:0] adx = (cx > aim_x) ? (cx - aim_x) : (aim_x - cx);
wire [11:0] ady = (cy > aim_y) ? (cy - aim_y) : (aim_y - cy);
wire        f_move = !aimed || (adx > AIM_DB_PX) || (ady > AIM_DB_PX);
wire        f_slew = !aimed || (adx > SLEW_PX)   || (ady > SLEW_PX);

// median of three; fewer -> mean of two / the one
wire [15:0] lo01 = (w0 < w1) ? w0 : w1;
wire [15:0] hi01 = (w0 < w1) ? w1 : w0;
wire [15:0] med3 = (w2 <= lo01) ? lo01 : (w2 >= hi01) ? hi01 : w2;
wire [16:0] sum2 = {1'b0, w0} + {1'b0, w1};
wire [15:0] dmed = (nw == 2'd3) ? med3 : (nw == 2'd2) ? sum2[16:1] : w0;
wire        dok  = (nw != 2'd0);
wire        on_t = aimed && (settle == 16'd0);
wire        push = dist_stb && en && trk_held && on_t && trusted;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        aim_x <= CX; aim_y <= CY; aim_go <= 1'b0;
        aimed <= 1'b0; settle <= 16'd0; fresh <= 16'd0;
        nw <= 2'd0; w0 <= 16'd0; w1 <= 16'd0; w2 <= 16'd0;
        age <= 8'd255; noobj <= 8'd0;
    end else begin
        aim_go <= 1'b0;

        if (ms_tick) begin
            if (settle != 16'd0) settle <= settle - 16'd1;
            if (fresh != 16'hFFFF) fresh <= fresh + 16'd1;
        end

        if (push) begin
            w2 <= w1; w1 <= w0; w0 <= dist_mm;
            if (nw != 2'd3) nw <= nw + 2'd1;
            fresh <= 16'd0;
            age   <= 8'd0;
        end else if (fresh >= FRESH_MS)
            nw <= 2'd0;                 // stale window -> '?'

        // Below the push: a new track / big slew / lost track on the same
        // clock as a reading wins, because that reading was aimed elsewhere.
        if (frame_edge) begin
            if (!push)
                age <= (nw == 2'd0) ? 8'd255 : (age == 8'd255) ? age : age + 8'd1;

            if (!en) begin
                aim_x <= CX; aim_y <= CY; aim_go <= 1'b1;
                aimed <= 1'b0; nw <= 2'd0; noobj <= 8'd0;
            end else if (trk_held) begin
                noobj <= 8'd0;
                if (f_move) begin
                    aim_x <= cx; aim_y <= cy; aim_go <= 1'b1;
                    aimed <= 1'b1;
                end
                if (f_slew) begin
                    settle <= SETTLE_MS;
                    nw     <= 2'd0;
                    age    <= 8'd255;
                end
            end else begin
                aimed <= 1'b0;
                nw    <= 2'd0;
                age   <= 8'd255;
                if (noobj != 8'd255) noobj <= noobj + 8'd1;
                if (noobj >= PARK_FR) begin
                    aim_x <= CX; aim_y <= CY; aim_go <= 1'b1;
                end
            end
        end
    end
end

//---------------------------------------------------------------------------
// Frame sequencer: snapshot -> sizes -> BCD -> publish
//---------------------------------------------------------------------------
localparam [2:0] F_IDLE = 3'd0, F_MUL = 3'd1, F_BCD = 3'd2, F_PUB = 3'd3;

reg [2:0]  cs;
reg        sv, sok, saim, s_en;
reg [11:0] sx0, sx1, sy0, sy1;
reg [15:0] sd;
reg [7:0]  sage;
reg [15:0] vw, vh;
reg [15:0] bd, bw, bh;
reg [7:0]  alarm_cnt;

reg [1:0]  ustep;                       // 0: D*KQ  1: *span_x -> W  2: *span_y -> H
reg        urun;
reg [33:0] m_a, m_acc, m_p;
reg [12:0] m_b;

reg [1:0]  kv;
reg [13:0] bb;
reg [15:0] bcd;
reg [3:0]  bk;

wire [15:0] bcd_adj = { (bcd[15:12] >= 4'd5) ? bcd[15:12] + 4'd3 : bcd[15:12],
                        (bcd[11:8]  >= 4'd5) ? bcd[11:8]  + 4'd3 : bcd[11:8],
                        (bcd[7:4]   >= 4'd5) ? bcd[7:4]   + 4'd3 : bcd[7:4],
                        (bcd[3:0]   >= 4'd5) ? bcd[3:0]   + 4'd3 : bcd[3:0] };

wire [15:0] k_val = (kv == 2'd0) ? sd : (kv == 2'd1) ? vw : vh;
wire [13:0] k_src = (k_val > 16'd9999) ? 14'd9999 : k_val[13:0];

// D_OFS applied and clamped to 1..8191 so the product stays in 34 bits.
wire signed [17:0] u_dcs = $signed({2'b00, sd}) + D_OFS_MM;
wire        [12:0] u_dc  = (u_dcs < 1) ? 13'd1 : (u_dcs > 8191) ? 13'd8191 : u_dcs[12:0];
wire        [11:0] spx   = (sx1 > sx0) ? (sx1 - sx0) : 12'd0;
wire        [11:0] spy   = (sy1 > sy0) ? (sy1 - sy0) : 12'd0;
wire        [15:0] u_res = m_acc[RSH+15:RSH];

wire [7:0] al_next = !s_en               ? 8'd0       :
                     sv                  ? ALARM_HOLD :
                     (alarm_cnt != 8'd0) ? alarm_cnt - 8'd1 : 8'd0;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        cs <= F_IDLE;
        sv <= 1'b0; sok <= 1'b0; saim <= 1'b0; s_en <= 1'b0;
        sx0 <= 12'd0; sx1 <= 12'd0; sy0 <= 12'd0; sy1 <= 12'd0;
        sd <= 16'd0; sage <= 8'd255;
        vw <= 16'd0; vh <= 16'd0; bd <= 16'd0; bw <= 16'd0; bh <= 16'd0;
        alarm_cnt <= 8'd0;
        ustep <= 2'd0; urun <= 1'b0;
        m_a <= 34'd0; m_acc <= 34'd0; m_p <= 34'd0; m_b <= 13'd0;
        kv <= 2'd0; bb <= 14'd0; bcd <= 16'd0; bk <= 4'd0;
        lb_px0 <= 12'd0; lb_py0 <= 12'd0; lb_valid <= 1'b0; lb_dok <= 1'b0;
        lb_aim <= 1'b0; lb_d_bcd <= 16'd0; lb_w_bcd <= 16'd0; lb_h_bcd <= 16'd0;
        alarm <= 1'b0;
        res_rec <= 128'd0; res_seq <= 8'd0; res_stb <= 1'b0;
    end else begin
        res_stb <= 1'b0;

        case (cs)
        F_IDLE: if (frame_edge) begin
            s_en <= en;
            sv   <= en && box_v;
            sok  <= en && trk_held && dok;
            saim <= en && trk_held && on_t;
            sd   <= (en && trk_held && dok) ? dmed : 16'd0;
            sage <= (en && trk_held) ? age : 8'd255;
            sx0 <= bx0; sx1 <= bx1; sy0 <= by0; sy1 <= by1;
            ustep <= 2'd0; urun <= 1'b0;
            cs <= F_MUL;
        end

        // Sizes, for a trusted distance only.
        F_MUL: begin
            if (!sok) begin
                vw <= 16'd0; vh <= 16'd0;
                kv <= 2'd0; bk <= 4'd0; cs <= F_BCD;
            end else if (!urun) begin
                case (ustep)
                2'd0:    begin m_a <= KQ;  m_b <= u_dc;         m_acc <= 34'd0; end
                2'd1:    begin m_a <= m_p; m_b <= {1'b0, spx}; m_acc <= 34'd1 << (RSH - 1); end
                default: begin m_a <= m_p; m_b <= {1'b0, spy}; m_acc <= 34'd1 << (RSH - 1); end
                endcase
                urun <= 1'b1;
            end else if (m_b != 13'd0) begin
                if (m_b[0]) m_acc <= m_acc + m_a;
                m_a <= {m_a[32:0], 1'b0};
                m_b <= {1'b0, m_b[12:1]};
            end else begin
                urun <= 1'b0;
                case (ustep)
                2'd0:    m_p <= m_acc;
                2'd1:    vw  <= u_res;
                default: begin
                    vh <= u_res;
                    kv <= 2'd0; bk <= 4'd0; cs <= F_BCD;
                end
                endcase
                ustep <= ustep + 2'd1;
            end
        end

        // Three numbers, 14 shifts each.
        F_BCD: begin
            if (bk == 4'd0) begin
                bb <= k_src; bcd <= 16'd0; bk <= 4'd1;
            end else begin
                bcd <= {bcd_adj[14:0], bb[13]};
                bb  <= {bb[12:0], 1'b0};
                if (bk == 4'd14) begin
                    bk <= 4'd0;
                    case (kv)
                    2'd0:    bd <= {bcd_adj[14:0], bb[13]};
                    2'd1:    bw <= {bcd_adj[14:0], bb[13]};
                    default: bh <= {bcd_adj[14:0], bb[13]};
                    endcase
                    if (kv == 2'd2) cs <= F_PUB;
                    kv <= kv + 2'd1;
                end else
                    bk <= bk + 4'd1;
            end
        end

        default: begin                  // F_PUB: everything on one clock
            lb_px0   <= sx0;
            lb_py0   <= sy0;
            lb_valid <= sv;
            lb_dok   <= sok;
            lb_aim   <= saim;
            lb_d_bcd <= bd;
            lb_w_bcd <= bw;
            lb_h_bcd <= bh;
            alarm     <= (al_next != 8'd0);
            alarm_cnt <= al_next;
            res_rec <= { sv, sok, saim, (al_next != 8'd0), 4'd0,
                         sx0, sx1, sy0, sy1,
                         sd, vw, vh, sage, 16'd0 };
            res_seq <= res_seq + 8'd1;
            res_stb <= 1'b1;
            cs <= F_IDLE;
        end
        endcase
    end
end

endmodule
