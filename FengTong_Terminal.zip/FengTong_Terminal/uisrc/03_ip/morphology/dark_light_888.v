//---------------------------------------------------------------------------
// dark_light_888 -- selective shadow/midtone lift, 3x3 aware.
//
// Ported from the competition project's dark_light_enhancement (RGB565,
// 74.25MHz).  Three changes were forced by this board, and one more came out
// of the 2026-08-10 bench test.
//
//   1. RGB888 in and out.  The original expanded 5/6-bit channels to 8 bits
//      with bit replication and squeezed the result back down; here the data
//      is already 8-bit per channel, so both conversions are gone.
//
//   2. The luma maths is restructured.  The original ran 77*R + 150*G + 29*B
//      on all nine pixels -- 27 multiplies.  On this part that is either 27
//      DSPs or a very wide LUT tree, and the DSPs are wanted by the pixel
//      path.  Luma is linear in R/G/B, so summing the eight surrounding
//      channels first and weighting once is algebraically the same answer:
//          SUM(y_i) = 77*SUM(r_i) + 150*SUM(g_i) + 29*SUM(b_i)
//      That is 2 weighted sums instead of 9, all shift-and-add, no DSP.  It
//      is also slightly more accurate, since the original truncated each y_i
//      to 8 bits before summing.  77+150+29 = 256 exactly, so the >>8
//      normalisation is lossless.
//
//   3. Four pipeline stages instead of two.  The original had a comfortable
//      13.5ns period; here it is 6.666ns with about 0.1ns of setup slack, so
//      the adder tree, the weighting, the gain lookup and the gain multiply
//      each get their own stage.
//
//   4. 2026-08-10: THE GAIN IS NOW CONTINUOUS.  The original picked one of
//      three discrete gains -- 1.5x below luma 64, 1.25x below 130, 1.0x
//      above -- and skipped anything it judged to be an edge.  On a 1080p
//      camera frame that produces exactly what the bench photo showed:
//
//        * a large flat region falls entirely inside one gain band, so every
//          pixel in it is scaled by the same number and the local contrast
//          that survives is only what the sensor noise carries.  Two adjacent
//          bands then meet along a hard contour.  That is the "oil painting"
//          look, and no amount of moving the two limits fixes it -- the
//          quantisation is the artefact.
//        * a pixel judged to be an edge got 1.0x while its neighbour two
//          codes away got 1.5x, which draws a bright rim around every object.
//
//      Now the gain is  1 + k/32  with k running 0..16 in unit steps, taken
//      straight off the centre luma: k = (LIFT_LIMIT - y) >> 3, clipped at
//      zero.  Seventeen levels instead of three, a step of 3.1% instead of
//      25%, so a band edge moves an output code by at most 2 -- below what is
//      visible on a noisy frame.  The endpoints are unchanged from the
//      original intent: 1.5x at black, 1.25x at luma 64, 1.0x at LIFT_LIMIT.
//
//      Edges are attenuated rather than excluded (k>>1) and EDGE_THRESHOLD
//      moved 20 -> 40.  Skipping edges outright is what drew the rim; halving
//      the lift still keeps texture contrast, which was the point of the rule,
//      without the discontinuity.  40 is also a saner threshold on an 8-bit
//      scale -- at 20 a large fraction of an ordinary frame reads as "edge".
//
//      Still no multiplier.  k splits into k[4:1] and k[0]:
//          v*k/32 = v*k_hi/16 + v*k_lo/32
//      and v*k_hi/16 for k_hi = 0..8 is a nine-way choice between sums of at
//      most three right-shifts of v.  Shift-and-add throughout, no DSP.
//
// Timing contract: FOUR internal register stages, then a combinational
// result.  The parent registers the mux output, giving the same 5-deep path
// as the erode/dilate branch so the two stay aligned.  (It was 2+1 before the
// gain curve went in; morphology_5x5 was re-timed to match.)
//
// Every stage free-runs -- there is no valid enable.  Gating the stages on
// href looks tidier but drops pixels: when href falls the last two pixels of
// the line are still inside the pipeline, and freezing it strands them so
// they surface on the next line.  Matrix_Generate_5X5_8Bit free-runs for the
// same reason.  Whatever comes through during blanking is masked downstream
// by the delayed de.
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module dark_light_888 #(
// |centre - surround| above this counts as an edge and gets half the lift.
parameter [7:0] EDGE_THRESHOLD = 8'd40,
// Luma at or above this gets no lift at all.  Pinned to 128 by the >>3 that
// derives k: (128 - 0) >> 3 = 16 = K_MAX exactly.  Moving it means moving the
// shift too, and keeping (LIFT_LIMIT >> SHIFT) == K_MAX.
parameter [8:0] LIFT_LIMIT     = 9'd128,
parameter [4:0] K_MAX          = 5'd16    // gain = 1 + K/32, so 16 -> 1.5x
)(
input  wire        clk,
input  wire        rst_n,

// 3x3 window, each entry {R,G,B}.  p11 is the centre.
input  wire [23:0] p00, p01, p02,
input  wire [23:0] p10, p11, p12,
input  wire [23:0] p20, p21, p22,

output wire [7:0]  r_out,
output wire [7:0]  g_out,
output wire [7:0]  b_out
);

//-------------------------------------------------------------------
// Stage 1 : sum the eight surrounding pixels per channel, hold the centre
//-------------------------------------------------------------------
wire [10:0] sum_r_c = {3'b0, p00[23:16]} + {3'b0, p01[23:16]} + {3'b0, p02[23:16]}
                    + {3'b0, p10[23:16]} + {3'b0, p12[23:16]}
                    + {3'b0, p20[23:16]} + {3'b0, p21[23:16]} + {3'b0, p22[23:16]};
wire [10:0] sum_g_c = {3'b0, p00[15:8]}  + {3'b0, p01[15:8]}  + {3'b0, p02[15:8]}
                    + {3'b0, p10[15:8]}  + {3'b0, p12[15:8]}
                    + {3'b0, p20[15:8]}  + {3'b0, p21[15:8]}  + {3'b0, p22[15:8]};
wire [10:0] sum_b_c = {3'b0, p00[7:0]}   + {3'b0, p01[7:0]}   + {3'b0, p02[7:0]}
                    + {3'b0, p10[7:0]}   + {3'b0, p12[7:0]}
                    + {3'b0, p20[7:0]}   + {3'b0, p21[7:0]}   + {3'b0, p22[7:0]};

reg [10:0] s1_sum_r, s1_sum_g, s1_sum_b;
reg [7:0]  s1_cr, s1_cg, s1_cb;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        s1_sum_r <= 11'd0; s1_sum_g <= 11'd0; s1_sum_b <= 11'd0;
        s1_cr    <= 8'd0;  s1_cg    <= 8'd0;  s1_cb    <= 8'd0;
    end else begin
        s1_sum_r <= sum_r_c;    s1_sum_g <= sum_g_c;  s1_sum_b <= sum_b_c;
        s1_cr    <= p11[23:16]; s1_cg    <= p11[15:8]; s1_cb   <= p11[7:0];
    end
end

//-------------------------------------------------------------------
// Stage 2 : weight to luma.  77 = 64+8+4+1, 150 = 128+16+4+2, 29 = 16+8+4+1,
// all shift-and-add so nothing lands in a DSP.
//-------------------------------------------------------------------
// The surrounding sums are 11-bit, so 150*sum needs 19 bits and the total 20.
wire [19:0] sr = {9'b0, s1_sum_r};
wire [19:0] sg = {9'b0, s1_sum_g};
wire [19:0] sb = {9'b0, s1_sum_b};

wire [19:0] y_sum_sur = ((sr << 6) + (sr << 3) + (sr << 2) + sr)        // 77  * sum_r
                      + ((sg << 7) + (sg << 4) + (sg << 2) + (sg << 1)) // 150 * sum_g
                      + ((sb << 4) + (sb << 3) + (sb << 2) + sb);       // 29  * sum_b

// >>8 undoes the weights, >>3 averages the eight pixels: bits [18:11].
wire [7:0] y_avg_c = y_sum_sur[18:11];

wire [15:0] cr = {8'b0, s1_cr};
wire [15:0] cg = {8'b0, s1_cg};
wire [15:0] cb = {8'b0, s1_cb};

wire [15:0] y_ctr_sum = ((cr << 6) + (cr << 3) + (cr << 2) + cr)
                      + ((cg << 7) + (cg << 4) + (cg << 2) + (cg << 1))
                      + ((cb << 4) + (cb << 3) + (cb << 2) + cb);
wire [7:0] y_ctr_c = y_ctr_sum[15:8];

reg [7:0] s2_y_avg, s2_y_ctr;
reg [7:0] s2_cr, s2_cg, s2_cb;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        s2_y_avg <= 8'd0; s2_y_ctr <= 8'd0;
        s2_cr    <= 8'd0; s2_cg    <= 8'd0; s2_cb <= 8'd0;
    end else begin
        s2_y_avg <= y_avg_c; s2_y_ctr <= y_ctr_c;
        s2_cr    <= s1_cr;   s2_cg    <= s1_cg;   s2_cb <= s1_cb;
    end
end

//-------------------------------------------------------------------
// Stage 3 : the gain index.  k = (LIFT_LIMIT - y) >> 3, 0 above the limit,
// halved on an edge.  One subtract, one shift, two compares, one mux.
//-------------------------------------------------------------------
wire [7:0] luma_diff = (s2_y_ctr > s2_y_avg) ? (s2_y_ctr - s2_y_avg)
                                             : (s2_y_avg - s2_y_ctr);
wire is_edge = (luma_diff > EDGE_THRESHOLD);

wire [8:0] y_ext     = {1'b0, s2_y_ctr};
wire [8:0] head_room = (y_ext < LIFT_LIMIT) ? (LIFT_LIMIT - y_ext) : 9'd0;

wire [5:0] k_raw   = head_room[8:3];                        // 0 .. 16
wire [4:0] k_clip  = (k_raw > {1'b0, K_MAX}) ? K_MAX : k_raw[4:0];
wire [4:0] k_final = is_edge ? {1'b0, k_clip[4:1]} : k_clip;

reg [4:0] s3_k;
reg [7:0] s3_cr, s3_cg, s3_cb;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        s3_k  <= 5'd0;
        s3_cr <= 8'd0; s3_cg <= 8'd0; s3_cb <= 8'd0;
    end else begin
        s3_k  <= k_final;
        s3_cr <= s2_cr; s3_cg <= s2_cg; s3_cb <= s2_cb;
    end
end

//-------------------------------------------------------------------
// Stage 4 : the lift itself, v*k/32, entirely in shifts.
//   k = 2*k_hi + k_lo  ->  v*k/32 = v*k_hi/16 + v*k_lo/32
// and v*k_hi/16 for k_hi = 0..8 is one of nine sums of right-shifts.
//-------------------------------------------------------------------
function [8:0] lift;
    input [7:0] v;
    input [4:0] k;
    reg   [8:0] a, b, c, d, e, hi;
    begin
        a  = {5'b0, v[7:4]};        // v/16
        b  = {4'b0, v[7:3]};        // v/8
        c  = {3'b0, v[7:2]};        // v/4
        d  = {2'b0, v[7:1]};        // v/2
        e  = {6'b0, v[7:5]};        // v/32
        case (k[4:1])               // k_hi, 0..8
            4'd1:    hi = a;
            4'd2:    hi = b;
            4'd3:    hi = b + a;
            4'd4:    hi = c;
            4'd5:    hi = c + a;
            4'd6:    hi = c + b;
            4'd7:    hi = c + b + a;
            4'd8:    hi = d;
            default: hi = 9'd0;     // k_hi == 0
        endcase
        lift = k[0] ? (hi + e) : hi;
    end
endfunction

reg [8:0] s4_dr, s4_dg, s4_db;
reg [7:0] s4_cr, s4_cg, s4_cb;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        s4_dr <= 9'd0; s4_dg <= 9'd0; s4_db <= 9'd0;
        s4_cr <= 8'd0; s4_cg <= 8'd0; s4_cb <= 8'd0;
    end else begin
        s4_dr <= lift(s3_cr, s3_k);
        s4_dg <= lift(s3_cg, s3_k);
        s4_db <= lift(s3_cb, s3_k);
        s4_cr <= s3_cr; s4_cg <= s3_cg; s4_cb <= s3_cb;
    end
end

//-------------------------------------------------------------------
// Combinational result -- the parent registers it.  Ten bits wide so the
// carry survives to be clipped; the original declared this 8-bit and then
// tested "> 255", a comparison that can never be true on an 8-bit value, so
// its saturation was dead code and a lifted midtone wrapped round to black.
//-------------------------------------------------------------------
function [7:0] add_sat;
    input [7:0] v;
    input [8:0] delta;
    reg   [9:0] w;
    begin
        w       = {2'b0, v} + {1'b0, delta};
        add_sat = (w > 10'd255) ? 8'd255 : w[7:0];
    end
endfunction

assign r_out = add_sat(s4_cr, s4_dr);
assign g_out = add_sat(s4_cg, s4_dg);
assign b_out = add_sat(s4_cb, s4_db);

endmodule
