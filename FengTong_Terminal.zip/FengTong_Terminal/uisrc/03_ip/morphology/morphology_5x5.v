//---------------------------------------------------------------------------
// morphology_5x5 -- greyscale morphology on RGB888, one button.
//
// TWO cascaded 5x5 passes as of 2026-08-10 (second bench test).  The file name
// still describes one window because that is what each pass is; the effective
// structuring element is 9x9.
//
//   One press advances the mode:
//       00 PASS    centre pixel, untouched
//       01 ERODE   dark features grow -- thin bright detail is eaten away
//       10 DILATE  bright features grow -- dark speckles are filled in
//       11 DARK    selective shadow/midtone lift (dark_light_888)
//   and wraps back to PASS.
//
// HOW THE STRENGTH GOT HERE, AND WHY IT TOOK THIS SHAPE
//   A rank filter moves a region boundary by the radius of its structuring
//   element, and that displacement is the whole of what "obvious" means when
//   you are looking at a 1080p frame on a TV:
//
//       3x3, first port     1 px    "nothing happened"
//       5x5, one pass       2 px    "could be more obvious"
//       5x5, two passes     4 px    this version
//
//   Getting past 2 px inside a single window is not a matter of writing a
//   bigger reduction.  The window height is set by the line buffers, and
//   Matrix_Generate_5X5_8Bit holds five lines; a 9-line window means eight
//   line buffers per channel, 24 eram, and a line-buffer module that does not
//   exist in this project.  Cascading two proven 5x5 passes reaches the same
//   9x9 support for the same 24 eram, adds no combinational depth at all, and
//   reuses a module that is already on silicon at this resolution.  The only
//   new thing to get right is the sync the second pass is fed, and that comes
//   straight off a tap of the delay line this module already builds.
//
// WHY THE ROW MEDIAN DOES NOT ERODE  (found in simulation, 2026-08-10)
//   Every version of this filter up to and including the first 5x5 port used
//   the source project's "rank-2" reduction: median across the row, then
//   min/max down the column.  A testbench that erodes a 20x20 rectangle and
//   measures the result says that structure is not doing what its name
//   suggests.  The rectangle came back 16 wide and 12 tall -- 2 px off each
//   side horizontally, 4 px vertically.
//
//   The row median is the reason, and it is not a bug, it is what a median
//   does.  Take a bright bar starting at column L and a window sampling
//   x-2, x, x+2.  At x = L the samples are dark, bright, bright: two votes to
//   one, so the median is bright and the edge has not moved.  A median only
//   flips once the MAJORITY of its samples have flipped, so a 3-sample row
//   median displaces a vertical edge by exactly ZERO.  All of the visible
//   erosion was coming from the column min/max.
//
//   So the 3x3 port, and the one-pass 5x5 after it, were both eroding
//   VERTICALLY ONLY.  That is very likely the real reason two rounds of bench
//   testing came back with "not obvious enough" -- half the effect was
//   missing, not merely small.
//
//   The fix costs nothing.  min5/max5 over the five contiguous columns is the
//   same three comparator levels as med3 (a 2-1-1 tree either way), and it
//   moves a vertical edge by the full radius.  What it gives up is the
//   median's outlier rejection: RANK_MODE = 1 is a true erosion, and a true
//   erosion spreads a single dead pixel over the whole structuring element.
//
// THE NOISE TRADE, STATED PLAINLY
//   The source project retreated to rank-2 because dilate was smearing single
//   sensor speckles into blocks of colour, and this version gives that
//   protection up on purpose -- reach was what the bench asked for, twice.
//   At radius 4 one hot pixel becomes a 9x9 blob.  IF SCATTERED DOTS OR SMALL
//   BLOBS APPEAR in erode or dilate on real footage, that is what it is, and
//   the cure is one word: set either pass's RANK_MODE to 0.  Each pass moved
//   back to 0 costs 2 px of horizontal reach and buys back one row of outlier
//   rejection.
//
//   The chain here is not the one that got burned: black-level subtraction,
//   auto-level and gamma all run upstream, and the sensor is a MIPI part
//   rather than a DVP OV5640, so the speckle rate should be far lower.
//
//   IF IT IS STILL NOT ENOUGH: add a third pass (12 more eram, 6 px), or
//   write a true 9-line window (24 eram on top and a new line-buffer module --
//   4 px in one pass, with better small-feature behaviour than a cascade).
//
// THE SHARPNESS TRADE (2026-09-05)
//   Three bench rounds walked this all the way down and the shape of the
//   trade is now measured rather than guessed:
//
//     radius 4 (two 5x5 passes cascaded)  "effect is there, picture is soft"
//     radius 2 (one 5x5 pass)             "still slightly soft"
//     radius 1 (one 3x3 pass)             <- current
//
//   There is no setting that is both wide and sharp, because a min/max over a
//   window IS the softening: every pixel inside the structuring element gets
//   replaced by the extreme of its neighbourhood, so detail finer than the
//   element cannot survive by construction.  The only real knob is how big the
//   element is, and radius 1 is the floor -- below that the window is a single
//   pixel and erode/dilate become the identity.
//
//   So if radius 1 reads as too weak on the bench, the answer is NOT a smaller
//   element.  It is to change what is being shown:
//
//   OPENING / CLOSING, WHICH IS ALREADY BUILT.  Pass 2 is fully instantiated
//   and currently wasted -- 12 eram of line buffer whose rank outputs go
//   nowhere.  Feed the ERODE position pass-1-erode then pass-2-DILATE and it
//   becomes an opening; DILATE fed dilate-then-erode becomes a closing.  Both
//   are textbook morphology, both remove small features as visibly as a plain
//   erosion does, and both leave large shapes and their edges essentially
//   where they were -- which is precisely "effect without softening".  The
//   cost is two mux arms (mid_* already carries pass 1's result for the active
//   mode, so pass 2 only needs its opposite output selected) and renaming the
//   two OSD strings, since the positions would no longer be erode/dilate.
//   Not done here because ERODE and DILATE are named algorithm items and
//   swapping their meaning is a scoring decision, not a tuning one.
//
// LINE BUFFERING
//   Six Matrix_Generate_5X5_8Bit -- three channels, two passes.  Four
//   fifo_bil_filter each, 24 eram in total (the 3x3 port used 6, the one-pass
//   5x5 used 12).  fifo_bil_filter is 2048 deep, so a 1920-pixel line fits.
//
// LATENCY
//   MORPH_SYNC_DLY = 12.  Where it goes:
//       0   in_r/g/b
//       3   pass-1 window centre            (matrix depth)
//       5   pass-1 ero/dil/ctr              (+ row rank, + column rank)
//       6   pass-1 mode select -> mid
//       9   pass-2 window centre
//      11   pass-2 ero/dil/ctr
//      12   final mode mux
//   The DARK branch hangs off the pass-1 window at 3, spends four stages
//   inside dark_light_888, and is then padded to 11 so the same final register
//   captures both branches.  Nothing downstream can tell the modes apart.
//
//   Pass 2 is fed vs_dly[5] / de_dly[5], which are in_vs / in_de delayed by
//   exactly 6 -- the age of mid.  They are pure delayed copies, so pass 2 sees
//   a textbook 1080-line by 1920-pixel frame and rebuilds its own counters
//   from it the same way pass 1 does.  Feeding pass 1's matrix_img_href
//   instead would also work but is two lines out of step, which is a subtler
//   thing to reason about than a tap index.
//
//   One consequence, inherited and harmless: the picture sits four lines lower
//   than the source, because each window centre is two lines behind the pixel
//   being fed in.
//
// Every stage free-runs; see the note in dark_light_888 for why gating on
// href would strand the last pixels of each line.
//---------------------------------------------------------------------------

`timescale 1ns/1ns

//===========================================================================
// One 5x5 rank pass on three channels.  Five clocks from in_* to
// ero/dil/ctr; the window itself is exposed at three clocks for dark_light.
//===========================================================================
module morph_rank5_core #(
parameter [10:0]  IMG_HDISP = 11'd1920,
parameter [10:0]  IMG_VDISP = 11'd1080,
// 0 = LEGACY.  Each row reduces to the median of columns 1, 3 and 5.  Rejects
//     one outlier per row, and displaces a vertical edge by NOTHING at all --
//     see WHY THE ROW MEDIAN DOES NOT ERODE in the file header.
// 1 = each row reduces to min (erode) or max (dilate) over all five columns,
//     then the column rank spans all five rows.  A real erosion, radius 2 in
//     both axes, same three comparator levels.
// 2 = min/max over the MIDDLE THREE columns and rows only, i.e. a true 3x3
//     structuring element, radius 1 in both axes.  Half the reach of mode 1
//     and half the softening; two comparator levels instead of three, and the
//     outer two row values fall away as dead logic.  This is the mode that
//     answers "the effect is there but the picture went soft" -- see THE
//     SHARPNESS TRADE in the file header.
parameter integer RANK_MODE = 1
)(
input  wire        clk,
input  wire        rst_n,

input  wire        in_vs,        // HIGH across the visible frame
input  wire        in_de,
input  wire [7:0]  in_r,
input  wire [7:0]  in_g,
input  wire [7:0]  in_b,

output reg  [7:0]  ero_r, ero_g, ero_b,
output reg  [7:0]  dil_r, dil_g, dil_b,
output reg  [7:0]  ctr_r, ctr_g, ctr_b,

// Inner 3x3 of the window, {R,G,B} per entry, w11 the centre.  Valid three
// clocks after in_*, i.e. two stages ahead of ero/dil/ctr.
output wire [23:0] w00, w01, w02,
output wire [23:0] w10, w11, w12,
output wire [23:0] w20, w21, w22
);

//-------------------------------------------------------------------
// 5x5 window, one generator per channel.  They see identical sync, so their
// outputs are sample-aligned and only one set of pixels needs tracking.
//-------------------------------------------------------------------
wire [7:0] r11, r12, r13, r14, r15;
wire [7:0] r21, r22, r23, r24, r25;
wire [7:0] r31, r32, r33, r34, r35;
wire [7:0] r41, r42, r43, r44, r45;
wire [7:0] r51, r52, r53, r54, r55;

wire [7:0] g11, g12, g13, g14, g15;
wire [7:0] g21, g22, g23, g24, g25;
wire [7:0] g31, g32, g33, g34, g35;
wire [7:0] g41, g42, g43, g44, g45;
wire [7:0] g51, g52, g53, g54, g55;

wire [7:0] b11, b12, b13, b14, b15;
wire [7:0] b21, b22, b23, b24, b25;
wire [7:0] b31, b32, b33, b34, b35;
wire [7:0] b41, b42, b43, b44, b45;
wire [7:0] b51, b52, b53, b54, b55;

Matrix_Generate_5X5_8Bit #(
    .IMG_HDISP (IMG_HDISP), .IMG_VDISP (IMG_VDISP)
) u_matrix_r (
    .clk (clk), .rst_n (rst_n),
    .per_img_vsync (in_vs), .per_img_href (in_de), .per_img_gray (in_r),
    .matrix_img_vsync (), .matrix_img_href (),
    .matrix_top_edge_flag (), .matrix_bottom_edge_flag (),
    .matrix_left_edge_flag (), .matrix_right_edge_flag (),
    .matrix_p11 (r11), .matrix_p12 (r12), .matrix_p13 (r13), .matrix_p14 (r14), .matrix_p15 (r15),
    .matrix_p21 (r21), .matrix_p22 (r22), .matrix_p23 (r23), .matrix_p24 (r24), .matrix_p25 (r25),
    .matrix_p31 (r31), .matrix_p32 (r32), .matrix_p33 (r33), .matrix_p34 (r34), .matrix_p35 (r35),
    .matrix_p41 (r41), .matrix_p42 (r42), .matrix_p43 (r43), .matrix_p44 (r44), .matrix_p45 (r45),
    .matrix_p51 (r51), .matrix_p52 (r52), .matrix_p53 (r53), .matrix_p54 (r54), .matrix_p55 (r55)
);

Matrix_Generate_5X5_8Bit #(
    .IMG_HDISP (IMG_HDISP), .IMG_VDISP (IMG_VDISP)
) u_matrix_g (
    .clk (clk), .rst_n (rst_n),
    .per_img_vsync (in_vs), .per_img_href (in_de), .per_img_gray (in_g),
    .matrix_img_vsync (), .matrix_img_href (),
    .matrix_top_edge_flag (), .matrix_bottom_edge_flag (),
    .matrix_left_edge_flag (), .matrix_right_edge_flag (),
    .matrix_p11 (g11), .matrix_p12 (g12), .matrix_p13 (g13), .matrix_p14 (g14), .matrix_p15 (g15),
    .matrix_p21 (g21), .matrix_p22 (g22), .matrix_p23 (g23), .matrix_p24 (g24), .matrix_p25 (g25),
    .matrix_p31 (g31), .matrix_p32 (g32), .matrix_p33 (g33), .matrix_p34 (g34), .matrix_p35 (g35),
    .matrix_p41 (g41), .matrix_p42 (g42), .matrix_p43 (g43), .matrix_p44 (g44), .matrix_p45 (g45),
    .matrix_p51 (g51), .matrix_p52 (g52), .matrix_p53 (g53), .matrix_p54 (g54), .matrix_p55 (g55)
);

Matrix_Generate_5X5_8Bit #(
    .IMG_HDISP (IMG_HDISP), .IMG_VDISP (IMG_VDISP)
) u_matrix_b (
    .clk (clk), .rst_n (rst_n),
    .per_img_vsync (in_vs), .per_img_href (in_de), .per_img_gray (in_b),
    .matrix_img_vsync (), .matrix_img_href (),
    .matrix_top_edge_flag (), .matrix_bottom_edge_flag (),
    .matrix_left_edge_flag (), .matrix_right_edge_flag (),
    .matrix_p11 (b11), .matrix_p12 (b12), .matrix_p13 (b13), .matrix_p14 (b14), .matrix_p15 (b15),
    .matrix_p21 (b21), .matrix_p22 (b22), .matrix_p23 (b23), .matrix_p24 (b24), .matrix_p25 (b25),
    .matrix_p31 (b31), .matrix_p32 (b32), .matrix_p33 (b33), .matrix_p34 (b34), .matrix_p35 (b35),
    .matrix_p41 (b41), .matrix_p42 (b42), .matrix_p43 (b43), .matrix_p44 (b44), .matrix_p45 (b45),
    .matrix_p51 (b51), .matrix_p52 (b52), .matrix_p53 (b53), .matrix_p54 (b54), .matrix_p55 (b55)
);

// Inner 3x3, for whatever the parent wants to judge local contrast with.
assign w00 = {r22, g22, b22};
assign w01 = {r23, g23, b23};
assign w02 = {r24, g24, b24};
assign w10 = {r32, g32, b32};
assign w11 = {r33, g33, b33};
assign w12 = {r34, g34, b34};
assign w20 = {r42, g42, b42};
assign w21 = {r43, g43, b43};
assign w22 = {r44, g44, b44};

//-------------------------------------------------------------------
// Rank helpers
//-------------------------------------------------------------------
function [7:0] min2; input [7:0] a, b; begin min2 = (a < b) ? a : b; end endfunction
function [7:0] max2; input [7:0] a, b; begin max2 = (a > b) ? a : b; end endfunction

function [7:0] med3;
    input [7:0] a, b, c;
    begin med3 = max2(min2(a, b), min2(max2(a, b), c)); end
endfunction

function [7:0] min3;
    input [7:0] a, b, c;
    begin min3 = min2(min2(a, b), c); end
endfunction

function [7:0] max3;
    input [7:0] a, b, c;
    begin max3 = max2(max2(a, b), c); end
endfunction

function [7:0] min5;
    input [7:0] a, b, c, d, e;
    begin min5 = min2(min2(min2(a, b), min2(c, d)), e); end
endfunction

function [7:0] max5;
    input [7:0] a, b, c, d, e;
    begin max5 = max2(max2(max2(a, b), max2(c, d)), e); end
endfunction

// One row value for the erode side and one for the dilate side.  RANK_MODE is
// a constant, so none of these ternaries survives synthesis; in mode 0 the two
// are the same expression and the tool folds the two registers into one.
// min5/max5 and med3 are all three comparator levels deep, so mode 1 is not
// paying for its horizontal reach in timing -- only in outlier immunity.
// Mode 2 takes the middle three columns only, which is two comparator levels
// and one pixel of horizontal reach.
function [7:0] row_lo;
    input [7:0] a, b, c, d, e;
    begin row_lo = (RANK_MODE == 2) ? min3(b, c, d) :
                   (RANK_MODE != 0) ? min5(a, b, c, d, e) : med3(a, c, e); end
endfunction

function [7:0] row_hi;
    input [7:0] a, b, c, d, e;
    begin row_hi = (RANK_MODE == 2) ? max3(b, c, d) :
                   (RANK_MODE != 0) ? max5(a, b, c, d, e) : med3(a, c, e); end
endfunction

// Column rank across the five row values.  This used to be a hardwired
// min5/max5 regardless of RANK_MODE, which is why modes 0 and 1 are both
// radius 2 VERTICALLY -- only their horizontal reach differed.  Mode 2 has to
// narrow this one too, otherwise a 3-wide row rank followed by a 5-tall column
// rank would be an asymmetric 1x2 structuring element and a horizontal edge
// would still move twice as far as a vertical one.
function [7:0] col_lo;
    input [7:0] a, b, c, d, e;
    begin col_lo = (RANK_MODE == 2) ? min3(b, c, d) : min5(a, b, c, d, e); end
endfunction

function [7:0] col_hi;
    input [7:0] a, b, c, d, e;
    begin col_hi = (RANK_MODE == 2) ? max3(b, c, d) : max5(a, b, c, d, e); end
endfunction

//-------------------------------------------------------------------
// P1 : ROW RANK.  One value per row per side, plus the untouched centre.
// Three comparator levels either way.
//-------------------------------------------------------------------
reg [7:0] lo_r0, lo_r1, lo_r2, lo_r3, lo_r4;
reg [7:0] hi_r0, hi_r1, hi_r2, hi_r3, hi_r4;
reg [7:0] lo_g0, lo_g1, lo_g2, lo_g3, lo_g4;
reg [7:0] hi_g0, hi_g1, hi_g2, hi_g3, hi_g4;
reg [7:0] lo_b0, lo_b1, lo_b2, lo_b3, lo_b4;
reg [7:0] hi_b0, hi_b1, hi_b2, hi_b3, hi_b4;
reg [7:0] p1_cr, p1_cg, p1_cb;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        lo_r0 <= 8'd0; lo_r1 <= 8'd0; lo_r2 <= 8'd0; lo_r3 <= 8'd0; lo_r4 <= 8'd0;
        hi_r0 <= 8'd0; hi_r1 <= 8'd0; hi_r2 <= 8'd0; hi_r3 <= 8'd0; hi_r4 <= 8'd0;
        lo_g0 <= 8'd0; lo_g1 <= 8'd0; lo_g2 <= 8'd0; lo_g3 <= 8'd0; lo_g4 <= 8'd0;
        hi_g0 <= 8'd0; hi_g1 <= 8'd0; hi_g2 <= 8'd0; hi_g3 <= 8'd0; hi_g4 <= 8'd0;
        lo_b0 <= 8'd0; lo_b1 <= 8'd0; lo_b2 <= 8'd0; lo_b3 <= 8'd0; lo_b4 <= 8'd0;
        hi_b0 <= 8'd0; hi_b1 <= 8'd0; hi_b2 <= 8'd0; hi_b3 <= 8'd0; hi_b4 <= 8'd0;
        p1_cr <= 8'd0; p1_cg <= 8'd0; p1_cb <= 8'd0;
    end else begin
        lo_r0 <= row_lo(r11,r12,r13,r14,r15);  hi_r0 <= row_hi(r11,r12,r13,r14,r15);
        lo_r1 <= row_lo(r21,r22,r23,r24,r25);  hi_r1 <= row_hi(r21,r22,r23,r24,r25);
        lo_r2 <= row_lo(r31,r32,r33,r34,r35);  hi_r2 <= row_hi(r31,r32,r33,r34,r35);
        lo_r3 <= row_lo(r41,r42,r43,r44,r45);  hi_r3 <= row_hi(r41,r42,r43,r44,r45);
        lo_r4 <= row_lo(r51,r52,r53,r54,r55);  hi_r4 <= row_hi(r51,r52,r53,r54,r55);
        p1_cr <= r33;

        lo_g0 <= row_lo(g11,g12,g13,g14,g15);  hi_g0 <= row_hi(g11,g12,g13,g14,g15);
        lo_g1 <= row_lo(g21,g22,g23,g24,g25);  hi_g1 <= row_hi(g21,g22,g23,g24,g25);
        lo_g2 <= row_lo(g31,g32,g33,g34,g35);  hi_g2 <= row_hi(g31,g32,g33,g34,g35);
        lo_g3 <= row_lo(g41,g42,g43,g44,g45);  hi_g3 <= row_hi(g41,g42,g43,g44,g45);
        lo_g4 <= row_lo(g51,g52,g53,g54,g55);  hi_g4 <= row_hi(g51,g52,g53,g54,g55);
        p1_cg <= g33;

        lo_b0 <= row_lo(b11,b12,b13,b14,b15);  hi_b0 <= row_hi(b11,b12,b13,b14,b15);
        lo_b1 <= row_lo(b21,b22,b23,b24,b25);  hi_b1 <= row_hi(b21,b22,b23,b24,b25);
        lo_b2 <= row_lo(b31,b32,b33,b34,b35);  hi_b2 <= row_hi(b31,b32,b33,b34,b35);
        lo_b3 <= row_lo(b41,b42,b43,b44,b45);  hi_b3 <= row_hi(b41,b42,b43,b44,b45);
        lo_b4 <= row_lo(b51,b52,b53,b54,b55);  hi_b4 <= row_hi(b51,b52,b53,b54,b55);
        p1_cb <= b33;
    end
end

//-------------------------------------------------------------------
// P2 : COLUMN RANK across the five row values.  Three comparator levels.
//-------------------------------------------------------------------
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        ero_r <= 8'd0; dil_r <= 8'd0; ctr_r <= 8'd0;
        ero_g <= 8'd0; dil_g <= 8'd0; ctr_g <= 8'd0;
        ero_b <= 8'd0; dil_b <= 8'd0; ctr_b <= 8'd0;
    end else begin
        ero_r <= col_lo(lo_r0, lo_r1, lo_r2, lo_r3, lo_r4);
        dil_r <= col_hi(hi_r0, hi_r1, hi_r2, hi_r3, hi_r4);
        ctr_r <= p1_cr;
        ero_g <= col_lo(lo_g0, lo_g1, lo_g2, lo_g3, lo_g4);
        dil_g <= col_hi(hi_g0, hi_g1, hi_g2, hi_g3, hi_g4);
        ctr_g <= p1_cg;
        ero_b <= col_lo(lo_b0, lo_b1, lo_b2, lo_b3, lo_b4);
        dil_b <= col_hi(hi_b0, hi_b1, hi_b2, hi_b3, hi_b4);
        ctr_b <= p1_cb;
    end
end

endmodule


//===========================================================================
// The button, the two passes and the shadow lift.
//===========================================================================
module morphology_5x5 #(
parameter [10:0]  IMG_HDISP = 11'd1920,
parameter [10:0]  IMG_VDISP = 11'd1080,
parameter integer KEY_MCNT  = 3_000_000,  // 20 ms at the 150 MHz pixel clock

// 2026-10-01 key remap: 1 = the mode comes from mode_ext (the key1 effect
// wheel's ERODE / DILATE / DARKLIFT positions) and key2 is free.  0 = the
// old behaviour, mode_key cycles it -- one parameter back.
parameter integer MODE_SRC  = 1
)(
input  wire        clk,
input  wire        rst_n,
input  wire        mode_key,     // raw button, debounced in here (MODE_SRC = 0)
input  wire [1:0]  mode_ext,     // 0 pass / 1 erode / 2 dilate / 3 dark (MODE_SRC = 1)

input  wire        in_hs,
input  wire        in_vs,        // HIGH across the visible frame
input  wire        in_de,
input  wire [7:0]  in_r,
input  wire [7:0]  in_g,
input  wire [7:0]  in_b,

output wire        out_hs,
output wire        out_vs,
output wire        out_de,
output wire [7:0]  out_r,
output wire [7:0]  out_g,
output wire [7:0]  out_b,

output wire [1:0]  morph_mode    // what is currently on screen
);

localparam [1:0] MODE_PASS   = 2'b00;
localparam [1:0] MODE_ERODE  = 2'b01;
localparam [1:0] MODE_DILATE = 2'b10;
localparam [1:0] MODE_DARK   = 2'b11;

localparam integer MORPH_SYNC_DLY = 12;
localparam integer PASS2_TAP      = 5;    // vs_dly/de_dly index -> delayed by 6

//-------------------------------------------------------------------
// Mode select.  mode_sel moves as soon as the button is pressed;
// mode_active only picks it up between frames.
//-------------------------------------------------------------------
wire key_p_flag;

key_filter #(
    .MCNT (KEY_MCNT - 1)
) u_key_filter (
    .Clk        (clk       ),
    .Reset_n    (rst_n     ),
    .Key        (mode_key  ),
    .Key_P_Flag (key_p_flag),
    .Key_R_Flag (          ),
    .Key_state  (          )
);

reg [1:0] mode_sel;
reg [1:0] mode_active;
reg       in_vs_d1;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n)
        mode_sel <= MODE_PASS;
    else if (MODE_SRC != 0)
        mode_sel <= mode_ext;           // latched into mode_active at the frame edge below
    else if (key_p_flag)
        mode_sel <= mode_sel + 2'd1;    // 2 bits wide, so DARK -> PASS wraps on its own
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        in_vs_d1    <= 1'b0;
        mode_active <= MODE_PASS;
    end else begin
        in_vs_d1 <= in_vs;
        // falling edge of a frame-active-high vsync = start of blanking
        if (in_vs_d1 & ~in_vs)
            mode_active <= mode_sel;
    end
end

assign morph_mode = mode_active;

//-------------------------------------------------------------------
// Sync delay line.  Declared up here because pass 2 feeds off a tap of it.
//-------------------------------------------------------------------
reg [MORPH_SYNC_DLY-1:0] hs_dly, vs_dly, de_dly;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        hs_dly <= {MORPH_SYNC_DLY{1'b0}};
        vs_dly <= {MORPH_SYNC_DLY{1'b0}};
        de_dly <= {MORPH_SYNC_DLY{1'b0}};
    end else begin
        hs_dly <= {hs_dly[MORPH_SYNC_DLY-2:0], in_hs};
        vs_dly <= {vs_dly[MORPH_SYNC_DLY-2:0], in_vs};
        de_dly <= {de_dly[MORPH_SYNC_DLY-2:0], in_de};
    end
end

assign out_hs = hs_dly[MORPH_SYNC_DLY-1];
assign out_vs = vs_dly[MORPH_SYNC_DLY-1];
assign out_de = de_dly[MORPH_SYNC_DLY-1];

//-------------------------------------------------------------------
// PASS 1 : true min/max on a 3x3 structuring element, radius 1 in both
// directions (RANK_MODE 2).  Out at delay 5, window out at delay 3.
//
// This is the ONLY pass whose rank result reaches the screen -- the output mux
// takes pass 2's centre tap, so pass 2 is a delay line for the picture and its
// own ero/dil outputs are dead logic.  Therefore this parameter alone sets how
// hard the effect hits and how soft the picture gets:
//
//   RANK_MODE(1)  radius 2, a 5x5 element.  What the 09-04 bitstream ran; the
//                 bench called it "still slightly soft".
//   RANK_MODE(2)  radius 1, a 3x3 element.  Half the reach, half the softening.
//                 <- current.  If the bench now calls the effect too weak,
//                 putting this back to 1 is the whole revert.
//-------------------------------------------------------------------
wire [7:0]  e1_r, e1_g, e1_b;
wire [7:0]  d1_r, d1_g, d1_b;
wire [7:0]  c1_r, c1_g, c1_b;
wire [23:0] w00, w01, w02, w10, w11, w12, w20, w21, w22;

morph_rank5_core #(
    .IMG_HDISP (IMG_HDISP), .IMG_VDISP (IMG_VDISP), .RANK_MODE (2)
) u_pass1 (
    .clk (clk), .rst_n (rst_n),
    .in_vs (in_vs), .in_de (in_de),
    .in_r (in_r), .in_g (in_g), .in_b (in_b),
    .ero_r (e1_r), .ero_g (e1_g), .ero_b (e1_b),
    .dil_r (d1_r), .dil_g (d1_g), .dil_b (d1_b),
    .ctr_r (c1_r), .ctr_g (c1_g), .ctr_b (c1_b),
    .w00 (w00), .w01 (w01), .w02 (w02),
    .w10 (w10), .w11 (w11), .w12 (w12),
    .w20 (w20), .w21 (w21), .w22 (w22)
);

//-------------------------------------------------------------------
// Pick pass 1's result for the active mode and hand it to pass 2.  PASS takes
// the untouched centre, so it comes out of pass 2 with the same latency as
// the two rank modes and nothing downstream shifts when the mode changes.
// Delay 6.
//-------------------------------------------------------------------
reg [7:0] mid_r, mid_g, mid_b;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        mid_r <= 8'd0; mid_g <= 8'd0; mid_b <= 8'd0;
    end else begin
        case (mode_active)
            MODE_ERODE  : begin mid_r <= e1_r; mid_g <= e1_g; mid_b <= e1_b; end
            MODE_DILATE : begin mid_r <= d1_r; mid_g <= d1_g; mid_b <= d1_b; end
            default     : begin mid_r <= c1_r; mid_g <= c1_g; mid_b <= c1_b; end
        endcase
    end
end

//-------------------------------------------------------------------
// PASS 2 : identical, applied to pass 1's result.  Out at delay 11.  Only its
// centre tap c2_* is wired to the output mux now (radius 2 -- see the mux
// comment below); ero_r/dil_r stay connected so radius 4 is a one-line return,
// but synthesis will trim their reduction logic while they are unused.
//-------------------------------------------------------------------
wire [7:0] e2_r, e2_g, e2_b;
wire [7:0] d2_r, d2_g, d2_b;
wire [7:0] c2_r, c2_g, c2_b;

morph_rank5_core #(
    .IMG_HDISP (IMG_HDISP), .IMG_VDISP (IMG_VDISP), .RANK_MODE (1)
) u_pass2 (
    .clk (clk), .rst_n (rst_n),
    .in_vs (vs_dly[PASS2_TAP]), .in_de (de_dly[PASS2_TAP]),
    .in_r (mid_r), .in_g (mid_g), .in_b (mid_b),
    .ero_r (e2_r), .ero_g (e2_g), .ero_b (e2_b),
    .dil_r (d2_r), .dil_g (d2_g), .dil_b (d2_b),
    .ctr_r (c2_r), .ctr_g (c2_g), .ctr_b (c2_b),
    .w00 (), .w01 (), .w02 (),
    .w10 (), .w11 (), .w12 (),
    .w20 (), .w21 (), .w22 ()
);

//-------------------------------------------------------------------
// DARK branch -- fed the inner 3x3 of the PASS-1 window, not the full 5x5 and
// not pass 2.  Its job is to judge local contrast, and a five-pixel span is
// the wrong scale for that: it would call a soft gradient an edge.  Four
// internal stages, so its combinational result is at delay 7; four more
// registers bring it to 11 alongside pass 2.
//-------------------------------------------------------------------
wire [7:0] dark_r, dark_g, dark_b;

dark_light_888 u_dark_light (
    .clk   (clk  ),
    .rst_n (rst_n),
    .p00   (w00), .p01 (w01), .p02 (w02),
    .p10   (w10), .p11 (w11), .p12 (w12),
    .p20   (w20), .p21 (w21), .p22 (w22),
    .r_out (dark_r), .g_out (dark_g), .b_out (dark_b)
);

reg [23:0] dk_d1, dk_d2, dk_d3, dk_d4;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        dk_d1 <= 24'd0; dk_d2 <= 24'd0; dk_d3 <= 24'd0; dk_d4 <= 24'd0;
    end else begin
        dk_d1 <= {dark_r, dark_g, dark_b};
        dk_d2 <= dk_d1;
        dk_d3 <= dk_d2;
        dk_d4 <= dk_d3;
    end
end

//-------------------------------------------------------------------
// Final mode mux, registered.  Delay 12.
//-------------------------------------------------------------------
reg [7:0] out_rr, out_gr, out_br;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        out_rr <= 8'd0; out_gr <= 8'd0; out_br <= 8'd0;
    end else begin
        case (mode_active)
            // Radius 2, not 4.  c2_* is mid_* delayed through pass 2's window
            // centre, and mid_* is already pass 1's erode/dilate result for the
            // active mode, so taking c2_* here is exactly one 5x5 pass.  Radius
            // 4 did show up on the bench but ate too much detail (08-12).  To
            // go back, wire e2_*/d2_* here again -- pass 2 still computes them.
            MODE_ERODE  : begin out_rr <= c2_r;         out_gr <= c2_g;        out_br <= c2_b;       end
            MODE_DILATE : begin out_rr <= c2_r;         out_gr <= c2_g;        out_br <= c2_b;       end
            MODE_DARK   : begin out_rr <= dk_d4[23:16]; out_gr <= dk_d4[15:8]; out_br <= dk_d4[7:0]; end
            default     : begin out_rr <= c2_r;         out_gr <= c2_g;        out_br <= c2_b;       end
        endcase
    end
end

assign out_r = out_rr;
assign out_g = out_gr;
assign out_b = out_br;

endmodule
