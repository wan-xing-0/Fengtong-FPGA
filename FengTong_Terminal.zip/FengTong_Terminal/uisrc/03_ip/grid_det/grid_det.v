// grid_det：静态人检测（v3 冻结结构 stem4）。1080p DE 流 -> 160x90 灰度 -> 七层整数 CNN -> CCL/NMS，最多 4 框。
//
// 2026-10-12 Claude 在 GPT 版（Anlogic5_v4/uisrc/03_ip/grid_det/grid_det.v）上重写。端口、hex 格式
// （packed_w0..3 / packed_bias）、整数契约（tools/grid_det/ARCH_FREEZE.md）不变；参数里 GPT 的 ROM_DIR
// 换成了 W0..W3_FILE/BIAS_FILE 五个文件名（10-13，原因见参数处），GPT 的 run_rtl_v3.py 不能直接套本文件。输出与 GPT 版、与
// integer.py golden 逐位一致。GPT 以后只换权重/阈值，hex 直接替换即可。改了四件事：
//  1. 卷积 tap 全流水，1 tap/拍（GPT 版 5 拍/tap）：接帧到发布 ~375 万拍，其中采集 ~239 万（就是 1080p 一帧），
//     计算 ~135 万；GPT 版计算 ~665 万。150MHz 下每两帧出一次结果。
//  2. 每级只做一件事。GPT 版 S_ADDR 一拍里串了「坐标 -> 常数乘 -> 三数加 -> /5 %5」，pclkx1 只剩
//     +0.005ns 余量，那条必成最差路径。这里 /5 用 x*13108>>16（x<16384 精确，地址最大 14399）单独一级。
//  3. 所有 RAM 单写口单读口、各自一个无复位 always 块（TD 推不出 ERAM 时退成 LUT RAM，23 万 bit 吃不起）。
//     输入只留一个 bank：采集和计算本来就是串行的，GPT 版第二个 bank 白占 6 块 ERAM。
//  4. 行列计数在场消隐（DE 连续低 VB_GUARD 拍，同 ccl_blob/det_overlay）归零，复位后见到第一次场消隐
//     才接帧；不看 VS。GPT 版只数 DE，复位落在帧中间就永久错位（帧中复位测试 LOGIT 全错）。
//     采集中途进了场消隐（帧残缺）就放弃这帧回 IDLE。
// 10-21：多导出 obj_low —— 每格「argmax=人且分数>=LOW_Q8」一位，和框同一拍发布，给下面的 grid_post 做竖向延伸。
//     框/分数/logit 不受影响，原测试台照旧逐位通过。
// ⭐ 10-30：背景学习（BG_LEARN=1）。安防静止时门被框（10-30 19:00 录像：空场 20 s 里门框 4 段、共 65/612 帧，
//     还触发了报警 + 射灯）。门那一列格子板上分数时不时过 1066；离线重放同一段录像分数中位 ~280、最高 1043，
//     与板上出框帧的相关 0.03 = 板上/录像域差（10-23 已记），所以不能离线挑阈值，也不能整体抬阈值（伤召回）。
//     做法：bg_learn 为高的那几帧里，每格若「argmax=人、分数在 (THR-BG_M, THR+BG_CAP]」就记
//     floor = max(floor, 分数+BG_M)；以后这格的门限 = max(THRESHOLD_Q8, floor)。学习段第一帧先清空旧表。
//     上限 BG_CAP：学习时镜头前有人（分数远高于门）的格子不记，人不会被学成背景。
//     从没学过（上电）= 每格 floor 无效 = 与旧版逐位一致（tb_grid_det_low / tb_chain 照旧通过）。
//     离线（录像域，加性偏差抵消）：学 45 帧、BG_M 100 后空场门格「超过 floor」1~5% 帧、连续 4 帧 0 次；
//     18:48 真人段出框率 92.9 -> 92.6%。BG_LEARN=0 = 这一节不生成。
module grid_det #(
    parameter signed [31:0] THRESHOLD_Q8 = 32'sd1066,   // 与 packed_*.hex 同一次导出（rtl_export.json）
    parameter signed [31:0] LOW_Q8       = 32'sd700,    // obj_low 的阈值（grid_post 竖向延伸），换权重要重新扫
    // 权重文件：工程里用裸文件名（hex 与本文件同目录，同 i2s_player 的 VOICE_FILE）；测试台传完整路径。
    // 10-13 改：原来是 {ROM_DIR,"packed_w0.hex"} 且 ROM_DIR=""，而 "" 按标准是一个 NUL 字节，
    // 文件名开头多个 \0，iverilog 实测读失败、ROM 全 x；$readmemh 失败不报错，上板就是权重全 0 永不出框。
    parameter W0_FILE   = "packed_w0.hex",
    parameter W1_FILE   = "packed_w1.hex",
    parameter W2_FILE   = "packed_w2.hex",
    parameter W3_FILE   = "packed_w3.hex",
    parameter BIAS_FILE = "packed_bias.hex",
    // 「DE 已经低了这么多拍」= 场消隐而不是行消隐。行消隐 220（测试台 280），场消隐 11,000。
    parameter integer VB_GUARD = 512,
    // 10-30 背景学习（见文件头）。BG_M = floor 比学到的分数高多少；BG_CAP = 只学 THR+BG_CAP 以下的分数
    parameter integer BG_LEARN = 0,
    parameter signed [31:0] BG_M   = 32'sd150,
    parameter signed [31:0] BG_CAP = 32'sd600
) (
    input wire clk, input wire rst_n, input wire en,
    input wire in_vs,                                    // 不用（帧边界从 DE 推），留着保持 GPT 的端口
    input wire in_de, input wire [23:0] in_rgb,
    output reg [47:0] obj_x0, obj_y0, obj_x1, obj_y1,   // 4 x 12bit，槽 0 在最低位
    output reg [7:0] obj_cls,                            // 4 x 2bit，1 人 2 动物
    output reg [127:0] obj_score,                        // 4 x signed32 Q8（类别 logit - 背景 logit）
    output reg [3:0] obj_valid,
    output reg [239:0] obj_low,                          // 位 y*20+x：该格 argmax=人且 logit1-logit0>=LOW_Q8
    output reg pub, output wire busy,                    // pub 单拍，所有结果字段只在这一拍切换
    input wire bg_learn,                                 // 10-30：电平；本帧（S_DIV_INIT 时采样）参与背景学习
    output reg [7:0] bg_cells,                           // 10-30：当前有效 floor 的格数（学完那帧发布时更新）
    output reg [31:0] result_frame_id, cycles_last
);
    localparam S_IDLE=0, S_CAPTURE=1, S_DIV_INIT=2, S_DIV=3,
        S_NORM_READ=4, S_NORM_SELECT=5, S_NORM_MUL=6, S_NORM_STORE=7,
        S_LAYER=8, S_BIAS_ADDR=9, S_BIAS_WAIT=10, S_BIAS_LOAD=11, S_GEN=12, S_DRAIN=13,
        S_CCL_INIT=14, S_SCAN_ADDR=15, S_SCAN_WAIT=16, S_SCAN_TEST=17,
        S_Q_ADDR=18, S_Q_WAIT=19, S_Q_LOAD=20, S_NB_ADDR=21, S_NB_CHECK=22, S_NB_WAIT=23,
        S_NB_TEST=24, S_NB_NEXT=25, S_COMPONENT=26, S_NMS_START=27, S_NMS_SEL=28,
        S_NMS_EDGE=29, S_NMS_DIMS=30, S_NMS_MUL=31, S_NMS_SUM=32, S_NMS_TEST=33,
        S_BEST=34, S_SCAN_NEXT=35, S_CLASS_DONE=36, S_PASS_DONE=37, S_PUBLISH=38;
    reg [5:0] state;
    assign busy = state != S_IDLE;

    // =====================================================================================
    // RAM / ROM：每块单写单读，无复位
    // =====================================================================================
    // 160x90 灰度，5 字节/字（低地址字节在低位），2880 字 = 6 ERAM
    reg [39:0] inmem [0:2879];
    reg        in_we;
    reg [11:0] in_waddr;
    reg [39:0] in_wdata, in_q;
    reg [11:0] norm_word;
    reg [11:0] s5_q;                       // 流水第 5 级：字地址
    wire norm_phase = state==S_NORM_READ || state==S_NORM_SELECT || state==S_NORM_MUL || state==S_NORM_STORE;
    wire [11:0] in_raddr = norm_phase ? norm_word : s5_q;
    always @(posedge clk) begin
        if (in_we) inmem[in_waddr] <= in_wdata;
        in_q <= inmem[in_raddr];
    end

    // 特征：4 lane（输出通道 mod 4）x 偶/奇层两套，每块 1024x40 = 2 ERAM，共 16
    // 偶层（0,2,4）写 fe、奇层（1,3,5）写 fo；层 L 读上一层写的那套
    reg        fw_we, fw_odd;
    reg [9:0]  fw_addr;
    reg [39:0] fw_d0, fw_d1, fw_d2, fw_d3;
    reg [39:0] fe0 [0:1023]; reg [39:0] fe1 [0:1023]; reg [39:0] fe2 [0:1023]; reg [39:0] fe3 [0:1023];
    reg [39:0] fo0 [0:1023]; reg [39:0] fo1 [0:1023]; reg [39:0] fo2 [0:1023]; reg [39:0] fo3 [0:1023];
    reg [39:0] fe0_q, fe1_q, fe2_q, fe3_q, fo0_q, fo1_q, fo2_q, fo3_q;
    always @(posedge clk) begin if (fw_we && !fw_odd) fe0[fw_addr] <= fw_d0; fe0_q <= fe0[s5_q[9:0]]; end
    always @(posedge clk) begin if (fw_we && !fw_odd) fe1[fw_addr] <= fw_d1; fe1_q <= fe1[s5_q[9:0]]; end
    always @(posedge clk) begin if (fw_we && !fw_odd) fe2[fw_addr] <= fw_d2; fe2_q <= fe2[s5_q[9:0]]; end
    always @(posedge clk) begin if (fw_we && !fw_odd) fe3[fw_addr] <= fw_d3; fe3_q <= fe3[s5_q[9:0]]; end
    always @(posedge clk) begin if (fw_we &&  fw_odd) fo0[fw_addr] <= fw_d0; fo0_q <= fo0[s5_q[9:0]]; end
    always @(posedge clk) begin if (fw_we &&  fw_odd) fo1[fw_addr] <= fw_d1; fo1_q <= fo1[s5_q[9:0]]; end
    always @(posedge clk) begin if (fw_we &&  fw_odd) fo2[fw_addr] <= fw_d2; fo2_q <= fo2[s5_q[9:0]]; end
    always @(posedge clk) begin if (fw_we &&  fw_odd) fo3[fw_addr] <= fw_d3; fo3_q <= fo3[s5_q[9:0]]; end

    // 权重：lane l 存输出通道 4g+l，层/组/输入通道/KY/KX 顺序，每层补齐到整字；4 x 1024x40 = 8 ERAM
    reg [39:0] wrom0 [0:1023]; reg [39:0] wrom1 [0:1023]; reg [39:0] wrom2 [0:1023]; reg [39:0] wrom3 [0:1023];
    reg [39:0] biasrom [0:511];            // {SH[7:0], bias[31:0]}，每层 cout 按 4 补齐
    initial begin
        $readmemh(W0_FILE, wrom0);
        $readmemh(W1_FILE, wrom1);
        $readmemh(W2_FILE, wrom2);
        $readmemh(W3_FILE, wrom3);
        $readmemh(BIAS_FILE, biasrom);
    end
    reg [9:0]  s5_wword;
    reg [39:0] wq0, wq1, wq2, wq3;
    always @(posedge clk) wq0 <= wrom0[s5_wword];
    always @(posedge clk) wq1 <= wrom1[s5_wword];
    always @(posedge clk) wq2 <= wrom2[s5_wword];
    always @(posedge clk) wq3 <= wrom3[s5_wword];
    reg [8:0]  bias_raddr;
    reg [39:0] bias_q;
    always @(posedge clk) bias_q <= biasrom[bias_raddr];

    // 20x12 网格：{6'd0, 类别[1:0], margin[31:0]}
    reg        g_we;
    reg [7:0]  g_waddr, grid_raddr;
    reg [39:0] g_wdata, grid_q;
    reg [39:0] gridmem [0:239];
    always @(posedge clk) begin
        if (g_we) gridmem[g_waddr] <= g_wdata;
        grid_q <= gridmem[grid_raddr];
    end

    // 12 行纵向累加
    reg [19:0] line_acc [0:159];
    reg [19:0] line_q;
    reg [7:0]  block_col, block_address;
    reg        block_valid, block_first;
    reg [11:0] block_sum;
    wire [19:0] vertical_sum = (block_first ? 20'd0 : line_q) + block_sum;
    always @(posedge clk) begin
        if (block_valid) line_acc[block_address] <= vertical_sum;
        line_q <= line_acc[block_col];
    end

    // CCL 队列：{y[3:0], x[4:0], idx[7:0]}
    reg        q_we;
    reg [7:0]  q_waddr, q_raddr;
    reg [16:0] q_wdata, queue_q;
    reg [16:0] queue_mem [0:255];
    always @(posedge clk) begin
        if (q_we) queue_mem[q_waddr] <= q_wdata;
        queue_q <= queue_mem[q_raddr];
    end

    function [7:0] pick_byte;
        input [39:0] word;
        input [2:0] slot;
        begin
            case (slot)
                3'd0: pick_byte = word[7:0];   3'd1: pick_byte = word[15:8];
                3'd2: pick_byte = word[23:16]; 3'd3: pick_byte = word[31:24];
                default: pick_byte = word[39:32];
            endcase
        end
    endfunction

    // =====================================================================================
    // 采集：灰度 -> 12x12 块均值 -> inmem，同时求帧 min/max
    // =====================================================================================
    reg [10:0] video_x, video_y;
    reg [31:0] video_frame_id, active_frame_id, cycle_count;
    reg        synced, capture_active;
    reg [9:0]  de_low;
    wire vblank = de_low == VB_GUARD-1 && !in_de;   // 单拍：DE 低满 VB_GUARD 拍的那一拍
    wire accept_now = synced && in_de && video_x==0 && video_y==0 && state==S_IDLE && en;
    // 测试台观察点（不出端口，综合会剪掉）
    reg        dbg_accept_valid, dbg_logit_valid;
    reg [31:0] dbg_accept_frame_id;
    reg [7:0]  dbg_logit_index;
    reg signed [31:0] dbg_logit0, dbg_logit1, dbg_logit2;

    reg [15:0] gray_r, gray_g, gray_b, gray_sum;
    reg        gray_v0, gray_v1;
    reg [3:0]  sub_x, sub_y;
    reg [6:0]  block_row;
    reg [11:0] horizontal_sum;
    reg        block_last, block_frame_last;
    reg [19:0] vsum_r;
    reg        vsum_v, vsum_last;
    reg        avg_valid, avg_last;
    reg [31:0] avg_product;
    wire [7:0] average_byte = avg_product[22:15];   // ((s>>4)*3641)>>15 == s/144，s<=36720 精确
    reg [7:0]  frame_min, frame_max;
    reg [11:0] capture_word;
    reg [2:0]  capture_slot;
    reg [39:0] capture_pack;
    wire [39:0] capture_insert = capture_pack | ({32'd0, average_byte} << (capture_slot*8));

    // 逐帧倒数 (65280+span/2)/span：16 拍恢复除法
    reg [7:0]  span;
    reg [15:0] dividend, quotient, reciprocal;
    reg [16:0] remainder;
    reg [4:0]  div_remaining;
    wire [16:0] div_trial = {remainder[15:0], dividend[15]};
    wire        div_bit = div_trial >= {9'd0, span};
    wire [16:0] div_remainder_next = div_bit ? div_trial - span : div_trial;
    wire [15:0] div_quotient_next = {quotient[14:0], div_bit};
    reg [2:0]  norm_slot;
    reg [39:0] norm_pack;
    reg [7:0]  norm_delta;
    reg [23:0] norm_product;
    wire [24:0] norm_rounded = {1'b0, norm_product} + 25'd128;
    wire [7:0]  norm_byte = norm_rounded[24:8] > 255 ? 8'd255 : norm_rounded[15:8];
    wire [39:0] norm_insert = norm_pack | ({32'd0, norm_byte} << (norm_slot*8));

    // =====================================================================================
    // 卷积：层表（冻结），按 layer_index 组合出参数
    // =====================================================================================
    reg [2:0] layer_index, group_index;
    reg [7:0] in_width, in_height, out_width, out_height;
    reg [2:0] group_count;
    reg [7:0] tap_count;
    reg [1:0] kernel_last;
    reg [3:0] dilation;
    reg [2:0] padding;
    reg       stride_two;
    reg [9:0] weight_base;
    reg [6:0] bias_base;
    reg [13:0] plane;                     // 输入一个通道在 lane 内占的字节数
    always @* begin
        in_width=20; in_height=12; out_width=20; out_height=12;
        group_count=6; tap_count=216; kernel_last=2;
        dilation=1; padding=1; stride_two=0; weight_base=0; bias_base=0; plane=240;
        case (layer_index)
            3'd0: begin in_width=160; in_height=90; out_width=80; out_height=45;
                  group_count=1; tap_count=9;   stride_two=1; weight_base=0;   bias_base=0;  plane=0;    end
            3'd1: begin in_width=80;  in_height=45; out_width=40; out_height=23;
                  group_count=4; tap_count=36;  stride_two=1; weight_base=2;   bias_base=4;  plane=3600; end
            3'd2: begin in_width=40;  in_height=23; out_width=20; out_height=12;
                  group_count=6; tap_count=144; stride_two=1; weight_base=31;  bias_base=20; plane=920;  end
            3'd3: begin dilation=2; padding=2; weight_base=204; bias_base=44; end
            3'd4: begin dilation=4; padding=4; weight_base=464; bias_base=68; end
            3'd5: begin dilation=2; padding=2; weight_base=724; bias_base=92; end
            3'd6: begin group_count=1; tap_count=24; kernel_last=0; padding=0; weight_base=984; bias_base=116; end
            default: begin end
        endcase
    end
    wire relu = layer_index != 3'd6;

    reg signed [31:0] bias0, bias1, bias2, bias3;
    reg [7:0]  shift0, shift1, shift2, shift3;
    reg [1:0]  bias_lane;

    // ---- 发生器：每拍发一个 tap ----
    reg [6:0]  ox; reg [5:0] oy;
    reg signed [9:0] base_x, base_y;      // ox*s - pad
    reg [3:0]  koff_x, koff_y;            // kx*dil
    reg [1:0]  kx, ky;
    reg [4:0]  ci;
    reg [7:0]  tap;
    reg [13:0] chbase;                    // (ci>>2)*plane
    reg [9:0]  wword, gstart_word;
    reg [2:0]  wslot, gstart_slot;
    wire tap_last = tap == tap_count-1;
    wire px_last  = ox == out_width-1 && oy == out_height-1;
    wire [9:0] wword_next = wslot==3'd4 ? wword+10'd1 : wword;
    wire [2:0] wslot_next = wslot==3'd4 ? 3'd0 : wslot+3'd1;

    // ---- 流水各级 ----
    reg        s1_v, s1_first, s1_last; reg signed [9:0] s1_cx, s1_cy; reg [13:0] s1_chb; reg [1:0] s1_lane;
    reg [9:0]  s1_wword; reg [2:0] s1_wslot;
    reg        s2_v, s2_first, s2_last, s2_pad; reg [7:0] s2_cx; reg [13:0] s2_row, s2_chb; reg [1:0] s2_lane;
    reg [9:0]  s2_wword; reg [2:0] s2_wslot;
    reg        s3_v, s3_first, s3_last, s3_pad; reg [14:0] s3_lin; reg [1:0] s3_lane;
    reg [9:0]  s3_wword; reg [2:0] s3_wslot;
    reg        s4_v, s4_first, s4_last, s4_pad; reg [14:0] s4_lin; reg [27:0] s4_prod; reg [1:0] s4_lane;
    reg [9:0]  s4_wword; reg [2:0] s4_wslot;
    reg        s5_v, s5_first, s5_last, s5_pad; reg [14:0] s5_lin; reg [1:0] s5_lane; reg [2:0] s5_wslot;
    reg        s6_v, s6_first, s6_last, s6_pad; reg [2:0] s6_r; reg [1:0] s6_lane; reg [2:0] s6_wslot;
    reg        s6b_v, s6b_first, s6b_last, s6b_pad; reg [2:0] s6b_r, s6b_wslot; reg [39:0] s6b_src, s6b_w0, s6b_w1, s6b_w2, s6b_w3;
    reg        s7_v, s7_first, s7_last; reg [7:0] s7_x; reg signed [7:0] s7_w0, s7_w1, s7_w2, s7_w3;
    reg        s8_v, s8_first, s8_last; reg signed [16:0] s8_p0, s8_p1, s8_p2, s8_p3;
    reg        s9_emit; reg signed [31:0] acc0, acc1, acc2, acc3;
    reg        s10_v; reg signed [32:0] s10_v0, s10_v1, s10_v2, s10_v3;
    reg        s10b_v; reg signed [32:0] s10b_v0, s10b_v1, s10b_v2, s10b_v3;
    reg        s11_v; reg signed [31:0] result0, result1, result2, result3;
    reg        s12_v; reg s12_c1, s12_c2; reg signed [31:0] s12_m1, s12_m2, s12_r0, s12_r1, s12_r2;
    reg [7:0]  grid_index;
    reg [2:0]  feature_slot; reg [9:0] feature_word;
    reg [39:0] feature_pack0, feature_pack1, feature_pack2, feature_pack3;
    wire [39:0] feature_insert0 = feature_pack0 | ({32'd0, result0[7:0]} << (feature_slot*8));
    wire [39:0] feature_insert1 = feature_pack1 | ({32'd0, result1[7:0]} << (feature_slot*8));
    wire [39:0] feature_insert2 = feature_pack2 | ({32'd0, result2[7:0]} << (feature_slot*8));
    wire [39:0] feature_insert3 = feature_pack3 | ({32'd0, result3[7:0]} << (feature_slot*8));
    wire pipe_busy = s1_v | s2_v | s3_v | s4_v | s5_v | s6_v | s6b_v | s7_v | s8_v | s9_emit | s10_v | s10b_v | s11_v | s12_v
                   | fw_we | g_we;

    // 行偏移 cy*W，按层常数
    reg [13:0] row_offset;
    always @* begin
        case (layer_index)
            3'd0:    row_offset = s1_cy[6:0] * 14'd160;
            3'd1:    row_offset = s1_cy[6:0] * 14'd80;
            3'd2:    row_offset = s1_cy[6:0] * 14'd40;
            default: row_offset = s1_cy[6:0] * 14'd20;
        endcase
    end

    // 第 6b 级：选源字（层 0 读 inmem，奇层读 fe，偶层读 fo），RAM 出数后先打一拍
    reg [39:0] src_word;
    always @* begin
        if (layer_index == 3'd0) src_word = in_q;
        else if (layer_index[0]) begin
            case (s6_lane) 2'd0: src_word = fe0_q; 2'd1: src_word = fe1_q; 2'd2: src_word = fe2_q; default: src_word = fe3_q; endcase
        end else begin
            case (s6_lane) 2'd0: src_word = fo0_q; 2'd1: src_word = fo1_q; 2'd2: src_word = fo2_q; default: src_word = fo3_q; endcase
        end
    end

    // 第 10 级：ReLU + 加半 LSB；第 11 级：算术右移 + 饱和
    function signed [32:0] round_add;
        input signed [31:0] accumulator;
        input [7:0] shift;
        input do_relu;
        reg signed [32:0] value;
        begin
            value = (do_relu && accumulator < 0) ? 33'sd0 : {accumulator[31], accumulator};
            if (shift != 0) value = value + (33'sd1 << (shift-1));
            round_add = value;
        end
    endfunction
    function signed [31:0] saturate;
        input signed [32:0] shifted;
        input do_relu;
        begin
            if (do_relu && shifted > 255) saturate = 32'sd255;
            else saturate = shifted[31:0];
        end
    endfunction

    // =====================================================================================
    // CCL / NMS
    // =====================================================================================
    reg [239:0] visited;
    reg [7:0]  scan_index; reg [4:0] scan_x; reg [3:0] scan_y;
    reg [1:0]  scan_class, selected_slot, nms_index, nb_dir;
    reg [7:0]  qhead, qtail;
    reg [7:0]  cur_idx; reg [4:0] cur_x; reg [3:0] cur_y;
    reg [7:0]  nb_idx;  reg [4:0] nb_x;  reg [3:0] nb_y; reg nb_exists;
    reg [4:0]  comp_min_x, comp_max_x;
    reg [3:0]  comp_min_y, comp_max_y;
    reg signed [31:0] comp_score;
    reg [11:0] cand_x0, cand_y0, cand_x1, cand_y1;
    reg [11:0] chosen_x0, chosen_y0, chosen_x1, chosen_y1;
    reg [11:0] isect_l, isect_t, isect_r, isect_b;
    reg [11:0] isect_w, isect_h, cand_w, cand_h, chosen_w, chosen_h;
    reg [23:0] isect_area, cand_area, chosen_area;
    reg [26:0] five_isect, twice_union;
    reg        best_valid;
    reg [11:0] best_x0, best_y0, best_x1, best_y1;
    reg [1:0]  best_class;
    reg signed [31:0] best_score;
    reg [47:0] work_x0, work_y0, work_x1, work_y1;
    reg [7:0]  work_class;
    reg [127:0] work_score;
    reg [3:0]  work_valid;
    reg [239:0] low_work;                  // 第 13 级逐格写满 240 位才会走到发布
    wire [1:0] grid_cls = grid_q[33:32];
    wire signed [31:0] grid_margin = grid_q[31:0];

    // =====================================================================================
    // 10-30 背景学习：floor 表（单写单读 RAM，无复位）+ 有效位（有复位）
    // 读口一直指着 grid_index；第 6 层两格之间至少隔 24 拍（tap_count），所以 bg_q 早就稳定，
    // 第 12 级算出本格门限 s12_thr，第 13 级比较；写回放到第 14 级（地址先存下来，第 13 级 grid_index 已自增）。
    // =====================================================================================
    reg  signed [31:0] s12_thr;
    reg  [15:0] bg_mem [0:255];
    reg  [15:0] bg_q;
    reg  [239:0] bg_v;
    reg         bg_vq;
    reg         lrn_f, lrn_first, lrn_prev;
    reg         s13_v, s13_q, s13_c1;
    reg  [7:0]  s13_idx;
    reg  [15:0] s13_lv, s13_old;
    reg         s13_oldv;
    reg  [8:0]  bg_count;
    always @(posedge clk) bg_q <= bg_mem[grid_index];
    // s13_q is the one-clock write strobe (the clock AFTER s13_v); s13_idx / s13_lv hold for 24 clocks.
    // (First draft gated it with s13_v too -- never both high: bg_v set, bg_mem never written; tb_bglearn P3.)
    always @(posedge clk) if (BG_LEARN != 0 && s13_q) bg_mem[s13_idx] <= s13_lv;
    // 一格可学 = argmax 人且分数在 (THR-BG_M, THR+BG_CAP]：低于下限的 floor 本来就不起作用，高于上限的是人
    wire        lrn_ok = s12_c1 && (s12_m1 > THRESHOLD_Q8 - BG_M) && (s12_m1 <= THRESHOLD_Q8 + BG_CAP);
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            bg_v <= 240'd0; bg_vq <= 1'b0; lrn_f <= 1'b0; lrn_first <= 1'b0; lrn_prev <= 1'b0;
            s13_v <= 1'b0; s13_q <= 1'b0; s13_c1 <= 1'b0; s13_idx <= 8'd0; s13_lv <= 16'd0;
            s13_old <= 16'd0; s13_oldv <= 1'b0; bg_count <= 9'd0; bg_cells <= 8'd0;
        end else if (BG_LEARN != 0) begin
            bg_vq <= bg_v[grid_index];
            if (state == S_DIV_INIT) begin                 // 每帧一次：这帧学不学
                lrn_f <= bg_learn; lrn_first <= bg_learn && !lrn_prev; lrn_prev <= bg_learn;
                bg_count <= 9'd0;
            end
            // 第 13 级：把本格的学习结果存下来（grid_index 这一拍自增）
            s13_v <= s12_v && lrn_f;
            if (s12_v) begin
                s13_idx <= grid_index; s13_c1 <= lrn_ok;
                s13_lv  <= s12_m1[15:0] + BG_M[15:0];       // lrn_ok 时 < THR+BG_CAP+BG_M，16 位够
                s13_old <= bg_q; s13_oldv <= bg_vq && !lrn_first;
            end
            // 第 14 级：写回。学习段第一帧：可学的写，不可学的清；之后：只在更大时写
            s13_q <= 1'b0;
            if (s13_v) begin
                if (s13_c1 && (!s13_oldv || s13_lv > s13_old)) begin
                    s13_q <= 1'b1; bg_v[s13_idx] <= 1'b1;
                end else if (lrn_first && !s13_c1) begin
                    bg_v[s13_idx] <= 1'b0;
                end
            end
            if (s12_v && (lrn_f ? (lrn_ok || (bg_vq && !lrn_first)) : bg_vq)) bg_count <= bg_count + 9'd1;
            if (state == S_PUBLISH) bg_cells <= (bg_count > 9'd255) ? 8'd255 : bg_count[7:0];
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state<=S_IDLE; video_x<=0; video_y<=0; video_frame_id<=0; active_frame_id<=0; cycle_count<=0;
            de_low<=0; synced<=0; capture_active<=0;
            obj_x0<=0; obj_y0<=0; obj_x1<=0; obj_y1<=0; obj_cls<=0; obj_score<=0; obj_valid<=0;
            obj_low<=0; low_work<=0;
            pub<=0; result_frame_id<=0; cycles_last<=0;
            dbg_accept_valid<=0; dbg_accept_frame_id<=0; dbg_logit_valid<=0;
            dbg_logit_index<=0; dbg_logit0<=0; dbg_logit1<=0; dbg_logit2<=0;
            gray_v0<=0; gray_v1<=0; block_valid<=0; vsum_v<=0; avg_valid<=0;
            gray_r<=0; gray_g<=0; gray_b<=0; gray_sum<=0;
            sub_x<=0; sub_y<=0; block_col<=0; block_row<=0; horizontal_sum<=0;
            capture_word<=0; capture_slot<=0; capture_pack<=0; frame_min<=255; frame_max<=0;
            in_we<=0; fw_we<=0; g_we<=0; q_we<=0;
            s1_v<=0; s2_v<=0; s3_v<=0; s4_v<=0; s5_v<=0; s6_v<=0; s7_v<=0; s8_v<=0;
            s9_emit<=0; s10_v<=0; s11_v<=0; s12_v<=0;
            work_x0<=0; work_y0<=0; work_x1<=0; work_y1<=0; work_class<=0; work_score<=0; work_valid<=0;
            visited<=0; layer_index<=0; group_index<=0;
        end else begin
            pub<=0; dbg_accept_valid<=0; dbg_logit_valid<=0;
            gray_v0<=0; gray_v1<=gray_v0; block_valid<=0; vsum_v<=0; avg_valid<=0;
            in_we<=0; fw_we<=0; g_we<=0; q_we<=0;
            if (busy) cycle_count <= cycle_count+1;

            // ---- 视频计数：场消隐归零，DE 计数；与 en/busy 无关 ----
            if (in_de) de_low<=0; else if (de_low!=VB_GUARD-1) de_low<=de_low+1;
            if (vblank) begin
                video_x<=0; video_y<=0; synced<=1;
            end else if (in_de) begin
                if (video_x==1919) begin
                    video_x<=0;
                    if (video_y==1079) begin video_y<=0; video_frame_id<=video_frame_id+1; end
                    else video_y<=video_y+1;
                end else video_x<=video_x+1;
            end
            if (accept_now) begin
                state<=S_CAPTURE; capture_active<=1;
                active_frame_id<=video_frame_id; cycle_count<=0;
                dbg_accept_valid<=1; dbg_accept_frame_id<=video_frame_id;
                sub_x<=0; sub_y<=0; block_col<=0; block_row<=0; horizontal_sum<=0;
                capture_word<=0; capture_slot<=0; capture_pack<=0; frame_min<=255; frame_max<=0;
                work_x0<=0; work_y0<=0; work_x1<=0; work_y1<=0; work_class<=0; work_score<=0; work_valid<=0;
            end
            // ---- 采集流水 ----
            if (in_de && (capture_active || accept_now)) begin
                gray_r <= in_rgb[23:16]*16'd77;
                gray_g <= in_rgb[15:8]*16'd150;
                gray_b <= in_rgb[7:0]*16'd29;
                gray_v0 <= 1;
                if (video_x==1919 && video_y==1079) capture_active<=0;
            end
            if (gray_v0) gray_sum <= gray_r+gray_g+gray_b;
            if (gray_v1) begin
                if (sub_x==11) begin
                    sub_x<=0; horizontal_sum<=0;
                    block_valid<=1; block_sum<=horizontal_sum+gray_sum[15:8];
                    block_address<=block_col; block_first<=sub_y==0; block_last<=sub_y==11;
                    block_frame_last<=sub_y==11 && block_col==159 && block_row==89;
                    if (block_col==159) begin
                        block_col<=0;
                        if (sub_y==11) begin sub_y<=0; block_row<=block_row+1; end
                        else sub_y<=sub_y+1;
                    end else block_col<=block_col+1;
                end else begin sub_x<=sub_x+1; horizontal_sum<=horizontal_sum+gray_sum[15:8]; end
            end
            if (block_valid && block_last) begin vsum_r<=vertical_sum; vsum_v<=1; vsum_last<=block_frame_last; end
            if (vsum_v) begin avg_product<=(vsum_r>>4)*32'd3641; avg_valid<=1; avg_last<=vsum_last; end
            if (avg_valid) begin
                if (average_byte<frame_min) frame_min<=average_byte;
                if (average_byte>frame_max) frame_max<=average_byte;
                if (capture_slot==4) begin
                    in_we<=1; in_waddr<=capture_word; in_wdata<=capture_insert;
                    capture_word<=capture_word+1; capture_slot<=0; capture_pack<=0;
                end else begin capture_slot<=capture_slot+1; capture_pack<=capture_insert; end
                if (avg_last) state<=S_DIV_INIT;
            end
            // 帧没收完就来了 VS：这帧残缺，放弃
            if (vblank && capture_active) capture_active<=0;

            // ---- 卷积流水（与 FSM 并行，FSM 只管发生器启停和排空）----
            // 第 1 级：坐标
            s1_v<=0;
            if (state==S_GEN) begin
                s1_v<=1; s1_first<=tap==0; s1_last<=tap_last;
                s1_cx<=base_x+$signed({6'd0,koff_x}); s1_cy<=base_y+$signed({6'd0,koff_y});
                s1_chb<=chbase; s1_lane<=ci[1:0]; s1_wword<=wword; s1_wslot<=wslot;
            end
            // 第 2 级：越界判断 + 行偏移
            s2_v<=s1_v; s2_first<=s1_first; s2_last<=s1_last;
            s2_pad <= s1_cx<0 || s1_cy<0 || s1_cx>=$signed({2'd0,in_width}) || s1_cy>=$signed({2'd0,in_height});
            s2_cx<=s1_cx[7:0]; s2_row<=row_offset; s2_chb<=s1_chb; s2_lane<=s1_lane;
            s2_wword<=s1_wword; s2_wslot<=s1_wslot;
            // 第 3 级：字节线性地址
            s3_v<=s2_v; s3_first<=s2_first; s3_last<=s2_last; s3_pad<=s2_pad;
            s3_lin <= s2_pad ? 15'd0 : {1'b0,s2_chb}+{1'b0,s2_row}+{7'd0,s2_cx};
            s3_lane<=s2_lane; s3_wword<=s2_wword; s3_wslot<=s2_wslot;
            // 第 4 级：x*13108
            s4_v<=s3_v; s4_first<=s3_first; s4_last<=s3_last; s4_pad<=s3_pad;
            s4_lin<=s3_lin; s4_prod<=s3_lin*15'd13108;
            s4_lane<=s3_lane; s4_wword<=s3_wword; s4_wslot<=s3_wslot;
            // 第 5 级：字地址 = x/5（RAM 读地址寄存器）
            s5_v<=s4_v; s5_first<=s4_first; s5_last<=s4_last; s5_pad<=s4_pad;
            s5_q<=s4_prod[27:16]; s5_lin<=s4_lin;
            s5_lane<=s4_lane; s5_wword<=s4_wword+weight_base; s5_wslot<=s4_wslot;
            // 第 6 级：RAM/ROM 出数；字内槽 = x - 5*(x/5)
            s6_v<=s5_v; s6_first<=s5_first; s6_last<=s5_last; s6_pad<=s5_pad;
            s6_r <= s5_lin[2:0] - {s5_q[0],2'b00} - s5_q[2:0];
            s6_lane<=s5_lane; s6_wslot<=s5_wslot;
            // 第 6b 级：RAM 出数打一拍
            s6b_v<=s6_v; s6b_first<=s6_first; s6b_last<=s6_last; s6b_pad<=s6_pad;
            s6b_r<=s6_r; s6b_wslot<=s6_wslot; s6b_src<=src_word;
            s6b_w0<=wq0; s6b_w1<=wq1; s6b_w2<=wq2; s6b_w3<=wq3;
            // 第 7 级：选字节
            s7_v<=s6b_v; s7_first<=s6b_first; s7_last<=s6b_last;
            s7_x <= s6b_pad ? 8'd0 : pick_byte(s6b_src, s6b_r);
            s7_w0<=pick_byte(s6b_w0,s6b_wslot); s7_w1<=pick_byte(s6b_w1,s6b_wslot);
            s7_w2<=pick_byte(s6b_w2,s6b_wslot); s7_w3<=pick_byte(s6b_w3,s6b_wslot);
            // 第 8 级：乘
            s8_v<=s7_v; s8_first<=s7_first; s8_last<=s7_last;
            s8_p0<=$signed({1'b0,s7_x})*s7_w0; s8_p1<=$signed({1'b0,s7_x})*s7_w1;
            s8_p2<=$signed({1'b0,s7_x})*s7_w2; s8_p3<=$signed({1'b0,s7_x})*s7_w3;
            // 第 9 级：累加（首 tap 从偏置起）
            s9_emit <= s8_v && s8_last;
            if (s8_v) begin
                acc0 <= (s8_first ? bias0 : acc0) + s8_p0;
                acc1 <= (s8_first ? bias1 : acc1) + s8_p1;
                acc2 <= (s8_first ? bias2 : acc2) + s8_p2;
                acc3 <= (s8_first ? bias3 : acc3) + s8_p3;
            end
            // 第 10/10b/11 级：重量化（ReLU+半 LSB / 算术右移 / 饱和）
            s10_v <= s9_emit;
            if (s9_emit) begin
                s10_v0<=round_add(acc0,shift0,relu); s10_v1<=round_add(acc1,shift1,relu);
                s10_v2<=round_add(acc2,shift2,relu); s10_v3<=round_add(acc3,shift3,relu);
            end
            s10b_v <= s10_v;
            if (s10_v) begin
                s10b_v0<=s10_v0>>>shift0; s10b_v1<=s10_v1>>>shift1;
                s10b_v2<=s10_v2>>>shift2; s10b_v3<=s10_v3>>>shift3;
            end
            s11_v <= s10b_v;
            if (s10b_v) begin
                result0<=saturate(s10b_v0,relu); result1<=saturate(s10b_v1,relu);
                result2<=saturate(s10b_v2,relu); result3<=saturate(s10b_v3,relu);
            end
            // 第 12 级：0-5 层打包写特征；6 层先比大小
            s12_v <= s11_v && layer_index==3'd6;
            if (s11_v) begin
                if (layer_index==3'd6) begin
                    s12_c1 <= result1>result0 && result1>=result2;   // 同分取小类别
                    s12_c2 <= result2>result0 && result2>result1;
                    s12_m1 <= result1-result0; s12_m2 <= result2-result0;
                    s12_thr <= (BG_LEARN != 0 && bg_vq && $signed({16'd0, bg_q}) > THRESHOLD_Q8)
                             ? $signed({16'd0, bg_q}) : THRESHOLD_Q8;       // 10-30
                    s12_r0 <= result0; s12_r1 <= result1; s12_r2 <= result2;
                end else if (feature_slot==4) begin
                    fw_we<=1; fw_odd<=layer_index[0]; fw_addr<=feature_word;
                    fw_d0<=feature_insert0; fw_d1<=feature_insert1; fw_d2<=feature_insert2; fw_d3<=feature_insert3;
                    feature_slot<=0; feature_word<=feature_word+1;
                    feature_pack0<=0; feature_pack1<=0; feature_pack2<=0; feature_pack3<=0;
                end else begin
                    feature_slot<=feature_slot+1;
                    feature_pack0<=feature_insert0; feature_pack1<=feature_insert1;
                    feature_pack2<=feature_insert2; feature_pack3<=feature_insert3;
                end
            end
            // 第 13 级：阈值 + 写网格
            if (s12_v) begin
                g_we<=1; g_waddr<=grid_index; grid_index<=grid_index+1;
                if (s12_c1)      g_wdata <= {6'd0, (s12_m1<s12_thr ? 2'd0 : 2'd1), s12_m1};   // 10-30: was THRESHOLD_Q8
                else if (s12_c2) g_wdata <= {6'd0, (s12_m2<THRESHOLD_Q8 ? 2'd0 : 2'd2), s12_m2};
                else             g_wdata <= 40'd0;
                low_work[grid_index] <= s12_c1 && s12_m1>=LOW_Q8;
                dbg_logit_valid<=1; dbg_logit_index<=grid_index;
                dbg_logit0<=s12_r0; dbg_logit1<=s12_r1; dbg_logit2<=s12_r2;
            end

            case (state)
                S_IDLE, S_CAPTURE: begin end
                // ---------------- 归一化 ----------------
                S_DIV_INIT: begin
                    span <= frame_max-frame_min;
                    dividend <= 16'd65280+((frame_max-frame_min)>>1);
                    quotient<=0; remainder<=0; div_remaining<=16;
                    norm_word<=0; norm_slot<=0; norm_pack<=0;
                    if (frame_max==frame_min) begin reciprocal<=0; state<=S_NORM_READ; end
                    else state<=S_DIV;
                end
                S_DIV: begin
                    dividend<=dividend<<1; quotient<=div_quotient_next; remainder<=div_remainder_next;
                    div_remaining<=div_remaining-1;
                    if (div_remaining==1) begin reciprocal<=div_quotient_next; state<=S_NORM_READ; end
                end
                S_NORM_READ:   state<=S_NORM_SELECT;   // 地址 norm_word，in_q 下一拍有效
                S_NORM_SELECT: begin norm_delta<=pick_byte(in_q,norm_slot)-frame_min; state<=S_NORM_MUL; end
                S_NORM_MUL:    begin norm_product<=norm_delta*reciprocal; state<=S_NORM_STORE; end
                S_NORM_STORE: begin
                    if (norm_slot==4) begin
                        in_we<=1; in_waddr<=norm_word; in_wdata<=norm_insert;
                        norm_slot<=0; norm_pack<=0;
                        if (norm_word==2879) begin layer_index<=0; state<=S_LAYER; end
                        else begin norm_word<=norm_word+1; state<=S_NORM_READ; end
                    end else begin norm_slot<=norm_slot+1; norm_pack<=norm_insert; state<=S_NORM_SELECT; end
                end
                // ---------------- 卷积：每组读 4 个偏置 -> 发生器 -> 排空 ----------------
                S_LAYER: begin
                    group_index<=0; feature_slot<=0; feature_word<=0; grid_index<=0;
                    feature_pack0<=0; feature_pack1<=0; feature_pack2<=0; feature_pack3<=0;
                    gstart_word<=0; gstart_slot<=0;               // 组内权重字地址相对 weight_base，第 5 级再加
                    bias_lane<=0; state<=S_BIAS_ADDR;
                end
                S_BIAS_ADDR: begin bias_raddr<={2'd0,bias_base}+{4'd0,group_index,2'b00}+{7'd0,bias_lane}; state<=S_BIAS_WAIT; end
                S_BIAS_WAIT: state<=S_BIAS_LOAD;
                S_BIAS_LOAD: begin
                    case (bias_lane)
                        2'd0: begin bias0<=bias_q[31:0]; shift0<=bias_q[39:32]; end
                        2'd1: begin bias1<=bias_q[31:0]; shift1<=bias_q[39:32]; end
                        2'd2: begin bias2<=bias_q[31:0]; shift2<=bias_q[39:32]; end
                        default: begin bias3<=bias_q[31:0]; shift3<=bias_q[39:32]; end
                    endcase
                    if (bias_lane==3) begin
                        ox<=0; oy<=0; base_x<=-$signed({7'd0,padding}); base_y<=-$signed({7'd0,padding});
                        kx<=0; ky<=0; koff_x<=0; koff_y<=0; ci<=0; tap<=0; chbase<=0;
                        wword<=gstart_word; wslot<=gstart_slot;
                        state<=S_GEN;
                    end else begin bias_lane<=bias_lane+1; state<=S_BIAS_ADDR; end
                end
                S_GEN: begin
                    if (tap_last) begin
                        tap<=0; kx<=0; ky<=0; koff_x<=0; koff_y<=0; ci<=0; chbase<=0;
                        if (px_last) begin
                            gstart_word<=wword_next; gstart_slot<=wslot_next;   // 下一组从这里开始
                            state<=S_DRAIN;
                        end else begin
                            wword<=gstart_word; wslot<=gstart_slot;
                            if (ox==out_width-1) begin
                                ox<=0; base_x<=-$signed({7'd0,padding});
                                oy<=oy+1; base_y<=base_y+(stride_two ? 10'sd2 : 10'sd1);
                            end else begin
                                ox<=ox+1; base_x<=base_x+(stride_two ? 10'sd2 : 10'sd1);
                            end
                        end
                    end else begin
                        tap<=tap+1; wword<=wword_next; wslot<=wslot_next;
                        if (kx==kernel_last) begin
                            kx<=0; koff_x<=0;
                            if (ky==kernel_last) begin
                                ky<=0; koff_y<=0; ci<=ci+1;
                                if (ci[1:0]==2'd3) chbase<=chbase+plane;
                            end else begin ky<=ky+1; koff_y<=koff_y+dilation; end
                        end else begin kx<=kx+1; koff_x<=koff_x+dilation; end
                    end
                end
                S_DRAIN: begin
                    if (!pipe_busy && !s1_v) begin
                        if (group_index==group_count-1) begin
                            if (layer_index==3'd6) begin selected_slot<=0; state<=S_CCL_INIT; end
                            else begin layer_index<=layer_index+1; state<=S_LAYER; end
                        end else begin group_index<=group_index+1; bias_lane<=0; state<=S_BIAS_ADDR; end
                    end
                end
                // ---------------- CCL：每个输出槽重扫一遍，只留本轮最佳 ----------------
                S_CCL_INIT: begin
                    visited<=0; scan_index<=0; scan_x<=0; scan_y<=0; scan_class<=1; best_valid<=0;
                    best_score<=32'sh80000000; state<=S_SCAN_ADDR;
                end
                S_SCAN_ADDR: begin grid_raddr<=scan_index; state<=S_SCAN_WAIT; end
                S_SCAN_WAIT: state<=S_SCAN_TEST;
                S_SCAN_TEST: begin
                    if (!visited[scan_index] && grid_cls==scan_class) begin
                        visited[scan_index]<=1;
                        q_we<=1; q_waddr<=0; q_wdata<={scan_y,scan_x,scan_index}; qhead<=0; qtail<=1;
                        comp_min_x<=scan_x; comp_max_x<=scan_x; comp_min_y<=scan_y; comp_max_y<=scan_y;
                        comp_score<=grid_margin; state<=S_Q_ADDR;
                    end else state<=S_SCAN_NEXT;
                end
                S_Q_ADDR: begin q_raddr<=qhead; state<=S_Q_WAIT; end
                S_Q_WAIT: state<=S_Q_LOAD;
                S_Q_LOAD: begin
                    cur_y<=queue_q[16:13]; cur_x<=queue_q[12:8]; cur_idx<=queue_q[7:0];
                    qhead<=qhead+1; nb_dir<=0; state<=S_NB_ADDR;
                end
                S_NB_ADDR: begin
                    nb_x<=cur_x; nb_y<=cur_y;
                    case (nb_dir)
                        2'd0: begin nb_exists<=cur_y!=0;  nb_y<=cur_y-1; nb_idx<=cur_idx-8'd20; end
                        2'd1: begin nb_exists<=cur_y!=11; nb_y<=cur_y+1; nb_idx<=cur_idx+8'd20; end
                        2'd2: begin nb_exists<=cur_x!=0;  nb_x<=cur_x-1; nb_idx<=cur_idx-8'd1;  end
                        default: begin nb_exists<=cur_x!=19; nb_x<=cur_x+1; nb_idx<=cur_idx+8'd1; end
                    endcase
                    state<=S_NB_CHECK;
                end
                S_NB_CHECK: begin
                    if (nb_exists && !visited[nb_idx]) begin grid_raddr<=nb_idx; state<=S_NB_WAIT; end
                    else state<=S_NB_NEXT;
                end
                S_NB_WAIT: state<=S_NB_TEST;
                S_NB_TEST: begin
                    if (grid_cls==scan_class) begin
                        visited[nb_idx]<=1;
                        q_we<=1; q_waddr<=qtail; q_wdata<={nb_y,nb_x,nb_idx}; qtail<=qtail+1;
                        if (nb_x<comp_min_x) comp_min_x<=nb_x;
                        if (nb_x>comp_max_x) comp_max_x<=nb_x;
                        if (nb_y<comp_min_y) comp_min_y<=nb_y;
                        if (nb_y>comp_max_y) comp_max_y<=nb_y;
                        if (grid_margin>comp_score) comp_score<=grid_margin;
                    end
                    state<=S_NB_NEXT;
                end
                S_NB_NEXT: begin
                    if (nb_dir==3) begin
                        if (qhead<qtail) state<=S_Q_ADDR; else state<=S_COMPONENT;
                    end else begin nb_dir<=nb_dir+1; state<=S_NB_ADDR; end
                end
                S_COMPONENT: begin
                    cand_x0<=comp_min_x*12'd96; cand_x1<=(comp_max_x+12'd1)*12'd96;
                    cand_y0<=comp_min_y*12'd96;
                    cand_y1<=comp_max_y==11 ? 12'd1080 : (comp_max_y+12'd1)*12'd96;
                    nms_index<=0; state<=S_NMS_START;
                end
                // NMS：与已选的同类框 5*交 > 2*并 则抑制
                S_NMS_START: begin
                    if (nms_index>=selected_slot) state<=S_BEST;
                    else if (work_class[nms_index*2+:2]!=scan_class) nms_index<=nms_index+1;
                    else state<=S_NMS_SEL;
                end
                S_NMS_SEL: begin
                    chosen_x0<=work_x0[nms_index*12+:12]; chosen_y0<=work_y0[nms_index*12+:12];
                    chosen_x1<=work_x1[nms_index*12+:12]; chosen_y1<=work_y1[nms_index*12+:12];
                    state<=S_NMS_EDGE;
                end
                S_NMS_EDGE: begin
                    isect_l<=cand_x0>chosen_x0 ? cand_x0 : chosen_x0;
                    isect_t<=cand_y0>chosen_y0 ? cand_y0 : chosen_y0;
                    isect_r<=cand_x1<chosen_x1 ? cand_x1 : chosen_x1;
                    isect_b<=cand_y1<chosen_y1 ? cand_y1 : chosen_y1;
                    cand_w<=cand_x1-cand_x0; cand_h<=cand_y1-cand_y0;
                    chosen_w<=chosen_x1-chosen_x0; chosen_h<=chosen_y1-chosen_y0;
                    state<=S_NMS_DIMS;
                end
                S_NMS_DIMS: begin
                    isect_w<=isect_r>isect_l ? isect_r-isect_l : 12'd0;
                    isect_h<=isect_b>isect_t ? isect_b-isect_t : 12'd0;
                    state<=S_NMS_MUL;
                end
                S_NMS_MUL: begin
                    isect_area<=isect_w*isect_h; cand_area<=cand_w*cand_h; chosen_area<=chosen_w*chosen_h;
                    state<=S_NMS_SUM;
                end
                S_NMS_SUM: begin
                    five_isect<=({3'd0,isect_area}<<2)+{3'd0,isect_area};
                    twice_union<={({2'd0,cand_area}+{2'd0,chosen_area}-{2'd0,isect_area}),1'b0};
                    state<=S_NMS_TEST;
                end
                S_NMS_TEST: begin
                    if (five_isect>twice_union) state<=S_SCAN_NEXT;
                    else begin nms_index<=nms_index+1; state<=S_NMS_START; end
                end
                S_BEST: begin
                    if (!best_valid || comp_score>best_score) begin    // 同分保持发现顺序
                        best_valid<=1; best_score<=comp_score; best_class<=scan_class;
                        best_x0<=cand_x0; best_y0<=cand_y0; best_x1<=cand_x1; best_y1<=cand_y1;
                    end
                    state<=S_SCAN_NEXT;
                end
                S_SCAN_NEXT: begin
                    if (scan_index==239) state<=S_CLASS_DONE;
                    else begin
                        scan_index<=scan_index+1;
                        if (scan_x==19) begin scan_x<=0; scan_y<=scan_y+1; end else scan_x<=scan_x+1;
                        state<=S_SCAN_ADDR;
                    end
                end
                S_CLASS_DONE: begin
                    if (scan_class==1) begin
                        scan_class<=2; scan_index<=0; scan_x<=0; scan_y<=0; state<=S_SCAN_ADDR;
                    end else state<=S_PASS_DONE;
                end
                S_PASS_DONE: begin
                    if (best_valid) begin
                        work_x0[selected_slot*12+:12]<=best_x0; work_y0[selected_slot*12+:12]<=best_y0;
                        work_x1[selected_slot*12+:12]<=best_x1; work_y1[selected_slot*12+:12]<=best_y1;
                        work_class[selected_slot*2+:2]<=best_class; work_score[selected_slot*32+:32]<=best_score;
                        work_valid[selected_slot]<=1;
                        if (selected_slot==3) state<=S_PUBLISH;
                        else begin selected_slot<=selected_slot+1; state<=S_CCL_INIT; end
                    end else state<=S_PUBLISH;
                end
                S_PUBLISH: begin
                    obj_x0<=work_x0; obj_y0<=work_y0; obj_x1<=work_x1; obj_y1<=work_y1;
                    obj_cls<=work_class; obj_score<=work_score; obj_valid<=work_valid; obj_low<=low_work;
                    pub<=1; result_frame_id<=active_frame_id; cycles_last<=cycle_count;
                    state<=S_IDLE;
                end
                default: state<=S_IDLE;
            endcase
            // 放在 case 之后：采集残缺放弃优先于一切
            if (vblank && capture_active) state<=S_IDLE;
        end
    end
endmodule


// =====================================================================================
// grid_post（2026-10-21）：grid_det 输出框的后处理。放在本文件里是为了 TD 文件清单不变（同 face_smooth）。
//
// 为什么。10-20 22:47 板上录像（v8c2_s3，阈值 1155）离线重放与板上蓝框逐帧一致，再对 YOLOX：
//   * 碎：单人帧 41% 出 >1 个框。高阈值 CCL 只留躯干最亮的几格，头/腿那几格分数在 700~1155，
//     不连通就成 2~3 个框，或整框缩在身体中段（上沿中位低 113 px、下沿高 108 px）。
//   * 抖：一格 96 px，框边逐次发布跳格；相邻两次发布四边位移比 YOLOX 多 41 px。
// 做什么（每次 grid_det pub 跑一遍，<300 拍，原子发布）：
//   1. 竖向延伸：人框上一行/下一行在框的列范围内有任一格 obj_low=1 就把边推过去，直到推不动。
//      只往上下长：整图用低阈值做 CCL 往左右也会长（录像里左边平均多一格），所以只借低阈值掩码长高度。
//   2. 合并：两个人框列区间至少重叠一列、纵向空隙 <= GAP_Y 行 -> 外接框，反复直到不变。
//      10-22 加横向：横向空隙 <= GAP_X 列（0 = 贴着）且纵向重叠*4 >= MG_OV*较矮框的高 -> 也合并（GAP_X=-1 关）。
//      为什么：10-22 22:01 录像近处（人被画面截断）一人碎成左右 2~3 个竖条，旧规则只并上下。重放（/c/tmp/grid_1022/ev22.py）
//      GAP_X=1 MG_OV=2：近处碎 11.2% -> 1.1%、IoU>=0.5 50.7 -> 57.1%，中距离碎 7.4 -> 0.4%，空场误报不变；
//      代价在多人：dataset_v8 板上多人帧人召回 830 -> 741 / 2536，挨着站的两人会并成一框。
//      合并判据 mg_ok 先打进 mg_q 再用（每对多 1 拍）：新加的高度/重叠比较不进 c_* 的写使能路径。
//   3. 跟踪（匹配规则同 face_smooth：中心互含，按槽顺序取第一个）：本帧框找未用、同类的旧轨迹，
//      中心走 1/2^SC、尺寸走 1/2^SS，没找到就新建。连续命中 CONFIRM 次才显示；已显示的漏检时
//      保持 HOLD 次发布，但和本帧任一框相交就不保持（否则一个人身上叠两个框）。
// 录像重放（/c/tmp/grid_1020/eval_post2.py）：碎 41% -> 3.4%，抖 41 -> 18 px，IoU>=0.5 40% -> 59%，
// 上下沿偏差 +113/-108 -> 0/-6 px，空场误报 3.8% 不变。dataset_v8 test（单帧，不含跟踪）：
// IoU>=0.5 53.6% -> 62.2%，碎 43.9% -> 7.1%。
// !! 逐位参考是 /c/tmp/grid_1022/post.py 的 post_frame + TrackR（10-22 起；grid_1020 那份是 GAP_X 之前的），改一边要改两边。
// 输入框必须是 grid_det 的格对齐框（坐标是 96 的倍数，y1 可为 1080）。out_vld 可以有空洞。
// =====================================================================================
module grid_post #(
    parameter integer GAP_Y   = 1,          // 合并的纵向空隙（行）
    parameter integer SC      = 2,          // 中心每次走 1/2^SC
    parameter integer SS      = 3,          // 尺寸每次走 1/2^SS
    parameter integer HOLD    = 4,          // 漏检保持几次发布（15 Hz，4 = 0.27 s）
    parameter integer CONFIRM = 2,          // 连续命中几次才显示（<= 15）
    parameter integer GAP_X   = -1,         // 10-22 横向合并：横向空隙 <= GAP_X 列（-1 = 关）
    parameter integer MG_OV   = 2           //   且 纵向重叠*4 >= MG_OV*较矮框高（2 = 至少重叠半个矮框）
) (
    input  wire         clk, input wire rst_n,
    input  wire         pub,                // grid_det 的 pub：in_* 已是新值
    input  wire [47:0]  in_x0, in_y0, in_x1, in_y1,   // 4 x 12bit，x1/y1 不含
    input  wire [7:0]   in_cls,
    input  wire [3:0]   in_vld,
    input  wire [239:0] in_low,
    output reg  [47:0]  out_x0, out_y0, out_x1, out_y1,
    output reg  [7:0]   out_cls,
    output reg  [3:0]   out_vld,
    output reg          out_pub             // 单拍，out_* 只在这一拍切换
);
    localparam S_IDLE=0, S_UP=1, S_DN=2, S_MG=3, S_OB=4, S_TD=5, S_TM=6, S_TW=7, S_NB=8, S_HB=9, S_COM=10;
    localparam [4:0] GAP5 = GAP_Y;          // 状态单位 1/16 px，中心存 2 倍
    localparam [5:0] GAPX6 = (GAP_X < 0) ? 6'd0 : GAP_X;
    reg [3:0] st;
    reg [2:0] i, j, k, mk, n_cnt, n_det;    // 3 位：循环数到 4 结束
    reg       m_hit;
    reg       mg_q, mg_ph;                  // 10-22：合并判据打一拍
    reg       up_q, dn_q, hold_q, ph;       // 10-23：延伸/保持判据也打一拍（板上 -0.082/-0.107 ns 就在这两条），ph = 判据相位
    reg [3:0] used;
    reg [239:0] low;

    // 本帧框，格坐标（右/下不含）
    reg [4:0] c_x0 [0:3]; reg [4:0] c_x1 [0:3];
    reg [3:0] c_y0 [0:3]; reg [3:0] c_y1 [0:3];
    reg [1:0] c_cls [0:3];
    reg [3:0] c_v;
    // 轨迹（上次发布）与新集合；有效槽总是从 0 开始连续
    reg [15:0] t_cx [0:3]; reg [15:0] t_cy [0:3]; reg [15:0] t_sx [0:3]; reg [15:0] t_sy [0:3];
    reg [3:0]  t_hits [0:3]; reg [3:0] t_miss [0:3]; reg [1:0] t_cls [0:3];
    reg [3:0]  t_v;
    reg [15:0] n_cx [0:3]; reg [15:0] n_cy [0:3]; reg [15:0] n_sx [0:3]; reg [15:0] n_sy [0:3];
    reg [3:0]  n_hits [0:3]; reg [3:0] n_miss [0:3]; reg [1:0] n_cls [0:3];

    // 96 的倍数 -> 格：v/96 = (v>>5)/3，(x*43)>>7 对 3 的倍数 x<=63 精确
    function [4:0] to_cell; input [11:0] v; reg [12:0] p;
        begin p = v[11:5]*6'd43; to_cell = p[11:7]; end endfunction
    function [11:0] px; input [4:0] c;
        begin px = {c, 6'd0} + {1'b0, c, 5'd0}; end endfunction
    function [19:0] colmask; input [4:0] a, b;
        begin colmask = ({20{1'b1}} << a) & ~({20{1'b1}} << b); end endfunction
    // 轨迹 -> 框 {x0,y0,x1,y1}，低边 floor 到 0、高边夹到画面
    function [47:0] tbox; input [15:0] cx, cy, sx, sy;
        reg signed [17:0] lx, ly; reg [16:0] hx, hy;
        begin
            lx = $signed({2'b0, cx}) - $signed({2'b0, sx});
            ly = $signed({2'b0, cy}) - $signed({2'b0, sy});
            hx = {1'b0, cx} + {1'b0, sx};
            hy = {1'b0, cy} + {1'b0, sy};
            tbox = {lx[17] ? 12'd0 : lx[16:5], ly[17] ? 12'd0 : ly[16:5],
                    hx[16:5] > 12'd1920 ? 12'd1920 : hx[16:5], hy[16:5] > 12'd1080 ? 12'd1080 : hy[16:5]};
        end endfunction

    // ---- 竖向延伸：当前槽 i 的上一行 / 下一行 ----
    wire [1:0]  ii = i[1:0], jj = j[1:0], kk = k[1:0];
    wire [19:0] cm     = colmask(c_x0[ii], c_x1[ii]);
    wire [3:0]  up_r   = c_y0[ii]==4'd0  ? 4'd0  : c_y0[ii]-4'd1;
    wire [3:0]  dn_r   = c_y1[ii]==4'd12 ? 4'd11 : c_y1[ii];
    wire        up_go  = c_y0[ii]!=4'd0  && |(low[up_r*20 +: 20] & cm);
    wire        dn_go  = c_y1[ii]!=4'd12 && |(low[dn_r*20 +: 20] & cm);
    wire        is_person = c_v[ii] && c_cls[ii]==2'd1;

    // ---- 合并：槽 i、j ----
    wire [4:0] mx0 = c_x0[ii] > c_x0[jj] ? c_x0[ii] : c_x0[jj];
    wire [4:0] mx1 = c_x1[ii] < c_x1[jj] ? c_x1[ii] : c_x1[jj];
    wire [3:0] my0 = c_y0[ii] > c_y0[jj] ? c_y0[ii] : c_y0[jj];
    wire [3:0] my1 = c_y1[ii] < c_y1[jj] ? c_y1[ii] : c_y1[jj];
    wire [3:0] h_i  = c_y1[ii] - c_y0[ii];
    wire [3:0] h_j  = c_y1[jj] - c_y0[jj];
    wire [3:0] hmin = h_i < h_j ? h_i : h_j;
    wire [3:0] yov  = my1 - my0;
    wire mg_hx = (GAP_X >= 0) && ({1'b0, mx0} <= {1'b0, mx1} + GAPX6) && (my0 <= my1) &&
                 ({4'd0, yov, 2'b00} >= MG_OV * hmin);
    wire mg_ok = c_v[ii] && c_v[jj] && c_cls[ii]==2'd1 && c_cls[jj]==2'd1 &&
                 ((mx0 < mx1 && {1'b0, my0} <= {1'b0, my1} + GAP5) || mg_hx);

    // ---- 跟踪：本帧框 i（像素）、旧轨迹框 ob、新集合框 nb 都先打一拍（每拍最多两级加法，pclkx1 150 MHz） ----
    wire [11:0] cx0 = px(c_x0[ii]), cx1 = px(c_x1[ii]), cy0 = px({1'b0, c_y0[ii]});
    wire [11:0] cy1 = c_y1[ii]==4'd12 ? 12'd1080 : px({1'b0, c_y1[ii]});
    reg  [11:0] dx0, dx1, dy0, dy1;            // S_TD 选中本帧框 i 时锁存
    reg  [12:0] d2x, d2y;
    reg  [47:0] ob [0:3];                      // S_OB 锁存：本次跟踪期间旧轨迹不变
    reg  [47:0] nb [0:3];                      // S_NB 锁存本帧框的新状态；S_HB 保持的轨迹直接抄 ob
    genvar g;
    wire [11:0] ox0 = ob[kk][47:36], oy0 = ob[kk][35:24], ox1 = ob[kk][23:12], oy1 = ob[kk][11:0];
    wire [12:0] o2x = {1'b0, ox0} + {1'b0, ox1}, o2y = {1'b0, oy0} + {1'b0, oy1};
    wire d_in_o = {ox0, 1'b0} <= d2x && d2x <= {ox1, 1'b0} && {oy0, 1'b0} <= d2y && d2y <= {oy1, 1'b0};
    wire o_in_d = {dx0, 1'b0} <= o2x && o2x <= {dx1, 1'b0} && {dy0, 1'b0} <= o2y && o2y <= {dy1, 1'b0};
    wire m_now  = t_v[kk] && !used[kk] && t_cls[kk]==c_cls[ii] && (d_in_o || o_in_d);
    // 本帧测量（状态单位）与 IIR 一步
    reg  [15:0] m_sx, m_sy;                    // S_TD 锁存
    wire [15:0] m_cx = {d2x[11:0], 4'd0}, m_cy = {d2y[11:0], 4'd0};
    wire [1:0]  mm = mk[1:0];
    wire signed [16:0] e_cx = $signed({1'b0, m_cx}) - $signed({1'b0, t_cx[mm]});
    wire signed [16:0] e_cy = $signed({1'b0, m_cy}) - $signed({1'b0, t_cy[mm]});
    wire signed [16:0] e_sx = $signed({1'b0, m_sx}) - $signed({1'b0, t_sx[mm]});
    wire signed [16:0] e_sy = $signed({1'b0, m_sy}) - $signed({1'b0, t_sy[mm]});
    wire signed [16:0] st_cx = e_cx >>> SC, st_cy = e_cy >>> SC, st_sx = e_sx >>> SS, st_sy = e_sy >>> SS;
    // 保持：旧轨迹 k 和本帧框（新集合前 n_det 个）相交就不保持
    wire [3:0] isect;
    generate for (g = 0; g < 4; g = g + 1) begin : g_isect
        wire [11:0] bx0 = nb[g][47:36], by0 = nb[g][35:24], bx1 = nb[g][23:12], by1 = nb[g][11:0];
        assign isect[g] = g < n_det && (ox1 < bx1 ? ox1 : bx1) > (ox0 > bx0 ? ox0 : bx0)
                                    && (oy1 < by1 ? oy1 : by1) > (oy0 > by0 ? oy0 : by0);
    end endgenerate
    wire hold_ok = t_v[kk] && !used[kk] && t_hits[kk] >= CONFIRM && t_miss[kk] < HOLD && !(|isect) && n_cnt < 3'd4;

    integer q;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            st <= S_IDLE; i <= 0; j <= 0; k <= 0; mk <= 0; n_cnt <= 0; n_det <= 0; m_hit <= 0; used <= 0;
            mg_q <= 0; mg_ph <= 0; up_q <= 0; dn_q <= 0; hold_q <= 0; ph <= 0;
            low <= 0; c_v <= 0; t_v <= 0;
            dx0 <= 0; dx1 <= 0; dy0 <= 0; dy1 <= 0; d2x <= 0; d2y <= 0; m_sx <= 0; m_sy <= 0;
            out_x0 <= 0; out_y0 <= 0; out_x1 <= 0; out_y1 <= 0; out_cls <= 0; out_vld <= 0; out_pub <= 0;
            for (q = 0; q < 4; q = q + 1) begin
                c_x0[q] <= 0; c_x1[q] <= 0; c_y0[q] <= 0; c_y1[q] <= 0; c_cls[q] <= 0;
                t_cx[q] <= 0; t_cy[q] <= 0; t_sx[q] <= 0; t_sy[q] <= 0; t_hits[q] <= 0; t_miss[q] <= 0; t_cls[q] <= 0;
                n_cx[q] <= 0; n_cy[q] <= 0; n_sx[q] <= 0; n_sy[q] <= 0; n_hits[q] <= 0; n_miss[q] <= 0; n_cls[q] <= 0;
                ob[q] <= 0; nb[q] <= 0;
            end
        end else begin
            out_pub <= 0;
            mg_q <= mg_ok; up_q <= up_go; dn_q <= dn_go; hold_q <= hold_ok;
            case (st)
            S_IDLE: if (pub) begin
                low <= in_low; c_v <= in_vld;
                for (q = 0; q < 4; q = q + 1) begin
                    c_x0[q] <= to_cell(in_x0[q*12 +: 12]); c_x1[q] <= to_cell(in_x1[q*12 +: 12]);
                    c_y0[q] <= to_cell(in_y0[q*12 +: 12]);
                    c_y1[q] <= in_y1[q*12 +: 12]==12'd1080 ? 4'd12 : to_cell(in_y1[q*12 +: 12]);
                    c_cls[q] <= in_cls[q*2 +: 2];
                end
                i <= 0; mg_ph <= 0; ph <= 0; st <= S_UP;
            end
            S_UP: begin
                if (i == 3'd4) begin i <= 0; j <= 1; st <= S_MG; end
                else if (!is_person) i <= i+1;
                else if (!ph) ph <= 1'b1;                 // 这拍 c_*/i 不动，up_q 拿到判据
                else begin
                    ph <= 1'b0;
                    if (up_q) c_y0[ii] <= c_y0[ii]-4'd1;
                    else st <= S_DN;
                end
            end
            S_DN: if (!ph) ph <= 1'b1;
            else begin
                ph <= 1'b0;
                if (dn_q) c_y1[ii] <= c_y1[ii]+4'd1;
                else begin i <= i+1; st <= S_UP; end
            end
            S_MG: if (!mg_ph) mg_ph <= 1'b1;            // 这拍 i/j/c_* 不动，mg_q 拿到这一对的判据
            else begin
                mg_ph <= 1'b0;
                if (mg_q) begin
                    c_x0[ii] <= c_x0[ii] < c_x0[jj] ? c_x0[ii] : c_x0[jj];
                    c_y0[ii] <= c_y0[ii] < c_y0[jj] ? c_y0[ii] : c_y0[jj];
                    c_x1[ii] <= c_x1[ii] > c_x1[jj] ? c_x1[ii] : c_x1[jj];
                    c_y1[ii] <= c_y1[ii] > c_y1[jj] ? c_y1[ii] : c_y1[jj];
                    c_v[jj] <= 1'b0;
                    i <= 0; j <= 1;                       // 从头再扫，直到一整遍没有合并
                end else if (j == 3'd3) begin
                    if (i == 3'd2) begin i <= 0; n_cnt <= 0; used <= 0; st <= S_OB; end
                    else begin i <= i+1; j <= i+2; end
                end else j <= j+1;
            end
            S_OB: begin
                for (q = 0; q < 4; q = q + 1) ob[q] <= tbox(t_cx[q], t_cy[q], t_sx[q], t_sy[q]);
                st <= S_TD;
            end
            S_TD: begin                                    // 本帧框 i（槽顺序）
                if (i == 3'd4) begin n_det <= n_cnt; st <= S_NB; end
                else if (!c_v[ii]) i <= i+1;
                else begin
                    dx0 <= cx0; dx1 <= cx1; dy0 <= cy0; dy1 <= cy1;
                    d2x <= {1'b0, cx0} + {1'b0, cx1}; d2y <= {1'b0, cy0} + {1'b0, cy1};
                    m_sx <= {cx1-cx0, 4'd0}; m_sy <= {cy1-cy0, 4'd0};
                    k <= 0; st <= S_TM;
                end
            end
            S_NB: begin
                for (q = 0; q < 4; q = q + 1) nb[q] <= tbox(n_cx[q], n_cy[q], n_sx[q], n_sy[q]);
                k <= 0; ph <= 0; st <= S_HB;
            end
            S_TM: begin                                    // 旧轨迹 k，取第一个匹配
                if (m_now) begin mk <= k; m_hit <= 1'b1; st <= S_TW; end
                else if (k == 3'd3) begin m_hit <= 1'b0; st <= S_TW; end
                else k <= k+1;
            end
            S_TW: begin
                n_cls[n_cnt[1:0]] <= c_cls[ii];
                n_miss[n_cnt[1:0]] <= 4'd0;
                if (m_hit) begin
                    used[mm] <= 1'b1;
                    n_cx[n_cnt[1:0]] <= t_cx[mm] + st_cx[15:0];
                    n_cy[n_cnt[1:0]] <= t_cy[mm] + st_cy[15:0];
                    n_sx[n_cnt[1:0]] <= t_sx[mm] + st_sx[15:0];
                    n_sy[n_cnt[1:0]] <= t_sy[mm] + st_sy[15:0];
                    n_hits[n_cnt[1:0]] <= t_hits[mm]==4'd15 ? 4'd15 : t_hits[mm]+4'd1;
                end else begin
                    n_cx[n_cnt[1:0]] <= m_cx; n_cy[n_cnt[1:0]] <= m_cy;
                    n_sx[n_cnt[1:0]] <= m_sx; n_sy[n_cnt[1:0]] <= m_sy;
                    n_hits[n_cnt[1:0]] <= 4'd1;
                end
                n_cnt <= n_cnt+1; i <= i+1; st <= S_TD;
            end
            S_HB: if (!ph) ph <= 1'b1;                     // 旧轨迹 k 是否保持（旧顺序）；这拍 hold_q 拿判据
            else begin
                ph <= 1'b0;
                if (hold_q) begin
                    n_cx[n_cnt[1:0]] <= t_cx[kk]; n_cy[n_cnt[1:0]] <= t_cy[kk];
                    n_sx[n_cnt[1:0]] <= t_sx[kk]; n_sy[n_cnt[1:0]] <= t_sy[kk];
                    n_hits[n_cnt[1:0]] <= t_hits[kk]; n_miss[n_cnt[1:0]] <= t_miss[kk]+4'd1;
                    n_cls[n_cnt[1:0]] <= t_cls[kk];
                    nb[n_cnt[1:0]] <= ob[kk];             // 状态没变，框就是旧框
                    n_cnt <= n_cnt+1;
                end
                if (k == 3'd3) st <= S_COM; else k <= k+1;
            end
            S_COM: begin
                for (q = 0; q < 4; q = q + 1) begin
                    t_cx[q] <= n_cx[q]; t_cy[q] <= n_cy[q]; t_sx[q] <= n_sx[q]; t_sy[q] <= n_sy[q];
                    t_hits[q] <= n_hits[q]; t_miss[q] <= n_miss[q]; t_cls[q] <= n_cls[q];
                    t_v[q] <= q < n_cnt;
                    out_vld[q] <= q < n_cnt && n_hits[q] >= CONFIRM;
                    out_x0[q*12 +: 12] <= nb[q][47:36]; out_y0[q*12 +: 12] <= nb[q][35:24];
                    out_x1[q*12 +: 12] <= nb[q][23:12]; out_y1[q*12 +: 12] <= nb[q][11:0];
                    out_cls[q*2 +: 2] <= n_cls[q];
                end
                out_pub <= 1'b1; st <= S_IDLE;
            end
            default: st <= S_IDLE;
            endcase
        end
    end
endmodule


// =====================================================================================
// gd_aim（2026-10-22）：从 grid_post 的人框里挑一个，给云台射灯瞄（system_top 里接 trk_range 的 cx/cy）。
// 放在本文件里同 grid_post：TD 文件清单不变。
//
// 用户 10-22：「舵机射灯追踪接入到轮廓识别」。之前射灯跟的是运动跟踪器（品红框，10-21 起不画）+ 人脸。
// 选框规则（每次 in_pub 一遍）：
//   1. 上次发布的瞄点落在某个人框里 -> 只在这些框里挑；都不含 -> 全部人框里挑。
//      粘住上一个目标：两个人、或一人碎成左右两框时，瞄点不会每次发布来回跳。
//   2. 挑「宽+高」最大的（不用面积：省乘法；碎框里最大那块总在人身上）。同分取槽号小的。
// 瞄点 = ((x0+x1)/2, y0+(y1-y0)/4)：胸口。近处下沿被画面截掉时落在脖子附近，同样在人身上。
// 时序：4 个槽逐拍送进 3 级流水（取槽 -> 算中心/尺寸/含点 -> 比较），每级不超过两条进位链，
// 不拼 4 路组合比较（pclkx1 紧，见 fpga_blanking_slack_fallacy）。in_pub 后第 7 拍原子发布 aim_*。
// in_* 在两次 in_pub 之间保持（grid_post 的 out_* 只在 out_pub 那拍切换），扫描期间读的是同一份。
// !! 逐位参考 /c/tmp/grid_1022/aimref.py 的 GdAim（tb_gd_aim.v 对照），改一边要改两边。
// =====================================================================================
module gd_aim (
    input  wire         clk, input wire rst_n,
    input  wire         in_pub,             // grid_post 的 out_pub
    input  wire [47:0]  in_x0, in_y0, in_x1, in_y1,   // 4 x 12bit，x1/y1 不含
    input  wire [7:0]   in_cls,
    input  wire [3:0]   in_vld,
    output reg  [11:0]  aim_x, aim_y,       // 像素，aim_v=0 时保持旧值
    output reg          aim_v,              // 本次发布有人框
    output reg          aim_pub             // 单拍，aim_* 只在这一拍切换
);
    reg  [2:0]  n;                          // 0..3 取槽，7 = 空闲
    reg         a_v, b_v, c_v;              // 流水各级有效
    reg         c_last;
    reg  [11:0] a_x0, a_y0, a_x1, a_y1;
    reg         a_p, a_last;
    reg  [11:0] b_cx, b_cy;
    reg  [12:0] b_sz;
    reg         b_p, b_in, b_last;
    reg  [11:0] k_x, k_y;                   // 目前最好
    reg  [12:0] k_sz;
    reg         k_ok, k_in;

    wire [1:0]  s = n[1:0];
    wire [11:0] dy = a_y1 - a_y0;
    wire        better = b_p && (!k_ok || (b_in && !k_in) || (b_in == k_in && b_sz > k_sz));

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            n <= 3'd7; a_v <= 1'b0; b_v <= 1'b0; c_v <= 1'b0; c_last <= 1'b0;
            a_x0 <= 12'd0; a_y0 <= 12'd0; a_x1 <= 12'd0; a_y1 <= 12'd0; a_p <= 1'b0; a_last <= 1'b0;
            b_cx <= 12'd0; b_cy <= 12'd0; b_sz <= 13'd0; b_p <= 1'b0; b_in <= 1'b0; b_last <= 1'b0;
            k_x <= 12'd0; k_y <= 12'd0; k_sz <= 13'd0; k_ok <= 1'b0; k_in <= 1'b0;
            aim_x <= 12'd960; aim_y <= 12'd540; aim_v <= 1'b0; aim_pub <= 1'b0;
        end else begin
            aim_pub <= 1'b0;
            // 级 0：取槽
            a_v <= 1'b0;
            if (in_pub) n <= 3'd0;
            else if (n != 3'd7) begin
                a_v    <= 1'b1;
                a_last <= (n == 3'd3);
                a_x0   <= in_x0[s*12 +: 12]; a_y0 <= in_y0[s*12 +: 12];
                a_x1   <= in_x1[s*12 +: 12]; a_y1 <= in_y1[s*12 +: 12];
                a_p    <= in_vld[s] && (in_cls[s*2 +: 2] == 2'd1);
                n      <= (n == 3'd3) ? 3'd7 : n + 3'd1;
            end
            // 级 1：中心、尺寸、含不含上次瞄点
            b_v    <= a_v; b_last <= a_last; b_p <= a_p;
            b_cx   <= ({1'b0, a_x0} + {1'b0, a_x1}) >> 1;
            b_cy   <= a_y0 + {2'b00, dy[11:2]};
            b_sz   <= {1'b0, a_x1 - a_x0} + {1'b0, dy};
            b_in   <= aim_v && (a_x0 <= aim_x) && (aim_x < a_x1) && (a_y0 <= aim_y) && (aim_y < a_y1);
            // 级 2：比较
            c_v <= b_v; c_last <= b_v && b_last;
            if (b_v) begin
                if (better) begin k_ok <= 1'b1; k_in <= b_in; k_sz <= b_sz; k_x <= b_cx; k_y <= b_cy; end
            end else if (!c_v) begin
                k_ok <= 1'b0; k_in <= 1'b0; k_sz <= 13'd0;   // 两次扫描之间清零
            end
            // 发布
            if (c_last) begin
                aim_pub <= 1'b1; aim_v <= k_ok;
                if (k_ok) begin aim_x <= k_x; aim_y <= k_y; end
            end
        end
    end
endmodule
// =====================================================================================
// gd_tof_gate（2026-10-23）：ToF 测到镜头前近处有东西 -> 清掉 grid_post 的人框（蓝框 / gd_person / gd_aim 一起）。
// 放在本文件里同 grid_post：TD 文件清单不变。
//
// 用户 10-23：「近处的其他物品很容易被误判成人的轮廓」。17:04 录像板上蓝框：手 54%、袖子 63%、瓶子 57% 的帧。
// 网络只看 160x90 灰度：贴镜头的白袖子和 3 m 外白毛衣的躯干是同一种竖亮块；离线查过清晰度、框几何、框内对比度，
// 都分不开（/c/tmp/grid_1023/sep.py）。ToF 是板上唯一直接量距离的东西：安防模式下 16x16 全视锥（27°）、短程。
// 代理估计（板上蓝框与画面中心 r442 px 圆相交，没算相机-ToF 偏置）：近物有框帧 40% -> 6~15%；
// 漏网的是视锥外（画面边缘）的近物。代价：人走进 NEAR_MM 以内也没有蓝框（人脸红框不受影响）。
//
// 规则：
//   近读数 = tof_stb 那拍 { code 0/6/11 且 mm < NEAR_MM } 或 code 3/13（过近，mm 不可信）。
//            1 sigma / 2 signal / 4 越界 / 7 回绕（远物读成近）等都不算。
//   每个近读数把 hold 重装成 HOLD_MS；hold != 0 = 近。HOLD 要盖住 grid_post 的 HOLD 4 次发布（0.27 s）
//   + 一次测距间隔（~60 ms），否则东西移开后还在保持的轨迹会闪一下。
//   连续近满 MAX_MS -> 放行（视锥里有固定障碍物：讲台、外壳窗口串扰），直到 HOLD_MS 没有近读数才重新武装。
//   失败方向都是「和没有这个门一样」：固定障碍物、ToF 不出读数（TOF_EN=0、I2C 挂了）都放行，蓝框不会永久消失。
//   en = 0（非安防）：不挡，计时器清零。
// 原子性：门只在 pub 那拍切换（pub ? gate_q : blk），grid_post 的 out_* 也只在那拍切换，
// 下游（det_overlay / gd_aim 发布后扫 4 拍 / gd_person）两次发布之间读到的是同一份。
// !! 测试台 /c/tmp/grid_1023/tb_tof_gate.v（run_gate.sh：小参数全规则 + 工程参数 hold + 变异全红）。
//
// 10-23 晚：20:55 录像里门几乎没挡（离线框碰中心锥时板上照样有框 91%，没门的 17:04 是 88%），
// 安防页看不到 ToF，分不出「一直近 -> 10 s 后放行」和「近物根本没读到」。dbg_txt = 安防页 TOF: 行的 12 个字符
//   "dddd cc S   "  dddd = 最近一次读数 mm（>9999 显示 9999，上电还没读数 ----）
//                  cc   = ULD 状态号 00..13，255 显示 --，其他 ??
//                  S    = B 正在挡 / R 一直近已放行 / - 没挡 / X 超过 1 s 没有读数（ToF 没在测）
// 读数在 tof_stb 那拍锁存，二进制转十进制用 14 拍逐位移位（加 3 法），不进任何组合长链。
// =====================================================================================
module gd_tof_gate #(
    parameter integer CLK_HZ  = 150000000,
    parameter integer NEAR_MM = 800,
    parameter integer HOLD_MS = 600,
    parameter integer MAX_MS  = 10000
)(
    input  wire         clk, input wire rst_n,
    input  wire         en,                 // sec_mode
    input  wire         tof_stb,            // 单拍，tof_mm / tof_code 这拍有效
    input  wire [15:0]  tof_mm,
    input  wire [7:0]   tof_code,           // ULD 状态号（vl53l1x_ctrl uld_status）
    input  wire         pub,                // grid_post 的 out_pub
    input  wire [3:0]   in_vld,
    output wire [3:0]   out_vld,
    output reg          blk,                // 当前这份发布被挡
    output reg  [95:0]  dbg_txt             // 安防页 "TOF:" 后面的 12 个字符，见头注释
);
    localparam integer TICK = CLK_HZ / 1000;
    reg  [17:0] pre;                        // 1 ms 分频（CLK_HZ <= 262 MHz）
    reg  [15:0] hold;                       // ms
    reg  [15:0] run;                        // 连续近了多少 ms
    reg         rel;                        // 放行
    reg         gate_q;

    wire ms      = (pre == TICK - 1);
    wire near_rd = tof_stb && ((tof_code == 8'd3) || (tof_code == 8'd13) ||
                   ((tof_code == 8'd0 || tof_code == 8'd6 || tof_code == 8'd11) && tof_mm < NEAR_MM));

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            pre <= 18'd0; hold <= 16'd0; run <= 16'd0; rel <= 1'b0; gate_q <= 1'b0; blk <= 1'b0;
        end else begin
            pre <= ms ? 18'd0 : pre + 18'd1;
            if (!en) begin
                hold <= 16'd0; run <= 16'd0; rel <= 1'b0;
            end else begin
                if (near_rd) hold <= HOLD_MS;
                else if (ms && hold != 16'd0) hold <= hold - 16'd1;
                if (hold == 16'd0) begin
                    run <= 16'd0; rel <= 1'b0;
                end else if (ms) begin
                    if (run == MAX_MS) rel <= 1'b1;
                    else run <= run + 16'd1;
                end
            end
            gate_q <= en && hold != 16'd0 && !rel;
            if (pub) blk <= gate_q;
        end
    end
    assign out_vld = in_vld & ~{4{pub ? gate_q : blk}};

    // ---- 调试读数 ----
    reg  [7:0]  d_code;
    reg         d_seen;                     // 上电后有过读数
    reg  [9:0]  age;                        // 距上次读数 ms，饱和在 1000
    reg  [13:0] bin;                        // 加 3 法移位
    reg  [15:0] bcd, d_bcd;
    reg  [3:0]  bc;                         // 剩余移位拍数，0 = 空闲

    function [3:0] add3(input [3:0] n); add3 = (n >= 4'd5) ? n + 4'd3 : n; endfunction
    wire [15:0] bcd_adj = {add3(bcd[15:12]), add3(bcd[11:8]), add3(bcd[7:4]), add3(bcd[3:0])};
    wire [7:0]  st_ch = (age == 10'd1000) ? "X" : rel ? "R" : gate_q ? "B" : "-";
    wire [15:0] cd_ch = (d_code == 8'd255) ? "--" : (d_code > 8'd13) ? "??" :
                        (d_code >= 8'd10) ? {"1", 8'h26 + d_code} : {"0", 8'h30 + d_code};
    wire [31:0] mm_ch = d_seen ? {4'h3, d_bcd[15:12], 4'h3, d_bcd[11:8], 4'h3, d_bcd[7:4], 4'h3, d_bcd[3:0]} : "----";

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            d_code <= 8'd255; d_seen <= 1'b0; age <= 10'd1000; bin <= 14'd0; bcd <= 16'd0; d_bcd <= 16'd0; bc <= 4'd0;
            dbg_txt <= {12{8'h20}};
        end else begin
            if (tof_stb) begin
                d_code <= tof_code; d_seen <= 1'b1; age <= 10'd0;
                bin <= (tof_mm > 16'd9999) ? 14'd9999 : tof_mm[13:0]; bcd <= 16'd0; bc <= 4'd14;
            end else begin
                if (ms && age != 10'd1000) age <= age + 10'd1;
                if (bc != 4'd0) begin
                    bcd <= {bcd_adj[14:0], bin[13]}; bin <= {bin[12:0], 1'b0}; bc <= bc - 4'd1;
                    if (bc == 4'd1) d_bcd <= {bcd_adj[14:0], bin[13]};
                end
            end
            dbg_txt <= {mm_ch, " ", cd_ch, " ", st_ch, "   "};
        end
    end
endmodule
