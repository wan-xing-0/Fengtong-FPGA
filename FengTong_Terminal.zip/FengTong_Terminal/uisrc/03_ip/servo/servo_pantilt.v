//===========================================================================
// servo_pantilt.v  --  SG90 two-axis head, and the closed loop that drives it
//                      from motion_frame_drawer's tracker.
//
// 2026-09-23.  Hardware: "SG90 二自由度舵机云台" -- two 9 g SG90 servos on a
// plastic pan/tilt frame, 90 deg of travel per axis, 35 g, payload 60-90 g.
//
// FROM THE SELLER'S SHEET, because there is no real datasheet:
//   * 50 Hz frame (20 ms), pulse 0.5-2.5 ms over the servo's full 180 deg.
//     The FRAME is only 90 deg per axis, and the sheet's own diagram maps
//     1000 / 1500 / 2000 us to -45 / 0 / +45 deg.  So 1000..2000 us is the
//     whole of the mechanical travel and everything outside it drives the
//     arm into the frame's end stop.  See PAN_MIN_US / PAN_MAX_US.
//   * DEAD BAND 8-10 us.  A commanded change smaller than that does nothing
//     at all.  This is not a rounding detail, it sets STEP_MIN -- see the
//     stability note on DEAD_X.
//   * 0.09-0.1 s per 60 deg unloaded  ->  ~600 deg/s slew, i.e. far faster
//     than this loop ever asks for.  It sets SETTLE, not the gain.
//   * 4.8-5 V.  Stall current 750 mA PER SERVO.  Two of them stalling is
//     1.5 A, which is why the wiring note below says "separate supply".
//   * Wire colours: brown = GND, red = +5 V, orange/yellow = signal.
//
//---------------------------------------------------------------------------
// ⚠ WIRING, AND WHY IT IS IN THE RTL FILE
//
// Three of these are things the RTL cannot protect against and that kill
// either the board or the servo, so they live next to the code that assumes
// them rather than in a document nobody opens at the bench:
//
//   1. DO NOT POWER THE SERVOS FROM THE FPGA BOARD.  Separate 5 V supply
//      (USB power bank / 5 V 2 A adapter), GROUND TIED TO THE FPGA GROUND.
//      A servo's inrush browns out a shared rail and the symptom is an FPGA
//      that resets whenever the head moves.
//   2. 1.8 V CEP SIGNAL PINS + OFF-BOARD LEVEL SHIFTER (LVCMOS18).  The two
//      signal pins leave on CEP J14 pins 3/4 (BANK33, 1.8 V) and feed the
//      BSS138 4-channel bidirectional board up to 3.3 V (J14 pin 1).  That
//      board is NON-inverting, hence PWM_ACTIVE_LOW = 0 in system_top (the
//      single-FET common-source shifter of 09-24 inverted and needed 1).  An
//      SG90 at 5 V wants ~2.5 V for a logic one: 3.3 V works, 1.8 V never
//      does, which is the entire reason the shifter exists.
//   3. 470-1000 uF across the servo 5 V at the connector, plus 0.1 uF.
//
// And one from the seller: DO NOT TURN THE HORN BY HAND.  Stripped gears are
// explicitly not covered.  Use the supplied CCPM tester's "Normal" (centre)
// button to find mechanical centre and bolt the frame up there, BEFORE this
// module ever drives it.
//===========================================================================


//===========================================================================
// One PWM channel.  Takes the microsecond tick from the parent so two
// channels share one divider.
//===========================================================================
module servo_pwm #(
    parameter integer PERIOD_US = 20000,     // 50 Hz
    parameter [11:0]  PW_RST    = 12'd1500,
    parameter integer PWM_ACTIVE_LOW = 0     // 1 = pulse is LOW, for an
                                             // inverting off-board shifter
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire        us_tick,
    input  wire [11:0] pw_us,
    output reg         pwm
);

localparam integer CW = 15;                  // 20000 fits in 15 bits

reg [CW-1:0] cnt;
reg [11:0]   pw_l;

//------------------------------------------------------------------------
// ⚠ pw_us IS LATCHED AT THE PERIOD WRAP, NEVER MID-PULSE.  The controller
// updates once per video frame (16.7 ms) and the PWM period is 20 ms, so the
// two are asynchronous by construction and an unlatched width WILL change
// while the pulse is high.  A pulse cut short that way is not "a slightly
// wrong angle", it is a single frame of an arbitrary command -- the servo
// reads it and jumps.  One 12-bit register buys the whole problem away.
//
// The cost of latching is up to one PWM period (20 ms) of extra latency
// before a commanded step reaches the horn.  SETTLE is sized for it.
//------------------------------------------------------------------------
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        cnt  <= {CW{1'b0}};
        pw_l <= PW_RST;
    end else if (us_tick) begin
        if (cnt == (PERIOD_US - 1)) begin
            cnt  <= {CW{1'b0}};
            pw_l <= pw_us;
        end else begin
            cnt <= cnt + 1'b1;
        end
    end
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) pwm <= (PWM_ACTIVE_LOW != 0);   // idle level
    else        pwm <= (cnt < {{(CW-12){1'b0}}, pw_l}) ^ (PWM_ACTIVE_LOW != 0);
end

endmodule


//===========================================================================
// The head: two channels plus the frame-rate control loop.
//===========================================================================
module servo_pantilt #(
parameter integer CLK_HZ    = 150000000,   // pclkx1, exactly 150.000 MHz
parameter integer IMG_HDISP = 1920,
parameter integer IMG_VDISP = 1080,
parameter integer PERIOD_US = 20000,

//------------------------------------------------------------------------
// ⚠ THE MASTER ROLLBACK, AND IT CHANGES THE NETLIST.  0 folds the divider,
// both PWM counters and the whole loop away, parks both outputs at a static
// 0 and ties md_inhibit low.  A servo receiving NO pulses goes limp, which
// is the safe failure: a limp head cannot fight its end stop.
//
// §-2.2's second bug was a rollback switch that gated outputs only and left
// everything synthesised.  That is not a rollback in a design whose seed is
// re-rolled by area, so this one gates the state.
//------------------------------------------------------------------------
parameter integer SERVO_EN  = 1,

//------------------------------------------------------------------------
// ⚠ PWM POLARITY.  0 = active-high pulse (drive an SG90 signal pin directly
// at 3.3 V).  1 = active-low pulse, for the OFF-BOARD single N-MOSFET level
// shifter (BSS138/2N7002 common-source) that INVERTS: emitting the pulse low
// here makes the servo see the active-high 0.5-2.5 ms pulse it wants.  Wiring
// is drawn in fpga_pin.adc's SG90 block.
//------------------------------------------------------------------------
parameter integer PWM_ACTIVE_LOW = 0,

//------------------------------------------------------------------------
// TRAVEL LIMITS.  These are the mechanical end stops of the FRAME, not the
// electrical range of the servo, and the difference is a stalled 750 mA
// motor pressing on a plastic bracket for as long as the board is on.
// 1000..2000 us is the seller's own -45..+45 mapping.  ⚠ NARROW THESE if the
// assembled head reaches its stop before 1000 or 2000; never widen them.
//------------------------------------------------------------------------
parameter [11:0]  PAN_MIN_US = 12'd1000,
parameter [11:0]  PAN_MAX_US = 12'd2000,
parameter [11:0]  PAN_CTR_US = 12'd1500,
parameter [11:0]  TLT_MIN_US = 12'd1000,
parameter [11:0]  TLT_MAX_US = 12'd2000,
parameter [11:0]  TLT_CTR_US = 12'd1500,

//------------------------------------------------------------------------
// ⭐⭐ THE ONE STABILITY CONDITION IN THIS FILE:
//
//        q  <=  2 * DEAD_X          where q = STEP_MIN expressed in pixels
//
// Everything else here is taste; this one decides whether the head hunts.
//
// Why there is a STEP_MIN at all: the servo's 8-10 us dead band means a
// smaller command is a no-op, so a pure proportional law stops moving while
// the error is still large and the loop sits there with a lie on the screen.
// STEP_MIN forces every commanded correction to be one the servo can
// actually execute.
//
// Why that creates the risk: a correction the servo CAN execute has a
// minimum size in pixels too, so the reachable positions form a LATTICE of
// spacing q, while the dead zone is a window of width 2*DEAD_X.  The loop
// can only come to rest on a lattice point inside that window:
//
//        q <= 2*DEAD_X  ->  a lattice point is always inside.  Settles from
//                           EVERY starting phase.
//        q >  2*DEAD_X  ->  the window fits between two lattice points for
//                           some phases.  Those phases HUNT at the frame
//                           rate, forever, and the other phases settle --
//                           which is why a single bench measurement can
//                           happily report "stable" on a broken setting.
//
// ⚠ THAT LAST LINE IS NOT THEORY.  svtb's first T13 ran one object position
// against a deliberately-broken DEAD_X and went green.  It takes a sweep
// over a full lattice period to see it, and the sweep has to be injected by
// DISPLACING AN ALREADY-SETTLED TARGET: sweeping the start position instead
// does not work, because the proportional region is a geometric decay that
// compresses a 28 px spread of starts into ~5 px by the time the loop
// reaches the STEP_MIN regime, putting every phase on the same lattice
// point.  svtb T12/T13 carry the working form.
//
// The numbers, with the only figure that has to be guessed -- the lens:
//   1000 us  = 90 deg              ->  11.1 us/deg
//   1920 px over an assumed 70 deg ->  27.4 px/deg
//   so                                 1 us ~ 2.47 px
//   q = STEP_MIN 12 us ~ 30 px  <=  2*DEAD_X = 192 px   ->  6.4x margin
//   STEP_MAX 40 us     ~ 99 px  <   BLK_W    = 128 px   ->  see SETTLE
//
// ⚠ THE 70 deg IS AN ASSUMPTION AND IT IS THE ONLY WAY THIS GOES WRONG.  A
// narrower lens means more px per us and the margin shrinks -- it would take
// a ~11 deg lens to break it, so there is room, but the failure is silent
// until it is not.  Board symptom: THE HEAD ROCKS LEFT-RIGHT ACROSS THE
// TARGET AND NEVER SETTLES.  First knob is DEAD_X/DEAD_Y UP, second is
// STEP_MIN down towards 10 (the servo's own dead band is the floor).
// ⚠ NOT KP_SHIFT -- the gain has nothing to do with this limit cycle, which
// lives entirely at the clamp.
//
// DEAD_Y is DEAD_X scaled by 1080/1920 so the dead zone is a square on the
// sensor rather than on the pixel grid.
//------------------------------------------------------------------------
parameter [11:0]  DEAD_X   = 12'd96,
parameter [11:0]  DEAD_Y   = 12'd54,
parameter integer KP_SHIFT = 4,
parameter [11:0]  STEP_MIN = 12'd12,
parameter [11:0]  STEP_MAX = 12'd40,

//------------------------------------------------------------------------
// Frames of md_inhibit after a step.  ⚠ IT IS SIZED BY THE PWM LATCH, NOT BY
// THE SERVO: up to 20 ms before the channel even latches the new width (see
// servo_pwm's header), then ~6 ms for 3.6 deg of travel.  26 ms is 1.6
// frames, so 3 frames of 16.7 ms is the first value with margin.
//
// ⭐ THE BUDGET FOR THIS ALREADY EXISTS AND IT WAS BUILT FOR EXACTLY THIS.
// 09-22 evening split the tracker's one coast timer into TRK_COAST = 12
// (blind frames -- "long is right, there is no information") and TRK_MISS =
// 6 (missed frames).  An inhibit window is a run of blind frames, so it
// spends the 12-frame budget and not the 6-frame one.  3 of 12 is a quarter.
//------------------------------------------------------------------------
parameter [3:0]   SETTLE = 4'd3,

//------------------------------------------------------------------------
// ⚠ THE SIGNS CANNOT BE KNOWN UNTIL THE HEAD IS BOLTED TOGETHER, and getting
// one wrong turns the loop into positive feedback: the head slews to its end
// stop at full speed and stays there drawing 750 mA.
//
// Board test, with the camera looking at a still scene and a hand entering
// from ONE side: the head should turn TOWARDS the hand.  If it turns away,
// flip that axis's parameter -- one parameter, one rebuild, nothing else.
//
// The clamp at PAN_MIN/MAX is what makes a wrong sign survivable rather than
// destructive: it ends at the travel limit instead of against the stop.
//------------------------------------------------------------------------
parameter integer PAN_INVERT = 0,
parameter integer TLT_INVERT = 0,

//------------------------------------------------------------------------
// What happens when the operator leaves the TRACK wheel position.  0 = hold
// the current angles (default), 1 = return to centre.
//
// Hold is the default because the wheel is how the board A/B is done -- §-2.1
// put TRACK and MOTION one key press apart on purpose -- and a head that
// re-centres on every key press changes the scene between the two pictures
// being compared.
//------------------------------------------------------------------------
parameter integer PARK_ON_DIS = 0,

//------------------------------------------------------------------------
// ⭐ AIM_MODE (2026-10-01).  0 = the closed tracking loop above, BIT-EXACT
// (eqsvtb).  1 = OPEN-LOOP POINTING: the head carries the VL53L1X, not the
// camera, so it never moves the picture and md_inhibit is tied low.
//
// WHY THE LOOP HAD TO GO (HANDOFF §-9.0): frame differencing only holds while
// the camera is still, and a closed loop needs the camera to keep moving.
// Every step cost SETTLE blind frames, and dead band / step size could only
// trade "follows tightly" against "blind less often".  With the camera bolted
// down the conflict is gone, and there is nothing to close a loop ON -- the
// ToF has no image of where it points -- so pointing is a straight mapping:
//
//     pw = CTR + AIM_OFS + sign * ((|p - centre| * AIM_K + 128) >> 8)
//
// AIM_K is us per pixel in Q8.  Linear in pixels while the true law is
// atan(dx / F_PX), so a gain matched at the centre overshoots the edges by
// ~5 deg; the defaults are matched at the EDGES instead (35 deg over 960 px
// and 21.5 deg over 540 px at the guessed 70 deg lens, 11.1 us/deg), which
// leaves the error at mid-field, at ~2 deg -- inside the 15-27 deg cone.
//
// Signs follow the loop's convention (target right/below -> wider pulse,
// flipped by PAN_INVERT / TLT_INVERT), so the board check is the same one:
// aim at something on one side and see if the ToF turns towards it.
//
// AIM_OFS_X / _Y (us, signed) absorb the parallax between the ToF on the
// head and the lens, plus any mechanical off-centre.  1-3 m demo: 0.
//
// ⚠ ONE COMMAND PER aim_go AND NO RATE LIMIT HERE.  The scheduler
// (aim_sched) owns the timing -- it waits SETTLE_MS before trusting a
// reading -- and the PWM latch at the period wrap still applies, so a
// command can never cut a pulse short.
//------------------------------------------------------------------------
parameter integer AIM_MODE  = 0,
parameter [9:0]   AIM_KX    = 10'd104,
parameter [9:0]   AIM_KY    = 10'd113,
parameter integer AIM_OFS_X = 0,
parameter integer AIM_OFS_Y = 0
)(
input  wire        clk,
input  wire        rst_n,

// ⚠ EDGE-DETECTED, NOT LEVEL-SAMPLED.  The chain's vs is a 5-line SYNC PULSE
// and not a frame-valid, which has already been the root cause of one bug in
// this project (the "blanking window is 11,000 cycles, not 99,000" note).
// A rising-edge detect gives exactly one tick per frame under EITHER reading,
// so this module does not depend on which one is true here.
input  wire        vs,

// The effect wheel's TRACK position.  Doubles as the loop's enable: selecting
// TRACK is what arms the head.  No new key, and the semantics are the ones
// the operator already has in their hand.
input  wire        track_en,

input  wire [11:0] target_x,       // pixels, motion_frame_drawer
input  wire [11:0] target_y,
input  wire        target_valid,
input  wire        cam_motion,
input  wire [1:0]  trk_state,      // 0 = none, 1 = coasting, 2 = LOCKED

// AIM_MODE = 1 only: point at (aim_x, aim_y), pixels, sampled on aim_go.
// Ignored -- and folded away -- at AIM_MODE = 0.
input  wire [11:0] aim_x,
input  wire [11:0] aim_y,
input  wire        aim_go,
// 2026-10-07: one-clock pulse, head back to PAN_CTR_US / TLT_CTR_US (straight
// ahead) and any pointing still in flight is dropped.  The top fires it on
// entry to SECURITY mode; before this the AIM head kept whatever angle the
// last episode left it at.  Tie to 0 for the old behaviour.
input  wire        aim_home,

output wire        o_pan_pwm,
output wire        o_tilt_pwm,

// Back to motion_frame_drawer's md_inhibit: "the camera is moving, re-seed
// the background".  Its header spells out why gating the detector's OUTPUT
// instead would leave the stored background describing the old view for
// 2^BG_SHIFT = 16 frames after every step.
output wire        md_inhibit,

// For the OSD.  The pan/tilt widths in us are the single most diagnostic
// thing this module has: they say whether the loop is moving and which way,
// which a photograph of the head cannot.
output wire [11:0] pw_pan,
output wire [11:0] pw_tilt,

// AIM_MODE = 0: the settle window (unchanged).  AIM_MODE = 1: "the ToF is
// not looking at the image centre" -- what tof_size's centre-box SIZE row
// needs to know to mark its reading 'M'.
output wire        loop_moving
);

localparam integer US_DIV = CLK_HZ / 1000000;          // 150
localparam [11:0]  CX     = IMG_HDISP / 2;             // 960
localparam [11:0]  CY     = IMG_VDISP / 2;             // 540

wire s_en = (SERVO_EN != 0);
wire aim  = (AIM_MODE != 0);

//------------------------------------------------------------------------
// Microsecond tick, shared by both channels.
//------------------------------------------------------------------------
reg  [15:0] udiv;
wire        us_tick = s_en && (udiv == (US_DIV - 1));

always @(posedge clk or negedge rst_n) begin
    if (!rst_n)      udiv <= 16'd0;
    else if (!s_en)  udiv <= 16'd0;
    else             udiv <= us_tick ? 16'd0 : (udiv + 16'd1);
end

//------------------------------------------------------------------------
// One tick per frame.
//------------------------------------------------------------------------
reg vs_d;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) vs_d <= 1'b0;
    else        vs_d <= vs;
end
wire ftick = s_en && vs && !vs_d;

//------------------------------------------------------------------------
// The error, as magnitude + side.  Unsigned throughout: the sign lives in
// one bit that is XORed with the invert parameter, which is both cheaper
// than signed arithmetic here and easier to read at the clamp.
//------------------------------------------------------------------------
wire        pos_x = (target_x >= CX);                  // target right of centre
wire [11:0] abs_x = pos_x ? (target_x - CX) : (CX - target_x);
wire        pos_y = (target_y >= CY);                  // target below centre
wire [11:0] abs_y = pos_y ? (target_y - CY) : (CY - target_y);

wire [11:0] raw_x = abs_x >> KP_SHIFT;
wire [11:0] raw_y = abs_y >> KP_SHIFT;

wire [11:0] stp_x = (raw_x < STEP_MIN) ? STEP_MIN :
                    (raw_x > STEP_MAX) ? STEP_MAX : raw_x;
wire [11:0] stp_y = (raw_y < STEP_MIN) ? STEP_MIN :
                    (raw_y > STEP_MAX) ? STEP_MAX : raw_y;

//------------------------------------------------------------------------
// ⚠ `trk_state == 2` -- LOCKED -- AND NOT MERELY target_valid.  A coasting
// track still publishes a target; it is the LAST believed measurement, and
// servoing on it means moving the camera because of something the detector
// could not see this frame.  Requiring a fresh association also paces the
// loop for free: after a step the inhibit window makes the tracker coast, so
// the next step cannot be issued until the detector has recovered and
// re-associated.  There is no separate rate limiter anywhere in this module
// and that is why.
//
// cam_motion covers the same window from the detector's side; both are kept
// because `settle` alone would not catch the camera being bumped by hand,
// and cam_motion alone lags the first inhibited frame by one.
//------------------------------------------------------------------------
reg  [3:0] settle;
wire       ready = s_en && track_en && target_valid && (trk_state == 2'd2)
                   && !cam_motion && (settle == 4'd0);

wire mv_x = ready && (abs_x > DEAD_X);
wire mv_y = ready && (abs_y > DEAD_Y);

// 1 = increase the pulse width.
wire up_x = pos_x ^ (PAN_INVERT != 0);
wire up_y = pos_y ^ (TLT_INVERT != 0);

reg [11:0] pan_r;
reg [11:0] tlt_r;

// 13-bit intermediates: pan_r <= 2000 and stp <= STEP_MAX, so the add cannot
// leave 13 bits.  The underflow guard matters only if someone sets a MIN_US
// below STEP_MAX; it is one compare and it keeps the clamp total.
wire [12:0] sum_x = {1'b0, pan_r} + {1'b0, stp_x};
wire [12:0] dif_x = {1'b0, pan_r} - {1'b0, stp_x};
wire [12:0] nxt_x = up_x ? sum_x : dif_x;
wire        und_x = !up_x && (pan_r < stp_x);
wire [11:0] cl_x  = und_x                             ? PAN_MIN_US :
                    (nxt_x > {1'b0, PAN_MAX_US})      ? PAN_MAX_US :
                    (nxt_x < {1'b0, PAN_MIN_US})      ? PAN_MIN_US :
                                                        nxt_x[11:0];

wire [12:0] sum_y = {1'b0, tlt_r} + {1'b0, stp_y};
wire [12:0] dif_y = {1'b0, tlt_r} - {1'b0, stp_y};
wire [12:0] nxt_y = up_y ? sum_y : dif_y;
wire        und_y = !up_y && (tlt_r < stp_y);
wire [11:0] cl_y  = und_y                             ? TLT_MIN_US :
                    (nxt_y > {1'b0, TLT_MAX_US})      ? TLT_MAX_US :
                    (nxt_y < {1'b0, TLT_MIN_US})      ? TLT_MIN_US :
                                                        nxt_y[11:0];

//------------------------------------------------------------------------
// AIM_MODE = 1: pixel -> pulse width, one command per aim_go.
//
// |d| * K by shift-add, one bit of K per clock and both axes side by side
// (10 clocks), then the signed add, then the clamp -- one carry chain per
// clock, the same rule every other block on pclkx1 follows.  At AIM_MODE = 0
// every register below is held at reset and folds away.
//------------------------------------------------------------------------
localparam [1:0] A_IDLE = 2'd0, A_MUL = 2'd1, A_SUM = 2'd2, A_CLAMP = 2'd3;

localparam integer PAN_AC = PAN_CTR_US + AIM_OFS_X;
localparam integer TLT_AC = TLT_CTR_US + AIM_OFS_Y;

wire        a_pos_x = (aim_x >= CX);
wire [11:0] a_abs_x = a_pos_x ? (aim_x - CX) : (CX - aim_x);
wire        a_pos_y = (aim_y >= CY);
wire [11:0] a_abs_y = a_pos_y ? (aim_y - CY) : (CY - aim_y);

reg  [1:0]  a_st;
reg  [3:0]  a_i;
reg  [9:0]  a_kx, a_ky;
reg  [21:0] a_mx, a_my;          // |d| <= 2047, << 10
reg  [21:0] a_px, a_py;
reg         a_upx, a_upy;
reg         a_off;
reg  signed [15:0] a_sx, a_sy;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        a_st <= A_IDLE; a_i <= 4'd0; a_kx <= 10'd0; a_ky <= 10'd0;
        a_mx <= 22'd0; a_my <= 22'd0; a_px <= 22'd0; a_py <= 22'd0;
        a_upx <= 1'b0; a_upy <= 1'b0; a_off <= 1'b0;
        a_sx <= 16'sd0; a_sy <= 16'sd0;
    end else if (!s_en || !aim || aim_home) begin
        a_st <= A_IDLE; a_off <= 1'b0;
    end else if (aim_go) begin
        // In ANY state: the newest command wins, so a park issued while a
        // previous mapping is still in A_MUL is not lost.
        a_mx  <= {10'd0, a_abs_x};
        a_my  <= {10'd0, a_abs_y};
        a_kx  <= AIM_KX;
        a_ky  <= AIM_KY;
        a_px  <= 22'd128;                // + half an LSB of the >> 8
        a_py  <= 22'd128;
        a_upx <= a_pos_x ^ (PAN_INVERT != 0);
        a_upy <= a_pos_y ^ (TLT_INVERT != 0);
        a_off <= (aim_x != CX) || (aim_y != CY);
        a_i   <= 4'd0;
        a_st  <= A_MUL;
    end else begin
        case (a_st)
        A_IDLE: ;
        A_MUL: begin
            if (a_kx[0]) a_px <= a_px + a_mx;
            if (a_ky[0]) a_py <= a_py + a_my;
            a_mx <= {a_mx[20:0], 1'b0};
            a_my <= {a_my[20:0], 1'b0};
            a_kx <= {1'b0, a_kx[9:1]};
            a_ky <= {1'b0, a_ky[9:1]};
            a_i  <= a_i + 4'd1;
            if (a_i == 4'd9) a_st <= A_SUM;
        end
        A_SUM: begin
            // a_p >> 8 <= 2047 * 1023 / 256 < 8192: 14 bits, so 16-bit
            // signed holds CTR +- it with room for any OFS.
            a_sx <= a_upx ? (PAN_AC + $signed({2'b00, a_px[21:8]}))
                          : (PAN_AC - $signed({2'b00, a_px[21:8]}));
            a_sy <= a_upy ? (TLT_AC + $signed({2'b00, a_py[21:8]}))
                          : (TLT_AC - $signed({2'b00, a_py[21:8]}));
            a_st <= A_CLAMP;
        end
        default: a_st <= A_IDLE;        // A_CLAMP: the block below writes
        endcase
    end
end

wire [11:0] a_clx = (a_sx < $signed({4'd0, PAN_MIN_US})) ? PAN_MIN_US :
                    (a_sx > $signed({4'd0, PAN_MAX_US})) ? PAN_MAX_US : a_sx[11:0];
wire [11:0] a_cly = (a_sy < $signed({4'd0, TLT_MIN_US})) ? TLT_MIN_US :
                    (a_sy > $signed({4'd0, TLT_MAX_US})) ? TLT_MAX_US : a_sy[11:0];

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        pan_r  <= PAN_CTR_US;
        tlt_r  <= TLT_CTR_US;
        settle <= 4'd0;
    end else if (!s_en) begin
        pan_r  <= PAN_CTR_US;
        tlt_r  <= TLT_CTR_US;
        settle <= 4'd0;
    end else if (aim) begin
        settle <= 4'd0;
        if (aim_home) begin
            pan_r <= PAN_CTR_US;
            tlt_r <= TLT_CTR_US;
        end else if (a_st == A_CLAMP) begin
            pan_r <= a_clx;
            tlt_r <= a_cly;
        end
    end else if (ftick) begin
        if ((PARK_ON_DIS != 0) && !track_en) begin
            pan_r  <= PAN_CTR_US;
            tlt_r  <= TLT_CTR_US;
            settle <= 4'd0;
        end else begin
            if (mv_x) pan_r <= cl_x;
            if (mv_y) tlt_r <= cl_y;

            if (mv_x || mv_y)        settle <= SETTLE;
            else if (settle != 4'd0) settle <= settle - 4'd1;
        end
    end
end

// AIM: settle is pinned at 0, so md_inhibit is 0 by construction; the !aim
// term says so where the next reader looks.
assign md_inhibit  = s_en && !aim && (settle != 4'd0);
assign loop_moving = s_en && (aim ? a_off : (settle != 4'd0));
assign pw_pan      = pan_r;
assign pw_tilt     = tlt_r;

//------------------------------------------------------------------------
// The two channels.  ⚠ Both are held at a static 0 when SERVO_EN = 0: no
// pulses at all, so the head is limp rather than commanded to centre.  A
// disabled loop must not be able to move anything.
//------------------------------------------------------------------------
generate
if (SERVO_EN != 0) begin : g_servo

    servo_pwm #(
        .PERIOD_US      (PERIOD_US),
        .PW_RST         (PAN_CTR_US),
        .PWM_ACTIVE_LOW (PWM_ACTIVE_LOW)
    ) u_pan (
        .clk     (clk),
        .rst_n   (rst_n),
        .us_tick (us_tick),
        .pw_us   (pan_r),
        .pwm     (o_pan_pwm)
    );

    servo_pwm #(
        .PERIOD_US      (PERIOD_US),
        .PW_RST         (TLT_CTR_US),
        .PWM_ACTIVE_LOW (PWM_ACTIVE_LOW)
    ) u_tilt (
        .clk     (clk),
        .rst_n   (rst_n),
        .us_tick (us_tick),
        .pw_us   (tlt_r),
        .pwm     (o_tilt_pwm)
    );

end else begin : g_off
    assign o_pan_pwm  = 1'b0;
    assign o_tilt_pwm = 1'b0;
end
endgenerate

endmodule
