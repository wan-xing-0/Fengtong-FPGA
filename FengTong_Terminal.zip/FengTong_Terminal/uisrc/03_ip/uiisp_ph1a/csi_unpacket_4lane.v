/*******************************MILIANKE*******************************
*Company : MiLianKe Electronic Technology Co., Ltd.
*WebSite:https://www.milianke.com
*Create Date: 2023/03/23
*Description:
*The reference demo provided by Milianke is only used for learning.
*Copyright: Copyright (c) MiLianKe
*All rights reserved.
*********************************************************************/
//---------------------------------------------------------------------------
// csi_unpacket_4lane : MIPI CSI-2 packet framing, 4-lane version.
//
// Ported verbatim from the vendor's 11_imx415_hdmi demo (which is proven on
// this board with the MLK-CAM002 / IMX415 module).  The only edits are the
// comment language and the header banner -- the RTL is byte-identical in
// behaviour to the demo's copy, deliberately, because this block is the one
// piece of the chain nobody can debug from a photograph of a screen.
//
// The D-PHY hard macro hands the fabric LANE_NUM*8 = 32 bits per byte clock,
// i.e. four consecutive bytes of the lane-interleaved stream.  Byte order
// inside the word is big-endian: the FIRST byte of the stream sits in
// [31:24].  Everything downstream (raw8_unpacket_4lane, and then the read
// side of system_top) keeps that convention.
//
// Packet handling is minimal by design: the rising edge of I_hs_valid marks
// a packet header, the data type in header byte 0 selects what it is, and
// for a RAW10 long packet the 16-bit word count is used to time the payload
// out.  No ECC/CRC check -- the demo has none either, and a corrupted line
// shows up as a torn frame rather than as a lockup.
//
//   header byte 0 = [31:24] = data identifier (data type in the low 6 bits)
//   header byte 1 = [23:16] = word count LSB
//   header byte 2 = [15: 8] = word count MSB
//   header byte 3 = [ 7: 0] = ECC (ignored)
//
// S_data_length is the payload length in 32-bit WORDS, hence the >>2: word
// count is in bytes and this interface eats 4 bytes per clock.
//---------------------------------------------------------------------------

module csi_unpacket_4lane (
    input wire        I_clk,
    input wire        I_rst_n,

    input wire        I_hs_valid,
    input wire [31:0] I_hs_data,

    output reg        O_csi_frame_start,
    output reg        O_csi_frame_end,
    output reg        O_csi_valid,
    output reg [31:0] O_csi_data
);

    localparam FRAME_DATA_DT  = 8'h2B;   // RAW10 long packet
    localparam FRAME_START_DT = 8'h00;   // frame start short packet
    localparam FRAME_END_DT   = 8'h01;   // frame end short packet

    reg         S_hs_valid_1d;
    reg  [31:0] S_hs_data_1d;
    wire        S_head_en;
    wire [31:0] S_packet_head_data;
    reg  [15:0] S_data_length;
    reg         S_data_en;
    reg  [15:0] S_data_en_cnt;

    always @(posedge I_clk) begin
        S_hs_valid_1d <= I_hs_valid;
        S_hs_data_1d  <= I_hs_data;
    end

    assign S_head_en          = ~S_hs_valid_1d & I_hs_valid;
    assign S_packet_head_data = S_head_en ? I_hs_data : 32'd0;

    always @(posedge I_clk) begin
        if (S_head_en && S_packet_head_data[31:24] == FRAME_START_DT)
            O_csi_frame_start <= 1'b1;
        else
            O_csi_frame_start <= 1'b0;
    end

    always @(posedge I_clk) begin
        if (S_head_en && S_packet_head_data[31:24] == FRAME_END_DT)
            O_csi_frame_end <= 1'b1;
        else
            O_csi_frame_end <= 1'b0;
    end

    always @(posedge I_clk) begin
        if (I_hs_valid) begin
            if (S_head_en && S_packet_head_data[31:24] == FRAME_DATA_DT)
                S_data_length <= {S_packet_head_data[15:8], S_packet_head_data[23:16]} >> 2;
            else
                S_data_length <= S_data_length;
        end
        else
            S_data_length <= 16'd0;
    end

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n)
            S_data_en <= 1'b0;
        else if (S_head_en && S_packet_head_data[31:24] == FRAME_DATA_DT)
            S_data_en <= 1'b1;
        else if (S_data_en_cnt == S_data_length - 1'b1)
            S_data_en <= 1'b0;
        else
            S_data_en <= S_data_en;
    end

    always @(posedge I_clk) begin
        if (S_data_en)
            S_data_en_cnt <= S_data_en_cnt + 16'd1;
        else
            S_data_en_cnt <= 16'd0;
    end

    always @(posedge I_clk) begin
        if (S_data_en) begin
            O_csi_valid <= 1'b1;
            O_csi_data  <= I_hs_data;
        end
        else begin
            O_csi_valid <= 1'b0;
            O_csi_data  <= 32'd0;
        end
    end

endmodule
