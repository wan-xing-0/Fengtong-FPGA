/*****************************************************************
Company : MiLianKe Electronic Technology Co., Ltd.
WebSite:https://www.milianke.com
@Author      :   XiaoQingquan
@Time        :   2024/12
version:     :   1.0
*****************************************************************/
//---------------------------------------------------------------------------
// image_correction : crop the sensor's raw frame to an exact W x H window and
// generate the AXI-stream framing (tuser / tlast) that uidbuf's write side
// needs.
//
// WHY IT IS NEEDED HERE
//   The SC500AI fed 1920x1080 straight out, so the old write side could fake
//   tlast by counting 480 words and take frame_start as tuser.  IMX415 in
//   2x2 binning (HADD=VADD=ADDMODE=1) emits roughly 1932x1096 -- more than a
//   frame's worth on both axes.  Without a crop, uidbuf (configured 480 words
//   x 1080 lines) would receive 483 words and 1096 lines per frame and the
//   picture would shear and crawl.  This is the vendor demo's cropper,
//   parameterised; the demo's fixed window was DATA_WIDTH=40 / 480 words /
//   1080 lines starting at (1,1).
//
// END OF LINE IS DETECTED FROM A GAP IN VALID, NOT FROM A COUNTER
//   There is no line marker in the RAW payload, so a run of GAP_CYCLES+1
//   consecutive invalid clocks is taken as the line boundary.  The upstream
//   unpacker has one-clock holes in valid (4 of every 5 clocks carry data),
//   so GAP_CYCLES must stay comfortably above 1.  MIPI line blanking is
//   hundreds of byte clocks, so 10 has a very wide margin on both sides.
//
// THREE DIFFERENCES FROM THE DEMO'S COPY, ALL DELIBERATE
//   1. v_cnt only advances on lines that actually carried data (the
//      line_seen flag).  THIS IS A BUG FIX, not a cleanup -- found by ftb.v,
//      see below.
//   2. cnt saturates instead of wrapping.  In the demo cnt is 17 bits and
//      keeps counting through vertical blanking, so it wraps and re-fires
//      `last` every 131072 clocks.  Saturating makes `last` fire exactly
//      once per gap, which is what fix 1 needs in order to mean anything.
//   3. The demo's `assign I_raw_tready = O_raw_tready;` is dropped.  There is
//      no I_raw_tready port, so that statement silently created an implicit
//      1-bit net that drove nothing.  The write side of uidbuf never asserts
//      backpressure at this point anyway (its write FIFO is 2048 deep against
//      480 words per line), and the old 2-lane path left O_W_tready
//      unconnected for the same reason.
//
// THE v_cnt BUG, AND WHY IT DECIDES THE BAYER PHASE
//   `last` means "GAP_CYCLES clocks with no data".  That is true at the end
//   of every line -- but it is equally true in the gap between the frame-start
//   short packet and the first long packet, which on real MIPI is far longer
//   than 10 byte clocks.  So in the demo the sequence is:
//
//     frame_start  -> v_cnt := 0
//     (idle gap)   -> `last` fires -> v_cnt := 1     <-- nothing was received
//     line 0 data  -> v_cnt is already 1
//
//   With the demo's `V_valid = (v_cnt > 0) && (v_cnt < 1081)` that means line
//   0 is KEPT and the bottom lines are dropped instead -- the opposite of
//   what "skip the first line" reads as.  ftb.v caught it as a whole-frame
//   off-by-one-line (line 0 emitting 480 words, line 2 emitting none).
//
//   It matters beyond a shifted crop window: dropping an odd number of lines
//   flips the Bayer row phase.  So this single flag is the difference between
//   delivering GBRG and delivering RGGB, i.e. between correct colour and
//   swapped red/blue downstream.  It is also why the demo's own ISP settings
//   cannot be used to prove what phase arrives here: its cropper's behaviour
//   depends on a blanking length, so the "BGGR then swap R/B = RGGB" chain in
//   isp_top is evidence about what its ISP EXPECTS, not about what it GETS.
//   Treat BAYER_X_ODD / BAYER_Y_ODD in raw8_2_rgb888 as the thing to settle
//   on the bench, and settle it there.
//
//   With the fix, v_cnt is exactly "how many data lines have completed", so
//   Y_SKIP=1 provably drops line 0 and the delivered phase is the sensor's
//   native GBRG with one line removed = RGGB.
//
// BAYER PHASE LIVES HERE (read this before changing X_SKIP or Y_SKIP)
//   Dropping words changes the horizontal phase in steps of 4 pixels, i.e.
//   never -- 4 is even.  Dropping lines flips the vertical phase.  So this
//   module can only reach 2 of the 4 Bayer phases and the remaining degree of
//   freedom is the demosaic's own BAYER_X_ODD parameter.  With the demo's
//   X_SKIP=1 / Y_SKIP=1 on an IMX415 (native GBRG) the delivered pattern is
//   RGGB, and raw8_2_rgb888 must be instantiated with BAYER_X_ODD=1,
//   BAYER_Y_ODD=0.  Change Y_SKIP to 2 and it becomes GBRG, needing (1,1).
//   Prefer changing the demosaic parameters: they cost nothing and they
//   cannot resize the frame by accident.
//---------------------------------------------------------------------------

module image_correction #(
    parameter DATA_WIDTH = 32,     // 32 = 4 packed RAW8 px, 40 = 4 RAW10 px
    parameter X_SKIP     = 1,      // words dropped at the start of each line
    parameter X_WORDS    = 480,    // words kept  (480 * 4 px = 1920)
    parameter Y_SKIP     = 1,      // lines dropped at the start of each frame
    parameter Y_LINES    = 1080,   // lines kept
    parameter GAP_CYCLES = 10      // invalid clocks that mean "end of line"
)(
    input                           I_clk,
    input                           I_rst_n,

    input      [DATA_WIDTH-1:0]     I_raw_data,
    input                           I_raw_valid,
    input                           I_raw_frame_start,
    input                           I_raw_frame_end,   // unused, see note
    // I_raw_frame_end is deliberately not used: frame_start already reloads
    // both counters, and the MIPI frame-end short packet arrives AFTER the
    // last line, so acting on it could only truncate a frame that is already
    // complete.  The port is kept because the demo has it and because the
    // signal is worth having wired for ChipWatcher.

    output     [DATA_WIDTH-1:0]     O_raw_tdata,
    output                          O_raw_tlast,
    output                          O_raw_tvalid,
    output                          O_raw_tuser
);

    localparam X_LAST  = X_SKIP + X_WORDS - 1;   // last word index kept
    localparam X_LIMIT = X_SKIP + X_WORDS;
    localparam Y_LIMIT = Y_SKIP + Y_LINES;

    reg                     I_raw_tvalid_d;
    reg  [DATA_WIDTH-1:0]   I_raw_tdata_r;
    reg  [14:0]             h_cnt, v_cnt;
    reg  [7:0]              cnt;    // 8 bits so GAP_CYCLES can go to 254
                                    // without silently wrapping; it saturates
                                    // at GAP_CYCLES+1, see below
    wire                    V_valid, H_valid;
    wire                    last;

    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n) begin
            I_raw_tvalid_d <= 1'b0;
            I_raw_tdata_r  <= {DATA_WIDTH{1'b0}};
        end
        else begin
            I_raw_tvalid_d <= I_raw_valid;
            I_raw_tdata_r  <= I_raw_data;
        end
    end

    // Gap timer.  Saturates one past the threshold so `last` is a single
    // pulse no matter how long the blanking runs.
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n)          cnt <= 8'd0;
        else if (I_raw_valid)  cnt <= 8'd0;
        else if (cnt <= GAP_CYCLES) cnt <= cnt + 8'd1;
    end

    assign last = (cnt == GAP_CYCLES);

    // "This line has carried at least one valid word."  Without it, `last`
    // cannot tell the end of a line from the idle gap that follows
    // frame_start, and v_cnt starts the frame at 1 instead of 0 -- see the
    // header.  Cleared by frame_start and by the gap it qualifies, so it is
    // armed exactly once per line.
    reg line_seen;
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n || I_raw_frame_start) line_seen <= 1'b0;
        else if (I_raw_valid)              line_seen <= 1'b1;
        else if (last)                     line_seen <= 1'b0;
    end

    // Line counter: reloaded every frame, advanced only by a gap that
    // actually terminated a line, and saturated at the bottom of the window
    // so long blanking cannot walk it back into the visible range.
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n || I_raw_frame_start)               v_cnt <= 15'd0;
        else if (last && line_seen && (v_cnt < Y_LIMIT)) v_cnt <= v_cnt + 15'd1;
    end

    assign V_valid = (v_cnt >= Y_SKIP) && (v_cnt < Y_LIMIT);

    // Word-within-line counter.
    always @(posedge I_clk or negedge I_rst_n) begin
        if (!I_rst_n || I_raw_frame_start)  h_cnt <= 15'd0;
        else if (last)                      h_cnt <= 15'd0;
        else if (I_raw_tvalid_d)            h_cnt <= h_cnt + 15'd1;
    end

    assign H_valid = (h_cnt >= X_SKIP) && (h_cnt < X_LIMIT);

    assign O_raw_tdata  = (V_valid && H_valid) ? I_raw_tdata_r : {DATA_WIDTH{1'b0}};
    assign O_raw_tvalid = V_valid && H_valid && I_raw_tvalid_d;
    assign O_raw_tuser  = (h_cnt == X_SKIP) && (v_cnt == Y_SKIP) && I_raw_tvalid_d;
    assign O_raw_tlast  = V_valid && (h_cnt == X_LAST) && I_raw_tvalid_d;

endmodule
