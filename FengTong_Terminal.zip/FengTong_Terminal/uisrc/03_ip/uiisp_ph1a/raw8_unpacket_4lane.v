//---------------------------------------------------------------------------
// raw8_unpacket_4lane : MIPI RAW10 payload -> RAW8, 4 pixels per 32-bit word.
//
// WHY THIS FILE EXISTS
//   The vendor demo has raw10_unpacket_4lane (40-bit out, 4 x RAW10) because
//   its ISP runs in the camera clock domain on full 10-bit data.  This project
//   stores RAW8 packed 4-per-word in DDR3 and demosaics on the READ side, so
//   the write side needs the 8-bit form -- which is what the 2-lane module
//   raw10_unpacket_2lane produced for the SC500AI.  This is the 4-lane
//   equivalent of that module: same output format and byte order, same
//   timing shape as the demo's 4-lane version.
//
// RAW10 ON THE WIRE
//   MIPI packs 4 pixels into 5 bytes: four MSB bytes then one byte holding the
//   four 2-bit LSB pairs.
//
//     b0 = P0[9:2]   b1 = P1[9:2]   b2 = P2[9:2]   b3 = P3[9:2]
//     b4 = {P3[1:0], P2[1:0], P1[1:0], P0[1:0]}
//
//   RAW8 is exactly "drop every fifth byte" -- no arithmetic, no rounding.
//   That is the same truncation the 2-lane module did (it assembled the full
//   10 bits and then took [9:2]); doing it by byte selection instead saves the
//   assemble/re-split and, more importantly, makes the mapping auditable.
//
// FIVE INPUT WORDS -> FOUR OUTPUT WORDS
//   The D-PHY gives 4 bytes per clock, so a 5-byte group never lines up with a
//   word.  Over 5 input words (20 bytes = 16 pixels) the MSB bytes sit at
//   positions 0,1,2,3, 5,6,7,8, 10,11,12,13, 15,16,17,18 -- the LSB bytes are
//   at 4, 9, 14, 19.  Hence one idle output slot every fifth clock, and:
//
//     S_cnt  prev word (_1d)  cur word      output bytes
//     0      W0               W1            b0 b1 b2 b3      = W0
//     1      W1               W2            b5 b6 b7 b8      = {W1[23:0], W2[31:24]}
//     2      W2               W3            b10 b11 b12 b13  = {W2[15:0], W3[31:16]}
//     3      W3               W4            b15 b16 b17 b18  = {W3[7:0],  W4[31:8]}
//     4      W4               W5            (none)
//
//   S_cnt is driven off S_csi_valid_1d, identical to the demo's 4-lane module,
//   so the valid pattern presented downstream (4 of every 5 clocks, one-cycle
//   holes) is bit-for-bit the same shape the demo's image_correction was
//   written against.  That matters: image_correction detects end-of-line from
//   a gap in valid, and the gap threshold has to stay clear of these holes.
//
// OUTPUT BYTE ORDER
//   O_raw8_data[31:24] is the FIRST pixel of the group.  The read side of
//   system_top unpacks [31:24], [23:16], [15:8], [7:0] in that order, and the
//   2-lane module fed it the same way, so the Bayer phase seen by
//   raw8_2_rgb888 depends only on the crop offsets in image_correction -- not
//   on anything in here.
//
//   NOTE the demo's raw10_unpacket_4lane REVERSES the quad on the way out
//   ({P3,P2,P1,P0}).  Not copied: its ISP reads the low field first, ours
//   reads the high field first.  Copying the reversal would mirror the image
//   in groups of four pixels and flip the Bayer column phase with it.
//
// FRAME MARKERS
//   Registered once, while data takes two stages, so frame_start leads the
//   first data word of the frame.  That is what image_correction wants: it
//   uses frame_start only to clear its line/word counters.
//---------------------------------------------------------------------------

module raw8_unpacket_4lane (
    input wire        I_clk,
    input wire        I_rst_n,

    input wire        I_csi_frame_start,
    input wire        I_csi_frame_end,
    input wire        I_csi_valid,
    input wire [31:0] I_csi_data,

    output reg        O_raw8_frame_start,
    output reg        O_raw8_frame_end,
    output reg        O_raw8_valid,
    output reg [31:0] O_raw8_data
);

    reg        S_csi_valid_1d;
    reg [31:0] S_csi_data_1d;
    reg [2:0]  S_cnt;
    reg        S_raw8_wr_en;
    reg [31:0] S_raw8_wr_data;

    always @(posedge I_clk) begin
        O_raw8_frame_start <= I_csi_frame_start;
        O_raw8_frame_end   <= I_csi_frame_end;
        S_csi_valid_1d     <= I_csi_valid;
        S_csi_data_1d      <= I_csi_data;
    end

    always @(posedge I_clk) begin
        if (S_csi_valid_1d) begin
            if (S_cnt == 3'd4) S_cnt <= 3'd0;
            else               S_cnt <= S_cnt + 3'd1;
        end
        else
            S_cnt <= 3'd0;
    end

    always @(posedge I_clk) begin
        if (S_csi_valid_1d) begin
            case (S_cnt)
            3'd0: begin   // b0 b1 b2 b3  -> P0 P1 P2 P3
                S_raw8_wr_en   <= 1'b1;
                S_raw8_wr_data <= S_csi_data_1d;
            end
            3'd1: begin   // b5 b6 b7 b8  -> P4 P5 P6 P7
                S_raw8_wr_en   <= 1'b1;
                S_raw8_wr_data <= {S_csi_data_1d[23:0], I_csi_data[31:24]};
            end
            3'd2: begin   // b10 b11 b12 b13 -> P8 P9 P10 P11
                S_raw8_wr_en   <= 1'b1;
                S_raw8_wr_data <= {S_csi_data_1d[15:0], I_csi_data[31:16]};
            end
            3'd3: begin   // b15 b16 b17 b18 -> P12 P13 P14 P15
                S_raw8_wr_en   <= 1'b1;
                S_raw8_wr_data <= {S_csi_data_1d[7:0], I_csi_data[31:8]};
            end
            default: begin  // S_cnt == 4 : the all-LSB byte lands here
                S_raw8_wr_en   <= 1'b0;
                S_raw8_wr_data <= 32'd0;
            end
            endcase
        end
        else begin
            S_raw8_wr_en   <= 1'b0;
            S_raw8_wr_data <= 32'd0;
        end
    end

    always @(posedge I_clk) begin
        O_raw8_data  <= S_raw8_wr_data;
        O_raw8_valid <= S_raw8_wr_en;
    end

endmodule
