/*******************************MILIANKE*******************************
*Company : MiLianKe Electronic Technology Co., Ltd.
*WebSite:https://www.milianke.com
*TechWeb:https://www.uisrc.com
*tmall-shop:https://milianke.tmall.com
*jd-shop:https://milianke.jd.com
*taobao-shop1: https://milianke.taobao.com
*Create Date: 2023/03/23
*Module Name:
*File Name:
*Description: 
*The reference demo provided by Milianke is only used for learning. 
*We cannot ensure that the demo itself is free of bugs, so users 
*should be responsible for the technical problems and consequences
*caused by the use of their own products.
*Copyright: Copyright (c) MiLianKe
*All rights reserved.
*Revision: 1.0
*Signal description
*1) I_ input
*2) O_ output
*3) IO_ input output
*4) S_ system internal signal
*5) _n activ low
*6) _dg debug signal 
*7) _r delay or register
*8) _s state mechine
*********************************************************************/
/*********raw8_2_rgb888 RAW8 ת RGB888***********
ͨ����ʵ��3*3��RAW����Ȼ�����RGB
--�汾��1.0
*********************************************************************/

`timescale 1ns/1ns

module raw8_2_rgb888#(
parameter   [13:0]  H_SIZE = 640,    //640*480
parameter   [13:0]  V_SIZE = 480,
//---- Fixed-gain white balance, Q4.4 : actual gain = value/16, 16 = 1.00x ----
//---- A RAW Bayer sensor has no AWB; blue gain of 1.00x makes white look yellow ----
//---- Tune WB_B first (24..28) against a white sheet; keep WB_G = 16 as reference ----
parameter   [7:0]   WB_R   = 8'd16,
parameter   [7:0]   WB_G   = 8'd16,
parameter   [7:0]   WB_B   = 8'd26,
//---- Bayer phase of the incoming stream --------------------------------
// The interpolation case below was hard-wired to GRBG (pixel (0,0) green,
// row 0 = G R G R, row 1 = B G B G), which is what the SC500AI delivered.
// IMX415 is GBRG natively and the write-side cropper drops one line, so it
// arrives as RGGB.  These two bits XOR the row/column parity, which is
// exactly a one-pixel shift of the mosaic and costs nothing: they fold into
// the existing 2-bit case select, no extra logic level, no extra LUT.
//
//   BAYER_X_ODD  BAYER_Y_ODD   stream is interpreted as
//        0            0        GRBG   (row0 G R, row1 B G)  <- old default
//        1            0        RGGB   (row0 R G, row1 G B)  <- IMX415 here
//        0            1        BGGR   (row0 B G, row1 G R)
//        1            1        GBRG   (row0 G B, row1 R G)
//
// If the picture comes up with red and blue swapped, or with a fine
// checkerboard/zipper on sharp edges, this pair is the first thing to try --
// all four combinations, one rebuild each.  It is cheaper and safer than
// moving the crop offsets in image_correction, which can resize the frame.
parameter           BAYER_X_ODD = 1'b0,
parameter           BAYER_Y_ODD = 1'b0
)
(
    //global clock
input   wire        I_clk,            //cmos video pixel clock
input   wire        I_rst_n,          //global reset
input   wire        I_raw_vs,          //Prepared Image data vsync valid signal
input   wire        I_raw_de,          //Prepared Image data href vaild  signal
input   wire[7:0]   I_raw_data,        //Prepared Image data 8 Bit RAW Data


output  wire        O_rgb_vs,   //Processed Image data vsync valid signal
output  wire        O_rgb_de,    //Processed Image data href vaild  signal
output  wire[7:0]   O_rgb_r,       //Prepared Image green data to be processed 
output  wire[7:0]   O_rgb_g,     //Prepared Image green data to be processed
output  wire[7:0]   O_rgb_b       //Prepared Image blue data to be processed
);

wire [7:0]raw_v_1_d0;//frame data of the 1th row
wire [7:0]raw_v_2_d0;//frame data of the 2th row
reg  [7:0]raw_v_3_d0;//frame data of the 3th row
reg  [7:0]raw_v_1_d1,raw_v_1_d2;
reg  [7:0]raw_v_2_d1,raw_v_2_d2;
reg  [7:0]raw_v_3_d1,raw_v_3_d2;
reg  raw_de_d1,raw_de_d2,raw_de_d3,raw_de_d4,raw_de_d5;  
reg  raw_vs_d1,raw_vs_d2,raw_vs_d3,raw_vs_d4,raw_vs_d5;

wire  shift_clk_en = I_raw_de;

Line_Shift_RAM_8Bit#(
.DATA_WIDTH (8          ),
.ADDR_WIDTH (11         ),
.DATA_DEPTH (H_SIZE     ),
.DELAY_NUM  (0          )
)
u0_Line_Shift_RAM_8Bit
(
.clk    (I_clk          ),
.rst_n  (I_rst_n        ),
.clken  (shift_clk_en   ),
.din    (I_raw_data     ),   
.dout   (raw_v_2_d0     )
);

Line_Shift_RAM_8Bit#(
.DATA_WIDTH (8          ),
.ADDR_WIDTH (11         ),
.DATA_DEPTH (H_SIZE     ),
.DELAY_NUM  (1          )
)
u1_Line_Shift_RAM_8Bit
(
.clk    (I_clk          ),
.rst_n  (I_rst_n        ),
.clken  (shift_clk_en   ),
.din    (raw_v_2_d0     ),   
.dout   (raw_v_1_d0     )
);

always@(posedge I_clk)begin
    raw_v_3_d0 <= I_raw_de ? I_raw_data : raw_v_3_d0; 

    raw_v_3_d1 <= raw_v_3_d0;
    raw_v_3_d2 <= raw_v_3_d1;
    raw_v_1_d1 <= raw_v_1_d0;
    raw_v_1_d2 <= raw_v_1_d1;
    raw_v_2_d1 <= raw_v_2_d0;
    raw_v_2_d2 <= raw_v_2_d1;


    raw_de_d1  <= I_raw_de;
    raw_de_d2  <= raw_de_d1;
    raw_de_d3  <= raw_de_d2;
    raw_de_d4  <= raw_de_d3;
    raw_de_d5  <= raw_de_d4;

    raw_vs_d1  <= I_raw_vs;
    raw_vs_d2  <= raw_vs_d1;
    raw_vs_d3  <= raw_vs_d2;
    raw_vs_d4  <= raw_vs_d3;
    raw_vs_d5  <= raw_vs_d4;
end

reg  [7:0]raw_v_h_11,raw_v_h_12,raw_v_h_13;
reg  [7:0]raw_v_h_21,raw_v_h_22,raw_v_h_23;
reg  [7:0]raw_v_h_31,raw_v_h_32,raw_v_h_33;
reg     [13:0]  pixel_cnt;
//��1�У����1�м򵥴���
always@(posedge I_clk)begin
  if(raw_de_d1|raw_de_d2)begin 
     pixel_cnt <=  (pixel_cnt < H_SIZE) ? pixel_cnt + 1'b1 : 10'd0;   //Point Counter  
    if(pixel_cnt == 0)begin //��ʼ������raw_de_d2Ϊ�ߵ�ƽ��0���س�ʼ��
        {raw_v_h_11,raw_v_h_12,raw_v_h_13} <= {8'd0,8'd0,8'd0};
        {raw_v_h_21,raw_v_h_22,raw_v_h_23} <= {8'd0,8'd0,8'd0};
        {raw_v_h_31,raw_v_h_32,raw_v_h_33} <= {8'd0,8'd0,8'd0};
    end  
    else if(pixel_cnt == 1)begin//���Ѿ��е�2�����ص����
        {raw_v_h_11,raw_v_h_12,raw_v_h_13} <= {raw_v_1_d0,raw_v_1_d1,raw_v_1_d0};
        {raw_v_h_21,raw_v_h_22,raw_v_h_23} <= {raw_v_2_d0,raw_v_2_d1,raw_v_2_d0};
        {raw_v_h_31,raw_v_h_32,raw_v_h_33} <= {raw_v_3_d0,raw_v_3_d1,raw_v_3_d0};    
    end
    else if(pixel_cnt == H_SIZE)begin//���һ�����أ�raw_de_d2=0�����һ�����أ�raw_de_d3=1��������2�����ص����
        {raw_v_h_11,raw_v_h_12,raw_v_h_13} <= {raw_v_1_d2,raw_v_1_d0,raw_v_1_d2};
        {raw_v_h_21,raw_v_h_22,raw_v_h_23} <= {raw_v_2_d2,raw_v_1_d0,raw_v_1_d2};
        {raw_v_h_31,raw_v_h_32,raw_v_h_33} <= {raw_v_3_d2,raw_v_1_d0,raw_v_1_d2};   
    end
    else begin
        {raw_v_h_11,raw_v_h_12,raw_v_h_13} <= {raw_v_1_d2,raw_v_1_d1,raw_v_1_d0};
        {raw_v_h_21,raw_v_h_22,raw_v_h_23} <= {raw_v_2_d2,raw_v_2_d1,raw_v_2_d0};
        {raw_v_h_31,raw_v_h_32,raw_v_h_33} <= {raw_v_3_d2,raw_v_3_d1,raw_v_3_d0};   
    end
  end
  else begin
        pixel_cnt <= 0;
        {raw_v_h_11,raw_v_h_12,raw_v_h_13} <= {8'd0,8'd0,8'd0};
        {raw_v_h_21,raw_v_h_22,raw_v_h_23} <= {8'd0,8'd0,8'd0};
        {raw_v_h_31,raw_v_h_32,raw_v_h_33} <= {8'd0,8'd0,8'd0};
  end
end


//----------------------------------------
//Count the frame lines
reg [10:0]  v_cnt;
reg [13:0]  h_cnt;
always@(posedge I_clk or negedge I_rst_n)begin
    if(!I_rst_n || I_raw_vs == 0)
        v_cnt <= 0;
    else if((raw_de_d3 == 1) && (raw_de_d2 == 0)) //Frame valid
        v_cnt <= (v_cnt < V_SIZE - 1'b1) ? v_cnt + 1'b1 : 11'd0;
    else 
        v_cnt <= v_cnt;
end

always@(posedge I_clk or negedge I_rst_n)begin
    if(!I_rst_n )
        h_cnt <= 0;
    else if(raw_de_d3 == 1'b1)  //��raw_de_d2��ʼ����
        h_cnt <= (h_cnt < H_SIZE - 1'b1) ? h_cnt + 1'b1 : 11'd0;
    else
        h_cnt <= 0;
end

//Convet RAW 2 RGB888 Format
reg [9:0]   rgb_r,rgb_g,rgb_b;
always@(posedge I_clk or negedge I_rst_n)begin
    if(!I_rst_n)begin
        rgb_r  <=  0;
        rgb_g  <=  0;
        rgb_b  <=  0;
    end else begin
        case({v_cnt[0] ^ BAYER_Y_ODD, h_cnt[0] ^ BAYER_X_ODD})
        2'b11: begin  //odd lines + odd point  //Center Green
            rgb_r  <=  (raw_v_h_12 + raw_v_h_32)>>1;
            rgb_g  <=   raw_v_h_22;     
            rgb_b  <=  (raw_v_h_21 + raw_v_h_23)>>1;
         end
        2'b10: begin  //odd lines + even point //Center Blue
            rgb_r  <=  (raw_v_h_11 + raw_v_h_13 + raw_v_h_31 + raw_v_h_33)>>2;
            rgb_g  <=  (raw_v_h_12 + raw_v_h_21 + raw_v_h_23 + raw_v_h_32)>>2;
            rgb_b  <=   raw_v_h_22;
        end
        2'b01: begin  //even lines + odd point //Center Red
            rgb_r  <=   raw_v_h_22;
            rgb_g  <=  (raw_v_h_12 + raw_v_h_21 + raw_v_h_23 + raw_v_h_32)>>2;
            rgb_b  <=  (raw_v_h_11 + raw_v_h_13 + raw_v_h_31 + raw_v_h_33)>>2;
        end
        2'b00: begin//even lines + even point  //Center Green        
            rgb_r  <=  (raw_v_h_21 + raw_v_h_23)>>1;
            rgb_g  <=   raw_v_h_22;
            rgb_b  <=  (raw_v_h_12 + raw_v_h_32)>>1;
        end 
        endcase
    end
end


//---- Fixed-gain white balance + saturating clamp --------------------------
// x_wb[11:4] is the integer part of the Q4.4 product; any bit set in
// x_wb[15:12] means the result overflowed 255, so clamp to 8hFF.
// Registered to keep the 150MHz pixel path short; de/vs use the d5 taps so
// timing stays aligned with the extra pipeline stage.
wire [15:0] r_wb = rgb_r[7:0] * WB_R;
wire [15:0] g_wb = rgb_g[7:0] * WB_G;
wire [15:0] b_wb = rgb_b[7:0] * WB_B;

reg [7:0] rgb_r_wb, rgb_g_wb, rgb_b_wb;
always@(posedge I_clk or negedge I_rst_n)begin
    if(!I_rst_n)begin
        rgb_r_wb <= 8'd0;
        rgb_g_wb <= 8'd0;
        rgb_b_wb <= 8'd0;
    end else begin
        rgb_r_wb <= (|r_wb[15:12]) ? 8'hFF : r_wb[11:4];
        rgb_g_wb <= (|g_wb[15:12]) ? 8'hFF : g_wb[11:4];
        rgb_b_wb <= (|b_wb[15:12]) ? 8'hFF : b_wb[11:4];
    end
end

assign O_rgb_r    = rgb_r_wb;
assign O_rgb_g    = rgb_g_wb;
assign O_rgb_b    = rgb_b_wb;
assign O_rgb_de   = raw_de_d5;
assign O_rgb_vs   = raw_vs_d5;

endmodule
