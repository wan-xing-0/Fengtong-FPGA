

module hdmi_phy_wrapper#(
    parameter DEVICE = "EG"
    )(
    input wire      I_pixel_clk,
    input wire      I_serial_clk,
    input wire      I_rst,

    input wire[9:0] I_ch0_raw_data,
    input wire[9:0] I_ch1_raw_data,
    input wire[9:0] I_ch2_raw_data,
    input wire[9:0] I_clk_raw_data,

    output wire     O_hdmi_tx_ch0_p,
    output wire     O_hdmi_tx_ch1_p,
    output wire     O_hdmi_tx_ch2_p,
    output wire     O_hdmi_tx_clk_p
);

    PH1_LOGIC_HP_OSERDES #(
        .ODDRMODE     ( "DDRX5" )  //  "DDRX1", "DDRX2", "DDRX3P5", "DDRX4", "DDRX5".  IDDR mode select.  
    )u0_PH1_LOGIC_HP_OSERDES(
        .sclk         ( I_serial_clk ), //  1-Bit input.                                
        .pclk         ( I_pixel_clk    ), //  1-Bit input.                                
        .rst          ( I_rst             ), //  1-Bit input.    

        .idata        ( I_ch0_raw_data    ), //  10-Bit input.     

        .odata        ( O_hdmi_tx_ch0_p   )  //  1-Bit output.                                
    );



    PH1_LOGIC_HP_OSERDES #(
        .ODDRMODE     ( "DDRX5" )  //  "DDRX1", "DDRX2", "DDRX3P5", "DDRX4", "DDRX5".  IDDR mode select.  
    )u1_PH1_LOGIC_HP_OSERDES(
        .sclk         ( I_serial_clk ), //  1-Bit input.                                
        .pclk         ( I_pixel_clk    ), //  1-Bit input.                                
        .rst          ( I_rst             ), //  1-Bit input.    

        .idata        ( I_ch1_raw_data    ), //  10-Bit input.     

        .odata        ( O_hdmi_tx_ch1_p   )  //  1-Bit output.                                
    );


    PH1_LOGIC_HP_OSERDES #(
        .ODDRMODE     ( "DDRX5" )  //  "DDRX1", "DDRX2", "DDRX3P5", "DDRX4", "DDRX5".  IDDR mode select.  
    )u2_PH1_LOGIC_HP_OSERDES(
        .sclk         ( I_serial_clk ), //  1-Bit input.                                
        .pclk         ( I_pixel_clk    ), //  1-Bit input.                                
        .rst          ( I_rst             ), //  1-Bit input.    

        .idata        ( I_ch2_raw_data    ), //  10-Bit input.     

        .odata        ( O_hdmi_tx_ch2_p   )  //  1-Bit output.                                
    );


    PH1_LOGIC_HP_OSERDES #(
        .ODDRMODE     ( "DDRX5" )  //  "DDRX1", "DDRX2", "DDRX3P5", "DDRX4", "DDRX5".  IDDR mode select.  
    )u3_PH1_LOGIC_HP_OSERDES(
        .sclk         ( I_serial_clk ), //  1-Bit input.                                
        .pclk         ( I_pixel_clk    ), //  1-Bit input.                                
        .rst          ( I_rst             ), //  1-Bit input.    

        .idata        ( I_clk_raw_data    ), //  10-Bit input.     

        .odata        ( O_hdmi_tx_clk_p   )  //  1-Bit output.                                
    );

endmodule





