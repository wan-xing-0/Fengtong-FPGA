/************************************************************\
**	Copyright (c) 2012-2025 Anlogic Inc.
**	All Right Reserved.
\************************************************************/
/************************************************************\
**	Build time: Aug 14 2025 09:50:59
**	TD version	:	6.2.168116
************************************************************/
`timescale 1ns/1ps
module wfifo
(
  input                         rst,
  input   [31:0]                di,
  input                         clkr,
  input                         re,
  input                         clkw,
  input                         we,
  output  [255:0]               dout,
  output                        empty_flag,
  output                        aempty,
  output                        full_flag,
  output                        afull,
  output                        valid,
  output                        overflow,
  output                        underflow,
  output                        wr_success,
  output  [8:0]                 rdusedw,
  output  [11:0]                wrusedw,
  output                        wr_rst_done,
  output                        rd_rst_done
);

  soft_fifo_39d9ecd9ca65
  #(
      .COMMON_CLK_EN(0),
      .MEMORY_TYPE(0),
      .RST_TYPE(1),
      .DATA_WIDTH_W(32),
      .ADDR_WIDTH_W(11),
      .DATA_WIDTH_R(256),
      .ADDR_WIDTH_R(8),
      .DOUT_INITVAL(256'h0),
      .OUTREG_EN("NOREG"),
      .SHOW_AHEAD_EN(1),
      .AL_FULL_NUM(2045),
      .AL_EMPTY_NUM(2),
      .RDUSEDW_WIDTH(9),
      .WRUSEDW_WIDTH(12),
      .ASYNC_RST_SYNC_RELS(1),
      .SYNC_STAGE(2)
  )soft_fifo_39d9ecd9ca65_Inst
  (
      .rst(rst),
      .di(di),
      .clkr(clkr),
      .re(re),
      .clkw(clkw),
      .we(we),
      .dout(dout),
      .empty_flag(empty_flag),
      .aempty(aempty),
      .full_flag(full_flag),
      .afull(afull),
      .valid(valid),
      .overflow(overflow),
      .underflow(underflow),
      .wr_success(wr_success),
      .rdusedw(rdusedw),
      .wrusedw(wrusedw),
      .wr_rst_done(wr_rst_done),
      .rd_rst_done(rd_rst_done)
  );
endmodule
