`timescale 1ns/1ns
//////////////////////////////////////////////////////////////////
// YCbCr444 to RGB888 conversion
// Pipeline latency: 3 clocks
//
//   R = Y + 1.402*(Cr-128)
//   G = Y - 0.344*(Cb-128) - 0.714*(Cr-128)
//   B = Y + 1.772*(Cb-128)
//
// Fixed-point (x256):
//   R = Y + ((359*(Cr-128)) >> 8)
//   G = Y - ((88*(Cb-128) + 183*(Cr-128)) >> 8)
//   B = Y + ((454*(Cb-128)) >> 8)
//////////////////////////////////////////////////////////////////

module VIP_YCbCr444_RGB888
(
    input               clk,
    input               rst_n,

    input               per_img_vsync,
    input               per_img_href,
    input       [7:0]   per_img_Y,
    input       [7:0]   per_img_Cb,
    input       [7:0]   per_img_Cr,

    output              post_img_vsync,
    output              post_img_href,
    output      [7:0]   post_img_red,
    output      [7:0]   post_img_green,
    output      [7:0]   post_img_blue
);

//--------------------------------------------
// Step 1: multiply
reg signed [17:0] cr_x_359;
reg signed [17:0] cb_x_88;
reg signed [17:0] cr_x_183;
reg signed [17:0] cb_x_454;
reg        [ 7:0] y_r0;

always @(posedge clk) begin
    cr_x_359 <= ($signed({1'b0, per_img_Cr}) - 9'sd128) * $signed(10'd359);
    cb_x_88  <= ($signed({1'b0, per_img_Cb}) - 9'sd128) * $signed(10'd88);
    cr_x_183 <= ($signed({1'b0, per_img_Cr}) - 9'sd128) * $signed(10'd183);
    cb_x_454 <= ($signed({1'b0, per_img_Cb}) - 9'sd128) * $signed(10'd454);
    y_r0     <= per_img_Y;
end

//--------------------------------------------
// Step 2: sum and add Y
reg signed [10:0] r_sum;
reg signed [10:0] g_sum;
reg signed [10:0] b_sum;

always @(posedge clk) begin
    r_sum <= $signed({3'b0, y_r0}) + (cr_x_359 >>> 8);
    g_sum <= $signed({3'b0, y_r0}) - ((cb_x_88 + cr_x_183) >>> 8);
    b_sum <= $signed({3'b0, y_r0}) + (cb_x_454 >>> 8);
end

//--------------------------------------------
// Step 3: clamp to [0, 255]
reg [7:0] r_out;
reg [7:0] g_out;
reg [7:0] b_out;

always @(posedge clk) begin
    // negative -> 0,  >255 -> 255
    r_out <= r_sum[10] ? 8'd0 : (|r_sum[9:8]) ? 8'd255 : r_sum[7:0];
    g_out <= g_sum[10] ? 8'd0 : (|g_sum[9:8]) ? 8'd255 : g_sum[7:0];
    b_out <= b_sum[10] ? 8'd0 : (|b_sum[9:8]) ? 8'd255 : b_sum[7:0];
end

//--------------------------------------------
// lag 3 clocks signal sync
reg [2:0] per_img_vsync_r;
reg [2:0] per_img_href_r;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        per_img_vsync_r <= 3'b0;
        per_img_href_r  <= 3'b0;
    end else begin
        per_img_vsync_r <= {per_img_vsync_r[1:0], per_img_vsync};
        per_img_href_r  <= {per_img_href_r[1:0],  per_img_href};
    end
end

assign post_img_vsync = per_img_vsync_r[2];
assign post_img_href  = per_img_href_r[2];
assign post_img_red   = post_img_href ? r_out : 8'd0;
assign post_img_green = post_img_href ? g_out : 8'd0;
assign post_img_blue  = post_img_href ? b_out : 8'd0;

endmodule
