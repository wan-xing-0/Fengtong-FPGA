
module key_filter(
	Clk,
	Reset_n,
	Key,
	Key_P_Flag,
	Key_R_Flag,
	Key_state
    );
	input Clk;
	input Reset_n;
	input Key;
	output reg Key_P_Flag;
	output reg Key_R_Flag;
	output reg Key_state;
	localparam IDLE = 0;
	localparam P_filter = 1;
	localparam Wait_r = 2;
	localparam R_filter = 3;
	
	parameter MCNT = 1000_000-1;
	
	reg sync_d0_key;
	reg sync_d1_key;
	reg r_key;
	wire pedg_key,nedg_key;
	reg [1:0] state;
	reg [30:0] cnt;
	wire time_20ms_reached;
	assign time_20ms_reached = cnt>=MCNT;
	
// KEY��ͬ���߼�����
	always@(posedge Clk)
		sync_d0_key<=Key;

	always@(posedge Clk)
		sync_d1_key<=sync_d0_key;
	
	always@(posedge Clk)
		r_key<=sync_d1_key;
	
	assign pedg_key = r_key == 0&&sync_d1_key == 1;
	assign nedg_key = r_key == 1&&sync_d1_key == 0;
	
	
	always@(posedge Clk or negedge Reset_n)
		if(!Reset_n)begin
			Key_P_Flag<=0;
			Key_R_Flag<=0;
			state<=IDLE;
			cnt<=0;
			Key_state<=1;
		end
		else begin
			case(state)
			IDLE:begin
				Key_R_Flag<=0;
				if(nedg_key)
					state<=P_filter;
			end
			P_filter:
				if(time_20ms_reached)begin
					state<=Wait_r;
					Key_P_Flag<=1;
					cnt<=0;
					Key_state<=0;
				end
				else if(pedg_key)begin
					state<=IDLE;
					cnt<=0;
				end
				else begin
					state<=state;
					cnt<=cnt+1;
				end
			Wait_r:begin
				Key_P_Flag<=0;
				if(pedg_key)begin
					state<=R_filter;
				end
				else
					state<=state;
			end
			R_filter:
				if(time_20ms_reached)begin
					state<=IDLE;
					Key_R_Flag<=1;
					cnt<=0;
					Key_state<=1;
				end
				else if(nedg_key)begin
					state<=Wait_r;
					cnt<=0;
				end
				else begin
					state<=state;
					cnt<=cnt+1;
				end
			default:state<=state;
			endcase
		end
		
	//always@(posedge Clk or negedge Reset_n)
	//if(!Reset_n)
	//	cnt<=0;
	//else if(state == P_filter || state == R_filter)
	//	cnt<= cnt+1;
	//else
	//	cnt<=0;

endmodule