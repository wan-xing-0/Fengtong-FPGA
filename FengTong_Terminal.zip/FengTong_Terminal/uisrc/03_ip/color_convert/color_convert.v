`timescale 1 ps/1 ps
module color_convert
(
    input   wire            clk,
    input   wire            rst_n,
    input   wire            ctrl_key,

    input   wire            in_hs,
    input   wire            in_vs,
    input   wire            in_de,
    input   wire   [7:0]    in_r,
    input   wire   [7:0]    in_g,
    input   wire   [7:0]    in_b,

    output  wire            out_hs,
    output  wire            out_vs,
    output  wire            out_de,
    output  wire   [23:0]   out_rgb,

    // 2026-05-23 burn 5: texture mode out to color_replace module.
    //   2'b00 = disabled  (modes 0..9, 12 use built-in filters / passthrough)
    //   2'b01 = marble    (mode 10 - color_replace uses ROM bank 0)
    //   2'b10 = wood      (mode 11 - color_replace uses ROM bank 1)
    output  wire   [1:0]    texture_mode,

    // 2026-10-01 按键重排: MOTION / TRACK 两档搬去 key4 (F9, system_top 的
    // 模式选择: TRACK 安防 / BOX 质检 / FACE 人脸), 这里不再出 motion_frame_en
    // / track_en. 原 key2 (D9) 的形态学三档和直方图接在轮盘末尾 (12..15),
    // 由下面两个口导出, key2 整个空出来.
    //   morph_sel : 0 = 不做, 1 = ERODE, 2 = DILATE, 3 = DARKLIFT -> morphology_5x5
    //   hist_en   : 1 = 画直方图 -> hist_osd
    // 这四档本模块自己透传 (rgb_mux 走 default, 同步走 passthrough).
    output  wire   [1:0]    morph_sel,
    output  wire            hist_en,

    // 2026-09-04: 轮盘当前档位, 给 text_osd 上屏用. 导出 mode_active 而不是
    // mode_sel —— mode_active 只在帧边界更新, 与这一帧实际渲染的效果一致;
    // mode_sel 按下即变, 会让 OSD 比画面早一帧改名.
    output  wire   [3:0]    wheel_mode
);

// =====================================================
// ģʽ���壺�� 9 ����ʾЧ��
// =====================================================
localparam MODE_ORG      = 4'd0;
localparam MODE_GRAY     = 4'd1;
localparam MODE_NEG      = 4'd2;
localparam MODE_SEPIA    = 4'd3;
localparam MODE_HISTEQ   = 4'd4;
localparam MODE_CONTRAST = 4'd5;
localparam MODE_GAMMA    = 4'd6;
localparam MODE_BILAT    = 4'd7;
localparam MODE_GUIDED   = 4'd8;
localparam MODE_HDR      = 4'd9;
// 2026-05-23 burn 5: photographic texture modes appended after HDR.
// User asked "8 marble, 9 wood" but those slots were already taken by
// GUIDED / HDR.  Appended at slot 10 / 11 to preserve existing filters.
localparam MODE_MARBLE   = 4'd10;
localparam MODE_WOOD     = 4'd11;
// 2026-10-01 按键重排: 12/13 原是 MOTION / TRACK (已搬到 key4).
// 现在 12..15 是原 key2 的形态学三档 + 原 key4 的直方图, 本模块透传,
// 效果由上游 morphology_5x5 / 下游 hist_osd 做.  16 档正好 4 bit, 15 -> 0 自然回绕.
localparam MODE_ERODE    = 4'd12;
localparam MODE_DILATE   = 4'd13;
localparam MODE_DARK     = 4'd14;
localparam MODE_HIST     = 4'd15;

wire key_p_flag;
wire key_r_flag;
wire key_state;
reg  [3:0] mode_sel;
reg  [3:0] mode_active;
reg        in_vs_d1;

key_filter #(
    .MCNT(3_000_000-1)   // 20 ms at the 150 MHz pixel clock
) u_key_filter(
    .Clk        (clk        ),
    .Reset_n    (rst_n      ),
    .Key        (ctrl_key   ),
    .Key_P_Flag (key_p_flag ),
    .Key_R_Flag (key_r_flag ),
    .Key_state  (key_state  )
);

always @(posedge clk or negedge rst_n) begin
    if(!rst_n)
        mode_sel <= MODE_ORG;
    else if(key_p_flag) begin
        // 2026-10-01: ORG→...→WOOD(11)→ERODE(12)→DILATE(13)→DARK(14)→HIST(15)→ORG
        // 4 bit 满 16 档, HIST + 1 自然回到 ORG.
        mode_sel <= (mode_sel == 4'd7) ? 4'd9 : mode_sel + 4'd1;   // 10-06: skip 8 (guided filter removed)
    end
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        in_vs_d1    <= 1'b0;
        mode_active <= MODE_ORG;
    end else begin
        in_vs_d1 <= in_vs;
        if(~in_vs_d1 & in_vs)
            mode_active <= mode_sel;
    end
end

// =====================================================
// RGB ת Y
// =====================================================
wire [15:0] r_ext = {8'b0, in_r};
wire [15:0] g_ext = {8'b0, in_g};
wire [15:0] b_ext = {8'b0, in_b};

reg [15:0] r_x_76, g_x_150, b_x_29;
always @(posedge clk) begin
    r_x_76  <= (r_ext << 6) + (r_ext << 3) + (r_ext << 2);
    g_x_150 <= (g_ext << 7) + (g_ext << 4) + (g_ext << 2) + (g_ext << 1);
    b_x_29  <= (b_ext << 4) + (b_ext << 3) + (b_ext << 2) + b_ext;
end

reg [15:0] y_sum;
always @(posedge clk) y_sum <= r_x_76 + g_x_150 + b_x_29;

reg [7:0] img_Y;
always @(posedge clk) img_Y <= y_sum[15:8];

reg [2:0] vs_3dly, de_3dly;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin vs_3dly <= 3'b0; de_3dly <= 3'b0; end
    else begin
        vs_3dly <= {vs_3dly[1:0], in_vs};
        de_3dly <= {de_3dly[1:0], in_de};
    end
end

wire y_vsync = vs_3dly[2];
wire y_href  = de_3dly[2];

// =====================================================
// RGB �ӳ��� (9 ��)
// =====================================================
reg [7:0] r_d1, r_d2, r_d3, r_d4, r_d5, r_d6, r_d7, r_d8, r_d9;
reg [7:0] g_d1, g_d2, g_d3, g_d4, g_d5, g_d6, g_d7, g_d8, g_d9;
reg [7:0] b_d1, b_d2, b_d3, b_d4, b_d5, b_d6, b_d7, b_d8, b_d9;
always @(posedge clk) begin
    r_d1 <= in_r;  r_d2 <= r_d1;  r_d3 <= r_d2;
    r_d4 <= r_d3;  r_d5 <= r_d4;  r_d6 <= r_d5;  r_d7 <= r_d6;
    r_d8 <= r_d7;  r_d9 <= r_d8;
    g_d1 <= in_g;  g_d2 <= g_d1;  g_d3 <= g_d2;
    g_d4 <= g_d3;  g_d5 <= g_d4;  g_d6 <= g_d5;  g_d7 <= g_d6;
    g_d8 <= g_d7;  g_d9 <= g_d8;
    b_d1 <= in_b;  b_d2 <= b_d1;  b_d3 <= b_d2;
    b_d4 <= b_d3;  b_d5 <= b_d4;  b_d6 <= b_d5;  b_d7 <= b_d6;
    b_d8 <= b_d7;  b_d9 <= b_d8;
end

// =====================================================
// �Ҷ�
// =====================================================
reg [7:0] gray_d1, gray_d2, gray_d3, gray_d4, gray_d5, gray_d6;
always @(posedge clk) begin
    gray_d1 <= img_Y;  gray_d2 <= gray_d1;
    gray_d3 <= gray_d2; gray_d4 <= gray_d3;
    gray_d5 <= gray_d4; gray_d6 <= gray_d5;
end
wire [23:0] rgb_gray_9 = {gray_d6, gray_d6, gray_d6};

// =====================================================
// ��Ƭ
// =====================================================
wire [7:0] neg_r_now = 8'hff - in_r;
wire [7:0] neg_g_now = 8'hff - in_g;
wire [7:0] neg_b_now = 8'hff - in_b;

reg [23:0] rgb_neg_d1, rgb_neg_d2, rgb_neg_d3, rgb_neg_d4, rgb_neg_d5, rgb_neg_d6, rgb_neg_d7, rgb_neg_d8, rgb_neg_d9;
always @(posedge clk) begin
    rgb_neg_d1 <= {neg_r_now, neg_g_now, neg_b_now};
    rgb_neg_d2 <= rgb_neg_d1; rgb_neg_d3 <= rgb_neg_d2;
    rgb_neg_d4 <= rgb_neg_d3; rgb_neg_d5 <= rgb_neg_d4;
    rgb_neg_d6 <= rgb_neg_d5; rgb_neg_d7 <= rgb_neg_d6;
    rgb_neg_d8 <= rgb_neg_d7; rgb_neg_d9 <= rgb_neg_d8;
end

// =====================================================
// Sepia
// =====================================================
reg [17:0] sepia_r_mul, sepia_g_mul, sepia_b_mul;
always @(posedge clk) begin
    sepia_r_mul <= in_r * 8'd101 + in_g * 8'd197 + in_b * 8'd48;
    sepia_g_mul <= in_r * 8'd89  + in_g * 8'd176 + in_b * 8'd43;
    sepia_b_mul <= in_r * 8'd70  + in_g * 8'd137 + in_b * 8'd34;
end

wire [7:0] sepia_r_now = (sepia_r_mul[17:8] > 10'd255) ? 8'd255 : sepia_r_mul[15:8];
wire [7:0] sepia_g_now = (sepia_g_mul[17:8] > 10'd255) ? 8'd255 : sepia_g_mul[15:8];
wire [7:0] sepia_b_now = (sepia_b_mul[17:8] > 10'd255) ? 8'd255 : sepia_b_mul[15:8];

reg [23:0] rgb_sepia_d1, rgb_sepia_d2, rgb_sepia_d3, rgb_sepia_d4, rgb_sepia_d5, rgb_sepia_d6, rgb_sepia_d7, rgb_sepia_d8;
always @(posedge clk) begin
    rgb_sepia_d1 <= {sepia_r_now, sepia_g_now, sepia_b_now};
    rgb_sepia_d2 <= rgb_sepia_d1; rgb_sepia_d3 <= rgb_sepia_d2;
    rgb_sepia_d4 <= rgb_sepia_d3; rgb_sepia_d5 <= rgb_sepia_d4;
    rgb_sepia_d6 <= rgb_sepia_d5; rgb_sepia_d7 <= rgb_sepia_d6;
    rgb_sepia_d8 <= rgb_sepia_d7;
end

// =====================================================
// Y ͨ���ӳ���
// =====================================================
reg [7:0] y_d1, y_d2, y_d3;
always @(posedge clk) begin
    y_d1 <= img_Y; y_d2 <= y_d1; y_d3 <= y_d2;
end

// =====================================================
// ֱ��ͼͳ��
// =====================================================
wire [7:0]  pixel_level;
// 22 bits, not 20.  The CDF runs to 1920*1080 = 2073600 and 2^20 = 1048576, so
// a 20-bit hop here silently drops bit[20] right where the CDF crosses the
// frame's median grey: the mapping climbs to 129, falls off a cliff to 0, then
// climbs again.  hist_stat and histEQ_proc were both widened to 22 for 1080p
// (see the 16505 scaling note in histEQ_proc); this net was missed, which
// cancelled the whole widening.  720p hid it -- 1280*720 = 921600 < 2^20.
wire [21:0] pixel_level_acc_num;
wire        pixel_level_valid;

hist_stat u_hist_stat(
    .clk                 (clk                 ),
    .rst_n               (rst_n               ),
    .img_vsync           (y_vsync             ),
    .img_href            (y_href              ),
    .img_gray            (img_Y               ),
    .pixel_level         (pixel_level         ),
    .pixel_level_acc_num (pixel_level_acc_num ),
    .pixel_level_valid   (pixel_level_valid   )
);

// =====================================================
// ֱ��ͼ���⻯
// =====================================================
wire        histEQ_start_flag;
wire        eq_vsync;
wire        eq_href;
wire [7:0]  eq_Y;

histEQ_proc u_histEQ_proc(
    .clk                 (clk                 ),
    .rst_n               (rst_n               ),
    .pixel_level         (pixel_level         ),
    .pixel_level_acc_num (pixel_level_acc_num ),
    .pixel_level_valid   (pixel_level_valid   ),
    .histEQ_start_flag   (histEQ_start_flag   ),
    .per_img_vsync       (y_vsync             ),
    .per_img_href        (y_href              ),
    .per_img_gray        (img_Y               ),
    .post_img_vsync      (eq_vsync            ),
    .post_img_href       (eq_href             ),
    .post_img_gray       (eq_Y                )
);

// =====================================================
// �1�70�1�71�1�71�1�77�1�71�1�77�1�70�1�70�1�71�1�77�1�71�1�77�1�71�1�77�1�79�1�75�1�71�1�77�1�71�1�77�1�70�1�74�1�71�1�77�1�70�1�72�1�71�1�77�1�70�1�78�1�71�1�77�1�71�1�77�1�71�1�77�1�71�1�77�1�71�1�77�1�71�1�77�1�71�1�77 9 �1�71�1�77�1�70�1�74�1�71�1�77�1�71�1�77�1�74�1�75
// =====================================================
// [V3 MODIFIED] HISTEQ color recovery with saturation boost.
//
// Previous V2 (pure addition) preserved the chromatic offset
// (R-Y,G-Y,B-Y) in absolute value, but because it adds the same
// scalar "diff" to all three channels, the chromatic component
// becomes relatively smaller compared to the new, larger
// luminance - visually the image looks desaturated / washed out.
//
// V3 adds (R-Y)>>N as a chromatic amplifier.  Formula:
//   R_out = R + (eq_Y - Y) + ((R - Y) >> N)
//         = (1+2^-N)*R + eq_Y - (1+2^-N)*Y
// Same for G and B.  Grays stay grays (R=G=B => R-Y=0 => no boost).
// No multiply anywhere - only shifts and signed adds.
//
// 2026-08-09: N was 1, a 1.5x boost, and on board that overshot.  After
// equalisation the luma is already stretched, so a further 1.5x on the colour
// offset drove saturated regions into the 0/255 clip, and because R, G and B
// clip independently those areas came back as flat blocks of a shifted hue.
// N=2 (1.25x) still answers the desaturation V2 suffered from while leaving
// headroom before the clip.  Delete the term to get V2 back.
//
// Width: r_d8 in [0,255], diff in [-255,255], chroma>>2 in [-64,63]
//        sum range = [-319, 573] -> still fits 11-bit signed, and the clip
//        below is unchanged: 573 sets bit[9], so it saturates to 255.

// Pipeline alignment.  The three terms below have to describe the SAME pixel,
// and before this fix they did not: r_d8 is 8 clocks behind in_r, eq_Y is 6
// (img_Y costs 3, histEQ_proc's bram->mult->round costs 3 more), and y_d8 is
// 11 (that chain is fed from img_Y, which is already 3 deep, and it belongs to
// the bilateral path further down).  So the formula was mixing pixel x-2,
// x and x+3 -- the scalar luma delta got taken across a 5-column span, and
// since it is added to R/G/B which then clip independently at 0/255, edges
// picked up blocky hue shifts.  Bring both strays to 8:
reg [7:0] eq_Y_d1, eq_Y_d2;   // eq_Y is 6 -> eq_Y_d2 is 8
reg [7:0] y_a7,   y_a8;       // y_d3 is 6 -> y_a8   is 8  (y_d3 is declared
                              // above; the y_d4..y_d12 chain is left alone
                              // because the bilateral path still needs it)
always @(posedge clk) begin
    eq_Y_d1 <= eq_Y;    eq_Y_d2 <= eq_Y_d1;
    y_a7    <= y_d3;    y_a8    <= y_a7;
end

wire signed [10:0] histeq_y_diff =
    $signed({3'b000, eq_Y_d2}) - $signed({3'b000, y_a8});

wire signed [10:0] histeq_r_chroma =
    $signed({3'b000, r_d8}) - $signed({3'b000, y_a8});
wire signed [10:0] histeq_g_chroma =
    $signed({3'b000, g_d8}) - $signed({3'b000, y_a8});
wire signed [10:0] histeq_b_chroma =
    $signed({3'b000, b_d8}) - $signed({3'b000, y_a8});

localparam integer HISTEQ_CHROMA_SHIFT = 2;   // 1 => 1.5x, 2 => 1.25x, 3 => 1.125x

wire signed [10:0] histeq_r_chroma_half = histeq_r_chroma >>> HISTEQ_CHROMA_SHIFT;
wire signed [10:0] histeq_g_chroma_half = histeq_g_chroma >>> HISTEQ_CHROMA_SHIFT;
wire signed [10:0] histeq_b_chroma_half = histeq_b_chroma >>> HISTEQ_CHROMA_SHIFT;

wire signed [10:0] histeq_r_sum =
    $signed({3'b000, r_d8}) + histeq_y_diff + histeq_r_chroma_half;
wire signed [10:0] histeq_g_sum =
    $signed({3'b000, g_d8}) + histeq_y_diff + histeq_g_chroma_half;
wire signed [10:0] histeq_b_sum =
    $signed({3'b000, b_d8}) + histeq_y_diff + histeq_b_chroma_half;

reg [7:0] eq_r_out, eq_g_out, eq_b_out;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        eq_r_out <= 8'd0;
        eq_g_out <= 8'd0;
        eq_b_out <= 8'd0;
    end else begin
        eq_r_out <= histeq_r_sum[10]     ? 8'd0   :
                    (|histeq_r_sum[9:8]) ? 8'd255 : histeq_r_sum[7:0];
        eq_g_out <= histeq_g_sum[10]     ? 8'd0   :
                    (|histeq_g_sum[9:8]) ? 8'd255 : histeq_g_sum[7:0];
        eq_b_out <= histeq_b_sum[10]     ? 8'd0   :
                    (|histeq_b_sum[9:8]) ? 8'd255 : histeq_b_sum[7:0];
    end
end

wire [23:0] rgb_histeq_9 = {eq_r_out, eq_g_out, eq_b_out};

// =====================================================
// �Աȶ�
// =====================================================
wire        contrast_in_vs;
wire        contrast_in_de;
wire [7:0]  contrast_in_r;
wire [7:0]  contrast_in_g;
wire [7:0]  contrast_in_b;

assign contrast_in_vs = (mode_active == MODE_CONTRAST) ? in_vs : 1'b0;
assign contrast_in_de = (mode_active == MODE_CONTRAST) ? in_de : 1'b0;
assign contrast_in_r  = (mode_active == MODE_CONTRAST) ? in_r  : 8'd0;
assign contrast_in_g  = (mode_active == MODE_CONTRAST) ? in_g  : 8'd0;
assign contrast_in_b  = (mode_active == MODE_CONTRAST) ? in_b  : 8'd0;

wire        contrast_vsync;
wire        contrast_href;
wire [7:0]  contrast_Y;
wire [7:0]  contrast_Cb;
wire [7:0]  contrast_Cr;

VIP_RGB888_YCbCr444 VIP_RGB888_YCbCr444_inst(
    .clk            (clk            ),
    .rst_n          (rst_n          ),
    .per_img_vsync  (contrast_in_vs ),
    .per_img_href   (contrast_in_de ),
    .per_img_red    (contrast_in_r  ),
    .per_img_green  (contrast_in_g  ),
    .per_img_blue   (contrast_in_b  ),
    .post_img_vsync (contrast_vsync ),
    .post_img_href  (contrast_href  ),
    .post_img_Y     (contrast_Y     ),
    .post_img_Cb    (contrast_Cb    ),
    .post_img_Cr    (contrast_Cr    )
);

wire [7:0] contrast_Y_lut;
Curve_Contrast_Array Curve_Contrast_Array_inst(
    .Pre_Data   (contrast_Y     ),
    .Post_Data  (contrast_Y_lut )
);

reg        contrast_vsync_r1;
reg        contrast_href_r1;
reg [7:0]  contrast_Y_r1;
reg [7:0]  contrast_Cb_r1;
reg [7:0]  contrast_Cr_r1;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        contrast_vsync_r1 <= 1'b0; contrast_href_r1 <= 1'b0;
        contrast_Y_r1 <= 8'd0; contrast_Cb_r1 <= 8'd128; contrast_Cr_r1 <= 8'd128;
    end else begin
        contrast_vsync_r1 <= contrast_vsync;
        contrast_href_r1  <= contrast_href;
        if(contrast_href) begin
            contrast_Y_r1  <= contrast_Y_lut;
            contrast_Cb_r1 <= contrast_Cb;
            contrast_Cr_r1 <= contrast_Cr;
        end else begin
            contrast_Y_r1 <= 8'd0; contrast_Cb_r1 <= 8'd128; contrast_Cr_r1 <= 8'd128;
        end
    end
end

wire        contrast_vsync_done;
wire        contrast_href_done;
wire [7:0]  contrast_r;
wire [7:0]  contrast_g;
wire [7:0]  contrast_b;

VIP_YCbCr444_RGB888 VIP_YCbCr444_RGB888_inst(
    .clk            (clk                ),
    .rst_n          (rst_n              ),
    .per_img_vsync  (contrast_vsync_r1  ),
    .per_img_href   (contrast_href_r1   ),
    .per_img_Y      (contrast_Y_r1      ),
    .per_img_Cb     (contrast_Cb_r1     ),
    .per_img_Cr     (contrast_Cr_r1     ),
    .post_img_vsync (contrast_vsync_done),
    .post_img_href  (contrast_href_done ),
    .post_img_red   (contrast_r         ),
    .post_img_green (contrast_g         ),
    .post_img_blue  (contrast_b         )
);

wire [23:0] rgb_contrast_raw = {contrast_r, contrast_g, contrast_b};

reg [23:0] rgb_contrast_d1, rgb_contrast_d2;
always @(posedge clk) begin
    rgb_contrast_d1 <= rgb_contrast_raw;
    rgb_contrast_d2 <= rgb_contrast_d1;
end

// =====================================================
// Gamma
// =====================================================
wire [7:0] gamma_r_lut, gamma_g_lut, gamma_b_lut;
Curve_Gamma_2P2 Curve_Gamma_2P2_r_inst(.Pre_Data(in_r), .Post_Data(gamma_r_lut));
Curve_Gamma_2P2 Curve_Gamma_2P2_g_inst(.Pre_Data(in_g), .Post_Data(gamma_g_lut));
Curve_Gamma_2P2 Curve_Gamma_2P2_b_inst(.Pre_Data(in_b), .Post_Data(gamma_b_lut));

reg [7:0] gamma_r_d1, gamma_r_d2, gamma_r_d3, gamma_r_d4, gamma_r_d5, gamma_r_d6, gamma_r_d7, gamma_r_d8, gamma_r_d9;
reg [7:0] gamma_g_d1, gamma_g_d2, gamma_g_d3, gamma_g_d4, gamma_g_d5, gamma_g_d6, gamma_g_d7, gamma_g_d8, gamma_g_d9;
reg [7:0] gamma_b_d1, gamma_b_d2, gamma_b_d3, gamma_b_d4, gamma_b_d5, gamma_b_d6, gamma_b_d7, gamma_b_d8, gamma_b_d9;

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        gamma_r_d1 <= 8'd0; gamma_r_d2 <= 8'd0; gamma_r_d3 <= 8'd0; gamma_r_d4 <= 8'd0; gamma_r_d5 <= 8'd0; gamma_r_d6 <= 8'd0; gamma_r_d7 <= 8'd0; gamma_r_d8 <= 8'd0; gamma_r_d9 <= 8'd0;
        gamma_g_d1 <= 8'd0; gamma_g_d2 <= 8'd0; gamma_g_d3 <= 8'd0; gamma_g_d4 <= 8'd0; gamma_g_d5 <= 8'd0; gamma_g_d6 <= 8'd0; gamma_g_d7 <= 8'd0; gamma_g_d8 <= 8'd0; gamma_g_d9 <= 8'd0;
        gamma_b_d1 <= 8'd0; gamma_b_d2 <= 8'd0; gamma_b_d3 <= 8'd0; gamma_b_d4 <= 8'd0; gamma_b_d5 <= 8'd0; gamma_b_d6 <= 8'd0; gamma_b_d7 <= 8'd0; gamma_b_d8 <= 8'd0; gamma_b_d9 <= 8'd0;
    end else begin
        if(in_de) begin
            gamma_r_d1 <= gamma_r_lut;gamma_g_d1 <= gamma_g_lut;gamma_b_d1 <= gamma_b_lut;
        end else begin
            gamma_r_d1 <= 8'd0;gamma_g_d1 <= 8'd0;gamma_b_d1 <= 8'd0;
        end
        gamma_r_d2 <= gamma_r_d1;gamma_r_d3 <= gamma_r_d2;gamma_r_d4 <= gamma_r_d3;
        gamma_r_d5 <= gamma_r_d4;gamma_r_d6 <= gamma_r_d5;gamma_r_d7 <= gamma_r_d6;
        gamma_r_d8 <= gamma_r_d7;gamma_r_d9 <= gamma_r_d8;

        gamma_g_d2 <= gamma_g_d1;gamma_g_d3 <= gamma_g_d2;gamma_g_d4 <= gamma_g_d3;
        gamma_g_d5 <= gamma_g_d4;gamma_g_d6 <= gamma_g_d5;gamma_g_d7 <= gamma_g_d6;
        gamma_g_d8 <= gamma_g_d7;gamma_g_d9 <= gamma_g_d8;

        gamma_b_d2 <= gamma_b_d1;gamma_b_d3 <= gamma_b_d2;gamma_b_d4 <= gamma_b_d3;
        gamma_b_d5 <= gamma_b_d4;gamma_b_d6 <= gamma_b_d5;gamma_b_d7 <= gamma_b_d6;
        gamma_b_d8 <= gamma_b_d7;gamma_b_d9 <= gamma_b_d8;
    end
end
wire [23:0] rgb_gamma_d9 = {gamma_r_d9, gamma_g_d9, gamma_b_d9};


// =====================================================
// ˫���˲�
// =====================================================
wire        bilat_vsync;
wire        bilat_href;
wire [7:0]  bilat_gray;

bilateral_filter_proc
#(
    .IMG_HDISP  (11'd1920 ),
    .IMG_VDISP  (11'd1080 )
)
u_bilateral_filter_proc
(
    .clk             (clk              ),
    .rst_n           (rst_n            ),
    .per_img_vsync   (~y_vsync         ),
    .per_img_href    (y_href           ),
    .per_img_gray    (img_Y            ),
    .post_img_vsync  (bilat_vsync      ),
    .post_img_href   (bilat_href       ),
    .post_img_gray   (bilat_gray       )
);

// ======== ˫���˲���ɫ�ָ� ========
// �� in_r �� bilat_gray ���ӳ� 15 �� (Y=3 + matrix=2 + pipeline=9 + out=1)
reg [7:0] r_d10, r_d11, r_d12, r_d13, r_d14, r_d15;
reg [7:0] g_d10, g_d11, g_d12, g_d13, g_d14, g_d15;
reg [7:0] b_d10, b_d11, b_d12, b_d13, b_d14, b_d15;
reg [7:0] y_d4, y_d5, y_d6, y_d7, y_d8, y_d9, y_d10, y_d11, y_d12;
always @(posedge clk) begin
    r_d10<=r_d9; r_d11<=r_d10; r_d12<=r_d11; r_d13<=r_d12; r_d14<=r_d13; r_d15<=r_d14;
    g_d10<=g_d9; g_d11<=g_d10; g_d12<=g_d11; g_d13<=g_d12; g_d14<=g_d13; g_d15<=g_d14;
    b_d10<=b_d9; b_d11<=b_d10; b_d12<=b_d11; b_d13<=b_d12; b_d14<=b_d13; b_d15<=b_d14;
    y_d4<=y_d3; y_d5<=y_d4; y_d6<=y_d5; y_d7<=y_d6; y_d8<=y_d7; y_d9<=y_d8; y_d10<=y_d9; y_d11<=y_d10; y_d12<=y_d11;
end

wire signed [9:0] y_diff = $signed({2'b0, bilat_gray}) - $signed({2'b0, y_d12});
wire signed [9:0] bilat_r_s = $signed({2'b0, r_d15}) + y_diff;
wire signed [9:0] bilat_g_s = $signed({2'b0, g_d15}) + y_diff;
wire signed [9:0] bilat_b_s = $signed({2'b0, b_d15}) + y_diff;
wire [7:0] bilat_r_w = bilat_r_s[9] ? 8'd0 : (|bilat_r_s[8]) ? 8'd255 : bilat_r_s[7:0];
wire [7:0] bilat_g_w = bilat_g_s[9] ? 8'd0 : (|bilat_g_s[8]) ? 8'd255 : bilat_g_s[7:0];
wire [7:0] bilat_b_w = bilat_b_s[9] ? 8'd0 : (|bilat_b_s[8]) ? 8'd255 : bilat_b_s[7:0];

// [PIPELINE] ���һ��, ��� "��-��-����-��ѡһ mux" �����
reg [7:0] bilat_r, bilat_g, bilat_b;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        bilat_r <= 8'd0; bilat_g <= 8'd0; bilat_b <= 8'd0;
    end else begin
        bilat_r <= bilat_r_w;
        bilat_g <= bilat_g_w;
        bilat_b <= bilat_b_w;
    end
end
wire [23:0] rgb_bilat = {bilat_r, bilat_g, bilat_b};

// ======== ˫���˲� hs/vs/de �ӳٲ��� (v2: +1 �Ĳ�ɫ����, �� 16) ========
localparam integer BILAT_SYNC_DLY = 16;   // ԭ 15, +1 �� bilat_r/g/b ����

reg [BILAT_SYNC_DLY-1:0] hs_bilat_dly;
reg [BILAT_SYNC_DLY-1:0] vs_bilat_dly;
reg [BILAT_SYNC_DLY-1:0] de_bilat_dly;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        hs_bilat_dly <= {BILAT_SYNC_DLY{1'b0}};
        vs_bilat_dly <= {BILAT_SYNC_DLY{1'b0}};
        de_bilat_dly <= {BILAT_SYNC_DLY{1'b0}};
    end else begin
        hs_bilat_dly <= {hs_bilat_dly[BILAT_SYNC_DLY-2:0], in_hs};
        vs_bilat_dly <= {vs_bilat_dly[BILAT_SYNC_DLY-2:0], in_vs};
        de_bilat_dly <= {de_bilat_dly[BILAT_SYNC_DLY-2:0], in_de};
    end
end


// ============================================================
// �����˲� - 5x5 RGB ��ͨ���汾
// �㷨˼·: �����ɵ� "Y ͨ���������� + ���Ȳ�ӳ��" ����,
//           ֱ�Ӷ� R/G/B ����ͨ���ֱ��� 5x5 �Ե����˲�.
//   * ���ڴ� 3x3 ���� 5x5 (���� 9 -> 25), ƽ���뾶�Ӵ�;
//   * ��ͨ����������, ������ɫ����ƽ��, ������ Y ͨ��ƫɫ����;
//   * ���� 5x5 �ѱ��������� 3x3 ��Ҫǿ, ���ټ���.
// ��Դ����: ���������� 4 �� 1280-deep FIFO * 3 · = 12 ��;
//           pipeline ÿ·Լ 30 ���˷���, ��· ~ 90 �� (Cyclone IV ����).
// ʱ�����: ���� 5x5 ·�����ӳ� = ���� 3 �� + ��ˮ 12 �� + ��� 1 �� = 16 ��.
// ============================================================

// ---------------------- ��· 5x5 �Ե����˲� ----------------------
//   per_img_vsync ȡ ~in_vs (��Ч��), per_img_href = in_de.
//   in_r/in_g/in_b ֱ��ι��, ������ RGB->Y ת��.
// 2026-10-06: guided filter removed (slot 8 is skipped by the key, see mode_sel).
wire [23:0] rgb_guided = {in_r, in_g, in_b};

// ---------------------- �����˲� hs/vs/de �ӳٲ��� ----------------------
// 5x5 �������ӳ� = �������� 3 �� + ��ˮ�� 12 �� + ����Ĵ� 1 �� = 16 ��.
// (�ɷ����� 34 ��, ��Ϊ�� RGB��Y �� 3 �� + ���� 3x3 + ���β�ɫ�ع�.)
localparam integer GUIDED_SYNC_DLY = 16;

reg [GUIDED_SYNC_DLY-1:0] hs_guided_dly;
reg [GUIDED_SYNC_DLY-1:0] vs_guided_dly;
reg [GUIDED_SYNC_DLY-1:0] de_guided_dly;

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        hs_guided_dly <= {GUIDED_SYNC_DLY{1'b0}};
        vs_guided_dly <= {GUIDED_SYNC_DLY{1'b0}};
        de_guided_dly <= {GUIDED_SYNC_DLY{1'b0}};
    end else begin
        hs_guided_dly <= {hs_guided_dly[GUIDED_SYNC_DLY-2:0], in_hs};
        vs_guided_dly <= {vs_guided_dly[GUIDED_SYNC_DLY-2:0], in_vs};
        de_guided_dly <= {de_guided_dly[GUIDED_SYNC_DLY-2:0], in_de};
    end
end

// =====================================================
//	HDR
// 7 hs/vs/de 
// =====================================================
wire [7:0] hdr_r, hdr_g, hdr_b;
wire       hdr_hs, hdr_vs, hdr_de;

hdr_tone_map u_hdr_tone_map (
    .clk    (clk    ),
    .rst_n  (rst_n  ),
    .in_hs  (in_hs  ),
    .in_vs  (in_vs  ),
    .in_de  (in_de  ),
    .in_r   (in_r   ),
    .in_g   (in_g   ),
    .in_b   (in_b   ),
    .out_hs (hdr_hs ),
    .out_vs (hdr_vs ),
    .out_de (hdr_de ),
    .out_r  (hdr_r  ),
    .out_g  (hdr_g  ),
    .out_b  (hdr_b  )
);



wire [23:0] rgb_hdr = {hdr_r, hdr_g, hdr_b};
// =====================================================
// 9 ��ͬ���ź��ӳ��� (���ؼ�ģʽ��)
// =====================================================
reg [8:0] hs_9dly, vs_9dly, de_9dly;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        hs_9dly <= 9'b0; vs_9dly <= 9'b0; de_9dly <= 9'b0;
    end else begin
        hs_9dly <= {hs_9dly[7:0], in_hs};
        vs_9dly <= {vs_9dly[7:0], in_vs};
        de_9dly <= {de_9dly[7:0], in_de};
    end
end

// =====================================================
// ���ѡ���� (���)
// =====================================================
reg [23:0] rgb_mux;
always @(*) begin
    case(mode_active)
        MODE_ORG      : rgb_mux = {in_r, in_g, in_b};
        MODE_GRAY     : rgb_mux = rgb_gray_9;
        MODE_NEG      : rgb_mux = rgb_neg_d9;
        MODE_SEPIA    : rgb_mux = rgb_sepia_d8;
        MODE_HISTEQ   : rgb_mux = rgb_histeq_9;
        MODE_CONTRAST : rgb_mux = rgb_contrast_d2;
        MODE_GAMMA    : rgb_mux = rgb_gamma_d9;
        MODE_BILAT    : rgb_mux = rgb_bilat;
        MODE_GUIDED   : rgb_mux = rgb_guided;
        MODE_HDR      : rgb_mux = rgb_hdr;
        // burn 5: marble/wood modes pass-through original RGB.
        // color_replace module (downstream) does the actual texture
        // substitution on red pixels using texture_mode signal.
        MODE_MARBLE   : rgb_mux = {in_r, in_g, in_b};
        MODE_WOOD     : rgb_mux = {in_r, in_g, in_b};
        // 12..15 (ERODE / DILATE / DARK / HIST): 效果在别的模块, 这里透传
        default       : rgb_mux = {in_r, in_g, in_b};
    endcase
end

assign out_rgb = rgb_mux;

// burn 5: MODE_MARBLE / MODE_WOOD piggy-back the ORG sync path - rgb_mux
// passes {in_r,in_g,in_b} verbatim, so no delay needed on sync signals.
wire mode_passthrough_sync = (mode_active == MODE_ORG)
                          || (mode_active == MODE_MARBLE)
                          || (mode_active == MODE_WOOD)
                          || (mode_active == MODE_ERODE)
                          || (mode_active == MODE_DILATE)
                          || (mode_active == MODE_DARK)
                          || (mode_active == MODE_HIST);

assign out_hs  = mode_passthrough_sync         ? in_hs :
                 (mode_active == MODE_HDR)     ? hdr_hs :
                 (mode_active == MODE_BILAT)   ? hs_bilat_dly [BILAT_SYNC_DLY-1]  :
                 (mode_active == MODE_GUIDED)  ? hs_guided_dly[GUIDED_SYNC_DLY-1] :
                                                 hs_9dly[8];
assign out_vs  = mode_passthrough_sync         ? in_vs :
                 (mode_active == MODE_HDR)     ? hdr_vs :
                 (mode_active == MODE_BILAT)   ? vs_bilat_dly [BILAT_SYNC_DLY-1]  :
                 (mode_active == MODE_GUIDED)  ? vs_guided_dly[GUIDED_SYNC_DLY-1] :
                                                 vs_9dly[8];
assign out_de  = mode_passthrough_sync         ? in_de :
                 (mode_active == MODE_HDR)     ? hdr_de :
                 (mode_active == MODE_BILAT)   ? de_bilat_dly [BILAT_SYNC_DLY-1]  :
                 (mode_active == MODE_GUIDED)  ? de_guided_dly[GUIDED_SYNC_DLY-1] :
                                                 de_9dly[8];

// burn 5: texture_mode export driven by mode_active.
//   MARBLE -> 2'b01 (color_replace selects ROM bank 0)
//   WOOD   -> 2'b10 (color_replace selects ROM bank 1)
//   else   -> 2'b00 (color_replace passes through rgb_in)
assign texture_mode = (mode_active == MODE_MARBLE) ? 2'b01 :
                      (mode_active == MODE_WOOD)   ? 2'b10 :
                                                     2'b00;

// 2026-10-01: 原 key2 / key4 的功能. mode_active 只在帧边界变,
// morphology_5x5 和 hist_osd 再各自在自己的帧边界锁存, 所以一次按键
// 不会在一帧中间切换.
assign morph_sel = (mode_active == MODE_ERODE)  ? 2'd1 :
                   (mode_active == MODE_DILATE) ? 2'd2 :
                   (mode_active == MODE_DARK)   ? 2'd3 : 2'd0;
assign hist_en   = (mode_active == MODE_HIST);

// 2026-09-04: 档位号直接上屏, 见端口处说明
assign wheel_mode = mode_active;

endmodule