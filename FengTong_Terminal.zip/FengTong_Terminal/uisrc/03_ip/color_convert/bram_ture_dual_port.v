module bram_ture_dual_port
#(
    parameter C_ADDR_WIDTH  = 8,//地址，灰度值位数
    parameter C_DATA_WIDTH  = 8
)(
    input  wire                     clka    ,
    input  wire                     wea     ,
    input  wire [C_ADDR_WIDTH-1:0]  addra   ,
    input  wire [C_DATA_WIDTH-1:0]  dina    ,
    output reg  [C_DATA_WIDTH-1:0]  douta   ,
    input  wire                     clkb    ,
    input  wire                     web     ,
    input  wire [C_ADDR_WIDTH-1:0]  addrb   ,
    input  wire [C_DATA_WIDTH-1:0]  dinb    ,
    output reg  [C_DATA_WIDTH-1:0]  doutb   
);
//----------------------------------------------------------------------
//地址是255，为0-255的灰度值，数据位宽可以根据数据量更改
localparam C_MEM_DEPTH = {C_ADDR_WIDTH{1'b1}};

reg     [C_DATA_WIDTH-1:0]      mem [C_MEM_DEPTH:0];//默认八位宽，深度256的ram
integer                         i;

initial
begin
    for(i = 0;i <= C_MEM_DEPTH;i = i+1)
        mem[i] = 0;
end 

always @(posedge clka)
begin
    if(wea == 1'b1)
        mem[addra] <= dina; 
    else
        douta <= mem[addra];
end

always @(posedge clkb)
begin
    if(web == 1'b1)
        mem[addrb] <= dinb; 
    else
        doutb <= mem[addrb];
end

endmodule
