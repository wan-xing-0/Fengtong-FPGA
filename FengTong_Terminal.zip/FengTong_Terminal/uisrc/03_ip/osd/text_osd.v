//---------------------------------------------------------------------------
// text_osd -- character overlay and vendor logo, drawn last in the chain.
//
// WHY
//   The brief scores an on-screen display carrying the Anlogic logo, and it
//   scores multi-algorithm switching "with the active mode shown on screen".
//   Both were the same missing piece: there was no way to put a glyph on this
//   picture.  This module is that way -- a status panel naming the active
//   position of all three keys plus a live motion-block count, and the logo.
//
//   It also ends a standing cost: until now the only way to tell which of the
//   13 wheel positions was live was to count button presses since power-up and
//   hope.  That has already caused one misdiagnosis (a bilateral-filter smooth
//   read as a dark-lift bug) because two effects were stacked unnoticed.
//
// POSITION IN THE CHAIN
//   Last, after hist_osd and immediately before hdmi_tx, so the text sits on
//   top of every effect and reads identically in all wheel positions.  Fed
//   frame-active-high vs, same as hist_osd.
//
// NO ARITHMETIC ON THE PIXEL PATH
//   Magnification is a power of two so every screen-to-cell conversion is a
//   bit slice: no divider, no multiplier, no DSP.  This is not stylistic --
//   the pixel-clock group runs at about +0.10ns of setup slack across the
//   whole design, and a multiply here would be competing for that budget with
//   every other module in the same domain.  The arithmetic that is genuinely
//   needed -- binary-to-BCD for the two counts -- is spread over 8 clocks (see
//   [BCD] below) so it never forms a deep combinational path either.
//
//   (Earlier revisions of this comment attributed the 0.10ns to "the affine
//   BRAM address chain" and then to "the fifowait reset tree".  Both were
//   wrong about the mechanism; measured 2026-09-05 evening, the worst paths
//   are long NETS out of u_affine's coordinate registers -- 85% routing, 3-4
//   logic levels.  The conclusion for this file never changed.)
//
// THE WORDMARK (2026-09-05)
//   The bench read the graphic mark as clear but asked for the "Anlogic" text
//   under it, which is what the vendor's own lockup looks like.  It is drawn
//   out of the FONT ROM, not a second bitmap, and that choice is the whole
//   design:
//
//     * No new source file, so the three TD file lists stay untouched.
//     * No new $readmemh, so no new way for a ROM to load silently empty --
//       the failure that costs a scored item and shows up only on a TV.
//     * No new ERAM.  The font was 0x20..0x5F in a 512x8 array, a quarter of
//       one block; extending it to 0x20..0x7F for six lowercase glyphs fills
//       the same block instead of allocating another.
//     * One ROM port serves both regions because the panel is at the far left
//       and the wordmark at the far right, so no pixel is inside both.
//
//   It is "Anlogic", not "ANLOGIC".  The panel stays uppercase because it is
//   instrumentation, but a brand mark rendered in the wrong case is a scored
//   item shown wrong, so six lowercase glyphs (c g i l n o) were added to the
//   generator.  Fixed-width cells put visibly wide gaps around 'l' and 'i';
//   that is inherent to an 8px cell renderer and is not worth a variable-pitch
//   pixel path to fix.
//
//   Sizing: WM_LOG2 = 2 gives 32px cells, so the text is as tall as one panel
//   row and 224px wide against the mark's 128.  WM_LOG2 = 1 halves it to
//   112x16, which fits under the mark without moving LX0 but is small enough
//   that the 4-row x-height of the lowercase reads as 8px on screen.
//
// THE INSTRUMENT READOUT (2026-09-05)
//   "处理延迟可视化" is a scored advanced item and latency_meter.v measures
//   it; this module displays it.  It gets its own block at the BOTTOM LEFT
//   rather than more rows on the status panel, for two reasons:
//
//     * hist_osd draws its box at x 64..575, y 64..319.  The status panel at
//       four rows already covers the top third of that when F9 is on;
//       growing it to seven rows would have covered nearly all of it.
//       Nothing else needed to move.
//     * These are measurements, not mode names.  The latency number is the
//       evidence behind the whole "deterministic real-time" claim and the
//       target count is the evidence that detection is running.  As their own
//       instrument they read as readings; appended to a list of key positions
//       they read as more mode names.
//
//   Three rows as of 09-05 evening -- latency in ms, latency in frames, and
//   the detected target count from ccl_blob.  A letter beside the count means
//   that module blew one of its budgets and the reading is suspect: L labels,
//   M merge list, T blanking time.  See [OVF] below for what each one is
//   telling you to change.
//
//   Three regions share the one font ROM port.  The mux is a priority chain,
//   so what it needs is that no pixel is inside two regions -- the panel is
//   y 32..159, the readout y 968..1063, the wordmark x 1664..1887, so all
//   three are pairwise disjoint.  RE-CHECK THAT WHEN MOVING ANY OF THEM: the
//   failure is not a wrong pixel, it is one region silently rendering
//   another's glyphs, and the panel and the readout are separated by y alone.
//
//   Uppercase only, including the units.  The font carries 0x20..0x7F but
//   only six lowercase glyphs (c g i l n o) were ever cut, for "Anlogic" --
//   'm' and 's' are blank slots, so "ms" would render as nothing at all.
//
// LATENCY 2 clocks, applied equally to data, de and vs -- same as hist_osd, so
// inserting this does not disturb anything downstream.
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module text_osd #(
// Status panel: NCOL x NROW cells of 8x8 pixels each, magnified 2^SCALE_LOG2.
// At SCALE_LOG2=2 a cell is 32x32, so the panel below is 512x128.
parameter [11:0] TX0        = 12'd32,
parameter [11:0] TY0        = 12'd32,
parameter integer SCALE_LOG2 = 2,
parameter integer NCOL       = 16,

// 4 -> 5 on 2026-09-08.  The fifth row is the F9 overlay selector, and it went
// in because of a bench report that F9 "only has two positions".  It has four;
// two of them differ only by whether detection boxes are drawn, and on a scene
// where the detector was finding nothing those two were pixel-identical to the
// other two.  A mode readout is the difference between "the button is broken"
// and "the detector found nothing", and those want opposite fixes.
//
// 5 -> 6 on 2026-09-23.  The sixth row is the SERVO head's two pulse widths.
// ⭐ IT IS THE FIFTH ROW'S ARGUMENT ARRIVING FOR AN ACTUATOR instead of a
// selector, and it is stronger here: "the head did not move" has at least
// five causes -- wrong pin, no 5 V on the servo rail, signal voltage too low,
// the loop never issuing a step, the loop issuing steps into a travel clamp
// -- and a photograph of a motionless head separates none of them.  Two
// numbers separate all five.  Unlike every other readout on this panel the
// failure can also be MECHANICAL, which is the one kind this project has no
// other way to see.
//
// The panel now spans y 32..223.  The arithmetic the LTY0 note below asks
// for: TY0 + NROW*32 = 224, LTY0 = 904, so the gap is 680 px and the two
// blocks stay disjoint.  Still clear of the wordmark (x 1664+) and the logo
// (x 1712+), and still drawn over hist_osd, which is deliberate -- the
// histogram is a debug aid, the state panel is a scoring item.
//
// 6 -> 4 on 10-03 evening (user): the panel holds only what is true in every
// mode -- wheel / affine / mode / latency.  MORPH went (it is a wheel position
// since 10-01), MOTION and SERVO moved to the security page below, LATENCY
// and FRAMES came up from the readout as one row.  All rows Chinese.
parameter integer NROW       = 4,

// Instrument readout: NCOL x LTROW cells of the same size as the status panel,
// put at the bottom left.  See THE INSTRUMENT READOUT in the header for why it
// is not just more panel rows.
//
// LTY0 was 984 while this was two rows.  The third row (target count, 09-05
// evening) would have run 984+3*32 = 1080 and touched the last scan line, so
// the block moved up to 968..1063 and kept a 16px bottom margin.
//
// 09-08: a fourth row (the detector's servo state) moved it up again by one
// cell, to 936..1063, same 16px bottom margin.  The invariant to keep is that
// this block stays disjoint from the STATUS PANEL, because the two share an x
// range and neither is drawn on top of the other -- the panel now ends at
// y 191 and there is no arithmetic anywhere tying the two apart, so a fifth
// row here or a sixth there has to be checked by hand.  Current gap: 744 px.
//
// 09-18: a fifth row (the face detector) moved it up one more cell, to
// 904..1063, keeping the same 16px bottom margin.  Gap to the panel: 712 px.
// The arithmetic to redo if a sixth row is ever added: LTY0 + LTROW*32 must
// stay <= 1064, and LTY0 must stay above TY0 + NROW*32 = 192.
//
// 09-25: rows six to eight are the ToF ranger and the size it produces (DIST,
// SIZE, PIX -- see tof_size.v), so the block moved up three cells to
// 808..1063, same 16px bottom margin.  Gap to the panel (ends at 223): 584 px.
// Still clear of hist_osd's box (y 64..319).
//
// 10-02: rows nine and ten are the table distance and the QC stable flag
// (qc_thick.v), so the block moved up two cells to 744..1063, same 16px
// bottom margin.  Gap to the panel (ends at 223): 520 px.
// 10-03: rows five to nine are Chinese -- see CHINESE GLYPHS below.
//
// ⭐ 10-03 evening (user): ONE PAGE PER MODE, BOTTOM-ANCHORED.  The readout
// shows only the instruments of the active key4 mode -- security: MOTION +
// SERVO (2 rows); inspection: TARGETS, MARGIN, 距离 .. 质检 (7); face: count +
// candidates (2); raw: nothing.  A page of k rows occupies the LAST k of the
// LTROW rows, so its bottom edge never moves, and rows above it are not
// drawn at all (no dimmed wash).  LTROW = the longest page; 840 + 7*32 = 1064,
// the same 16 px bottom margin.  Gap to the panel (ends at 159): 680 px.
parameter [11:0] LTX0      = 12'd32,
parameter [11:0] LTY0      = 12'd808,     // 10-06: 840 -> 808, the BOX page grew a row (表面)
parameter integer LTROW    = 8,

// Logo: 64x32 source, magnified 2^LOGO_LOG2 -> 128x64 at the default.
//
// LX0 was 1760 until the wordmark went in below it.  The wordmark is wider
// than the mark (224 vs 128), so the pair is centred as a unit instead: the
// block spans WX0..WX0+223 = 1664..1887, which keeps the same 32px right
// margin the logo had on its own, and LX0 = 1664 + (224-128)/2 = 1712 puts
// the mark on the wordmark's centre line.
parameter [11:0] LX0       = 12'd1712,
parameter [11:0] LY0       = 12'd32,
parameter integer LOGO_LOG2 = 1,

// Vendor wordmark, drawn out of the font ROM rather than a second bitmap --
// see THE WORDMARK in the header.  Seven 8x8 cells magnified 2^WM_LOG2, so
// 224x32 at the default, sitting 8px under the 64-tall logo (32+64+8 = 104).
parameter [11:0] WX0      = 12'd1664,
parameter [11:0] WY0      = 12'd104,
parameter integer WM_LOG2 = 2,

// Brand colours, lifted from the vendor artwork.  The blue is raised well
// above the source 0x1C2D4E: at native darkness the mark vanishes against any
// dim scene, and the logo has to stay legible over arbitrary video.
parameter [23:0] LOGO_BLUE = 24'h4080E0,
parameter [23:0] LOGO_RED  = 24'hFF2029,
parameter [23:0] TEXT_FG   = 24'hFFFFFF,

// Wordmark ink.  Same value as LOGO_BLUE, written out rather than referenced
// so the two can be split without thinking about parameter order.  White also
// works and is the fallback if the blue reads as dim on the bench.
parameter [23:0] WM_FG     = 24'h4080E0

// 10-30 (final OSD, user): the per-row switches DET_CNN / SHAPE_ROW /
// COLOR_ROW / STAFF_ROW / TOF_ROW / STD_ROWS / STAIN_ROW / RGB_ROW are gone
// with the rows they switched -- the bottom-left block now has exactly the
// pages described at [PAGES].  Rollback = text_osd.v.pre_1030 together with
// osd_cn.hex.pre_1030 (six glyph slots were re-used, see gen_cn_font.py).
)(
input  wire        clk,
input  wire        rst_n,
input  wire        en,

// Live state, all free-running -- nothing here is sampled by the pixel path.
input  wire [3:0]  wheel_mode,     // color_convert    0..15
// (morph_mode went 10-03 evening: ERODE / DILATE / DARKLIFT are wheel
// positions 12..14 since 10-01, and the row only ever read OFF.)
input  wire [3:0]  affine_mode,    // affine_transform 0..10
input  wire [7:0]  moved_blocks,   // motion_frame_drawer, latched per frame

// 2026-09-21: that same module's verdict on whether the frame was usable at
// all.  Drawn as a 'C' after the block count -- see mot_flag_c.
input  wire        cam_motion,

// 2026-09-22: the single-target tracker's lifecycle from the same module.
// 0 = none, 1 = coasting, 2 = locked.  Shares cam_motion's character slot.
input  wire [1:0]  trk_state,

// 2026-09-22 (evening): the soft dispersion verdict from the same module --
// the frame was kept, but it was too spread out for the tracker to start a
// new track on.  Drawn as 'S' in the same slot, below 'C' and above the
// tracker states.  See mot_flag_c for the priority argument.
input  wire        cam_soft,

//-------------------------------------------------------------------
// 2026-09-23: the servo head's two commanded pulse widths, in microseconds
// (1000..2000), straight off servo_pantilt.
//
// ⚠ COMMANDED, NOT MEASURED.  There is no feedback path from an SG90, so
// these say what the FPGA asked for and nothing about what the horn did.
// That is precisely the split that makes them diagnostic: numbers moving
// with a motionless head is a wiring or power fault, numbers frozen is a
// loop fault, and no other pair of observations separates those two.
//-------------------------------------------------------------------
input  wire [11:0] pw_pan,
input  wire [11:0] pw_tilt,

// From latency_meter.  Already BCD and already whole numbers, so nothing
// arithmetic happens in here on their account.
input  wire [15:0] lat_bcd,        // 4 BCD digits, units of 0.1 ms
input  wire [3:0]  lat_frames,     // 0..15 whole camera frames

// From ccl_blob: targets found in the last completed frame, and the OR of its
// three overflow flags.  det_count reuses the same binary-to-BCD converter as
// moved_blocks -- see [BCD] below.
input  wire [7:0]  det_count,

// The three overflow flags SEPARATELY, not their OR.  They were merged into one
// bit and drawn as '*' up to 2026-09-07, and on the bench that told us the
// reading was bad without telling us which budget had blown -- which is the
// only part that says what to change.  One character either way; see [OVF].
input  wire [2:0]  det_ovf,        // {time, merge, label}

// det_binarize's margin servo: where it settled, and which side of the mean it
// decided the objects are on.  Both on screen rather than in ChipWatcher only,
// because between them they answer the whole of "why is it not finding
// anything" -- a margin pinned at its ceiling means the level test ran out of
// travel, one sitting on its floor with no targets means the threshold is fine
// and the shape tests are eating them, and a polarity letter that disagrees
// with the scene means the two-frame flip guard has not settled yet.
input  wire [7:0]  det_margin,
input  wire        det_fg_dark,    // 1 = objects are DARKER than the surface

// 10-09 (SHAPE_ROW): shape_vote's output -- 0 other / 1 circle / 2 rect /
// 3 triangle; valid = the vote is confident.  Latched on frame_start.
input  wire [1:0]  shape_class,
input  wire        shape_valid,

// 10-11 (COLOR_ROW): obj_color_detect's stable_id -- 0 black 1 gray 2 white
// 3 red 4 orange 5 yellow 6 green 7 cyan 8 blue 9 purple, 15 none.  Latched
// on frame_start.
input  wire [3:0]  obj_color,

// F9 / key4, the application mode (2026-10-01): 0 TRACK, 1 BOX, 2 FACE;
// 3 MULTI = TRACK with key2 switched to the green multi-box view;
// 4 FACE CAP = FACE with key2 hiding the red boxes; 5 RAW (10-03 evening).
// It names the MODE row AND picks the readout page (security 0/3,
// inspection 1, face 2/4, raw 5 = no page).  The gating of the overlays
// themselves happens in system_top.
input  wire [2:0]  ovl_mode,

// Face detector, 2026-09-18.  Two numbers rather than one, for the reason the
// detector's L/M/T flags were split apart: "no candidate regions at all" and
// "regions but no face in them" are completely different failures wanting
// opposite fixes, and one combined count cannot tell them apart.
input  wire [3:0]  face_rois,      // candidate ROIs face_roi_buf selected
input  wire [7:0]  face_count,     // of those, how many hold a face box
input  wire        face_held,      // a bank swap was skipped: classifier overran

// A THIRD number, added 09-19 late for the same reason there were two: the
// pooled accepting-window count of the best box, which is what says whether
// face_detect's MIN_NEIGHBORS is set to a number real faces can actually
// reach.  "candidates exist but every accept is isolated" and "candidates
// exist and the evidence is clustered but the cut is too high" look identical
// in n/m and are opposite fixes.  Costs one character cell of the four the
// value field had spare.
input  wire [3:0]  face_nacc,

// And two more, 09-19 night, for the geometry gates of section 3.-14.  Same
// argument a third time: a gate that is working and a gate that is eating
// every face are indistinguishable from the numbers already here.  These use
// the last two spare cells, so the FACES row is now full -- a fourth
// instrument needs a row of its own, not a cleverer encoding.
input  wire [3:0]  face_rej,       // candidates the geometry gates rejected
input  wire        face_flat,      // >=1 patch withheld for lack of contrast

// 10-04 evening: the CNN's own verdict on each of the four ROIs this sweep,
// as signed score >>> 11 (half logits while report.txt says 4096 units per
// logit, as v8/v9 do; clamped +-99; > 0 = "face"), slot 0
// in the low byte, and which slots were classified at all.  Printed in the 12
// spare cells of the 人脸 row.  This is the number the board and the offline
// simulator (board_sim) can be compared on, ROI for ROI: on the 12:13
// recording the board drew a box on a big frontal face 23% of the time where
// the simulator, fed the recorded picture, published one 72% of the time.
input  wire [31:0] face_sc,
input  wire [3:0]  face_sc_v,

// 10-12 (STAFF_ROW): staff_ctrl.  cos_bcd = two BCD digits of cos x 100,
// valid while cos_v; st 0 idle / 1 mouth / 2 blink / 3 pass / 4 cool.
input  wire [7:0]  staff_cos_bcd,
input  wire        staff_cos_v,
input  wire [2:0]  staff_st,

// 2026-09-25: the ToF ranger and the workpiece size, as FINISHED 8-character
// value fields from tof_size.  Formatted there rather than here because each
// row has several whole-row messages (NO ACK, NO BOX, AFFINE ...) chosen by
// state this module has no business knowing, and because tof_size latches
// all three on one clock -- the three rows always describe the same frame.
// The labels stay here with every other label.
// 10-03: the SIZE row is qc_thick's now (W x H x Z, 12 characters); tof_size's
// own SIZE text goes to qc_thick, which builds the row around it.
input  wire [63:0] tof_dist_text,
input  wire [39:0] tof_roi_text,    // 10-04: tof_roi_scan, 5 chars after the distance
input  wire [63:0] tof_pix_text,

// 2026-10-02: qc_thick's rows, finished value fields like the ones above,
// with Chinese glyph codes (>= 0x80) where they say so.
input  wire [95:0] qc_size_text,
input  wire [63:0] qc_base_text,
input  wire [63:0] qc_state_text,
input  wire [79:0] qc_def_text,         // qc_defect: 10 chars, see its OSD TEXT note

// 10-20 (STD_ROWS): qc_std's value fields, 13 chars each, Chinese codes
// >= 0x80 or 0x01..0x1F (the second glyph table, see CHINESE GLYPHS).
input  wire [103:0] qc_part_text,
input  wire [103:0] qc_vol_text,
input  wire [103:0] qc_judge_text,

// 10-27 (STAIN_ROW): stain_detect.  out = the voted result, valid = it has
// judged at least once, hot = the last judgement's hot cells (saturates 255).
input  wire        stain_out,
input  wire        stain_valid,
input  wire [7:0]  stain_hot,

// 10-28 (RGB_ROW): obj_color_detect's mean_r/g/b (voters' mean, every frame)
input  wire [7:0]  oc_mean_r,
input  wire [7:0]  oc_mean_g,
input  wire [7:0]  oc_mean_b,

// 2026-10-05: the fill light's readout (alert/light_meter).  Three 8-bit
// numbers and the lamp state, drawn as the security page's third row:
//   LUM:sss mmm aaa*     sig = mean - black point, mean, ambient estimate,
//                        '*' = the fill light is on.
// ASCII label on purpose: the Chinese ROM has 2 free slots left.
input  wire [7:0]  lum_sig,
input  wire [7:0]  lum_mean,
input  wire [7:0]  lum_amb,
input  wire        lum_on,
// 10-23 (TOF_ROW): gd_tof_gate dbg_txt, 12 characters "dddd cc S   ", registered.
input  wire [95:0] tof_txt,

// ⭐ 10-30 (final OSD, user): the security page's two counts = boxes DRAWN
// (system_top: popcount of the red face / blue person overlays' valid bits).
input  wire [3:0]  sec_faces,
input  wire [3:0]  sec_bodies,
// 10-30: grid_det background learning in progress (key2 held in 安防) ->
// the 轮廓数 row adds 学习中
input  wire        sec_learning,
// 10-30: the BOX page.  qc_std_on = qc_std's 标准件 mode (the short page);
// qc_stable (= qc_thick qc_text_stb) drives 状态; qc_cal_show (qc_text_cal)
// = qc_state_text is a key2 calibration result, and while it is 状态 / 判定
// carry that text ("标定+12+04") instead; qc_reason_text = qc_std's 原因
// field (blank = row not drawn).
input  wire        qc_std_on,
input  wire        qc_stable,
input  wire        qc_cal_show,
input  wire [103:0] qc_reason_text,
// 10-31 (Anlogic_update): the production count -- parts judged in this batch
// and how many passed, three BCD digits each (system_top counts in BCD, so no
// divider is anywhere near the pixel path).  The batch restarts when key3
// changes the standard part.
input  wire [11:0] qc_cnt_bcd,
input  wire [11:0] qc_pass_bcd,

// video
input  wire        in_vs,          // HIGH across the visible frame
input  wire        in_de,
input  wire [23:0] in_rgb,

output reg         out_vs,
output reg         out_de,
output reg  [23:0] out_rgb
);

localparam integer CELL_LOG2 = 3 + SCALE_LOG2;   // pixels per cell, log2

//-------------------------------------------------------------------
// 10-03 evening: EVERY label and name on both blocks is Chinese (user);
// only digits, units (MM / MS), 'X' / '#' / ':' / '+-' stay ASCII.  A byte
// >= 0x80 is glyph (code - 0x80) of osd_cn_rom.  These are
// tools/gen_cn_font.py's codes -- THE TABLE ORDER IS THE ENCODING, append
// only; this list was generated from the script's output, not typed.
//-------------------------------------------------------------------
localparam [7:0] CN_LUN = 8'hA5, CN_PAN = 8'hA6, CN_FANG = 8'hA0, CN_SHE = 8'hA1,
                 CN_MO = 8'hA7, CN_SHI = 8'hA8, CN_YAN = 8'hA9, CN_CHI2 = 8'hAA,
                 CN_ZHEN = 8'hAB, CN_YUN2 = 8'hE6, CN_DONG = 8'h9B, CN_YUN = 8'h99,
                 CN_TAI = 8'h89, CN_MU2 = 8'hE2, CN_BIAO = 8'hE3,
                 CN_JU = 8'h83, CN_LI = 8'h84, CN_CHI = 8'h85,
                 CN_CUN = 8'h86, CN_XIANG = 8'h87, CN_SU = 8'h88, CN_MIAN = 8'h8A,
                 CN_ZHI = 8'h8B, CN_JIAN = 8'h8C, CN_REN = 8'hDD, CN_LIAN = 8'hDE,
                 CN_HOU2 = 8'hF0, CN_XUAN2 = 8'hF1, CN_FEN = 8'hF2, CN_JU2 = 8'hF3,
                 CN_PING = 8'hF4, CN_CHAO = 8'hF5, CN_KUAI = 8'hE7, CN_BING = 8'hEE,
                 CN_SHI5 = 8'hEF, CN_AN = 8'hCC, CN_LIANG2 = 8'hCF, CN_YUAN = 8'hAC,
                 CN_TU = 8'hAD, CN_HUI = 8'hAE, CN_DU = 8'hA4, CN_FAN = 8'hAF,
                 CN_SE = 8'hB0, CN_HUAI = 8'hB1, CN_JIU = 8'hB2, CN_ZHI2 = 8'hB3,
                 CN_FANG2 = 8'hB4, CN_JUN = 8'hB5, CN_HENG = 8'hB6, CN_DUI = 8'hB7,
                 CN_BI2 = 8'hB8, CN_GA = 8'hB9, CN_MA = 8'hBA, CN_SHUANG = 8'hBB,
                 CN_BIAN = 8'hBC, CN_LV = 8'hBD, CN_BO = 8'hBE, CN_STAIN = 8'hBF,
                 CN_KONG = 8'hC0, CN_GAO = 8'hC1, CN_TAI2 = 8'hC2, CN_DA = 8'hC3,
                 CN_LI2 = 8'hC4, CN_SHI2 = 8'hC5, CN_MU = 8'hC6, CN_WEN2 = 8'hC7,
                 CN_FU = 8'hC8, CN_SHI3 = 8'hC9, CN_PENG = 8'hCA, CN_ZHANG2 = 8'hCB,
                 CN_BU2 = 8'hCD, CN_TI = 8'hCE, CN_GUAN = 8'h8D, CN_XUAN = 8'hD0,
                 CN_ZHUAN = 8'hD1, CN_JING = 8'hD2, CN_YOU = 8'hD3, CN_ZUO = 8'hD4,
                 CN_CUO = 8'hD5, CN_QIE = 8'hD6, CN_FANG3 = 8'hD7, CN_XIAO = 8'hD9,
                 CN_SUO = 8'hD8, CN_BEI = 8'hDA, CN_AN2 = 8'hDB, CN_FANG4 = 8'hDC,
                 CN_SHI4 = 8'hDF, CN_BIE = 8'hE0, CN_DUO = 8'hE1, CN_CAI = 8'hE4,
                 CN_JI = 8'hE5, CN_BIAO3 = 8'hFE,
                 // 10-20, STD_ROWS: 工件 / 判定 and the second table (体积)
                 CN_GONG = 8'h97, CN_JIAN2 = 8'h98, CN_DING = 8'h81,
                 CN_TI2 = 8'h07, CN_JI2 = 8'h08, CN_PAN2 = 8'h09,
                 // 10-27, STAIN_ROW: 污渍 有 / 无 n格 (渍 and 有 appended to the second table)
                 CN_WU = 8'h96, CN_GE = 8'h0B, CN_ZI4 = 8'h0F, CN_YOU3 = 8'h10,
                 // 10-30, final OSD: 0xE8..0xED re-used in place (were 晃散锁滑阈值),
                 // 0x12..0x1F appended -- gen_cn_font.py
                 CN_SHU = 8'hE8, CN_KUO = 8'hE9, CN_YI4 = 8'hEA, CN_YIN = 8'hEB,
                 CN_YAN2 = 8'hEC, CN_JU3 = 8'hED,
                 CN_WEN = 8'h80, CN_CE = 8'h82, CN_ZHONG = 8'h93, CN_LIANG = 8'h9F,
                 CN_YUAN4 = 8'h03, CN_SAN2 = 8'h05,
                 CN_HEI = 8'h12, CN_BAI = 8'h13, CN_HONG = 8'h14, CN_CHENG = 8'h15,
                 CN_HUANG2 = 8'h16, CN_LV2 = 8'h17, CN_QING = 8'h18, CN_LAN = 8'h19,
                 CN_ZI3 = 8'h1A, CN_XING = 8'h1B, CN_JIAO = 8'h1C, CN_QI3 = 8'h1D,
                 CN_TA = 8'h1E, CN_ZHUANG = 8'h1F,
                 CN_XUE = 8'h94, CN_XI = 8'h95,
                 CN_HE = 8'h0A;                                   // 10-31: 合 (检数 合格 row)

//-------------------------------------------------------------------
// Pixel coordinates off de/vs.  Same eight lines every module in this design
// uses; there is no disp_x/disp_y to borrow and uivtc's counters sit 11 clocks
// upstream of here.
//-------------------------------------------------------------------
reg [11:0] px, py;
reg        de_prev;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        px <= 12'd0; py <= 12'd0; de_prev <= 1'b0;
    end else begin
        de_prev <= in_de;
        if (!in_vs) begin
            px <= 12'd0;
            py <= 12'd0;
        end
        else if (in_de) begin
            px <= px + 1'b1;
        end
        else begin
            px <= 12'd0;
            if (de_prev) py <= py + 1'b1;
        end
    end
end

//-------------------------------------------------------------------
// [BCD] Binary to BCD for the two counts, one dabble iteration per clock.
//
// Both change once a frame, so 8 clocks is free -- and spreading it keeps the
// shift-and-add-3 out of a single clock period.  Done flat it is 8 stages of
// three 4-bit compare-and-adds, which is exactly the kind of path that would
// land on top of the pixel-clock group in the timing report.
//
// ONE SEQUENCER, THREE DATA PATHS.  moved_blocks, det_count and det_margin are
// converted side by side off the same db_step counter and the same frame_start
// pulse, so each extra count costs a 12-bit accumulator and its adjust logic
// and nothing else -- no second state machine to keep in step with this one.
//
// All three sources are 8 bits, which is what makes one 8-step sequencer serve
// them.  A wider one would need its own step count; do not add a 12-bit source
// to this block without splitting the sequencer.
//
// 2026-09-23: TWO MORE PATHS, AND THE 8-BIT RULE ABOVE IS WHY THEY ARE SCALED
// RATHER THAN WIDENED.  pw_pan/pw_tilt are 12-bit, so feeding them in raw is
// exactly the thing the paragraph above forbids.  What gets converted is the
// DEVIATION FROM CENTRE IN UNITS OF 4 us -- see pan_mag -- which is 0..125 and
// therefore 8 bits, so the sequencer is untouched and each axis costs one
// accumulator and its adjust logic, the same as db_bin3.
//
// 4 us of quantisation is ~10 px at the lens scale, well under DEAD_X = 96, so
// the reading cannot hide a correction the loop considered worth making.
//-------------------------------------------------------------------
reg vs_d;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) vs_d <= 1'b0;
    else        vs_d <= in_vs;
end
wire frame_start = in_vs && !vs_d;

reg [7:0]  db_bin,  db_bin2,  db_bin3,  db_bin4,  db_bin5;
reg [11:0] db_acc,  db_acc2,  db_acc3,  db_acc4,  db_acc5;
reg [3:0]  db_step;
reg [11:0] bcd,     bcd2,     bcd3,     bcd4,     bcd5;

//-------------------------------------------------------------------
// The servo deviations, as sign + magnitude in units of 4 us.
//
// ⚠ 1500 IS WRITTEN HERE AS A LITERAL AND IT IS servo_pantilt'S PAN_CTR_US.
// This module has no parameter for it on purpose: an OSD that took the centre
// as a parameter could be configured to disagree with the hardware it is
// reporting on, and a readout that can lie about its own zero is worse than
// no readout.  The two axes share the constant because the head's two centres
// are the same number and always will be -- it is 1.5 ms, the midpoint of the
// RC servo standard, not a tuning value.
//
// If PAN_CTR_US / TLT_CTR_US are ever moved off 1500, THIS IS THE SECOND
// PLACE TO EDIT, and the symptom of forgetting is a reading that is
// consistently offset while the head sits correctly centred.
//-------------------------------------------------------------------
wire        pan_neg = (pw_pan  < 12'd1500);
wire        tlt_neg = (pw_tilt < 12'd1500);
wire [11:0] pan_dev = pan_neg ? (12'd1500 - pw_pan)  : (pw_pan  - 12'd1500);
wire [11:0] tlt_dev = tlt_neg ? (12'd1500 - pw_tilt) : (pw_tilt - 12'd1500);

// >> 2 : 4 us per count.  0..500 becomes 0..125, which fits the 8-bit
// sequencer above -- that is the whole reason for the shift.
wire [7:0]  pan_mag = pan_dev[9:2];
wire [7:0]  tlt_mag = tlt_dev[9:2];

wire [11:0] db_adj = { (db_acc[11:8] >= 4'd5) ? (db_acc[11:8] + 4'd3) : db_acc[11:8],
                       (db_acc[7:4]  >= 4'd5) ? (db_acc[7:4]  + 4'd3) : db_acc[7:4],
                       (db_acc[3:0]  >= 4'd5) ? (db_acc[3:0]  + 4'd3) : db_acc[3:0]  };

wire [11:0] db_next = { db_adj[10:0], db_bin[7] };

wire [11:0] db_adj2 = { (db_acc2[11:8] >= 4'd5) ? (db_acc2[11:8] + 4'd3) : db_acc2[11:8],
                        (db_acc2[7:4]  >= 4'd5) ? (db_acc2[7:4]  + 4'd3) : db_acc2[7:4],
                        (db_acc2[3:0]  >= 4'd5) ? (db_acc2[3:0]  + 4'd3) : db_acc2[3:0]  };

wire [11:0] db_next2 = { db_adj2[10:0], db_bin2[7] };

wire [11:0] db_adj3 = { (db_acc3[11:8] >= 4'd5) ? (db_acc3[11:8] + 4'd3) : db_acc3[11:8],
                        (db_acc3[7:4]  >= 4'd5) ? (db_acc3[7:4]  + 4'd3) : db_acc3[7:4],
                        (db_acc3[3:0]  >= 4'd5) ? (db_acc3[3:0]  + 4'd3) : db_acc3[3:0]  };

wire [11:0] db_next3 = { db_adj3[10:0], db_bin3[7] };

wire [11:0] db_adj4 = { (db_acc4[11:8] >= 4'd5) ? (db_acc4[11:8] + 4'd3) : db_acc4[11:8],
                        (db_acc4[7:4]  >= 4'd5) ? (db_acc4[7:4]  + 4'd3) : db_acc4[7:4],
                        (db_acc4[3:0]  >= 4'd5) ? (db_acc4[3:0]  + 4'd3) : db_acc4[3:0]  };

wire [11:0] db_next4 = { db_adj4[10:0], db_bin4[7] };

wire [11:0] db_adj5 = { (db_acc5[11:8] >= 4'd5) ? (db_acc5[11:8] + 4'd3) : db_acc5[11:8],
                        (db_acc5[7:4]  >= 4'd5) ? (db_acc5[7:4]  + 4'd3) : db_acc5[7:4],
                        (db_acc5[3:0]  >= 4'd5) ? (db_acc5[3:0]  + 4'd3) : db_acc5[3:0]  };

wire [11:0] db_next5 = { db_adj5[10:0], db_bin5[7] };

//-------------------------------------------------------------------
// ⚠ THE SIGNS ARE LATCHED WITH THE MAGNITUDES, on the same frame_start.
// Reading pan_neg live next to a bcd4 that was converted eight clocks ago
// would, on the frame a correction crosses centre, print the new sign against
// the old magnitude -- a reading that never existed.  This is the same
// publish-atomically trap as the det_overlay latch bug (09-19): the question
// is not whether each value is right but whether the two were sampled at the
// same instant.
//-------------------------------------------------------------------
reg pan_neg_r, tlt_neg_r;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        db_bin  <= 8'd0;  db_acc  <= 12'd0; db_step <= 4'd0; bcd  <= 12'd0;
        db_bin2 <= 8'd0;  db_acc2 <= 12'd0;                  bcd2 <= 12'd0;
        db_bin3 <= 8'd0;  db_acc3 <= 12'd0;                  bcd3 <= 12'd0;
        db_bin4 <= 8'd0;  db_acc4 <= 12'd0;                  bcd4 <= 12'd0;
        db_bin5 <= 8'd0;  db_acc5 <= 12'd0;                  bcd5 <= 12'd0;
        pan_neg_r <= 1'b0; tlt_neg_r <= 1'b0;
    end else if (frame_start) begin
        db_bin  <= moved_blocks;
        db_bin2 <= det_count;
        db_bin3 <= det_margin;
        db_bin4 <= pan_mag;
        db_bin5 <= tlt_mag;
        db_acc  <= 12'd0;
        db_acc2 <= 12'd0;
        db_acc3 <= 12'd0;
        db_acc4 <= 12'd0;
        db_acc5 <= 12'd0;
        pan_neg_r <= pan_neg;
        tlt_neg_r <= tlt_neg;
        db_step <= 4'd8;
    end else if (db_step != 4'd0) begin
        db_acc  <= db_next;
        db_acc2 <= db_next2;
        db_acc3 <= db_next3;
        db_acc4 <= db_next4;
        db_acc5 <= db_next5;
        db_bin  <= {db_bin[6:0],  1'b0};
        db_bin2 <= {db_bin2[6:0], 1'b0};
        db_bin3 <= {db_bin3[6:0], 1'b0};
        db_bin4 <= {db_bin4[6:0], 1'b0};
        db_bin5 <= {db_bin5[6:0], 1'b0};
        db_step <= db_step - 4'd1;
        if (db_step == 4'd1) begin
            bcd  <= db_next;
            bcd2 <= db_next2;
            bcd3 <= db_next3;
            bcd4 <= db_next4;
            bcd5 <= db_next5;
        end
    end
end

// Leading zeros blanked, so "7 BLK" does not read as "007 BLK".
wire [7:0] cnt_c2 = (bcd[11:8] == 4'd0) ? 8'h20 : (8'h30 + {4'd0, bcd[11:8]});
wire [7:0] cnt_c1 = (bcd[11:4] == 8'd0) ? 8'h20 : (8'h30 + {4'd0, bcd[7:4]});
wire [7:0] cnt_c0 =                                (8'h30 + {4'd0, bcd[3:0]});

wire [7:0] det_c2 = (bcd2[11:8] == 4'd0) ? 8'h20 : (8'h30 + {4'd0, bcd2[11:8]});
wire [7:0] det_c1 = (bcd2[11:4] == 8'd0) ? 8'h20 : (8'h30 + {4'd0, bcd2[7:4]});
wire [7:0] det_c0 =                                 (8'h30 + {4'd0, bcd2[3:0]});

wire [7:0] mgn_c2 = (bcd3[11:8] == 4'd0) ? 8'h20 : (8'h30 + {4'd0, bcd3[11:8]});
wire [7:0] mgn_c1 = (bcd3[11:4] == 8'd0) ? 8'h20 : (8'h30 + {4'd0, bcd3[7:4]});
wire [7:0] mgn_c0 =                                 (8'h30 + {4'd0, bcd3[3:0]});

// [OVF] Which budget ccl_blob blew, in one character next to the count:
//
//   L  labels    the 2047 provisional labels ran out.  The mask has thousands
//                of separate regions in it, so the threshold is producing
//                speckle -- open the mask harder or raise MARGIN.
//   M  merges    the 1024-entry merge list ran out.  Lots of DIAGONAL contact,
//                which is a lace of thresholded gradient rather than solid
//                objects -- same fix, different symptom.
//   T  time      the frame-end passes did not finish in vertical blanking.
//                Only reachable with L or M already true in practice, so if T
//                shows up alone the passes themselves got slower.
//   (blank)      the reading is trustworthy.
//
// Priority order, not a sum: L is the most upstream cause and the one worth
// acting on first, and a frame that blew labels has almost always blown the
// merge list too.  Reading the flags one at a time in ChipWatcher is still the
// way to see all three -- this is the version that fits on a demo screen.
// 10-03 evening: one Chinese glyph each, same priority -- L 标(labels),
// M 并(merges), T 时(time).
wire [7:0] det_ovf_c = det_ovf[0] ? CN_BIAO
                     : det_ovf[1] ? CN_BING
                     : det_ovf[2] ? CN_SHI5
                     :              8'h20;

//-------------------------------------------------------------------
// Row text.  Each row is a fixed 8-character label and an 8-character value,
// both held as 64-bit string literals so a row is one case arm rather than a
// per-character decode.  Names are padded to exactly 8.
//-------------------------------------------------------------------
// 10-03 evening: names are 13 cells (the row is 16: two-glyph label + ':').
reg [103:0] wheel_name;
always @(*) begin
    case (wheel_mode)
        4'd0 : wheel_name = {CN_YUAN, CN_TU,                     {11{8'h20}}};  // ORG      原图
        4'd1 : wheel_name = {CN_HUI, CN_DU,                      {11{8'h20}}};  // GRAY     灰度
        4'd2 : wheel_name = {CN_FAN, CN_SE,                      {11{8'h20}}};  // NEG      反色
        4'd3 : wheel_name = {CN_HUAI, CN_JIU,                    {11{8'h20}}};  // SEPIA    怀旧
        4'd4 : wheel_name = {CN_ZHI2, CN_FANG2, CN_JUN, CN_HENG, {9{8'h20}}};   // HISTEQ   直方均衡
        4'd5 : wheel_name = {CN_DUI, CN_BI2, CN_DU,              {10{8'h20}}};  // CONTRAST 对比度
        4'd6 : wheel_name = {CN_GA, CN_MA,                       {11{8'h20}}};  // GAMMA    伽马
        4'd7 : wheel_name = {CN_SHUANG, CN_BIAN, CN_LV, CN_BO,   {9{8'h20}}};   // BILAT    双边滤波
        4'd8 : wheel_name = {13{8'h20}};                                        // (10-06: guided filter removed; key skips slot 8)
        4'd9 : wheel_name = {CN_GAO, CN_DONG, CN_TAI2,           {10{8'h20}}};  // HDR      高动态
        4'd10: wheel_name = {CN_DA, CN_LI2, CN_SHI2,             {10{8'h20}}};  // MARBLE   大理石
        4'd11: wheel_name = {CN_MU, CN_WEN2,                     {11{8'h20}}};  // WOOD     木纹
        4'd12: wheel_name = {CN_FU, CN_SHI3,                     {11{8'h20}}};  // ERODE    腐蚀
        4'd13: wheel_name = {CN_PENG, CN_ZHANG2,                 {11{8'h20}}};  // DILATE   膨胀
        4'd14: wheel_name = {CN_AN, CN_BU2, CN_TI, CN_LIANG2,    {9{8'h20}}};   // DARKLIFT 暗部提亮
        4'd15: wheel_name = {CN_ZHI2, CN_FANG2, CN_TU,           {10{8'h20}}};  // HISTGRAM 直方图
    endcase
end

reg [103:0] affine_name;
always @(*) begin
    case (affine_mode)
        4'd0 : affine_name = {CN_GUAN,                        {12{8'h20}}};  // OFF      关
        4'd1 : affine_name = {CN_XUAN, CN_ZHUAN, "90",        {9{8'h20}}};   // ROT 90   旋转90
        4'd2 : affine_name = {CN_XUAN, CN_ZHUAN, "180",       {8{8'h20}}};   // ROT 180
        4'd3 : affine_name = {CN_XUAN, CN_ZHUAN, "270",       {8{8'h20}}};   // ROT 270
        4'd4 : affine_name = {CN_JING, CN_XIANG,              {11{8'h20}}};  // MIRROR   镜像
        4'd5 : affine_name = {CN_YOU, CN_CUO, CN_QIE,         {10{8'h20}}};  // SHEAR R  右错切
        4'd6 : affine_name = {CN_ZUO, CN_CUO, CN_QIE,         {10{8'h20}}};  // SHEAR L  左错切
        4'd7 : affine_name = {CN_FANG3, CN_DA, "2", CN_BEI,   {9{8'h20}}};   // ZOOM 2X  放大2倍
        4'd8 : affine_name = {CN_FANG3, CN_DA, "4", CN_BEI,   {9{8'h20}}};   // ZOOM 4X
        4'd9 : affine_name = {CN_SUO, CN_XIAO, "2", CN_BEI,   {9{8'h20}}};   // SHRINK2X 缩小2倍
        4'd10: affine_name = {CN_SUO, CN_XIAO, "4", CN_BEI,   {9{8'h20}}};   // SHRINK4X
        default: affine_name = {"??",                         {11{8'h20}}};
    endcase
end

// (10-30: the 运动 row and its camera-motion / tracker flag 晃散锁滑 went
// with the final OSD; the four glyph slots now hold 数廓已因.  The flag's
// design notes are in text_osd.v.pre_1030.)

//-------------------------------------------------------------------
// Latency strings.  lat_bcd arrives as four BCD digits in units of 0.1 ms,
// so the decimal point is a fixed character between digit 1 and digit 0 --
// no scaling, no rounding, nothing to get wrong here.
//
// 9999 (rendered "999.9") is latency_meter's saturation value and means the
// sensor has stopped producing frames.  It is deliberately a reading that
// cannot be mistaken for a real one.
//-------------------------------------------------------------------
wire [7:0] ms_d3 = (lat_bcd[15:12] == 4'd0) ? 8'h20 : (8'h30 + {4'd0, lat_bcd[15:12]});
wire [7:0] ms_d2 = (lat_bcd[15:8]  == 8'd0) ? 8'h20 : (8'h30 + {4'd0, lat_bcd[11:8]});
wire [7:0] ms_d1 =                                    (8'h30 + {4'd0, lat_bcd[7:4]});
wire [7:0] ms_d0 =                                    (8'h30 + {4'd0, lat_bcd[3:0]});

wire [63:0] lat_ms_text = {ms_d3, ms_d2, ms_d1, 8'h2E, ms_d0, "MS", 8'h20};

// lat_frames is 0..15, so "divide by ten" is one compare and one subtract of
// a constant -- cheaper than carrying a second BCD converter for one digit.
wire [3:0] frm_hi = (lat_frames >= 4'd10) ? 4'd1                : 4'd0;
wire [3:0] frm_lo = (lat_frames >= 4'd10) ? (lat_frames - 4'd10) : lat_frames;

wire [7:0] frm_c1 = (frm_hi == 4'd0) ? 8'h20 : (8'h30 + {4'd0, frm_hi});
wire [7:0] frm_c0 =                            (8'h30 + {4'd0, frm_lo});

// (10-03 evening: LATENCY and FRAMES are one row of the top panel now, and
// the per-row value fields are built in the row cases below.)

//-------------------------------------------------------------------
// The face row: " 3  2/1" -- votes, then candidate ROIs, then faces found in
// them.  All three are 0..15 in principle and 0..4 in practice, so one digit
// each is enough and no BCD converter is needed; 15 would print as '?'.
//
// READ IT LEFT TO RIGHT AND IT IS A PIPELINE.  Votes says how much evidence
// the best location gathered, ROIs says how many regions were offered to the
// classifier, and faces says how many boxes were published.  Each stage can
// be zero for a reason the next one cannot distinguish:
//
//   0  0/0   nothing to look at      -- face_skin / ccl_blob, not the cascade
//   0  2/0   looked, found nothing   -- ROI framing or scale
//   1  2/0   found it once           -- MIN_NEIGHBORS is cutting; either the
//                                       evidence is genuinely thin or the cut
//                                       is too high.  THIS is the case the
//                                       first two numbers alone could not name
//   3  2/1   working                 -- clustered evidence, one box
//
// 'H' in front means face_roi_buf skipped a bank swap because the classifier
// was still scanning.  That is harmless once (one frame of staleness) and a
// standing 'H' means the scan is no longer finishing inside a frame -- which
// is the one failure mode of the face chain that nothing else on screen shows.
//-------------------------------------------------------------------
// 09-19 night, section 3.-14: two more cells, so the geometry gates added the
// same evening are visible from the board.  The value field is eight cells and
// all eight are now spoken for:
//
//     v _ r C H n / m
//     0 1 2 3 4 5 6 7
//
// v = pooled votes, r = candidates the gates rejected, C lit when a patch was
// withheld for being flat, H = bank swap deferred (as before), n = candidates,
// m = published boxes.  The leading blank went, not H: a standing H is the one
// failure of the face chain that nothing else on screen shows.
//
// The gates needed a readout because they are otherwise INVISIBLE -- a gate
// doing its job and a gate eating every face both read "0 0/0" on the old row.
//
//   0  0  0/0   nothing to look at        -- skin chain, gates idle
//   0  2C 0/0   candidates looked flat    -- MIN_CONTRAST; blank wall or lens
//   0  3  0/0   candidates looked wrong   -- MAX_SIDE / MB_MAX_SIDE / AR_SHIFT
//                                            fired.  If a REAL face is in shot
//                                            when this reads high, a ceiling is
//                                            too tight -- that is the knob
//   1  0  2/0   found it once             -- MIN_NEIGHBORS is cutting
//   3  0  2/1   working
// 10-03 evening: H -> 超 (classifier overran), C -> 平 (flat patch withheld).
wire [7:0] face_held_c = face_held ? CN_CHAO : 8'h20;
wire [7:0] face_flat_c = face_flat ? CN_PING : 8'h20;
wire [7:0] face_roi_c  = 8'h30 + {4'd0, face_rois};
wire [7:0] face_rej_c  = 8'h30 + {4'd0, face_rej};
wire [7:0] face_cnt_c  = 8'h30 + {4'd0, face_count[3:0]};
wire [7:0] face_vote_c = 8'h30 + {4'd0, face_nacc};

// The per-slot scores, "+12-03+00--- " style: sign + two digits, or "---"
// for a slot that was not classified this sweep.  Fixed width, leading zeros
// kept (same reasons as the servo row).  Formatted into registers once per
// clock from registered inputs: |v|, the clamp is upstream, and a /10 on
// seven bits -- no arithmetic reaches lat_row.
function [23:0] sc_txt;
    input [7:0] v;
    input       ok;
    reg   [7:0] m;
    begin
        m = v[7] ? (8'd0 - v) : v;
        if (m > 8'd99) m = 8'd99;
        sc_txt = ok ? {(v[7] ? "-" : "+"), 8'h30 + (m / 8'd10), 8'h30 + (m % 8'd10)} : "---";
    end
endfunction

// The fill-light row's 12-char value field, "sss mmm aaa*".  Fixed width,
// leading zeros kept (same reasons as the servo row), registered from
// registered inputs so no /10 reaches lat_row.
function [23:0] dec3;
    input [7:0] v;
    begin
        dec3 = {8'h30 + (v / 8'd100), 8'h30 + ((v / 8'd10) % 8'd10), 8'h30 + (v % 8'd10)};
    end
endfunction

reg [95:0] lum_txt;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) lum_txt <= {12{8'h20}};
    else        lum_txt <= {dec3(lum_sig), " ", dec3(lum_mean), " ", dec3(lum_amb),
                            lum_on ? "*" : " "};
end

// [STAFF] 10-12: "0.97 BLINK   " -- 13 characters after "识别:".  The cos
// is staff_ctrl's latest result (---- when none for 1 s); the word is the
// verification state.  Registered from registered inputs, like lum_txt.
reg [103:0] staff_txt;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) staff_txt <= {13{8'h20}};
    else        staff_txt <= {staff_cos_v ? {"0.", 8'h30 + {4'd0, staff_cos_bcd[7:4]}, 8'h30 + {4'd0, staff_cos_bcd[3:0]}}
                                          : "----",
                              " ",
                              (staff_st == 3'd1) ? "MOUTH" : (staff_st == 3'd2) ? "BLINK" :
                              (staff_st == 3'd3) ? "PASS " : (staff_st == 3'd4) ? "FAIL " :
                              (staff_st == 3'd5) ? "NEAR " : "     ",   // 10-24: waiting for the staff to come close
                              {3{8'h20}}};
end

reg [95:0] face_sc_txt;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) face_sc_txt <= {12{8'h20}};
    else        face_sc_txt <= {sc_txt(face_sc[7:0],   face_sc_v[0]),
                                sc_txt(face_sc[15:8],  face_sc_v[1]),
                                sc_txt(face_sc[23:16], face_sc_v[2]),
                                sc_txt(face_sc[31:24], face_sc_v[3])};
end

//-------------------------------------------------------------------
// The margin servo's readout: "  56 D" -- where det_binarize's adaptive
// threshold settled, and which side it decided the objects are on.
//
// D and B rather than DARK/BRIGHT: the value field is eight cells wide and
// three of them are the number, so a word does not fit next to it -- and the
// pair only ever has to be told apart from each other, never read cold.
//-------------------------------------------------------------------
// 10-03 evening: D -> 暗, B -> 亮.
wire [7:0] pol_c = det_fg_dark ? CN_AN : CN_LIANG2;

//-------------------------------------------------------------------
// [SHAPE] 10-09 (SHAPE_ROW): the BOX page's 识别 row, ported from the
// teammate's Anlogic7 text_osd.  Class and valid are latched together on
// frame_start, so the whole frame shows one value and the two always belong
// to the same vote.  ASCII names: the CJK font is full (128/128).
//   --       no confident vote (no box, or the classes disagree)
//   OTHER / CIRCLE / RECT / TRI
//-------------------------------------------------------------------
reg [1:0] shp_cls_r;
reg       shp_v_r;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        shp_cls_r <= 2'd0;
        shp_v_r   <= 1'b0;
    end else if (frame_start) begin
        shp_cls_r <= shape_class;
        shp_v_r   <= shape_valid;
    end
end

// 10-30 (final OSD): Chinese, 3 cells -- 其他 / 圆形 / 矩形 / 三角形, "--"
// with no confident vote.
reg [23:0] shape_name;
always @(*) begin
    if (!shp_v_r)
        shape_name = {"--", 8'h20};
    else case (shp_cls_r)
        2'd0:    shape_name = {CN_QI3,   CN_TA,   8'h20};
        2'd1:    shape_name = {CN_YUAN4, CN_XING, 8'h20};
        2'd2:    shape_name = {CN_JU3,   CN_XING, 8'h20};
        default: shape_name = {CN_SAN2,  CN_JIAO, CN_XING};
    endcase
end

//-------------------------------------------------------------------
// [STAIN] 10-27 (STAIN_ROW): stain_detect's verdict, the 13 value cells of
//   污渍:有 012格     voted stain, last judgement had 12 hot cells
//   污渍:无 000格     judged, clean
//   污渍:---          not judged yet (no box >= 128 x 128 since power-up)
// The three inputs are latched together on frame_start (the teammate's rule:
// the count and the verdict must come from the same judgement).  The digits
// only depend on the latched byte and lat_row is registered per line, so
// none of this is on the pixel path.
//-------------------------------------------------------------------
reg       stn_out_r, stn_v_r;
reg [7:0] stn_hot_r;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        stn_out_r <= 1'b0; stn_v_r <= 1'b0; stn_hot_r <= 8'd0;
    end else if (frame_start) begin
        stn_out_r <= stain_out;
        stn_v_r   <= stain_valid;
        stn_hot_r <= stain_hot;
    end
end

// Digits by the fill-light row's dec3 (fixed width, leading zeros kept),
// registered from registered inputs like lum_txt, so no /10 reaches lat_row.
reg [103:0] stain_txt;   // 13 cells
always @(posedge clk or negedge rst_n) begin
    if (!rst_n)        stain_txt <= {13{8'h20}};
    else if (!stn_v_r) stain_txt <= {"---", {10{8'h20}}};
    else               stain_txt <= {stn_out_r ? CN_YOU3 : CN_WU, {12{8'h20}}};   // 10-30: 有 / 无 only
end

// [RGB] 10-28 (RGB_ROW): same two-register pattern as the stain row.
reg [7:0]   ocm_r, ocm_g, ocm_b;
reg [127:0] rgb_txt;    // 16 cells, the whole row
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        ocm_r <= 8'd0; ocm_g <= 8'd0; ocm_b <= 8'd0;
        rgb_txt <= {16{8'h20}};
    end else begin
        if (frame_start) begin ocm_r <= oc_mean_r; ocm_g <= oc_mean_g; ocm_b <= oc_mean_b; end
        rgb_txt <= {"RGB:", dec3(ocm_r), " ", dec3(ocm_g), " ", dec3(ocm_b), " "};
    end
end

//-------------------------------------------------------------------
// [COLOR] 10-11 (COLOR_ROW): obj_color_detect's colour after the shape,
// ported from the teammate's Anlogic7 text_osd.  Both names are 6 cells, so
// the row drops the shape's leading blank to fit 16:  识别:CIRCLE WHITE
// ASCII again: 红橙黄绿青蓝紫白黑灰 would need ten glyphs the full font
// does not have.
//-------------------------------------------------------------------
reg [3:0] col_r;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n)           col_r <= 4'd15;
    else if (frame_start) col_r <= obj_color;
end

// 10-30 (final OSD): Chinese, 2 cells -- 黑色 .. 紫色, "--" for none (15).
reg [15:0] color_name;
always @(*) begin
    case (col_r)
        4'd0:    color_name = {CN_HEI,    CN_SE};
        4'd1:    color_name = {CN_HUI,    CN_SE};
        4'd2:    color_name = {CN_BAI,    CN_SE};
        4'd3:    color_name = {CN_HONG,   CN_SE};
        4'd4:    color_name = {CN_CHENG,  CN_SE};
        4'd5:    color_name = {CN_HUANG2, CN_SE};
        4'd6:    color_name = {CN_LV2,    CN_SE};
        4'd7:    color_name = {CN_QING,   CN_SE};
        4'd8:    color_name = {CN_LAN,    CN_SE};
        4'd9:    color_name = {CN_ZI3,    CN_SE};
        default: color_name = "--";
    endcase
end

//-------------------------------------------------------------------
// THE SERVO ROW.  Eight cells, exactly:  <sign><3 digits><sign><3 digits>
//
//        "+015-003"   pan 60 us right of centre, tilt 12 us up
//        "+000+000"   both parked at centre
//
// ⚠ LEADING ZEROS ARE **NOT** BLANKED HERE, and that is the opposite of
// every other number on this panel.  Two reasons, both about reading it at
// the bench rather than about looking tidy:
//
//   * the two fields are adjacent with no separator, so blanking would let
//     "+15-3" slide into an ambiguous string; fixed width keeps the axes in
//     fixed screen columns.
//   * "+000" is the single most important reading this row has -- it means
//     "the loop is alive and has nothing to correct" -- and it must be
//     visibly distinct from a blank field, which is what "no servo output at
//     all" would look like.
//
// Units are 4 us per count, so 125 is full travel.  The number is what the
// pulse asked for, never what the horn did -- see the port comment.
//-------------------------------------------------------------------
wire [7:0] pan_s  = pan_neg_r ? "-" : "+";
wire [7:0] tlt_s  = tlt_neg_r ? "-" : "+";

wire [7:0] pan_d2 = 8'h30 + {4'd0, bcd4[11:8]};
wire [7:0] pan_d1 = 8'h30 + {4'd0, bcd4[7:4]};
wire [7:0] pan_d0 = 8'h30 + {4'd0, bcd4[3:0]};
wire [7:0] tlt_d2 = 8'h30 + {4'd0, bcd5[11:8]};
wire [7:0] tlt_d1 = 8'h30 + {4'd0, bcd5[7:4]};
wire [7:0] tlt_d0 = 8'h30 + {4'd0, bcd5[3:0]};

wire [63:0] srv_text = {pan_s, pan_d2, pan_d1, pan_d0,
                        tlt_s, tlt_d2, tlt_d1, tlt_d0};

//-------------------------------------------------------------------
// F9's positions, spelled out.  This row exists because the bench read four
// positions as two -- see the NROW parameter.  There are eight now that the
// face overlay shares the selector, which makes the row more necessary, not
// less: the difference between FACE and BOX+FACE is invisible on a scene where
// one of the two detectors is finding nothing.
//
// The names describe WHAT IS DRAWN, not the bit pattern, so "the screen does
// not match the label" is a real report rather than a decode question.
//-------------------------------------------------------------------
reg [103:0] ovl_name;
always @(*) begin
    case (ovl_mode)
        // 2026-10-01: key4 is the application mode; 10-03 evening: + RAW
        3'd0:    ovl_name = {CN_AN2, CN_FANG4,                     {11{8'h20}}};  // TRACK    安防
        3'd1:    ovl_name = {CN_ZHI, CN_JIAN,                      {11{8'h20}}};  // BOX      质检
        3'd2:    ovl_name = {CN_REN, CN_LIAN, CN_SHI4, CN_BIE,     {9{8'h20}}};   // FACE     人脸识别
        3'd3:    ovl_name = {CN_AN2, CN_FANG4, CN_DUO, CN_MU2, CN_BIAO, {8{8'h20}}}; // MULTI 安防多目标
        3'd4:    ovl_name = {CN_REN, CN_LIAN, CN_CAI, CN_JI,       {9{8'h20}}};   // FACE CAP 人脸采集
        3'd5:    ovl_name = {CN_YUAN, CN_TU,                       {11{8'h20}}};  // RAW      原图
        3'd6:    ovl_name = {CN_REN, CN_LIAN, "DBG",               {8{8'h20}}};   // FACE DBG 人脸DBG (10-04)
        default: ovl_name = {"??",                                 {11{8'h20}}};
    endcase
end

//-------------------------------------------------------------------
// Cell coordinates.  Every one of these is a bit slice of a subtract.
//-------------------------------------------------------------------
wire [11:0] dx = px - TX0;
wire [11:0] dy = py - TY0;

wire in_panel = (px >= TX0) && (px < (TX0 + (NCOL << CELL_LOG2)))
             && (py >= TY0) && (py < (TY0 + (NROW << CELL_LOG2)));

wire [4:0] t_cx = dx >> CELL_LOG2;      // cell column
wire [4:0] t_cy = dy >> CELL_LOG2;      // cell row
wire [2:0] t_sx = dx >> SCALE_LOG2;     // column within the 8-wide glyph
wire [2:0] t_sy = dy >> SCALE_LOG2;     // row within the 8-tall cell

// 10-03 evening: four rows, each a whole 16-cell string (two-glyph label,
// ':', 13 cells of value) -- the same construction as the readout below.
reg [127:0] top_row;
always @(*) begin
    case (t_cy)
        5'd0: top_row = {CN_LUN, CN_PAN,  ":", wheel_name};               // 轮盘
        5'd1: top_row = {CN_FANG, CN_SHE, ":", affine_name};              // 仿射
        5'd2: top_row = {CN_MO, CN_SHI,   ":", ovl_name};                 // 模式
        5'd3: top_row = {CN_YAN, CN_CHI2, ":", lat_ms_text,               // 延迟
                         frm_c1, frm_c0, CN_ZHEN, "  "};                  //  " 33.5MS  1帧"
        default: top_row = {16{8'h20}};
    endcase
end

// REGISTERED, and that is free: the row string depends on py alone, py
// steps once per line in horizontal blanking, and the first pixel of the next
// line is hundreds of clocks later.  It takes the row / mode / page selection
// off the per-pixel path, which is now just the 16:1 cell mux on px.
reg [127:0] top_row_r;
always @(posedge clk) top_row_r <= top_row;

wire [7:0]  panel_ascii = top_row_r[(4'd15 - t_cx[3:0])*8 +: 8];

//-------------------------------------------------------------------
// Latency readout, bottom left.  Identical construction to the panel above,
// with its own origin and two rows.  Same magnification so both blocks read
// as the same instrument family.
//-------------------------------------------------------------------
wire [11:0] ltdx = px - LTX0;
wire [11:0] ltdy = py - LTY0;

wire in_lat = (px >= LTX0) && (px < (LTX0 + (NCOL  << CELL_LOG2)))
           && (py >= LTY0) && (py < (LTY0 + (LTROW << CELL_LOG2)));

wire [4:0] l_cx = ltdx >> CELL_LOG2;
wire [4:0] l_cy = ltdy >> CELL_LOG2;
wire [2:0] l_sx = ltdx >> SCALE_LOG2;
wire [2:0] l_sy = ltdy >> SCALE_LOG2;

//-------------------------------------------------------------------
// [PAGES] ⭐ 10-30 (final OSD, user).  One bottom-anchored page per mode: a
// page of k rows occupies the LAST k of the LTROW rows (so its bottom edge
// never moves) and rows above it are not drawn at all.  LTROW = the longest
// page, 质检 任意 (6).  Every row is a whole 16-cell string.
//   安防        人脸数:n            red face boxes drawn this frame
//               轮廓数:n [学习中]   blue person boxes drawn this frame; 学习中
//                                   while grid_det learns the background
//   (10-31 Anlogic_update: + 检数 -- 任意 last row, 标准件 above 原因; LTROW 7)
//   质检 任意   工件:任意
//               污渍:有 / 无 / ---  (--- = not judged: no box >= 128 x 128 / not white)
//               目标:n
//               识别:红色 圆形      (colour, shape; "--" = no confident vote)
//               尺寸: 26X 49X 28
//               状态:测量中 / 已稳定  (qc_stable; every not-stable state of
//                                     qc_thick reads 测量中)
//   质检 标准件 工件:标准件 60X60X30
//               尺寸: 60X 60X 30
//               判定:合格 / 不合格 [厚-13] / 测量中
//               原因:颜色 形状 尺寸 污渍   only the failing ones; the row is
//                                     not drawn while there are none
//   原图        nothing
// For CAL_SHOW_FR frames after a key2 calibration the last row (状态 /
// 判定) shows qc_thick's own text instead ("标定+12+04" / "标定错3").
// The 人脸 mode and its page went with system_top's FACE_MODE = 0.
//-------------------------------------------------------------------
wire pg_sec  = (ovl_mode == 3'd0) || (ovl_mode == 3'd3);    // TRACK / MULTI
wire pg_qc   = (ovl_mode == 3'd1);                          // BOX

// The page selector and the two counts latched per frame, so a change can
// never tear a row.  qc_stable / qc_cal_show are NOT latched: qc_thick
// publishes them on the same clock as qc_state_text and the 尺寸 text, which
// are read live too -- latching only the flags would let them disagree.
reg       qstd_r, slrn_r;
reg [3:0] nfac_r, nbod_r;
reg [11:0] qcnt_r, qpas_r;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        qstd_r <= 1'b0; slrn_r <= 1'b0; nfac_r <= 4'd0; nbod_r <= 4'd0;
        qcnt_r <= 12'd0; qpas_r <= 12'd0;
    end else if (frame_start) begin
        qstd_r <= qc_std_on; slrn_r <= sec_learning;
        nfac_r <= sec_faces; nbod_r <= sec_bodies;
        qcnt_r <= qc_cnt_bcd; qpas_r <= qc_pass_bcd;
    end
end

// three BCD digits, leading zeros blanked, right-aligned in 3 cells
function [23:0] cnt3c;
    input [11:0] v;
    cnt3c = {(v[11:8] == 4'd0) ? 8'h20 : (8'h30 + {4'd0, v[11:8]}),
            (v[11:4] == 8'd0) ? 8'h20 : (8'h30 + {4'd0, v[7:4]}),
            8'h30 + {4'd0, v[3:0]}};
endfunction
wire [127:0] cnt_row_any = {CN_JIAN, CN_SHU, ":", cnt3c(qcnt_r), {10{8'h20}}};
wire [127:0] cnt_row_std = {CN_JIAN, CN_SHU, ":", cnt3c(qcnt_r), " ", CN_HE, CN_GE, ":", cnt3c(qpas_r), {3{8'h20}}};
wire qstb_r = qc_stable;
wire qcal_r = qc_cal_show;

wire [4:0] pg_rows = pg_sec ? 5'd2 : !pg_qc ? 5'd0 : qstd_r ? 5'd5 : 5'd7;   // 10-31: + 检数

// the row is part of the active page (rows above it are not drawn at all)
wire lat_vis = ({1'b0, l_cy} + {1'b0, pg_rows}) >= LTROW;

// one digit, 0..9 (both counts are 0..4 in practice: four overlay slots)
function [7:0] dig1;
    input [3:0] v;
    dig1 = (v > 4'd9) ? "9" : (8'h30 + {4'd0, v});
endfunction

// the target count left-aligned, three cells
wire [23:0] det_l = (bcd2[11:8] != 4'd0) ? {det_c2, det_c1, det_c0}
                  : (bcd2[7:4]  != 4'd0) ? {det_c1, det_c0, 8'h20}
                  :                        {det_c0, 8'h20, 8'h20};

// 状态 / 判定 value while a calibration result is up
wire [103:0] cal_13 = {qc_state_text, {5{8'h20}}};

reg [127:0] lat_row;
reg         lat_hide;                // a page row with nothing to say
always @(*) begin
    lat_row  = {16{8'h20}};
    lat_hide = 1'b0;
    if (pg_sec) begin
        if (l_cy == LTROW - 2)                                          // 人脸数
            lat_row = {CN_REN, CN_LIAN, CN_SHU, ":", dig1(nfac_r), {11{8'h20}}};
        else if (l_cy == LTROW - 1)                                     // 轮廓数
            lat_row = {CN_LUN, CN_KUO, CN_SHU, ":", dig1(nbod_r), " ",
                       slrn_r ? {CN_XUE, CN_XI, CN_ZHONG} : {3{8'h20}}, {7{8'h20}}};
    end else if (pg_qc && !qstd_r) begin                                // 任意
        if (l_cy == LTROW - 7)                                          // 工件
            lat_row = {CN_GONG, CN_JIAN2, ":", qc_part_text};
        else if (l_cy == LTROW - 6)                                     // 污渍
            lat_row = {CN_STAIN, CN_ZI4, ":", stain_txt};
        else if (l_cy == LTROW - 5)                                     // 目标
            lat_row = {CN_MU2, CN_BIAO, ":", det_l, {10{8'h20}}};
        else if (l_cy == LTROW - 4)                                     // 识别
            lat_row = {CN_SHI4, CN_BIE, ":", color_name, " ", shape_name, {7{8'h20}}};
        else if (l_cy == LTROW - 3)                                     // 尺寸
            lat_row = {CN_CHI, CN_CUN, ":", qc_size_text, " "};
        else if (l_cy == LTROW - 2)                                     // 状态
            lat_row = {CN_ZHUANG, CN_TAI2, ":",
                       qcal_r ? cal_13
                     : qstb_r ? {CN_YI4, CN_WEN, CN_DING, {10{8'h20}}}
                     :          {CN_CE, CN_LIANG, CN_ZHONG, {10{8'h20}}}};
        else if (l_cy == LTROW - 1)                                     // 检数 (10-31)
            lat_row = cnt_row_any;
    end else if (pg_qc) begin                                           // 标准件
        if (l_cy == LTROW - 5)                                          // 工件
            lat_row = {CN_GONG, CN_JIAN2, ":", qc_part_text};
        else if (l_cy == LTROW - 4)                                     // 尺寸
            lat_row = {CN_CHI, CN_CUN, ":", qc_size_text, " "};
        else if (l_cy == LTROW - 3)                                     // 判定
            lat_row = {CN_PAN2, CN_DING, ":", qcal_r ? cal_13 : qc_judge_text};
        else if (l_cy == LTROW - 2)                                     // 检数 合格 (10-31)
            lat_row = cnt_row_std;
        else if (l_cy == LTROW - 1) begin                               // 原因
            lat_row  = {CN_YUAN, CN_YIN, ":", qc_reason_text};
            lat_hide = qcal_r || (qc_reason_text[103:96] == 8'h20);
        end
    end
end

// Registered for the same reason as top_row_r (py-only, one step per line).
reg [127:0] lat_row_r;
reg         lat_vis_r;
always @(posedge clk) begin
    lat_row_r <= lat_row;
    lat_vis_r <= lat_vis && !lat_hide;
end

wire        in_lat_on = in_lat && lat_vis_r;
wire [7:0]  lat_ascii = lat_row_r[(4'd15 - l_cx[3:0])*8 +: 8];

//-------------------------------------------------------------------
// Wordmark cell coordinates.  Same bit-slice arithmetic as the panel, with its
// own magnification so the brand text can be sized independently of the
// instrumentation text.
//-------------------------------------------------------------------
localparam integer WM_NCHAR     = 7;             // "Anlogic"
localparam integer WM_CELL_LOG2 = 3 + WM_LOG2;   // pixels per cell, log2

// Eight bytes, not seven: the eighth is a space that is never inside in_wm,
// and its only job is to keep the part-select below in range when px is
// outside the wordmark and wx has wrapped.
localparam [63:0] WM_STR = "Anlogic ";

wire [11:0] wx = px - WX0;
wire [11:0] wy = py - WY0;

wire in_wm = (px >= WX0) && (px < (WX0 + (WM_NCHAR << WM_CELL_LOG2)))
          && (py >= WY0) && (py < (WY0 + (12'd8 << WM_LOG2)));

wire [2:0] wm_ci = wx >> WM_CELL_LOG2;   // which character, 0..6
wire [2:0] wm_sx = wx >> WM_LOG2;        // column within the glyph
wire [2:0] wm_sy = wy >> WM_LOG2;        // row within the cell

wire [7:0] wm_ascii = WM_STR[(3'd7 - wm_ci)*8 +: 8];

//-------------------------------------------------------------------
// One font ROM, three consumers.
//
// A priority mux is safe here because the three rectangles are pairwise
// disjoint -- status panel x 32..543 y 32..159, latency readout x 32..543
// y 984..1047, wordmark x 1664..1887 y 104..135.  A second ROM (or a
// dual-port one) would be buying a conflict that cannot arise.
//
// IF ANY RECTANGLE MOVES, RE-CHECK THAT ALL THREE STAY DISJOINT.  The
// failure mode is not a wrong pixel, it is one region silently rendering
// another's glyphs -- and the panel and the readout share an x range, so
// they are separated by y alone.
//-------------------------------------------------------------------
wire [7:0] ascii = in_wm  ? wm_ascii
                 : in_lat ? lat_ascii
                          : panel_ascii;

// The panel strings are printable uppercase and the wordmark is a literal, so
// this clamp never fires in practice -- it is here so a future string with a
// stray byte degrades to a space instead of reading a neighbouring glyph.
// The upper bound is 0x7F because the ROM now carries the lowercase range;
// undefined slots in it are blank, which is the intended degradation.
wire [7:0] ascii_c = (ascii >= 8'h20 && ascii <= 8'h7F) ? ascii : 8'h20;
wire [6:0] slot    = ascii_c - 8'h20;

wire [2:0] font_row = in_wm ? wm_sy : in_lat ? l_sy : t_sy;
wire [2:0] font_col = in_wm ? wm_sx : in_lat ? l_sx : t_sx;

wire [7:0] font_q;
osd_font_rom u_font (
    .clk  (clk),
    .addr ({slot, font_row}),
    .data (font_q)
);

//-------------------------------------------------------------------
// ⭐ CHINESE GLYPHS (10-03).  A byte >= 0x80 in the panel or the readout is
// glyph (byte - 0x80) of osd_cn_rom: 16x16, one glyph per cell, so at the top
// level's 32 px cell it is drawn 2x -- the same cell grid as the ASCII, which
// is why nothing else in the layout moved.  The glyph row / column is the
// cell-local offset scaled to 16 steps, whatever the cell size (otb runs 8 px
// cells and gets every other pixel).
//
// Parallel to the ASCII ROM, same one-clock read, so the only new logic on
// the pixel path is the final 2:1 on glyph_on.  The wordmark never asks.
//-------------------------------------------------------------------
localparam [11:0] CMASK = (12'd1 << CELL_LOG2) - 12'd1;

// 10-20: 0x01..0x1F is the second table (slots 129..159; 0x00 stays a space).
wire        cn_lo   = (ascii[7:5] == 3'b000) && (ascii[4:0] != 5'd0);
wire        is_cn   = !in_wm && (ascii[7] || cn_lo);
wire [7:0]  cn_slot = ascii[7] ? {1'b0, ascii[6:0]} : {3'b100, ascii[4:0]};
wire [11:0] c_ox   = (in_lat ? ltdx : dx) & CMASK;
wire [11:0] c_oy   = (in_lat ? ltdy : dy) & CMASK;
wire [3:0]  cn_col = (c_ox << 4) >> CELL_LOG2;
wire [3:0]  cn_row = (c_oy << 4) >> CELL_LOG2;

wire [15:0] cn_q;
osd_cn_rom u_cn (
    .clk  (clk),
    .addr ({cn_slot, cn_row}),
    .data (cn_q)
);

//-------------------------------------------------------------------
// Logo
//-------------------------------------------------------------------
wire [11:0] lgx = px - LX0;
wire [11:0] lgy = py - LY0;

wire in_logo = (px >= LX0) && (px < (LX0 + (12'd64 << LOGO_LOG2)))
            && (py >= LY0) && (py < (LY0 + (12'd32 << LOGO_LOG2)));

wire [5:0] logo_x = lgx >> LOGO_LOG2;
wire [4:0] logo_y = lgy >> LOGO_LOG2;

wire [1:0] logo_q;
anlogic_logo_rom u_logo (
    .clk  (clk),
    .addr ({logo_y, logo_x}),
    .data (logo_q)
);

//-------------------------------------------------------------------
// Align the picture and the selectors with the ROM read.
//
// ONE delay stage, not two.  The ROMs register their own output, so a signal
// delayed once here is contemporary with the font/logo word, and the output
// register below supplies the second clock of the advertised 2-clock latency.
// Delaying the picture twice puts it one pixel behind the panel decision and
// shifts the whole overlay left by one -- which is exactly what the first
// bench run showed.  hist_osd uses single-stage delays for the same reason.
//-------------------------------------------------------------------
reg [23:0] rgb_d1;
reg        vs_d1, de_d1;
reg [2:0]  sx_d1;
reg [3:0]  cx_d1;
reg        cn_d1;
reg        panel_d1, logo_d1, wm_d1, lat_d1;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        vs_d1 <= 1'b0; de_d1 <= 1'b0;
        panel_d1 <= 1'b0; logo_d1 <= 1'b0; wm_d1 <= 1'b0; lat_d1 <= 1'b0;
    end else begin
        vs_d1    <= in_vs;
        de_d1    <= in_de;
        panel_d1 <= in_panel;
        logo_d1  <= in_logo;
        wm_d1    <= in_wm;
        lat_d1   <= in_lat_on;          // 10-03 evening: only the active page
    end
end

always @(posedge clk) begin
    rgb_d1 <= in_rgb;
    sx_d1  <= font_col;      // whichever region is live this pixel
    cx_d1  <= cn_col;
    cn_d1  <= is_cn;
end

//-------------------------------------------------------------------
// Compose.  Text sits on a quarter-brightness wash of the picture rather than
// a solid block: the panel stays readable over a bright scene without cutting
// a dead rectangle out of the video the judges are being shown.
//-------------------------------------------------------------------
wire glyph_on = cn_d1 ? cn_q[4'd15 - cx_d1] : font_q[3'd7 - sx_d1];

wire [23:0] dimmed = { 2'b00, rgb_d1[23:18],
                       2'b00, rgb_d1[15:10],
                       2'b00, rgb_d1[7:2]   };

wire [23:0] logo_rgb = (logo_q == 2'd1) ? LOGO_BLUE : LOGO_RED;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        out_rgb <= 24'd0;
        out_vs  <= 1'b0;
        out_de  <= 1'b0;
    end else begin
        if (en && logo_d1 && (logo_q != 2'd0))
            out_rgb <= logo_rgb;
        else if (en && wm_d1)
            // Ink only, no wash.  The wordmark is part of the mark above it and
            // has to sit on the video the same way the mark does; a dimmed
            // panel behind it would read as a second UI element.
            out_rgb <= glyph_on ? WM_FG : rgb_d1;
        else if (en && (panel_d1 || lat_d1))
            out_rgb <= glyph_on ? TEXT_FG : dimmed;
        else
            out_rgb <= rgb_d1;

        out_vs <= vs_d1;
        out_de <= de_d1;
    end
end

endmodule
