//---------------------------------------------------------------------------
// aim_label -- security mode (HANDOFF §-9.3 item 7): a two-line label at the
// top-left of every motion box, and a flashing ALARM banner.
//
// 2026-10-01.
//
//   line 0   "1234MM *"     distance; '*' = the ToF head is on this box now
//            "   ?MM *"     no trusted distance (status / sigma / not yet
//                           measured / stale) -- never a number we would not
//                           bet on (§-9.5)
//   line 1   " 450X1700"    width X height, mm; blank without a distance
//
// Cells are the 8x8 OSD font at 2x: 16 px, LCOLS = 10 per line -> a 160 x 32
// label, white (aim target: yellow) on black, inset LINSET px from the box
// corner and pulled left at the right edge so it is never clipped.  Box
// corners come in BLOCK INDICES (motion_frame_drawer's units): x * BLK_W,
// y * BLK_H.
//
// The banner is "ALARM" at 4x (32 px cells, 160 x 32), white on red, centred
// at the top, on for 16 frames and off for 16 (~1.9 Hz at 60 Hz).
// 10-03 evening (user: all OSD text Chinese): it reads 报警 -- four 32 px
// cells, blank / 报 / 警 / blank, 128 x 32, still centred (BAN_X0 896).  The
// two 16x16 glyphs are localparams below (tools/gen_cn_font.py BANNER), drawn
// 2x; this module still has only the ASCII ROM.
//
// ⚠ THE LABEL TABLE IS NOT RE-LATCHED HERE, BY CONSTRUCTION.  aim_sched
// writes all of it on one clock ~600 clocks after the chain vs rises, and
// the chain vs rises 35 lines (~77,000 clocks) before the first active line
// (vs is ~vtc_vs, a 5-line sync pulse -- memory fpga_vs_is_sync_pulse), so
// it is stable for the whole of every active frame.  If this module is ever
// fed from a source that publishes mid-frame, latch at !in_vs instead.
//
// 10-12: THE PASS BANNER.  pass = staff_ctrl verified the staff member (face +
// liveness).  It replaces the alarm banner -- 报警 is not drawn while pass is
// up, whatever alarm says -- and reads "员工 PASS", seven 32 px cells (224 x 32)
// centred at PB_X0, white on green, steady (no blink).  员 / 工 are banner
// localparams like 报 / 警 (tools/gen_cn_font.py BANNER), not CN table slots;
// P A S S come from the ASCII ROM at 4x, the way the original ALARM did.
//
// One font ROM (one ERAM), shared: where the banner and a label overlap,
// the banner wins; where labels overlap, the lower slot wins.
//
// PIPELINE, 5 clocks in -> out:
//   S1  per-label / banner hit and offsets            (registered)
//   S2  priority select; that slot's fields           (registered)
//   S3  char code -> ROM address                      (registered)
//   S4  ROM data                                      (ROM's own register)
//   S5  glyph bit -> pixel                            (output register)
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module aim_label #(
parameter integer NBOX      = 4,
parameter integer BLK_W     = 128,
parameter integer BLK_H     = 72,
parameter integer IMG_HDISP = 1920,
parameter integer LINSET    = 8,
parameter [11:0]  BAN_X0    = 12'd896,
parameter [11:0]  BAN_Y0    = 12'd32,
parameter [23:0]  FG        = 24'hFFFFFF,
parameter [23:0]  FG_AIM    = 24'hFFFF00,
parameter [23:0]  BG        = 24'h000000,
parameter [23:0]  BAN_FG    = 24'hFFFFFF,
parameter [23:0]  BAN_BG    = 24'hE00000,
parameter [11:0]  PB_X0     = 12'd848,      // (1920 - 224) / 2
parameter [23:0]  PB_FG     = 24'hFFFFFF,
parameter [23:0]  PB_BG     = 24'h00A000
)(
input  wire        clk,
input  wire        rst_n,

input  wire [NBOX*4-1:0]  lb_x0,
input  wire [NBOX*4-1:0]  lb_y0,
// 2026-10-01 evening: lb_pix = 1 takes the origins in PIXELS from lb_px0 /
// lb_py0 instead (trk_range: the magenta box is not block-aligned).
// lb_pix = 0 is the block-index path above, unchanged.
input  wire               lb_pix,
input  wire [NBOX*12-1:0] lb_px0,
input  wire [NBOX*12-1:0] lb_py0,
input  wire [NBOX-1:0]    lb_valid,
input  wire [NBOX-1:0]    lb_dok,
input  wire [NBOX-1:0]    lb_aim,
input  wire [NBOX*16-1:0] lb_d_bcd,
input  wire [NBOX*16-1:0] lb_w_bcd,
input  wire [NBOX*16-1:0] lb_h_bcd,
input  wire               alarm,
input  wire               pass,           // 10-12: staff verified -> "员工 PASS", no 报警

input  wire        in_vs,          // HIGH across the visible frame
input  wire        in_de,
input  wire [23:0] in_rgb,
output reg         out_vs,
output reg         out_de,
output reg  [23:0] out_rgb
);

localparam integer LCOLS = 10;
localparam integer LW    = LCOLS * 16;          // 160
localparam integer LH    = 32;
localparam integer LXMAX = IMG_HDISP - LW - LINSET;
localparam integer BW    = 4 * 32;              // " 报警 ", 16x16 glyphs at 2x

// tools/gen_cn_font.py BANNER output: row 0 in the top 16 bits, bit 15 left.
localparam [255:0] BN_BAO   = 256'h100011fc11041104fd141108110015fc19443144d12811281110112851442182;   // 报
localparam [255:0] BN_JING2 = 256'h2420ff20247e7ec482287a104a287ac60500fffe00003ff800003ff820083ff8;   // 警
localparam [255:0] BN_YUAN3 = 256'h00001ff0101010101ff000003ff82008200821082108210802c004301808e004;   // 员
localparam [255:0] BN_GONG2 = 256'h000000007ffc0100010001000100010001000100010001000100fffe00000000;   // 工
localparam integer BH    = 32;
localparam integer PW    = 7 * 32;              // "员工 PASS"

//------------------------------------------------------------------------
// Pixel coordinates.  Same eight lines as every other module here.
//------------------------------------------------------------------------
reg [11:0] px, py;
reg        de_prev;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        px <= 12'd0; py <= 12'd0; de_prev <= 1'b0;
    end else begin
        de_prev <= in_de;
        if (!in_vs) begin
            px <= 12'd0;
            py <= 12'd0;
        end
        else if (in_de) begin
            px <= px + 12'd1;
        end
        else begin
            px <= 12'd0;
            if (de_prev) py <= py + 12'd1;
        end
    end
end

// Blink: one count per frame.
reg       vs_d;
reg [4:0] fcnt;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin vs_d <= 1'b0; fcnt <= 5'd0; end
    else begin
        vs_d <= in_vs;
        if (in_vs && !vs_d) fcnt <= fcnt + 5'd1;
    end
end

//------------------------------------------------------------------------
// Label origins in pixels.  Constant multiplies of a 4-bit index; they only
// change when aim_sched publishes, so the products are registered once and
// the per-pixel compares below see plain registers.
//------------------------------------------------------------------------
reg [11:0] lx [0:NBOX-1];
reg [11:0] ly [0:NBOX-1];
integer o;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        for (o = 0; o < NBOX; o = o + 1) begin lx[o] <= 12'd0; ly[o] <= 12'd0; end
    end else begin
        for (o = 0; o < NBOX; o = o + 1) begin
            if (lb_pix) begin
                lx[o] <= (lb_px0[o*12 +: 12] + LINSET > LXMAX) ? LXMAX
                                                              : lb_px0[o*12 +: 12] + LINSET;
                ly[o] <= lb_py0[o*12 +: 12] + LINSET;
            end else begin
                lx[o] <= (lb_x0[o*4 +: 4] * BLK_W + LINSET > LXMAX) ? LXMAX
                                                                   : lb_x0[o*4 +: 4] * BLK_W + LINSET;
                ly[o] <= lb_y0[o*4 +: 4] * BLK_H + LINSET;
            end
        end
    end
end

//------------------------------------------------------------------------
// S1: hits and offsets
//------------------------------------------------------------------------
reg [NBOX-1:0] h1;
reg [7:0]      dx1 [0:NBOX-1];      // < LW = 160
reg [4:0]      dy1 [0:NBOX-1];      // < LH = 32
reg            bh1, bp1;               // banner hit; it is the PASS banner
reg [7:0]      bdx1;
reg [4:0]      bdy1;
reg            de1;

integer a;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        h1 <= {NBOX{1'b0}}; bh1 <= 1'b0; bp1 <= 1'b0; bdx1 <= 8'd0; bdy1 <= 5'd0; de1 <= 1'b0;
        for (a = 0; a < NBOX; a = a + 1) begin dx1[a] <= 8'd0; dy1[a] <= 5'd0; end
    end else begin
        de1 <= in_de && in_vs;
        for (a = 0; a < NBOX; a = a + 1) begin
            h1[a]  <= lb_valid[a] && (px >= lx[a]) && (px < lx[a] + LW)
                                  && (py >= ly[a]) && (py < ly[a] + LH);
            dx1[a] <= px - lx[a];
            dy1[a] <= py - ly[a];
        end
        bh1  <= pass ? ((px >= PB_X0) && (px < PB_X0 + PW) && (py >= BAN_Y0) && (py < BAN_Y0 + BH))
                     : (alarm && fcnt[4] && (px >= BAN_X0) && (px < BAN_X0 + BW)
                                         && (py >= BAN_Y0) && (py < BAN_Y0 + BH));
        bp1  <= pass;
        bdx1 <= px - (pass ? PB_X0 : BAN_X0);
        bdy1 <= py - BAN_Y0;
    end
end

//------------------------------------------------------------------------
// S2: which one, and its fields
//------------------------------------------------------------------------
reg        any2, ban2, bp2, dok2, aim2;
reg [7:0]  dx2;
reg [4:0]  dy2;
reg [15:0] d2, w2, h2;

integer s;
reg [2:0] sel_c;
reg       hit_c;
always @(*) begin
    hit_c = 1'b0; sel_c = 3'd0;
    for (s = NBOX - 1; s >= 0; s = s - 1)
        if (h1[s]) begin hit_c = 1'b1; sel_c = s; end
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        any2 <= 1'b0; ban2 <= 1'b0; bp2 <= 1'b0; dok2 <= 1'b0; aim2 <= 1'b0;
        dx2 <= 8'd0; dy2 <= 5'd0; d2 <= 16'd0; w2 <= 16'd0; h2 <= 16'd0;
    end else begin
        any2 <= de1 && (bh1 || hit_c);
        ban2 <= bh1;
        bp2  <= bp1;
        dx2  <= bh1 ? bdx1 : dx1[sel_c];
        dy2  <= bh1 ? bdy1 : dy1[sel_c];
        dok2 <= lb_dok[sel_c];
        aim2 <= lb_aim[sel_c];
        d2   <= lb_d_bcd[sel_c*16 +: 16];
        w2   <= lb_w_bcd[sel_c*16 +: 16];
        h2   <= lb_h_bcd[sel_c*16 +: 16];
    end
end

//------------------------------------------------------------------------
// S3: character -> ROM address
//------------------------------------------------------------------------
function [7:0] dg;                      // digit, or blank
    input [3:0] d;
    input       blank;
    dg = blank ? 8'h20 : (8'h30 + {4'd0, d});
endfunction

// Banner cells are 32 px: column dx[7:5], glyph row dy[4:2], glyph col dx[4:2].
// Label cells are 16 px: column dx[7:4], line dy[4], glyph row dy[3:1].
wire [3:0] lcol = dx2[7:4];
wire       lline = dy2[4];

reg [7:0] ch;
always @(*) begin
    if (ban2 && bp2) begin              // 10-12: 员 工 _ P A S S
        case (dx2[7:5])
        3'd3:    ch = "P";
        3'd4:    ch = "A";
        3'd5,
        3'd6:    ch = "S";
        default: ch = 8'h20;
        endcase
    end else if (ban2) begin
        ch = 8'h20;                     // 10-03 evening: 报警 bypasses the ROM
    end else if (!lline) begin
        case (lcol)
        4'd0: ch = dok2 ? dg(d2[15:12], d2[15:12] == 4'd0) : 8'h20;
        4'd1: ch = dok2 ? dg(d2[11:8],  d2[15:8]  == 8'd0) : 8'h20;
        4'd2: ch = dok2 ? dg(d2[7:4],   d2[15:4]  == 12'd0) : 8'h20;
        4'd3: ch = dok2 ? dg(d2[3:0],   1'b0) : "?";
        4'd4: ch = "M";
        4'd5: ch = "M";
        4'd7: ch = aim2 ? "*" : 8'h20;
        default: ch = 8'h20;
        endcase
    end else if (!dok2) begin
        ch = 8'h20;
    end else begin
        case (lcol)
        4'd0: ch = dg(w2[15:12], w2[15:12] == 4'd0);
        4'd1: ch = dg(w2[11:8],  w2[15:8]  == 8'd0);
        4'd2: ch = dg(w2[7:4],   w2[15:4]  == 12'd0);
        4'd3: ch = dg(w2[3:0],   1'b0);
        4'd4: ch = "X";
        4'd5: ch = dg(h2[15:12], h2[15:12] == 4'd0);
        4'd6: ch = dg(h2[11:8],  h2[15:8]  == 8'd0);
        4'd7: ch = dg(h2[7:4],   h2[15:4]  == 12'd0);
        4'd8: ch = dg(h2[3:0],   1'b0);
        default: ch = 8'h20;
        endcase
    end
end

wire [6:0] slot = ch[6:0] - 7'h20;      // every code above is 0x20..0x5F
wire [2:0] grow = ban2 ? dy2[4:2] : dy2[3:1];

reg [9:0] addr3;
reg       any3, ban3, bp3, cn3, aim3;
reg [2:0] gcol3;
reg [15:0] brow3;                       // banner glyph row (cells 1, 2)
reg [3:0]  bcol3;                       // column within it, dx[4:1]
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        addr3 <= 10'd0; any3 <= 1'b0; ban3 <= 1'b0; bp3 <= 1'b0; cn3 <= 1'b0; aim3 <= 1'b0; gcol3 <= 3'd0;
        brow3 <= 16'd0; bcol3 <= 4'd0;
    end else begin
        brow3 <= bp2 ? ((dx2[7:5] == 3'd0) ? BN_YUAN3[(4'd15 - dy2[4:1])*16 +: 16]
                      : (dx2[7:5] == 3'd1) ? BN_GONG2[(4'd15 - dy2[4:1])*16 +: 16]
                      :                      16'd0)
               : (dx2[7:5] == 3'd1) ? BN_BAO  [(4'd15 - dy2[4:1])*16 +: 16]
               : (dx2[7:5] == 3'd2) ? BN_JING2[(4'd15 - dy2[4:1])*16 +: 16]
               :                      16'd0;
        // the 16x16 path: every alarm-banner cell, PASS-banner cells 0 and 1
        cn3   <= ban2 && (!bp2 || (dx2[7:5] <= 3'd1));
        bp3   <= bp2;
        bcol3 <= dx2[4:1];
        addr3 <= {slot, grow};
        any3  <= any2;
        ban3  <= ban2;
        aim3  <= aim2;
        gcol3 <= ban2 ? dx2[4:2] : dx2[3:1];
    end
end

//------------------------------------------------------------------------
// S4: ROM
//------------------------------------------------------------------------
wire [7:0] glyph;
osd_font_rom u_font (
    .clk  ( clk   ),
    .addr ( addr3 ),
    .data ( glyph )
);

reg       any4, ban4, bp4, cn4, aim4;
reg [2:0] gcol4;
reg [15:0] brow4;
reg [3:0]  bcol4;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin any4 <= 1'b0; ban4 <= 1'b0; bp4 <= 1'b0; cn4 <= 1'b0; aim4 <= 1'b0; gcol4 <= 3'd0; brow4 <= 16'd0; bcol4 <= 4'd0; end
    else begin any4 <= any3; ban4 <= ban3; bp4 <= bp3; cn4 <= cn3; aim4 <= aim3; gcol4 <= gcol3; brow4 <= brow3; bcol4 <= bcol3; end
end

//------------------------------------------------------------------------
// S5: pixel, and picture/sync delayed to match
//------------------------------------------------------------------------
wire ink = cn4 ? brow4[4'd15 - bcol4]    // 报警 / 员工, bit 15 leftmost
                : glyph[3'd7 - gcol4];   // bit 7 is the leftmost pixel (labels, PASS)

reg [23:0] rgb_d [0:3];
reg [3:0]  vs_dl, de_dl;
integer q;
always @(posedge clk) begin
    rgb_d[0] <= in_rgb;
    for (q = 1; q < 4; q = q + 1) rgb_d[q] <= rgb_d[q-1];
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        vs_dl <= 4'd0; de_dl <= 4'd0;
        out_rgb <= 24'd0; out_vs <= 1'b0; out_de <= 1'b0;
    end else begin
        vs_dl <= {vs_dl[2:0], in_vs};
        de_dl <= {de_dl[2:0], in_de};
        out_vs <= vs_dl[3];
        out_de <= de_dl[3];
        out_rgb <= !any4 ? rgb_d[3]
                 : ban4  ? (bp4 ? (ink ? PB_FG : PB_BG) : (ink ? BAN_FG : BAN_BG))
                 :         (ink ? (aim4 ? FG_AIM : FG) : BG);
    end
end

endmodule
