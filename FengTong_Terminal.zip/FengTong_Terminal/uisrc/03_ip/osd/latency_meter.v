//---------------------------------------------------------------------------
// latency_meter -- live capture-to-display latency, measured on chip.
//
// WHY
//   "处理延迟可视化" is one of the five advanced scored items, and it is the
//   one that costs the least to earn.  It is also the item that carries the
//   product claim: the whole argument for a hardware pipeline over a
//   PC/GPU front end is that the latency is small AND deterministic, and a
//   number on the screen is what turns that from a slide into evidence.
//   A report that says "we implemented it" scores differently from one that
//   says "we measured 33.4 ms end to end, here is the counter that did it".
//
// WHAT IT MEASURES
//   Wall time from the sensor starting to emit a frame to that frame's first
//   pixel leaving the HDMI transmitter.  Decomposed as
//
//       latency = NBUF_LAG * T_cam  +  phase  +  chain
//
//   where
//       T_cam   camera frame period, MEASURED (clocks between sensor SOFs)
//       phase   clocks from the last sensor SOF to the display frame's first
//               active pixel, MEASURED
//       chain   clocks from uivtc's first active pixel to the first active
//               pixel at hdmi_tx's input, MEASURED -- the whole ISP +
//               morphology + affine + wheel + replace + motion + OSD depth
//       NBUF_LAG whole camera frames of DDR3 buffering, a DESIGN CONSTANT
//               of 1, derived in the parameter comment below
//
//   Three of the four terms are counters, not constants.  That matters for
//   the report: the number tracks the sensor's actual frame rate and the
//   actual pipeline, so if a later revision adds pipeline stages the reading
//   follows without anybody remembering to update a constant.
//
//   Deriving 'phase' this way rather than tagging pixel data with a
//   timestamp keeps the write path untouched.  The tagging approach (write a
//   timestamp into the frame's first pixels, read it back) needs surgery on
//   the camera-to-DDR3 packing and on the read-side unpack, and it needs its
//   own counter CDC anyway, for the same answer.
//
// CLOCK DOMAINS
//   Everything is computed in pclkx1.  The only crossing is the sensor frame
//   start, which arrives on S_hs_rx_clk (the MIPI byte clock).  It is
//   brought over as a toggle, not as a pulse: a pulse one cam_clk wide can
//   fall between two pclkx1 edges and be lost outright, whereas a toggle is
//   a level that a 2-flop synchroniser cannot miss.  The third flop is the
//   edge detector.  Valid as long as the sensor frame rate stays far below
//   pclkx1/2, which at 30fps against 150MHz it does by six orders of
//   magnitude.
//
//   That crossing is not in the timing report because S_hs_rx_clk has no
//   create_clock -- it is part of the 2% the STA does not cover, same as the
//   rest of the MIPI receive path.  The synchroniser is what makes that
//   safe; do not "simplify" it away.
//
// NO MULTIPLIER, NO DIVIDER
//   Both conversions (clocks to 0.1 ms, clocks to frames) are done by
//   repeated subtraction spread across the frame, and binary to BCD by
//   double dabble one iteration per clock.  A display frame is 2,475,000
//   pclkx1 clocks and the worst case here is about 2,300 of them, so the
//   whole calculation finishes inside the first line and a half of the
//   frame.  This is not premature optimisation: text_osd's header explains
//   why nothing on this clock gets a multiplier, and the same reasoning
//   applies to a module that shares its budget.
//
// LATENCY OF THIS MODULE
//   Zero -- it has no video path.  It taps vtc_de and txt_out_de and drives
//   nothing but the OSD's text.
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module latency_meter #(
    // pclkx1 clocks per 0.1 ms.  150.015MHz * 1e-4 s = 15001.5, so 15002 is
    // three parts in 100,000 long -- far inside the 0.1 ms quantisation of
    // the reading itself.  Retune together with the pixel clock.
    parameter integer TENTH_DIV = 15002,

    // Whole camera frames of DDR3 buffering between "frame written" and
    // "frame displayed".  NOT a fudge factor: system_top instantiates
    // uisetvbuf with BUF_DELAY=2 over BUF_LENTH=3, so the reader is handed
    // buffer (w+2) mod 3 = (w-1) mod 3 -- exactly one whole camera frame
    // behind the writer.  Revisit only if those two parameters change.
    parameter integer NBUF_LAG = 1,

    // Ceilings.  9999 displays as 999.9 ms and is the "sensor is not
    // producing frames" indication: cam_ph runs away and pins the reading
    // instead of wrapping round to a plausible-looking small number, which
    // would be worse than useless on a demo bench.
    parameter integer TENTH_MAX = 9999,
    parameter integer FRAME_MAX = 15
)(
    input  wire        clk,          // pclkx1
    input  wire        rst_n,

    // Sensor side.  cam_sof is one cam_clk wide, once per sensor frame.
    input  wire        cam_clk,      // S_hs_rx_clk
    input  wire        cam_sof,      // S_raw8_frame_start

    // Display side, all already in the clk domain.
    input  wire        vtc_vs,       // narrow POSITIVE pulse in vertical blanking
    input  wire        vtc_de,       // uivtc data enable -- head of the chain
    input  wire        out_de,       // data enable at hdmi_tx's input -- tail

    output reg  [15:0] lat_bcd,      // four BCD digits of the 0.1 ms reading
    output reg  [3:0]  lat_frames,   // latency in whole camera frames
    output reg  [25:0] lat_clks,     // exact, for the report / ChipWatcher
    output reg  [15:0] chain_clks    // measured processing-chain depth
);

//-------------------------------------------------------------------
// Sensor frame start, cam_clk -> clk.  Toggle, two synchroniser flops, one
// edge detector.  See CLOCK DOMAINS in the header.
//
// No reset on cam_tgl: there is no reset in this domain that is guaranteed
// released after the MIPI clock is running, and the value does not matter --
// only its transitions do, and a wrong initial value costs at most one
// spurious pulse at power-up, hundreds of frames before anyone reads the
// panel.
//-------------------------------------------------------------------
reg cam_tgl = 1'b0;
always @(posedge cam_clk) begin
    if (cam_sof) cam_tgl <= ~cam_tgl;
end

reg [2:0] tgl_s;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) tgl_s <= 3'b000;
    else        tgl_s <= {tgl_s[1:0], cam_tgl};
end
wire cam_sof_p = tgl_s[2] ^ tgl_s[1];

//-------------------------------------------------------------------
// Camera frame period and phase.  One counter yields both: its value at the
// moment of a sensor SOF is the period that just ended, and its value at any
// other moment is the phase since that SOF.
//
// Saturating rather than wrapping.  If the sensor stops, a wrapping counter
// would keep producing small, believable latency readings; saturation walks
// the reading up to 999.9 and parks it there, which is diagnosable from
// across the room.  24 bits saturates at 112 ms, about seven display frames.
//-------------------------------------------------------------------
localparam [23:0] PH_MAX = 24'hFFFFFF;

reg [23:0] cam_ph, cam_per;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        cam_ph  <= 24'd0;
        cam_per <= 24'd0;
    end else if (cam_sof_p) begin
        cam_per <= cam_ph;      // exact: clocks from the previous SOF to this one
        cam_ph  <= 24'd1;
    end else if (cam_ph != PH_MAX) begin
        cam_ph  <= cam_ph + 1'b1;
    end
end

//-------------------------------------------------------------------
// Display frame boundary, and the processing-chain depth.
//
// The reference instant is the frame's first ACTIVE pixel, not vs: vs is a
// narrow positive pulse sitting in vertical blanking (vcnt 1085..1089) and
// there is no single vs convention across this chain -- ISP/morphology/
// affine run frame-active-high, color_convert runs frame-active-low.  de is
// unambiguous everywhere, so both ends of the chain measurement use it and
// vs is only used to arm the flags once per frame.
//
// Clearing both flags on vtc_vs is safe because the chain is tens of clocks
// deep against 45 lines of vertical blanking -- out_de for a frame always
// lands long before the next vs.
//-------------------------------------------------------------------
reg        vin_seen, vout_seen;
reg [15:0] chain_cnt;

wire disp_sof_p = vtc_de & ~vin_seen;   // one clock, at the first active pixel

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        vin_seen <= 1'b0; vout_seen <= 1'b0;
        chain_cnt <= 16'd0; chain_clks <= 16'd0;
    end else if (vtc_vs) begin
        vin_seen <= 1'b0; vout_seen <= 1'b0;
        chain_cnt <= 16'd0;
    end else begin
        if (vtc_de) vin_seen <= 1'b1;
        if (vin_seen && !vout_seen) begin
            if (out_de) begin
                vout_seen  <= 1'b1;
                // +1 because chain_cnt does not advance on the clock that
                // sets vin_seen, so it lags the true separation by one.
                chain_clks <= chain_cnt + 16'd1;
            end else begin
                chain_cnt  <= chain_cnt + 16'd1;
            end
        end
    end
end

//-------------------------------------------------------------------
// The sum.  NBUF_LAG is a parameter but is never a real multiply: 0, 1 and 2
// are a mux and a shift.  Anything above 2 is clamped, because a fourth
// buffer would be a change to uisetvbuf, and whoever makes that change
// should come back here rather than get silently wrong arithmetic.
//-------------------------------------------------------------------
localparam integer LAG = (NBUF_LAG > 2) ? 2 : NBUF_LAG;

wire [25:0] lag_term = (LAG == 2) ? {cam_per, 1'b0}
                     : (LAG == 1) ? {2'b00, cam_per}
                                  : 26'd0;

wire [25:0] lat_next = lag_term + {2'b00, cam_ph} + {10'd0, chain_clks};

//-------------------------------------------------------------------
// Conversion, once per display frame:
//   S_TENTH  clocks   -> 0.1 ms, repeated subtraction of TENTH_DIV
//   S_FRAME  clocks   -> whole camera frames, repeated subtraction of cam_per
//   S_BCD    0.1 ms   -> four BCD digits, double dabble
//
// Worst case is S_TENTH at 24-bit saturation: 33.5M/15002 = about 2,240
// clocks, against 2,475,000 in a display frame.
//-------------------------------------------------------------------
localparam [1:0] S_IDLE = 2'd0, S_TENTH = 2'd1, S_FRAME = 2'd2, S_BCD = 2'd3;

reg [1:0]  st;
reg [25:0] rem, frem;
reg [23:0] per_hold;
reg [13:0] tenth_q;
reg [3:0]  frm_q;
reg [3:0]  dab_step;
reg [15:0] dab_bcd;
reg [13:0] dab_bin;

wire [15:0] dab_adj = { (dab_bcd[15:12] >= 4'd5) ? (dab_bcd[15:12] + 4'd3) : dab_bcd[15:12],
                        (dab_bcd[11:8]  >= 4'd5) ? (dab_bcd[11:8]  + 4'd3) : dab_bcd[11:8],
                        (dab_bcd[7:4]   >= 4'd5) ? (dab_bcd[7:4]   + 4'd3) : dab_bcd[7:4],
                        (dab_bcd[3:0]   >= 4'd5) ? (dab_bcd[3:0]   + 4'd3) : dab_bcd[3:0]  };

wire [15:0] dab_next = { dab_adj[14:0], dab_bin[13] };

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        st       <= S_IDLE;
        rem      <= 26'd0;  frem    <= 26'd0;  per_hold <= 24'd0;
        tenth_q  <= 14'd0;  frm_q   <= 4'd0;
        dab_step <= 4'd0;   dab_bcd <= 16'd0;  dab_bin  <= 14'd0;
        lat_bcd  <= 16'd0;  lat_frames <= 4'd0; lat_clks <= 26'd0;
    end else if (disp_sof_p) begin
        // Restart unconditionally.  A frame time is three orders of
        // magnitude longer than the calculation, so an in-flight conversion
        // here would mean something is badly wrong; taking the newest input
        // is the right recovery either way.
        lat_clks <= lat_next;
        rem      <= lat_next;
        frem     <= lat_next;
        per_hold <= cam_per;
        tenth_q  <= 14'd0;
        frm_q    <= 4'd0;
        st       <= S_TENTH;
    end else begin
        case (st)
            S_TENTH: begin
                if ((rem >= TENTH_DIV) && (tenth_q < TENTH_MAX)) begin
                    rem     <= rem - TENTH_DIV;
                    tenth_q <= tenth_q + 1'b1;
                end else begin
                    st <= S_FRAME;
                end
            end

            S_FRAME: begin
                // per_hold == 0 before the first two sensor SOFs have been
                // seen; without this guard the subtraction would never
                // reduce frem and the state machine would sit here.
                if ((per_hold != 24'd0) && (frem >= {2'b00, per_hold})
                                        && (frm_q < FRAME_MAX)) begin
                    frem  <= frem - {2'b00, per_hold};
                    frm_q <= frm_q + 1'b1;
                end else begin
                    dab_bin  <= tenth_q;
                    dab_bcd  <= 16'd0;
                    dab_step <= 4'd14;      // 14 bits in, one shift per clock
                    st       <= S_BCD;
                end
            end

            S_BCD: begin
                if (dab_step != 4'd0) begin
                    dab_bcd  <= dab_next;
                    dab_bin  <= {dab_bin[12:0], 1'b0};
                    dab_step <= dab_step - 4'd1;
                    if (dab_step == 4'd1) begin
                        lat_bcd    <= dab_next;
                        lat_frames <= frm_q;
                    end
                end else begin
                    st <= S_IDLE;
                end
            end

            default: st <= S_IDLE;
        endcase
    end
end

endmodule
