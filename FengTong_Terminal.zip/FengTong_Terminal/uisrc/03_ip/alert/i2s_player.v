//---------------------------------------------------------------------------
// i2s_player -- plays one of NCLIP voice clips out of an on-chip ROM to a
// MAX98357A I2S amplifier.  2026-10-04.
//
// Clock plan: no new PLL.  BCLK = clk / (2*BCLK_HALF); at clk = 150 MHz and
// BCLK_HALF = 293 that is 255.97 kHz, 32 BCLK per frame -> fs = 7999 Hz
// (0.01 % slow; inaudible).  Philips I2S, 16-bit slots: LRC low = left, MSB
// one BCLK after each LRC edge, DIN changes on the BCLK falling edge.  Both
// slots carry the same sample (MAX98357A with SD floating outputs (L+R)/2).
//
// ROM: 8-bit signed PCM at 8 kHz, one byte per line in VOICE_FILE
// ($readmemh, resolved relative to the CALLER's directory and SILENT on a
// missing file -- check the synthesis log for the file being read).  Clip i
// occupies [START_i, START_i + LEN_i).  Built by tools/voice/make_voice_rom.py,
// which also prints the START/LEN parameters.
//
// play pulses for one clk with clip id; ignored while busy (the caller
// re-requests if it still cares).  VOL_SHIFT attenuates in 6 dB steps.
//
// The outputs leave on J14 at 1.8 V; MAX98357A VIH is ~1.3 V [unverified],
// so direct connection is the first thing to try (see 硬件参数与接线/README.md).
//---------------------------------------------------------------------------
module i2s_player #(
    parameter        BCLK_HALF  = 293,
    parameter        ROM_AW     = 16,
    parameter        ROM_DEPTH  = 49152,
    parameter        VOICE_FILE = "voice_rom.hex",
    parameter [ROM_AW-1:0] START0 = 0,
    parameter [ROM_AW-1:0] LEN0   = 0,
    parameter [ROM_AW-1:0] START1 = 0,
    parameter [ROM_AW-1:0] LEN1   = 0,
    parameter [ROM_AW-1:0] START2 = 0,
    parameter [ROM_AW-1:0] LEN2   = 0,
    parameter [ROM_AW-1:0] START3 = 0,
    parameter [ROM_AW-1:0] LEN3   = 0,
    // 2026-10-07: clips 4/5 (mode announcements); clip widened to 3 bits
    parameter [ROM_AW-1:0] START4 = 0,
    parameter [ROM_AW-1:0] LEN4   = 0,
    parameter [ROM_AW-1:0] START5 = 0,
    parameter [ROM_AW-1:0] LEN5   = 0,
    // 2026-10-12: clips 6..8 (staff verification: passed / open mouth / blink);
    // clip widened to 4 bits.  A 3-bit caller still works (zero-extended).
    parameter [ROM_AW-1:0] START6 = 0,
    parameter [ROM_AW-1:0] LEN6   = 0,
    parameter [ROM_AW-1:0] START7 = 0,
    parameter [ROM_AW-1:0] LEN7   = 0,
    parameter [ROM_AW-1:0] START8 = 0,
    parameter [ROM_AW-1:0] LEN8   = 0,
    // 2026-10-12 night: clip 9 (staff verification failed)
    parameter [ROM_AW-1:0] START9 = 0,
    parameter [ROM_AW-1:0] LEN9   = 0,
    // 2026-10-24: clip 10 (staff verification: come closer)
    parameter [ROM_AW-1:0] START10 = 0,
    parameter [ROM_AW-1:0] LEN10   = 0,
    parameter        VOL_SHIFT  = 0
)(
    input            clk,
    input            rst_n,
    input            play,
    input      [3:0] clip,
    output reg       busy,
    output reg       o_bclk,
    output reg       o_lrc,
    output reg       o_din
);

//------------------------------------------------------------- ROM
reg [7:0] rom [0:ROM_DEPTH-1];
initial $readmemh(VOICE_FILE, rom);

reg [ROM_AW-1:0] rd_addr;
reg [7:0]        rom_q;
always @(posedge clk) rom_q <= rom[rd_addr];

//------------------------------------------------------------- BCLK
reg [9:0] div;
wire      half_tick = (div == BCLK_HALF - 1);
wire      fall      = half_tick &  o_bclk;   // bclk about to go 1 -> 0
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        div    <= 10'd0;
        o_bclk <= 1'b0;
    end else if (half_tick) begin
        div    <= 10'd0;
        o_bclk <= ~o_bclk;
    end else
        div <= div + 10'd1;
end

//------------------------------------------------------------- playback
reg [ROM_AW-1:0] end_addr;
reg [4:0]        pos;        // frame position, advanced on falling edges
reg [15:0]       cur, nxt;
reg              fetch_d1, fetch_d2;

reg [ROM_AW-1:0] sel_start, sel_len;
always @(*) begin
    case (clip)
    4'd0:    begin sel_start = START0; sel_len = LEN0; end
    4'd1:    begin sel_start = START1; sel_len = LEN1; end
    4'd2:    begin sel_start = START2; sel_len = LEN2; end
    4'd3:    begin sel_start = START3; sel_len = LEN3; end
    4'd4:    begin sel_start = START4; sel_len = LEN4; end
    4'd5:    begin sel_start = START5; sel_len = LEN5; end
    4'd6:    begin sel_start = START6; sel_len = LEN6; end
    4'd7:    begin sel_start = START7; sel_len = LEN7; end
    4'd8:    begin sel_start = START8; sel_len = LEN8; end
    4'd9:    begin sel_start = START9; sel_len = LEN9; end
    4'd10:   begin sel_start = START10; sel_len = LEN10; end
    default: begin sel_start = 0;      sel_len = 0;    end   // 11..15: no clip, play ignored
    endcase
end

// fetch the next sample once per frame, mid-frame, well before pos wraps
wire fetch = fall && (pos == 5'd15);

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        busy     <= 1'b0;
        rd_addr  <= {ROM_AW{1'b0}};
        end_addr <= {ROM_AW{1'b0}};
        fetch_d1 <= 1'b0;
        fetch_d2 <= 1'b0;
        nxt      <= 16'd0;
    end else begin
        fetch_d1 <= fetch && busy && (rd_addr != end_addr);
        fetch_d2 <= fetch_d1;
        if (play && !busy && sel_len != 0) begin
            busy     <= 1'b1;
            rd_addr  <= sel_start;
            end_addr <= sel_start + sel_len;
        end else if (fetch && busy) begin
            if (rd_addr == end_addr) begin
                busy <= 1'b0;
                nxt  <= 16'd0;
            end
        end
        // rom_q for rd_addr is valid one clock after fetch_d1 is raised
        if (fetch_d2) begin
            nxt     <= $signed({rom_q, 8'h00}) >>> VOL_SHIFT;
            rd_addr <= rd_addr + 1'b1;
        end
        if (!busy && !play) nxt <= 16'd0;
    end
end

// serialiser: at falling edge, pos -> pos+1 and DIN shows bit for new pos.
// Slot bit k = (pos-1) mod 16 carries cur[15-k]; pos 0 carries the previous
// frame's LSB, so cur is reloaded at pos 1.
wire [4:0] npos = pos + 5'd1;
wire [3:0] k    = npos[3:0] - 4'd1;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        pos   <= 5'd31;
        cur   <= 16'd0;
        o_lrc <= 1'b1;
        o_din <= 1'b0;
    end else if (fall) begin
        pos   <= npos;
        o_lrc <= npos[4];
        if (npos == 5'd1) begin
            cur   <= nxt;
            o_din <= nxt[15];
        end else
            o_din <= cur[15 - k];
    end
end

endmodule
