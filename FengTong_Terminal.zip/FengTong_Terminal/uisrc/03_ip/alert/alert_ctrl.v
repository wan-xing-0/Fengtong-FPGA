//---------------------------------------------------------------------------
// alert_ctrl -- security-mode reaction to an intruder: spotlight + voice.
// 2026-10-04.  (10-05: the fill light is NOT here -- it is ambient-light
// driven, in both security and inspection mode; see light_meter.v.)
//
// 2026-10-05 evening: THREE LEVELS -- motion wakes, a face confirms.
//
//   target  = "something moves" (system_top's lbm_alarm, which already
//             carries trk_range/aim_label's ALARM_HOLD frames).
//   person  = a face associated with the target THIS frame (face_assoc.v).
//
//   level 0  no episode                              spot off, silent
//   level 1  motion, not yet confirmed               spot on,  silent
//   level 2  a face was seen in this episode         spot on,  voice
//   level 3  NOFACE_S s of motion and still no face  spot on,  voice
//            ("moving but hiding its face" -- the case the face detector
//            misses is promoted, not dropped)
//
//   voice, once confirmed:
//     confirmation                   -> clip 0  "您已进入监控区域，请离开"
//     still there ESC_S s later      -> clip 1  "警告，请立即离开"
//     then every REPEAT_S s          -> clip 1 again
//
// ⚠ WHAT "NOFACE_S s OF MOTION" MEANS, because the motion box DROPS OUT AND
// RE-ACQUIRES on the board.  The clock is an EPISODE clock, not a "box has
// been up continuously" clock:
//   * an episode starts on the first target and ends only after target has
//     been absent for REARM_S s in a row;
//   * on_s counts seconds WITH target up inside the episode and is NOT reset
//     by a dropout -- it pauses and resumes.
// So a box that blinks out for a second and comes back keeps its time; a
// counter that restarted on every re-acquire would never reach NOFACE_S for
// exactly the intruder this level exists for.  The face flag is sticky for
// the same reason: one confirmed frame confirms the episode.
//
// SPOT_HOLD_CLKS (10-06): the spot stays on this many clocks after target
// last fell -- a floor under the lamp's on/off rate whatever the inputs do,
// so no upstream dropout can ever strobe it.  0 = spot_en = en && target,
// the 10-05 behaviour bit for bit.
//
// Time base: one tick per TICK_CLKS clocks (150 MHz / 150_000_000 = 1 s),
// restarted when an episode starts so NOFACE_S is whole seconds, not
// "NOFACE_S minus up to one".  Tests shrink TICK_CLKS.
//---------------------------------------------------------------------------
module alert_ctrl #(
    parameter TICK_CLKS    = 150_000_000,
    parameter ESC_S        = 6,
    parameter REPEAT_S     = 8,
    parameter REARM_S      = 5,
    parameter NOFACE_S     = 2,
    parameter SPOT_HOLD_CLKS = 0
)(
    input            clk,
    input            rst_n,
    input            en,
    input            target,
    input            person,
    input            player_busy,
    output reg       play,
    output reg [1:0] clip,
    output           spot_en,
    output     [1:0] level
);

wire act = en && target;

reg        episode;     // from the first target until REARM_S s of absence
reg [7:0]  on_s, off_s;
reg        warned;      // clip 0 has been requested in this episode
reg        seen_face;   // a face was associated at least once this episode
reg [7:0]  next_s;      // on_s value at which the next clip 1 is due

wire start = act && !episode;

reg [27:0] tick_cnt;
wire       tick = (tick_cnt == TICK_CLKS - 1);
always @(posedge clk or negedge rst_n)
    if (!rst_n)            tick_cnt <= 28'd0;
    else if (tick || start) tick_cnt <= 28'd0;
    else                   tick_cnt <= tick_cnt + 28'd1;

wire confirm = person || seen_face || (episode && on_s >= NOFACE_S);

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        episode   <= 1'b0;
        on_s      <= 8'd0;
        off_s     <= 8'd0;
        warned    <= 1'b0;
        seen_face <= 1'b0;
        next_s    <= ESC_S;
        play      <= 1'b0;
        clip      <= 2'd0;
    end else if (!en) begin
        episode   <= 1'b0;
        on_s      <= 8'd0;
        off_s     <= 8'd0;
        warned    <= 1'b0;
        seen_face <= 1'b0;
        play      <= 1'b0;
    end else begin
        play <= 1'b0;
        if (act) begin
            off_s <= 8'd0;
            if (start) begin
                episode <= 1'b1;
                on_s    <= 8'd0;
            end else if (tick && on_s != 8'hff)
                on_s <= on_s + 8'd1;
            if (person) seen_face <= 1'b1;
            if (!warned) begin
                if (confirm && !player_busy) begin
                    play   <= 1'b1;
                    clip   <= 2'd0;
                    warned <= 1'b1;
                    on_s   <= 8'd0;
                    next_s <= ESC_S;
                end
            end else if (on_s >= next_s && !player_busy) begin
                play   <= 1'b1;
                clip   <= 2'd1;
                next_s <= on_s + REPEAT_S;
            end
        end else begin
            if (tick && off_s != 8'hff) off_s <= off_s + 8'd1;
            if (off_s >= REARM_S) begin
                episode   <= 1'b0;
                warned    <= 1'b0;
                seen_face <= 1'b0;
                on_s      <= 8'd0;
            end
        end
    end
end

reg [27:0] spot_cnt;
always @(posedge clk or negedge rst_n)
    if (!rst_n)              spot_cnt <= 28'd0;
    else if (!en)            spot_cnt <= 28'd0;
    else if (act)            spot_cnt <= SPOT_HOLD_CLKS;
    else if (spot_cnt != 0)  spot_cnt <= spot_cnt - 28'd1;

assign spot_en = act || (en && spot_cnt != 28'd0);
assign level   = !episode   ? 2'd0 :
                 !warned    ? 2'd1 :
                 seen_face  ? 2'd2 : 2'd3;

endmodule


//---------------------------------------------------------------------------
// alarm_src -- what alert_ctrl.target means when SEC_ALARM_SRC = 1.  2026-10-23.
//
// User 10-23 night (22:05 board video): "一开始画面中没有任何框也报警了，人走远了有框
// 但是没有报警" -- the 10-05 wiring wakes the alarm on the MOTION tracker
// (lbm_alarm), which is not drawn any more (MD_DRAW = 0) and loses slow / far
// people, while the blue box only kept an alarm already up (SEC_SPOT_GD = 1).
// Here the alarm follows what is on the screen:
//
//   target = face                                  a red face box is up
//         || box && (episode || box held START_MS) the blue person box
//
//   face  = |face_vld (face_detect's confirmed boxes, CONFIRM frames already).
//   box   = gd_person (grid_post, after the ToF gate).
//   START_MS: a blue box must be up that long, without a gap, before it can
//   START an episode (a few-publish false box cannot light the lamp); once an
//   episode is up (alert_ctrl level != 0) any blue box keeps it.
// Registered: target is one clock late, nothing combinational reaches alert_ctrl.
//---------------------------------------------------------------------------
module alarm_src #(
    parameter integer CLK_HZ   = 150_000_000,
    parameter integer START_MS = 500
)(
    input      clk,
    input      rst_n,
    input      en,
    input      box,
    input      face,
    input      episode,
    output reg target
);
localparam integer TICK = CLK_HZ / 1000;
reg [17:0] pre;
reg [15:0] on_ms;
wire ms = (pre == TICK - 1);
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        pre <= 18'd0; on_ms <= 16'd0; target <= 1'b0;
    end else begin
        pre <= ms ? 18'd0 : pre + 18'd1;
        if (!en || !box)                    on_ms <= 16'd0;
        else if (ms && on_ms != START_MS)   on_ms <= on_ms + 16'd1;
        target <= en && (face || (box && (episode || on_ms == START_MS)));
    end
end
endmodule


//---------------------------------------------------------------------------
// spot_seq -- the spotlight around staff verification.  2026-10-23.
//
// User 10-23 night: the red spot on the face makes recognition / liveness
// worse than in normal light.  So:
//   * the liveness prompt starts (staff_ctrl plays clip 7 / 8)
//         -> the spot flashes FLASH_N times with it (ON_MS on, OFF_MS off),
//            then stays DARK for the rest of the challenge (retries included)
//   * PASS   -> alert_ctrl is off (system_top), and stays off QUIET_S s after
//               pass falls, so the staff member walking away is not an intruder
//   * FAIL   -> staff_ctrl leaves the challenge (COOL / IDLE): the spot is
//               alert_ctrl's again, so it comes back on the person
//   * before the prompt is out (it waits for the alarm voice) the spot is
//     alert_ctrl's, unchanged.
// en = 0 (not security mode): spot_out = spot_in, everything cleared.
//
// CHAL_LIT (10-26, 10-25 23:40 video): after the flashes the spot stays LIT,
// forced on whatever spot_in does, until the challenge ends.  In that room
// face_detect does not see a 0.5 m face without the spot (the fill light was
// on): all 12 challenges lost the face < 1 s after the flashes, LOST_T ->
// "未通过" -> COOL -> spot back -> recognised -> prompt again -- the voice
// loop.  Offline on the same frames (staff_q golden, YuNet boxes) the red
// spot does not hurt: rec >= 0.80 97 % lit vs 89 % dark.  Forced rather than
// spot_in: alert_ctrl's spot follows the boxes, and the boxes need the light.
// Bounded by the challenge (PASS / COOL leave it).  0 = DARK, 10-23 bit for bit.
//
// STAFF_DARK (10-27, user on the 17:12 video: "开始识别射灯仍亮"): from the
// moment the face is recognised as the staff member (staff_ctrl NEAR, then the
// challenge) the spot is OFF, except the FLASH_N flashes with the prompt.  It
// overrides CHAL_LIT.  The 10-26 reason for CHAL_LIT does not hold on this
// video: lit, face_detect still lost the face for 6 s, and the lamp on the
// shirt is what made the box sit low (cos 0.5-0.66 vs 0.97 offline); staff_cap
// HOLD now bridges the drop-outs instead.  0 = the 10-26 behaviour bit for bit.
//
// PASS_DARK_MS (10-28, user on the 10-28 00:00 video: after a pass the spot
// never came back -- QUIET_S 30 kept alert_ctrl off for 30 s after pass fell,
// and every new pass restarted it, so it stayed dark for the last 90 s).  The
// spot is now dark only PASS_DARK_MS from the pass, then alert_ctrl runs again
// and its spot follows the blue box / face as usual.  The VOICE keeps the old
// rule: `mute` = pass, or < QUIET_S s since it fell; system_top holds alert_ctrl's
// player_busy with it, so the alarm waits (warned stays 0, sec_level stays at 1
// -> no Ethernet alarm pictures of the staff member).  quiet = alert_ctrl en gate.
// 0 = quiet is mute, the 10-27 behaviour bit for bit.
//---------------------------------------------------------------------------
module spot_seq #(
    parameter integer CLK_HZ  = 150_000_000,
    parameter integer FLASH_N = 3,
    parameter integer ON_MS   = 200,
    parameter integer OFF_MS  = 200,
    parameter integer QUIET_S = 30,
    parameter integer CHAL_LIT = 0,
    parameter integer STAFF_DARK = 0,
    parameter integer PASS_DARK_MS = 0
)(
    input      clk,
    input      rst_n,
    input      en,
    input      spot_in,         // alert_ctrl spot_en
    input      chal,            // staff_ctrl state: mouth / blink challenge
    input      near,            // staff_ctrl state: NEAR (recognised, not close yet)
    input      prompt,          // one clock: the challenge prompt starts playing
    input      pass,            // staff_ctrl pass
    output     spot_out,
    output     quiet,           // alert_ctrl off (PASS_DARK_MS: < PASS_DARK_MS ms since the pass)
    output     mute             // alarm voice held: pass, or < QUIET_S s since it fell
);
localparam integer TICK = CLK_HZ / 1000;
reg [17:0] pre;
reg [3:0]  ph;                  // flash phase, counts down: odd = lit
reg [15:0] ph_ms;
reg        flashing, dark;
reg [16:0] q_ms;                // QUIET_S <= 131 s
reg [16:0] pd_ms;               // PASS_DARK_MS left
reg        pass_d;
wire       pass_rise = pass && !pass_d;
wire ms = (pre == TICK - 1);
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        pre <= 18'd0; ph <= 4'd0; ph_ms <= 16'd0; flashing <= 1'b0; dark <= 1'b0;
        q_ms <= 17'd0; pd_ms <= 17'd0; pass_d <= 1'b0;
    end else begin
        pre <= ms ? 18'd0 : pre + 18'd1;
        pass_d <= pass;
        if (!en) begin
            flashing <= 1'b0; dark <= 1'b0; q_ms <= 17'd0; pd_ms <= 17'd0;
        end else begin
            // flash: 2*FLASH_N phases, lit first
            if (!chal) begin
                flashing <= 1'b0; dark <= 1'b0;
            end else if (prompt && !flashing && !dark) begin
                flashing <= 1'b1; ph <= 2*FLASH_N - 1; ph_ms <= ON_MS - 1;
            end else if (flashing && ms) begin
                if (ph_ms != 16'd0) ph_ms <= ph_ms - 16'd1;
                else if (ph == 4'd0) begin flashing <= 1'b0; dark <= 1'b1; end
                else begin ph <= ph - 4'd1; ph_ms <= ph[0] ? OFF_MS - 1 : ON_MS - 1; end
            end
            // quiet after a pass
            if (pass)                       q_ms <= QUIET_S * 1000;
            else if (ms && q_ms != 17'd0)   q_ms <= q_ms - 17'd1;
            if (pass_rise)                  pd_ms <= PASS_DARK_MS;
            else if (ms && pd_ms != 17'd0)  pd_ms <= pd_ms - 17'd1;
        end
    end
end
assign spot_out = (en && flashing) ? ph[0] :
                  (en && STAFF_DARK != 0 && (chal || near)) ? 1'b0 :
                  (en && chal && dark) ? (CHAL_LIT != 0) : spot_in;
assign mute     = pass || (en && q_ms != 17'd0);
assign quiet    = (PASS_DARK_MS != 0) ? (en && (pass_rise || pd_ms != 17'd0)) : mute;
endmodule
