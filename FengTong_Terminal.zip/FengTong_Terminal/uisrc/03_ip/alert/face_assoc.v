//---------------------------------------------------------------------------
// face_assoc -- "is the thing that moves a person?"  2026-10-05 evening.
//
// Security mode runs the motion tracker (magenta box) and the face detector
// (red boxes) side by side.  Once per frame (vs rising edge) this looks for a
// face whose CENTRE lies inside the tracker box grown by a margin:
//
//          MY_UP above  (the box is often the moving arm / torso, the head
//                        sits above it)
//   MX  |  tracker box  |  MX
//          MY_DN below
//
//   person  = such a face exists this frame         -> alert_ctrl confirms
//   fx, fy  = its centre (lowest index wins)         -> spotlight aim
//
// use_box = 0 (MULTI view: several green boxes, no single tracker box) drops
// the geometry and accepts any valid face.
//
// Why associate at all instead of "any face while something moves": a static
// false face (a poster, the odd ear/hand box) plus unrelated motion elsewhere
// would otherwise confirm, and the spotlight would be aimed at the poster.
//
// Registered on the frame edge so both readers (alert_ctrl, the aim mux) see
// one decision per frame; the inputs are themselves per-frame latched boxes.
//
// PERSON_HOLD (10-06): person stays up this many frames after the last hit,
// fx/fy frozen at the last face.  The 10-05 night board run showed the red
// box dropping out for a handful of frames at a time; with person feeding the
// spotlight directly that was a STROBE (and every lamp edge also blanks the
// motion detector for 4 frames via light_inhibit), and the aim jumped
// face -> hand -> face.  0 = no hold, the 10-05 behaviour bit for bit.
//---------------------------------------------------------------------------
module face_assoc #(
    parameter integer NROI  = 4,
    parameter [11:0]  MX    = 12'd128,    // one motion block
    parameter [11:0]  MY_UP = 12'd216,    // three block rows
    parameter [11:0]  MY_DN = 12'd72,
    parameter [7:0]   PERSON_HOLD = 8'd0
)(
    input                  clk,
    input                  rst_n,
    input                  vs,
    input                  en,
    input                  use_box,
    input                  box_v,
    input      [11:0]      bx0, bx1, by0, by1,
    input  [NROI*12-1:0]   fx0, fx1, fy0, fy1,
    input  [NROI-1:0]      f_vld,
    output reg             person,
    output reg [11:0]      fx,
    output reg [11:0]      fy
);

// grown box, clamped at 0 (no upper clamp needed: centres are < 2048)
wire [11:0] gx0 = (bx0 > MX)    ? bx0 - MX    : 12'd0;
wire [11:0] gy0 = (by0 > MY_UP) ? by0 - MY_UP : 12'd0;
wire [12:0] gx1 = {1'b0, bx1} + MX;
wire [12:0] gy1 = {1'b0, by1} + MY_DN;

reg         hit;
reg  [11:0] hx, hy;
reg  [12:0] cx, cy;
integer i;
always @* begin
    hit = 1'b0; hx = 12'd0; hy = 12'd0;
    for (i = NROI - 1; i >= 0; i = i - 1) begin
        cx = ({1'b0, fx0[i*12 +: 12]} + {1'b0, fx1[i*12 +: 12]}) >> 1;
        cy = ({1'b0, fy0[i*12 +: 12]} + {1'b0, fy1[i*12 +: 12]}) >> 1;
        if (f_vld[i] && (!use_box ||
            (box_v && cx >= {1'b0, gx0} && cx <= gx1
                   && cy >= {1'b0, gy0} && cy <= gy1))) begin
            hit = 1'b1; hx = cx[11:0]; hy = cy[11:0];
        end
    end
end

reg       vs_q;
reg [7:0] hold;
always @(posedge clk or negedge rst_n)
    if (!rst_n) begin
        vs_q <= 1'b0; person <= 1'b0; fx <= 12'd0; fy <= 12'd0; hold <= 8'd0;
    end else begin
        vs_q <= vs;
        if (!en) begin
            person <= 1'b0;
            hold   <= 8'd0;
        end else if (vs && !vs_q) begin
            if (hit) begin
                person <= 1'b1;
                hold   <= PERSON_HOLD;
                fx <= hx; fy <= hy;
            end else if (hold != 8'd0) begin
                person <= 1'b1;
                hold   <= hold - 8'd1;
            end else
                person <= 1'b0;
        end
    end

endmodule
