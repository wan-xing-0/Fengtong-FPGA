//---------------------------------------------------------------------------
// light_meter -- "the room is too dark" -> fill light on.  2026-10-05.
//
// Metric: sig = (mean G of the frame) - lo, both measured at the auto-level
// INPUT (w_rgb_*, linear), lo = isp_auto_level's black point (osd_lo_g).
//
//   * the input, not the output: exposure and gain are fixed (no AE), so the
//     mean there is linear in scene illuminance; auto-level and gamma
//     downstream would stretch a dark frame back up and hide it.
//   * minus lo, because the sensor pedestal (~16 codes) is in that mean and a
//     pitch-black room still reads ~16: a bare threshold would be tuning the
//     pedestal, not the light.  sig is "signal above the black point".
//
// THE LOOP PROBLEM.  The light itself brightens the frame, so "sig > TH ->
// off" would turn it straight back off and it would oscillate.  So:
//   OFF    : sig < ON_TH for DARK_FR frames            -> remember, ON
//   SETTLE : wait SETTLE_FR frames (light + auto-level settle),
//            delta = sig - sig_dark  = the light's own contribution
//   ON     : ambient = sig - delta; off when it exceeds ON_TH + HYST for
//            BRIGHT_FR frames (and MIN_ON_FR has passed)
// After switching off it waits MIN_OFF_FR frames before it may switch on
// again.  BRIGHT_FR is long (4 s) on purpose: a white shirt walking in front
// of the lamp raises sig by more than the room light coming back would, and
// only a sustained rise should end the fill light.
//
// A frame is only accepted if it carried > MIN_PIX pixels, so a wrong vs
// polarity or a truncated frame is ignored instead of read as "black".
//---------------------------------------------------------------------------
module light_meter #(
    parameter [7:0]  ON_TH      = 8'd12,
    parameter [7:0]  HYST       = 8'd10,
    parameter [7:0]  DARK_FR    = 8'd30,    // ~0.5 s
    parameter [7:0]  BRIGHT_FR  = 8'd240,   // ~4 s
    parameter [7:0]  SETTLE_FR  = 8'd20,
    parameter [11:0] MIN_ON_FR  = 12'd300,  // ~5 s
    parameter [11:0] MIN_OFF_FR = 12'd120,  // ~2 s
    parameter        SUM_SHIFT  = 21,       // 1920*1080 ~ 2^21
    parameter [31:0] MIN_PIX    = 32'd1048576
)(
    input            clk,
    input            rst_n,
    input            en,
    input            in_vs,          // HIGH across the visible frame
    input            in_de,
    input      [7:0] in_g,
    input      [7:0] lo,             // auto-level black point (G)
    output reg       light_on,
    output reg [7:0] mean,           // last accepted frame's mean G
    output reg [7:0] sig,            // mean - lo
    output reg [7:0] ambient         // sig - learned light contribution
);

//------------------------------------------------------------- frame mean
reg  [31:0] sum, cnt;
reg         vs_d;
reg         fstb;                    // one clock: a new mean is valid
wire [31:0] mean_full = sum >> SUM_SHIFT;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        sum <= 0; cnt <= 0; vs_d <= 1'b0; fstb <= 1'b0; mean <= 8'd0;
    end else begin
        vs_d <= in_vs;
        fstb <= 1'b0;
        if (vs_d && !in_vs) begin                 // end of frame
            if (cnt > MIN_PIX) begin
                mean <= (mean_full > 255) ? 8'd255 : mean_full[7:0];
                fstb <= 1'b1;
            end
            sum <= 0; cnt <= 0;
        end else if (in_vs && in_de) begin
            sum <= sum + in_g;
            cnt <= cnt + 1;
        end
    end
end

wire [7:0] sig_w = (mean > lo) ? (mean - lo) : 8'd0;

//------------------------------------------------------------- control
localparam S_OFF = 2'd0, S_SETTLE = 2'd1, S_ON = 2'd2;
reg [1:0]  st;
reg [7:0]  s_dark, delta, run;
reg [11:0] age;                      // frames in the current state

wire [8:0] amb_w = {1'b0, sig_w} - {1'b0, delta};
wire [7:0] amb   = amb_w[8] ? 8'd0 : amb_w[7:0];
wire [8:0] off_th = {1'b0, ON_TH} + HYST;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        st <= S_OFF; light_on <= 1'b0; s_dark <= 0; delta <= 0;
        run <= 0; age <= MIN_OFF_FR; ambient <= 0; sig <= 0;
    end else if (!en) begin
        st <= S_OFF; light_on <= 1'b0; delta <= 0; run <= 0;
        age <= MIN_OFF_FR;            // may switch on as soon as re-enabled
    end else if (fstb) begin
        if (age != 12'hfff) age <= age + 12'd1;
        sig     <= sig_w;
        ambient <= (st == S_OFF) ? sig_w : amb;
        case (st)
        S_OFF: begin
            run <= (sig_w < ON_TH) ? ((run == 8'hff) ? run : run + 8'd1) : 8'd0;
            if (sig_w < ON_TH && run + 8'd1 >= DARK_FR && age >= MIN_OFF_FR) begin
                st <= S_SETTLE; light_on <= 1'b1; s_dark <= sig_w;
                run <= 0; age <= 0;
            end
        end
        S_SETTLE: begin
            if (age + 12'd1 >= SETTLE_FR) begin
                delta <= (sig_w > s_dark) ? sig_w - s_dark : 8'd0;
                st <= S_ON; run <= 0;
            end
        end
        default: begin   // S_ON
            run <= ({1'b0, amb} > off_th) ? ((run == 8'hff) ? run : run + 8'd1) : 8'd0;
            if ({1'b0, amb} > off_th && run + 8'd1 >= BRIGHT_FR && age >= MIN_ON_FR) begin
                st <= S_OFF; light_on <= 1'b0; delta <= 0;
                run <= 0; age <= 0;
            end
        end
        endcase
    end
end

endmodule
