//---------------------------------------------------------------------------
// light_inhibit -- blind the motion detector around a lamp edge.  2026-10-05.
//
// A lamp switching on or off steps the picture's brightness.  Frame
// differencing reads a step as motion: a fill light turning on would draw
// boxes (and the boxes would wake the spotlight and the voice), and the
// spotlight turning off would leave a "ghost" where its beam fell on the wall
// and re-trigger the alarm that just ended -- a self-sustaining loop.
//
// motion_frame_drawer already has the right input for this: md_inhibit
// blinds the frame AND re-seeds the IIR background (so the step is absorbed
// in ~3 frames instead of forgotten over 16).  This block drives it.
//
//   chg   : any change on a watched lamp output (one clock, from the caller)
//   vs    : the detector's own vs (cr_out_vs); only its rising edge is used
//
// The output is a REGISTER THAT CHANGES ONLY ON vs's RISING EDGE, i.e. stable
// across a frame, the same convention servo_pantilt's md_inhibit follows.
// Held for N consecutive frames starting with the first frame boundary after
// the change; a second change during the hold restarts the count.
//---------------------------------------------------------------------------
module light_inhibit #(
    parameter [7:0] N = 8'd8
)(
    input      clk,
    input      rst_n,
    input      vs,
    input      chg,
    output reg inhibit
);

reg       vs_d, pend;
reg [7:0] cnt;
wire      vs_rise = vs && !vs_d;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        vs_d <= 1'b0; pend <= 1'b0; cnt <= 8'd0; inhibit <= 1'b0;
    end else begin
        vs_d <= vs;
        if (chg) pend <= 1'b1;
        if (vs_rise) begin
            if (pend || chg) begin
                pend    <= 1'b0;
                cnt     <= N;
                inhibit <= (N != 8'd0);
            end else if (cnt != 8'd0) begin
                cnt     <= cnt - 8'd1;
                inhibit <= (cnt != 8'd1);
            end else
                inhibit <= 1'b0;
        end
    end
end

endmodule
