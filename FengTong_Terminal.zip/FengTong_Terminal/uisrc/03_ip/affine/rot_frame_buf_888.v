//---------------------------------------------------------------------------
// rot_frame_buf_888 -- 90/270 degree rotation and 2x zoom of a centre window,
// on-chip.
//
// Ported from the competition project's rot_frame_buffer (RGB565, 720p).
//
// HOW IT AVOIDS A FRAME STORE
//   A true frame rotation needs random access to the frame buffer, which this
//   board does not have: uidbuf hands out DDR3 in fixed raster order and there
//   is no read-address hook.  The trick the source project used, and the only
//   reason this transform is portable at all, is to rotate a *window* inside
//   block RAM instead.  A CENTER_W x CENTER_H square at the middle of the
//   screen is decimated 2:1 into a 256x256 grid, and the read address is the
//   transpose of the write address.  Everything outside the window is passed
//   through untouched by the parent.
//
//   Only shifts are used for the decimation, so there is no multiplier and no
//   DSP -- the source learned that the hard way.  An earlier revision let a
//   102x18 multiply infer a DSP, and the placement shift that caused pushed
//   the real critical path onto the HDMI outputs, putting chroma noise on the
//   picture in every mode, rotation or not.
//
// 2026-08-10: ZOOM RIDES ON THE SAME TWO BANKS
//   The bench test asked for the source project's zoom modes back.  Full-frame
//   zoom is still impossible here and always will be without a second frame
//   store -- 2x magnification wants source line 270 on output line 0, and at
//   output line 0 source line 270 has not been received yet.  The source got
//   away with it by re-ordering SDRAM reads; uidbuf has no such hook.
//
//   The window buffer, though, is already double-buffered and already reads
//   the PREVIOUS frame, so inside the window the causality problem does not
//   exist.  Scaling it costs exactly one thing: a different read address.  No
//   extra RAM, no extra clock, no DSP.
//
//     XF_ZOOMIN   grid = (local >> 2) + 64
//                 the middle 256x256 of the window fills all 512x512, i.e.
//                 2x magnification of the original pixels
//     XF_ZOOMOUT  grid = local - 128, valid for local in [128, 384)
//                 the whole window shrinks into the middle 256x256 and the
//                 surrounding ring is blanked, so it reads as "smaller"
//                 rather than as a crop
//
//     XF_ROT180   grid = (255-u_b, 255-v_b).  Full-frame 180 is impossible --
//                 it wants the lines in reverse order -- but inside a bank
//                 that is already holding a whole finished frame, reading it
//                 backwards is just another address.  Free.
//     XF_ZOOM4X   grid = (local >> 4) + 96, one octave above XF_ZOOMIN.
//
// 2026-08-10: THE WINDOW IS NOW 1024x1024, AND IT COST NOTHING
//   The bench asked for the transform to cover the screen, with black around
//   whatever could not be covered.  Covering it outright is impossible and
//   always will be: the transpose has to read the whole square back in a
//   different order, so the square has to be stored, and it has to be stored
//   twice (single buffering puts a diagonal tear across the picture -- see
//   PING-PONG below).  A full 1080x1080 at full resolution is 28 Mbit per
//   bank.  There is no arrangement of this part that holds it.
//
//   What is free is the decimation.  At a fixed 2 x 65536 x 24 bit budget the
//   window size and the sharpness inside it trade off exactly one for one:
//
//       decimation   window        cell on screen   eram
//       2:1          512 x 512     2 x 2 px         160   (until now)
//       3:1          768 x 768     3 x 3 px         160
//       4:1         1024 x 1024    4 x 4 px         160   (this version)
//
//   1024x1024 is as close to the ceiling as the ceiling is worth chasing: a
//   90-degree rotation can only ever act on a square, the largest square that
//   fits 1080p is 1080x1080, and 1024 leaves a 28-pixel band top and bottom
//   that is black anyway now.  Horizontally it leaves 448 px each side, which
//   is inherent -- rotating a 1920-wide region by 90 degrees would need a
//   1920-tall screen.
//
//   The cost is real and worth stating: everything inside the window is now
//   a 256x256 image stretched over 1024x1024, so it is four screen pixels per
//   sample instead of two.  Buying that back means buying RAM.  Roughly
//   +50..90 eram gets a 360x360 grid at 3:1 over the full 1080 height, at the
//   price of a shift-add on the block RAM address path (360 is not a power of
//   two, so {v_b, u_b} stops being a concatenation) and a timing re-check.
//
// WHAT CHANGED IN THE PORT
//   * RGB888 instead of RGB565.
//   * 1080p geometry: X_OFFSET (1920-1024)/2 = 448, Y_OFFSET (1080-1024)/2 = 28.
//   * Coordinates are 12-bit.  The original carried wr_y as 10 bits, which
//     tops out at 1023 -- at 1080p that would wrap 56 lines from the bottom of
//     every frame and fold them back over the top of the window.
//   * PING-PONG.  The original wrote and read a single buffer in the same
//     pass.  At screen row v_b it reads grid row 255-u_b, so over roughly half
//     the window the cell being read has not been written yet this frame and
//     still holds the previous one -- a diagonal seam across the rotated
//     square, worst on motion.  Two banks remove it outright: the frame being
//     written is never the frame being read.  The cost is a second 65536x24
//     array, and with 76 of 646 ERAM20K in use there is room.
//
// LATENCY
//   3 clocks from (px, py, pix_in) to (rot_data, rot_inside):
//     T   combinational coords, window test, both addresses
//     T+1 registered into the RAM address/data/we inputs
//     T+2 RAM output register
//     T+3 second output register
//   The parent must delay everything else by the same 3.
//
// The RAM arrays and their output registers deliberately have no reset --
// that is what keeps them inferrable as block RAM on this part.
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module rot_frame_buf_888 #(
parameter integer CENTER_W = 1024,    // window width on screen (pinned by the 10-bit locals)
parameter integer CENTER_H = 1024,    // window height on screen
parameter integer X_OFFSET = 448,     // (1920 - 1024) / 2
parameter integer Y_OFFSET = 28       // (1080 - 1024) / 2
)(
input  wire        clk,
input  wire        rst_n,

input  wire [11:0] px,          // screen x of the pixel on pix_in this cycle
input  wire [11:0] py,          // screen y
input  wire        pix_valid,   // de
input  wire [23:0] pix_in,      // {R,G,B}

input  wire        rot_en,      // high in any of the six window modes
input  wire [2:0]  xform,       // which one -- see XF_* below
input  wire        frame_tick,  // one pulse per frame, during blanking

output wire [23:0] rot_data,    // valid 3 clocks after px/py
output wire        rot_inside   // 3 clocks after; high inside the window
);

localparam [2:0] XF_ROT90   = 3'd0;
localparam [2:0] XF_ROT270  = 3'd1;
localparam [2:0] XF_ZOOMIN  = 3'd2;
localparam [2:0] XF_ZOOMOUT = 3'd3;
localparam [2:0] XF_ROT180  = 3'd4;   // point reflection, not a transpose
localparam [2:0] XF_ZOOM4X  = 3'd5;
localparam [2:0] XF_ZOUT4X  = 3'd6;

//-------------------------------------------------------------------
// T0 : where are we, and is it inside the window
//-------------------------------------------------------------------
wire signed [12:0] u_s = $signed({1'b0, px}) - X_OFFSET;
wire signed [12:0] v_s = $signed({1'b0, py}) - Y_OFFSET;

wire in_center_c = (u_s >= 0) && (u_s < CENTER_W)
                && (v_s >= 0) && (v_s < CENTER_H);

// 10 bits of local coordinate is what pins CENTER_* at 1024, and the 8-bit
// grid index below is what pins the grid at 256.  Changing the window size
// means changing all three plus the 8'd255 reflection constant.
wire [9:0] u_local = u_s[9:0];
wire [9:0] v_local = v_s[9:0];

wire [7:0] u_b = u_local[9:2];   // 4:1 decimation, shift only
wire [7:0] v_b = v_local[9:2];

// Transpose.  90 sends (u,v) -> (v, 255-u); 270 is the other handedness.
wire [7:0] rot90_u  = v_b;
wire [7:0] rot90_v  = 8'd255 - u_b;
wire [7:0] rot270_u = 8'd255 - v_b;
wire [7:0] rot270_v = u_b;

// Zoom in: read the middle quarter of the grid over the whole window.
//   source local = u_local/2 + CENTER_W/4, grid = source local / 4
//                = u_local[9:3] + 64
wire [7:0] zi_u = {1'b0, u_local[9:3]} + 8'd64;
wire [7:0] zi_v = {1'b0, v_local[9:3]} + 8'd64;

// Zoom in 4x: same idea one octave up, grid = u_local[9:4] + 96.
wire [7:0] z4_u = {2'b0, u_local[9:4]} + 8'd96;
wire [7:0] z4_v = {2'b0, v_local[9:4]} + 8'd96;

// Zoom out: the whole grid lands in the middle quarter of the window.
//   source local = 2*u_local - CENTER_W/2, grid = source local / 4
//                = (u_local - 256) >> 1,  valid for u_local in [256, 768)
wire [9:0] zo_u10 = (u_local - 10'd256) >> 1;
wire [9:0] zo_v10 = (v_local - 10'd256) >> 1;
wire       zo_ok  = (u_local >= 10'd256) && (u_local < 10'd768)
                 && (v_local >= 10'd256) && (v_local < 10'd768);

// Zoom out 4x: the whole grid lands in the middle SIXTEENTH of the window.
//   source local = 4*(u_local - 384), grid = source local / 4 = u_local - 384
//   valid for u_local in [384, 640), which is 256 px centred on 512
wire [9:0] zo4_u10 = u_local - 10'd384;
wire [9:0] zo4_v10 = v_local - 10'd384;
wire       zo4_ok  = (u_local >= 10'd384) && (u_local < 10'd640)
                  && (v_local >= 10'd384) && (v_local < 10'd640);

wire [7:0] u_src = (xform == XF_ROT90)  ? rot90_u        :
                   (xform == XF_ROT270) ? rot270_u       :
                   (xform == XF_ROT180) ? (8'd255 - u_b) :
                   (xform == XF_ZOOMIN) ? zi_u           :
                   (xform == XF_ZOOM4X) ? z4_u           :
                   (xform == XF_ZOUT4X) ? zo4_u10[7:0]   : zo_u10[7:0];
wire [7:0] v_src = (xform == XF_ROT90)  ? rot90_v        :
                   (xform == XF_ROT270) ? rot270_v       :
                   (xform == XF_ROT180) ? (8'd255 - v_b) :
                   (xform == XF_ZOOMIN) ? zi_v           :
                   (xform == XF_ZOOM4X) ? z4_v           :
                   (xform == XF_ZOUT4X) ? zo4_v10[7:0]   : zo_v10[7:0];

// Inside the window but outside the shrunk picture: paint it black rather
// than leak the un-scaled surroundings through the middle of the effect.
wire blank_c = ((xform == XF_ZOOMOUT) && !zo_ok)
            || ((xform == XF_ZOUT4X) && !zo4_ok);

wire [15:0] wr_addr_c = {v_b,   u_b  };
wire [15:0] rd_addr_c = {v_src, u_src};
wire        wr_en_c   = pix_valid && in_center_c && rot_en;

//-------------------------------------------------------------------
// Bank select.  Write this frame's window into one bank while reading last
// frame's out of the other, and swap between frames.
//-------------------------------------------------------------------
reg bank;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n)           bank <= 1'b0;
    else if (frame_tick)  bank <= ~bank;
end

//-------------------------------------------------------------------
// T1 : everything the RAM sees comes out of a flop, so the RAM inputs get
// short dedicated routes and never see a combinational glitch.  Outside the
// window modes the write strobe is forced low and the address/data flops are
// left holding, which keeps the arrays quiet.
//-------------------------------------------------------------------
reg [15:0] wr_addr_r, rd_addr_r;
reg [23:0] wr_data_r;
reg        we_r;
reg        in_center_d1, blank_d1;
reg        wr_bank_d1, rd_bank_d1;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        wr_addr_r    <= 16'd0;
        rd_addr_r    <= 16'd0;
        wr_data_r    <= 24'd0;
        we_r         <= 1'b0;
        in_center_d1 <= 1'b0;
        blank_d1     <= 1'b0;
        wr_bank_d1   <= 1'b0;
        rd_bank_d1   <= 1'b1;
    end else if (rot_en) begin
        wr_addr_r    <= wr_addr_c;
        rd_addr_r    <= rd_addr_c;
        wr_data_r    <= pix_in;
        we_r         <= wr_en_c;
        in_center_d1 <= in_center_c;
        blank_d1     <= blank_c;
        wr_bank_d1   <=  bank;
        rd_bank_d1   <= ~bank;
    end else begin
        we_r         <= 1'b0;
        in_center_d1 <= 1'b0;
        blank_d1     <= 1'b0;
    end
end

wire we_a = we_r & ~wr_bank_d1;
wire we_b = we_r &  wr_bank_d1;

//-------------------------------------------------------------------
// The two banks.  Nothing in here is reset, on purpose.
//-------------------------------------------------------------------
reg [23:0] mem_a [0:65535];
reg [23:0] mem_b [0:65535];

reg [23:0] qa1, qa2;
reg [23:0] qb1, qb2;

always @(posedge clk) begin
    if (we_a) mem_a[wr_addr_r] <= wr_data_r;
    qa1 <= mem_a[rd_addr_r];
    qa2 <= qa1;
end

always @(posedge clk) begin
    if (we_b) mem_b[wr_addr_r] <= wr_data_r;
    qb1 <= mem_b[rd_addr_r];
    qb2 <= qb1;
end

//-------------------------------------------------------------------
// Carry the window flag, the blanking flag and the read-bank select
// alongside the data
//-------------------------------------------------------------------
reg in_center_d2, in_center_d3;
reg blank_d2,     blank_d3;
reg rd_bank_d2,   rd_bank_d3;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        in_center_d2 <= 1'b0; in_center_d3 <= 1'b0;
        blank_d2     <= 1'b0; blank_d3     <= 1'b0;
        rd_bank_d2   <= 1'b1; rd_bank_d3   <= 1'b1;
    end else begin
        in_center_d2 <= in_center_d1; in_center_d3 <= in_center_d2;
        blank_d2     <= blank_d1;     blank_d3     <= blank_d2;
        rd_bank_d2   <= rd_bank_d1;   rd_bank_d3   <= rd_bank_d2;
    end
end

wire [23:0] bank_q = rd_bank_d3 ? qb2 : qa2;

assign rot_data   = blank_d3 ? 24'd0 : bank_q;
assign rot_inside = in_center_d3;

endmodule
