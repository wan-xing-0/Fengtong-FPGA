//---------------------------------------------------------------------------
// affine_transform -- one button, eight geometric modes on RGB888.
//
// Ported from the competition project's affine_transform (RGB565, 1280x720,
// behind an SDRAM frame store with a controllable read address).
//
// WHAT SURVIVED THE PORT, AND WHAT COULD NOT
//   The source cycled twelve modes.  Five of them worked by driving
//   sdram_rd_mode, which told the SDRAM reader to fetch lines in a different
//   order (source affine_transform.v:142-151).  This board has no such hook:
//   uidbuf streams DDR3 out in fixed raster order, one line after another, and
//   there is nothing to redirect.  Worse, those modes are not merely awkward
//   here, they are non-causal -- full-frame 2x zoom wants source line 270 on
//   output line 0, and source line 270 has not arrived yet.
//
//   The first port took four modes.  2026-08-10 added three more and traded
//   the fourth kind of scaling for a window-local one, after the bench test
//   asked for "the old zoom and shear as well":
//
//     free           SHEAR_R, SHEAR_L -- pure x remaps, so the line buffer
//                    HMIRROR already runs answers them by changing one
//                    address.  Zero new RAM.
//     window-local   ZOOM_IN, ZOOM_OUT -- the 512x512 rotate buffer is
//                    already double-buffered and already reads the previous
//                    frame, so scaling inside it IS causal.  Zero new RAM.
//                    Full-frame scaling still is not possible; see
//                    rot_frame_buf_888.
//     still dropped  ROT180 (needs the lines in reverse order), TRANSLATE
//                    (would fit, but eight positions is already as much as
//                    one hand wants to cycle through).
//
// MODES -- eleven positions, so the counter wraps on a compare, not on carry
//   0 BYPASS   untouched
//   1 ROT90    centre 1024x1024 window turned 90 degrees, rest of frame black
//   2 ROT180   window turned upside down
//   3 ROT270   the other handedness
//   4 HMIRROR  whole frame mirrored left to right
//   5 SHEAR_R  whole frame skewed, top left / bottom right
//   6 SHEAR_L  the other lean
//   7 ZOOM_IN  window magnified 2x
//   8 ZOOM_4X  window magnified 4x
//   9 ZOOM_OUT window shrunk 2x onto a black field
//  10 ZOUT_4X  window shrunk 4x, so the zoom set is symmetric: 4x 2x 1x /2 /4
//
//   ROT180, ZOOM_4X and ZOUT_4X joined on 2026-08-10.  All three are read-
//   address changes on the window buffer and cost no RAM, no multiplier and
//   no clock: 180 is a point reflection of a bank that already holds a
//   finished frame, and each zoom step is one more shift place.  That takes
//   the port to 11 of the source project's 12; the one absent is full-frame
//   zoom, which needs a real frame store (see rot_frame_buf_888).
//
// THE WINDOW, AND WHY IT IS NOT THE WHOLE SCREEN
//   The four window modes act on a 1024x1024 square in the middle of the
//   frame and paint everything outside it black (2026-08-10; it was 512x512
//   with the picture showing through around it).  1024 is not an arbitrary
//   compromise: a 90-degree rotation can only act on a square, the largest
//   square inside 1080p is 1080x1080, and the extra 56 lines would cost block
//   RAM that 4:1 decimation gets for free.  See rot_frame_buf_888 for the
//   window-size / sharpness trade and what it would cost to go further.
//
//   HMIRROR and the two shears are unaffected -- they need only the line
//   already in hand, so they have always covered the whole frame.
//
// SHEAR GEOMETRY
//   Read x is displaced by (py - 540) >> 1, so +-270 pixels top to bottom.
//   That is the source's (wr_y - 360) >> 1 kept at the same fraction of the
//   picture: 270/1920 and 180/1280 are both 14%.  Past the edge of the line
//   there is nothing to read, so those pixels go black -- the same way the
//   source blanked them.
//
// COORDINATES
//   There is no disp_x/disp_y anywhere in this design; the video interface is
//   de/vs only.  px/py are rebuilt here with the same eight lines hist_osd
//   already runs on silicon: vs low re-zeroes, de counts x, the falling edge
//   of de counts y.  px/py are valid in the same cycle as the pixel they
//   describe.
//
// LATENCY
//   AFFINE_SYNC_DLY = 4: three clocks through either RAM, one more for the
//   output mux.  BYPASS is delayed by the same four, so what the wheel
//   downstream sees does not shift when the mode changes.
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module affine_transform #(
parameter integer IMG_HDISP = 1920,
parameter integer IMG_VDISP = 1080,
parameter integer CENTER_W  = 1024,
parameter integer CENTER_H  = 1024,
parameter integer KEY_MCNT  = 3_000_000   // 20 ms at the 150 MHz pixel clock
)(
input  wire        clk,
input  wire        rst_n,
input  wire        mode_key,     // raw button, debounced in here
// 10-20 (user): QC mode (BOX) has no use for the affine -- its boxes must be
// measured on the real picture -- so there it is forced to BYPASS from the
// next frame, presses do not advance it, and the key is lent out: key_press
// is the debounced press, one clock, whatever bypass is (system_top cycles
// qc_std's mode with it).  The selected mode is kept and comes back when
// bypass drops.  Tie bypass 0 for the old behaviour.
input  wire        bypass,
output wire        key_press,

input  wire        in_hs,
input  wire        in_vs,        // HIGH across the visible frame
input  wire        in_de,
input  wire [7:0]  in_r,
input  wire [7:0]  in_g,
input  wire [7:0]  in_b,

output wire        out_hs,
output wire        out_vs,
output wire        out_de,
output wire [7:0]  out_r,
output wire [7:0]  out_g,
output wire [7:0]  out_b,

output wire [3:0]  affine_mode
);

localparam [3:0] MODE_BYPASS  = 4'd0;
localparam [3:0] MODE_ROT90   = 4'd1;
localparam [3:0] MODE_ROT180  = 4'd2;
localparam [3:0] MODE_ROT270  = 4'd3;
localparam [3:0] MODE_HMIRROR = 4'd4;
localparam [3:0] MODE_SHEAR_R = 4'd5;
localparam [3:0] MODE_SHEAR_L = 4'd6;
localparam [3:0] MODE_ZOOMIN  = 4'd7;
localparam [3:0] MODE_ZOOM4X  = 4'd8;
localparam [3:0] MODE_ZOOMOUT = 4'd9;
localparam [3:0] MODE_ZOUT4X  = 4'd10;
localparam [3:0] MODE_LAST    = 4'd10;  // wrap point; 11 is not a power of two

// rot_frame_buf_888's xform encoding
localparam [2:0] XF_ROT90   = 3'd0;
localparam [2:0] XF_ROT270  = 3'd1;
localparam [2:0] XF_ZOOMIN  = 3'd2;
localparam [2:0] XF_ZOOMOUT = 3'd3;
localparam [2:0] XF_ROT180  = 3'd4;
localparam [2:0] XF_ZOOM4X  = 3'd5;
localparam [2:0] XF_ZOUT4X  = 3'd6;

localparam integer AFFINE_SYNC_DLY = 4;
localparam integer X_OFFSET = (IMG_HDISP - CENTER_W) / 2;   // 704
localparam integer Y_OFFSET = (IMG_VDISP - CENTER_H) / 2;   // 284
localparam integer V_CENTRE = IMG_VDISP / 2;                // 540

wire [23:0] pix_in = {in_r, in_g, in_b};

//-------------------------------------------------------------------
// Mode select, latched between frames
//-------------------------------------------------------------------
wire key_p_flag;

key_filter #(
    .MCNT (KEY_MCNT - 1)
) u_key_filter (
    .Clk        (clk       ),
    .Reset_n    (rst_n     ),
    .Key        (mode_key  ),
    .Key_P_Flag (key_p_flag),
    .Key_R_Flag (          ),
    .Key_state  (          )
);

reg [3:0] mode_sel;
reg [3:0] mode_active;
reg       in_vs_d1;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n)
        mode_sel <= MODE_BYPASS;
    else if (key_p_flag && !bypass)
        mode_sel <= (mode_sel == MODE_LAST) ? MODE_BYPASS : (mode_sel + 4'd1);
end

wire frame_tick = in_vs_d1 & ~in_vs;    // falling edge = start of blanking

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        in_vs_d1    <= 1'b0;
        mode_active <= MODE_BYPASS;
    end else begin
        in_vs_d1 <= in_vs;
        if (frame_tick)
            mode_active <= bypass ? MODE_BYPASS : mode_sel;
    end
end

assign affine_mode = mode_active;
assign key_press   = key_p_flag;

// Which of the two datapaths this mode uses.
wire rot_en = (mode_active == MODE_ROT90)  || (mode_active == MODE_ROT180)
           || (mode_active == MODE_ROT270) || (mode_active == MODE_ZOOMIN)
           || (mode_active == MODE_ZOOM4X) || (mode_active == MODE_ZOOMOUT)
           || (mode_active == MODE_ZOUT4X);

wire lb_en  = (mode_active == MODE_HMIRROR)
           || (mode_active == MODE_SHEAR_R) || (mode_active == MODE_SHEAR_L);

wire [2:0] rot_xform = (mode_active == MODE_ROT90)  ? XF_ROT90  :
                       (mode_active == MODE_ROT180) ? XF_ROT180 :
                       (mode_active == MODE_ROT270) ? XF_ROT270 :
                       (mode_active == MODE_ZOOMIN) ? XF_ZOOMIN :
                       (mode_active == MODE_ZOOM4X) ? XF_ZOOM4X :
                       (mode_active == MODE_ZOOMOUT) ? XF_ZOOMOUT : XF_ZOUT4X;

//-------------------------------------------------------------------
// Screen coordinates, rebuilt from de/vs (same shape as hist_osd)
//-------------------------------------------------------------------
reg [11:0] px, py;
reg        de_prev;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        px <= 12'd0; py <= 12'd0; de_prev <= 1'b0;
    end else begin
        de_prev <= in_de;
        if (!in_vs) begin
            // vs is low only during the sync pulse, deep in blanking
            px <= 12'd0;
            py <= 12'd0;
        end else if (in_de) begin
            px <= px + 1'b1;
        end else begin
            px <= 12'd0;
            if (de_prev) py <= py + 1'b1;   // falling edge of de ends a line
        end
    end
end

//-------------------------------------------------------------------
// ROT90 / ROT270 / ZOOM : window remap in block RAM
//-------------------------------------------------------------------
wire [23:0] rot_data;
wire        rot_inside;

rot_frame_buf_888 #(
    .CENTER_W (CENTER_W),
    .CENTER_H (CENTER_H),
    .X_OFFSET (X_OFFSET),
    .Y_OFFSET (Y_OFFSET)
) u_rot (
    .clk        (clk       ),
    .rst_n      (rst_n     ),
    .px         (px        ),
    .py         (py        ),
    .pix_valid  (in_de     ),
    .pix_in     (pix_in    ),
    .rot_en     (rot_en    ),
    .xform      (rot_xform ),
    .frame_tick (frame_tick),
    .rot_data   (rot_data  ),
    .rot_inside (rot_inside)
);

//-------------------------------------------------------------------
// HMIRROR / SHEAR : ping-pong line buffer, written forwards, read at an
// arbitrary x.
//
// Remapping x cannot start until the line has fully arrived, so the result is
// one line behind -- invisible at 1080p.  The write strobe is gated on the
// mode for the same reason the rotate banks are: an always-on 1920-per-line
// write into block RAM is a lot of internal switching to pay for a mode
// nobody is looking at.  The cost is that the first line after switching in
// shows whatever was left in the buffer.
//
// Reads take the same three clocks as the rotate path so the output mux sees
// both branches aligned.  No reset on the arrays or their output registers.
//-------------------------------------------------------------------
reg lsel;                                    // which buffer is being written
always @(posedge clk or negedge rst_n) begin
    if (!rst_n)                 lsel <= 1'b0;
    else if (!in_de && de_prev) lsel <= ~lsel;   // end of a line
end

// Shear displacement, |(py - 540) >> 1|, kept unsigned so nothing depends on
// how the tool treats mixed-sign expressions.
wire        py_hi   = (py >= V_CENTRE);
wire [11:0] py_dist = py_hi ? (py - V_CENTRE) : (V_CENTRE - py);
wire [11:0] shear_m = {1'b0, py_dist[11:1]};          // 0 .. 270

// SHEAR_R leans one way below the centre line and the other way above it;
// SHEAR_L is the mirror of that.
wire use_minus = (mode_active == MODE_SHEAR_R) ? py_hi : ~py_hi;

wire [11:0] rd_minus = px - shear_m;
wire [11:0] rd_plus  = px + shear_m;

wire [11:0] shear_rd = use_minus ? rd_minus : rd_plus;
wire        shear_ok = use_minus ? (px >= shear_m) : (rd_plus < IMG_HDISP);

wire        mir_mode = (mode_active == MODE_HMIRROR);
wire [11:0] mir_rd   = (IMG_HDISP - 1) - px;

wire [11:0] lb_rd_c  = mir_mode ? mir_rd : shear_rd;
wire        lb_ok_c  = mir_mode ? 1'b1   : shear_ok;

// Never index the array out of range, even on a cycle whose data is discarded.
wire [10:0] lb_rd_addr_c = lb_ok_c ? lb_rd_c[10:0] : 11'd0;

reg [10:0] lb_wr_addr_r, lb_rd_addr_r;
reg [23:0] lb_wr_data_r;
reg        lb_we_r;
reg        wsel_d1, rsel_d1, ok_d1;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        lb_wr_addr_r <= 11'd0;
        lb_rd_addr_r <= 11'd0;
        lb_wr_data_r <= 24'd0;
        lb_we_r      <= 1'b0;
        wsel_d1      <= 1'b0;
        rsel_d1      <= 1'b1;
        ok_d1        <= 1'b0;
    end else if (lb_en) begin
        lb_wr_addr_r <= px[10:0];
        lb_rd_addr_r <= lb_rd_addr_c;
        lb_wr_data_r <= pix_in;
        lb_we_r      <= in_de;
        wsel_d1      <=  lsel;
        rsel_d1      <= ~lsel;
        ok_d1        <= lb_ok_c;
    end else begin
        lb_we_r      <= 1'b0;
        ok_d1        <= 1'b0;
    end
end

reg [23:0] lb0 [0:IMG_HDISP-1];
reg [23:0] lb1 [0:IMG_HDISP-1];
reg [23:0] m0q1, m0q2, m1q1, m1q2;

always @(posedge clk) begin
    if (lb_we_r && !wsel_d1) lb0[lb_wr_addr_r] <= lb_wr_data_r;
    m0q1 <= lb0[lb_rd_addr_r];
    m0q2 <= m0q1;
end

always @(posedge clk) begin
    if (lb_we_r &&  wsel_d1) lb1[lb_wr_addr_r] <= lb_wr_data_r;
    m1q1 <= lb1[lb_rd_addr_r];
    m1q2 <= m1q1;
end

reg rsel_d2, rsel_d3;
reg ok_d2,   ok_d3;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        rsel_d2 <= 1'b1; rsel_d3 <= 1'b1;
        ok_d2   <= 1'b0; ok_d3   <= 1'b0;
    end else begin
        rsel_d2 <= rsel_d1; rsel_d3 <= rsel_d2;
        ok_d2   <= ok_d1;   ok_d3   <= ok_d2;
    end
end

wire [23:0] lb_data = rsel_d3 ? m1q2 : m0q2;

//-------------------------------------------------------------------
// BYPASS needs the same three clocks the two RAM paths take
//-------------------------------------------------------------------
reg [23:0] byp_d1, byp_d2, byp_d3;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        byp_d1 <= 24'd0; byp_d2 <= 24'd0; byp_d3 <= 24'd0;
    end else begin
        byp_d1 <= pix_in; byp_d2 <= byp_d1; byp_d3 <= byp_d2;
    end
end

//-------------------------------------------------------------------
// Output mux, registered -- the fourth clock
//-------------------------------------------------------------------
reg [23:0] out_rgb_r;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n)
        out_rgb_r <= 24'd0;
    else begin
        // Selected off rot_en / lb_en rather than a mode list, so adding a
        // mode is one line in the decoder above and nothing here.
        //
        // Black outside the window, not the untransformed picture.  With the
        // window at 1024x1024 the leftover is a border round the edge, and
        // letting the original show through there reads as "the effect is
        // broken in the corners" rather than as a frame.  Same for a shear
        // that has run off the end of the source line.
        if      (rot_en) out_rgb_r <= rot_inside ? rot_data : 24'd0;
        else if (lb_en)  out_rgb_r <= ok_d3      ? lb_data  : 24'd0;
        else             out_rgb_r <= byp_d3;
    end
end

assign {out_r, out_g, out_b} = out_rgb_r;

//-------------------------------------------------------------------
// Sync, delayed to match
//-------------------------------------------------------------------
reg [AFFINE_SYNC_DLY-1:0] hs_dly, vs_dly, de_dly;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        hs_dly <= {AFFINE_SYNC_DLY{1'b0}};
        vs_dly <= {AFFINE_SYNC_DLY{1'b0}};
        de_dly <= {AFFINE_SYNC_DLY{1'b0}};
    end else begin
        hs_dly <= {hs_dly[AFFINE_SYNC_DLY-2:0], in_hs};
        vs_dly <= {vs_dly[AFFINE_SYNC_DLY-2:0], in_vs};
        de_dly <= {de_dly[AFFINE_SYNC_DLY-2:0], in_de};
    end
end

assign out_hs = hs_dly[AFFINE_SYNC_DLY-1];
assign out_vs = vs_dly[AFFINE_SYNC_DLY-1];
assign out_de = de_dly[AFFINE_SYNC_DLY-1];

endmodule
