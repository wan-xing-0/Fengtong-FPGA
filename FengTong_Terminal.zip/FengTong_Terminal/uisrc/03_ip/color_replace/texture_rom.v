//---------------------------------------------------------------------------
// texture_rom -- 2 x 128x128 RGB565 photographic tiles, marble and wood.
//
// 32768 entries: address[14] picks the bank (0 marble, 1 wood), [13:7] is the
// tile row and [6:0] the tile column, so the low 14 bits are just {y,x} within
// a 128x128 tile and the pattern wraps every 128 pixels for free.
//
// The original was an Altera altsyncram wrapper with an input address register
// plus an output register -- two clocks.  This is a plain inferred array with
// the same two clocks, which is what the parent's pipeline is built around.
//
// The data file sits beside this source on purpose.  TD resolves a relative
// readmemh path against the directory of the file calling it first, so a bare
// filename here is unambiguous.  The DDR IP in this project gets it wrong the
// other way -- "./uisrc/03_ip/ph1a_ddr/ddr_ip_1.txt" resolved against
// ddr_ip.v's own directory is a doubled path -- and throws HDL-5105 on every
// build.  If this one ever starts warning, the texture goes silently all-black,
// so check the synthesis log for it rather than finding out on the TV.
//
// No reset anywhere: that is what lets this infer as block RAM.
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module texture_rom #(
parameter HEXFILE = "texture_combined.hex"
)(
input  wire        clock,
input  wire [14:0] address,
output wire [15:0] q
);

reg [15:0] mem [0:32767];

initial $readmemh(HEXFILE, mem);

reg [15:0] q1, q2;

always @(posedge clock) begin
    q1 <= mem[address];
    q2 <= q1;
end

assign q = q2;

endmodule
