//---------------------------------------------------------------------------
// color_replace -- swap red regions for a photographic marble or wood texture.
//
// Ported from the competition project's color_replace (RGB565, 1280x720).
// That module was the survivor of six burns; its parameter values are not
// arbitrary and the history is worth knowing before touching them:
//
//   burn 3  a strict 1x16 AND test was replaced by hysteresis, because single
//           sub-threshold pixels punched holes through the middle of the cap.
//   burn 4  absolute G/B limits became relative differences and MIN_HITS went
//           8 -> 32.  HYST_END also went to 24, which turned out to be far too
//           wide: sub-pixel red at a right-hand edge kept re-arming the exit
//           counter and painted roughly 800px streaks across the screen.
//   burn 5  HYST_END 24 -> 8 killed the streaks.  This is the version ported.
//   burn 6  loosened the thresholds again and flooded the whole desk with
//           wood.  Reverted.
//
// So: widen HYST_END and you get streaks, loosen the colour test and you get
// the entire room.  The defaults below are burn 5's, rescaled.
//
// MARGINS AFTER GAMMA (2026-08-10)
//   First bench test: a red object was held up and nothing was replaced.  The
//   thresholds were the problem, and the reason is that this chain is not the
//   source project's.  isp_gamma sits upstream and sRGB-encodes every channel
//   (~^0.4545), which lifts midtones hard and therefore COMPRESSES channel
//   DIFFERENCES in the upper half of the range.  A linear-light pixel of
//   (150, 90, 80) -- an ordinary red object under room light -- comes out of
//   the encode at roughly (200, 159, 151): R-G has collapsed from 60 to 41.
//   The old R_GT_*_MIN of 80 could only be met by a near-primary red.
//
//   So R_GT_G_MIN / R_GT_B_MIN went 80 -> 40 and R_MIN 48 -> 40, with
//   MIN_HITS_PER_ROW 48 -> 24 so a hand-held object rather than a whole
//   tabletop still qualifies a row.
//
//   These are still the burn-5 *ratios* measured in the right colour space,
//   not the burn-6 free-for-all -- but burn 6 is the warning: skin is reddish
//   and R_GT_B_MIN is what keeps wood grain (where R is barely above B) out.
//
// HUE, NOT WARMTH (2026-08-10, second bench test)
//   Second bench test: "only a very standard red gets replaced".  So 40 was
//   still too tight -- but dropping the two differences to ~25 is precisely
//   the move that produced burn 6's tabletop of wood, because a plain
//   difference test cannot tell red from any other warm colour.  Work the
//   numbers on gamma-encoded pixels and the problem is obvious:
//
//       object        R    G    B     R-G   R-B    old test at 40
//       red object   200  159  151     41    49    passes, just
//       dull red     170  140  135     30    35    FAILS  <- the complaint
//       skin         220  170  150     50    70    passes <- unwanted
//       brown wood   160  120   85     40    75    passes <- unwanted
//
//   Loosening to 25 catches the dull red and also nails skin and wood even
//   harder.  There is no threshold on those two columns that separates them.
//
//   What does separate them is HUE.  Take sat = R - min(G,B) and
//   dif = |G - B|; when R is the maximum these are exactly the HSV saturation
//   and 60deg-normalised hue, so dif/sat is how far the colour has rotated
//   away from pure red.  On the same four rows:
//
//       object       sat  dif  dif*4 <= sat ?
//       red object    49    8   32 <= 49  yes
//       dull red      35    5   20 <= 35  yes   <- now caught
//       skin          70   20   80 >  70  NO    <- now rejected
//       brown wood    75   35  140 >  75  NO    <- now rejected
//
//   That is one min, one max, one subtract and a shift.  With hue policed,
//   the saturation floor can drop to 32 and still be safer than the old 40
//   was: hue_ok forces R to lead BOTH other channels by at least 0.75*sat,
//   so R_GT_G_MIN and R_GT_B_MIN are subsumed and gone.
//
//   Three knobs remain.  If faces or skin start growing marble, raise
//   HUE_SHIFT to 3 first (halves the hue window to +-7.5deg) -- that costs
//   nothing on a saturated object.  Raise SAT_MIN only if a desaturated pink
//   is still getting through.  R_MIN is just a darkness floor.
//
//   Deliberately NOT relied on: the surviving pink corner of the space.  A
//   washed-out pink (200,165,160) has sat 40 and dif 5, so it passes.  If the
//   demo puts a hand next to the red object and the hand turns to marble,
//   HUE_SHIFT=3 is the fix, not SAT_MIN.
//
//   If an object still is not caught, measure rather than guess: press F9 for
//   the histogram, fill the frame with the object, and read the R peak
//   against the G and B peaks -- that gap is the real margin available.
//
// THE LOW-SATURATION HOLE (2026-09-05, third bench test)
//   Third bench test: "it only swaps when the object is VERY red -- an
//   ordinary red gets nothing, or a few specks".  That is HUE_SHIFT = 3
//   overshooting, and the arithmetic says so plainly.  Run the header's own
//   four rows again at shift 3 instead of shift 2:
//
//       object       R    G    B    sat  dif   dif<<3 <= sat ?
//       red object  200  159  151    49    8   64 >  49   FAILS  <- complaint
//       dull red    170  140  135    35    5   40 >  35   FAILS  <- complaint
//       skin        220  170  150    70   20  160 >  70   rejected, wanted
//       brown wood  160  120   85    75   35  280 >  75   rejected, wanted
//
//   Both reds fail, and NOT because their hue is wrong -- dif is 8 and 5, they
//   are sitting essentially on the red axis.  They fail because the test is
//   RELATIVE: tolerance is sat >> HUE_SHIFT, so at sat 49 the whole allowance
//   is 6 counts.  An ordinary red object under room light, after the upstream
//   sRGB encode compresses its channel differences (see MARGINS AFTER GAMMA),
//   simply does not have 49*7/8 of headroom to spare.  A saturated red does:
//   a red plastic (230,40,60) has sat 190 and rides through at shift 3 easily.
//
//   So the relative test is right for saturated colour and wrong for
//   desaturated colour, which is exactly backwards from what is needed.  The
//   fix is an OR, not a different shift:
//
//       hue_ok = (dif << HUE_SHIFT <= sat)            // saturated: hue window
//              | (dif <= DIF_TOL && r >= DIF_TOL_R_MIN)  // washed out: axis
//
//   The second arm reads "g and b are within 10 counts of each other, and the
//   pixel is bright" -- i.e. a light red/pink on the grey axis.  Re-run every
//   colour that matters, at HUE_SHIFT 3 / DIF_TOL 10 / DIF_TOL_R_MIN 144:
//
//       object       R    G    B   sat  dif  rel  abs  verdict
//       red object  200  159  151   49    8   no  yes  REPLACED  <- fixed
//       dull red    170  140  135   35    5   no  yes  REPLACED  <- fixed
//       red plastic 230   40   60  190   20  yes   -   REPLACED
//       pure red    255    0    0  255    0  yes   -   REPLACED
//       skin        220  170  150   70   20   no   no  kept
//       brown wood  160  120   85   75   35   no   no  kept
//       red-brown   130   72   58   72   14   no   no  kept
//       white       240  240  240    0    0    -   -   kept (sat < SAT_MIN)
//       orange      240  140   40  200  100   no   no  kept
//
//   Every wanted rejection from 08-12 survives, because skin and wood are
//   rejected on dif alone (20 and 35, both over DIF_TOL) and not on the hue
//   window at all.  The one hole the brightness gate closes on top is dark
//   red-brown (110,60,55): dif 5 would pass the absolute arm, but R 110 < 144
//   holds it -- and note that pixel passes the RELATIVE arm anyway (40 <= 55),
//   so it was already being replaced before this change and still is.  Killing
//   it needs SAT_MIN above 55, which costs every dark red object; not done.
//
//   Cost: one 8-bit compare, one 8-bit compare, one OR.  No new BRAM, no DSP.
//
//   ORDER OF KNOBS if the bench comes back again.  Too little replaced: raise
//   DIF_TOL (10 -> 14) before touching HUE_SHIFT, it only widens the
//   desaturated corner and leaves saturated behaviour alone.  Skin or a hand
//   turning to marble: lower DIF_TOL_R_MIN's opposite -- i.e. RAISE
//   DIF_TOL_R_MIN (144 -> 176) or drop DIF_TOL to 8; skin's dif of 20 means it
//   only ever gets in through a badly widened DIF_TOL.
//
// WHAT CHANGED IN THE PORT
//   * RGB888.  The original compared 5-bit R against a 6-bit G halved to five
//     bits (g_half = g6[5:1]) to put them on one scale.  With 8 bits per
//     channel that trick is unnecessary -- R, G and B compare directly -- and
//     the thresholds move up by the same 8x the channels did: R_MIN 6 -> 48,
//     R_GT_* 10 -> 80.  The sums need 9 bits (255 + 80 = 335).
//   * 1080p.  Line wrap 1279 -> 1919, frame 719 -> 1079, MIN_HITS_PER_ROW
//     32 -> 48 to keep the same fraction of a line.  HYST_START scales with
//     resolution (4 -> 6); HYST_END deliberately does not, because raising it
//     is precisely what produced burn 4's streaks.
//   * Coordinates come from de/vs like everything else here, rather than the
//     source's framesync/rdreq pair.
//   * Declarations are in dependency order.  The original used framesync_edge
//     and row_wrap some fifty lines above their wire declarations; Verilog
//     tolerates that, but TD has burned this project before by turning a
//     forward-referenced name into an implicit 1-bit net and blacking out the
//     picture with no warning at all.
//
// KNOWN, INHERITED: the row test uses the PREVIOUS row's hit count, so the
// topmost row of a red region is never replaced.  One line, invisible.
//
// LATENCY 3 clocks: 2 for the texture ROM, 1 for the output register.
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module color_replace #(
parameter integer IMG_HDISP = 1920,
parameter integer IMG_VDISP = 1080,

// Hysteresis: go active after START consecutive red pixels, drop out after
// END consecutive non-red ones.
parameter [5:0]  HYST_START       = 6'd6,
parameter [5:0]  HYST_END         = 6'd8,

// A row is only eligible if the row above it had at least this many hits.
parameter [11:0] MIN_HITS_PER_ROW = 12'd24,

// Colour test, 8-bit scale.  Read MARGINS AFTER GAMMA and then HUE, NOT
// WARMTH in the header before touching any of these three.
parameter [7:0]   R_MIN     = 8'd32,   // R has to be at least this bright
parameter [8:0]   SAT_MIN   = 9'd32,   // r - min(g,b): how far red stands out
parameter integer HUE_SHIFT = 3,       // |g-b| << HUE_SHIFT <= sat, see header
                                       // 2 -> 3 on 08-12: +-15deg hue window
                                       // was tagging red-brown wood grain as
                                       // marble.  MAX IS 3 -- hue_lhs is [10:0]
                                       // and 255<<3 = 2040 only just fits.

// Absolute escape from the hue window, for the desaturated reds that the
// RELATIVE test cannot hold.  See THE LOW-SATURATION HOLE in the header: a
// pixel whose g and b are within DIF_TOL of each other is on the grey axis and
// is red by construction, whatever its saturation -- but only trust that when
// it is also bright, or dark red-brown wood walks straight through the gap.
parameter [7:0]   DIF_TOL       = 8'd10,
parameter [7:0]   DIF_TOL_R_MIN = 8'd144
)(
input  wire        clk,
input  wire        rst_n,

input  wire        in_vs,          // HIGH across the visible frame
input  wire        in_de,
input  wire [23:0] in_rgb,         // {R,G,B}

input  wire [1:0]  texture_mode,   // 00 off, 01 marble, 10 wood

output wire        out_vs,
output wire        out_de,
output wire [23:0] out_rgb
);

localparam integer CR_SYNC_DLY = 3;

//------------------------------------------------------------------------
// [1] Screen coordinates, rebuilt from de/vs
//------------------------------------------------------------------------
reg [11:0] px, py;
reg        de_prev, in_vs_d1;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        px <= 12'd0; py <= 12'd0; de_prev <= 1'b0; in_vs_d1 <= 1'b0;
    end else begin
        de_prev  <= in_de;
        in_vs_d1 <= in_vs;
        if (!in_vs) begin
            px <= 12'd0;
            py <= 12'd0;
        end else if (in_de) begin
            px <= px + 1'b1;
        end else begin
            px <= 12'd0;
            if (de_prev) py <= py + 1'b1;
        end
    end
end

wire frame_tick = in_vs_d1 & ~in_vs;                     // start of blanking
wire row_wrap   = in_de & (px == (IMG_HDISP - 1));       // last pixel of a line

//------------------------------------------------------------------------
// [2] Colour test.  Three questions: is R bright enough, does red stand out
// from the other two by enough, and is the HUE actually red rather than
// merely warm.  The third one is what lets the second one be generous --
// see HUE, NOT WARMTH in the header.
//------------------------------------------------------------------------
wire [7:0] r8 = in_rgb[23:16];
wire [7:0] g8 = in_rgb[15:8];
wire [7:0] b8 = in_rgb[7:0];

wire [7:0] gb_max = (g8 > b8) ? g8 : b8;
wire [7:0] gb_min = (g8 > b8) ? b8 : g8;
wire [7:0] gb_dif = gb_max - gb_min;                  // |g - b|, never negative

wire       r_is_max = (r8 >= gb_max);
wire [8:0] sat      = {1'b0, r8} - {1'b0, gb_min};    // only read when r_is_max

// |g - b| * 2^HUE_SHIFT <= sat.  These are exactly the HSV quantities: sat is
// (max - min) and (g - b)/sat is hue/60deg when red is the max, so the window
// is +-60/2^HUE_SHIFT degrees around pure red: +-15 at 2, +-7.5 at 3 (current).
// gb_dif can reach 255, so the left side needs 11 bits to hold 255<<3 = 2040 --
// anything narrower would silently wrap and turn a wide-hue pixel into a
// passing one.  That 11 is also why HUE_SHIFT cannot go past 3 without widening
// this wire and the {2'b0, sat} below.
wire [10:0] hue_lhs = {3'b0, gb_dif} << HUE_SHIFT;
wire        hue_rel = (hue_lhs <= {2'b0, sat});

// The absolute escape.  hue_rel scales its tolerance with saturation, so a
// washed-out red gets a tolerance of a few counts and loses to ordinary sensor
// noise; this arm says |g-b| <= DIF_TOL is on the grey axis regardless.  The
// brightness gate is what keeps dark red-brown out of it -- see the header.
wire        hue_abs = (gb_dif <= DIF_TOL) && (r8 >= DIF_TOL_R_MIN);

wire        hue_ok  = hue_rel | hue_abs;

wire color_bit = (r8 > R_MIN) && r_is_max && (sat >= SAT_MIN) && hue_ok;

//------------------------------------------------------------------------
// [3] Horizontal hysteresis, reset every row and every frame
//------------------------------------------------------------------------
reg [5:0] consec_red;
reg [5:0] consec_nored;
reg       hori_active;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        consec_red   <= 6'd0;
        consec_nored <= 6'd0;
        hori_active  <= 1'b0;
    end else if (frame_tick || row_wrap) begin
        consec_red   <= 6'd0;
        consec_nored <= 6'd0;
        hori_active  <= 1'b0;
    end else if (in_de) begin
        if (color_bit) begin
            consec_nored <= 6'd0;
            if (consec_red < 6'd63)
                consec_red <= consec_red + 6'd1;
            if (consec_red >= (HYST_START - 6'd1))
                hori_active <= 1'b1;
        end else begin
            consec_red <= 6'd0;
            if (consec_nored < 6'd63)
                consec_nored <= consec_nored + 6'd1;
            if (consec_nored >= (HYST_END - 6'd1))
                hori_active <= 1'b0;
        end
    end
end

//------------------------------------------------------------------------
// [4] Per-row hit count.  A row only qualifies if the row above it had enough
// hits, which throws away isolated specks without a second line buffer.
//------------------------------------------------------------------------
reg [11:0] line_hits;
reg [11:0] prev_line_hits;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        line_hits      <= 12'd0;
        prev_line_hits <= 12'd0;
    end else if (frame_tick) begin
        line_hits      <= 12'd0;
        prev_line_hits <= 12'd0;
    end else if (row_wrap) begin
        prev_line_hits <= line_hits + (hori_active ? 12'd1 : 12'd0);
        line_hits      <= 12'd0;
    end else if (in_de && hori_active && (line_hits != 12'hFFF)) begin
        line_hits <= line_hits + 12'd1;
    end
end

wire row_qualifies = (prev_line_hits >= MIN_HITS_PER_ROW);

//------------------------------------------------------------------------
// [5] Texture lookup.  The low 7 bits of each coordinate are the tile offset,
// so the 128x128 pattern wraps by itself.  1920 is a whole number of tiles;
// 1080 is not, so there is a seam 56 pixels from the bottom -- it only shows
// inside a red region, and the source had the same thing at 720p.
//------------------------------------------------------------------------
wire        rom_select = texture_mode[1];      // 01 -> marble, 10 -> wood
wire [14:0] tex_addr   = {rom_select, py[6:0], px[6:0]};

wire [15:0] rom_q;

texture_rom u_texture_rom (
    .clock   (clk     ),
    .address (tex_addr),
    .q       (rom_q   )
);

// RGB565 -> RGB888 by bit replication, so full scale stays full scale.
wire [23:0] rom_rgb888 = { rom_q[15:11], rom_q[15:13],
                           rom_q[10:5],  rom_q[10:9],
                           rom_q[4:0],   rom_q[4:2] };

//------------------------------------------------------------------------
// [6] Line the decision up with the ROM data, then one output register
//------------------------------------------------------------------------
reg [23:0] rgb_d1, rgb_d2;
reg        active_d1, qualifies_d1;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        rgb_d1       <= 24'd0;
        rgb_d2       <= 24'd0;
        active_d1    <= 1'b0;
        qualifies_d1 <= 1'b0;
    end else begin
        rgb_d1       <= in_rgb;
        rgb_d2       <= rgb_d1;
        active_d1    <= hori_active;
        qualifies_d1 <= row_qualifies;
    end
end

wire replace_now = active_d1 && qualifies_d1 && (texture_mode != 2'b00);

reg [23:0] out_rgb_r;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) out_rgb_r <= 24'd0;
    else        out_rgb_r <= replace_now ? rom_rgb888 : rgb_d2;
end

assign out_rgb = out_rgb_r;

//------------------------------------------------------------------------
// [7] Sync, delayed to match
//------------------------------------------------------------------------
reg [CR_SYNC_DLY-1:0] vs_dly, de_dly;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        vs_dly <= {CR_SYNC_DLY{1'b0}};
        de_dly <= {CR_SYNC_DLY{1'b0}};
    end else begin
        vs_dly <= {vs_dly[CR_SYNC_DLY-2:0], in_vs};
        de_dly <= {de_dly[CR_SYNC_DLY-2:0], in_de};
    end
end

assign out_vs = vs_dly[CR_SYNC_DLY-1];
assign out_de = de_dly[CR_SYNC_DLY-1];

endmodule
