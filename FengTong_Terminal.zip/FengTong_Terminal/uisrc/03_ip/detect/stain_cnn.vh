// stain_cnn.vh  由 stain_v4.py 生成于 2026-10-25 19:29，请勿手改
// 在 stain_detect 模块体内 `include，不要加 include guard
//
// !! v4: 不再有 CNN 权重。需要 stain_detect.v v4（格均值 + 格级闭运算），和 v3.x 的 RTL 不兼容 !!
//
// 标定（摄像头真实采集）: 干净 66 张 cmax<=4，污渍 42 张 cmax>=42，T=23，误报 0/66，检出 42/42
//
// M  = 格内工件像素平均亮度；PM = 整格都是工件
// V  = erode_(2*GUARD+1, 越界=0)( close_CK(PM) )；BG = close_CK(M)
// hot = V && (BG - M >= SCNN_T)；热格数 >= SCNN_MIN_CELLS → 本帧阳性
localparam integer SCNN_G         = 128;     // 坐标换算网格（与 stain_overlay 一致）
localparam integer SCNN_HG        = 64;      // 判定网格
localparam integer SCNN_LUMA_R    = 77;
localparam integer SCNN_LUMA_G    = 150;
localparam integer SCNN_LUMA_B    = 29;
localparam integer SCNN_CK        = 5;       // 闭运算窗口（格，奇数）
localparam integer SCNN_GUARD     = 4;       // 有效区内缩（格）
localparam integer SCNN_T         = 23;      // 对比度阈值（灰阶）
localparam integer SCNN_MIN_CELLS = 3;
localparam integer SCNN_VOTE_N    = 8;       // 多帧投票窗口
localparam integer SCNN_VOTE_K    = 5;       // 窗口内阳性次数门限
