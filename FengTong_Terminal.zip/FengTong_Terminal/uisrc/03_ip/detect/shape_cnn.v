//---------------------------------------------------------------------------
// shape_cnn -- 对 ccl_blob 框内的黑色检测 mask 做形状分类（other/circle/rect/tri）
//
// 2026-10-09 重写。shape_cnn_weights.vh 和整数 golden model（shape_cnn_train.py
// 的 int_forward）都不动，结果逐位一致；变的是帧边界、ROI 缓存和整个计算后端。
// 端口与"接 ccl_blob 输出"那一版的顶层接线一致，10-09 晚只多了一个 class_valid
// 输出（见第 9 条）。
//
// ⭐ 2026-10-09 夜 四类版（第 10 条）：加三角形 CLS_TRI = 2'd3。只改 L6 FC（3 -> 4
// 路）和 argmax，多一个 logit3 输出；L0~L5 的流水和存储一个字都没动。
// ⚠ 必须配 4 类的 shape_cnn_weights.vh（SC_L6_COUT = 4）。配 3 类的旧 .vh 时
// SC_W6 / SC_B6 第 3 类的下标越界；为此 CLS_TRI 取自 .vh 的 SC_CLS_TRI，旧 .vh
// 没有这个名字，综合和仿真都会直接报"未声明"。
//
//===========================================================================
// 网络（与 golden model 相同）
//===========================================================================
//   ROI  bbox 四周各扩 pw=w>>4 / ph=h>>4，DDA 最近邻非等比拉伸到 32x32，
//        画面外取 0。src_x(j) = (x0-pw) + ((2j+1)*Wr)/64，Wr = w+2*pw
//   L0   conv3x3 1->8   +b ReLU round>>SH0 sat255    32x32   -> 8x30x30
//   L1   maxpool 2x2                                 8x30x30 -> 8x15x15
//   L2   conv3x3 8->16  +b ReLU round>>SH2 sat255    8x15x15 -> 16x13x13
//   L3   maxpool 2x2，丢第 13 行/列                  16x13x13 -> 16x6x6
//   L4   conv3x3 16->16 +b ReLU round>>SH4 sat255    16x6x6  -> 16x4x4
//   L5   每通道 16 点求和（1/16 已折进 FC 权重）     -> 16 x uint12
//   L6   FC 16->4 +b，argmax，相等取小编号
//   requant: y = min(255, (max(acc,0) + (1<<(SH-1))) >> SH)，SH==0 不加舍入
//
//===========================================================================
// 和上一版比改了什么，为什么
//===========================================================================
// 1. 帧边界从 de 推导（[A]）。这条链上的 vs 是 ~vtc_vs，即取反的 5 行同步
//    脉冲（ccl_blob [1]）。上一版在 vs 下降沿开算、上升沿清 ROI，两者只隔
//    11,000 拍，而 L0 要读 64,800 拍：从第 2 个通道起读到的全是零。
// 2. ROI 双缓冲（[C]）。整个计算 ~27 万拍，是场消隐的 2.7 倍，一定会跑进
//    下一帧的有效区，所以采样和计算各用一份。
// 3. 框在消隐期跟随、有效区冻结（[B]），冻结下来的永远是 ccl_blob 最新一次
//    发布的框。上一版在 vs 上升沿锁存，ccl_blob 发布得晚时会锁到上上帧的框。
// 4. 坐标用 ccl_blob 的 out_px/out_py（已加 MASK_SHIFT），不自己重建：框是在
//    开运算后的 mask 上算的，原始 mask 相对它有 (+2,+2) 的位移。
// 5. 池化并进卷积（[E]）。ReLU+requant 之后都是 >=0 的 uint8，对 2x2 的四个
//    卷积输出取滚动最大值，和先存整张图再池化逐位一致。f0（57.6 kbit）和
//    f2（21.6 kbit）整块消失；L2 的第 13 行/列本来就会被 L3 丢掉，直接不算，
//    省 28,800 拍。L4 的 16 个输出同理直接求和进 gsum，f4 也不要了。
// 6. 所有存储都是"一个写口 + 一个寄存读口"，f1/f3 能进 ERAM。上一版池化时
//    一拍读同一块 RAM 的 4 个地址，卷积的读地址组合算出后直接进乘法，只能
//    落到 LUT-RAM 或寄存器上。
// 7. MAC 拆成 10 级流水，每级只做一件事（[F]）。上一版"读 RAM -> 乘 -> 加 ->
//    requant -> 写 RAM"挤在一个 6.67 ns 周期里，而 pclkx1 只剩 0.1 ns 余量。
// 8. L5 里越界的位选 f4[...][SC_GSUM_W-1:0] 随 f4 一起没了（TD 会把这类
//    越界报成 HDL-8007，iverilog 不报）。
// 9. 10-09 晚：class_valid。采样那一帧没有框时本模块不计算、直接报 other，
//    下游（OSD）分不清"没有框"和"有框但判为 other"。class_valid 与
//    shape_class 在同一拍更新：S_IDLE 的无框分支写 0，S_DONE 写 1。不能在
//    顶层用 blob_valid[0] 代替：done 在场消隐开始后约 27 万拍才来，那时
//    ccl_blob 已经发布了下一组框，blob_valid 差一帧。
// 10. 10-09 夜：四类（加三角形）。FC 每拍多读一个权重、多一个乘法和一个累加器
//    （fw3/fp3/lg3），仍是一个输入通道三拍，FC 总拍数不变。argmax 从 3 路
//    变 4 路：6 个两两比较并行做、再按优先级选，组合深度仍是"一个 32 位比较
//    + 几级与/选择"，和 3 路时同一级别，所以不分拍、done 的时刻不变（见
//    S_DONE）。shape_class 仍是 2 位，2'd3 = 三角形，原来就没用到的编码。
//
//===========================================================================
// 时间与资源
//===========================================================================
//   L0+L1   8 x 15x15 x 4 x   9 =  64,800 拍
//   L2+L3  16 x  6x6  x 4 x  72 = 165,888
//   L4+L5  16 x  4x4      x 144 =  36,864
//   三次排空 3 x 17，FC 16 x 3（4 类同样是 16 x 3）~100
//   合计约 267,700 拍 = 1.8 ms @150 MHz，一帧 16.5 ms 的 11%。
//
//   f1   8x15x15 x 8 bit = 14.4 kbit    单写单读，期望进 ERAM
//   f3  16x6x6   x 8 bit =  4.6 kbit    同上
//   roi / roi_c 2 x 1024 FF，gsum 16 x 12 FF
//   权重是 localparam 常量的变量下标读、寄存输出。W4 有 2304 x 8，TD 可能做成
//   LUT ROM 也可能做成 ERAM ROM，综合后看报告；如果 pclkx1 的最差路径落在
//   w4r2 上，就是它。
//
//===========================================================================
// 时序关系
//===========================================================================
// 帧 N 结束后 ccl_blob 在消隐期发布框；本模块在帧 N+1 用这个框采样 mask，
// 帧 N+1 结束（de 断开 VB_GUARD 拍）时拍下快照开算，约 1.8 ms 后 done。
// 也就是"帧 N 的框套帧 N+1 的 mask"，和 det_overlay 画框是同一个一帧滞后。
// 框取的是顶层接进来的那一个（ccl_blob slot 0）。
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module shape_cnn #(
parameter integer IMG_HDISP = 1920,   // 只为与上一版接口一致，内部不再使用
parameter integer IMG_VDISP = 1080,

// de 连续低多少拍算"帧结束"。与 ccl_blob 的 VB_GUARD 同义、取同一个值：必须
// 大于行消隐、远小于场消隐。dgap 是 10 位计数器，所以不能超过 1023。
parameter integer VB_GUARD  = 512
)(
input  wire        clk,
input  wire        rst_n,

// ---- ccl_blob 的 mask 透传流 ----
input  wire        in_vs,             // 保留端口，内部不用，见 [A]
input  wire        in_de,
input  wire [11:0] in_px,             // 框坐标系，ccl_blob 已加 MASK_SHIFT
input  wire [11:0] in_py,
input  wire        in_mask,           // 1 = 框包围的那类像素（顶层接 ~blk_mask）

// ---- ccl_blob 的外接框，含端点 ----
input  wire        bbox_valid,
input  wire [11:0] bbox_x0,
input  wire [11:0] bbox_y0,
input  wire [11:0] bbox_x1,
input  wire [11:0] bbox_y1,

// ---- 结果：done 拉高一拍，其余保持到下一次 done ----
output reg         done,
output reg  [1:0]  shape_class,       // 0 other / 1 circle / 2 rect / 3 tri（10-09 夜）
output reg  signed [31:0] logit0,
output reg  signed [31:0] logit1,
output reg  signed [31:0] logit2,
output reg  signed [31:0] logit3,     // 10-09 夜：三角形
output reg         class_valid        // 10-09：1 = 结果来自有效框；0 = 采样那一帧没有框（shape_class 为 other）
);

// W0 B0 W2 B2 W4 B4 W6 B6 SH0 SH2 SH4 L*_CIN GSUM_W -- generated, do not hand-edit
`include "shape_cnn_weights.vh"

localparam [1:0] CLS_OTHER  = 2'd0;
localparam [1:0] CLS_CIRCLE = 2'd1;
localparam [1:0] CLS_RECT   = 2'd2;
// 10-09 夜。故意取 .vh 里的 SC_CLS_TRI 而不写 2'd3：3 类的旧 .vh 没有这个名字，
// 配错时任何工具（TD / iverilog）都会在这里报"未声明的标识符"，而不是像越界的
// 常量位选那样在 TD 里只给一个 HDL-8007 警告、悄悄做出错的硬件。
localparam [1:0] CLS_TRI    = SC_CLS_TRI;

// 本文件的 FC / argmax 写死为 4 路。上面那一条只拦"没有 SC_CLS_TRI"，这里在
// 仿真里再核对一遍类数和 FC 输入数。只在 iverilog 下编译（它自动定义
// __ICARUS__），不用 translate_off：工程里没有 TD 认这个注释的先例，不冒这个险。
`ifdef __ICARUS__
initial begin
    if (SC_L6_COUT != 4 || SC_L6_CIN != 16) begin
        $display("ERROR shape_cnn: shape_cnn_weights.vh 是 %0d 类（SC_L6_COUT），本文件要 4 类", SC_L6_COUT);
        $finish;
    end
end
`endif

//------------------------------------------------------------------------
// 结构常量。通道数取 .vh 里的值，每层输出通道 = 下一层输入通道；空间尺寸
// 是网络结构本身，写死在下面的循环上限里（lim_g / lim_s）。
//------------------------------------------------------------------------
localparam integer CI0 = SC_L0_CIN;   // 1
localparam integer CI2 = SC_L2_CIN;   // 8
localparam integer CI4 = SC_L4_CIN;   // 16
localparam integer NFC = SC_L6_CIN;   // 16
localparam integer CO0 = CI2;         // 8
localparam integer CO2 = CI4;         // 16
localparam integer CO4 = NFC;         // 16

localparam integer F1_N = CO0 * 15 * 15;   // 1800
localparam integer F3_N = CO2 *  6 *  6;   //  576

// 一层最后一个抽头发出后等多少拍再开下一层。流水线从发出到写回 RAM 是 10 拍，
// 下一层最早在发出后第 3 拍读 RAM，所以 >= 8 就够；多留一倍。
localparam [3:0] DRAIN = 4'd15;

//------------------------------------------------------------------------
// 权重 / 偏置补零到 2 的幂。另外两层的 ROM 每拍也在读，只是结果被 lay 选掉；
// 补齐之后变量下标永远在范围内，不依赖综合器怎么处理越界读。
//------------------------------------------------------------------------
localparam [128*8-1:0]  W0P = SC_W0;       //   72 项
localparam [2048*8-1:0] W2P = SC_W2;       // 1152 项
localparam [4096*8-1:0] W4P = SC_W4;       // 2304 项
localparam [16*32-1:0]  B0P = SC_B0;       //    8 项
localparam [16*32-1:0]  B2P = SC_B2;       //   16 项
localparam [16*32-1:0]  B4P = SC_B4;       //   16 项

// requant 的舍入常数。SH <= 0 时为 0，且不出现负的移位量。
localparam integer SHR0 = (SC_SH0 > 0) ? (SC_SH0 - 1) : 0;
localparam integer SHR2 = (SC_SH2 > 0) ? (SC_SH2 - 1) : 0;
localparam integer SHR4 = (SC_SH4 > 0) ? (SC_SH4 - 1) : 0;
localparam [32:0]  RND0 = (SC_SH0 > 0) ? (33'd1 << SHR0) : 33'd0;
localparam [32:0]  RND2 = (SC_SH2 > 0) ? (33'd1 << SHR2) : 33'd0;
localparam [32:0]  RND4 = (SC_SH4 > 0) ? (33'd1 << SHR4) : 33'd0;

// requant 第二级：移位 + 饱和到 uint8。r 已经是 ReLU 并加过舍入常数的 33 位
// 非负数，所以加舍入不会溢出。SH < 0 时先判饱和再左移，等价于无限精度下的
// min(255, r << -SH)。sh 只会以编译期常量传入，综合时整段折叠成连线和一个比较。
function [7:0] rq_sat;
    input [32:0]  r;
    input integer sh;
    integer       p, k;
    reg   [32:0]  s;
    begin
        p = (sh > 0) ? sh : 0;
        k = (sh < 0) ? -sh : 0;
        if (sh >= 0) begin
            s      = r >> p;
            rq_sat = (s > 33'd255) ? 8'd255 : s[7:0];
        end else begin
            rq_sat = (r > (33'd255 >> k)) ? 8'd255 : (r[7:0] << k);
        end
    end
endfunction

//========================================================================
// 状态机寄存器先声明：[C] 要靠 state 判断能不能拍快照
//========================================================================
localparam [2:0] S_IDLE   = 3'd0,
                 S_RUN    = 3'd1,
                 S_DRAIN  = 3'd2,
                 S_FC_RD  = 3'd3,
                 S_FC_MUL = 3'd4,
                 S_FC_ACC = 3'd5,
                 S_DONE   = 3'd6;

reg [2:0] state;
reg [1:0] lay;        // 0 = L0+L1，1 = L2+L3，2 = L4+L5
reg       lay_go;     // 一层开始的那一拍，[G] 用它清写指针

//========================================================================
// [A] 帧边界：从 de 推导，不用 vs
//
// ⚠ 这条链上的 vs 是 ~vtc_vs，即取反的 5 行同步脉冲，它在前后肩上也是高
// （ccl_blob [1] 有完整论证）。de 在行间只低一个行消隐、在帧间低整个场
// 消隐，"de 已经连续低了 VB_GUARD 拍"把两者分得很开。
//========================================================================
reg [9:0] dgap;
reg       vblank_d;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n)               dgap <= 10'd0;
    else if (in_de)           dgap <= 10'd0;
    else if (dgap != 10'h3FF) dgap <= dgap + 10'd1;
end

wire vblank = (dgap >= VB_GUARD);

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) vblank_d <= 1'b0;
    else        vblank_d <= vblank;
end

// 本帧最后一个有效像素之后 VB_GUARD 拍，一帧一次。上电后第一次触发时
// roi_en 还是复位值 0，只会出一个 other 的 done（class_valid = 0），无害。
wire frame_tick = vblank & ~vblank_d;

//========================================================================
// [B] ROI 采样参数：消隐期内一直跟随 bbox，有效区一开始就冻结。
//
// ccl_blob 只在消隐期发布，且在下一帧第一个像素之前一定发布完（否则 abort），
// 所以冻结下来的一定是最新一次发布的框。
//
// frame_tick 那一拍 roi_en 仍属于刚采完的那一帧：本模块的 de 比 ccl_blob 的
// 晚 2 拍，而 ccl_blob 最早在它自己的 frame_tick 之后约 9 拍才发布，有 7 拍
// 以上余量。
//========================================================================
reg               roi_en;
reg signed [13:0] Xs, Ys;
reg        [12:0] Wr, Hr;

wire [12:0] bb_w  = bbox_x1 - bbox_x0 + 13'd1;
wire [12:0] bb_h  = bbox_y1 - bbox_y0 + 13'd1;
wire [12:0] bb_pw = bb_w >> 4;
wire [12:0] bb_ph = bb_h >> 4;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        roi_en <= 1'b0;
        Xs <= 14'sd0; Ys <= 14'sd0; Wr <= 13'd1; Hr <= 13'd1;
    end else if (vblank) begin
        roi_en <= bbox_valid;
        Wr <= bb_w + (bb_pw << 1);
        Hr <= bb_h + (bb_ph << 1);
        Xs <= $signed({1'b0, bbox_x0}) - $signed({1'b0, bb_pw});
        Ys <= $signed({1'b0, bbox_y0}) - $signed({1'b0, bb_ph});
    end
end

// 32 个采样坐标，寄存器化、分两拍算。Xs/Wr 只在消隐期变化，到第一个有效
// 像素时早已稳定，多花两拍没有代价；省掉的是像素域里"常数乘 + 加 + 比较 +
// 1024 扇出"这一整条单拍组合路径。
reg        [12:0] smp_xo [0:31];
reg        [12:0] smp_yo [0:31];
reg signed [13:0] smp_x  [0:31];   // 采样坐标。不能叫 sx/sy：[E] 的池化子位置计数器用了这两个名字
reg signed [13:0] smp_y  [0:31];
integer jj;

always @(posedge clk) begin
    for (jj = 0; jj < 32; jj = jj + 1) begin
        smp_xo[jj] <= ((2*jj+1) * Wr) >> 6;
        smp_yo[jj] <= ((2*jj+1) * Hr) >> 6;
        smp_x[jj]  <= Xs + $signed({1'b0, smp_xo[jj]});
        smp_y[jj]  <= Ys + $signed({1'b0, smp_yo[jj]});
    end
end

//========================================================================
// [C] ROI 采样，双缓冲
//
//   roi   : 本帧正在写入的 32x32，下标 row*32 + col
//   roi_c : frame_tick 时拍下的快照，L0 只读它
//
// 快照和清零在同一拍。只在空闲时拍快照：计算只要一帧的 11%，正常情况下
// frame_tick 时一定空闲；万一不空闲，这一帧就跳过，绝不在 L0 读的时候换数据。
//
// 画面外的采样点没有任何像素坐标会等于它，格子保持清零值 0，与 golden
// model 的"画面外取 0"一致，所以不需要单独的范围比较。
//========================================================================
reg [1023:0] roi, roi_c;

reg [31:0] colhit_r, rowhit_r;
reg        de_r, mask_r;
integer    hj;                // 不与 jj 共用：两个 always 块共用一个 integer 在仿真里会竞争

always @(posedge clk) begin
    de_r   <= in_de;
    mask_r <= in_mask;
    for (hj = 0; hj < 32; hj = hj + 1) begin
        colhit_r[hj] <= ($signed({2'b00, in_px}) == smp_x[hj]);
        rowhit_r[hj] <= ($signed({2'b00, in_py}) == smp_y[hj]);
    end
end

integer ri, ci;

always @(posedge clk) begin
    if (frame_tick) begin
        if (state == S_IDLE) roi_c <= roi;
        roi <= 1024'd0;
    end else if (de_r && roi_en) begin
        for (ri = 0; ri < 32; ri = ri + 1)
            for (ci = 0; ci < 32; ci = ci + 1)
                if (rowhit_r[ri] && colhit_r[ci])
                    roi[ri*32 + ci] <= mask_r;
    end
end

//========================================================================
// [D] 特征图存储。都是一个写口 + 一个寄存读口。
//
//   f1   : L0+L1 的输出 = L2 的输入，下标 (c*15 + y)*15 + x
//   f3   : L2+L3 的输出 = L4 的输入，下标 (c*6  + y)*6  + x
//   gsum : L4+L5 的输出 = FC 的输入
//
// 写端口在 [G]：各层的输出按 c、y、x 的顺序产生，正好就是存储顺序，所以写
// 地址只是一个递增指针。三块存储只在本层写，lay 在排空结束之前不会变。
//========================================================================
reg [7:0]           f1   [0:F1_N-1];
reg [7:0]           f3   [0:F3_N-1];
reg [SC_GSUM_W-1:0] gsum [0:NFC-1];
reg [7:0]           f1_q, f3_q;

reg [10:0] iaddr2;            // [F] 第 2 级产生
reg        wr_en;             // [G] 产生
reg [10:0] wr_a;
reg [15:0] wr_d;

always @(posedge clk) begin
    if (wr_en && (lay == 2'd0)) f1[wr_a] <= wr_d[7:0];
    f1_q <= f1[iaddr2];
end

always @(posedge clk) begin
    if (wr_en && (lay == 2'd1)) f3[wr_a[9:0]] <= wr_d[7:0];
    f3_q <= f3[iaddr2[9:0]];
end

always @(posedge clk) begin
    if (wr_en && (lay == 2'd2)) gsum[wr_a[3:0]] <= wr_d[SC_GSUM_W-1:0];
end

//========================================================================
// [E] 循环计数器：每拍发出一个抽头。
//
// 卷积层的循环从外到内是 oc, gy, gx, sy, sx, ic, ky, kx：
//   (gy,gx) 是池化后的输出位置，(sy,sx) 是池化窗口里的子位置，
//   卷积输出位置 = 2*g + s，输入位置再加 (ky,kx)。
//   L0  g 0..14  s 0..1   -> 卷积位置 0..29，全部
//   L2  g 0..5   s 0..1   -> 卷积位置 0..11，第 12 行/列被 L3 丢掉，不算
//   L4  g 0      s 0..3   -> 卷积位置 0..3，16 点求和代替池化
// 所以"2*g + s"对三层都成立（L4 的 g 恒为 0）。
//
// 权重地址：一个输出点内 (ic,ky,kx) 的顺序正好就是权重的存储顺序
// ((oc*CIN + ic)*3 + ky)*3 + kx，所以 wa 每拍加一，一个点结束时退回本 oc 的
// 起点 wbase；本 oc 最后一个点结束时 wa+1 恰好是下一个 oc 的起点。
//========================================================================
reg [4:0]  oc, ic;
reg [3:0]  gy, gx;
reg [1:0]  sy, sx, ky, kx;
reg [11:0] wa, wbase;
reg [3:0]  dcnt;

wire [4:0] lim_ci = (lay == 2'd0) ? (CI0 - 1) : (lay == 2'd1) ? (CI2 - 1) : (CI4 - 1);
wire [4:0] lim_co = (lay == 2'd0) ? (CO0 - 1) : (lay == 2'd1) ? (CO2 - 1) : (CO4 - 1);
wire [1:0] lim_s  = (lay == 2'd2) ? 2'd3 : 2'd1;
wire [3:0] lim_g  = (lay == 2'd0) ? 4'd14 : (lay == 2'd1) ? 4'd5 : 4'd0;

wire t_first = (ic == 5'd0)   && (ky == 2'd0) && (kx == 2'd0);
wire t_last  = (ic == lim_ci) && (ky == 2'd2) && (kx == 2'd2);
wire g_first = (sy == 2'd0)   && (sx == 2'd0);
wire g_last  = (sy == lim_s)  && (sx == lim_s);
wire oc_adv  = t_last && g_last && (gx == lim_g) && (gy == lim_g);
wire lay_end = oc_adv && (oc == lim_co);
wire issue   = (state == S_RUN);

wire [4:0] y0 = {gy, 1'b0} + sy + ky;
wire [4:0] x0 = {gx, 1'b0} + sx + kx;

// FC
reg [4:0]               fi;
reg [SC_GSUM_W-1:0]     fg;
reg signed [7:0]        fw0, fw1, fw2, fw3;
reg signed [31:0]       fp0, fp1, fp2, fp3;
reg signed [31:0]       lg0, lg1, lg2, lg3;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        state  <= S_IDLE;
        lay    <= 2'd0;
        lay_go <= 1'b0;
        dcnt   <= 4'd0;
        oc <= 5'd0; ic <= 5'd0; gy <= 4'd0; gx <= 4'd0;
        sy <= 2'd0; sx <= 2'd0; ky <= 2'd0; kx <= 2'd0;
        wa <= 12'd0; wbase <= 12'd0;
        fi <= 5'd0; fg <= {SC_GSUM_W{1'b0}};
        fw0 <= 8'sd0; fw1 <= 8'sd0; fw2 <= 8'sd0; fw3 <= 8'sd0;
        fp0 <= 32'sd0; fp1 <= 32'sd0; fp2 <= 32'sd0; fp3 <= 32'sd0;
        lg0 <= 32'sd0; lg1 <= 32'sd0; lg2 <= 32'sd0; lg3 <= 32'sd0;
        done        <= 1'b0;
        shape_class <= CLS_OTHER;
        class_valid <= 1'b0;
        logit0 <= 32'sd0; logit1 <= 32'sd0; logit2 <= 32'sd0; logit3 <= 32'sd0;
    end else begin
        done   <= 1'b0;
        lay_go <= 1'b0;

        case (state)

        //----------------------------------------------------------------
        S_IDLE: begin
            if (frame_tick) begin
                if (!roi_en) begin
                    // 这一帧采样时没有框：直接判 other，并标记无效
                    shape_class <= CLS_OTHER;
                    class_valid <= 1'b0;
                    logit0 <= 32'sd0; logit1 <= 32'sd0; logit2 <= 32'sd0; logit3 <= 32'sd0;
                    done   <= 1'b1;
                end else begin
                    // [C] 在同一拍拍下 roi_c，第一个读它的是 2 拍之后的 [F] S2
                    lay    <= 2'd0;
                    lay_go <= 1'b1;
                    oc <= 5'd0; ic <= 5'd0; gy <= 4'd0; gx <= 4'd0;
                    sy <= 2'd0; sx <= 2'd0; ky <= 2'd0; kx <= 2'd0;
                    wa <= 12'd0; wbase <= 12'd0;
                    state <= S_RUN;
                end
            end
        end

        //----------------------------------------------------------------
        // 每拍发出一个抽头，计数器推进一格。
        //----------------------------------------------------------------
        S_RUN: begin
            if (kx != 2'd2) kx <= kx + 2'd1;
            else begin
                kx <= 2'd0;
                if (ky != 2'd2) ky <= ky + 2'd1;
                else begin
                    ky <= 2'd0;
                    if (ic != lim_ci) ic <= ic + 5'd1;
                    else begin
                        ic <= 5'd0;
                        if (sx != lim_s) sx <= sx + 2'd1;
                        else begin
                            sx <= 2'd0;
                            if (sy != lim_s) sy <= sy + 2'd1;
                            else begin
                                sy <= 2'd0;
                                if (gx != lim_g) gx <= gx + 4'd1;
                                else begin
                                    gx <= 4'd0;
                                    if (gy != lim_g) gy <= gy + 4'd1;
                                    else begin
                                        gy <= 4'd0;
                                        // 一层结束时这里多加的一下无害，下一层开始会清零
                                        oc <= oc + 5'd1;
                                    end
                                end
                            end
                        end
                    end
                end
            end

            if (!t_last)     wa <= wa + 12'd1;
            else if (oc_adv) begin
                wa    <= wa + 12'd1;
                wbase <= wa + 12'd1;
            end
            else             wa <= wbase;

            if (lay_end) begin
                dcnt  <= DRAIN;
                state <= S_DRAIN;
            end
        end

        //----------------------------------------------------------------
        // 等流水线把这一层的最后一个结果写回，再开下一层。
        //----------------------------------------------------------------
        S_DRAIN: begin
            if (dcnt != 4'd0)
                dcnt <= dcnt - 4'd1;
            else if (lay == 2'd2) begin
                fi    <= 5'd0;
                lg0   <= SC_B6[0*32 +: 32];
                lg1   <= SC_B6[1*32 +: 32];
                lg2   <= SC_B6[2*32 +: 32];
                lg3   <= SC_B6[3*32 +: 32];
                state <= S_FC_RD;
            end else begin
                lay    <= lay + 2'd1;
                lay_go <= 1'b1;
                oc <= 5'd0; ic <= 5'd0; gy <= 4'd0; gx <= 4'd0;
                sy <= 2'd0; sx <= 2'd0; ky <= 2'd0; kx <= 2'd0;
                wa <= 12'd0; wbase <= 12'd0;
                state <= S_RUN;
            end
        end

        //----------------------------------------------------------------
        // L6 FC 16->4：一个输入通道三拍（读、乘、加），共 48 拍，换来四条
        // 互不相连的短路径。
        //----------------------------------------------------------------
        S_FC_RD: begin
            fg    <= gsum[fi[3:0]];
            fw0   <= SC_W6[(0*NFC + fi)*8 +: 8];
            fw1   <= SC_W6[(1*NFC + fi)*8 +: 8];
            fw2   <= SC_W6[(2*NFC + fi)*8 +: 8];
            fw3   <= SC_W6[(3*NFC + fi)*8 +: 8];
            state <= S_FC_MUL;
        end

        S_FC_MUL: begin
            fp0   <= fw0 * $signed({1'b0, fg});
            fp1   <= fw1 * $signed({1'b0, fg});
            fp2   <= fw2 * $signed({1'b0, fg});
            fp3   <= fw3 * $signed({1'b0, fg});
            state <= S_FC_ACC;
        end

        S_FC_ACC: begin
            lg0 <= lg0 + fp0;
            lg1 <= lg1 + fp1;
            lg2 <= lg2 + fp2;
            lg3 <= lg3 + fp3;
            if (fi == NFC - 1) state <= S_DONE;
            else begin
                fi    <= fi + 5'd1;
                state <= S_FC_RD;
            end
        end

        //----------------------------------------------------------------
        // argmax，相等取小编号。只有 roi_en = 1 的帧才会走到这里，所以
        // class_valid 恒为 1，和 shape_class 同一拍更新。
        //
        // 10-09 夜 四路：6 个比较都只读 lg 寄存器、互相独立，综合成 6 个并行的
        // 32 位比较器 + 一个 4 选 1 的优先级选择，深度和 3 路时一样。每一支
        // 只比它后面的编号，靠 else 的顺序保证"比前面的严格大"：例如走到
        // CIRCLE 时 0 号已落选，而 lg1 >= lg2、lg3，所以 lg0 < lg1。
        // 与 numpy 的 argmax（相等取第一个）逐位一致，tb 有平局用例。
        //----------------------------------------------------------------
        S_DONE: begin
            logit0 <= lg0; logit1 <= lg1; logit2 <= lg2; logit3 <= lg3;
            if ((lg0 >= lg1) && (lg0 >= lg2) && (lg0 >= lg3)) shape_class <= CLS_OTHER;
            else if ((lg1 >= lg2) && (lg1 >= lg3))            shape_class <= CLS_CIRCLE;
            else if (lg2 >= lg3)                              shape_class <= CLS_RECT;
            else                                              shape_class <= CLS_TRI;
            class_valid <= 1'b1;
            done  <= 1'b1;
            state <= S_IDLE;
        end

        default: state <= S_IDLE;

        endcase
    end
end

//========================================================================
// [F] MAC 流水线，每拍一个抽头。每级只做一件事：
//
//   S1  输入坐标、地址的常数乘部分、权重地址
//   S2  输入地址相加；ROI 取一行；三块权重 ROM 各读一次
//   S3  f1/f3 读出（RAM 的寄存读）；ROI 取一位；按 lay 选权重
//   S4  按 lay 选输入；取偏置
//   S5  8x9 乘
//   S6  累加（首个抽头从偏置开始）
//   S7  ReLU + 舍入常数
//   S8  移位 + 饱和到 uint8
//   S9  池化取最大 / L4 求和（[G]）
//   S10 写回（[D]）
//
// 控制位 v/tf/tl/gf/gl 跟着数据走，下标 k 就是第 k 级。
//========================================================================
reg [8:1] v_p, tf_p, tl_p, gf_p, gl_p;
reg [4:0] oc_p1, oc_p2, oc_p3;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        v_p  <= 8'd0; tf_p <= 8'd0; tl_p <= 8'd0;
        gf_p <= 8'd0; gl_p <= 8'd0;
        oc_p1 <= 5'd0; oc_p2 <= 5'd0; oc_p3 <= 5'd0;
    end else begin
        v_p   <= {v_p[7:1],  issue};
        tf_p  <= {tf_p[7:1], t_first};
        tl_p  <= {tl_p[7:1], t_last};
        gf_p  <= {gf_p[7:1], g_first};
        gl_p  <= {gl_p[7:1], g_last};
        oc_p1 <= oc;
        oc_p2 <= oc_p1;
        oc_p3 <= oc_p2;
    end
end

reg [4:0]         y1, x1;
reg [10:0]        icH1;
reg [7:0]         yH1;
reg [11:0]        wa1;

reg [31:0]        roirow2;
reg [4:0]         roix2;
reg [7:0]         w0r2, w2r2, w4r2;

reg               roib3;
reg [7:0]         wq3;

reg [7:0]         xs4;
reg signed [7:0]  ws4;
reg signed [31:0] bias4, bias5;

reg signed [16:0] prod5;
reg signed [31:0] acc6;
reg [32:0]        r7;
reg [7:0]         y8;

wire [32:0] rnd_cur = (lay == 2'd0) ? RND0 : (lay == 2'd1) ? RND2 : RND4;

always @(posedge clk) begin
    //---- S1 ----
    // L2 读 f1：(ic*15 + y)*15 + x = ic*225 + y*15 + x
    // L4 读 f3：(ic*6  + y)*6  + x = ic*36  + y*6  + x
    // L0 不用这条地址（读 roi_c），算出来的值落在 f1/f3 范围内，读了也无害。
    y1   <= y0;
    x1   <= x0;
    icH1 <= (lay == 2'd1) ? (ic * 8'd225) : (ic * 6'd36);
    yH1  <= (lay == 2'd1) ? (y0 * 4'd15)  : (y0 * 3'd6);
    wa1  <= wa;

    //---- S2 ----
    iaddr2  <= icH1 + yH1 + x1;
    roirow2 <= roi_c[y1*32 +: 32];
    roix2   <= x1;
    w0r2    <= W0P[wa1[6:0]  * 8 +: 8];
    w2r2    <= W2P[wa1[10:0] * 8 +: 8];
    w4r2    <= W4P[wa1       * 8 +: 8];

    //---- S3 ----（f1_q / f3_q 在 [D] 里于这一拍落地）
    roib3 <= roirow2[roix2];
    wq3   <= (lay == 2'd0) ? w0r2 : (lay == 2'd1) ? w2r2 : w4r2;

    //---- S4 ----
    // L0 的输入就是 0/1，不是 0/255：golden model 里 roi_sample 出来的就是 0/1。
    xs4   <= (lay == 2'd0) ? {7'd0, roib3} : (lay == 2'd1) ? f1_q : f3_q;
    ws4   <= wq3;
    bias4 <= (lay == 2'd0) ? B0P[oc_p3[3:0]*32 +: 32]
           : (lay == 2'd1) ? B2P[oc_p3[3:0]*32 +: 32]
           :                 B4P[oc_p3[3:0]*32 +: 32];

    //---- S5 ----
    prod5 <= ws4 * $signed({1'b0, xs4});
    bias5 <= bias4;

    //---- S6 ----
    if (v_p[5]) acc6 <= (tf_p[5] ? bias5 : acc6) + prod5;

    //---- S7 ----（只有 tl_p[6] 那一拍的 acc6 是完整的，其余拍算了也不用）
    r7 <= (acc6[31] ? 33'd0 : {1'b0, acc6}) + rnd_cur;

    //---- S8 ----
    y8 <= (lay == 2'd0) ? rq_sat(r7, SC_SH0)
        : (lay == 2'd1) ? rq_sat(r7, SC_SH2)
        :                 rq_sat(r7, SC_SH4);
end

//========================================================================
// [G] S9：池化 / 求和，并产生写回。
//
// 只在一个卷积点完成（tl）时动作。L0/L2 对一组 2x2 取滚动最大值，L4 对一组
// 4x4 求和；一组结束（gl）时把结果交给 [D] 写回，写指针加一。requant 的输出
// 都 >= 0，所以"组内第一个直接取值、其后取 max"和先存后池化逐位一致。
//
// 求和最大 16 x 255 = 4080，写 gsum 时截到 SC_GSUM_W 位，与上一版的 L5 相同。
//========================================================================
reg  [15:0] red;
reg  [10:0] wptr;

wire [15:0] y8w    = {8'd0, y8};
wire [15:0] red_nx = gf_p[8]        ? y8w
                   : (lay == 2'd2)  ? (red + y8w)
                   : (y8w > red)    ? y8w : red;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        red   <= 16'd0;
        wptr  <= 11'd0;
        wr_en <= 1'b0;
        wr_a  <= 11'd0;
        wr_d  <= 16'd0;
    end else begin
        wr_en <= 1'b0;
        if (lay_go)
            wptr <= 11'd0;            // 此时上一层已排空，不会有写回在途
        else if (v_p[8] && tl_p[8]) begin
            red <= red_nx;
            if (gl_p[8]) begin
                wr_en <= 1'b1;
                wr_a  <= wptr;
                wr_d  <= red_nx;
                wptr  <= wptr + 11'd1;
            end
        end
    end
end

endmodule