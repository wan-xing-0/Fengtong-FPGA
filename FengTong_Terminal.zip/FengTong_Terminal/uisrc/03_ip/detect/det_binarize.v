//---------------------------------------------------------------------------
// det_binarize -- luma plus a per-frame adaptive threshold.  Front end of the
// L5 analysis layer: everything downstream of here works on one bit per pixel.
//
// WHY IT TAPS THE AFFINE OUTPUT
//   The branch is fed af_out_*, between affine_transform and the effect wheel,
//   and all three properties that picks are load-bearing:
//
//     * DOWNSTREAM OF MORPHOLOGY, so the erode/dilate key is available as
//       detection pre-processing -- which is what the brief's inspection mode
//       actually wants it for, rather than as a visual effect.
//     * DOWNSTREAM OF AFFINE, so the coordinates the analysis produces are
//       display coordinates.  Boxes drawn at the tail of the chain then land
//       on the object with no transform to undo.  Tap upstream of affine and
//       every rotate/zoom position puts the boxes somewhere else.
//     * UPSTREAM OF THE WHEEL, so detection does not change when the wheel
//       moves.  HISTEQ, MARBLE, WOOD and NEG each rewrite the pixel values the
//       threshold is measuring; detection would otherwise be a function of
//       which effect is being demonstrated.
//
//   Consequence worth knowing: in a non-pass affine position the picture
//   outside the 1024x1024 centre window is black, so detection is confined to
//   that window.  In the pass position (the demo default) the window is the
//   whole frame.  That is correct behaviour rather than a limitation -- the
//   analysis sees exactly what the screen shows.
//
// WHY THE WINDOW MEAN STILL CONTAMINATES ITSELF -- 2026-09-18, ROUND 5, AND
// IT IS A CORRECTION TO THE BLOCK BELOW RATHER THAN A REPLACEMENT OF IT
//
//   The 09-17 wide box mean went to the board and the servo came alive: MARGIN
//   moved over 16..66 instead of sitting on 112, the polarity read B on bright
//   objects, and a single object at a comfortable distance got a clean box.
//   The box block below is right about everything it claims.  What it got
//   wrong is how much headroom "linear degradation" leaves.
//
//   The three bench complaints that came back were ONE mechanism:
//
//     * a single object had to be held at a distance -- too close and it
//       vanished entirely;
//     * two objects had to be kept apart, and worked less well than one;
//     * three objects barely worked at all.
//
//   Let f be the fraction of the 512x576 REFERENCE WINDOW that objects cover.
//   The window mean is then bg + f*(obj - bg), so the contrast the compare
//   actually sees is (1 - f) * the true contrast.  That is the block below's
//   own formula, and it is exactly the problem:
//
//     one object, arm's length         f ~ 0.2   ->  80% of the contrast
//     one object, held close           f -> 1.0  ->  NOTHING
//     two objects within one window    f ~ 0.5   ->  50%
//     three                            f ~ 0.7   ->  30%
//
//   "Keep the objects apart" is the user discovering by hand that two objects
//   in DIFFERENT windows do not share an f.  Nothing about that is tunable:
//   widening the window lowers f only linearly and gives up spatial resolution
//   for it, and the too-close case defeats any finite window.
//
//   THE FIX IS TO STOP LETTING AN OBJECT INTO ITS OWN REFERENCE.  A block
//   whose mean has already moved object-wards by more than OBJ_GAP is, by that
//   fact, not background, and it is not allowed to supply its own value to any
//   window that taps it -- the window reads bg_lvl instead (see [3d]).  The
//   tap COUNT is unchanged, so the divide stays a shift and there is no
//   reciprocal and no divider anywhere in this path.
//
//   What that buys, same four scenes:
//
//     one object, arm's length         ~100%   (nothing to exclude nearby)
//     one object, held close           ~100%   (window reads bg_lvl outright)
//     two objects within one window    ~100%
//     three                            ~100%
//
//   and the residual error is no longer f at all -- it is only how well bg_lvl
//   estimates the background, which is a MEDIAN over the blocks the object is
//   not on and therefore does not move when the object grows.
//
//   WHY OBJ_GAP IS NOT POL_GAP.  POL_GAP (12) only has to clear the wobble of
//   a 9216-sample mean.  This test has to clear the LENS SHADING, which on
//   this lens is tens of counts -- a dark corner is background and excluding
//   it would substitute the global level there and undo the whole reason the
//   reference is local.  48 is above the shading and well below what an object
//   does to a block it covers.  They are separate parameters on purpose; do
//   not "simplify" them into one.
//
//   THE LIMIT, STATED HONESTLY.  Once objects own more than half the block
//   grid, the median IS the object and so is the polarity vote's majority.
//   Both break at the same point, which is the real boundary of any
//   single-frame spatial method.  Past it the only answers are a temporal
//   background model (which forgets objects that stop moving, so it is wrong
//   for this demo) or a lens-shading correction plus a fixed threshold.
//
// WHY THE REFERENCE IS A WIDE BOX MEAN -- 2026-09-17, AND THIS REPLACES BOTH
// EARLIER ANSWERS.  READ THIS ONE; THE TWO BLOCKS AFTER IT ARE HISTORY.
//
//   Round 3 (09-09) thresholded against the pixel's OWN BLOCK's mean.  A block
//   is 128x72 = 9216 px, so anything bigger COVERS blocks, a covered block's
//   mean IS the object, and the contrast collapses exactly where the object is
//   most solid.  The bench saw outlines: rim yes, middle no.
//
//   Round 4 (09-10) replaced that with a 3x3-block max/min and then OR'd the
//   frame mean back in, so a pixel was foreground if it stood out from its
//   neighbourhood OR from the frame.  That is what the 09-16 bench photos show,
//   and no parameter reaches it:
//
//     * A max over a 3x3 block window is a max over ~83,000 samples.  One
//       bright object -- or one specular glint -- pins it at 255 over a region
//       one block LARGER than the object.  Inside that region thr_dark is
//       255 - margin, so the perfectly ordinary dark background AROUND a bright
//       object is all "dark foreground".  That is a HALO, and it is bigger than
//       the object that caused it.
//     * dk_cnt then beats bt_cnt, the old pixel-count polarity rule picks DARK,
//       and what gets boxed is the halo, not the object.  Every 09-16 photo
//       reads "MARGIN 112 D": the servo saturated fighting a halo it could not
//       win against, and the few boxes that did appear sit around the object
//       with a visible gap because they are the halo's bounding box.
//     * Add a second object and the halos push fg_cnt past FG_MAX, the brake
//       empties the mask, and TARGETS reads 0 with objects plainly in frame --
//       which is "multiple objects are worse than one", exactly.
//
//   The reference has to be a BACKGROUND estimate: something the object cannot
//   pull towards itself, AND that no single bright or dark pixel can move.  A
//   mean cannot be moved by one pixel; the way to stop the object moving it is
//   to make the support much larger than the object.  So:
//
//     ref(x,y) = mean of the block means over a WIN_NX x WIN_NY block window
//                around the pixel's block        (4 x 8 blocks = 512 x 576 px)
//     dark  objects:  gray <  ref - margin
//     bright objects: gray >  ref + margin
//
//   i.e. a coarse Bradley threshold against a heavily low-passed copy of the
//   frame -- which is what WHAT THIS MODULE STILL CANNOT DO below already named
//   as the real fix.  Properties worth knowing:
//
//     * AN OBJECT COVERING FRACTION f OF THE WINDOW attenuates its own contrast
//       by (1-f) instead of destroying it.  A 410x396 px object (the earbud
//       case in the 09-16 photos) covers 55% of the window, so 200 counts of
//       object still presents 90.  It degrades along a slope; an extreme falls
//       off a cliff.
//     * THE VIGNETTE IS STILL ABSORBED: 512x576 px of support against a shading
//       field that spans the whole frame.
//     * NO HALO.  A mean pulled up by a nearby bright object raises BOTH
//       decision levels by the same amount, so the wrong-polarity side is only
//       sensitised where the pull exceeds margin -- and the polarity rule below
//       no longer lets that side be selected anyway.
//     * 32 taps, so the window divide is a shift.  WIN_NX*WIN_NY MUST stay
//       equal to 1<<WIN_SH.
//     * The block mean itself does need a divide by BLK_W*BLK_H, and 9216 is
//       not a power of two -- MEAN_PRE/MEAN_MUL/MEAN_POST are it.  Reshaping
//       the grid means recomputing those three.  That trap is back; it was gone
//       only while the statistic was max/min.
//
// SUPERSEDED, KEPT FOR THE HISTORY --
// WHY THE REFERENCE IS AN EXTREME AND NOT A MEAN -- 2026-09-09 ROUND 4, AND
// THIS IS THE ONE THAT EXPLAINS EVERY BENCH PHOTO SO FAR
//   Round 3 replaced the frame mean with the pixel's OWN BLOCK's mean, which
//   was the right idea aimed at the wrong statistic, and the bench said so
//   immediately: objects came out as OUTLINES.  A black coaster on a white
//   board drew four little boxes on its rim and nothing on its middle; a black
//   and a red object together were detected almost nowhere.
//
//   The reason is arithmetic, not tuning.  A block is 128x72 = 9216 pixels,
//   and any object bigger than that COVERS blocks completely.  A covered
//   block's mean IS the object, so |pixel - mean| collapses to zero exactly
//   where the object is most solid.  Only the rim blocks -- part board, part
//   object -- hold a mean that either side can clear.  The reference had
//   become a function of the thing it was supposed to measure against, so the
//   detector could only ever see boundaries.  Turn the object into two objects
//   and it gets worse, because more blocks are fully covered.
//
//   Everything else on the bench sheet is downstream of that one fact.  An
//   outline is a THIN, BRANCHING mask, which is the worst possible input to
//   ccl_blob: every arc of it becomes its own provisional label, the 1024-pair
//   merge list fills ('M' on the OSD), the frame-end passes run out of
//   blanking ('T'), and on a 'T' frame the previous frame's boxes stay on
//   screen -- the lingering that looked like a separate bug.  One object, many
//   long thin boxes.
//
//   So the reference has to be a BACKGROUND estimate, meaning one the object
//   cannot pull towards itself.  The cheap statistic with that property is an
//   extreme: on a light board the background is the BRIGHTEST thing around, on
//   a dark mat it is the DARKEST, and a dark object can no more raise a
//   neighbourhood maximum than a bright one can lower a minimum.
//
//     dark  objects:  gray <  (max of the 3x3 block window) - margin
//     bright objects: gray >  (min of the 3x3 block window) + margin
//
//   which is a coarse TOP-HAT transform.  Three consequences worth knowing:
//
//     * 3x3 BLOCKS, NOT ONE.  A single block's own max still fails when the
//       object covers it completely.  The window is 384x216 px, so an object
//       has to fill that before it can starve its own reference -- and the
//       nine windows of nine adjacent blocks overlap in six, so the reference
//       field is an envelope that creeps rather than a mosaic that steps.
//       That is the answer to the block-boundary-artefact objection this
//       comment used to raise against block-local thresholds: it applied to
//       means, whose value jumps the moment an object enters the block.
//
//     * IT IS AN EXTREME OF ~83,000 SAMPLES, so it sits at the top of the
//       NOISE, not at the middle of it -- about +4.4 sigma, ~9 counts at the
//       grain this sensor delivers.  MARGIN therefore starts 9 counts into its
//       own budget and everything below MARGIN_MIN - 9 counts of excursion
//       reads as background.  A single stuck-dark pixel can still trip; that
//       is det_morph_open's job and it already does it.
//
//     * A SPECULAR GLINT RAISES THE MAXIMUM and desensitises its window.  That
//       is a MISS, not a false blob -- the direction that costs a target
//       rather than the direction that fills the merge list -- so it degrades
//       the way this pipeline can absorb.
//
//   It also retires two known traps for free.  The vignette ring is gone,
//   because a corner is now measured against its own corner.  And the black
//   surround of a non-pass F8 position can no longer be a target: those blocks
//   have max = 0, so thr_dark clamps to 0 and nothing is below it, while
//   min = 0 puts thr_brt at the margin and black is not above that either.
//
// WHY THERE IS A DEAD ZONE AND NOT JUST "COMPARE AGAINST THE MEAN"
//   Plain mean thresholding assumes the scene is half object.  It is not -- a
//   few parts on a bench are a few percent -- so the mean sits essentially at
//   the background level and sensor noise alone puts half the background over
//   the line.  MARGIN moves the decision level clear of the background by a
//   fixed amount, which is what makes the mask empty when nothing is there
//   instead of a field of speckle.
//
// POLARITY IS DECIDED ON BLOCKS, NOT PIXELS -- 2026-09-17
//   Dark parts on a white sheet and a bright part on a dark mat are both
//   plausible demos, and picking wrong detects nothing.  The block below is
//   still right that "flip if the foreground is over half the frame" can never
//   fire (with the polarity backwards the mask is EMPTY, not inverted), and it
//   is still right that both sides have to be measured every frame.  What is
//   wrong is measuring them in PIXELS: with any local reference the
//   wrong-polarity side carries a halo whose area is comparable to the object,
//   so dk_cnt and bt_cnt are contaminated by construction and cannot arbitrate.
//   That is precisely how the 09-16 build ended up with fg_dark=1 ("D" on the
//   OSD) while looking at bright objects on a dark desk.
//
//   The block means computed for the reference are NOT contaminated -- an
//   object raises its own blocks and nothing else -- and they are already
//   there.  So during the sum-to-mean pass, once per frame:
//
//     n_hi = blocks whose mean is more than POL_GAP ABOVE the frame mean
//     n_lo = blocks whose mean is more than POL_GAP BELOW it
//
//   and THE OBJECT IS THE MINORITY SIDE.  Not the bigger one -- the frame mean
//   is dragged by whatever is in frame, so a bright object lifts the mean above
//   the desk and it is the DESK that ends up deviating, in the hundreds of
//   blocks, against a few tens for the object.  The scene assumption this
//   module has always carried (objects are a few percent of the picture) says
//   the majority is the background.  Two special cases matter and both are
//   written out at the decision: a side with ZERO blocks is not a minority (a
//   small object leaves the background inside the deadband, so one-sided means
//   the side that voted is the object), and a TIE carries no information at all
//   -- a pure shading gradient votes symmetrically -- so it defers to the pixel
//   counts rather than holding a stale answer.
//
//   Cost: two counters in a pass that runs 225 times per FRAME, and NOTHING on
//   the pixel path.  FORCE_POL still pins it.
//
// SUPERSEDED, KEPT FOR THE HISTORY --
// POLARITY FINDS ITSELF -- AND THE OBVIOUS RULE FOR IT IS WRONG
//   Dark parts on a white sheet and a bright part on a dark mat are both
//   plausible demos, and picking wrong means detecting nothing.
//
//   The tempting rule is "flip if the foreground came out as more than half
//   the frame".  It does not work, and it is worth writing down why: with the
//   polarity backwards on a dark object over a light background, the mask is
//   not the inverse of the right answer, it is EMPTY.  The threshold is
//   mean+MARGIN and nothing in the scene is above it.  Zero never trips a
//   "more than half" test, so that rule leaves the polarity stuck forever.
//
//   So both sides are counted every frame, unconditionally and independently
//   of which one is currently selected:
//
//     dk_cnt = pixels below mean-MARGIN      bt_cnt = pixels above mean+MARGIN
//
//   and the object is the side with MORE pixels -- unless that side is over
//   half the frame, in which case it is the background and the other side is
//   the object.  Both counts near zero (an empty bench) means there is nothing
//   to decide, so POL_FLOOR holds the current choice rather than letting the
//   two noise counts dither it.
//
//   Two 21-bit counters and one extra 8-bit compare, and it removes a
//   re-synthesise-and-burn cycle from every change of demo surface.
//   FORCE_POL pins it if a scene ever really is more than half object.
//
// WHAT THIS MODULE STILL CANNOT DO -- READ THIS BEFORE TUNING MARGIN
//   The claim above that a lighting gradient "is already being flattened
//   upstream by isp_auto_level" is WRONG, and the 2026-09-07 bench run is what
//   showed it.  isp_auto_level is a global tone curve: it stretches the
//   0.5%/99.5% points of the whole frame.  It does nothing whatever to a
//   SPATIAL gradient, and on a plain wall -- where the only content in the
//   frame IS the vignette -- it takes that gradient and stretches it to fill
//   0..255, which makes this module's job strictly harder rather than easier.
//
//   So MARGIN is a noise-floor control and nothing more.  Raising it buys
//   immunity to sensor grain and costs low-contrast targets; it will never buy
//   immunity to shading, because at high enough gain the shading spans the
//   whole range.  The two things that actually handle shading are downstream
//   and are shape tests, not level tests: det_morph_open removes what is thin
//   and ccl_blob's MAX_W/MAX_H/FILL_SHIFT remove what is frame-sized or hollow.
//   FG_MAX below is the last-resort brake for when even those are not enough.
//
//   The real fix, if this is ever revisited, is a lens-shading correction or a
//   threshold measured against a heavily low-passed copy of the frame.  There
//   is no shading correction anywhere in this ISP chain today.
//
// THE MARGIN IS A SERVO NOW -- 2026-09-08, AND THIS IS WHAT THE SECOND BENCH
// RUN FORCED
//   The 09-07 fixes traded one failure for another.  With MARGIN pinned at 32
//   on a dim bench surface the mask still came out as a frame-wide lace, so:
//   the 1024-entry merge list filled ('M' on the OSD), everything fused into
//   one giant component, and the 09-07 shape tests correctly threw that
//   component out -- TOGETHER WITH THE REAL OBJECT THAT HAD MERGED INTO IT.
//   The screen read '0 TARGETS' with an obvious target in frame, and the two
//   F9 positions that only differ by the boxes looked identical to the two
//   that do not.  Honest, and useless.
//
//   No fixed MARGIN can be right here, because the number it has to clear is
//   isp_auto_level's output noise floor, and that moves with the scene: the
//   auto-level gain on a dim surface is several times what it is on a lit one.
//   A constant tuned for one bench is wrong on the next.
//
//   So the margin is closed-loop.  Once a frame the count on the SELECTED side
//   is compared against a target band and the margin steps one notch:
//
//     fg > FG_HI  ->  margin += MARGIN_STEP   (mask too full: tighten)
//     fg < FG_LO  ->  margin -= MARGIN_STEP   (mask too empty: loosen)
//     otherwise       hold
//
//   That is an integral controller whose fixed point is "the foreground is a
//   fixed fraction of the frame" -- i.e. a PERCENTILE threshold, which is what
//   this always wanted to be, without a histogram, a sort or a divider.  The
//   band between FG_LO and FG_HI is the deadband; inside it nothing moves, so
//   there is no limit cycle while a scene is behaving.
//
//   WHY IT CANNOT BE WORSE THAN THE FIXED VERSION.  MARGIN_MIN is the floor and
//   also the reset value, and it is the old constant.  The loop can only ever
//   raise the margin above what 09-07 shipped, never below it, so no scene that
//   works today can be broken by it.  ADAPT_EN = 0 pins it at the floor for an
//   A/B on the bench without a rebuild.
//
//   WHY A HIGH-CONTRAST TARGET SURVIVES THE CLIMB.  The margin walks up until
//   the NOISE stops crossing the line.  A part that is genuinely darker or
//   brighter than the surface is tens of counts clear of the mean, so raising
//   the decision level from 32 to 112 erodes its soft edge and nothing else.
//   What the loop deletes is exactly the population it should: the low-
//   amplitude field that was fusing everything into one component.
//
//   WHY IT CANNOT RUN AWAY.  Both ends clamp, and both ends self-correct: at
//   MARGIN_MAX on a scene that is genuinely more than FG_HI object, the loop
//   just saturates and FG_MAX still brakes; at MARGIN_MIN on an empty scene
//   fg is zero, which is below FG_LO, and the loop simply stays on the floor.
//   Convergence over the whole range is (MAX-MIN)/STEP = 40 frames, 0.7 s.
//
//   dbg_margin is on a port and on the OSD, because the first bench question
//   is now "where did the servo settle" and that has to be readable without
//   ChipWatcher.  A reading pinned at MARGIN_MAX means the loop ran out of
//   travel and the next lever is the shape tests or a real shading correction.
//
//   TIMING NOTE.  The margin update and the threshold update are on SEPARATE
//   clocks -- margin at frame_tick, thresholds one clock later off the latched
//   mean.  That is not tidiness: folding them together would put a 21-bit
//   compare, an 8-bit add and an 8-bit subtract in series on one edge, and this
//   clock group closes at +0.058ns.  Splitting them makes the threshold path
//   SHORTER than it was before this change, because it now starts at a
//   register instead of at the 29-bit frame_sum adder.  There are thousands
//   of spare clocks in this module's blanking window; one of them is free.
//   (That window is 11,000 clocks and not the 99,000 this comment used to
//   say -- see [3c]'s budget note.  The conclusion is unchanged.)
//
// NO DIVIDER
//   The frame mean is frame_sum >> MEAN_SHIFT rather than a divide by the
//   pixel count.  At 1080p that is >> 21 against 2073600, so the shift
//   under-reports the mean by 1.14% -- against a MARGIN of tens of counts,
//   not a measurable error, and it buys back the ~1500 LUT a 29-bit divider
//   costs on this device (see the awb.v note in the handover: 97% of that
//   module's area is three dividers).
//
// LATENCY 3 clocks on data, de and vs alike.  px/py are rebuilt from the
// delayed de/vs rather than delayed themselves, so they cannot drift out of
// step with the bit they belong to.
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module det_binarize #(
parameter integer IMG_HDISP = 1920,
parameter integer IMG_VDISP = 1080,

// Distance from the frame mean to the decision level, in 8-bit luma counts.
// Bigger = fewer, cleaner blobs; smaller = catches low-contrast parts and more
// noise with them.
//
// 2026-09-08: renamed from MARGIN, because it is now the FLOOR and the reset
// value of a servo rather than the operating point -- see THE MARGIN IS A
// SERVO NOW.  The rename is deliberate: leaving it called MARGIN would let a
// future edit set it thinking it pins the threshold, which it no longer does.
// The loop can only ever move the decision level away from the noise floor,
// never towards it, so this value remains the worst case the design will run.
parameter [7:0]   MARGIN_MIN = 8'd24,

// Ceiling on the same servo.  112 is ~44% of full scale; past that thr_dark
// clamps at 0 or thr_brt at 255 and the loop is measuring nothing, so there is
// no point letting it climb further.  A reading pinned here on the bench means
// the level test has run out of travel and the next lever is downstream shape
// rejection or a real lens-shading correction.
parameter [7:0]   MARGIN_MAX = 8'd112,

// One notch per frame.  2 crosses the whole range in 44 frames (0.73 s), which
// is fast enough that nobody watching sees it hunt and slow enough that a hand
// waved through frame cannot drag the level anywhere it will not walk back
// from within the same second.
parameter [7:0]   MARGIN_STEP = 8'd2,

// The target band for the selected side's pixel count.  Defaults are 1/8 of a
// 1080p frame and 1/1024 of one:
//
//   above FG_HI  the mask is too full to be objects -- it is a field, and a
//                field is what fuses everything into one component
//   below FG_LO  the mask is emptier than the smallest thing worth reporting
//                (1/1024 frame is about 45x45 px, half of MIN_AREA's 32x32
//                twice over), so there is room to loosen
//
// Between them nothing moves.  Widening the band makes the loop lazier, not
// more stable -- it is already unconditionally stable, being an integrator
// against a monotone plant.
//
// 2026-09-17: FG_HI raised from 1/8 frame to 1/5.  With the halo gone, fg_cnt
// is the object area and nothing else, and THREE ordinary desk objects already
// add up to more than 1/8 of a 1080p frame -- which would have the servo read
// "success" as "too full" and tighten until they disappeared.  The band has to
// be wide enough that the demo itself does not push through the top of it.
parameter [20:0]  FG_HI      = 21'd414720,
parameter [20:0]  FG_LO      = 21'd2025,

// 0 pins the margin at MARGIN_MIN, i.e. exactly the pre-09-08 behaviour.  For
// an A/B on the bench without a rebuild, and for any testbench that wants a
// fixed threshold.
parameter integer ADAPT_EN   = 1,

//---------------------------------------------------------------------------
// THE LOCAL REFERENCE GRID -- 2026-09-09.  See section [3b] for why a single
// frame mean cannot work on this lens; these are its geometry.
//
// Deliberately the grid motion_frame_drawer has been running since 09-05: 15
// columns of 128 px by 15 rows of 72.  1080 = 15*72 exactly, so unlike most
// tilings of a 1080p frame this one has no ragged last row whose mean would
// be computed over the wrong divisor.  Reusing it also makes the column index
// free (px[10:7]) and means one bench-proven geometry instead of two.
//
// BLK_W must stay a power of two and BLK_W_LOG2 must match it -- the column
// index is a shift and the in-block column is a bit slice, both sized from
// it. BLK_H is counted, so it need not be a power of two.
//
// ⚠ 2026-09-17: THE RECIPROCAL TRAP IS BACK.  Round 4 could say "max and min
// do not divide"; a mean does.  MEAN_PRE/MEAN_MUL/MEAN_POST below encode
// 1/(BLK_W*BLK_H) and Verilog cannot derive them, so RESHAPING THE GRID MEANS
// RECOMPUTING ALL THREE or every threshold is off by a scale factor.
// N_COLS and N_ROWS must still be <= 15: the block coordinates in [3c] are
// 4-bit.
//---------------------------------------------------------------------------
parameter integer BLK_W      = 128,
parameter integer BLK_W_LOG2 = 7,
parameter integer BLK_H      = 72,
parameter integer N_COLS     = 15,
parameter integer N_ROWS     = 15,

//---------------------------------------------------------------------------
// THE REFERENCE WINDOW -- 2026-09-17.  How many blocks of block-mean get
// averaged into one pixel's background level.
//
// 4 WIDE x 8 TALL, and the asymmetry is the point: a block is 128 x 72 px, so
// 4 x 8 blocks is 512 x 576 PIXELS -- very nearly square on the screen, which
// is what a background estimate should be.  An equal 6 x 6 would be 768 x 432,
// i.e. flat, and would starve faster on a tall object than on a wide one.
//
// WHY THIS SIZE.  The largest object in the 09-16 photos is about 420 x 510 px
// (the charger), so it covers 73% of this window and presents 27% of its own
// contrast.  These are near-saturated objects on a dark desk -- 200 counts of
// contrast -- so 27% is still 54 counts, more than 3x the MARGIN floor.  It
// works with room to spare on the worst case actually photographed, and stays
// well under half the frame width so that a background STEP (a table edge, a
// shadow line) can never dominate the estimate.
//
// ⚠ WIN_NX * WIN_NY MUST EQUAL 1 << WIN_SH.  The window divide is that shift
// and nothing checks it.  Both must also stay <= 8: cv_kx/cv_ky are 3-bit, and
// WIN_NY=8 is already at that limit.
//
// WIN_OX/WIN_OY are where the window sits relative to the centre block.  With
// an EVEN tap count it cannot be centred, so it is biased half a block one
// way.  64 px / 36 px of bias in a BACKGROUND estimate is not measurable;
// making the count odd to avoid it would cost a divider, which is.
//
// WHICH WAY TO TUNE IT, and these fail differently:
//   blobs hugging a strong background edge, or the mask sensitised in a band
//     next to a shadow  -> window too big, go to 4 x 4 (WIN_NY=4, WIN_SH=4,
//     WIN_OY=2)
//   a BIG object still coming out as a ring, or still missed in the middle
//     -> window too small, go to 8 x 8 (WIN_NX=8, WIN_SH=6, WIN_OX=4); costs
//     14400 clocks of blanking instead of 7200, still 7x inside budget
// Try these before touching MARGIN -- MARGIN is a noise-floor control and
// cannot buy either of them.
//---------------------------------------------------------------------------
parameter integer WIN_NX     = 4,
parameter integer WIN_NY     = 8,
parameter integer WIN_SH     = 5,      // log2(WIN_NX*WIN_NY)
parameter integer WIN_OX     = 2,
parameter integer WIN_OY     = 4,

// Block mean = ((sum >> MEAN_PRE) * MEAN_MUL) >> MEAN_POST.
// For 128*72 = 9216:  57/(2^19) = 1/9203.5, i.e. 0.14% high, against a
// >>MEAN_PRE truncation that is low by the same order -- the two partly
// cancel and the residue is under one count over the whole range.  57 is
// 32+16+8+1, so the "multiply" is three adds if the tool does not spend a DSP.
parameter integer MEAN_PRE   = 10,
parameter [6:0]   MEAN_MUL   = 7'd57,
parameter integer MEAN_POST  = 9,

// Width of one block's pixel sum.  BLK_W*BLK_H*255 must fit: 9216*255 =
// 2350080 needs 22.  A parameter and not a localparam because a bench that
// shrinks the block wants to shrink the RAM with it, and because the
// MEAN_PRE slice below is taken from the top of exactly this width.
parameter integer BSW        = 22,

// 0 = threshold against the scalar frame mean, i.e. exactly the pre-09-09
// behaviour that produced the 09-08 bench photos.  The block pass still runs
// (leaving it running costs nothing and keeps the RAMs' timing identical), the
// pixel compares just come off the scalar levels instead.  This is here so the
// change can be A/B'd against the build it replaces without re-deriving
// anything, the same way BG_SHIFT=0 degrades motion detection to its old
// algorithm exactly.
parameter integer LOCAL_EN = 1,

// log2 of the pixel count, rounded UP: the mean is a shift, not a divide.
// 21 for 1920x1080 (2^21 = 2097152 against 2073600).  MEAN_SHIFT+7 must stay
// within frame_sum's 29 bits.
//
// 2026-09-09: with LOCAL_EN=1 the frame mean no longer thresholds anything.
// It is kept because it still drives dbg_thresh, so a ChipWatcher trace taken
// across this change is still comparable, and because LOCAL_EN=0 needs it.
parameter integer MEAN_SHIFT = 21,

// Below this many pixels on both sides there is nothing in frame worth
// deciding about, so the polarity holds instead of following noise.
//
// 2026-09-17: this governs the LOCAL_EN=0 datapath ONLY.  With LOCAL_EN=1 the
// polarity is voted on blocks and POL_GAP/POL_BLK are its knobs -- see
// POLARITY IS DECIDED ON BLOCKS.  It is kept so that LOCAL_EN=0 still means
// "bit-exact pre-09-09 behaviour" and not "mostly that".
parameter integer POL_FLOOR  = 64,

// POLARITY VOTE, 2026-09-17 -- the LOCAL_EN=1 replacement for POL_FLOOR,
// which counted pixels and could not be trusted once a local reference
// existed (see POLARITY IS DECIDED ON BLOCKS).
//
// POL_GAP: how far a BLOCK MEAN has to sit from the frame mean before that
// block votes.  12 counts is comfortably above the frame-to-frame wobble of a
// 9216-sample mean and far below what any object in frame does to its block.
// POL_BLK: the lead one side needs over the other to change the decision.  0
// would let a single block flip the demo; 1 is the smallest useful hysteresis
// and stacks with the two-frame flip_cnt below.
parameter [7:0]   POL_GAP    = 8'd12,
parameter [7:0]   POL_BLK    = 8'd1,

//------------------------------------------------------------------------
// OBJECT-BLOCK EXCLUSION -- 2026-09-18, and it is the whole point of this
// revision.  Read WHY THE WINDOW MEAN STILL CONTAMINATES ITSELF in the
// header before touching any of the three.
//
// OBJ_EXCL: 1 = a block whose own mean has moved OBJECT-WARDS by more than
// OBJ_GAP is not allowed to supply its own value to any window that taps it;
// the window reads the background level instead.  0 = exactly the 09-17
// datapath, for an A/B.
//
// OBJ_GAP is NOT POL_GAP and must not be set equal to it.  POL_GAP only has
// to clear the wobble of a 9216-sample mean, so 12 counts is right for it.
// This one has to clear the LENS SHADING -- this lens has tens of counts of
// vignette, and a corner block that is 30 counts below the frame mean is
// background, not an object.  Excluding it would put the global level back
// into the corner reference and undo the entire reason the window is local.
// 48 sits above the shading and an order of magnitude below what an object
// does to a block it covers.  Lower it only if large LOW-CONTRAST objects
// still come out as rings, and expect vignette artefacts in the corners when
// you do.
//
// BG_TRACK: which value substitutes for an excluded tap.
//   1 = bg_lvl, a tracked MEDIAN of the non-object block means (see [3d]).
//       Not dragged by the object at all, which is what makes an object that
//       covers a large fraction of the FRAME detectable.
//   0 = mean_hold, the plain frame mean.  Zero extra logic, but it is pulled
//       by the object in proportion to the object's share of the frame, so a
//       40%-of-frame object keeps only ~60% of its contrast.
parameter integer OBJ_EXCL   = 1,
parameter [7:0]   OBJ_GAP    = 8'd48,
parameter integer BG_TRACK   = 1,

// How hard bg_lvl chases the median, as a right shift of the vote imbalance.
// step = (|n_above - n_below| >> BG_RATE) + 1, so 3 gives up to 29 counts a
// frame and settles an 80-count step in about five frames (85 ms).  Raise it
// to slow the tracker down if a moving object drags it; lower it if a lighting
// change takes visibly long to recover.
parameter integer BG_RATE    = 3,

// THE PANIC BRAKE.  If the selected side came out larger than this, the
// threshold is sitting on the background rather than on an object, and every
// downstream number for that frame is fiction.  The mask is forced empty for
// the NEXT frame instead.
//
// Why blank rather than adapt: the 2026-09-07 bench run put a yellow rectangle
// round the whole frame on a plain wall, and a judge reads that as "the
// detector is broken", where an honest 0 TARGETS reads as "there is nothing
// there" -- which is the truth.
//
// 2026-09-08: the margin DOES adapt now, and this brake stayed anyway.  They
// are not redundant.  The servo is an integrator and needs tens of frames to
// walk anywhere; this is the one-frame cutout that keeps a sudden scene change
// -- a hand over the lens, the room lights going out -- from publishing a
// frame of fiction while the loop catches up.  FG_MAX is deliberately well
// above FG_HI so the two never fight: the servo owns the steady state, the
// brake owns the transient.
//
// 2/5 of a 1080p frame by default (3/8 until 09-17, raised with FG_HI so the
// gap between the servo band and the brake did not shrink).  An object that
// legitimately covers more than 40% of the picture is closer to the lens than
// any inspection demo puts it, and ccl_blob's MAX_W/MAX_H would have thrown it
// out anyway.
//
// It cannot latch up: dk_hit/bt_hit are compares against the threshold and are
// counted whatever out_bin is doing, so the guard re-evaluates every frame and
// releases by itself when the scene improves.
parameter [20:0]  FG_MAX     = 21'd829440,

// 0 = decide polarity per frame (see POLARITY FINDS ITSELF)
// 1 = force "object is darker than background"
// 2 = force "object is brighter than background"
parameter integer FORCE_POL  = 0
)(
input  wire        clk,
input  wire        rst_n,

input  wire        in_vs,          // HIGH across the visible frame
input  wire        in_de,
input  wire [7:0]  in_r,
input  wire [7:0]  in_g,
input  wire [7:0]  in_b,

output reg         out_vs,
output reg         out_de,
output reg         out_bin,        // 1 = foreground
output reg  [11:0] out_px,
output reg  [11:0] out_py,

// Bench instrumentation.  Not used by the logic -- these exist so the
// threshold and the polarity decision can be read out of ChipWatcher instead
// of inferred from how the mask looks.
output wire [7:0]  dbg_thresh,
output wire        dbg_fg_dark,
output reg  [20:0] dbg_dk_count,
output reg  [20:0] dbg_bt_count,

// Where the servo is sitting.  On a port AND on the OSD, not just in
// ChipWatcher: it is the single number that says whether the detector is
// working the scene or has run out of travel.
output wire [7:0]  dbg_margin,

// High while the FG_MAX brake is holding the mask empty.  Worth having on a
// port: an empty screen with this set is the guard doing its job, an empty
// screen with it clear is a threshold that found nothing, and the two want
// opposite fixes.
output reg         dbg_fg_over
);

localparam [20:0] HALF_FRAME = (IMG_HDISP * IMG_VDISP) / 2;

//------------------------------------------------------------------------
// [1] Luma, two balanced adder stages.
//
// Y ~= 0.25R + 0.5G + 0.25B.  Not the 601 weights -- those are twelve
// shift-add terms and would form exactly the kind of wide combinational cone
// this design has no timing budget for.  The approximation costs a little
// green weighting and nothing that matters to a threshold, and it is the same
// reduction motion_frame_drawer already applies to this picture.
//------------------------------------------------------------------------
reg [8:0] s_rb, s_g2;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        s_rb <= 9'd0; s_g2 <= 9'd0;
    end else begin
        s_rb <= {1'b0, in_r} + {1'b0, in_b};
        s_g2 <= {in_g, 1'b0};
    end
end

reg [7:0] gray;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) gray <= 8'd0;
    else        gray <= ({1'b0, s_rb} + {1'b0, s_g2}) >> 2;
end

//------------------------------------------------------------------------
// [2] Sync delays.  de_d[1] is contemporary with gray, de_d[2] with out_bin.
//------------------------------------------------------------------------
reg [2:0] de_d, vs_d;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        de_d <= 3'b0; vs_d <= 3'b0;
    end else begin
        de_d <= {de_d[1:0], in_de};
        vs_d <= {vs_d[1:0], in_vs};
    end
end

wire acc_v = de_d[1];                    // gray is valid

reg acc_v_d, vs2_d;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin acc_v_d <= 1'b0; vs2_d <= 1'b0; end
    else        begin acc_v_d <= acc_v;  vs2_d <= vs_d[2]; end
end

wire line_end   = acc_v_d & ~acc_v;
wire frame_tick = vs2_d & ~vs_d[2];      // falling edge of the delayed vs

//------------------------------------------------------------------------
// [3] Frame sum, in two tiers.
//
// Per pixel the accumulator is only 19 bits wide (1920*255 = 489600); the
// 29-bit frame total is touched once per line, in blanking.  Done flat it
// would be a 29-bit carry chain in the pixel path for no reason.
//------------------------------------------------------------------------
reg [18:0] line_sum;
reg [28:0] frame_sum;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        line_sum <= 19'd0; frame_sum <= 29'd0;
    end else if (frame_tick) begin
        line_sum <= 19'd0; frame_sum <= 29'd0;
    end else if (acc_v) begin
        line_sum <= line_sum + {11'd0, gray};
    end else if (line_end) begin
        frame_sum <= frame_sum + {10'd0, line_sum};
        line_sum  <= 19'd0;
    end
end

// Fold in whatever is still in line_sum.  vs falls at least one clock after
// the last de, so line_end has normally already fired and line_sum is zero --
// this makes the mean right either way rather than depending on that.
wire [28:0] frame_total = frame_sum + {10'd0, line_sum};
wire [7:0]  mean_new    = frame_total[MEAN_SHIFT+7 : MEAN_SHIFT];

//------------------------------------------------------------------------
// [3b] THE LOCAL REFERENCE.  This is the 2026-09-09 change, and it exists
// because the 09-08 build failed on a white desk in a way no parameter could
// have fixed.
//
// WHAT ONE NUMBER CANNOT DO.  Section [3] averages the whole frame and
// section [4] used to compare every pixel against that one value.  That is
// only valid if the illumination is flat, and on this lens it is not: there
// is a vignette worth several tens of counts from corner to centre before
// anything in the scene is considered.  Against a scalar reference the servo
// in [5] has no operating point to find --
//
//   small margin -> half the vignette gradient reads as foreground, fg_cnt
//                   runs past FG_HI, the loop tightens
//   large margin -> the gradient is finally excluded, and so is every real
//                   object whose contrast against ITS OWN SURROUND is less
//                   than the gradient's contrast against the frame mean
//
// so it walks to MARGIN_MAX and stays. Every photo from the 09-08 bench run
// reads MARGIN 108..112, and on a light desk the only pixels still crossing a
// +-112 band are the dark corners -- which is exactly where the boxes were
// drawn, while three plainly visible objects mid-frame were missed. The
// dark-background photos worked for the opposite reason: a dark scene has a
// low mean, so mean+112 still sits under a white object.
//
// The bench also reported that objects were detected more reliably NEAR THE
// EDGE of frame, which is the same mechanism seen from the other side: the
// edge is already offset from the frame mean by the vignette, so an object
// sitting on it clears the band that the same object mid-frame could not.
//
// THE FIX is to change the quantity being compared, not the margin: a pixel
// is foreground when it stands out from ITS OWN NEIGHBOURHOOD. The vignette
// is then absorbed into the reference -- it varies slowly enough to be flat
// across a few hundred pixels -- and the servo gets a real operating point
// back, so expect MARGIN to fall away from 112 towards MARGIN_MIN once this
// is running.
//
// ⚠ HOW BIG THAT NEIGHBOURHOOD IS, AND WHAT IT IS A STATISTIC OF, TOOK THREE
// BENCH ROUNDS.  The header's WHY THE REFERENCE IS A WIDE BOX MEAN has the
// argument; the short version is that the support has to be much LARGER than
// the object (or the object becomes its own reference) and the statistic has
// to be a MEAN (or one glint moves it).  Round 3 got the first wrong, round 4
// got the second wrong.  This is a 4x8-block box mean: 512x576 px of support.
//
// ONE FRAME OF LAG, exactly as the scalar mean already had: the block sums
// accumulated while frame N is scanned are what thresholds frame N+1. The
// reasoning in [4] about that trade is unchanged.
//
// WHAT THIS STILL CANNOT DO. The support is a box, so a step edge in the
// illumination inside it is averaged with what is on both sides, and the
// reference is pulled towards the wrong level for a window's width either side
// of a hard shadow boundary -- a wider window pushes that further, which is
// the one cost of WIN_NY=8. det_morph_open clears the thin seams that result
// and ccl_blob's fill test clears the hollow ones. Going further means a real
// bilinear interpolation between block centres, four RAM ports -- deliberately
// not done here.
//------------------------------------------------------------------------
localparam integer NBLK = N_COLS * N_ROWS;            // 225

// Read-stage coordinates: ONE pipeline index ahead of gray, so a synchronous
// RAM read issued from them lands on the clock gray is valid. Same
// rebuild-from-the-delayed-sync idiom as section [7], one index earlier -- and
// for the same reason, that a counter carried alongside the data is the thing
// that ends up one pixel out of step.
reg  [11:0] rx;
reg  [11:0] r_yblk;                   // 0 .. BLK_H-1
reg  [7:0]  r_yt;                     // 0 .. N_ROWS-1
reg         de0_d;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) de0_d <= 1'b0;
    else        de0_d <= de_d[0];
end

wire r_line_end = de0_d & ~de_d[0];

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        rx <= 12'd0; r_yblk <= 12'd0; r_yt <= 8'd0;
    end else if (!vs_d[0]) begin
        rx <= 12'd0; r_yblk <= 12'd0; r_yt <= 8'd0;
    end else if (de_d[0]) begin
        rx <= rx + 12'd1;
    end else begin
        rx <= 12'd0;
        if (r_line_end) begin
            if (r_yblk == (BLK_H - 1)) begin
                r_yblk <= 12'd0;
                // Clamped, not wrapped. 1080 = 15*72 exactly so this cannot
                // fire, but a source that runs long must not alias row 15
                // onto block 0 and corrupt the top of the frame.
                if (r_yt != (N_ROWS - 1)) r_yt <= r_yt + 8'd1;
            end else begin
                r_yblk <= r_yblk + 12'd1;
            end
        end
    end
end

wire [7:0] r_xt = rx >> BLK_W_LOG2;

// yt*N_COLS + xt. N_COLS is a parameter, so this is a constant multiply and
// synthesis reduces it to shifts -- (yt<<4)-yt at the default 15. Max
// 14*15+14 = 224, so the 8-bit result cannot overflow at 1080p.
wire [7:0] r_idx = r_yt * N_COLS + r_xt;

// Accumulate-stage copies, one clock later, contemporary with gray.
reg [7:0]            a_xt, a_yt;
reg [BLK_W_LOG2-1:0] a_xblk;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        a_xt <= 8'd0; a_yt <= 8'd0; a_xblk <= {BLK_W_LOG2{1'b0}};
    end else begin
        a_xt <= r_xt; a_yt <= r_yt; a_xblk <= rx[BLK_W_LOG2-1:0];
    end
end

wire [7:0] a_idx = a_yt * N_COLS + a_xt;

// One block's worth of one line, reduced to its SUM -- 2026-09-17, back from
// the extremes round 4 used; see WHY THE REFERENCE IS A WIDE BOX MEAN. Reset
// at the first column of each block rather than cleared afterwards, so a line
// that starts mid-block after a glitch cannot carry a stale partial sum.
// 128 * 255 = 32640, so 16 bits is exact with room to spare.
reg [15:0] bline_sum;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        bline_sum <= 16'd0;
    end else if (acc_v) begin
        bline_sum <= (a_xblk == 0) ? {8'd0, gray}
                                   : (bline_sum + {8'd0, gray});
    end
end

// bline_sum is one pixel behind on the wrap clock -- non-blocking assignment,
// so at a_xblk == BLK_W-1 it still holds the first 127 pixels. The last one is
// folded in combinationally on the way to the array, which is the same trick
// the pre-round-4 sum version used.
wire [15:0] bline_tot  = (a_xblk == 0) ? {8'd0, gray}
                                       : (bline_sum + {8'd0, gray});
wire        a_blk_wrap = acc_v & (a_xblk == (BLK_W - 1));

//------------------------------------------------------------------------
// The accumulator array, read-modify-written once per block per LINE: 15
// writes per line, not one per pixel. Two stages -- address out, sum back and
// written -- and a given block is not addressed again for a whole line
// (2200 clocks), so the pipeline cannot collide with itself.
//
// One read port and one write port, no reset on the array or its output
// register: that is what makes this a block RAM rather than 4950 flops. Phase
// C of the frame-end pass in [3c] zeroes it, and warm_n covers the undefined
// contents on the way out of reset.
//------------------------------------------------------------------------
reg [BSW-1:0] bsum [0:NBLK-1];
reg [BSW-1:0] bsum_q;

reg        rmw_v1, rmw_v2;
reg [7:0]  rmw_a1, rmw_a2;
reg [15:0] rmw_d1, rmw_d2;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        rmw_v1 <= 1'b0; rmw_a1 <= 8'd0; rmw_d1 <= 16'd0;
        rmw_v2 <= 1'b0; rmw_a2 <= 8'd0; rmw_d2 <= 16'd0;
    end else begin
        rmw_v1 <= a_blk_wrap;
        rmw_a1 <= a_idx;
        rmw_d1 <= bline_tot;

        rmw_v2 <= rmw_v1;
        rmw_a2 <= rmw_a1;
        rmw_d2 <= rmw_d1;
    end
end

//------------------------------------------------------------------------
// [3c] The frame-end pass, in THREE phases, all inside vertical blanking.
//
// PHASE M -- MEAN. 225 clocks. Read each block's sum out of bsum, turn it into
// an 8-bit block mean, write that into bmean. This is also where the polarity
// vote is counted (n_hi / n_lo against the frame mean), because the block
// means stream past here once and nowhere else.
//
// PHASE W -- WINDOW. For each of the 225 blocks, read the WIN_NX x WIN_NY
// block means around it out of bmean and average them. That average is the
// local background level; the margin is applied to it HERE and both decision
// levels are published into bthr, so the pixel path stays a RAM read and a
// compare. 32 clocks a block, 7200 for the grid.
//
// PHASE C -- CLEAR. 225 clocks writing 0 back into bsum for the next frame.
//
// ~7700 clocks, and it is a different module's blanking budget from
// ccl_blob's, not a share of the same one.
//
// ⚠⚠ AGAINST WHAT, THOUGH -- THIS SAID "~99,000" UNTIL 2026-09-18 AND THAT
// WAS WRONG BY NINE TIMES.  These phases start at THIS module's frame_tick,
// the falling edge of in_vs, and in_vs is ~vtc_vs -- the inverted FIVE-line
// sync pulse, not a frame-active flag.  So the real budget here is
// 5 x 2200 = 11,000 clocks, and ~7700 of 11,000 is a 30% margin, not a 92%
// one.  It fits at 1080p with a 15x15 grid and WIN_NX*WIN_NY = 32, and it
// fits by less than this comment used to claim.
//
// ⚠ WHICH MAKES WIN_NX * WIN_NY A TIMING PARAMETER, NOT ONLY A QUALITY ONE.
// Phase W costs WIN_NX*WIN_NY clocks per block, so 8x8 taps would be 14,400
// for the grid -- over the 11,000, with nothing in this module that would
// notice.  Phase W would still be reading bmean when the next frame's active
// pixels started writing bsum, and the port-arbitration argument at [3c]
// ("the users are disjoint in time") would quietly stop being true.
//
// ccl_blob hit the same five-line window and it cost the boxes outright; it
// now derives its frame edges from de and has the whole 45-line interval
// (its [1]).  Doing the same here would give these phases ~98,000 and make
// the tap count a free choice again.  Deliberately NOT done in the round that
// fixed ccl_blob: this module is inside its budget today, and the bsum port
// hand-off has a documented one-clock race (PH_GAP, see below) that earns a
// round of its own rather than a ride on someone else's.
//
// ⚠ WHY THE CLEAR IS STILL ITS OWN PHASE even though phase M reads each bsum
// entry exactly once and could clear it in passing. The pre-round-4 version
// did exactly that and it cost a bench round: the clear was gated on the
// phase's own run flag, which drops on the clock the LAST read address is
// issued, one clock before that read's write-back lands -- so block 224 never
// got cleared and its accumulator grew every frame until it wrapped. A
// separate write stream cannot have that bug at all. 225 clocks out of 91,000
// spare is not a price worth negotiating over.
//
// ⚠ PHASE W MUST NOT WRITE bmean. It reads every entry up to WIN_NX*WIN_NY
// times -- block n is a neighbour of dozens of others -- so anything written
// during it would be seen by the blocks not yet processed and the mask would
// come out sensitised in a band sweeping the frame. bmean is written in M and
// only read in W; bsum is read in M and only written in C and by the raster's
// read-modify-write. Every array has one writer per phase.
//
// WHY THE MARGIN IS APPLIED HERE and not in the pixel path. The alternative
// is to store 225 levels and do level +- margin per pixel, which puts an 8-bit
// add, an 8-bit subtract and two saturations between a RAM output and a
// compare, on the 150 MHz clock, in a design whose worst path already has no
// room to spare. Folding it into a pass that runs 225 times per FRAME leaves
// the pixel path as a RAM read and a compare -- the same depth section [4] had
// with scalar levels, so this change costs nothing in timing. The margin only
// moves at frame_tick anyway, so there is nothing to lose.
//
// ORDERING: PH_MEAN is entered ON frame_tick and its first read is the clock
// after, by which time margin_r and mean_hold have both taken the values the
// frame just ended produced. The same one-clock offset that [4] documents, for
// the same reason. Phase W consumes margin_r hundreds of clocks later still,
// so it sees the same one.
//------------------------------------------------------------------------
// ⚠ THREE BITS, AND PH_GAP IS LOAD-BEARING -- 2026-09-17, found by dtb TEST 22.
//
// Phase M issues a read on the clock it is in and writes bmean TWO clocks
// later (RAM read latency, then the registered write).  Phase W issues its
// first bmean READ on its own first clock.  Run them back to back and that
// read is one clock ahead of phase M's last write, so the last block's window
// tap comes back holding the PREVIOUS FRAME's mean.
//
// At 1080p that is invisible: phase W starts on block (0,0), whose replicated
// window taps are all low-numbered blocks written thousands of clocks earlier,
// and the stale entry (block 224) is only read near the end of the pass by
// which time it is long since correct.  It showed up at all only because dtb's
// single-block instance makes block 0 BOTH the last one written and the first
// one read -- 24 pixels out of 243,712, one count of threshold, on the frames
// where the test scene changes.  A one-clock gap costs nothing and removes a
// whole class of "works at one grid size" bug.
localparam [2:0] PH_IDLE = 3'd0, PH_MEAN = 3'd1, PH_GAP = 3'd2,
                 PH_WIN  = 3'd3, PH_CLR  = 3'd4;

reg [2:0] cv_ph;
reg [3:0] cv_xt, cv_yt;               // block under construction (phase W)
reg [2:0] cv_kx, cv_ky;               // which tap of the window
reg [7:0] cv_maddr;                   // phase M address
reg [7:0] cv_caddr;                   // phase C address

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        cv_ph <= PH_IDLE; cv_xt <= 4'd0; cv_yt <= 4'd0;
        cv_kx <= 3'd0;    cv_ky <= 3'd0;
        cv_maddr <= 8'd0; cv_caddr <= 8'd0;
    end else if (frame_tick) begin
        cv_ph <= PH_MEAN; cv_xt <= 4'd0; cv_yt <= 4'd0;
        cv_kx <= 3'd0;    cv_ky <= 3'd0;
        cv_maddr <= 8'd0; cv_caddr <= 8'd0;
    end else begin
        case (cv_ph)
        PH_MEAN: begin
            if (cv_maddr == (NBLK - 1)) cv_ph    <= PH_GAP;
            else                        cv_maddr <= cv_maddr + 8'd1;
        end
        // One clock, so the last bmean write lands before the first read.
        PH_GAP: cv_ph <= PH_WIN;
        PH_WIN: begin
            if (cv_kx != (WIN_NX - 1)) begin
                cv_kx <= cv_kx + 3'd1;
            end else begin
                cv_kx <= 3'd0;
                if (cv_ky != (WIN_NY - 1)) begin
                    cv_ky <= cv_ky + 3'd1;
                end else begin
                    cv_ky <= 3'd0;
                    if (cv_xt != (N_COLS - 1)) begin
                        cv_xt <= cv_xt + 4'd1;
                    end else begin
                        cv_xt <= 4'd0;
                        if (cv_yt != (N_ROWS - 1)) cv_yt <= cv_yt + 4'd1;
                        else                       cv_ph <= PH_CLR;
                    end
                end
            end
        end
        PH_CLR: begin
            if (cv_caddr == (NBLK - 1)) cv_ph    <= PH_IDLE;
            else                        cv_caddr <= cv_caddr + 8'd1;
        end
        default: ;
        endcase
    end
end

wire cv_mean = (cv_ph == PH_MEAN);
wire cv_win  = (cv_ph == PH_WIN);
wire cv_clr  = (cv_ph == PH_CLR);

// Port arbitration on bsum. The users are disjoint in time -- phase M and the
// clear run in blanking, the read-modify-write only fires on a_blk_wrap which
// needs acc_v -- so a plain select is enough and there is no arbiter to get
// wrong.
wire [7:0] bsum_ra = cv_mean ? cv_maddr : rmw_a1;

always @(posedge clk) bsum_q <= bsum[bsum_ra];

// cv_clr takes priority over rmw_v2. The two cannot be high together -- the
// pass runs in blanking, rmw_v2 needs acc_v -- but the priority makes that a
// property of the code, not of the timing.
wire [BSW-1:0] rmw_new = bsum_q + {{(BSW-16){1'b0}}, rmw_d2};
wire [7:0]     bsum_wa = cv_clr ? cv_caddr      : rmw_a2;
wire [BSW-1:0] bsum_wd = cv_clr ? {BSW{1'b0}}   : rmw_new;
wire           bsum_we = cv_clr | rmw_v2;

always @(posedge clk) if (bsum_we) bsum[bsum_wa] <= bsum_wd;

//------------------------------------------------------------------------
// PHASE M. bsum_q for cv_maddr lands one clock after the address is issued,
// so the bmean write and the polarity vote both run off delayed copies.
//
// mean_hold is declared HERE, not next to the always block in [4] that loads
// it: this pass reads it earlier in the file, and a reg used before its
// declaration is something iverilog tolerates and a vendor synthesiser is
// under no obligation to.
//------------------------------------------------------------------------
reg [7:0] mean_hold;

// NINE bits wide since 09-18, not eight: bit 8 is the object-side flag that
// phase W uses to decide whether to believe this tap.  Keeping it in the same
// word is deliberate -- a separate 225x1 array would be a second port to
// arbitrate and a second address to keep in step, for one bit.
reg [8:0] bmean [0:NBLK-1];
reg [8:0] bmean_q;

reg       cvm_v;
reg [7:0] cvm_a;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        cvm_v <= 1'b0; cvm_a <= 8'd0;
    end else begin
        cvm_v <= cv_mean; cvm_a <= cv_maddr;
    end
end

// sum / (BLK_W*BLK_H), as ((sum >> MEAN_PRE) * MEAN_MUL) >> MEAN_POST.
//
// ⚠ THE PRODUCT WIDTH IS DERIVED, NOT WRITTEN OUT.  It has to be: the exact
// width is (BSW-MEAN_PRE) + 7 for a 7-bit multiplier, and a hardcoded literal
// sized for the 1080p geometry silently truncates the moment a bench
// instantiates a smaller block with MEAN_PRE=0 -- dtb does exactly that, with
// BSW=20, where a 19-bit product loses the top bit and every block mean comes
// out wrong above half scale.  MEAN_POST+8 must stay inside this width.
//
// The clamp can only fire on a sum that should not exist, but it costs one mux
// in a pass that runs 225 times per frame.
localparam integer MNW = BSW - MEAN_PRE + 7;

wire [BSW-MEAN_PRE-1:0] mn_pre   = bsum_q[BSW-1:MEAN_PRE];
wire [MNW-1:0]          mn_mul   = mn_pre * MEAN_MUL;
wire [8:0]              mn_sh    = mn_mul[MEAN_POST+8 : MEAN_POST];
wire [7:0]              blk_mean = mn_sh[8] ? 8'd255 : mn_sh[7:0];

//------------------------------------------------------------------------
// THE OBJECT-SIDE FLAG.  Same shape as the polarity vote below and for the
// same reason -- a block mean is a 9216-sample average, so it moves when the
// thing inside the block changes and not when a single pixel does -- but a
// DIFFERENT gap (OBJ_GAP, see the parameter) and a different question:
//
//   polarity vote  "which side of the frame mean is the MINORITY"
//   object flag    "is THIS block on the side the object is already known
//                   to be on"
//
// So this one reads fg_dark, which is the decision in force, one frame old.
// That is the right staleness: the polarity only changes on two consecutive
// frames of agreement, so by the time it flips the flag follows it on the
// very next pass, and a single frame of wrongly-signed exclusion costs a
// reference that is the frame level -- i.e. the 09-08 behaviour -- and not a
// reference that is wrong in the other direction.
//------------------------------------------------------------------------
wire [8:0] obj_hi_l = {1'b0, mean_hold} + {1'b0, OBJ_GAP};
wire [8:0] obj_lo_l = {1'b0, mean_hold} - {1'b0, OBJ_GAP};

wire obj_hi = ~obj_hi_l[8] & ({1'b0, blk_mean} >  obj_hi_l);
wire obj_lo = ~obj_lo_l[8] & ({1'b0, blk_mean} <  obj_lo_l);

wire blk_obj = (OBJ_EXCL != 0) & (fg_dark ? obj_lo : obj_hi);

always @(posedge clk) if (cvm_v) bmean[cvm_a] <= {blk_obj, blk_mean};

// The polarity vote. pol_hi_l[8] set means mean_hold + POL_GAP ran past 255,
// so no block can vote high; pol_lo_l[8] is the borrow out of the same
// subtraction and means no block can vote low. Both are the honest answer at
// the ends of the scale rather than a wrap into nonsense.
wire [8:0] pol_hi_l = {1'b0, mean_hold} + {1'b0, POL_GAP};
wire [8:0] pol_lo_l = {1'b0, mean_hold} - {1'b0, POL_GAP};

wire vote_hi = cvm_v & ~pol_hi_l[8] & ({1'b0, blk_mean} >  pol_hi_l);
wire vote_lo = cvm_v & ~pol_lo_l[8] & ({1'b0, blk_mean} <  pol_lo_l);

// Cleared on frame_tick and read on the NEXT frame_tick, which is the same
// one-frame ordering dk_cnt/bt_cnt have: phase M for frame N runs in the
// blanking right after frame_tick(N), so at frame_tick(N+1) these hold frame
// N's vote. 225 blocks maximum, so 8 bits.
reg [7:0] pol_hi_n, pol_lo_n;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        pol_hi_n <= 8'd0; pol_lo_n <= 8'd0;
    end else if (frame_tick) begin
        pol_hi_n <= 8'd0; pol_lo_n <= 8'd0;
    end else begin
        if (vote_hi) pol_hi_n <= pol_hi_n + 8'd1;
        if (vote_lo) pol_lo_n <= pol_lo_n + 8'd1;
    end
end

//------------------------------------------------------------------------
// [3d] bg_lvl -- A TRACKED MEDIAN OF THE NON-OBJECT BLOCK MEANS.  New on
// 2026-09-18.  This is the value an excluded tap reads instead of its own.
//
// WHY A MEDIAN AND NOT A MEAN.  The obvious substitute is mean_hold, which
// is already sitting there and costs nothing.  It is good enough while the
// object is a few percent of the picture, and it is NOT good enough for the
// case this revision exists to fix: an object held close to the lens covers
// tens of percent of the FRAME, so it drags mean_hold by tens of percent of
// its own contrast, and the contrast that survives is only (1 - f_frame).
// A median of the background blocks is not dragged at all until the object
// owns more than half the block grid.
//
// WHY IT IS TRACKED AND NOT COMPUTED.  A true median of 225 numbers needs a
// sort, and an exact mean of the non-object blocks needs a divide by a count
// that changes every frame -- a multiplier and a reciprocal table, in a
// design whose setup slack is 0.1 ns.  A one-step-per-frame tracker gets the
// same answer with two counters and one add: count how many background blocks
// sit above the current estimate and how many below, then step towards the
// larger side.  That is a stochastic median chase, and at 60 frames a second
// it converges faster than anything a person can see.
//
// The step is proportional (BG_RATE) rather than fixed at one count, because
// a fixed step of 1 would need 1.3 s to cross an 80-count lighting change,
// which IS visible.
//
// WHAT IT CANNOT DO.  If the object covers more than half the block grid,
// the median IS the object, and so is the polarity vote's majority -- both
// break together at the same place, which is the honest limit of a
// single-frame spatial method and is documented as such in the header.
//------------------------------------------------------------------------
reg [7:0] bg_lvl;
reg [7:0] bg_ab, bg_bl;

wire bg_vote = cvm_v & ~blk_obj;
wire bg_hi_v = bg_vote & (blk_mean > bg_lvl);
wire bg_lo_v = bg_vote & (blk_mean < bg_lvl);

// Equal votes -- which includes "nobody voted" -- means hold.  Blocks that
// land exactly on the estimate count on neither side, which is what makes the
// fixed point the median rather than something next to it.
wire [8:0] bg_ab9 = {1'b0, bg_ab};
wire [8:0] bg_bl9 = {1'b0, bg_bl};
wire       bg_up  = bg_ab9 > bg_bl9;
wire [8:0] bg_gap = bg_up ? (bg_ab9 - bg_bl9) : (bg_bl9 - bg_ab9);
wire [8:0] bg_stp = (bg_gap >> BG_RATE) + 9'd1;

wire [9:0] bg_add = {2'd0, bg_lvl} + {1'd0, bg_stp};
wire [9:0] bg_sub = {2'd0, bg_lvl} - {1'd0, bg_stp};

wire [7:0] bg_nxt = (bg_gap == 9'd0)        ? bg_lvl
                  :  bg_up                 ? (|bg_add[9:8] ? 8'd255 : bg_add[7:0])
                  :  bg_sub[9]             ? 8'd0
                  :                          bg_sub[7:0];

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        bg_lvl <= 8'd128; bg_ab <= 8'd0; bg_bl <= 8'd0;
    end else if (frame_tick) begin
        bg_lvl <= bg_nxt;
        bg_ab  <= 8'd0;
        bg_bl  <= 8'd0;
    end else begin
        if (bg_hi_v && (bg_ab != 8'hFF)) bg_ab <= bg_ab + 8'd1;
        if (bg_lo_v && (bg_bl != 8'hFF)) bg_bl <= bg_bl + 8'd1;
    end
end

// The value an excluded tap contributes.  Stable for the whole pass: bg_lvl
// moves on frame_tick and phase W starts ~227 clocks later, the same ordering
// argument margin_r relies on.
wire [7:0] bg_ref = (BG_TRACK != 0) ? bg_lvl : mean_hold;

//------------------------------------------------------------------------
// PHASE W. The window is REPLICATE-bordered, not wrapped: a block near an
// edge repeats the edge block. Wrapping would let the top of the frame take
// its background level from the bottom, which on a scene with any vertical
// shading is the one reference guaranteed to be wrong.
//
// The clamps are written against the UNSIGNED sum-then-subtract rather than a
// signed index, for the same reason motion_frame_drawer's adjacency test is
// 5-bit: cv_xt reaches 0, and a borrow there would alias the left edge onto
// the right one -- which is exactly where objects enter the frame.
//------------------------------------------------------------------------
wire [5:0] nx_raw = {2'd0, cv_xt} + {3'd0, cv_kx};
wire [5:0] ny_raw = {2'd0, cv_yt} + {3'd0, cv_ky};

wire       nx_neg = (nx_raw < WIN_OX);
wire       ny_neg = (ny_raw < WIN_OY);
wire [5:0] nx_sub = nx_raw - WIN_OX;
wire [5:0] ny_sub = ny_raw - WIN_OY;

wire [3:0] n_xt = nx_neg                  ? 4'd0
                : (nx_sub > (N_COLS - 1)) ? (N_COLS - 1)
                :                            nx_sub[3:0];
wire [3:0] n_yt = ny_neg                  ? 4'd0
                : (ny_sub > (N_ROWS - 1)) ? (N_ROWS - 1)
                :                            ny_sub[3:0];

wire [7:0] cv_raddr = n_yt * N_COLS + n_xt;

always @(posedge clk) bmean_q <= bmean[cv_raddr];

// bmean_q for a tap lands one clock after its address, so the accumulator
// runs off delayed copies of "which tap" and of the destination block.
reg       cwd_v, cwd_first, cwd_last;
reg [7:0] cwd_blk;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        cwd_v <= 1'b0; cwd_first <= 1'b0; cwd_last <= 1'b0; cwd_blk <= 8'd0;
    end else begin
        cwd_v     <= cv_win;
        cwd_first <= (cv_kx == 3'd0) && (cv_ky == 3'd0);
        cwd_last  <= (cv_kx == (WIN_NX - 1)) && (cv_ky == (WIN_NY - 1));
        cwd_blk   <= cv_yt * N_COLS + cv_xt;
    end
end

// THE SUBSTITUTION.  One 8-bit mux in front of the accumulator, and it is the
// entire 09-18 change to this phase: a tap that flagged itself as sitting on
// the object contributes the background level instead of its own mean.
//
// Note what this is NOT: it is not a skip.  The tap count stays (1<<WIN_SH),
// so the divide below stays a bit-select and no reciprocal is needed.  The
// cost of that choice is that a window entirely inside a large object reads
// bg_ref exactly, i.e. it falls back to a global reference in the one place
// where a local one was impossible anyway -- which is strictly better than the
// 09-17 behaviour, where it read the OBJECT and the contrast went to zero.
wire [7:0] tap_val = bmean_q[8] ? bg_ref : bmean_q[7:0];

// (1<<WIN_SH) taps of 8 bits, so WIN_SH+8 bits holds the sum exactly and the
// divide by the tap count is the top 8 of them -- sized from the parameter
// rather than written out, because a hand-written width is the thing that
// silently overflows the day someone widens the window.
localparam integer WSW = WIN_SH + 8;

reg [WSW-1:0] win_sum;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n)     win_sum <= {WSW{1'b0}};
    else if (cwd_v) win_sum <= cwd_first ? {{WIN_SH{1'b0}}, tap_val}
                                         : (win_sum + {{WIN_SH{1'b0}}, tap_val});
end

// Same one-behind fold as bline_tot: on the last tap the register still holds
// taps 0..N-2, so the last one is mixed in combinationally on the way to bthr.
wire [WSW-1:0] win_tot  = cwd_first ? {{WIN_SH{1'b0}}, tap_val}
                                    : (win_sum + {{WIN_SH{1'b0}}, tap_val});
wire [7:0]     win_mean = win_tot[WIN_SH+7 : WIN_SH];

// The two decision levels, both measured from the SAME local background level
// -- 2026-09-17.  win_mean is a mean of means, so it is 8-bit by construction
// and the only saturation needed is on the upward add.
//
// ⚠ THE GLOBAL TERM IS GONE ON PURPOSE.  Until 09-16 this read
//
//     ref_dk = max(frame_mean, dilated_block_max)
//     ref_bt = min(frame_mean, eroded_block_min)
//
// i.e. "foreground if it stands out from its neighbourhood OR from the frame".
// The OR was there to see object interiors that a one-block-reach extreme
// could not, and it worked for that -- but an OR of two references is the most
// permissive thing you can build, and on the dark-desk scenes it put the
// entire background around every bright object over thr_dark.  Do not
// reintroduce it to fix an interior problem: the interior problem is what
// WIN_NX/WIN_NY are for, and they solve it without touching the other
// polarity.  See WHY THE REFERENCE IS A WIDE BOX MEAN in the header.
//
// ORDERING: margin_r moves on frame_tick and the first bthr write is ~230
// clocks later, so the pass always uses the margin the servo just chose --
// the same one-clock-offset argument [4] makes, with far more slack.
wire [7:0] cv_dk  = (win_mean > margin_r) ? (win_mean - margin_r) : 8'd0;
wire [8:0] cv_bt9 = {1'b0, win_mean} + {1'b0, margin_r};
wire [7:0] cv_bt  = cv_bt9[8] ? 8'd255 : cv_bt9[7:0];

// Both levels for one block in one word, so the pixel path is a single read.
// Written by the pass, read by the raster; disjoint in time again.
reg [15:0] bthr [0:NBLK-1];
reg [15:0] bthr_q;

wire bthr_we = cwd_v & cwd_last;

always @(posedge clk) if (bthr_we) bthr[cwd_blk] <= {cv_bt, cv_dk};
always @(posedge clk) bthr_q <= bthr[r_idx];

wire [7:0] thr_bt_px = bthr_q[15:8];
wire [7:0] thr_dk_px = bthr_q[7:0];

//------------------------------------------------------------------------
// Warm-up. The first pass reads an array that was never written and turns it
// into 225 fictional thresholds; the frame after that is the first one whose
// accumulator started from the zeroes the first pass wrote. So the mask is
// held empty for the first three frame_ticks rather than two -- one frame of
// margin over what the argument strictly requires, at 16 ms a frame.
//
// This is a HOLD, not a reset: dk_hit/bt_hit are gated, so dk_cnt and bt_cnt
// read zero and the servo sees fg_cnt < FG_LO and walks towards MARGIN_MIN.
// That is the right state to come out of warm-up in.
//
// ⚠ 2026-09-17: THE POLARITY IS NO LONGER FROZEN DURING WARM-UP, and that is
// an improvement rather than an oversight. The block vote does not depend on
// the mask, so it is live from pass 2 onwards -- pass 1 votes on an array that
// was never written, but flip_cnt wants two consecutive frames of agreement,
// so one garbage vote cannot carry. By the time tbl_ready rises the polarity
// has had two valid frames to settle, which is why the first visible frame is
// not a frame of the wrong polarity. The sentence this replaces said
// pol_active stays low through warm-up; that was true only of the pixel-count
// version.
//------------------------------------------------------------------------
reg [1:0] warm_n;
reg       tbl_ready;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        warm_n <= 2'd3; tbl_ready <= 1'b0;
    end else if (frame_tick) begin
        if (warm_n != 2'd0) warm_n    <= warm_n - 2'd1;
        else                tbl_ready <= 1'b1;
    end
end

//------------------------------------------------------------------------
// [4] Decision levels, both sides, updated once per frame -- in TWO steps.
//
// The current frame is thresholded with the previous frame's numbers.  One
// frame of lag on a lighting change, against a system that already carries a
// frame of DDR3 buffering: not measurable.
//
// STEP 1, at frame_tick: latch the mean and move the servo (section [5]).
// STEP 2, one clock later: recompute the two decision levels from the LATCHED
// mean and the ALREADY-REGISTERED margin.
//
// The split is load-bearing on timing, not style -- see TIMING NOTE in the
// header.  It also fixes an ordering trap that a single-step version has: the
// margin the loop just chose has to be the one the thresholds use, and with
// both on the same non-blocking edge the thresholds would silently keep using
// the previous margin, turning a one-frame loop into a two-frame one.
//------------------------------------------------------------------------
reg [7:0] thr_dark, thr_brt;
reg       thr_upd;

// mean_new comes off frame_sum + line_sum, and frame_sum is CLEARED at
// frame_tick, so the mean has to be captured on that edge or it is gone.
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        mean_hold <= 8'd0;
        thr_upd   <= 1'b0;
    end else begin
        thr_upd <= frame_tick;
        if (frame_tick) mean_hold <= mean_new;
    end
end

wire [8:0] mean_plus = {1'b0, mean_hold} + {1'b0, margin_r};

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        thr_dark <= 8'd0;
        thr_brt  <= 8'd255;
    end else if (thr_upd) begin
        thr_dark <= (mean_hold > margin_r) ? (mean_hold - margin_r) : 8'd0;
        thr_brt  <= mean_plus[8] ? 8'd255 : mean_plus[7:0];
    end
end

//------------------------------------------------------------------------
// The compares. With LOCAL_EN=1 the levels come from the block the pixel
// falls in, read out of bthr one clock earlier by r_idx; with LOCAL_EN=0 they
// come from the scalar pair above, which is the pre-09-09 datapath exactly.
// Both are parameter-selected, so one of the two muxes folds away at
// elaboration and neither costs a level of logic.
//
// The path is RAM-output-register -> 8-bit compare, which is the same depth
// as the register -> compare it replaces. That was the point of doing the
// margin arithmetic in [3c].
//------------------------------------------------------------------------
wire [7:0] use_dk  = (LOCAL_EN != 0) ? thr_dk_px : thr_dark;
wire [7:0] use_bt  = (LOCAL_EN != 0) ? thr_bt_px : thr_brt;
wire       use_rdy = (LOCAL_EN != 0) ? tbl_ready : 1'b1;

wire dk_hit = acc_v & use_rdy & (gray < use_dk);
wire bt_hit = acc_v & use_rdy & (gray > use_bt);

//------------------------------------------------------------------------
// [5] Both-sided counting, the polarity decision, and the margin servo.
//------------------------------------------------------------------------
reg [20:0] dk_cnt, bt_cnt;
reg        fg_dark;
reg [1:0]  flip_cnt;
reg [7:0]  margin_r;

assign dbg_thresh  = fg_dark ? thr_dark : thr_brt;
assign dbg_fg_dark = fg_dark;
assign dbg_margin  = margin_r;

// The polarity vote, counted in BLOCKS during phase M -- see POLARITY IS
// DECIDED ON BLOCKS in the header.
//
// WHICH FRAME THESE BELONG TO: phase M for frame N runs in the blanking right
// after frame_tick(N), so at frame_tick(N+1) they hold frame N's vote while
// dk_cnt/bt_cnt hold frame N+1's pixel counts.  That is the RIGHT pairing, not
// a slip -- the threshold table frame N+1 was masked with also came out of
// that same pass, so the vote and the levels it judges agree on which frame
// they describe.
//
// ⚠ NO HALF-FRAME OVERRIDE ON THE BLOCK VOTE, and it is not an oversight.
// That rule read "if this side is over half the frame it must be the
// background", which is a statement about a PIXEL count landing on the
// background.  A block vote cannot make that statement -- pol_hi_n and
// pol_lo_n are bounded by 225 and both are measured against the frame mean,
// so neither can run away the way a pixel count against a bad threshold does.
//
// ⚠ THE OBJECT IS THE MINORITY SIDE, NOT THE BIGGER ONE.  "More blocks wins"
// is the obvious rule and it is BACKWARDS, for the same reason the pixel
// version needed its half-frame override: the frame mean is dragged by
// whatever is in the frame, so on a bright object over a dark desk the frame
// mean rises above the desk and THE BACKGROUND becomes the side that deviates
// -- 191 background blocks voting low against 30 object blocks voting high.
// Take the bigger side and every such scene picks the desk.  The scene
// assumption this module has always documented is that objects are a few
// percent of the picture, and that assumption read off the block grid says:
// the majority IS the background, so the object is the other one.
//
// ⚠ A SIDE WITH ZERO BLOCKS IS NOT A MINORITY.  When the object is small
// enough that it barely moves the frame mean, the background sits INSIDE the
// deadband and does not vote at all: n_hi = 2, n_lo = 0.  Reading that as
// "low is the minority" picks exactly the wrong answer, so one-sided votes are
// their own case -- the side that deviates is the object, because nothing else
// in frame deviates from anything.
//
// ⚠ AND A TIE FALLS THROUGH TO THE PIXEL RULE rather than holding.  A pure
// shading gradient puts as many blocks above the frame mean as below it, so
// its vote is 4-4 and carries NO information -- holding there freezes whatever
// the previous scene left behind, which is how dtb TEST 23 came out inverted
// with a correct threshold table.  A tie means the blocks cannot tell, and the
// pixel counts are then the only evidence there is.  This is also what keeps
// the rule working at N_COLS=N_ROWS=1 (dtb's u_bin_loc1, where the single
// block's mean IS the frame mean so no block can ever vote) instead of
// freezing the polarity at its reset value forever.
//
// The fallback cannot bring the 09-16 failure back with it: that needed a
// LARGE bright object, and a large bright object moves its own blocks decades
// past POL_GAP and votes decisively.  The pixel rule only ever arbitrates
// scenes in which the block grid is symmetric or silent.
wire [8:0] pol_hi9 = {1'b0, pol_hi_n};
wire [8:0] pol_lo9 = {1'b0, pol_lo_n};

wire pol_hi_v = (LOCAL_EN != 0) && (pol_hi_n != 8'd0);
wire pol_lo_v = (LOCAL_EN != 0) && (pol_lo_n != 8'd0);

// Majority by more than the hysteresis, hence background, hence the object is
// the other side.
wire pol_hi_maj = pol_hi9 > (pol_lo9 + POL_BLK);
wire pol_lo_maj = pol_lo9 > (pol_hi9 + POL_BLK);

wire pol_blk_dec = (pol_hi_v != pol_lo_v)                     // one-sided
                || (pol_hi_v && pol_lo_v && (pol_hi_maj || pol_lo_maj));

wire pol_px_act  = (dk_cnt >= POL_FLOOR) || (bt_cnt >= POL_FLOOR);

wire pol_active  = pol_blk_dec || pol_px_act;

wire want_px     = (dk_cnt >= HALF_FRAME) ? 1'b0
                 : (bt_cnt >= HALF_FRAME) ? 1'b1
                 :                          (dk_cnt > bt_cnt);

wire want_dark   = !pol_blk_dec           ? want_px
                 : (pol_hi_v != pol_lo_v) ? pol_lo_v   // only one side deviates
                 :                          pol_hi_maj; // majority = background

// The count the CURRENT polarity actually selected.  fg_dark is updated later
// in the same block, so at frame_tick this still reads the value that was in
// force while these counts were being accumulated -- which is the one the
// brake has to judge.
wire [20:0] fg_cnt = fg_dark ? dk_cnt : bt_cnt;

//------------------------------------------------------------------------
// The servo step.  One 21-bit compare against each band edge, one 8-bit
// add/sub, two clamps.  Everything here is on the frame_tick edge only.
//
// The clamps are written against the 9-bit intermediate rather than against
// margin_r, so a MARGIN_STEP that does not divide the range evenly still lands
// exactly on the rail instead of oscillating one notch below it.
//------------------------------------------------------------------------
wire [8:0] mg_up = {1'b0, margin_r} + {1'b0, MARGIN_STEP};
wire [8:0] mg_dn = {1'b0, margin_r} - {1'b0, MARGIN_STEP};

wire [7:0] margin_nxt =
      (ADAPT_EN == 0)   ? MARGIN_MIN
    : (fg_cnt > FG_HI)  ? ((mg_up > {1'b0, MARGIN_MAX}) ? MARGIN_MAX : mg_up[7:0])
    : (fg_cnt < FG_LO)  ? ((mg_dn[8] || (mg_dn < {1'b0, MARGIN_MIN}))
                                                      ? MARGIN_MIN : mg_dn[7:0])
    :                     margin_r;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        dk_cnt   <= 21'd0;
        bt_cnt   <= 21'd0;
        fg_dark  <= (FORCE_POL == 2) ? 1'b0 : 1'b1;
        flip_cnt <= 2'd0;
        margin_r <= MARGIN_MIN;
        dbg_dk_count <= 21'd0;
        dbg_bt_count <= 21'd0;
        dbg_fg_over  <= 1'b0;
    end else if (frame_tick) begin
        dbg_dk_count <= dk_cnt;
        dbg_bt_count <= bt_cnt;
        dbg_fg_over  <= (fg_cnt > FG_MAX);
        margin_r     <= margin_nxt;
        dk_cnt <= 21'd0;
        bt_cnt <= 21'd0;

        // Two frames of agreement before flipping, so a hand passing over the
        // lens cannot toggle it mid-demo.
        if ((FORCE_POL == 0) && pol_active && (want_dark != fg_dark)) begin
            if (flip_cnt == 2'd1) begin
                fg_dark  <= want_dark;
                flip_cnt <= 2'd0;
            end else begin
                flip_cnt <= flip_cnt + 2'd1;
            end
        end else begin
            flip_cnt <= 2'd0;
        end
    end else begin
        if (dk_hit) dk_cnt <= dk_cnt + 21'd1;
        if (bt_hit) bt_cnt <= bt_cnt + 21'd1;
    end
end

//------------------------------------------------------------------------
// [6] The output bit: one mux over two compares already computed above.
//
// ⚠ out_de/out_vs COME FROM INDEX [1], NOT [2].  out_bin is registered out of
// the stage that has acc_v = de_d[1], so it lands one clock after de_d[1] --
// which is the same clock de_d[2] is on, and therefore one clock BEFORE a
// register fed from de_d[2].  Using [2] here made out_de lag out_bin and
// out_px by one, which dropped the first pixel of every row and ran px from
// 1 to 1920.  On a pattern that does not touch column 0 the result looks
// completely correct, so this only showed up on the boundary test in dtb.v.
//------------------------------------------------------------------------
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        out_bin <= 1'b0; out_de <= 1'b0; out_vs <= 1'b0;
    end else begin
        out_bin <= dbg_fg_over ? 1'b0 : (fg_dark ? dk_hit : bt_hit);
        out_de  <= de_d[1];
        out_vs  <= vs_d[1];
    end
end

//------------------------------------------------------------------------
// [7] Coordinates, rebuilt from the delayed sync rather than delayed
// alongside the data.  Same eight lines as every other module here; doing it
// this way means the coordinate cannot end up one pixel out of step with the
// bit it labels, which is the failure the OSD already hit once.
//------------------------------------------------------------------------
reg de_out_prev;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        out_px <= 12'd0; out_py <= 12'd0; de_out_prev <= 1'b0;
    end else begin
        de_out_prev <= de_d[2];
        if (!vs_d[2]) begin
            out_px <= 12'd0;
            out_py <= 12'd0;
        end
        else if (de_d[2]) begin
            out_px <= out_px + 12'd1;
        end
        else begin
            out_px <= 12'd0;
            if (de_out_prev) out_py <= out_py + 12'd1;
        end
    end
end

endmodule
