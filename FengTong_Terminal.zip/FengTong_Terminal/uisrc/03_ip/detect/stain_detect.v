//---------------------------------------------------------------------------
// stain_detect -- 白色工件污渍检测 RTL 实现（v4：格均值 + 格级闭运算，无 CNN）
//
// 接收 black_color_detect 输出的 RGB/mask 像素流 + ccl_blob 发布的边界框，
// 把框分成 64x64 格，判定"哪些格比周围的白底明显更暗"。端口与 v3.x 完全相同。
//
//===========================================================================
// 为什么放弃 v3.x 的 CNN（2026-10-25）
//===========================================================================
// v3.3 上板：干净件 / 污渍件热格都散布全图（H 50~60），真实污渍那块反而几乎不亮。
// v3.x 的输入特征 dx = max d 不做任何平均，单个坏点就能定死一格；三轮修补
// （mask 膨胀、脉冲增强重训、腐蚀 + 方向性开运算）都没把区分能力找回来，而复杂度
// 越来越高（1500 行，4 条 1920 宽行缓存，1.5M 时钟的卷积）。
//
// v4 只问一件事：这一格的【平均亮度】比周围白底暗多少？
//   - 每格约 10x10 = 100 个像素取平均，单个坏点只占 1%，天然被抹掉
//   - 真实污渍（摄像头采集里是 10 px 以上的斑）让整格平均明显变暗
// 在 dirty_cnn/normal_img + dirty_img（摄像头真实采集，108 张）上实测：
//   干净图最大对比度 <= 4，污渍图最小 >= 42，间隔 38 灰阶，108/108 判对。
//   即使 mask 把污渍本身挖成洞（black_color_detect 把暗斑判成"黑"），结果不变。
//
//===========================================================================
// 与金模型对齐的约定（dirty_cnn/stain_v4.py 的 stain_map()）
//===========================================================================
//  - 框要求 W >= 128 且 H >= 128（box_good），帧 N 用帧首锁存的框。
//  - RX = (128<<16)/W，格号 cx = (((x-X0)*RX)>>16)>>1（cy 同理），0..63。
//    先按 128 取整再 >>1 —— 和 stain_overlay 逐位相同，红色热格才不会错位。
//  - Y = (77R+150G+29B)>>8；mask=1 或消隐的像素记背景。
//  - 每格: N = 像素数, NB = 背景像素数, S = 工件像素 Y 之和
//      M  = (N-NB>0) ? S/(N-NB) : 0          格内工件平均亮度
//      PM = (N>0) && (NB==0)                 整格都是工件
//  - V  = erode_{2*GUARD+1,越界=0}( erode_{CK,越界=0}( dilate_{CK,越界忽略}(PM) ) )
//        先闭运算填掉污渍被 mask 挖出的洞，再整体内缩 GUARD 格避开边缘阴影/倒角
//  - BG = close_CK(M)（先 max 后 min，越界忽略）；c = max(0, BG-M)
//  - hot = V && c >= SCNN_T；热格数 >= SCNN_MIN_CELLS 本帧判阳；
//    最近 SCNN_VOTE_N 次中 >= SCNN_VOTE_K 次判阳 → stain_out。
//
// 实现要点
//  - 像素侧只剩一次亮度乘加 + 格号乘法 + 单格累加，没有任何行缓存。
//  - 格级形态学在 64x64 上做：灰度 CKxCK 拆成 (CK-1)/2 次 3 抽头，再拆成水平 / 垂直，
//    每趟 1 读/拍，滑窗只比较 3 个数（时序友好）；二值图按 64 bit 行字做，水平
//    方向是移位 + 与/或，垂直方向逐行读。
//
// 时序估算（1080p，pclk 148.5 MHz）
//   特征：每格 ~12 拍，64 格 ~800 拍/网格行（一个网格行 >= 2 条扫描线 = 4400 拍）
//   后处理：灰度 4*(CK/2) 趟 x ~4.4k + 二值 ~1k + 判定 4.1k ≈ 23k 拍（CK=5）≈ 0.16 ms
//   约每 2 帧出一个结果（累加一帧，下一帧做后处理，与 v3.x 相同的调度）。
//
// 存储（bit）
//   累加器    : 2 x 64 x 40
//   M / T1 / T2: 3 x 4096 x 8
//   PM / VA / VB: 3 x 64 x 64
//   热格位图  : 2 x 4096 x 1
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module stain_detect #(
    parameter integer IMG_HDISP = 1920,
    parameter integer IMG_VDISP = 1080
)(
    input  wire        clk,
    input  wire        rst_n,

    // 像素流
    input  wire        in_vs,
    input  wire        in_de,
    input  wire [23:0] in_rgb,      // {R[7:0], G[7:0], B[7:0]}
    input  wire        in_mask,     // 1 = 背景

    // 来自 ccl_blob 的边界框（帧首锁存）
    input  wire [11:0] box_x0,
    input  wire [11:0] box_x1,
    input  wire [11:0] box_y0,
    input  wire [11:0] box_y1,
    input  wire        box_valid,

    // 输出
    output reg         stain_out,       // 1 = 检测到污渍（经多次投票）
    output reg         stain_frame,     // 1 = 最近一次判定为阳（未经投票）
    output reg         stain_valid,     // 1 = 至少完成过一次判定
    output reg  [7:0]  hot_cells,       // 最近一次的热格数（饱和到 255）

    // 调试
    output reg         busy,            // 1 = 后处理正在进行
    output reg  [5:0]  hot_x0,          // 热格包围盒（64x64 网格坐标），无热格时 x0>x1
    output reg  [5:0]  hot_x1,
    output reg  [5:0]  hot_y0,
    output reg  [5:0]  hot_y1,

    // 热格位图读口（给 stain_overlay 把热格画成红色）
    // 64x64 = 4096 bit，双缓冲：判定往一块写，显示侧读另一块。
    // ⚠ 读是【同步】的（寄存一拍），stain_overlay 的流水线已按此对齐。
    input  wire [11:0] hmap_ra,         // {cy[5:0], cx[5:0]}
    output reg         hmap_q,
    output reg         hmap_vld,        // 1 = 至少写满过一块
    output reg  [11:0] hmap_x0,
    output reg  [11:0] hmap_y0,
    output reg  [11:0] hmap_x1,
    output reg  [11:0] hmap_y1
);

// ====================================================================
// 参数 — 由 dirty_cnn/stain_v4.py 生成
// ====================================================================
`include "stain_cnn.vh"

localparam integer G      = SCNN_G;         // 128，坐标换算网格
localparam integer HG     = SCNN_HG;        // 64，判定网格（本实现按 6 位格号编写）
localparam integer CK     = SCNN_CK;        // 闭运算窗口（奇数，>=3）
localparam integer RC     = CK / 2;         // 闭运算半径 = 3 抽头趟数
localparam integer GUARD  = SCNN_GUARD;     // 有效区内缩（格）
localparam integer RMAX   = (RC > GUARD) ? RC : GUARD;
localparam integer NGP    = 4 * RC;         // 灰度趟数：{max,min} x {H,V} x RC
localparam integer ACC_W  = 40;
localparam integer NCELL  = HG * HG;

// 累加器字段 {S[19:0], NB[9:0], N[9:0]}
`define ACC_S(v)  v[39:20]
`define ACC_NB(v) v[19:10]
`define ACC_N(v)  v[9:0]

// ====================================================================
// 跨块握手信号（每个信号只由一个 always 块驱动）
// ====================================================================
// [P6] 驱动
reg        frame_act;       // 本帧进行累加
reg        cnn_pend;        // 已累加完一帧，等待特征收尾 + 后处理完成
reg        feat_req;        // 脉冲：一个网格行完成
reg [5:0]  feat_row;
reg        feat_bank;
reg        fin_tg;          // 翻转：帧收尾请求
reg [5:0]  fin_row;
reg        fin_has;         // 帧内是否有框内像素
reg        fin_bank;
// [F1] 驱动
reg        fin_ack;
reg        fc_bank;         // 特征计算正在读的 bank
reg [5:0]  fa_ra, fa_wa;
reg        fa_we;
reg        feat_done;       // 脉冲：整帧特征写完
reg        feat_bad;        // 本帧有网格行丢失
// [F2] 驱动
reg        cnn_fin;         // 脉冲：判定完成，stain_frame 已更新

// ====================================================================
// [0] 帧坐标计数器
// ====================================================================
reg [11:0] xcnt, ycnt;
reg        de_d, vs_d;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        xcnt <= 12'd0; ycnt <= 12'd0;
        de_d <= 1'b0;  vs_d <= 1'b1;     // vs_d 复位为 1：复位释放时不产生伪 frame_start
    end else begin
        de_d <= in_de;
        vs_d <= in_vs;
        xcnt <= in_de ? xcnt + 12'd1 : 12'd0;   // 当前像素的 x = xcnt
        if (in_vs & ~vs_d)       ycnt <= 12'd0;  // 帧首
        else if (de_d & ~in_de)  ycnt <= ycnt + 12'd1;  // 行尾
    end
end

wire frame_start = in_vs & ~vs_d;

// ====================================================================
// [P1] 亮度 Y = (77R + 150G + 29B) >> 8，背景 / 消隐时 Y=0, m=1
// ====================================================================
wire [7:0] r_in = in_rgb[23:16];
wire [7:0] g_in = in_rgb[15:8];
wire [7:0] b_in = in_rgb[7:0];

reg [7:0]  p1_y;
reg        p1_m, p1_de;
reg [11:0] p1_x, p1_r;

always @(posedge clk) begin
    if (in_mask || !in_de)
        p1_y <= 8'd0;
    else
        p1_y <= (SCNN_LUMA_R * r_in + SCNN_LUMA_G * g_in + SCNN_LUMA_B * b_in) >> 8;
    p1_m  <= in_mask | ~in_de;
    p1_de <= in_de;
    p1_x  <= xcnt;
    p1_r  <= ycnt;
end

// ====================================================================
// 边界框锁存 + RX/RY 除法（G=128，和 stain_overlay 同一套）
//   v4 没有像素级窗口，框贴帧边也没关系，只要求宽高 >= G。
// ====================================================================
reg [11:0] bx0, bx1, by0, by1;
reg [11:0] bh;
reg [31:0] rx, ry;

wire box_good = box_valid
              && (box_x1 >= box_x0) && (box_y1 >= box_y0)
              && ((box_x1 - box_x0) >= (G - 1))
              && ((box_y1 - box_y0) >= (G - 1));

reg [1:0]  div_st;
reg        div_ph;          // 0 = RX, 1 = RY
reg [31:0] div_num, div_den, div_q;
reg [4:0]  div_cnt;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        bx0 <= 12'd0; bx1 <= 12'd0; by0 <= 12'd0; by1 <= 12'd0;
        bh  <= 12'd0;
        rx  <= 32'd0; ry  <= 32'd0;
        div_st <= 2'd0; div_ph <= 1'b0;
        div_num <= 32'd0; div_den <= 32'd0; div_q <= 32'd0; div_cnt <= 5'd0;
    end else if (frame_start) begin
        bx0 <= box_x0; bx1 <= box_x1;
        by0 <= box_y0; by1 <= box_y1;
        bh  <= box_y1 - box_y0 + 12'd1;
        if (box_good) begin
            div_st  <= 2'd1;
            div_ph  <= 1'b0;
            div_num <= G << 16;
            div_den <= box_x1 - box_x0 + 12'd1;
        end else begin
            div_st  <= 2'd0;
        end
    end else begin
        case (div_st)
        2'd1: begin             // 商 17 位（bit16..0）
            div_q   <= 32'd0;
            div_cnt <= 5'd16;
            div_st  <= 2'd2;
        end
        2'd2: begin
            if (div_num >= (div_den << div_cnt)) begin
                div_q[div_cnt] <= 1'b1;
                div_num        <= div_num - (div_den << div_cnt);
            end
            if (div_cnt == 5'd0) div_st  <= 2'd3;
            else                 div_cnt <= div_cnt - 5'd1;
        end
        2'd3: begin
            if (!div_ph) begin
                rx      <= div_q;
                div_num <= G << 16;
                div_den <= bh;
                div_ph  <= 1'b1;
                div_st  <= 2'd1;
            end else begin
                ry      <= div_q;
                div_st  <= 2'd0;
            end
        end
        default: ;
        endcase
    end
end

// ====================================================================
// [P5] 框内判定 + 格号 cx, cy（128 网格取整后 >>1）
// ====================================================================
wire in_box = frame_act & p1_de
            & (p1_x >= bx0) & (p1_x <= bx1)
            & (p1_r >= by0) & (p1_r <= by1);

reg [31:0] mul_cx, mul_cy;
reg        p5_inbox;
reg [7:0]  p5_y;
reg        p5_m;

always @(posedge clk) begin
    mul_cx   <= (p1_x - bx0) * rx;
    mul_cy   <= (p1_r - by0) * ry;
    p5_inbox <= in_box;
    p5_y     <= p1_y;
    p5_m     <= p1_m;
end

// mul[22:16] 是 128 网格格号，再丢掉最低位 = 64 网格格号
wire [5:0] cx = mul_cx[22:17];
wire [5:0] cy = mul_cy[22:17];

// ====================================================================
// [P6] 行流式累加器 —— 双 bank 乒乓
//   像素侧：每时钟 1 像素，读改写 2 级流水 + 1 级转发
//   特征侧：读另一块 bank，读完即清零
// ====================================================================
reg [ACC_W-1:0] acc_ram0 [0:HG-1];
reg [ACC_W-1:0] acc_ram1 [0:HG-1];
reg [ACC_W-1:0] acc_q0, acc_q1;

reg        acc_sel;         // 像素侧当前写入的 bank
reg [5:0]  prev_cy;
reg        prev_inbox;
reg        clr_act;
reg [5:0]  clr_idx;

// s0（组合）：网格行切换判定 + 发起读
wire new_row  = p5_inbox & prev_inbox & (cy != prev_cy);
wire pix_bank = new_row ? ~acc_sel : acc_sel;

// s1：读数据返回，计算新值
reg        s1_v, s1_bank, s1_m;
reg [5:0]  s1_cx;
reg [7:0]  s1_y;

// 写回记录：上一像素的写和本像素的读在同一拍，需要转发
reg              wb_v, wb_bank;
reg [5:0]        wb_cx;
reg [ACC_W-1:0]  wb_data;

wire [ACC_W-1:0] s1_old = (wb_v && (wb_bank == s1_bank) && (wb_cx == s1_cx))
                        ? wb_data : (s1_bank ? acc_q1 : acc_q0);
wire [19:0] s1_ns  = `ACC_S(s1_old)  + {12'd0, s1_y};
wire [9:0]  s1_nnb = `ACC_NB(s1_old) + {9'd0, s1_m};
wire [9:0]  s1_nn  = `ACC_N(s1_old)  + 10'd1;
wire [ACC_W-1:0] s1_new = {s1_ns, s1_nnb, s1_nn};

// 每块 bank 1 读 1 写；写口优先级：清零 > 像素 > 特征侧清零
wire [5:0] b0_ra = (p5_inbox && (pix_bank == 1'b0)) ? cx : fa_ra;
wire [5:0] b1_ra = (p5_inbox && (pix_bank == 1'b1)) ? cx : fa_ra;

wire b0_pw = s1_v  & (s1_bank == 1'b0);
wire b1_pw = s1_v  & (s1_bank == 1'b1);
wire b0_fw = fa_we & (fc_bank == 1'b0);
wire b1_fw = fa_we & (fc_bank == 1'b1);

wire             b0_we = clr_act | b0_pw | b0_fw;
wire [5:0]       b0_wa = clr_act ? clr_idx : (b0_pw ? s1_cx : fa_wa);
wire [ACC_W-1:0] b0_wd = (!clr_act && b0_pw) ? s1_new : {ACC_W{1'b0}};

wire             b1_we = clr_act | b1_pw | b1_fw;
wire [5:0]       b1_wa = clr_act ? clr_idx : (b1_pw ? s1_cx : fa_wa);
wire [ACC_W-1:0] b1_wd = (!clr_act && b1_pw) ? s1_new : {ACC_W{1'b0}};

always @(posedge clk) begin
    acc_q0 <= acc_ram0[b0_ra];
    if (b0_we) acc_ram0[b0_wa] <= b0_wd;
end

always @(posedge clk) begin
    acc_q1 <= acc_ram1[b1_ra];
    if (b1_we) acc_ram1[b1_wa] <= b1_wd;
end

// 特征侧读出数据
wire [ACC_W-1:0] acc_fq = fc_bank ? acc_q1 : acc_q0;

// ---- 像素侧控制 + 帧调度 ----
wire pend_clr = cnn_fin | (feat_done & feat_bad);

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        acc_sel    <= 1'b0;
        prev_cy    <= 6'd0;
        prev_inbox <= 1'b0;
        s1_v <= 1'b0; s1_bank <= 1'b0; s1_cx <= 6'd0;
        s1_y <= 8'd0; s1_m  <= 1'b0;
        wb_v <= 1'b0; wb_bank <= 1'b0; wb_cx <= 6'd0; wb_data <= {ACC_W{1'b0}};
        feat_req  <= 1'b0; feat_row <= 6'd0; feat_bank <= 1'b0;
        fin_tg    <= 1'b0; fin_row  <= 6'd0; fin_has   <= 1'b0; fin_bank <= 1'b0;
        frame_act <= 1'b0;
        cnn_pend  <= 1'b0;
        clr_act   <= 1'b1;          // 复位后清两块 bank
        clr_idx   <= 6'd0;
    end else begin
        feat_req <= 1'b0;

        // s0 -> s1
        s1_v    <= p5_inbox;
        s1_bank <= pix_bank;
        s1_cx   <= cx;
        s1_y    <= p5_y;
        s1_m    <= p5_m;

        // s1 -> 写回记录
        wb_v    <= s1_v;
        wb_bank <= s1_bank;
        wb_cx   <= s1_cx;
        wb_data <= s1_new;

        if (p5_inbox) begin
            prev_cy    <= cy;
            prev_inbox <= 1'b1;
        end

        // 网格行切换：交换 bank，旧 bank 交给特征计算
        if (new_row) begin
            acc_sel   <= ~acc_sel;
            feat_bank <= acc_sel;
            feat_row  <= prev_cy;
            feat_req  <= 1'b1;
        end

        if (clr_act) begin
            clr_idx <= clr_idx + 6'd1;
            if (clr_idx == HG - 1) clr_act <= 1'b0;
        end

        if (pend_clr) cnn_pend <= 1'b0;

        if (frame_start) begin
            prev_inbox <= 1'b0;
            wb_v       <= 1'b0;
            if (frame_act) begin
                // 上一帧是累加帧：冲刷最后一个网格行，进入等待后处理
                if (prev_inbox) acc_sel <= ~acc_sel;
                fin_bank  <= acc_sel;
                fin_row   <= prev_cy;
                fin_has   <= prev_inbox;
                fin_tg    <= ~fin_tg;
                cnn_pend  <= 1'b1;
                frame_act <= 1'b0;
            end else if (box_good && !(cnn_pend && !pend_clr)) begin
                // 空闲且有合格框：本帧累加，消隐期先清两块 bank
                frame_act <= 1'b1;
                clr_act   <= 1'b1;
                clr_idx   <= 6'd0;
            end else begin
                frame_act <= 1'b0;
            end
        end
    end
end

// ====================================================================
// 格级存储
//   M  : 格均值，F1 写，F2 读
//   T1/T2: 灰度形态学乒乓
//   PM : 整格是工件（64 bit 行字），F1 写，F2 读
//   VA/VB: 二值形态学乒乓
// 全部同步读。F1 和 F2 在时间上不重叠（cnn_pend 保证），所以 M / PM 的读写不冲突。
// ====================================================================
reg  [11:0] m_wa;   reg [7:0] m_wd;   reg m_we;     // [F1]
reg  [11:0] g_ra;                                   // [F2]，M/T1/T2 共用读地址
reg  [11:0] t_wa;   reg [7:0] t_wd;   reg t1_we, t2_we;   // [F2]
reg  [7:0]  m_q, t1_q, t2_q;

reg  [7:0]  m_mem  [0:NCELL-1];
reg  [7:0]  t1_mem [0:NCELL-1];
reg  [7:0]  t2_mem [0:NCELL-1];

always @(posedge clk) begin
    m_q <= m_mem[g_ra];
    if (m_we) m_mem[m_wa] <= m_wd;
end
always @(posedge clk) begin
    t1_q <= t1_mem[g_ra];
    if (t1_we) t1_mem[t_wa] <= t_wd;
end
always @(posedge clk) begin
    t2_q <= t2_mem[g_ra];
    if (t2_we) t2_mem[t_wa] <= t_wd;
end

reg  [5:0]  pm_wa;  reg [63:0] pm_wd; reg pm_we;    // [F1]
reg  [5:0]  b_ra;                                   // [F2]，PM/VA/VB 共用读地址
reg  [5:0]  v_wa;   reg [63:0] v_wd;  reg va_we, vb_we;   // [F2]
reg  [63:0] pm_q, va_q, vb_q;

reg  [63:0] pm_mem [0:HG-1];
reg  [63:0] va_mem [0:HG-1];
reg  [63:0] vb_mem [0:HG-1];

always @(posedge clk) begin
    pm_q <= pm_mem[b_ra];
    if (pm_we) pm_mem[pm_wa] <= pm_wd;
end
always @(posedge clk) begin
    va_q <= va_mem[b_ra];
    if (va_we) va_mem[v_wa] <= v_wd;
end
always @(posedge clk) begin
    vb_q <= vb_mem[b_ra];
    if (vb_we) vb_mem[v_wa] <= v_wd;
end

// ====================================================================
// [F1] 特征计算 — 逐格读累加器，M = S/(N-NB)，PM = (N>0 && NB==0)
// ====================================================================
localparam [2:0] F_IDLE = 3'd0, F_RD  = 3'd1, F_WT   = 3'd2, F_LD = 3'd3,
                 F_DIV  = 3'd4, F_WR  = 3'd5, F_DONE = 3'd6;

reg [2:0]  fc_st;
reg [5:0]  fc_row, fc_col;
reg        fc_final;        // 正在处理帧收尾
reg        fc_fill;         // 当前行无数据，直接写 N=0 特征
reg        fc_empty;        // 当前格没有工件像素
reg        fc_lost;         // 有网格行请求在忙时到达（丢失）
reg        fc_pm;
reg [62:0] pm_acc;          // 当前行 PM 的前 63 位
reg [9:0]  dv_den;
reg [19:0] dv_num;
reg [7:0]  dv_q;
reg [2:0]  dv_bit;

wire [19:0] dv_sub = {10'd0, dv_den} << dv_bit;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        fc_st    <= F_IDLE;
        fc_row   <= 6'd0;  fc_col <= 6'd0;
        fc_final <= 1'b0;  fc_fill <= 1'b0; fc_empty <= 1'b0; fc_lost <= 1'b0;
        fc_pm    <= 1'b0;  pm_acc  <= 63'd0;
        fc_bank  <= 1'b0;  fin_ack <= 1'b0;
        dv_den   <= 10'd0; dv_num <= 20'd0; dv_q <= 8'd0; dv_bit <= 3'd0;
        fa_ra <= 6'd0; fa_wa <= 6'd0; fa_we <= 1'b0;
        m_wa  <= 12'd0; m_wd <= 8'd0; m_we <= 1'b0;
        pm_wa <= 6'd0;  pm_wd <= 64'd0; pm_we <= 1'b0;
        feat_done <= 1'b0; feat_bad <= 1'b0;
    end else begin
        fa_we     <= 1'b0;
        m_we      <= 1'b0;
        pm_we     <= 1'b0;
        feat_done <= 1'b0;

        if (feat_req && (fc_st != F_IDLE)) fc_lost <= 1'b1;

        case (fc_st)
        F_IDLE: begin
            if (feat_req) begin
                fc_row   <= feat_row;
                fc_bank  <= feat_bank;
                fc_col   <= 6'd0;
                fc_final <= 1'b0;
                fc_fill  <= 1'b0;
                fc_st    <= F_RD;
            end else if (fin_tg != fin_ack) begin
                fin_ack  <= fin_tg;
                fc_final <= 1'b1;
                fc_bank  <= fin_bank;
                fc_col   <= 6'd0;
                if (fin_has) begin
                    fc_row  <= fin_row;
                    fc_fill <= 1'b0;
                    fc_st   <= F_RD;
                end else begin
                    fc_row  <= 6'd0;
                    fc_fill <= 1'b1;
                    fc_st   <= F_LD;
                end
            end
        end

        F_RD: begin
            fa_ra <= fc_col;
            fc_st <= F_WT;
        end

        F_WT: fc_st <= F_LD;        // 读延迟

        F_LD: begin : f_ld
            reg [ACC_W-1:0] a;
            reg [9:0]       np;
            a  = fc_fill ? {ACC_W{1'b0}} : acc_fq;
            np = `ACC_N(a) - `ACC_NB(a);
            if (!fc_fill) begin
                fa_wa <= fc_col;            // 读后清零
                fa_we <= 1'b1;
                fa_ra <= fc_col + 6'd1;     // 预取下一格
            end
            fc_pm  <= (`ACC_N(a) != 10'd0) && (`ACC_NB(a) == 10'd0);
            dv_den <= np;
            dv_num <= `ACC_S(a);
            dv_q   <= 8'd0;
            dv_bit <= 3'd7;
            if (np == 10'd0) begin
                fc_empty <= 1'b1;
                fc_st    <= F_WR;
            end else begin
                fc_empty <= 1'b0;
                fc_st    <= F_DIV;
            end
        end

        F_DIV: begin                // 8 位商；S <= 255*(N-NB) 保证不溢出
            if (dv_num >= dv_sub) begin dv_q[dv_bit] <= 1'b1; dv_num <= dv_num - dv_sub; end
            if (dv_bit == 3'd0) fc_st  <= F_WR;
            else                dv_bit <= dv_bit - 3'd1;
        end

        F_WR: begin
            m_wa <= {fc_row, fc_col};
            m_wd <= fc_empty ? 8'd0 : dv_q;
            m_we <= 1'b1;
            if (fc_col == HG - 1) begin
                pm_wa <= fc_row;
                pm_wd <= {fc_pm, pm_acc};
                pm_we <= 1'b1;
                fc_col <= 6'd0;
                if (fc_final && (fc_row != HG - 1)) begin
                    // 帧收尾：补齐后续没有像素的网格行
                    fc_row  <= fc_row + 6'd1;
                    fc_fill <= 1'b1;
                    fc_st   <= F_LD;
                end else if (fc_final) begin
                    fc_st   <= F_DONE;
                end else begin
                    fc_st   <= F_IDLE;
                end
            end else begin
                pm_acc[fc_col] <= fc_pm;
                fc_col <= fc_col + 6'd1;
                fc_st  <= F_LD;
            end
        end

        F_DONE: begin
            feat_done <= 1'b1;
            feat_bad  <= fc_lost;
            fc_lost   <= 1'b0;
            fc_st     <= F_IDLE;
        end

        default: fc_st <= F_IDLE;
        endcase
    end
end

// ====================================================================
// [F2] 后处理 —— 格级形态学 + 判定
//
//   灰度（BG = close_CK(M)）：NGP = 4*RC 趟，每趟一个方向、一个 3 抽头 max/min。
//     趟 k 的源：k=0 读 M，之后 T1/T2 乒乓；k 偶数写 T1、奇数写 T2，最后一趟
//     （k = NGP-1，奇数）写 T2，所以 BG 在 T2。
//     越界用恒等元填充（max 填 0，min 填 255），等价于"越界忽略"。
//     3 抽头 x RC 趟 = 半径 RC 的窗口：max 的复合满足结合律，边界也一致。
//
//   二值（V）：3 趟，每趟逐行：out[y] = OPV_{|dy|<=R} OPH_R(src[y+dy])
//     B0: PM -> VA  dilate R=RC  越界行跳过
//     B1: VA -> VB  erode  R=RC  越界行记 0
//     B2: VB -> VA  erode  R=GUARD 越界行记 0
//     水平方向移位补 0：对 OR 等价于越界忽略，对 AND 等价于越界记 0 —— 正好都对。
//
//   判定：光栅扫一遍，c = max(0, T2 - M)，hit = VA[cy][cx] && c >= T。
// ====================================================================
localparam [3:0] S_IDLE = 4'd0, S_GP_RUN = 4'd1, S_GP_DRN = 4'd2,
                 S_BP_RUN = 4'd3, S_BP_W1 = 4'd4, S_BP_W2 = 4'd5, S_BP_WR = 4'd9,
                 S_FN_RUN = 4'd6, S_FN_DRN = 4'd7, S_DONE = 4'd8;

reg [3:0]  pp_st;

// ---- 灰度趟 ----
reg [4:0]  gp_k;            // 趟号 0..NGP-1
reg [3:0]  gp_rep;          // 同方向重复次数 0..RC-1
reg        gp_dir;          // 0 = 水平（沿 cx），1 = 垂直（沿 cy）
reg        gp_op;           // 0 = max，1 = min
reg [5:0]  gp_l;            // 当前行 / 列
reg [6:0]  gp_j;            // 发出读的位置 0..64（64 = 右侧填充）
reg [1:0]  gp_dc;           // 排空计数

// ⚠ 读地址 g_ra 本身是寄存器，RAM 再寄存一拍：发地址后【第 2 拍】数据才有效。
//   ga_* = 地址已寄存（RAM 正在读），gq_* = 数据有效，在这一拍移入窗口。
reg        ga_v, ga_pad;    // 读发出级
reg [6:0]  ga_j;
reg        gq_v, gq_pad;    // 数据有效级
reg [6:0]  gq_j;
reg        gb_v;            // 窗口已移位，输出级
reg [6:0]  gb_j;
reg [7:0]  gw0, gw1, gw2;   // gw0 最新

wire [7:0] g_ident = gp_op ? 8'd255 : 8'd0;
wire [7:0] g_src_q = (gp_k == 5'd0) ? m_q : (gp_k[0] ? t1_q : t2_q);

function [7:0] op3;
    input       mn;
    input [7:0] a, b, c;
    reg   [7:0] t;
    begin
        if (mn) begin t = (a < b) ? a : b; op3 = (t < c) ? t : c; end
        else    begin t = (a > b) ? a : b; op3 = (t > c) ? t : c; end
    end
endfunction

// ---- 二值趟 ----
reg [1:0]  bp_k;            // 0..2
reg [5:0]  bp_y;
reg [3:0]  bp_d;            // 0..2R
reg        bi_v, bi_oob;    // 地址已寄存
reg        bq_v, bq_oob;    // 数据有效，本拍合并
reg [63:0] bp_acc;

wire [3:0] bp_r    = (bp_k == 2'd2) ? GUARD : RC;
wire       bp_or   = (bp_k == 2'd0);    // B0 膨胀，其余腐蚀
wire [63:0] bp_src_q = (bp_k == 2'd0) ? pm_q : (bp_k == 2'd1) ? va_q : vb_q;

function [63:0] hdil;       // 水平膨胀，移位补 0
    input [63:0] w; input [3:0] r;
    integer k;
    begin
        hdil = w;
        for (k = 1; k <= RMAX; k = k + 1)
            if (k <= r) hdil = hdil | (w << k) | (w >> k);
    end
endfunction

function [63:0] hero;       // 水平腐蚀，移位补 0（= 越界记 0）
    input [63:0] w; input [3:0] r;
    integer k;
    begin
        hero = w;
        for (k = 1; k <= RMAX; k = k + 1)
            if (k <= r) hero = hero & (w << k) & (w >> k);
    end
endfunction

// ---- 判定趟 ----
reg [12:0] fn_i;            // 发出读的格号 0..4095
reg        fv_v;            // 地址已寄存
reg [11:0] fv_i;
reg        fq_v;            // 数据有效，本拍判定
reg [11:0] fq_i;
reg [12:0] hot_cnt;
reg [5:0]  hx0, hx1, hy0, hy1;

// 热格位图，双缓冲。hmap_wsel = 正在写的那一块，显示侧读 ~hmap_wsel。
reg        hmap [0:2*NCELL-1];
reg        hmap_wsel;
reg        hm_we;
reg [11:0] hm_wa;
reg        hm_wd;

always @(posedge clk) hmap_q <= hmap[{~hmap_wsel, hmap_ra}];
always @(posedge clk) if (hm_we) hmap[{hmap_wsel, hm_wa}] <= hm_wd;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        pp_st  <= S_IDLE;
        busy   <= 1'b0;
        gp_k <= 5'd0; gp_rep <= 4'd0; gp_dir <= 1'b0; gp_op <= 1'b0;
        gp_l <= 6'd0; gp_j <= 7'd0; gp_dc <= 2'd0;
        ga_v <= 1'b0; ga_pad <= 1'b0; ga_j <= 7'd0;
        gq_v <= 1'b0; gq_pad <= 1'b0; gq_j <= 7'd0;
        gb_v <= 1'b0; gb_j <= 7'd0;
        gw0 <= 8'd0; gw1 <= 8'd0; gw2 <= 8'd0;
        g_ra <= 12'd0; t_wa <= 12'd0; t_wd <= 8'd0; t1_we <= 1'b0; t2_we <= 1'b0;
        bp_k <= 2'd0; bp_y <= 6'd0; bp_d <= 4'd0; bi_v <= 1'b0; bi_oob <= 1'b0;
        bq_v <= 1'b0; bq_oob <= 1'b0;
        bp_acc <= 64'd0;
        b_ra <= 6'd0; v_wa <= 6'd0; v_wd <= 64'd0; va_we <= 1'b0; vb_we <= 1'b0;
        fn_i <= 13'd0; fv_v <= 1'b0; fv_i <= 12'd0; fq_v <= 1'b0; fq_i <= 12'd0;
        hot_cnt <= 13'd0;
        hx0 <= 6'd63; hx1 <= 6'd0; hy0 <= 6'd63; hy1 <= 6'd0;
        hm_we <= 1'b0; hm_wa <= 12'd0; hm_wd <= 1'b0;
        stain_frame <= 1'b0;
        stain_valid <= 1'b0;
        hot_cells   <= 8'd0;
        hot_x0 <= 6'd63; hot_x1 <= 6'd0; hot_y0 <= 6'd63; hot_y1 <= 6'd0;
        cnn_fin     <= 1'b0;
        hmap_wsel   <= 1'b0;
        hmap_vld    <= 1'b0;
        hmap_x0 <= 12'd0; hmap_y0 <= 12'd0; hmap_x1 <= 12'd0; hmap_y1 <= 12'd0;
    end else begin
        t1_we   <= 1'b0;
        t2_we   <= 1'b0;
        va_we   <= 1'b0;
        vb_we   <= 1'b0;
        hm_we   <= 1'b0;
        cnn_fin <= 1'b0;
        ga_v    <= 1'b0;
        bi_v    <= 1'b0;
        fv_v    <= 1'b0;

        // ---------------- 灰度：数据有效级 / 窗口移位级 / 输出级（跟着流水走） ----
        gq_v   <= ga_v;
        gq_pad <= ga_pad;
        gq_j   <= ga_j;
        gb_v   <= gq_v;
        gb_j   <= gq_j;
        if (gq_v) begin
            gw2 <= gw1;
            gw1 <= gw0;
            gw0 <= gq_pad ? g_ident : g_src_q;
        end
        if (gb_v && (gb_j != 7'd0)) begin
            // 窗口 {gw2, gw1, gw0} = 位置 {o-1, o, o+1}，o = gb_j-1
            t_wa  <= gp_dir ? {gb_j[5:0] - 6'd1, gp_l} : {gp_l, gb_j[5:0] - 6'd1};
            t_wd  <= op3(gp_op, gw2, gw1, gw0);
            t1_we <= ~gp_k[0];
            t2_we <=  gp_k[0];
        end

        // ---------------- 二值：数据有效级合并 ----
        bq_v   <= bi_v;
        bq_oob <= bi_oob;
        if (bq_v) begin
            if (bq_oob) begin
                if (!bp_or) bp_acc <= 64'd0;            // 腐蚀：越界行记 0
            end else if (bp_or)
                bp_acc <= bp_acc | hdil(bp_src_q, bp_r);
            else
                bp_acc <= bp_acc & hero(bp_src_q, bp_r);
        end

        // ---------------- 判定：数据有效级 ----
        fq_v <= fv_v;
        fq_i <= fv_i;
        if (fq_v) begin : fn_proc
            reg [7:0] c;
            reg       hit;
            c   = (t2_q > m_q) ? (t2_q - m_q) : 8'd0;
            hit = va_q[fq_i[5:0]] && (c >= SCNN_T);
            hm_we <= 1'b1;
            hm_wa <= fq_i;
            hm_wd <= hit;
            if (hit) begin
                hot_cnt <= hot_cnt + 13'd1;
                if (fq_i[5:0]  < hx0) hx0 <= fq_i[5:0];
                if (fq_i[5:0]  > hx1) hx1 <= fq_i[5:0];
                if (fq_i[11:6] < hy0) hy0 <= fq_i[11:6];
                if (fq_i[11:6] > hy1) hy1 <= fq_i[11:6];
            end
        end

        case (pp_st)
        S_IDLE: begin
            busy <= 1'b0;
            if (feat_done && !feat_bad) begin
                busy   <= 1'b1;
                gp_k   <= 5'd0; gp_rep <= 4'd0; gp_dir <= 1'b0; gp_op <= 1'b0;
                gp_l   <= 6'd0; gp_j   <= 7'd0;
                gw0 <= 8'd0; gw1 <= 8'd0; gw2 <= 8'd0;     // max 的恒等元
                pp_st  <= S_GP_RUN;
            end
        end

        // ============================================================
        // 灰度趟：每行 / 列发出 65 次读（第 65 次是右侧填充，不读 RAM）
        // ============================================================
        S_GP_RUN: begin
            g_ra   <= gp_dir ? {gp_j[5:0], gp_l} : {gp_l, gp_j[5:0]};
            ga_v   <= 1'b1;
            ga_pad <= gp_j[6];
            ga_j   <= gp_j;
            if (gp_j == 7'd64) begin
                gp_j  <= 7'd0;
                gp_dc <= 2'd0;
                pp_st <= S_GP_DRN;
            end else
                gp_j <= gp_j + 7'd1;
        end

        S_GP_DRN: begin
            // 最后一次发出在 t：t+2 数据移入窗口，t+3 输出级写最后一格（本状态
            // gp_dc==2 的这一拍），同拍复位窗口不冲突（t+3 没有移位）。
            // 下一行 / 下一趟 t+4 开始发出，读在 t+5，晚于最后一次写入（t+4）。
            gp_dc <= gp_dc + 2'd1;
            if (gp_dc == 2'd2) begin : gp_next
                reg       nop;
                reg [4:0] nk;
                nop = gp_op;
                nk  = gp_k;
                if (gp_l != HG - 1) begin
                    gp_l <= gp_l + 6'd1;
                end else begin
                    gp_l <= 6'd0;
                    nk   = gp_k + 5'd1;
                    gp_k <= nk;
                    if (gp_rep != RC - 1) begin
                        gp_rep <= gp_rep + 4'd1;
                    end else begin
                        gp_rep <= 4'd0;
                        if (gp_dir) nop = 1'b1;     // H,V 的 max 做完换 min
                        gp_dir <= ~gp_dir;
                        gp_op  <= nop;
                    end
                end
                gw0 <= nop ? 8'd255 : 8'd0;
                gw1 <= nop ? 8'd255 : 8'd0;
                gw2 <= nop ? 8'd255 : 8'd0;
                if ((gp_l == HG - 1) && (nk == NGP)) begin
                    bp_k   <= 2'd0;
                    bp_y   <= 6'd0;
                    bp_d   <= 4'd0;
                    bp_acc <= 64'd0;            // B0 是 OR，恒等元 0
                    pp_st  <= S_BP_RUN;
                end else
                    pp_st  <= S_GP_RUN;
            end
        end

        // ============================================================
        // 二值趟：每行发出 2R+1 次读，越界的不读
        // ============================================================
        S_BP_RUN: begin : bp_run
            reg signed [7:0] ry;
            ry = $signed({2'b00, bp_y}) + $signed({4'b0000, bp_d}) - $signed({4'b0000, bp_r});
            b_ra   <= ry[5:0];
            bi_v   <= 1'b1;
            bi_oob <= (ry < 0) || (ry > HG - 1);
            if (bp_d == {bp_r, 1'b0}) begin
                bp_d  <= 4'd0;
                pp_st <= S_BP_W1;
            end else
                bp_d <= bp_d + 4'd1;
        end

        S_BP_W1: pp_st <= S_BP_W2;      // 最后一次读：地址已寄存
        S_BP_W2: pp_st <= S_BP_WR;      // 最后一次读：本拍合并

        S_BP_WR: begin
            v_wa  <= bp_y;
            v_wd  <= bp_acc;
            va_we <= (bp_k != 2'd1);    // B0、B2 写 VA，B1 写 VB
            vb_we <= (bp_k == 2'd1);
            bp_acc <= 64'hFFFF_FFFF_FFFF_FFFF;      // 之后的趟都是 AND
            if (bp_y != HG - 1) begin
                bp_y  <= bp_y + 6'd1;
                if (bp_k == 2'd0) bp_acc <= 64'd0;
                pp_st <= S_BP_RUN;
            end else begin
                bp_y <= 6'd0;
                if (bp_k == 2'd2) begin
                    fn_i    <= 13'd0;
                    hot_cnt <= 13'd0;
                    hx0 <= 6'd63; hx1 <= 6'd0; hy0 <= 6'd63; hy1 <= 6'd0;
                    pp_st   <= S_FN_RUN;
                end else begin
                    bp_k  <= bp_k + 2'd1;
                    pp_st <= S_BP_RUN;
                end
            end
        end

        // ============================================================
        // 判定趟：光栅序，M / T2 / VA 行字同时读
        // ============================================================
        S_FN_RUN: begin
            g_ra <= fn_i[11:0];
            b_ra <= fn_i[11:6];
            fv_v <= 1'b1;
            fv_i <= fn_i[11:0];
            if (fn_i == NCELL - 1) begin
                gp_dc <= 2'd0;
                pp_st <= S_FN_DRN;
            end
            fn_i <= fn_i + 13'd1;
        end

        S_FN_DRN: begin
            // 最后一格 t 发出，t+2 判定；DONE 在 t+3 读到更新后的 hot_cnt，
            // 位图最后一次写也在 t+3 用的是翻转前的 hmap_wsel
            gp_dc <= gp_dc + 2'd1;
            if (gp_dc == 2'd1) pp_st <= S_DONE;
        end

        S_DONE: begin
            stain_frame <= (hot_cnt >= SCNN_MIN_CELLS);
            hot_cells   <= (hot_cnt > 13'd255) ? 8'd255 : hot_cnt[7:0];
            hot_x0 <= hx0; hot_x1 <= hx1; hot_y0 <= hy0; hot_y1 <= hy1;
            stain_valid <= 1'b1;
            cnn_fin     <= 1'b1;
            // 位图写完，换手给显示侧；框一起发布，显示侧要用它映射坐标
            hmap_wsel <= ~hmap_wsel;
            hmap_vld  <= 1'b1;
            hmap_x0   <= bx0; hmap_y0 <= by0;
            hmap_x1   <= bx1; hmap_y1 <= by1;
            pp_st     <= S_IDLE;
        end

        default: pp_st <= S_IDLE;
        endcase
    end
end

// ====================================================================
// [F3] 多次投票：最近 VOTE_N 次判定中 >= VOTE_K 次判阳 → 报警
//      （要求 SCNN_VOTE_N >= 2）
// ====================================================================
reg [SCNN_VOTE_N-1:0] vote_sr;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        vote_sr   <= {SCNN_VOTE_N{1'b0}};
        stain_out <= 1'b0;
    end else if (cnn_fin) begin : vote
        reg [SCNN_VOTE_N-1:0] nsr;
        integer vi, vc;
        nsr = {vote_sr[SCNN_VOTE_N-2:0], stain_frame};   // stain_frame 已是本次结果
        vc  = 0;
        for (vi = 0; vi < SCNN_VOTE_N; vi = vi + 1)
            vc = vc + nsr[vi];
        vote_sr   <= nsr;
        stain_out <= (vc >= SCNN_VOTE_K);
    end
end

`undef ACC_S
`undef ACC_NB
`undef ACC_N

endmodule
