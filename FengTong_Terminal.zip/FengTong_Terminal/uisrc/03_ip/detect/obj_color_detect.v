//---------------------------------------------------------------------------
// obj_color_detect -- 检测框内物体的颜色识别 (2026-10-10)
//
// 10-11 从队友的 contain/Anlogic7 移植（原文件名中间带空格），只改了一处：
// [5] 的 f_pr 由 > 改成 >=，让 330 度本身归 RED，和下面写的 [330,15) 一致。
// 测试台 C:/tmp/color_1011/（octb_px 全 2^24 色逐像素、
// octb_frm 整帧 61 项）。
//
// 接在 black_color_detect_cnn 后面：out_mask = 1 是黑色背景，0 是物体。
// 对一帧里"确定在物体内部"的像素逐个分类，整帧投票，帧末给出颜色。
// 假设物体颜色单一（纯白、纯红……），所以多数票就是物体颜色。
//
// ⚠ black_color_detect_cnn 的 view_mode 必须是 2'b00，否则 out_rgb 是掩码
//   图而不是相机画面，这里只会看到黑和白。主线 system_top 本来就是 2'b00。
//
// 一个像素要同时满足三条才投票：
//   1. de && !mask                       物体像素
//   2. 在检测框内，且框四边各缩 BOX_MARGIN 挡住框外的非黑背景（桌面、墙……）
//   3. 水平腐蚀：它左边 ERODE_L 个、右边 ERODE_R 个像素也都满足 1、2
//      去掉边缘混色像素。右边要多腐蚀：black_color_detect 的迟滞
//      (HYST_START = 6) 让物体右侧约 6 个黑背景像素仍标为物体，
//      再加 3x3 因果卷积的 1 px，ERODE_R 要 >= 8。
//      左边反而没有泄漏（HYST_END 让物体左侧 8 px 仍标为背景），只防去马赛克的模糊。
//
// 像素分类（无除法；色相用"4t 与 k*delta 比较"，k 是常数，综合成加法）：
//   mx = max(R,G,B), mn = min, delta = mx - mn, 饱和度 S = delta / mx
//   mx < V_BLACK                                   -> BLACK
//   delta < SAT_MIN 或 16*delta < SAT_Q4*mx (无彩色) -> WHITE (mx >= V_WHITE) / GRAY
//   否则按色相（度）：
//     RED [330,15)  ORANGE [15,45)  YELLOW [45,75)  GREEN [75,165)
//     CYAN [165,195)  BLUE [195,255)  PURPLE [255,330)
//   最大通道决定扇区：R 扇区 h = 60*(G-B)/delta，G 扇区 h = 120 + 60*(B-R)/delta，
//   B 扇区 h = 240 + 60*(R-G)/delta。令 t 为括号里的差，
//   "h 偏离扇区中心 >= k*15 度" 就是 4t >= k*delta，H_* 参数即这些 k。
//
// 类别编码（color_id / stable_id）：
//   0 BLACK  1 GRAY  2 WHITE  3 RED  4 ORANGE  5 YELLOW  6 GREEN  7 CYAN
//   8 BLUE   9 PURPLE   15 = 无效（没物体 / 票太少 / 不够纯）
//
// 帧判决：票数最多的类，且 总票数 >= MIN_PIX、赢家 >= 总票数 >> PURITY_SHIFT
// 才有效；同一结果（包括"无效"）连续 CONFIRM 帧才更新 stable_*，防闪。
// mean_r/g/b 是参与投票像素的平均 RGB —— 调阈值时用 ChipWatcher 看它。
//
// 帧边界：in_vs 的上升沿，用来结算和清零。无论 vs 是帧有效还是取反的 5 行
// 同步脉冲，一帧都只有一个上升沿，而且都在场消隐里（servo_pantilt / tof_size
// 用的是同一个论证）。
//
// 框的时序（10-10 改）：框在本帧第一个有效像素锁存，整帧不变。ccl_blob 在
// 场消隐里算完上一帧并在 S_PUB 一拍发布，下一帧第一个像素之前一定已发布，
// 所以统计帧 N 用的固定是帧 N-1 的框。原来在 vs 上升沿锁存，取反同步脉冲的
// 读法下沿在消隐第 5 行左右，ccl_blob 可能还没算完，滞后会在 1、2 帧间跳。
// 框只决定"看哪一块"，"哪些像素是物体"仍由本帧逐像素的 mask 决定，所以
// 一帧滞后只会让移动物体少几票，不会把背景算进来。
//
// 不在显示通路里：只读不写视频，不改变任何模块的对齐和延迟。
// 资源：10 个 21 位计数器 + 3 个 29 位累加器 + 一份快照，无 RAM、无 DSP。
// 计数位宽按 1920x1080 定：2,073,600 < 2^21，2,073,600*255 < 2^29，不会溢出。
//
// ⭐ 10-28 MEAN_MODE（0 = 与上面完全一样，逐位）。板上症状：红对，浅蓝纸和
// 浅黄纸都报 WHITE。两个原因叠在一起：
//   1. 浅色纸本来就不够艳。录像里蓝纸 S 0.39、黄纸 0.14，而录像（采集卡+OBS）
//      比板子看到的更艳：logo 的 RTL 蓝 (64,128,224) S 0.71，录像里是
//      (25,133,252) S 0.90，约 1.5~1.7 倍。折回板上，蓝纸约 0.26~0.29，
//      在 SAT_Q4 5 (0.31) 之下，逐像素全投 WHITE —— 和板上一致。
//   2. 质检补光灯偏蓝：白纸本身在录像里 (208,220,253)，S 0.18，色相和蓝纸一样
//      (~220 度)。不做白平衡，任何单一饱和度门限都分不开"偏蓝的白"和"浅蓝"，
//      而浅黄 (S ~0.1) 比白纸还"不艳"。
// 所以 MEAN_MODE 1 的帧判决：
//   * 逐像素投票的赢家是彩色（RED..PURPLE）且过纯度 -> 照旧用它（艳色、
//     手挡一部分时多数票更稳，红色现在就是这条路）。
//   * 否则（赢家是 WHITE/GRAY/BLACK 或纯度不够）-> 用投票像素的"平均色"
//     乘白平衡增益 WB_* 再分类：平均值没有像素噪声，饱和度门限可以压到
//     M_SAT_Q7/128，色相边界用 7.5 度一档（M_*，见参数）。
// WB_* 是 10-28 21:51 录像里补光灯下白纸折回板上域的增益。离线（录像折回板上
// 域，k 取 1.45 和 1.7 都试）：白 100 %、红 100 %、蓝 100 %、黄 93 %（剩下的是
// 手正在放纸那几帧）；旧判决同样条件下 白 96 % 红 100 % 蓝 0 % 黄 0 %，与板上
// 一致。白纸 WB 后均值 S 最大 0.093，蓝纸最小 0.137，门限 15/128 = 0.117 在
// 中间。换场地/换灯后白纸要是报成别的颜色，用 OSD 的 RGB 行读白纸均值，
// WB_R = 256*max/R、WB_G = 256*max/G、WB_B = 256*max/B 重算。
// 多出 5 拍消隐期里的串行运算，不加 RAM、不加 DSP（乘常数）。
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module obj_color_detect #(
// ---- 统计区域 ----
parameter integer USE_BOX      = 1,      // 0 = 不用框，整帧所有物体像素都投票
parameter integer BOX_MARGIN   = 8,      // 框四边各往里缩的像素
parameter integer ERODE_L      = 4,
parameter integer ERODE_R      = 10,

// ---- 像素分类 ----
parameter [7:0]   V_BLACK      = 8'd48,  // 最亮通道低于它 = 黑（背景泄漏 / 阴影）
parameter [7:0]   V_WHITE      = 8'd160, // 无彩色且最亮通道 >= 它 = 白，否则灰
parameter [7:0]   SAT_MIN      = 8'd24,  // delta 绝对下限，暗处的色相不可信
parameter [4:0]   SAT_Q4       = 5'd5,   // 饱和度门限，单位 1/16：5 = 0.31

// ---- 色相边界，单位 15 度（见头部说明）----
parameter integer H_RO         = 1,      // R 扇区  RED|ORANGE     15
parameter integer H_OY         = 3,      // R 扇区  ORANGE|YELLOW  45
parameter integer H_PR         = -2,     // R 扇区  PURPLE|RED    330
parameter integer H_YG         = -3,     // G 扇区  YELLOW|GREEN   75
parameter integer H_GC         = 3,      // G 扇区  GREEN|CYAN    165
parameter integer H_CB         = -3,     // B 扇区  CYAN|BLUE     195
parameter integer H_BP         = 1,      // B 扇区  BLUE|PURPLE   255

// ---- 帧判决 ----
parameter [20:0]  MIN_PIX      = 21'd256,
parameter integer PURITY_SHIFT = 1,      // 1 = 赢家至少占一半票
parameter integer CONFIRM      = 3,      // 1..15

// ---- 10-28 均值判决（MEAN_MODE 1，见头部）----
parameter integer MEAN_MODE    = 0,      // 0 = 只用逐像素投票（旧版逐位）
parameter [8:0]   WB_R         = 9'd256, // 白平衡增益 Q8（256 = 1.0），只乘平均色
parameter [8:0]   WB_G         = 9'd256,
parameter [8:0]   WB_B         = 9'd256,
parameter [7:0]   M_SAT_MIN    = 8'd10,  // 平均色 delta 下限
parameter [7:0]   M_SAT_Q7     = 8'd15,  // 平均色饱和度门限，单位 1/128：15 = 0.117
// 色相边界，单位 7.5 度（8t 与 k*delta 比）：和 H_* 同样的 7 条边界，
// 唯独 ORANGE|YELLOW 从 45 挪到 37.5 度 —— 浅黄纸白平衡后在 48~50 度，离 45 太近
parameter integer M_RO         = 2,      // 15
parameter integer M_OY         = 5,      // 37.5
parameter integer M_PR         = -4,     // 330
parameter integer M_YG         = -6,     // 75
parameter integer M_GC         = 6,      // 165
parameter integer M_CB         = -6,     // 195
parameter integer M_BP         = 2       // 255
)(
input  wire        clk,
input  wire        rst_n,

input  wire        in_vs,
input  wire        in_de,
input  wire [23:0] in_rgb,         // {R,G,B}，相机画面（view_mode = 2'b00）
input  wire        in_mask,        // 1 = 黑色背景，0 = 物体；和 in_rgb 同拍

input  wire        box_valid,
input  wire [11:0] box_x0,
input  wire [11:0] box_y0,
input  wire [11:0] box_x1,         // 含端点
input  wire [11:0] box_y1,

output reg  [3:0]  color_id,       // 本帧结果
output reg         color_valid,
output reg  [3:0]  stable_id,      // 连续 CONFIRM 帧一致后的结果，用这个
output reg         stable_valid,
output reg         res_stb,        // 每帧一拍，以上全部输出在这拍更新
output reg  [20:0] win_cnt,        // 赢家票数
output reg  [20:0] tot_cnt,        // 总票数
output reg  [7:0]  mean_r,         // 投票像素的平均 RGB（标定用）
output reg  [7:0]  mean_g,
output reg  [7:0]  mean_b,
output wire [63:0] color_text      // stable_id 的 8 字符 ASCII 名字
);

localparam [3:0] C_BLACK  = 4'd0,
                 C_GRAY   = 4'd1,
                 C_WHITE  = 4'd2,
                 C_RED    = 4'd3,
                 C_ORANGE = 4'd4,
                 C_YELLOW = 4'd5,
                 C_GREEN  = 4'd6,
                 C_CYAN   = 4'd7,
                 C_BLUE   = 4'd8,
                 C_PURPLE = 4'd9,
                 C_NONE   = 4'd15;
localparam integer NCLS = 10;
localparam integer EW   = ERODE_L + ERODE_R + 1;

//------------------------------------------------------------------------
// [1] 坐标 —— 与 black_color_detect_cnn 的 [1] 同一写法，坐标系一致
//------------------------------------------------------------------------
reg [11:0] px, py;
reg        de_prev, vs_prev;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        px <= 12'd0; py <= 12'd0;
        de_prev <= 1'b0; vs_prev <= 1'b0;
    end else begin
        de_prev <= in_de;
        vs_prev <= in_vs;
        if (!in_vs) begin
            px <= 12'd0;
            py <= 12'd0;
        end else if (in_de) begin
            px <= px + 1'b1;
        end else begin
            px <= 12'd0;
            if (de_prev) py <= py + 1'b1;
        end
    end
end

wire frame_evt = in_vs & ~vs_prev;      // 一帧一次，在场消隐里：结算 + 清零

// 本帧第一个有效像素（第 0 行行首）。py 在场消隐里一直是 0，两种 vs 读法都成立。
// 这一拍本身还用旧框判断 (0,0) 这一个像素，它不可能在内缩后的框里，无影响。
wire box_evt = in_de & ~de_prev & (py == 12'd0);

//------------------------------------------------------------------------
// [2] 检测框：本帧第一个像素锁存并内缩，整帧不变。缩完不够大就当没有框。
//     ccl_blob 的 blob_* 只在 S_PUB 一拍变化，任何一拍采到的都是同一帧的完整一组。
//------------------------------------------------------------------------
reg        bx_ok;
reg [11:0] bx0, bx1, by0, by1;

wire [12:0] x_need  = {1'b0, box_x0} + 2*BOX_MARGIN;
wire [12:0] y_need  = {1'b0, box_y0} + 2*BOX_MARGIN;
wire        box_big = ({1'b0, box_x1} >= x_need) && ({1'b0, box_y1} >= y_need);

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        bx_ok <= 1'b0;
        bx0 <= 12'd0; bx1 <= 12'd0; by0 <= 12'd0; by1 <= 12'd0;
    end else if (box_evt) begin
        bx_ok <= box_valid && box_big;
        bx0   <= box_x0 + BOX_MARGIN;
        bx1   <= box_x1 - BOX_MARGIN;       // box_big 保证不下溢
        by0   <= box_y0 + BOX_MARGIN;
        by1   <= box_y1 - BOX_MARGIN;
    end
end

wire in_box = (USE_BOX == 0) ? 1'b1
            : (bx_ok && (px >= bx0) && (px <= bx1) && (py >= by0) && (py <= by1));

//------------------------------------------------------------------------
// [3] 候选像素 @1
//------------------------------------------------------------------------
reg        s1_obj;
reg [23:0] s1_rgb;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) s1_obj <= 1'b0;
    else        s1_obj <= in_de & ~in_mask & in_box;
end

always @(posedge clk) s1_rgb <= in_rgb;

//------------------------------------------------------------------------
// [4] 水平腐蚀。esr[0] 最新（右侧），esr[EW-1] 最老（左侧），
//     中心像素是 esr[ERODE_R]，其 RGB 是 erg[ERODE_R]。
//     行间消隐远长于窗口，所以窗口不会跨行。
//------------------------------------------------------------------------
reg [EW-1:0] esr;
reg [23:0]   erg [0:ERODE_R];
integer k;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) esr <= {EW{1'b0}};
    else        esr <= (esr << 1) | s1_obj;
end

always @(posedge clk) begin
    erg[0] <= s1_rgb;
    for (k = 1; k <= ERODE_R; k = k + 1)
        erg[k] <= erg[k-1];
end

// @2：投票资格 + 对应 RGB
reg       q2;
reg [7:0] r2, g2, b2;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) q2 <= 1'b0;
    else        q2 <= &esr;
end

always @(posedge clk) begin
    r2 <= erg[ERODE_R][23:16];
    g2 <= erg[ERODE_R][15:8];
    b2 <= erg[ERODE_R][7:0];
end

//------------------------------------------------------------------------
// [5] 分类流水线 @3..@6，每级只做一件事，150 MHz 留足余量
//------------------------------------------------------------------------
// @3 : max / min / 扇区（0 = R, 1 = G, 2 = B；并列时 R > G > B 优先）
reg       q3;
reg [7:0] r3, g3, b3, mx3, mn3;
reg [1:0] sec3;

wire rg = (r2 >= g2);
wire rb = (r2 >= b2);
wire gb = (g2 >= b2);

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) q3 <= 1'b0;
    else        q3 <= q2;
end

always @(posedge clk) begin
    r3 <= r2; g3 <= g2; b3 <= b2;
    if (rg && rb) begin
        sec3 <= 2'd0; mx3 <= r2; mn3 <= gb ? b2 : g2;
    end else if (gb) begin
        sec3 <= 2'd1; mx3 <= g2; mn3 <= rb ? b2 : r2;
    end else begin
        sec3 <= 2'd2; mx3 <= b2; mn3 <= rg ? g2 : r2;
    end
end

// @4 : delta 和扇区内的有符号差 t
reg              q4;
reg [7:0]        r4, g4, b4, mx4, d4;
reg [1:0]        sec4;
reg signed [9:0] t4;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) q4 <= 1'b0;
    else        q4 <= q3;
end

always @(posedge clk) begin
    r4 <= r3; g4 <= g3; b4 <= b3;
    mx4  <= mx3;
    d4   <= mx3 - mn3;
    sec4 <= sec3;
    case (sec3)
    2'd0:    t4 <= $signed({2'b00, g3}) - $signed({2'b00, b3});
    2'd1:    t4 <= $signed({2'b00, b3}) - $signed({2'b00, r3});
    default: t4 <= $signed({2'b00, r3}) - $signed({2'b00, g3});
    endcase
end

// @5 : 全部比较位
wire signed [13:0] tq    = $signed({t4[9], t4[9], t4, 2'b00});   // 4t
wire signed [13:0] dq    = $signed({6'd0, d4});
wire        [13:0] sat_l = {2'b00, d4, 4'b0000};                 // 16*delta
wire        [13:0] sat_r = mx4 * SAT_Q4;                         // SAT_Q4*mx

reg       q5;
reg [7:0] r5, g5, b5;
reg [1:0] sec5;
reg       dark5, white5, chroma5;
reg       f_oy, f_ro, f_pr, f_yg, f_gc, f_cb, f_bp;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) q5 <= 1'b0;
    else        q5 <= q4;
end

always @(posedge clk) begin
    r5 <= r4; g5 <= g4; b5 <= b4;
    sec5    <= sec4;
    dark5   <= (mx4 <  V_BLACK);
    white5  <= (mx4 >= V_WHITE);
    chroma5 <= (d4 >= SAT_MIN) && (sat_l >= sat_r);
    f_oy    <= (tq >= H_OY * dq);
    f_ro    <= (tq >= H_RO * dq);
    f_pr    <= (tq >= H_PR * dq);
    f_yg    <= (tq <  H_YG * dq);
    f_gc    <= (tq <  H_GC * dq);
    f_cb    <= (tq <  H_CB * dq);
    f_bp    <= (tq <  H_BP * dq);
end

// @6 : 类别
reg       q6;
reg [7:0] r6, g6, b6;
reg [3:0] c6;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) q6 <= 1'b0;
    else        q6 <= q5;
end

always @(posedge clk) begin
    r6 <= r5; g6 <= g5; b6 <= b5;
    if (dark5)
        c6 <= C_BLACK;
    else if (!chroma5)
        c6 <= white5 ? C_WHITE : C_GRAY;
    else case (sec5)
        2'd0:    c6 <= f_oy ? C_YELLOW : f_ro ? C_ORANGE : f_pr ? C_RED  : C_PURPLE;
        2'd1:    c6 <= f_yg ? C_YELLOW : f_gc ? C_GREEN  : C_CYAN;
        default: c6 <= f_cb ? C_CYAN   : f_bp ? C_BLUE   : C_PURPLE;
    endcase
end

//------------------------------------------------------------------------
// [6] 整帧累加 @7。frame_evt 时快照并清零：此刻流水线里不可能有有效像素
//     （上一帧最后一行早已过去，下一帧第一个像素还要十几拍才到 @7）。
//------------------------------------------------------------------------
reg [20:0] cnt [0:NCLS-1];
reg [20:0] tot;
reg [28:0] sum_r, sum_g, sum_b;
integer i;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        for (i = 0; i < NCLS; i = i + 1) cnt[i] <= 21'd0;
        tot   <= 21'd0;
        sum_r <= 29'd0; sum_g <= 29'd0; sum_b <= 29'd0;
    end else if (frame_evt) begin
        for (i = 0; i < NCLS; i = i + 1) cnt[i] <= 21'd0;
        tot   <= 21'd0;
        sum_r <= 29'd0; sum_g <= 29'd0; sum_b <= 29'd0;
    end else if (q6) begin
        cnt[c6] <= cnt[c6] + 1'b1;
        tot     <= tot + 1'b1;
        sum_r   <= sum_r + r6;
        sum_g   <= sum_g + g6;
        sum_b   <= sum_b + b6;
    end
end

reg [20:0] snap [0:NCLS-1];
reg [20:0] snap_tot;
reg [28:0] snap_r, snap_g, snap_b;
integer j;

always @(posedge clk) begin
    if (frame_evt) begin
        for (j = 0; j < NCLS; j = j + 1) snap[j] <= cnt[j];
        snap_tot <= tot;
        snap_r   <= sum_r;
        snap_g   <= sum_g;
        snap_b   <= sum_b;
    end
end

//------------------------------------------------------------------------
// [7] 帧判决，消隐期里顺序做完（约 20 拍）：
//     ARG  10 拍逐类找最大
//     DIV   8 拍恢复除法求平均（sum <= 255*tot，商必在 8 位内），三通道并行
//     PUB   1 拍出结果 + 稳定化
//     MEAN_MODE 1 在 DIV 和 PUB 之间多 5 拍：WB、M1..M4（平均色分类）
//------------------------------------------------------------------------
localparam [2:0] S_IDLE = 3'd0,
                 S_ARG  = 3'd1,
                 S_DIV  = 3'd2,
                 S_PUB  = 3'd3,
                 S_WB   = 3'd4,
                 S_M1   = 3'd5,
                 S_M2   = 3'd6,
                 S_M3   = 3'd7;

reg [2:0]  st;
reg [3:0]  ai;
reg [3:0]  best;
reg [20:0] bestc;
reg [2:0]  di;
reg [28:0] dv;
reg [28:0] rem_r, rem_g, rem_b;
reg [7:0]  qr, qg, qb;
reg [3:0]  last_cand;
reg [3:0]  agree;

wire       pix_ok   = (snap_tot >= MIN_PIX);
wire       pure_ok  = (bestc >= (snap_tot >> PURITY_SHIFT));
wire       frm_ok   = pix_ok && pure_ok && (best != C_NONE);
wire       best_chr = (best >= C_RED) && (best <= C_PURPLE);
reg  [3:0] mcls;                       // 平均色的类别（MEAN_MODE 1），M3 写入
wire [3:0] cand     = (MEAN_MODE == 0) ? (frm_ok ? best : C_NONE)
                    : (frm_ok && best_chr) ? best
                    : pix_ok               ? mcls
                    :                        C_NONE;
wire [3:0] agree_n  = (cand != last_cand) ? 4'd1
                    : (agree < CONFIRM)   ? agree + 4'd1
                    :                       agree;
wire       tot_zero = (snap_tot == 21'd0);

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        st    <= S_IDLE;
        ai    <= 4'd0;
        best  <= C_NONE;
        bestc <= 21'd0;
        di    <= 3'd0;
        dv    <= 29'd0;
        rem_r <= 29'd0; rem_g <= 29'd0; rem_b <= 29'd0;
        qr    <= 8'd0;  qg    <= 8'd0;  qb    <= 8'd0;
        last_cand    <= C_NONE;
        agree        <= 4'd0;
        color_id     <= C_NONE;
        color_valid  <= 1'b0;
        stable_id    <= C_NONE;
        stable_valid <= 1'b0;
        res_stb      <= 1'b0;
        win_cnt      <= 21'd0;
        tot_cnt      <= 21'd0;
        mean_r <= 8'd0; mean_g <= 8'd0; mean_b <= 8'd0;
    end else begin
        res_stb <= 1'b0;
        case (st)
        S_IDLE: begin
            if (frame_evt) begin           // snap 在同一拍写入
                st    <= S_ARG;
                ai    <= 4'd0;
                best  <= C_NONE;
                bestc <= 21'd0;
            end
        end

        S_ARG: begin                       // 并列时编号小的赢
            if (snap[ai] > bestc) begin
                best  <= ai;
                bestc <= snap[ai];
            end
            if (ai == NCLS - 1) begin
                st    <= S_DIV;
                di    <= 3'd7;
                dv    <= {1'b0, snap_tot, 7'd0};    // tot << 7
                rem_r <= snap_r; rem_g <= snap_g; rem_b <= snap_b;
                qr    <= 8'd0;   qg    <= 8'd0;   qb    <= 8'd0;
            end else begin
                ai <= ai + 4'd1;
            end
        end

        S_DIV: begin
            if (rem_r >= dv) begin rem_r <= rem_r - dv; qr[di] <= 1'b1; end
            if (rem_g >= dv) begin rem_g <= rem_g - dv; qg[di] <= 1'b1; end
            if (rem_b >= dv) begin rem_b <= rem_b - dv; qb[di] <= 1'b1; end
            dv <= dv >> 1;
            if (di == 3'd0) st <= (MEAN_MODE != 0) ? S_WB : S_PUB;
            else            di <= di - 3'd1;
        end

        S_WB: st <= S_M1;                  // [7b] 的寄存器按 st 推进
        S_M1: st <= S_M2;
        S_M2: st <= S_M3;
        S_M3: st <= S_PUB;

        S_PUB: begin
            color_id    <= cand;
            color_valid <= (cand != C_NONE);   // MEAN_MODE 0 时就是 frm_ok
            win_cnt     <= bestc;
            tot_cnt     <= snap_tot;
            mean_r      <= tot_zero ? 8'd0 : qr;
            mean_g      <= tot_zero ? 8'd0 : qg;
            mean_b      <= tot_zero ? 8'd0 : qb;

            last_cand   <= cand;
            agree       <= agree_n;
            if (agree_n >= CONFIRM) begin
                stable_id    <= cand;
                stable_valid <= (cand != C_NONE);
            end

            res_stb <= 1'b1;
            st      <= S_IDLE;
        end
        endcase
    end
end

//------------------------------------------------------------------------
// [7b] 10-28 平均色分类（MEAN_MODE 1）。DIV 最后一拍 qr/qg/qb 写完，之后：
//     WB  乘白平衡增益（常数，综合成加法）并饱和到 255
//     M1  扇区 / 最大 / 最小（并列 R > G > B，和 [5] 相同）
//     M2  delta 和扇区内有符号差 t
//     M3  比较并出类别 mcls，PUB 那拍 cand 用它
// 每拍只有一级运算；MEAN_MODE 0 时 mcls 没人读，整段被综合掉。
//------------------------------------------------------------------------
wire [16:0] wpr = qr * WB_R;
wire [16:0] wpg = qg * WB_G;
wire [16:0] wpb = qb * WB_B;

reg  [7:0]        wr, wg, wb;
reg  [7:0]        r_m, g_m, b_m, mx_m, mn_m, d_m, mxd_m;
reg  [1:0]        sec_m, sec_d;
reg  signed [9:0] t_m;

wire signed [13:0] tq_m  = $signed({t_m[9], t_m, 3'b000});   // 8t
wire signed [13:0] dq_m  = $signed({6'd0, d_m});
wire        [14:0] msat_l = {d_m, 7'd0};                 // 128*delta
wire        [14:0] msat_r = mxd_m * M_SAT_Q7;            // M_SAT_Q7*mx

always @(posedge clk) begin
    if (st == S_WB) begin
        wr <= (wpr[16:8] > 9'd255) ? 8'd255 : wpr[15:8];
        wg <= (wpg[16:8] > 9'd255) ? 8'd255 : wpg[15:8];
        wb <= (wpb[16:8] > 9'd255) ? 8'd255 : wpb[15:8];
    end
    if (st == S_M1) begin
        r_m <= wr; g_m <= wg; b_m <= wb;
        if (wr >= wg && wr >= wb) begin
            sec_m <= 2'd0; mx_m <= wr; mn_m <= (wg >= wb) ? wb : wg;
        end else if (wg >= wb) begin
            sec_m <= 2'd1; mx_m <= wg; mn_m <= (wr >= wb) ? wb : wr;
        end else begin
            sec_m <= 2'd2; mx_m <= wb; mn_m <= (wr >= wg) ? wg : wr;
        end
    end
    if (st == S_M2) begin
        d_m   <= mx_m - mn_m;
        mxd_m <= mx_m;
        sec_d <= sec_m;
        case (sec_m)
        2'd0:    t_m <= $signed({2'b00, g_m}) - $signed({2'b00, b_m});
        2'd1:    t_m <= $signed({2'b00, b_m}) - $signed({2'b00, r_m});
        default: t_m <= $signed({2'b00, r_m}) - $signed({2'b00, g_m});
        endcase
    end
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n)
        mcls <= C_NONE;
    else if (st == S_M3) begin
        if (mxd_m < V_BLACK)
            mcls <= C_BLACK;
        else if (!((d_m >= M_SAT_MIN) && (msat_l >= msat_r)))
            mcls <= (mxd_m >= V_WHITE) ? C_WHITE : C_GRAY;
        else case (sec_d)
            2'd0:    mcls <= (tq_m >= M_OY * dq_m) ? C_YELLOW
                           : (tq_m >= M_RO * dq_m) ? C_ORANGE
                           : (tq_m >= M_PR * dq_m) ? C_RED : C_PURPLE;
            2'd1:    mcls <= (tq_m <  M_YG * dq_m) ? C_YELLOW
                           : (tq_m <  M_GC * dq_m) ? C_GREEN : C_CYAN;
            default: mcls <= (tq_m <  M_CB * dq_m) ? C_CYAN
                           : (tq_m <  M_BP * dq_m) ? C_BLUE : C_PURPLE;
        endcase
    end
end

//------------------------------------------------------------------------
// [8] 名字，8 个 ASCII 字符，高字节在左
//------------------------------------------------------------------------
function [63:0] cname;
    input [3:0] c;
    begin
        case (c)
        C_BLACK : cname = "BLACK   ";
        C_GRAY  : cname = "GRAY    ";
        C_WHITE : cname = "WHITE   ";
        C_RED   : cname = "RED     ";
        C_ORANGE: cname = "ORANGE  ";
        C_YELLOW: cname = "YELLOW  ";
        C_GREEN : cname = "GREEN   ";
        C_CYAN  : cname = "CYAN    ";
        C_BLUE  : cname = "BLUE    ";
        C_PURPLE: cname = "PURPLE  ";
        default : cname = "--      ";
        endcase
    end
endfunction

assign color_text = cname(stable_id);

endmodule