﻿//---------------------------------------------------------------------------
// stain_overlay -- 把 stain_detect 判定的热格画成红色半透明覆盖层。
//
// WHY
//   hot_cells / 热格包围盒都只是统计量，分不清"一条边""散布全图""一小块真污渍"
//   这三种情况 —— 而它们要改的东西完全不同。2026-10-21 和 10-24 两轮修复都栽在
//   同一个地方：H 从 255 降到个位数【看起来】像好了，但包围盒 X00-61Y03-61 说明
//   热格仍然散布在整个网格上，即残留的还是噪声。
//
//   把热格直接画在工件上，"散布的噪点"和"聚成一团的污渍"一眼就能分开，不需要
//   再从数字去猜。这是定位这类问题最直接的工具。
//
// 坐标映射
//   stain_detect 的格号是 cx = ((px-X0)*RX)>>16，RX = (G<<16)/W。本模块必须用
//   【完全相同】的算法，否则红色会和实际判定的格子错位 —— 那比不画还糟，因为它
//   会把人引向错误的结论。
//
//   RX/RY 没从 stain_detect 导出，所以这里自己算一遍：帧首取框，用同一套 17 拍
//   移位减法除法。除法在消隐期做完，像素路径上只剩一个乘法和一次移位。
//
//   ⚠⚠ 必须用 G=128 算 RX 再把格号 >>1，【不能】直接用 HG=64 算 RX。
//   两者看着等价，其实不是：((p*RX128)>>16)>>1 是两次取整，((p*RX64)>>16) 是
//   一次，在某些宽度下差一格。实测（check_overlay_map.py，逐像素穷举）:
//       W=630 -> 偏移 443 处差 1 格   W=650 -> 偏移 518 处
//       W=700 -> 偏移 536 处          W=1080 -> 偏移 827 和 962 处
//   板上工件正好是 630x628，所以这不是理论问题。硬件代价相同（乘法都是 12x17，
//   >>1 只是一根线），所以直接用和 stain_detect 逐位相同的表达式。
//
//   G 在本模块里写死 128（= SCNN_G），HG 只用来做范围检查。
//
// 像素路径
//   一个 12x17 乘法 + 一次移位 + 一次 1 bit 查表 + 一次混色。乘法在 DSP 里，
//   和 det_overlay 的 64 个比较器相比便宜得多。
//
// 半透明而不是实心
//   实心会盖掉污渍本身，而看污渍【长什么样】恰恰是判断"这是不是真污渍"的依据。
//   50% 混合既能看出热格位置，又保留了下面的画面。
//
// LATENCY 3 clocks on data, de and vs alike.
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module stain_overlay #(
parameter integer IMG_HDISP = 1920,
parameter integer IMG_VDISP = 1080,
parameter integer G         = 128,         // 累加网格边长，必须等于 SCNN_G
parameter integer HG        = 64,          // HEAD 网格边长，必须等于 SCNN_HG
parameter [23:0]  HOT_RGB   = 24'hFF0000   // 红色；黄=检测框，绿=运动，红=热格
)(
input  wire        clk,
input  wire        rst_n,
input  wire        en,

// 来自 stain_detect 的热格位图读口
output wire [11:0] hmap_ra,
input  wire        hmap_q,
input  wire        hmap_vld,
input  wire [11:0] hmap_x0,
input  wire [11:0] hmap_y0,
input  wire [11:0] hmap_x1,
input  wire [11:0] hmap_y1,

input  wire        in_vs,          // HIGH across the visible frame
input  wire        in_de,
input  wire [23:0] in_rgb,

output reg         out_vs,
output reg         out_de,
output reg  [23:0] out_rgb
);

// ====================================================================
// [0] 像素坐标
// ====================================================================
reg [11:0] px, py;
reg        de_d, vs_d;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        px <= 12'd0; py <= 12'd0; de_d <= 1'b0; vs_d <= 1'b1;
    end else begin
        de_d <= in_de;
        vs_d <= in_vs;
        px   <= in_de ? px + 12'd1 : 12'd0;
        if (in_vs & ~vs_d)      py <= 12'd0;
        else if (de_d & ~in_de) py <= py + 12'd1;
    end
end

wire frame_start = in_vs & ~vs_d;

// ====================================================================
// [1] 帧首锁存框 + 算 RX/RY（和 stain_detect 同一套移位减法除法）
// ====================================================================
reg [11:0] bx0, by0, bx1, by1;
reg [31:0] rx, ry;
reg        box_ok;

reg [1:0]  div_st;
reg        div_ph;
reg [31:0] div_num, div_den, div_q;
reg [4:0]  div_cnt;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        bx0 <= 12'd0; by0 <= 12'd0; bx1 <= 12'd0; by1 <= 12'd0;
        rx <= 32'd0; ry <= 32'd0; box_ok <= 1'b0;
        div_st <= 2'd0; div_ph <= 1'b0;
        div_num <= 32'd0; div_den <= 32'd0; div_q <= 32'd0; div_cnt <= 5'd0;
    end else if (frame_start) begin
        bx0 <= hmap_x0; by0 <= hmap_y0;
        bx1 <= hmap_x1; by1 <= hmap_y1;
        box_ok <= hmap_vld && (hmap_x1 > hmap_x0) && (hmap_y1 > hmap_y0);
        if (hmap_vld && (hmap_x1 > hmap_x0) && (hmap_y1 > hmap_y0)) begin
            div_st  <= 2'd1;
            div_ph  <= 1'b0;
            div_num <= G << 16;
            div_den <= hmap_x1 - hmap_x0 + 12'd1;
        end else begin
            div_st  <= 2'd0;
        end
    end else begin
        case (div_st)
        2'd1: begin
            div_q   <= 32'd0;
            div_cnt <= 5'd16;
            div_st  <= 2'd2;
        end
        2'd2: begin
            if (div_num >= (div_den << div_cnt)) begin
                div_q[div_cnt] <= 1'b1;
                div_num        <= div_num - (div_den << div_cnt);
            end
            if (div_cnt == 5'd0) div_st  <= 2'd3;
            else                 div_cnt <= div_cnt - 5'd1;
        end
        2'd3: begin
            if (!div_ph) begin
                rx      <= div_q;
                div_num <= G << 16;
                div_den <= by1 - by0 + 12'd1;
                div_ph  <= 1'b1;
                div_st  <= 2'd1;
            end else begin
                ry      <= div_q;
                div_st  <= 2'd0;
            end
        end
        default: ;
        endcase
    end
end

// ====================================================================
// [2] s1: 框内判定 + 格号（乘法）
// ====================================================================
wire in_box = box_ok & in_de
            & (px >= bx0) & (px <= bx1)
            & (py >= by0) & (py <= by1);

reg [31:0] mul_cx, mul_cy;
reg        s1_in, s1_de, s1_vs;
reg [23:0] s1_rgb;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        s1_in <= 1'b0; s1_de <= 1'b0; s1_vs <= 1'b0;
    end else begin
        s1_in <= in_box;
        s1_de <= in_de;
        s1_vs <= in_vs;
    end
end

always @(posedge clk) begin
    mul_cx <= (px - bx0) * rx;
    mul_cy <= (py - by0) * ry;
    s1_rgb <= in_rgb;
end

// 格号：和 stain_detect 的 mul_cx[22:16] 逐位相同，再 >>1 得 HEAD 格号。
// 见文件头的 ⚠⚠ —— 不能图省事直接按 HG 算 RX。
wire [6:0] cx_acc = mul_cx[22:16];
wire [6:0] cy_acc = mul_cy[22:16];
wire [5:0] cx = cx_acc[6:1];
wire [5:0] cy = cy_acc[6:1];

assign hmap_ra = {cy, cx};

// ====================================================================
// [3] s2: 位图读出（stain_detect 内部寄存一拍）在这一拍有效
//
// ⚠ 不要再给 hmap_q 加一级寄存器。对齐关系是：
//     T   : px / in_rgb 有效，in_box 组合算出
//     T+1 : s1_in = in_box(T)，mul_cx = f(px(T))，hmap_ra 组合有效（像素 T）
//     T+2 : hmap_q = 位图[hmap_ra(T+1)]（像素 T）；s2_in = s1_in（像素 T）✓
//     T+3 : 输出寄存器用 s2_in 和 hmap_q，都是像素 T ✓
//   再加一级会让 hmap_q 落后 s2_in 一个像素，红色整体左移一格。
// ====================================================================
reg        s2_in, s2_de, s2_vs;
reg [23:0] s2_rgb;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        s2_in <= 1'b0; s2_de <= 1'b0; s2_vs <= 1'b0;
    end else begin
        s2_in <= s1_in;
        s2_de <= s1_de;
        s2_vs <= s1_vs;
    end
end

always @(posedge clk) s2_rgb <= s1_rgb;

// ====================================================================
// [4] 输出：热格处 50% 混红（各通道先右移 1 位再相加，不会溢出）
// ====================================================================
wire [7:0] mr = {1'b0, s2_rgb[23:17]} + {1'b0, HOT_RGB[23:17]};
wire [7:0] mg = {1'b0, s2_rgb[15:9]}  + {1'b0, HOT_RGB[15:9]};
wire [7:0] mb = {1'b0, s2_rgb[7:1]}   + {1'b0, HOT_RGB[7:1]};

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        out_rgb <= 24'd0;
        out_vs  <= 1'b0;
        out_de  <= 1'b0;
    end else begin
        if (en && s2_in && hmap_q)
            out_rgb <= {mr, mg, mb};
        else
            out_rgb <= s2_rgb;
        out_vs <= s2_vs;
        out_de <= s2_de;
    end
end

endmodule
