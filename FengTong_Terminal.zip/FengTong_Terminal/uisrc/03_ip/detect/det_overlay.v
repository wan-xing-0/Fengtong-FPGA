//---------------------------------------------------------------------------
// det_overlay -- draws the detection bounding boxes.
//
// Sits after hist_osd and before text_osd, so the boxes go over the histogram
// (which is a tuning aid) but under the status panel and the logo (which are
// scored items and have to stay legible).  Fed frame-active-high vs, same as
// both of its neighbours.
//
// WHY YELLOW
//   motion_frame_drawer already owns green.  The two overlays can be on at the
//   same time -- MOTION on the wheel plus F9 in a detect state -- and a demo
//   in which the judge cannot tell the motion box from the detection box has
//   thrown away the distinction between two separate scored items.
//
// THE BOXES ARE A FRAME OLD, BY CONSTRUCTION
//   ccl_blob cannot know the bottom-right blob's extent until the last pixel
//   of the frame, so its results are published in blanking and drawn on the
//   frame after.  Same 16ms lag motion_frame_drawer's box already carries, and
//   invisible for the same reason.  The upside is that no handshake is needed:
//   the coordinates are latched here once per frame and are then constant for
//   every pixel of it.
//
// WHY THE EDGE TESTS ARE PRECOMPUTED PER FRAME
//   x0+THICK and x1-THICK change once a frame, so they are registered at frame
//   start rather than recomputed 2.07 million times.  What is left in the pixel
//   path is eight magnitude compares per box and nothing else -- no add, no
//   multiply.  With NBLOB = 8 that is 64 eleven-bit compares, which is the real
//   cost of this module and the reason it is split across three clocks: the
//   compares register into stage 2, the per-box AND/OR into stage 3, and the
//   colour mux is stage 3's output register.  Folded into two stages it would
//   be a compare plus a wide OR in one period, and this design has 0.1ns of
//   setup slack.
//
//   If P&R comes back with clk0 regressed, NBLOB is the dial: 4 halves the
//   comparator count and still covers both demo modes.
//
// LATENCY 3 clocks on data, de and vs alike.  latency_meter measures the chain
// rather than assuming it, so the OSD reading follows this automatically.
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module det_overlay #(
parameter integer NBLOB     = 8,
parameter [23:0]  BOX_RGB   = 24'hFFFF00,   // yellow -- motion's box is green
parameter integer BOX_THICK = 3,

// Clocks of "de has stayed low" that mean the frame has ended rather than a
// line.  Same parameter, same reason and same scaling rule as ccl_blob's --
// see [2].  Hardware: horizontal blanking is 220 clocks, the vertical
// interval is 99,000, 512 sits between them.
parameter integer VB_GUARD   = 512,

// 1 = latch over in_vs's low period, bit-exactly the way this module did
// before 2026-09-18.  See [2] for why that window is the wrong one.
parameter integer VS_LATCH   = 0
)(
input  wire        clk,
input  wire        rst_n,
input  wire        en,

// From ccl_blob.  Constant across a frame; latched here at frame start.
input  wire [NBLOB*12-1:0] blob_x0,
input  wire [NBLOB*12-1:0] blob_x1,
input  wire [NBLOB*12-1:0] blob_y0,
input  wire [NBLOB*12-1:0] blob_y1,
input  wire [NBLOB-1:0]    blob_valid,

input  wire        in_vs,          // HIGH across the visible frame
input  wire        in_de,
input  wire [23:0] in_rgb,

output reg         out_vs,
output reg         out_de,
output reg  [23:0] out_rgb
);

// One loop variable per always block.  Sharing a module-level integer between
// two clocked blocks is a synthesis hazard even where simulation tolerates it.
integer m;      // [2] box latch
integer mc;     // [3] comparators

//------------------------------------------------------------------------
// [1] Pixel coordinates.  Same eight lines as every other module here.
//------------------------------------------------------------------------
reg [11:0] px, py;
reg        de_prev;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        px <= 12'd0; py <= 12'd0; de_prev <= 1'b0;
    end else begin
        de_prev <= in_de;
        if (!in_vs) begin
            px <= 12'd0;
            py <= 12'd0;
        end
        else if (in_de) begin
            px <= px + 12'd1;
        end
        else begin
            px <= 12'd0;
            if (de_prev) py <= py + 12'd1;
        end
    end
end

//------------------------------------------------------------------------
// [2] Latch the boxes and their inset edges.
//
// THE ENABLE IS THE WHOLE VERTICAL INTERVAL, NOT THE RISING EDGE OF vs.
// This is not a style choice, it fixes a real one-pixel bug.
//
// ⚠⚠ AND IT USED TO SAY `!in_vs`, WHICH IS NOT THE WHOLE VERTICAL INTERVAL
// (fixed 2026-09-18).  in_vs on this chain is ~vtc_vs -- the inverted
// FIVE-line sync pulse (uivtc: vcnt 1085..1089) -- and it is high across the
// 4-line front porch and the 35-line back porch as well as the visible
// frame.  So this latch was open for 5 lines of the 45, and the sentence
// below about "worst case ~67,600 clocks into a 99,000-clock interval" was
// describing a window this module never had.  ccl_blob had the identical bug
// on the same signal, where it cost the boxes outright; see its [1].  Here it
// costs one frame of box lag whenever ccl_blob publishes after the pulse has
// passed, which is most of the interval.
//
// de is the honest edge: out_de through the detect chain is a plain shift of
// in_de, so it carries uivtc's geometry -- low for 220 clocks between active
// lines, low for 45 line times between frames.  The latch is now open for
// exactly the interval the paragraph below assumes, and closes on the frame's
// first active pixel, which is what the one-pixel argument needs.
//
//   Latching on the frame's first clock puts the new coordinates in these
//   registers at the SAME edge the comparators below sample the old ones,
//   because the comparator stage is one clock later.  For exactly one pixel
//   -- (0,0), the first of every frame -- `hit` then combines the previous
//   frame's coordinates with the new frame's validity bits.  With a previous
//   frame that published nothing, x0 = x1 = 0 and x0+THICK = 1, which reads as
//   "inside the box AND on its edge" at (0,0), and a stray yellow dot appears
//   in the corner on the frame after every empty one.
//
//   Latching throughout blanking instead means the registers are already
//   stable when the frame's first pixel arrives, and they then hold for the
//   whole frame because the latch enable stays low through horizontal
//   blanking.  No boundary case left to get wrong.  It relies on ccl_blob
//   having published by then, which is the condition its own header documents
//   (worst case ~80,900 clocks into a 99,000-clock interval) -- and which is
//   only actually true since both modules stopped gating on in_vs.
//
// The x1-THICK clamp matters too: a box narrower than the line width would
// otherwise wrap to 0xFFF and the right-hand edge would never draw.  Clamped
// to 0 the whole narrow box fills instead, which is the right answer for a
// target only a few pixels across.
//------------------------------------------------------------------------
reg [11:0] bx0  [0:NBLOB-1];
reg [11:0] bx1  [0:NBLOB-1];
reg [11:0] by0  [0:NBLOB-1];
reg [11:0] by1  [0:NBLOB-1];
reg [11:0] bx0t [0:NBLOB-1];
reg [11:0] bx1t [0:NBLOB-1];
reg [11:0] by0t [0:NBLOB-1];
reg [11:0] by1t [0:NBLOB-1];
reg [NBLOB-1:0] bv;

// "de has been low long enough that this is the frame gap, not the line gap."
// dgap saturates rather than wrapping, so a long interval cannot roll it back
// under the guard and reopen the latch mid-frame.
reg [9:0] dgap;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n)               dgap <= 10'd0;
    else if (in_de)           dgap <= 10'd0;
    else if (dgap != 10'h3FF) dgap <= dgap + 10'd1;
end

wire latch_en = (VS_LATCH != 0) ? ~in_vs : (dgap >= VB_GUARD);

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        bv <= {NBLOB{1'b0}};
        for (m = 0; m < NBLOB; m = m + 1) begin
            bx0[m]  <= 12'd0; bx1[m]  <= 12'd0;
            by0[m]  <= 12'd0; by1[m]  <= 12'd0;
            bx0t[m] <= 12'd0; bx1t[m] <= 12'd0;
            by0t[m] <= 12'd0; by1t[m] <= 12'd0;
        end
    end else if (latch_en) begin
        bv <= blob_valid;
        for (m = 0; m < NBLOB; m = m + 1) begin
            bx0[m] <= blob_x0[m*12 +: 12];
            bx1[m] <= blob_x1[m*12 +: 12];
            by0[m] <= blob_y0[m*12 +: 12];
            by1[m] <= blob_y1[m*12 +: 12];

            bx0t[m] <= blob_x0[m*12 +: 12] + BOX_THICK;
            by0t[m] <= blob_y0[m*12 +: 12] + BOX_THICK;

            bx1t[m] <= (blob_x1[m*12 +: 12] >= BOX_THICK)
                     ? (blob_x1[m*12 +: 12] -  BOX_THICK) : 12'd0;
            by1t[m] <= (blob_y1[m*12 +: 12] >= BOX_THICK)
                     ? (blob_y1[m*12 +: 12] -  BOX_THICK) : 12'd0;
        end
    end
end

//------------------------------------------------------------------------
// [3] Stage 2: the compares.  One always block so each bit has one driver.
//------------------------------------------------------------------------
reg [NBLOB-1:0] xin_r, yin_r, xed_r, yed_r;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        xin_r <= {NBLOB{1'b0}}; yin_r <= {NBLOB{1'b0}};
        xed_r <= {NBLOB{1'b0}}; yed_r <= {NBLOB{1'b0}};
    end else begin
        for (mc = 0; mc < NBLOB; mc = mc + 1) begin
            xin_r[mc] <= (px >= bx0[mc])  && (px <= bx1[mc]);
            yin_r[mc] <= (py >= by0[mc])  && (py <= by1[mc]);
            xed_r[mc] <= (px <  bx0t[mc]) || (px >  bx1t[mc]);
            yed_r[mc] <= (py <  by0t[mc]) || (py >  by1t[mc]);
        end
    end
end

//------------------------------------------------------------------------
// [4] Stage 3: per-box AND, then the reduction.
//------------------------------------------------------------------------
wire [NBLOB-1:0] hit;

genvar b;
generate
    for (b = 0; b < NBLOB; b = b + 1) begin : g_hit
        assign hit[b] = bv[b] & xin_r[b] & yin_r[b] & (xed_r[b] | yed_r[b]);
    end
endgenerate

reg any_hit;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) any_hit <= 1'b0;
    else        any_hit <= |hit;
end

//------------------------------------------------------------------------
// [5] Picture and sync, delayed to match
//------------------------------------------------------------------------
reg [23:0] rgb_d1, rgb_d2;
reg [1:0]  vs_dly, de_dly;

always @(posedge clk) begin
    rgb_d1 <= in_rgb;
    rgb_d2 <= rgb_d1;
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        vs_dly <= 2'b0; de_dly <= 2'b0;
    end else begin
        vs_dly <= {vs_dly[0], in_vs};
        de_dly <= {de_dly[0], in_de};
    end
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        out_rgb <= 24'd0; out_vs <= 1'b0; out_de <= 1'b0;
    end else begin
        out_rgb <= (en && any_hit) ? BOX_RGB : rgb_d2;
        out_vs  <= vs_dly[1];
        out_de  <= de_dly[1];
    end
end

endmodule
