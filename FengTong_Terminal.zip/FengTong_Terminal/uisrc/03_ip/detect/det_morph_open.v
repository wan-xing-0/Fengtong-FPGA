//---------------------------------------------------------------------------
// det_morph_open -- binary opening (erode then dilate) on the detection mask.
// Sits between det_binarize and ccl_blob; one bit per pixel in and out.
//
// WHY AN OPENING AND NOT A BIGGER MARGIN
//   Both suppress speckle, but they suppress different things.  Raising
//   det_binarize's MARGIN moves the decision level away from the frame mean,
//   which throws away low-contrast targets along with the noise and does
//   nothing at all about a large low-amplitude structure -- the lens vignette,
//   which is what put a frame-spanning box on screen on 2026-09-07.  An opening
//   is a decision about SHAPE: it removes what is thin, at any contrast, and
//   leaves what is solid, at any contrast.  The two are complementary and the
//   design now uses both, with MARGIN carrying the noise floor and this
//   carrying the geometry.
//
// WHY IT IS HERE AND NOT ON THE PICTURE PATH
//   morphology_3x3 on D9 already offers erode/dilate, it is upstream of this
//   branch, and it was the free experiment worth trying first.  It is not a
//   substitute: it is greyscale rank-2 morphology on RGB, so it changes what
//   the operator SEES, it is one press away from being switched off mid-demo,
//   and its rank-2 rows deliberately refuse to remove a lone hot pixel (see its
//   header).  Detection needs the cleanup unconditionally and on the bit that
//   ccl_blob actually labels, which is here.
//
// WHY OPENING AND NOT A 3x3 MAJORITY
//   A majority-of-nine costs one stage instead of two and removes 1px and 2px
//   speckle just as well.  It also FILLS 1px holes, which sounds like a bonus
//   and is not: the vignette band and the shadow gradients in the 09-07 photos
//   are broad, low-contrast regions whose mask is a lace of holes, and filling
//   them consolidates that lace into exactly the large connected component this
//   change is trying to get rid of.  An opening only ever removes foreground,
//   so it cannot manufacture a blob that was not already there.
//
// COST  Two det_bin3x3 stages: six 1920x1 row buffers, ~200 LUT of window
//       logic, 6 clocks.  The row buffers land in either 6 ERAM or ~200-400
//       dram LUT depending on what TD decides -- see WHERE THESE SIX ARRAYS
//       ACTUALLY LAND in det_bin3x3's header before quoting a number from
//       here.  The mask is shifted (+2,+2); same header, GEOMETRY note, for
//       why that is left uncompensated.
//
// The residual it does NOT fix, on purpose: a broad connected background region
// survives an opening because it is not thin.  That one is ccl_blob's problem
// and is handled there by the bounding-box and fill-ratio rejects.
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module det_morph_open #(
parameter integer IMG_HDISP = 1920,
parameter integer IMG_VDISP = 1080
)(
input  wire        clk,
input  wire        rst_n,

input  wire        in_vs,          // HIGH across the visible frame
input  wire        in_de,
input  wire        in_bin,

output wire        out_vs,
output wire        out_de,
output wire        out_bin,
output wire [11:0] out_px,
output wire [11:0] out_py
);

//------------------------------------------------------------------------
// Stage 1 -- erode.  Its px/py are left open: only the last stage's
// coordinates reach ccl_blob, and the intermediate pair would be a second set
// of counters to keep in step for no reader.
//------------------------------------------------------------------------
wire e_vs, e_de, e_bin;

det_bin3x3 #(
.IMG_HDISP ( IMG_HDISP ),
.IMG_VDISP ( IMG_VDISP ),
.MODE      ( 0         )          // AND of nine
)u_erode(
.clk     ( clk    ),
.rst_n   ( rst_n  ),
.in_vs   ( in_vs  ),
.in_de   ( in_de  ),
.in_bin  ( in_bin ),
.out_vs  ( e_vs   ),
.out_de  ( e_de   ),
.out_bin ( e_bin  ),
.out_px  (        ),
.out_py  (        )
);

//------------------------------------------------------------------------
// Stage 2 -- dilate, fed the eroded mask and the eroded sync.  Feeding it the
// ORIGINAL sync instead would put the two stages a row out of step, and the
// result of that is not a broken picture but a mask that looks plausible and
// is wrong -- worth naming, because both syncs are in scope right here.
//------------------------------------------------------------------------
det_bin3x3 #(
.IMG_HDISP ( IMG_HDISP ),
.IMG_VDISP ( IMG_VDISP ),
.MODE      ( 1         )          // OR of nine
)u_dilate(
.clk     ( clk     ),
.rst_n   ( rst_n   ),
.in_vs   ( e_vs    ),
.in_de   ( e_de    ),
.in_bin  ( e_bin   ),
.out_vs  ( out_vs  ),
.out_de  ( out_de  ),
.out_bin ( out_bin ),
.out_px  ( out_px  ),
.out_py  ( out_py  )
);

endmodule
