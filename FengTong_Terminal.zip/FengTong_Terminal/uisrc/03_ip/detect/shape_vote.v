//---------------------------------------------------------------------------
// shape_vote -- a stable shape label out of shape_cnn's one-per-frame guess
// (2026-10-09).
//
// WHY  shape_cnn classifies slot 0's box once a frame.  A single frame can be
//   wrong (the box catches a hand, the mask loses a corner, the box is one
//   frame late against the mask), and both readers -- the OSD 识别 row and
//   the workpiece record latched on qc_trig -- need the class of the part,
//   not of whichever frame happened to be last.
//
// HOW  One saturating counter per class.  Each `done` with class_valid adds
//   one to the class it names (up to CMAX) and takes one from every other;
//   a `done` without a box takes one from all of them.  The output is the
//   largest counter (ties to the lower class number, like shape_cnn's own
//   argmax), and it is valid while that counter is >= ON_N.  So a part needs
//   ON_N agreeing frames to be named, a stray frame costs the leader only one
//   step, and an empty table forgets the part within CMAX frames.
//   en = 0 (not in BOX mode) clears everything.
//
// TIMING  Updates one clock after `done` (shape_cnn's, ~1.8 ms into the
//   vertical blanking).  vcls / vvalid / vconf change together.
//---------------------------------------------------------------------------
`timescale 1ns/1ns

module shape_vote #(
parameter integer NCLS = 4,       // classes 0..NCLS-1 (shape_class is 2 bit)
parameter integer CMAX = 15,
parameter integer ON_N = 4
)(
input  wire       clk,
input  wire       rst_n,
input  wire       en,
input  wire       done,
input  wire [1:0] cls,
input  wire       cls_valid,

output reg  [1:0] vcls,
output reg        vvalid,
output reg  [3:0] vconf          // the leading counter
);

reg [3:0] c [0:NCLS-1];
integer k;

// argmax over the counters as they are now (combinational, 4 x 4 bit)
reg [1:0] am;
reg [3:0] amv;
always @(*) begin
    am  = 2'd0;
    amv = c[0];
    for (k = 1; k < NCLS; k = k + 1)
        if (c[k] > amv) begin am = k[1:0]; amv = c[k]; end
end

reg upd;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        for (k = 0; k < NCLS; k = k + 1) c[k] <= 4'd0;
        upd <= 1'b0;
        vcls <= 2'd0; vvalid <= 1'b0; vconf <= 4'd0;
    end else if (!en) begin
        for (k = 0; k < NCLS; k = k + 1) c[k] <= 4'd0;
        upd <= 1'b0;
        vcls <= 2'd0; vvalid <= 1'b0; vconf <= 4'd0;
    end else begin
        upd <= done;
        if (done) begin
            for (k = 0; k < NCLS; k = k + 1) begin
                if (cls_valid && cls == k[1:0])
                    c[k] <= (c[k] >= CMAX) ? CMAX[3:0] : c[k] + 4'd1;
                else
                    c[k] <= (c[k] == 4'd0) ? 4'd0 : c[k] - 4'd1;
            end
        end
        if (upd) begin
            vcls   <= am;
            vconf  <= amv;
            vvalid <= (amv >= ON_N);
        end
    end
end

endmodule
