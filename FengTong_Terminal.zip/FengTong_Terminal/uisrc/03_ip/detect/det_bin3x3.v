//---------------------------------------------------------------------------
// det_bin3x3 -- 3x3 binary rank filter on the detection mask.  One bit in, one
// bit out; MODE picks erosion (AND of nine) or dilation (OR of nine).  Two of
// these back to back make the opening in det_morph_open.
//
// WHY THIS EXISTS AT ALL
//   det_binarize's threshold is global, and on any real bench surface the
//   residual illumination gradient and the sensor noise at isp_auto_level's
//   digital gain put a scatter of single pixels over the line.  Those cost
//   nothing on the picture path but they are ruinous here: every isolated
//   speck is a provisional label, every diagonal touch is a merge-list entry,
//   and ccl_blob's budget is 2047 labels and 1024 merges.  The board showed
//   ovf_label/ovf_merge set on EVERY frame of the 2026-09-07 bench run -- the
//   '*' on the OSD -- which means the published boxes were assembled from a
//   label space that had already run out and a merge list that had already
//   dropped edges.
//
//   An opening removes exactly the structure that is expensive and keeps
//   exactly the structure that is a target: a 1px speck and a 1px-wide line
//   both vanish, a 40x40 part loses its four corner pixels.  The label count
//   collapses by one to two orders of magnitude, which is what actually clears
//   the overflow rather than papering over it.
//
// WHY THREE ROW BUFFERS AND NOT TWO
//   The textbook 3x3 line-buffer uses two buffers and relies on READ-BEFORE-
//   WRITE at one address: row y overwrites the buffer that still holds row y-2,
//   and the read has to see the old value.  That is a property of the RAM's
//   collision mode, not of the RTL, and TD's ERAM does not document it as
//   read-first.  Getting it wrong does not fail loudly -- the top row of the
//   window silently becomes the current row, erosion turns into a horizontal
//   AND, and the mask merely looks "a bit thin".
//
//   Three buffers on a mod-3 row rotation means the buffer being written is
//   never one of the two being read, at any address, in any cycle.  It costs
//   one extra 1920x1 buffer per stage -- 1920 bits, against 355 free ERAM on
//   this part -- and removes the assumption entirely.
//
// WHERE THESE SIX ARRAYS ACTUALLY LAND, AND WHY IT DOES NOT MATTER MUCH
//   A 1-bit-wide 1920-deep array is the shape a synthesiser is least likely to
//   put in block RAM, and every other deep array in this project is 8 bits or
//   wider.  The 09-07 area report settles what TD does with the awkward cases,
//   so this does not have to be guessed at:
//
//     u_logo    (anlogic_logo_rom, 2 bits x 2048)   -> 1 eram, 0 dram lut
//     u_ccl_blob                                    -> 11 eram + 1024 dram lut
//
//   ccl_blob asked for 15 ERAM by its own accounting and got 11; its 1024x22
//   merge list went to distributed RAM instead.  So TD will decline ERAM for a
//   deep array -- but its fallback is LUT RAM, NOT registers.  Either outcome
//   is fine here: 6 x 1920 bits is 6 ERAM out of 355 free, or roughly 200-400
//   dram LUT with a two-level output mux.  What would NOT have been fine is a
//   register fallback, because a 1920:1 mux over flip-flops is ~11 levels of
//   LUT6 and this clock group has 6.7ns to play with; the ccl_blob numbers say
//   that is not the failure mode to plan for.
//
//   Worth a glance at the report anyway.  If ERAM is wanted specifically, the
//   lever is a TD ram-style attribute on the three arrays -- the project has no
//   such attribute anywhere today, which is why none is written here.
//
// WHY THE ADDRESS IS THE SAME FOR READ AND WRITE
//   ccl_blob's row buffers read at in_px and write at px_d4, and its header has
//   to argue that the row-boundary overlap (writing 1917+ of row y-1 while
//   reading 0..3 of row y) is safe on a 1W1R block RAM.  Here the write data is
//   the input bit itself, with no pipeline in front of it, so read and write
//   can share one address and that argument is not needed: at column 0 of row y
//   the previous row's last write already landed, into a different buffer.
//
// GEOMETRY -- THE OUTPUT IS ONE PIXEL DOWN AND ONE RIGHT
//   The window centre is one row and one column behind the newest pixel, and
//   out_de is a fixed 3-clock delay of in_de (the house pattern -- see
//   morphology_3x3's LATENCY note, which inherits the same one-line shift on
//   the picture path).  So the answer for source pixel (x,y) is emitted with
//   the coordinates (x+1, y+1).
//
//   Two of these in series therefore shift the mask by (+2,+2).  On a 1920x1080
//   frame with BOX_THICK = 3 that is a quarter of the box line width and well
//   under the blur of the lens at any working distance -- not worth the
//   subtract-and-clamp it would take to undo.  If it ever does matter, the
//   place to undo it is det_overlay's per-frame box latch, which is already
//   doing adds there and runs once a frame rather than once a pixel.
//
//   Consequences, all deliberate:
//     * output row 0 and output column 0 have their window centre off-frame.
//       For MODE 0 that means they are always background, because the AND
//       includes the zeros the guards feed in.  For MODE 1 they are not: the OR
//       still sees the real column 0 / row 0 data one tap over, which is
//       correct dilation and is what puts an opened object back at its original
//       size when it started against the frame edge.
//     * source row IMG_VDISP-1 is never a window centre, so the bottom row is
//       lost.  A target on the last scan line is already half out of frame.
//
// WHY THE py GUARDS ARE NOT OPTIONAL
//   The row buffers are never cleared -- block RAM, same as every other line
//   buffer here.  Rows 0 and 1 would otherwise read whatever the PREVIOUS
//   frame left at those addresses, and for a dilation that is a band of stale
//   foreground across the top of the frame that ccl_blob reads as a real,
//   frame-wide target.  row_ok1/row_ok2 below are the same guard ccl_blob's
//   section [4] applies with `row_ok`, for the same reason.
//
// LATENCY 3 clocks on data, de and vs alike.  px/py are rebuilt from the
// delayed sync rather than delayed alongside the data, so a coordinate cannot
// drift out of step with the bit it labels -- det_binarize's section [7] notes
// what that failure looked like the one time it happened.
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module det_bin3x3 #(
parameter integer IMG_HDISP = 1920,
parameter integer IMG_VDISP = 1080,

// 0 = erosion, the AND of the nine.  A pixel survives only with all eight
//     neighbours set, so anything thinner than 3px disappears.
// 1 = dilation, the OR of the nine.  Grows what is left back to its original
//     size, which is what makes the pair an opening rather than just an erode.
parameter integer MODE = 0
)(
input  wire        clk,
input  wire        rst_n,

input  wire        in_vs,          // HIGH across the visible frame
input  wire        in_de,
input  wire        in_bin,         // 1 = foreground

output reg         out_vs,
output reg         out_de,
output reg         out_bin,
output reg  [11:0] out_px,
output reg  [11:0] out_py
);

//------------------------------------------------------------------------
// [1] Input-side coordinates and the mod-3 row phase.
//
// ipx is the buffer address for the bit currently on in_bin: at the first
// active clock of a row the counter still reads 0 and increments for the next,
// which is the same relationship det_binarize's generator has with out_bin.
//------------------------------------------------------------------------
reg [11:0] ipx, ipy;
reg [1:0]  rphase;                 // ipy mod 3
reg        ide_prev;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        ipx <= 12'd0; ipy <= 12'd0; rphase <= 2'd0; ide_prev <= 1'b0;
    end else begin
        ide_prev <= in_de;
        if (!in_vs) begin
            ipx    <= 12'd0;
            ipy    <= 12'd0;
            rphase <= 2'd0;
        end
        else if (in_de) begin
            ipx <= ipx + 12'd1;
        end
        else begin
            ipx <= 12'd0;
            if (ide_prev) begin
                ipy    <= ipy + 12'd1;
                rphase <= (rphase == 2'd2) ? 2'd0 : (rphase + 2'd1);
            end
        end
    end
end

//------------------------------------------------------------------------
// [2] Three 1-bit row buffers on a mod-3 rotation.  No reset on the arrays or
// their output registers -- block RAM, same as ccl_blob's lbuf0/lbuf1.
//
// Row y writes buffer (y mod 3).  Row y-1 is then in ((y mod 3) + 2) mod 3 and
// row y-2 in ((y mod 3) + 1) mod 3, so neither read ever names the buffer this
// row is writing.
//------------------------------------------------------------------------
reg lb0 [0:IMG_HDISP-1];
reg lb1 [0:IMG_HDISP-1];
reg lb2 [0:IMG_HDISP-1];

reg q0, q1, q2;

always @(posedge clk) begin
    if (in_de && (rphase == 2'd0)) lb0[ipx] <= in_bin;
    q0 <= lb0[ipx];
end

always @(posedge clk) begin
    if (in_de && (rphase == 2'd1)) lb1[ipx] <= in_bin;
    q1 <= lb1[ipx];
end

always @(posedge clk) begin
    if (in_de && (rphase == 2'd2)) lb2[ipx] <= in_bin;
    q2 <= lb2[ipx];
end

//------------------------------------------------------------------------
// [3] Pick the two previous rows out of the rotation, and gate the three
// window rows.
//
// rphase_d/ipy_d1/de_d1 are the one-clock-delayed copies that line up with the
// registered RAM outputs -- reading the rotation with the live rphase would
// select the NEXT row's assignment for the last read of every row.
//------------------------------------------------------------------------
reg [1:0]  rphase_d;
reg [11:0] ipy_d1;
reg        de_d1;
reg        b_q;                    // the live row, registered to match q0..q2

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        rphase_d <= 2'd0; ipy_d1 <= 12'd0; de_d1 <= 1'b0; b_q <= 1'b0;
    end else begin
        rphase_d <= rphase;
        ipy_d1   <= ipy;
        de_d1    <= in_de;
        b_q      <= in_bin;
    end
end

wire prev1 = (rphase_d == 2'd0) ? q2 : (rphase_d == 2'd1) ? q0 : q1;
wire prev2 = (rphase_d == 2'd0) ? q1 : (rphase_d == 2'd1) ? q2 : q0;

// See WHY THE py GUARDS ARE NOT OPTIONAL.  ipy_d1 is the row the buffers were
// just read for, so row y-1 exists from ipy_d1 >= 1 and row y-2 from >= 2.
wire row_ok1 = (ipy_d1 >= 12'd1);
wire row_ok2 = (ipy_d1 >= 12'd2);

wire cur_v = de_d1              ? b_q   : 1'b0;
wire p1_v  = (de_d1 & row_ok1)  ? prev1 : 1'b0;
wire p2_v  = (de_d1 & row_ok2)  ? prev2 : 1'b0;

//------------------------------------------------------------------------
// [4] Horizontal window.  Three taps per row; [1] is the centre column.
//------------------------------------------------------------------------
reg [2:0] s_cur, s_p1, s_p2;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        s_cur <= 3'b0; s_p1 <= 3'b0; s_p2 <= 3'b0;
    end else begin
        s_cur <= {s_cur[1:0], cur_v};
        s_p1  <= {s_p1[1:0],  p1_v };
        s_p2  <= {s_p2[1:0],  p2_v };
    end
end

wire and9 = &{s_p2, s_p1, s_cur};
wire or9  = |{s_p2, s_p1, s_cur};
wire res  = (MODE == 0) ? and9 : or9;

//------------------------------------------------------------------------
// [5] Output.  de/vs come from index [1] and the coordinate generator below
// from index [2] -- the two are the same value one clock apart, which is what
// makes px read 0 on the first active clock.  det_binarize's section [6] has
// the full argument; getting it backwards there dropped column 0 of every row.
//------------------------------------------------------------------------
reg [2:0] de_dly, vs_dly;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        de_dly <= 3'b0; vs_dly <= 3'b0;
    end else begin
        de_dly <= {de_dly[1:0], in_de};
        vs_dly <= {vs_dly[1:0], in_vs};
    end
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        out_bin <= 1'b0; out_de <= 1'b0; out_vs <= 1'b0;
    end else begin
        out_bin <= res;
        out_de  <= de_dly[1];
        out_vs  <= vs_dly[1];
    end
end

//------------------------------------------------------------------------
// [6] Output coordinates, rebuilt from the delayed sync.
//------------------------------------------------------------------------
reg ode_prev;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        out_px <= 12'd0; out_py <= 12'd0; ode_prev <= 1'b0;
    end else begin
        ode_prev <= de_dly[2];
        if (!vs_dly[2]) begin
            out_px <= 12'd0;
            out_py <= 12'd0;
        end
        else if (de_dly[2]) begin
            out_px <= out_px + 12'd1;
        end
        else begin
            out_px <= 12'd0;
            if (ode_prev) out_py <= out_py + 12'd1;
        end
    end
end

endmodule
