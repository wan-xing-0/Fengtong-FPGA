//---------------------------------------------------------------------------
// black_color_detect_cnn -- per-pixel "is this the black backdrop" with a tiny
// integer CNN.  The teammate's module (Anlogic7, kept as
// black_color_detect_cnn.v.a7), RE-PIPELINED for this design's pixel clock.
//
//   L1  1x1 conv  3 -> 8, ReLU    per-pixel colour features
//   L2  1x1 conv  8 -> 2, ReLU
//   L3  3x3 conv  2 -> 1          spatial context, 2 line buffers x 16 bit
//   out logit > TH3               1 = backdrop ("black")
//
// Weights: cnn_weights.vh (`include, resolved next to this file).  uint8
// activations x int8 weights, int24 accumulators.
//
// ⭐ 10-04: WHAT CHANGED FROM .a7, AND WHAT DID NOT
//   * Every adder tree is split so no clock carries more than ONE two-input
//     add (L1 3+1 operands, L2 8+1, L3 18+1, then the TH3 compare on its own
//     clock).  .a7 summed six 17-bit products in one clock (s3) and four plus a
//     bias in the next; pclkx1 runs this design with ~0 ns to spare (19:57
//     build: -0.033 ns intra-clock, a 92 %-routing fifowait path), so a
//     three-level carry chain here is a new worst path waiting to be placed.
//     The products stay one clock each -- TD maps constant multiplies to DSP
//     (face_skin's did, HANDOFF §-3.-11-D).
//   * The sums are the same integers re-associated, in widths that cannot
//     overflow, so out_mask / out_rgb are BIT-EXACT with .a7 -- seven clocks
//     later (LATENCY 14 -> 21).  cnntb_eq checks that clock by clock against
//     .a7 itself, on a real board frame and on random frames.
//   * Nothing else: same ports, same post filter, same view_mode encoding.
//
// ⚠ IT IS A FIXED COLOUR CLASSIFIER.  No reference, no adaptation: the same
// RGB always gets the same answer.  isp_auto_level is OFF since 10-04 and the
// sensor's AE still moves the exposure, so a white workpiece in a dark scene
// and a lit green wall in a bright one can be the SAME colour (board shots
// 16:54 / 12:10: (56,104,69) vs (46,90,69)).  Train for the scene it will see
// -- cnn_weights.vh's header says which one.  det_binarize (block-mean
// reference) does not have this limit; DET_CNN in system_top picks.
//
// KNOWN (as .a7): L3 is causal -- window rows py-2..py, cols px-2..px, so the
// mask sits one pixel down and right of a centre-aligned conv.
//
// Post filter (POST_FILTER=1): horizontal hysteresis + previous row's hit
// count, as .a7.  With target = backdrop the object's left edge comes in
// HYST_END-1 px late and its right edge HYST_START-1 px late: width -2 px,
// shifted right ~6 px.  The size calibration (key2 held) absorbs it.
//
// view_mode: 00 pass-through, 01 darken detected pixels, 1x binary mask.
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module black_color_detect_cnn #(
parameter integer IMG_HDISP        = 1920,
parameter integer IMG_VDISP        = 1080,
parameter integer POST_FILTER      = 1,
parameter [5:0]   HYST_START       = 6'd6,
parameter [5:0]   HYST_END         = 6'd8,
parameter [11:0]  MIN_HITS_PER_ROW = 12'd24,
parameter integer DARK_SHIFT       = 2      // view_mode 01: >> per channel
)(
input  wire        clk,
input  wire        rst_n,

input  wire        in_vs,          // HIGH across the visible frame (af_out_vs is)
input  wire        in_de,
input  wire [23:0] in_rgb,         // {R,G,B}

input  wire [1:0]  view_mode,

output wire        out_vs,
output wire        out_de,
output wire [23:0] out_rgb,
output wire        out_mask
);

// W1 B1 W2 B2 W3 B3 TH3 SH1 SH2 -- generated, do not hand-edit
`include "cnn_weights.vh"

// Stage map.  Index k of the side band = the pixel whose data sits in the
// stage-k registers.  (.a7's numbers in brackets.)
localparam integer S_H   = 4;      // h, L1 output          [3]
localparam integer S_E   = 10;     // e, L2 output          [7]
localparam integer S_WIN = 12;     // 3x3 window valid      [9]
localparam integer S_BIT = 19;     // cnn_bit registered    [12, combinational]
localparam integer PD    = 20;     // mask, the post filter's output [13]

//------------------------------------------------------------------------
// [1] Screen coordinates, rebuilt from de/vs
//------------------------------------------------------------------------
reg [11:0] px, py;
reg        de_prev;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        px <= 12'd0; py <= 12'd0; de_prev <= 1'b0;
    end else begin
        de_prev <= in_de;
        if (!in_vs) begin
            px <= 12'd0;
            py <= 12'd0;
        end else if (in_de) begin
            px <= px + 1'b1;
        end else begin
            px <= 12'd0;
            if (de_prev) py <= py + 1'b1;
        end
    end
end

//------------------------------------------------------------------------
// [2] Side-band delay line
//------------------------------------------------------------------------
reg [PD:1] vs_p, de_p;
reg [23:0] rgb_p [1:PD];
reg [11:0] px_p  [1:PD];
reg [11:0] py_p  [1:PD];
integer k;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        vs_p <= {PD{1'b0}};
        de_p <= {PD{1'b0}};
    end else begin
        vs_p <= {vs_p[PD-1:1], in_vs};
        de_p <= {de_p[PD-1:1], in_de};
    end
end

always @(posedge clk) begin
    rgb_p[1] <= in_rgb;
    px_p[1]  <= px;
    py_p[1]  <= py;
    for (k = 2; k <= PD; k = k + 1) begin
        rgb_p[k] <= rgb_p[k-1];
        px_p[k]  <= px_p[k-1];
        py_p[k]  <= py_p[k-1];
    end
end

// ReLU, arithmetic shift, clamp to uint8 (no carry chain: a sign test and
// an OR of the bits above the field)
function [7:0] relu_q8;
    input signed [23:0] a;
    input integer       sh;
    reg   signed [23:0] s;
    begin
        if (a[23]) relu_q8 = 8'd0;
        else begin
            s = a >>> sh;
            relu_q8 = (s > 24'sd255) ? 8'd255 : s[7:0];
        end
    end
endfunction

//------------------------------------------------------------------------
// [3] L1: 1x1 conv 3 -> 8.  products @1, pairs @2, acc @3, h @4
//------------------------------------------------------------------------
wire [8*8-1:0] h_vec;
genvar gc;

generate
for (gc = 0; gc < 8; gc = gc + 1) begin : L1
    wire signed [7:0]  wr   = W1[(gc*3+0)*8 +: 8];
    wire signed [7:0]  wg   = W1[(gc*3+1)*8 +: 8];
    wire signed [7:0]  wb   = W1[(gc*3+2)*8 +: 8];
    wire signed [23:0] bias = B1[gc*24 +: 24];
    reg  signed [16:0] pr, pg, pb;
    reg  signed [23:0] sa, sb, acc;
    reg         [7:0]  h;
    always @(posedge clk) begin
        pr  <= wr * $signed({1'b0, in_rgb[23:16]});
        pg  <= wg * $signed({1'b0, in_rgb[15:8]});
        pb  <= wb * $signed({1'b0, in_rgb[7:0]});
        sa  <= pr + pg;
        sb  <= pb + bias;
        acc <= sa + sb;
        h   <= relu_q8(acc, SH1);
    end
    assign h_vec[gc*8 +: 8] = h;
end
endgenerate

//------------------------------------------------------------------------
// [4] L2: 1x1 conv 8 -> 2.  products @5, pairs @6, quads @7, octet @8,
//     +bias @9, e @10
//------------------------------------------------------------------------
wire [2*8-1:0] e_vec;              // {ch1, ch0}, aligned with *_p[S_E]

generate
for (gc = 0; gc < 2; gc = gc + 1) begin : L2
    wire signed [23:0] bias = B2[gc*24 +: 24];
    wire signed [7:0]  w [0:7];
    reg  signed [16:0] p [0:7];
    reg  signed [17:0] q [0:3];
    reg  signed [18:0] r0, r1;
    reg  signed [19:0] t;
    reg  signed [23:0] acc;
    reg         [7:0]  e;
    genvar gj;
    for (gj = 0; gj < 8; gj = gj + 1) begin : WJ
        assign w[gj] = W2[(gc*8+gj)*8 +: 8];
        always @(posedge clk)
            p[gj] <= w[gj] * $signed({1'b0, h_vec[gj*8 +: 8]});
    end
    for (gj = 0; gj < 4; gj = gj + 1) begin : QJ
        always @(posedge clk)
            q[gj] <= p[2*gj] + p[2*gj+1];
    end
    always @(posedge clk) begin
        r0  <= q[0] + q[1];
        r1  <= q[2] + q[3];
        t   <= r0 + r1;
        acc <= t + bias;
        e   <= relu_q8(acc, SH2);
    end
    assign e_vec[gc*8 +: 8] = e;
end
endgenerate

//------------------------------------------------------------------------
// [5] Line buffers + 3x3 window (as .a7, at S_E instead of 7).
//     @S_E   : e for (py, px) arrives.  lb0 holds row y-1, lb1 row y-2.
//     @S_E+1 : column {top, mid, cur} registered; mid is written into lb1.
//     @S_WIN : window, kx=2 is the newest column, ky=2 the current row.
//------------------------------------------------------------------------
reg [15:0] lb0 [0:IMG_HDISP-1];
reg [15:0] lb1 [0:IMG_HDISP-1];
reg [15:0] col_top, col_mid, col_cur;

always @(posedge clk) begin
    if (de_p[S_E]) begin
        col_mid          <= lb0[px_p[S_E]];   // read-first
        lb0[px_p[S_E]]   <= e_vec;
        col_top          <= lb1[px_p[S_E]];
        col_cur          <= e_vec;
    end
    if (de_p[S_E+1])
        lb1[px_p[S_E+1]] <= col_mid;          // one column behind the lb1 read
end

reg [15:0] win [0:8];                         // index ky*3 + kx
always @(posedge clk) begin
    if (de_p[S_E+1]) begin
        win[0] <= win[1]; win[1] <= win[2]; win[2] <= col_top;
        win[3] <= win[4]; win[4] <= win[5]; win[5] <= col_mid;
        win[6] <= win[7]; win[7] <= win[8]; win[8] <= col_cur;
    end
end

// zero padding: columns left of x=0 are the previous line, rows above y=0
// the previous frame
wire [2:0] col_ok = { 1'b1, (px_p[S_WIN] >= 12'd1), (px_p[S_WIN] >= 12'd2) };
wire [2:0] row_ok = { 1'b1, (py_p[S_WIN] >= 12'd1), (py_p[S_WIN] >= 12'd2) };

//------------------------------------------------------------------------
// [6] L3: 3x3 conv 2 -> 1.  products @13, 9 pairs @14, 5 @15 (bias joins
//     here), 3 @16, 2 @17, acc @18, > TH3 @19
//------------------------------------------------------------------------
reg  signed [16:0] p3 [0:17];
reg  signed [17:0] u3 [0:8];
reg  signed [23:0] v3 [0:4];
reg  signed [23:0] w30, w31, w32, x30, x31, acc3;
reg                cnn_bit;
wire signed [23:0] bias3 = B3;
wire signed [23:0] th3   = TH3;

genvar gch, gky, gkx;
generate
for (gch = 0; gch < 2; gch = gch + 1) begin : L3C
    for (gky = 0; gky < 3; gky = gky + 1) begin : L3Y
        for (gkx = 0; gkx < 3; gkx = gkx + 1) begin : L3X
            localparam integer IDX = (gch*3 + gky)*3 + gkx;
            wire signed [7:0] w = W3[IDX*8 +: 8];
            wire        [7:0] a = win[gky*3 + gkx][gch*8 +: 8];
            always @(posedge clk)
                p3[IDX] <= (col_ok[gkx] && row_ok[gky])
                         ? (w * $signed({1'b0, a})) : 17'sd0;
        end
    end
end
for (gc = 0; gc < 9; gc = gc + 1) begin : L3U
    always @(posedge clk)
        u3[gc] <= p3[2*gc] + p3[2*gc+1];
end
endgenerate

always @(posedge clk) begin
    v3[0]   <= u3[0] + u3[1];
    v3[1]   <= u3[2] + u3[3];
    v3[2]   <= u3[4] + u3[5];
    v3[3]   <= u3[6] + u3[7];
    v3[4]   <= u3[8] + bias3;
    w30     <= v3[0] + v3[1];
    w31     <= v3[2] + v3[3];
    w32     <= v3[4];
    x30     <= w30 + w31;
    x31     <= w32;
    acc3    <= x30 + x31;
    cnn_bit <= (acc3 > th3);       // aligned with *_p[S_BIT]
end

//------------------------------------------------------------------------
// [7] Post filter: hysteresis + per-row hit count, as .a7, in the @S_BIT
//     domain (cnn_bit is a register here, .a7's was the compare itself)
//------------------------------------------------------------------------
wire de_b       = de_p[S_BIT];
wire frame_tick = vs_p[S_BIT+1] & ~vs_p[S_BIT];
wire row_wrap   = de_b & (px_p[S_BIT] == (IMG_HDISP - 1));

reg [5:0]  consec_red, consec_nored;
reg        hori_active;
reg [11:0] line_hits, prev_line_hits;
reg        cnn_bit_d;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        consec_red   <= 6'd0;
        consec_nored <= 6'd0;
        hori_active  <= 1'b0;
    end else if (frame_tick || row_wrap) begin
        consec_red   <= 6'd0;
        consec_nored <= 6'd0;
        hori_active  <= 1'b0;
    end else if (de_b) begin
        if (cnn_bit) begin
            consec_nored <= 6'd0;
            if (consec_red < 6'd63) consec_red <= consec_red + 6'd1;
            if (consec_red >= (HYST_START - 6'd1)) hori_active <= 1'b1;
        end else begin
            consec_red <= 6'd0;
            if (consec_nored < 6'd63) consec_nored <= consec_nored + 6'd1;
            if (consec_nored >= (HYST_END - 6'd1)) hori_active <= 1'b0;
        end
    end
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        line_hits      <= 12'd0;
        prev_line_hits <= 12'd0;
    end else if (frame_tick) begin
        line_hits      <= 12'd0;
        prev_line_hits <= 12'd0;
    end else if (row_wrap) begin
        prev_line_hits <= line_hits + (hori_active ? 12'd1 : 12'd0);
        line_hits      <= 12'd0;
    end else if (de_b && hori_active && (line_hits != 12'hFFF)) begin
        line_hits <= line_hits + 12'd1;
    end
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) cnn_bit_d <= 1'b0;
    else        cnn_bit_d <= cnn_bit;
end

// @PD: mask for the pixel in rgb_p[PD]
wire mask_pd = (POST_FILTER != 0)
             ? (hori_active && (prev_line_hits >= MIN_HITS_PER_ROW))
             : cnn_bit_d;

//------------------------------------------------------------------------
// [8] Output register
//------------------------------------------------------------------------
wire [23:0] rgb_pd = rgb_p[PD];

reg        out_vs_r, out_de_r, out_mask_r;
reg [23:0] out_rgb_r;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        out_vs_r   <= 1'b0;
        out_de_r   <= 1'b0;
        out_mask_r <= 1'b0;
        out_rgb_r  <= 24'd0;
    end else begin
        out_vs_r   <= vs_p[PD];
        out_de_r   <= de_p[PD];
        out_mask_r <= mask_pd & de_p[PD];
        case (view_mode)
        2'b00:   out_rgb_r <= rgb_pd;
        2'b01:   out_rgb_r <= mask_pd
                    ? { rgb_pd[23:16] >> DARK_SHIFT,
                        rgb_pd[15:8]  >> DARK_SHIFT,
                        rgb_pd[7:0]   >> DARK_SHIFT }
                    : rgb_pd;
        default: out_rgb_r <= mask_pd ? 24'hFFFFFF : 24'h000000;
        endcase
    end
end

assign out_vs   = out_vs_r;
assign out_de   = out_de_r;
assign out_rgb  = out_rgb_r;
assign out_mask = out_mask_r;

endmodule
