//---------------------------------------------------------------------------
// ccl_blob -- single-pass connected-component labelling with 8-connectivity,
// per-label feature accumulation, and a top-N target list published once a
// frame.  This is the L5 analysis layer proper; it closes the brief's
// "target detection and identification" extension item and is what the
// tracking, classification and measurement rounds build on.
//
// It has no video path.  It consumes one bit per pixel from det_binarize and
// produces NBLOB bounding boxes for det_overlay to draw a frame later.
//
//===========================================================================
// HOW THE LABELS ARE ASSIGNED
//===========================================================================
// Raster scan, 8-connectivity, so a foreground pixel looks at four already
// labelled neighbours: NW, N, NE from the previous row and W from this one.
// It takes the smallest non-zero one, and if two of them differ it appends the
// pair to a merge list for the frame-end passes to reconcile.  Label 0 means
// background, so "is this neighbour foreground" and "what is its label" are
// the same read -- no separate validity bit anywhere.
//
// WHY MIN AND MAX OF THE FOUR IS ENOUGH.  This is not obvious, and it is what
// makes ONE merge per pixel sufficient:
//
//   NW, N and NE are horizontally adjacent in the previous row.  When that row
//   was scanned each of them saw its own left neighbour, so any two adjacent
//   foreground pixels there either came out with the same label or already had
//   their pair written to the merge list.  W is vertically adjacent to NW, and
//   the same argument applied when W was labelled.
//
//   So the four neighbours form at most TWO groups not already known to be
//   connected -- {NW, W} and {NE} -- and they can only be separate when N is
//   background, which is an 8-connected diagonal bridge that THIS pixel is
//   creating.  min and max therefore span every equivalence this pixel
//   introduces, and anything they skip over is already on the list from an
//   earlier row.
//
//   Consequence: one merge-list write per pixel worst case, so the list needs
//   a single write port and no arbitration.
//
//===========================================================================
// WHY THE UNION-FIND RUNS AT FRAME END AND NOT DURING THE SCAN
//===========================================================================
// The tempting version keeps parent[] live during the scan: on a merge, read
// parent[b] and write min(parent[b], a).  That LOSES EDGES.  If parent[b] was
// already 5 and now a = 3, writing 3 discards the fact that 5 and 3 are the
// same component, and the two arms of a U-shaped object come out as separate
// targets.  Fixing it needs the displaced edge pushed back somewhere, which is
// the same work again plus a read-modify-write hazard in the pixel path.
//
// So the scan only appends pairs and the whole reconciliation happens in
// vertical blanking, where there are 45 lines x 2200 = 99,000 clocks and
// nothing else to do with them.
//
// ⚠ AND GETTING THOSE 99,000 CLOCKS TOOK UNTIL 2026-09-18.  Until then the
// passes were gated on in_vs's low period, which is the five-line sync pulse
// -- 11,000 clocks.  See [1]; it is the single highest-value thing to
// understand about this module.
//
//   PASS A  For each recorded pair (a,b): ra = parent[a], rb = parent[b],
//           m = min(ra,rb), then write m to parent[a], parent[b], parent[ra]
//           and parent[rb].  The first two are the hook that merges the trees;
//           the last two are the shortcut that makes it CONVERGE -- without
//           them a chain a -> ra -> m survives and pass A keeps rediscovering
//           the same edge every round.  Repeat while any round found ra != rb,
//           capped at MAX_ROUNDS.  Real blobs converge in two.
//
//           Fixed point: parent[a] == parent[b] for every recorded pair, which
//           is exactly the condition that the parent forest partitions the
//           labels correctly.
//
//           ⚠ 2026-10-05: the shortcut writes are NOT monotone.  parent[ra] can
//           already be below m (ra's own parent), and writing m RAISES it;
//           with the right pairs that undoes another pair's hook every round
//           and the relaxation cycles.  It converged on the board only
//           because the list was full of duplicates (more re-hooks per round).
//           On the deduplicated list of the 10-05 frame 2691 it was still
//           changing after 60 rounds, so at MAX_ROUNDS the top of a face came
//           out as its own blob.  PA_HOOK = 1 drops the two shortcut writes:
//           every write is then a min, nothing ever rises, and it converges:
//           3-8 rounds on 120 recorded face frames (mostly 4-5), and on all
//           120 the boxes at the MAX_ROUNDS 5 cap equal the converged ones.
//           7 clocks a pair instead of 9.
//
//   PASS B  Pointer-jump every label once, in INCREASING order.  parent[i] <= i
//           is an invariant here -- it holds at init and every write in pass A
//           stores a min of two values already <= their own index -- so
//           parent[parent[i]] has already been flattened this pass and a single
//           increasing sweep resolves the whole forest.  Runs ONCE, after
//           pass A has converged, not inside the loop: passes C and D need a
//           flat table, nothing before them does.
//
//   PASS C  Fold each non-root's feature record into its root's.  Increasing
//           order, and a root is never a source, so no record is counted twice.
//
//   PASS D  Sweep the roots, reject the ones that are not targets (see below),
//           and insertion-sort the NBLOB largest survivors into registers.
//
//   PASS E  Merge bounding boxes that sit within BOX_GAP of each other, one
//           candidate pair per clock.  See [9b].
//
// Worst case is about 81,000 clocks against the 99,000 available (71,700
// before MAX_ROUNDS went to 5), and the common case (a handful of merges) is
// a small fraction of that -- with no merges at all, passes A and B are
// skipped entirely and the cost is 12 clocks per label.  If it ever does run
// over, ovf_time goes high, the previous frame's boxes stay on screen for
// STALE_HOLD frames, and the state machine resets cleanly instead of
// publishing half a result.
//
//===========================================================================
// WHAT PASS D REJECTS, AND WHY AREA ALONE IS NOT ENOUGH (2026-09-07)
//===========================================================================
// The first bench run put a yellow rectangle around the WHOLE FRAME in nearly
// every shot.  That was not a drawing bug: the lens vignette makes the frame
// border cross a global threshold, the border is 8-connected all the way round,
// and one ring-shaped component therefore has a bounding box of exactly
// (0,0)-(1919,1079).  Worse, any real object that touched the ring merged into
// it and stopped being reported at all -- a 270,000-pixel charger sitting in
// the middle of the frame produced no box of its own.
//
// MIN_AREA cannot see this.  `area` is a PIXEL COUNT, and a thin ring round a
// 1080p frame is a perfectly respectable 200,000 pixels -- an order of
// magnitude over any sane MIN_AREA.  What is wrong with it is its SHAPE, so the
// tests have to be about shape:
//
//   MAX_W / MAX_H   the bounding box may not span most of a frame dimension.
//                   Kills the ring (1920x1080), the full-width bands the
//                   09-07 photos showed across the top of the picture, and the
//                   guaranteed frame-filling blob a non-pass affine position
//                   produces by painting its surround black.
//
//   FILL_SHIFT      area must be at least (bbox area >> FILL_SHIFT).  This is
//                   the one that generalises: a solid part fills 60-80% of its
//                   box, a circle 78%, while a ring, a lace of thresholded
//                   gradient, or two unrelated specks that a stray diagonal
//                   merged into one label fill a few percent.  It costs one
//                   11x11 multiply, once per label, in blanking.
//
// Both are cheap and neither is a substitute for the other: a compact 40x40
// noise clump passes the fill test and is caught by MIN_AREA, a solid object
// held very close passes the fill test and is caught by MAX_W/MAX_H, and the
// vignette ring passes MIN_AREA and is caught by both.
//
// dbg_reject counts what these threw away, so "the filter ate my target" is a
// reading rather than a guess.  A target that vanishes with dbg_reject going up
// by one is a rejection; one that vanishes with dbg_reject flat never made it
// out of the threshold.
//
// EVERY DEPENDENT READ COSTS TWO CLOCKS.  The address is registered and the
// RAM output is registered, so `par_ra_r <= X` at cycle t makes par_q valid at
// t+2.  The wait states in each pass are that, not padding -- collapsing them
// reads the previous iteration's data, which shows up as blobs merged with
// whatever was next to them in the label space.
//
//===========================================================================
// PIPELINE ALIGNMENT (get this wrong and the boxes are off by a pixel, or the
// neighbours come from the wrong row)
//===========================================================================
// The previous row's labels come from one block RAM read per clock at the
// running pixel address, and NW/N/NE are that read plus two delayed copies.
// With a registered RAM output the read issued at cycle n returns lbuf[n-1] at
// cycle n+1, so at cycle m the three copies are lbuf[m-1], lbuf[m-2] and
// lbuf[m-3].  Setting L = m-2 makes those exactly NE, N and NW of pixel L --
// which is why the input bit is delayed two clocks to reach the prev-row
// reduction and three to reach the label decision.
//
// The row buffers ping-pong on py[0]: row y writes buffer y[0] and reads
// buffer ~y[0].  At a row boundary the tail of row y-1 is still being written
// into the same buffer row y has started reading, but the addresses are 1917+
// against 0..3 and a 1W1R block RAM does not care.
//
// THE FEEDBACK PATH IS ONE COMPARE DEEP.  W is this pipeline's own output from
// the previous clock, so it cannot be pipelined away.  The three prev-row
// labels are therefore reduced to a single min/max one stage EARLIER, leaving
// the closed loop as one 11-bit compare and a mux.  Doing the four-way
// reduction in one stage instead would put three levels of compare inside a
// loop that has to close in one clock, and this design has 0.1ns of setup
// slack to spend.  The new-label counter is pre-incremented into lnext_p1 for
// the same reason -- taking a label is a mux between two registers, not an add
// in the loop.
//
//===========================================================================
// WHAT COSTS WHAT
//===========================================================================
//   2 x 1920 x LBW    row label buffers, ping-pong        4 ERAM
//   NLAB x LBW        union-find parent table             2 ERAM
//   NLAB x 64         feature records                     7 ERAM
//   MERGE_N x 2*LBW   merge list                          2 ERAM
//
// The feature record is exactly 64 bits: {area[19:0], x0, x1, y0, y1} with
// 11-bit coordinates.  Area saturates at 2^20-1, half a frame -- a blob that
// large is a thresholding failure, not a target.
//
// NO CENTROID YET.  sum_x/sum_y would add 62 bits per label (another 6 ERAM)
// and then a divide to turn them into a position.  The box centre is
// (x0+x1)>>1, costs nothing, and is what the nearest-neighbour tracker in the
// next round needs.  True centroids can go in later with the reciprocal-LUT
// trick isp_auto_level already uses, if there is ever a reason to want them.
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module ccl_blob #(
parameter integer IMG_HDISP = 1920,
parameter integer IMG_VDISP = 1080,

// Label width.  11 bits = 2047 usable provisional labels.  A provisional
// label is only created at the leading edge of a region in a row, so a bench
// scene with tens of objects uses tens of labels; thousands means the
// threshold is producing speckle, which is what ovf_label is there to say.
parameter integer LBW      = 11,

// Targets reported per frame.  det_overlay instantiates eight coordinate
// comparators per box, so this is also the overlay's logic cost -- drop it to
// 4 if the P&R report shows clk0 regressing.
parameter integer NBLOB    = 8,

// Merge list depth: one entry per 8-connected diagonal bridge in the frame.
// MIDX must stay exactly log2(MERGE_N) -- it is the index width, and there is
// no portable log2 to derive it with in the Verilog TD accepts.
parameter integer MERGE_N  = 1024,
parameter integer MIDX     = 10,

// Blobs smaller than this are dropped before the top-N sort.  256 is about
// 16x16 on a 1080p frame.
parameter integer MIN_AREA = 256,

// Bounding-box span caps -- see WHAT PASS D REJECTS.  Defaults are 7/8 of the
// frame, which is loose enough for an object held close to the lens and still
// rejects anything that reaches both opposite edges.  3/4 (1440 x 810) is the
// tightening step if background structure still gets through.
parameter integer MAX_W = 1680,
parameter integer MAX_H = 945,

// Minimum fill, as log2 of the reciprocal: 2 = the blob must cover at least a
// quarter of its own bounding box.  3 is the loosening step for objects with
// long thin protrusions; a value of 20 or more disables the test, since the
// shifted bbox is then always 0 or 1.
parameter integer FILL_SHIFT = 2,

// Safety cap on the pass A relaxation.  Two rounds is enough for convex
// blobs; the cap means a pathological frame degrades to a wrong box instead
// of a state machine that never finishes.
parameter integer MAX_ROUNDS = 4,

//------------------------------------------------------------------------
// WHAT TO DO WHEN THE READING IS KNOWN TO BE WRONG -- 2026-09-18.
//
// Both of these exist because the 09-17 bench run produced exactly the two
// complaints the old silent behaviour guarantees: "three objects give false
// boxes" and "a box stays on screen after the object is gone".
//
// OVF_TRIM: 1 = when the label table or the merge list overflowed during the
// scan, publish only blob 0 (pass D's largest survivor).  0 = publish
// everything that passed the area and shape tests.  The L/M characters appear
// either way, so the diagnostic is never hidden.
//
// ⚠⚠ THE ARGUMENT FOR 1 WAS WRONG, AND system_top NOW PASSES 0.  It used to
// read "the boxes of that frame point at fragments of whatever happened to
// keep its label, so publishing all eight is publishing eight lies."  That
// confuses SPLITTING with RELOCATION.  A dropped merge pair leaves two labels
// with separate roots; passes C and D then accumulate each root's bbox from
// the feature records of the runs that DID reach it.  Every published bbox is
// therefore a union of real foreground runs -- a SUBSET of a true object,
// never a rectangle somewhere the mask was empty.  Overflow makes boxes too
// small and too many.  It cannot make them point at nothing.
//
// What that cost on the board (2026-09-18 photos): three frames with two or
// three objects present, blob_count reading the CORRECT 2 / 2 / 3, an M on
// the OSD, and exactly ONE box drawn.  The merge pressure came from
// background speckle -- hundreds of tiny blobs that MIN_AREA rejects anyway,
// which is why blob_count stayed right -- and the real objects' equivalences
// survived intact.  So OVF_TRIM was throwing away boxes that were correct, to
// avoid showing a splitting artefact that was not happening.
//
// Keep the parameter: if a future scene really does over-segment the objects
// themselves, "one box instead of five pieces of one object" becomes the
// better presentation again, and this is how to get it back in one recompile.
// The module default stays 1 so that dtb's T28 keeps testing the mechanism.
//
// STALE_HOLD: how many CONSECUTIVE frames of "the passes did not fit in
// blanking" are allowed to keep showing the last good boxes before the boxes
// are blanked instead.  Holding is right for a one-frame overrun -- blinking
// the boxes off for 16 ms is worse than 16 ms of slightly old geometry -- and
// wrong for a sustained one, which is what a box parked over empty desk looks
// like.  2 frames is 33 ms of hold, under the flicker threshold, and then it
// tells the truth.
parameter integer OVF_TRIM   = 1,
parameter integer STALE_HOLD = 2,

// How many previously-recorded merge pairs the duplicate filter remembers.
// See CONSECUTIVE-DUPLICATE FILTER at [6].  This is graduated on purpose,
// because it is the ONE thing this round adds to the PIXEL path -- a 2*LBW
// equality compare in front of the merge list's write enable:
//   2 = both slots.  Needed for three components meeting at a point, where
//       the scan alternates between two pairs along the junction.
//   1 = one slot.  Half the compare logic; still collapses the ordinary
//       two-component horizontal overlap, which is the case that filled the
//       list on the bench.
//   0 = OFF, bit-exact pre-09-18 behaviour and zero logic in the pixel path.
// If pclkx1 goes negative after this round and re-seeding does not recover
// it, step this down before touching anything else -- it is the only change
// here with a pixel-domain cost.
parameter integer DUP_DEPTH  = 2,

// How many clocks of "de has stayed low" mean the frame has ended, rather
// than a line.  See [1] FRAME EDGES -- this is what gives the frame-end
// passes the WHOLE vertical interval instead of the sync pulse.  It has to
// sit above the horizontal blanking (uivtc: H_FrameSize 2200 - H_ActiveSize
// 1980 = 220 clocks) and far below the vertical one (45 x 2200 = 99,000).
// 512 is the midpoint in the log sense and costs 0.5% of the window.
// ⚠ A BENCH WITH A SMALL FRAME MUST SCALE THIS. It is in CLOCKS, and a bench
// whose horizontal blanking is 16 needs a VB_GUARD of a few tens, not 512 --
// otherwise de resumes before the guard expires, the passes never start at
// all, and every starvation test passes for the wrong reason.
parameter integer VB_GUARD   = 512,

// 1 = derive the frame edges from in_vs the way everything before 2026-09-18
// did, bit-exactly.  Keep it at 0; this exists so that "did the frame-edge
// change do this" is one recompile and not an argument.  See [1].
parameter integer VS_EDGES   = 0,

// BOX MERGE -- 2026-09-18, and it is the counterpart of MERGE_GAP in
// motion_frame_drawer.  How many PIXELS apart two surviving bounding boxes
// may sit and still be called one object.  0 = off, exact 8-connectivity,
// pre-09-18 behaviour.  See [9b] for the full argument and the cost.
parameter integer BOX_GAP    = 0,

// How many times the pairwise sweep is repeated, so that a chain A-B-C
// collapses in one frame.  Each round is NBLOB*NBLOB clocks in blanking.
parameter integer BOX_ROUNDS = 2,

// 2026-10-05, the two fixes below.  Both 0 = this module exactly as of 09-18.
//
// SEEN_LOG2: hashed "already on the list" filter in front of the merge list,
// 2^SEEN_LOG2 entries.  See SEEN FILTER at [6].  The DUP_DEPTH filter only
// catches a pair repeated back to back, but most repeats are ROW-PERIODIC: a
// run whose left part carries the larger label hands that split down to the
// row below, so the same pair is pushed again on every row of the blob, with
// the other seams of the frame in between.  Skin masks on the 10-05 board
// recording: median 3,945 pushes of 366 distinct pairs; after DUP_DEPTH 2,
// 1,536 writes and the list overflowed on 82% of frames with a face in them
// -- the face then comes out as fragments.  At 8 (256 entries) the writes are
// within a few percent of the distinct-pair count (p90 609, max 894).
parameter integer SEEN_LOG2  = 0,

// PA_HOOK: 1 = pass A writes only parent[a] and parent[b].  See PASS A at [9].  The
// shortcut writes to parent[ra] / parent[rb] can RAISE a parent, and on a
// duplicate-free list that makes pass A cycle without converging (frame 2691:
// still changing after 60 rounds, the top of a face lost).  Must be 1 whenever
// SEEN_LOG2 is non-zero.
parameter integer PA_HOOK    = 0,

// 2026-10-09 MASK PASS-THROUGH for shape_cnn (teammate's Anlogic7, ported).
// MASK_EN = 0: none of [10] is built, out_* are 0 -- the module is exactly
// as before, which is what the skin-chain instance and every bench get.
// in_mask is the mask BEFORE det_morph_open, aligned with in_de by the top
// level; the boxes are computed on the opened mask, which the two causal 3x3
// stages pushed by (+2,+2), so an in_mask pixel sits at (in_px+MASK_SHIFT,
// in_py+MASK_SHIFT) in box coordinates.  0 when in_mask is in_bin itself.
parameter integer MASK_EN    = 0,
parameter integer MASK_SHIFT = 2
)(
input  wire        clk,
input  wire        rst_n,

// From det_binarize -- already aligned with each other.
//
// ⚠ in_vs IS NOT A FRAME-ACTIVE FLAG, despite being high across the visible
// frame.  On this chain it is ~vtc_vs, the inverted five-line sync PULSE, so
// it is also high across both porches.  [1] explains why that mattered and
// why the frame edges no longer come from it.
input  wire        in_vs,
input  wire        in_de,
input  wire        in_bin,
input  wire [11:0] in_px,
input  wire [11:0] in_py,

// Published once per frame, in vertical blanking, and stable for the whole of
// the following frame -- which is what lets det_overlay read them with no
// handshake at all.
output reg  [NBLOB*12-1:0] blob_x0,
output reg  [NBLOB*12-1:0] blob_x1,
output reg  [NBLOB*12-1:0] blob_y0,
output reg  [NBLOB*12-1:0] blob_y1,
output reg  [NBLOB-1:0]    blob_valid,
output reg  [7:0]          blob_count,

// Each holds for one frame.  ovf_label = the provisional label space ran out,
// ovf_merge = the merge list did, ovf_time = the frame-end passes did not
// finish before the next frame started.  Any of them means the published boxes
// are suspect, and the OSD shows their OR as a single character.
output reg         ovf_label,
output reg         ovf_merge,
output reg         ovf_time,

// Bench instrumentation.  Not used by the logic -- these exist so the bring-up
// question "is the threshold producing speckle" can be answered from
// ChipWatcher instead of from how the boxes look.
output reg  [11:0] dbg_label_max,
output reg  [11:0] dbg_merge_cnt,
output reg  [2:0]  dbg_rounds,

// Roots that were big enough to be a target and were thrown out by the shape
// tests anyway.  Latched per frame alongside the boxes.
output reg  [11:0] dbg_reject,

// MASK PASS-THROUGH (MASK_EN), see [10].  Two clocks after in_*.
input  wire              in_mask,
output reg               out_vs,
output reg               out_de,
output reg  [11:0]       out_px,     // box coordinates, MASK_SHIFT added
output reg  [11:0]       out_py,
output reg               out_mask,
output reg  [NBLOB-1:0]  out_inbox   // bit j = pixel inside published box j
);

localparam integer NLAB     = (1 << LBW);
localparam [19:0]  AREA_MAX = 20'hFFFFF;
localparam [11:0]  X_LAST   = IMG_HDISP - 1;

localparam [4:0] S_IDLE = 5'd0,
                 S_A_ML = 5'd1,  S_A_WT = 5'd2,  S_A_RA = 5'd3,
                 S_A_RB = 5'd4,  S_A_W0 = 5'd5,  S_A_W1 = 5'd6,
                 S_A_W2 = 5'd7,  S_A_W3 = 5'd8,  S_A_W4 = 5'd9,
                 S_ROUND= 5'd10,
                 S_B_RI = 5'd11, S_B_W1 = 5'd12, S_B_W2 = 5'd13,
                 S_B_W3 = 5'd14, S_B_W4 = 5'd15,
                 S_C_RI = 5'd16, S_C_K1 = 5'd17, S_C_CK = 5'd18,
                 S_C_P1 = 5'd19, S_C_RP = 5'd20, S_C_R1 = 5'd21,
                 S_C_WR = 5'd22,
                 S_D_RD = 5'd23, S_D_W1 = 5'd24, S_D_DIM= 5'd25,
                 S_D_MUL= 5'd26, S_D_INS= 5'd27,
                 S_E_CK = 5'd29,
                 S_PUB  = 5'd28;

integer j;

//========================================================================
// [0] Declared up here because the memory port muxes below need fsm_run.
//========================================================================
reg [4:0] state;

reg [11:0] k;                  // merge list index, pass A
reg [11:0] i;                  // label index, passes B/C/D
reg [11:0] mcount;             // merges recorded this frame
reg [11:0] lmax_hold;          // highest provisional label this frame
reg [2:0]  round;
reg        changed;
reg [3:0]  startd;
reg [1:0]  stale_n;            // consecutive frames the passes overran

// The scan-side flags are cleared at frame_start and set during the scan, and
// the passes run in the blanking AFTER that scan -- so at S_PUB these still
// describe the frame being published.  No extra latch needed.
wire ovf_bad = (OVF_TRIM != 0) && (ovf_label || ovf_merge);

reg [LBW-1:0] ua_r, ub_r, ra_r, rb_r, rm_r, p_hold;
reg [63:0]    reci_hold;

reg [LBW-1:0] par_ra_r, par_wa_r, par_wd_r;
reg           par_we_r;
reg [LBW-1:0] frec_ra_r, frec_wa_r;
reg [63:0]    frec_wd_r;
reg           frec_we_r;

wire fsm_run = (state != S_IDLE);

//========================================================================
// [1] Frame edges
//
// ⚠⚠ THESE COME FROM in_de, NOT FROM in_vs, AND THAT IS THE WHOLE POINT.
// It is the fix for "the object is detected but no box is drawn", which on
// the board reads as T on the OSD with TARGETS >= 1, and which gets worse
// for a centred object than for one clipped by the frame edge.
//
// in_vs on this chain is ~vtc_vs -- the INVERTED FIVE-LINE SYNC PULSE
// (uivtc: vtc_vs = vcnt > 1084 && vcnt <= 1089), not a frame-active flag.
// It is high across the visible frame, but it is ALSO high across the 4-line
// front porch and the 35-line back porch.  So gating the frame-end passes on
// its LOW period handed them 5 x 2200 = 11,000 clocks -- while every budget
// ever written for this module assumed the whole 45-line vertical interval,
// 99,000.  Nine times too few, for three years of rounds.
//
// The passes cost ~17 clocks per label (B 5 + C 7 + D 5) plus 9 per merge
// pair per round, so 11,000 clocks ran out at roughly 500-600 labels.  Past
// that the abort fires, ovf_time goes high, and since STALE_HOLD the boxes
// are blanked after two such frames -- the detector was right and the
// publish path was starved.  The position and count dependence follows: an
// object clipped by the frame edge, with its replicate-clamped surround,
// fragments the mask into fewer labels than a fully visible one in the
// middle, and two or three objects into strictly more.
//
// WHY THE BENCH NEVER SAW IT: dtb drives vs low for VB = 40 LINE TIMES
// against 32 active rows.  Its own header does the sizing against 99,000.
// It modelled the number the design wanted, not the pulse the chain has --
// §4.3's first class of self-deceiving bench, in a new place.
//
// WHY de WORKS: out_de through det_bin3x3 is a plain 3-clock shift of in_de,
// so mop_de carries uivtc's geometry exactly -- low for 220 clocks between
// active lines, low for 45 line times between frames.  "de has been low for
// VB_GUARD clocks" separates those two with more than a decade of margin and
// needs no line counter and no new port.  Cost: VB_GUARD clocks off the
// front of a 99,000-clock window.
//
// WHAT MOVES WITH THEM, deliberately, because every consumer of these two
// edges wants the TRUE frame boundary and not the sync pulse:
//   - the abort (below endcase) now fires at the first active pixel, so the
//     passes get the whole interval instead of losing the back porch;
//   - the parent[] init starts there too, running 2048 clocks into active
//     video -- which is what [8] already says it is designed to do ("during
//     the ACTIVE part of the frame"), and is safe because the scan never
//     reads that array.  On an abort frame fsm_run is still high on the init's
//     first clock, so parent[0] is skipped; labels start at 1, so no.
//   - the scan-side clears (mwptr, ovf_label, ovf_merge) land at the first
//     active pixel, several pipeline stages ahead of that pixel's own label
//     allocation and merge push, so they still precede what they clear;
//   - ovf_bad stays valid at S_PUB, which now runs BEFORE the clears rather
//     than after them -- more margin than it had, not less.
//========================================================================
reg [9:0] dgap;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n)               dgap <= 10'd0;
    else if (in_de)           dgap <= 10'd0;
    else if (dgap != 10'h3FF) dgap <= dgap + 10'd1;
end

wire vblank    = (dgap >= VB_GUARD);
wire frame_act = (VS_EDGES != 0) ? in_vs : ~vblank;

reg fact_d;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) fact_d <= 1'b0;
    else        fact_d <= frame_act;
end

wire frame_start = frame_act & ~fact_d;
wire frame_tick  = fact_d  & ~frame_act;

//========================================================================
// [2] Input delay chain.  d2 feeds the prev-row reduction, d3 the label
// decision, d4 the row-buffer write and the record read-modify-write.
//========================================================================
reg        bin_d1, bin_d2, bin_d3;
reg        de_d1,  de_d2,  de_d3,  de_d4;
reg [11:0] px_d1,  px_d2,  px_d3,  px_d4;
reg [11:0] py_d1,  py_d2,  py_d3,  py_d4;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        bin_d1 <= 1'b0;  bin_d2 <= 1'b0;  bin_d3 <= 1'b0;
        de_d1  <= 1'b0;  de_d2  <= 1'b0;  de_d3  <= 1'b0;  de_d4  <= 1'b0;
        px_d1  <= 12'd0; px_d2  <= 12'd0; px_d3  <= 12'd0; px_d4  <= 12'd0;
        py_d1  <= 12'd0; py_d2  <= 12'd0; py_d3  <= 12'd0; py_d4  <= 12'd0;
    end else begin
        bin_d1 <= in_bin; bin_d2 <= bin_d1; bin_d3 <= bin_d2;
        de_d1  <= in_de;  de_d2  <= de_d1;  de_d3  <= de_d2;  de_d4 <= de_d3;
        px_d1  <= in_px;  px_d2  <= px_d1;  px_d3  <= px_d2;  px_d4 <= px_d3;
        py_d1  <= in_py;  py_d2  <= py_d1;  py_d3  <= py_d2;  py_d4 <= py_d3;
    end
end

//========================================================================
// [3] Row label buffers, ping-pong.  No reset on the arrays or their output
// registers -- block RAM, same as every other line buffer in this design.
//
// Every pixel of every row is written, background included, so a row is
// completely refreshed before the next row reads it.  Row 0 reads whatever
// the previous frame left behind; the py != 0 masks in [4] discard it.
//========================================================================
reg [LBW-1:0] lbuf0 [0:IMG_HDISP-1];
reg [LBW-1:0] lbuf1 [0:IMG_HDISP-1];

reg [LBW-1:0] lbl_c;                        // label just decided = write data

wire [11:0] lb_ra = in_px;
wire [11:0] lb_wa = px_d4;
wire        lb_we = de_d4;
wire        wsel  = py_d4[0];
wire        rsel  = ~in_py[0];

reg [LBW-1:0] lq0, lq1;
reg           rsel_d;

always @(posedge clk) begin
    if (lb_we & ~wsel) lbuf0[lb_wa] <= lbl_c;
    lq0 <= lbuf0[lb_ra];
end

always @(posedge clk) begin
    if (lb_we &  wsel) lbuf1[lb_wa] <= lbl_c;
    lq1 <= lbuf1[lb_ra];
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) rsel_d <= 1'b0;
    else        rsel_d <= rsel;
end

wire [LBW-1:0] q = rsel_d ? lq1 : lq0;

reg [LBW-1:0] q_d1, q_d2;
always @(posedge clk) begin
    q_d1 <= q;
    q_d2 <= q_d1;
end

//========================================================================
// [4] Stage B: reduce the three previous-row neighbours to one min and one
// max.  Two levels of compare, and deliberately OFF the feedback path.
//========================================================================
wire row_ok = (py_d2 != 12'd0);

wire [LBW-1:0] nw = (row_ok && (px_d2 != 12'd0))  ? q_d2 : {LBW{1'b0}};
wire [LBW-1:0] n  =  row_ok                       ? q_d1 : {LBW{1'b0}};
wire [LBW-1:0] ne = (row_ok && (px_d2 != X_LAST)) ? q    : {LBW{1'b0}};

wire [LBW-1:0] nn_min = (nw == 0) ? n : (n == 0) ? nw : (nw < n) ? nw : n;
wire [LBW-1:0] nn_max = (nw == 0) ? n : (n == 0) ? nw : (nw > n) ? nw : n;

wire [LBW-1:0] p_min = (nn_min == 0) ? ne : (ne == 0) ? nn_min
                                          : (nn_min < ne) ? nn_min : ne;
wire [LBW-1:0] p_max = (nn_max == 0) ? ne : (ne == 0) ? nn_max
                                          : (nn_max > ne) ? nn_max : ne;

reg [LBW-1:0] pmin_r, pmax_r;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        pmin_r <= {LBW{1'b0}}; pmax_r <= {LBW{1'b0}};
    end else begin
        pmin_r <= p_min; pmax_r <= p_max;
    end
end

//========================================================================
// [5] Stage C: the label decision.  One compare inside the loop.
//
// Bit LBW of lnext doubles as the exhausted flag -- it can only be set by
// counting past NLAB-1, so no separate comparator is needed for it.
//========================================================================
reg [LBW:0] lnext, lnext_p1;

wire           lbl_full  = lnext[LBW];
wire [LBW-1:0] new_label = lnext[LBW-1:0];

// Widened before use: lnext is LBW+1 bits, and lmax_hold is a flat 12 so the
// pass B/C/D loop counters do not have to track LBW.  Assigning narrow to wide
// zero-extends, which keeps this portable at any LBW instead of needing a
// zero-width replication.
wire [15:0] lnext_w = lnext;

wire [LBW-1:0] w_l = (px_d3 != 12'd0) ? lbl_c : {LBW{1'b0}};

wire have_p = (pmin_r != 0);
wire have_w = (w_l    != 0);

wire [LBW-1:0] pw_min = (pmin_r < w_l) ? pmin_r : w_l;
wire [LBW-1:0] pw_max = (pmax_r > w_l) ? pmax_r : w_l;

wire fg_pix   = bin_d3 & de_d3;
wire want_new = fg_pix & ~have_p & ~have_w;
wire take_new = want_new & ~lbl_full;

wire [LBW-1:0] lmin_w = !fg_pix           ? {LBW{1'b0}}
                      : (have_p & have_w) ? pw_min
                      :  have_p           ? pmin_r
                      :  have_w           ? w_l
                      :  take_new         ? new_label
                      :                     {LBW{1'b0}};

wire [LBW-1:0] lmax_w = !fg_pix           ? {LBW{1'b0}}
                      : (have_p & have_w) ? pw_max
                      :  have_p           ? pmax_r
                      :  have_w           ? w_l
                      :                     lmin_w;

wire mpush_w = fg_pix & (lmax_w != lmin_w);

reg             upd_c, new_c, mpush_r;
reg [2*LBW-1:0] mpair_r;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        lbl_c    <= {LBW{1'b0}};
        upd_c    <= 1'b0;
        new_c    <= 1'b0;
        mpush_r  <= 1'b0;
        mpair_r  <= {(2*LBW){1'b0}};
        lnext    <= {{LBW{1'b0}}, 1'b1};
        lnext_p1 <= 2;
    end else begin
        lbl_c    <= lmin_w;
        upd_c    <= (lmin_w != 0);
        new_c    <= take_new;
        mpush_r  <= mpush_w;
        mpair_r  <= {lmin_w, lmax_w};

        if (frame_start) begin
            lnext    <= {{LBW{1'b0}}, 1'b1};
            lnext_p1 <= 2;
        end else if (take_new) begin
            lnext    <= lnext_p1;
            lnext_p1 <= lnext_p1 + 1'b1;
        end
    end
end

//========================================================================
// [6] Merge list.  Written during the scan, read by pass A -- the two never
// overlap in time, so one write port and one read port is all it takes.
//========================================================================
reg [2*LBW-1:0] mlist [0:MERGE_N-1];
reg [2*LBW-1:0] mlist_q;

reg [11:0] mwptr;
reg [11:0] m_ra;

//------------------------------------------------------------------------
// CONSECUTIVE-DUPLICATE FILTER -- 2026-09-18.  Two registers and two
// comparators, and it is the single cheapest thing in this module.
//
// The merge list is a SET: pass A's fixed point is "parent[a] == parent[b] for
// every recorded pair", and recording the same pair twice adds nine clocks and
// no information.  But the scan records one pair PER PIXEL, and where two
// components overlap horizontally the pair is the same on every pixel of the
// overlap:
//
//   row y-1     . . A A A A A A . .        <- one run, label A
//   row y       . . B B B B B B . .        <- the run below it, label B
//
// Every pixel of row y sees W = min(A,B) and N = A, so every pixel pushes
// {min,max} = the identical word.  A 100-pixel overlap cost 100 entries of a
// 1024-entry list and 900 clocks of pass A per round.  Two objects that touch,
// or one speckled mask, filled the list on their own -- which is the 'M' on
// the bench photos, and 'M' means the union-find equivalences were LOST and
// every box that frame points somewhere arbitrary.
//
// Two slots deep, not one, because three components meeting at a point make
// the scan alternate between two pairs for the length of the junction.  Depth
// two catches that; depth one would pass every other word.
//
// Correctness: dropping a duplicate cannot change pass A's fixed point, and
// the filter is stateless across frames (cleared at frame_start), so it can
// never suppress a pair the new frame needs.
//------------------------------------------------------------------------
reg [2*LBW-1:0] mlast0, mlast1;
reg [1:0]       mlast_v;

// mp_v / mp_pair: the push as the filters and the list see it -- mpush_r /
// mpair_r, or one clock later with SEEN_LOG2 (the seen table's read latency).
wire            mp_v;
wire [2*LBW-1:0] mp_pair;
wire            seen_hit;

wire mdup = ((DUP_DEPTH >= 1) && mlast_v[0] && (mp_pair == mlast0))
         || ((DUP_DEPTH >= 2) && mlast_v[1] && (mp_pair == mlast1));

wire mfull = (mwptr >= MERGE_N);
wire mwr   = mp_v & ~mfull & ~mdup & ~seen_hit;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        mlast0 <= {(2*LBW){1'b0}}; mlast1 <= {(2*LBW){1'b0}};
        mlast_v <= 2'b00;
    end else if (frame_start) begin
        mlast_v <= 2'b00;
    end else if (mwr) begin
        mlast1  <= mlast0;
        mlast0  <= mp_pair;
        mlast_v <= {mlast_v[0], 1'b1};
    end
end

always @(posedge clk) begin
    if (mwr) mlist[mwptr[MIDX-1:0]] <= mp_pair;
    mlist_q <= mlist[m_ra[MIDX-1:0]];
end

//------------------------------------------------------------------------
// SEEN FILTER -- 2026-10-05 (SEEN_LOG2 != 0).  A direct-mapped table of the
// pairs already written this frame, indexed by lo ^ (hi << 3) ^ (hi >> 5).
// A push whose slot holds the identical pair is dropped; otherwise it is
// written and takes the slot.  Like the DUP_DEPTH filter it can only drop a
// pair that IS on the list, so pass A's fixed point cannot change -- a
// collision just lets a duplicate through.
//
// One extra pipeline stage: the table is read with the hash of mpair_r (a
// register, so nothing is added to the label feedback loop) and compared one
// clock later against mpair_r2, which is what the list then writes.
//
// Cleared by a 2^SEEN_LOG2-clock sweep after reset and after every frame_tick
// (labels are reused every frame, so a stale entry would drop a real pair).
// The sweep runs in vertical blanking, where nothing pushes; the hit is masked
// while it runs and for the clock after, and whenever the slot being read is
// the one being written, so neither the reset contents nor the RAM's
// read-during-write behaviour ever matter.
//------------------------------------------------------------------------
generate if (SEEN_LOG2 != 0) begin : g_seen
    localparam integer SN = 1 << SEEN_LOG2;

    wire [LBW-1:0] h_lo = mpair_r[2*LBW-1:LBW];
    wire [LBW-1:0] h_hi = mpair_r[LBW-1:0];
    wire [LBW+3:0] h_x  = {4'd0, h_lo} ^ {1'b0, h_hi, 3'd0} ^ {4'd0, (h_hi >> 5)};
    wire [SEEN_LOG2-1:0] sidx1 = h_x[SEEN_LOG2-1:0];

    reg                 mpush_r2;
    reg [2*LBW-1:0]     mpair_r2;
    reg [SEEN_LOG2-1:0] sidx_r2;
    reg [SEEN_LOG2:0]   sclr;          // sweep address; MSB set = idle
    reg                 smask;         // clear running last clock, or RDW clash
    reg [2*LBW:0]       seen [0:SN-1]; // {valid, pair}
    reg [2*LBW:0]       seen_q;

    wire sclr_busy = ~sclr[SEEN_LOG2];

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            mpush_r2 <= 1'b0;
            mpair_r2 <= {(2*LBW){1'b0}};
            sidx_r2  <= {SEEN_LOG2{1'b0}};
            sclr     <= {(SEEN_LOG2+1){1'b0}};
            smask    <= 1'b1;
        end else begin
            mpush_r2 <= mpush_r;
            mpair_r2 <= mpair_r;
            sidx_r2  <= sidx1;
            if (frame_tick)     sclr <= {(SEEN_LOG2+1){1'b0}};
            else if (sclr_busy) sclr <= sclr + 1'b1;
            smask <= sclr_busy || (mwr && (sidx1 == sidx_r2));
        end
    end

    always @(posedge clk) begin
        if (sclr_busy) seen[sclr[SEEN_LOG2-1:0]] <= {(2*LBW+1){1'b0}};
        else if (mwr)  seen[sidx_r2] <= {1'b1, mpair_r2};
        seen_q <= seen[sidx1];
    end

    assign mp_v     = mpush_r2;
    assign mp_pair  = mpair_r2;
    assign seen_hit = mpush_r2 & ~smask & seen_q[2*LBW] & (seen_q[2*LBW-1:0] == mpair_r2);
end else begin : g_noseen
    assign mp_v     = mpush_r;
    assign mp_pair  = mpair_r;
    assign seen_hit = 1'b0;
end endgenerate

wire [LBW-1:0] ml_a = mlist_q[2*LBW-1:LBW];
wire [LBW-1:0] ml_b = mlist_q[LBW-1:0];

//========================================================================
// [7] Feature records.  {area[19:0], x0[10:0], x1[10:0], y0[10:0], y1[10:0]}
//
// y0 never changes after the record is created and y1 is always the current
// row: labels are visited in raster order, so py is monotonic per label.  Two
// comparators saved, and it is a property of the scan order rather than an
// approximation.
//
// THREE-DEEP FORWARDING ON THE READ-MODIFY-WRITE.  A read issued at cycle c
// returns data at c+1 reflecting writes applied up to the edge ending c, so
// the two writes still in flight have to be bypassed by hand.  Consecutive
// pixels of a horizontal run all hit the same label, so this is the common
// case here, not a corner one -- without the bypass every run would count as
// one pixel wide.
//========================================================================
reg [63:0] frec [0:NLAB-1];
reg [63:0] frec_q;

reg [LBW-1:0] lbl_r1, lbl_r2, lbl_r3;
reg           upd_r1, upd_r2, upd_r3;
reg [11:0]    px_r1,  py_r1;
reg           new_r1;
reg [63:0]    rec_r2, rec_r3;

wire [LBW-1:0] frec_ra = fsm_run ? frec_ra_r : lbl_c;
wire [LBW-1:0] frec_wa = fsm_run ? frec_wa_r : lbl_r2;
wire [63:0]    frec_wd = fsm_run ? frec_wd_r : rec_r2;
wire           frec_we = fsm_run ? frec_we_r : upd_r2;

always @(posedge clk) begin
    if (frec_we) frec[frec_wa] <= frec_wd;
    frec_q <= frec[frec_ra];
end

wire [63:0] base = (upd_r2 && (lbl_r2 == lbl_r1)) ? rec_r2
                 : (upd_r3 && (lbl_r3 == lbl_r1)) ? rec_r3
                 :                                  frec_q;

wire [19:0] b_area = base[63:44];
wire [10:0] b_x0   = base[43:33];
wire [10:0] b_x1   = base[32:22];
wire [10:0] b_y0   = base[21:11];

wire [10:0] cur_x = px_r1[10:0];
wire [10:0] cur_y = py_r1[10:0];

wire [19:0] up_area = (b_area == AREA_MAX) ? AREA_MAX : (b_area + 20'd1);
wire [10:0] up_x0   = (cur_x < b_x0) ? cur_x : b_x0;
wire [10:0] up_x1   = (cur_x > b_x1) ? cur_x : b_x1;

wire [63:0] rec_w = new_r1 ? { 20'd1, cur_x, cur_x, cur_y, cur_y }
                           : { up_area, up_x0, up_x1, b_y0, cur_y };

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        lbl_r1 <= {LBW{1'b0}}; lbl_r2 <= {LBW{1'b0}}; lbl_r3 <= {LBW{1'b0}};
        upd_r1 <= 1'b0;  upd_r2 <= 1'b0;  upd_r3 <= 1'b0;
        px_r1  <= 12'd0; py_r1  <= 12'd0; new_r1 <= 1'b0;
        rec_r2 <= 64'd0; rec_r3 <= 64'd0;
    end else begin
        lbl_r1 <= lbl_c;  upd_r1 <= upd_c;
        px_r1  <= px_d4;  py_r1  <= py_d4;  new_r1 <= new_c;

        lbl_r2 <= lbl_r1; upd_r2 <= upd_r1; rec_r2 <= rec_w;
        lbl_r3 <= lbl_r2; upd_r3 <= upd_r2; rec_r3 <= rec_r2;
    end
end

//========================================================================
// [8] Union-find parent table.  Initialised to parent[i] = i during the
// ACTIVE part of the frame -- 2048 clocks out of two million, and free
// because the scan never touches this array.  The frame-end passes then find
// it ready with no init pass of their own.
//========================================================================
reg [LBW-1:0] parent [0:NLAB-1];
reg [LBW-1:0] par_q;

reg [LBW:0] init_a;
reg         init_run;

wire [LBW-1:0] par_wa = fsm_run ? par_wa_r : init_a[LBW-1:0];
wire [LBW-1:0] par_wd = fsm_run ? par_wd_r : init_a[LBW-1:0];
wire           par_we = fsm_run ? par_we_r : init_run;

always @(posedge clk) begin
    if (par_we) parent[par_wa] <= par_wd;
    par_q <= parent[par_ra_r];
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        init_a <= {(LBW+1){1'b0}}; init_run <= 1'b0;
    end else if (frame_start) begin
        init_a <= {(LBW+1){1'b0}}; init_run <= 1'b1;
    end else if (init_run) begin
        init_a <= init_a + 1'b1;
        if (init_a == (NLAB - 1)) init_run <= 1'b0;
    end
end

//========================================================================
// [9] Frame-end passes
//========================================================================
wire [LBW-1:0] uf_min = (ra_r < par_q) ? ra_r : par_q;

// Fold a child record into its root's.
wire [19:0] c_area = reci_hold[63:44];
wire [10:0] c_x0   = reci_hold[43:33];
wire [10:0] c_x1   = reci_hold[32:22];
wire [10:0] c_y0   = reci_hold[21:11];
wire [10:0] c_y1   = reci_hold[10:0];

wire [19:0] r_area = frec_q[63:44];
wire [10:0] r_x0   = frec_q[43:33];
wire [10:0] r_x1   = frec_q[32:22];
wire [10:0] r_y0   = frec_q[21:11];
wire [10:0] r_y1   = frec_q[10:0];

wire [20:0] sum_area = {1'b0, c_area} + {1'b0, r_area};

wire [63:0] rec_comb = { (sum_area[20] ? AREA_MAX : sum_area[19:0]),
                         ((c_x0 < r_x0) ? c_x0 : r_x0),
                         ((c_x1 > r_x1) ? c_x1 : r_x1),
                         ((c_y0 < r_y0) ? c_y0 : r_y0),
                         ((c_y1 > r_y1) ? c_y1 : r_y1) };

// Insertion sort, descending by area.  The list is already sorted, so gt is a
// 1..10..0 prefix and gt[j] & ~gt[j-1] is the single insertion point.
reg [19:0] top_area [0:NBLOB-1];
reg [10:0] top_x0   [0:NBLOB-1];
reg [10:0] top_x1   [0:NBLOB-1];
reg [10:0] top_y0   [0:NBLOB-1];
reg [10:0] top_y1   [0:NBLOB-1];
reg [7:0]  nfound;

wire [19:0]      ins_area = frec_q[63:44];

//------------------------------------------------------------------------
// Pass D shape tests.  frec_ra_r and par_ra_r are left pointing at label i for
// the whole of S_D_DIM..S_D_INS and nothing writes either array during pass D,
// so frec_q and par_q are stable across all three states and the width, height
// and product can be spread over them instead of landing in one period.
//------------------------------------------------------------------------
wire [10:0] d_x0 = frec_q[43:33];
wire [10:0] d_x1 = frec_q[32:22];
wire [10:0] d_y0 = frec_q[21:11];
wire [10:0] d_y1 = frec_q[10:0];

reg [10:0] w_r, h_r;
reg [21:0] bbox_r;
reg        isroot_r;

// The bbox is at most 1920x1080, so 22 bits is exact and the shift below never
// loses a bit that mattered.
wire [21:0] fill_min = bbox_r >> FILL_SHIFT;

// ins_area rather than a fourth latch: frec_q is held for all of
// S_D_DIM..S_D_INS, so this and the coordinate writes below read the same
// record, and there is one source of truth for the area instead of two.
// Plain parameter names, not part-selects: MIN_AREA and friends are `integer`
// and the comparison is unsigned as long as one side is an unsigned vector,
// which it is.  This is the same form the pre-09-07 MIN_AREA test used.
wire d_big    = (ins_area >= MIN_AREA);

wire d_accept = isroot_r && d_big
             && (w_r <= MAX_W)
             && (h_r <= MAX_H)
             && ({2'd0, ins_area} >= fill_min);

// Counted separately from d_accept so the OSD/ChipWatcher reading distinguishes
// "the shape tests took it" from "it was never big enough to consider".
wire d_reject = isroot_r && d_big && !d_accept;

// MIN_AREA is compared against a 20-bit count that saturates at AREA_MAX, so a
// MIN_AREA above 2^20-1 would silently reject everything.  Nothing enforces
// that in RTL; it is called out here because "no targets ever" is a symptom
// that looks like a threshold problem and is not.

//------------------------------------------------------------------------
// [9b] PASS E -- BOX MERGE.  2026-09-18.
//
// WHY THIS EXISTS.  ONE object was coming out as several boxes: "a single
// object occasionally reads as several boxes that jump about", "an object near
// the edge easily gives two", "an object at the top border easily gives two".
// The mask really is disconnected in those frames -- the board photos show
// dark shadow bands crossing the bright objects, and either side of such a
// band is a separate 8-connected component, correctly labelled as two.
//
// This is the SAME COMPLAINT, WITH THE SAME CAUSE AND THE SAME FIX, that
// motion_frame_drawer already carries as MERGE_GAP: read its comment, which
// closes with "never a wrong box, always one object wearing three of them".
// That module bridges dead cells on the block grid; this one bridges dead
// pixels between bounding boxes.  Until today the detect chain had no
// equivalent and was held to strict 8-connectivity.
//
// WHY AT THE BOX LEVEL AND NOT IN THE MASK.  The alternative is a
// morphological CLOSING in front of the labeller, and it does not reach:
// det_morph_open's stages are 3x3, so a closing there bridges a 2-pixel gap,
// while the bands in the photos are tens of pixels.  Bridging those in the
// mask means a structuring element tens of pixels across -- one pair of row
// buffers per unit of radius, in the pixel path.  Here it is a handful of
// comparators on eight registers, in blanking.  (det_morph_open's header
// argues against hole-FILLING, and that argument still stands for the mask:
// filling the vignette lace is what consolidates it into one frame-sized
// component.  Merging BOXES cannot do that -- MAX_W/MAX_H/FILL_SHIFT have
// already thrown the lace's component away by the time pass E runs.)
//
// HOW.  One pair per clock over the NBLOB survivors, BOX_ROUNDS sweeps, so a
// chain A-B-C collapses even though A and C never touch.  Merging writes the
// union into the LOWER slot and zeroes the upper one's area, which is exactly
// what blob_valid tests, so an absorbed slot goes invalid with no extra flag.
//
// ⚠ COST, AND IT IS THE HONEST DIRECTION OF THE TRADE: two genuinely separate
// objects whose boxes pass within BOX_GAP now share one box.  That is the
// same trade motion_frame_drawer took deliberately, for the same reason --
// "one object wearing three boxes" reads as broken, "two touching objects in
// one box" reads as coarse.  BOX_GAP is the only knob that moves those two
// against each other, and 0 turns the whole pass off bit-exactly.
//
// ⚠ IT BREAKS THE SORTED-BY-AREA INVARIANT.  Pass D leaves top_* descending
// by area; a merge adds two areas together and can push a slot above the one
// before it.  Nothing downstream depends on the order -- blob_valid is a
// per-slot area test and det_overlay draws all slots alike -- EXCEPT
// OVF_TRIM, which publishes "blob 0, the largest".  With BOX_GAP > 0 and
// OVF_TRIM = 1 that sentence stops being true.  system_top runs OVF_TRIM = 0,
// so they do not meet there; if OVF_TRIM ever goes back to 1, re-sort here or
// pick the largest explicitly.
//------------------------------------------------------------------------
reg [3:0] e_a, e_b;
reg [2:0] e_round;

// Widened by one bit so that x1 + BOX_GAP cannot wrap at the right-hand edge
// of the frame.  The gap is ADDED to each box in turn rather than subtracted
// from the other, for the same reason motion_frame_drawer gives: the
// subtraction underflows at coordinate 0, which is precisely where an object
// entering frame lives.
wire [12:0] eg   = BOX_GAP;

wire [12:0] ea_x0 = {2'b00, top_x0[e_a]};
wire [12:0] ea_x1 = {2'b00, top_x1[e_a]};
wire [12:0] ea_y0 = {2'b00, top_y0[e_a]};
wire [12:0] ea_y1 = {2'b00, top_y1[e_a]};
wire [12:0] eb_x0 = {2'b00, top_x0[e_b]};
wire [12:0] eb_x1 = {2'b00, top_x1[e_b]};
wire [12:0] eb_y0 = {2'b00, top_y0[e_b]};
wire [12:0] eb_y1 = {2'b00, top_y1[e_b]};

wire [20:0] e_sum = {1'b0, top_area[e_a]} + {1'b0, top_area[e_b]};

// Both slots have to hold something: area == 0 IS the empty marker, both for
// the slots pass D never filled and for the ones a previous merge absorbed.
wire e_hit = (BOX_GAP != 0)
          && (e_a  <  e_b)
          && (top_area[e_a] != 20'd0)
          && (top_area[e_b] != 20'd0)
          && (ea_x0 <= (eb_x1 + eg)) && (eb_x0 <= (ea_x1 + eg))
          && (ea_y0 <= (eb_y1 + eg)) && (eb_y0 <= (ea_y1 + eg));

wire [NBLOB-1:0] gt;
wire [NBLOB-1:0] gt_prev = {gt[NBLOB-2:0], 1'b0};

genvar gi;
generate
    for (gi = 0; gi < NBLOB; gi = gi + 1) begin : g_gt
        assign gt[gi] = (ins_area > top_area[gi]);
    end
endgenerate

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        state  <= S_IDLE;
        startd <= 4'd0;  stale_n <= 2'd0;
        k <= 12'd0; i <= 12'd0; round <= 3'd0; changed <= 1'b0;
        e_a <= 4'd0; e_b <= 4'd1; e_round <= 3'd0;
        mcount <= 12'd0; lmax_hold <= 12'd0; nfound <= 8'd0;
        mwptr  <= 12'd0; m_ra <= 12'd0;
        par_ra_r <= {LBW{1'b0}}; par_wa_r <= {LBW{1'b0}};
        par_wd_r <= {LBW{1'b0}}; par_we_r <= 1'b0;
        frec_ra_r<= {LBW{1'b0}}; frec_wa_r<= {LBW{1'b0}};
        frec_wd_r<= 64'd0;       frec_we_r<= 1'b0;
        ua_r <= 0; ub_r <= 0; ra_r <= 0; rb_r <= 0; rm_r <= 0; p_hold <= 0;
        reci_hold <= 64'd0;
        ovf_label <= 1'b0; ovf_merge <= 1'b0; ovf_time <= 1'b0;
        blob_x0 <= 0; blob_x1 <= 0; blob_y0 <= 0; blob_y1 <= 0;
        blob_valid <= {NBLOB{1'b0}}; blob_count <= 8'd0;
        dbg_label_max <= 12'd0; dbg_merge_cnt <= 12'd0; dbg_rounds <= 3'd0;
        dbg_reject <= 12'd0;
        w_r <= 11'd0; h_r <= 11'd0; bbox_r <= 22'd0; isroot_r <= 1'b0;
        for (j = 0; j < NBLOB; j = j + 1) begin
            top_area[j] <= 20'd0; top_x0[j] <= 11'd0; top_x1[j] <= 11'd0;
            top_y0[j]   <= 11'd0; top_y1[j] <= 11'd0;
        end
    end else begin
        par_we_r  <= 1'b0;
        frec_we_r <= 1'b0;

        //----------------------------------------------------------------
        // Scan-side bookkeeping
        //----------------------------------------------------------------
        if (frame_start) begin
            mwptr     <= 12'd0;
            ovf_label <= 1'b0;
            ovf_merge <= 1'b0;
            ovf_time  <= 1'b0;
            // The abort that goes with this -- a frame boundary with the passes
            // still running -- is BELOW endcase, not here.  See THE ABORT HAS
            // TO BE LAST.
        end else begin
            if (mwr)                  mwptr     <= mwptr + 12'd1;
            // ~mdup, so a duplicate arriving after the list is full is not
            // reported as an overflow -- it was already recorded and dropping
            // it loses nothing.  Without this the flag would fire on scenes
            // the filter had actually rescued.
            if (mp_v && ~mdup && ~seen_hit && mfull) ovf_merge <= 1'b1;
            if (want_new && lbl_full) ovf_label <= 1'b1;
        end

        //----------------------------------------------------------------
        // Kick the passes off a few clocks after vs falls, so the last
        // pixel's record write has landed before the ports change hands.
        //----------------------------------------------------------------
        if (frame_tick) begin
            lmax_hold <= lnext_w[11:0] - 12'd1;
            mcount    <= mwptr;
            startd    <= 4'd8;
        end else if (startd != 4'd0) begin
            startd <= startd - 4'd1;
            if (startd == 4'd1) begin
                dbg_label_max <= lmax_hold;
                dbg_merge_cnt <= mcount;
                round   <= 3'd0;
                changed <= 1'b0;
                k       <= 12'd0;
                i       <= 12'd1;
                nfound  <= 8'd0;
                dbg_reject <= 12'd0;
                for (j = 0; j < NBLOB; j = j + 1)
                    top_area[j] <= 20'd0;

                if      (lmax_hold == 12'd0) state <= S_PUB;
                else if (mcount    == 12'd0) state <= S_C_RI;  // nothing merged
                else                         state <= S_A_ML;
            end
        end

        //----------------------------------------------------------------
        case (state)

        // Explicit and load-bearing.  The startd block above sets state to
        // S_A_ML/S_C_RI/S_PUB while state is still S_IDLE, so if S_IDLE fell
        // through to the default below, that assignment would be overwritten
        // by `state <= S_IDLE` in the same cycle and the passes would never
        // start.  Symptom: labels and merges count correctly, blob_count stays
        // 0 forever.
        S_IDLE: ;

        //================================================================
        // PASS A -- hook the trees together, plus the shortcut writes that
        // make it converge.  Nine clocks per recorded pair (seven, PA_HOOK).
        //================================================================
        S_A_ML: begin
            if (k >= mcount) state <= S_ROUND;
            else begin
                m_ra  <= k;
                state <= S_A_WT;
            end
        end

        S_A_WT: state <= S_A_RA;               // mlist_q lands here

        S_A_RA: begin
            ua_r     <= ml_a;
            ub_r     <= ml_b;
            par_ra_r <= ml_a;
            state    <= S_A_RB;
        end

        S_A_RB: begin
            par_ra_r <= ub_r;
            state    <= S_A_W0;
        end

        S_A_W0: begin                          // par_q = parent[a]
            ra_r  <= par_q;
            state <= S_A_W1;
        end

        S_A_W1: begin                          // par_q = parent[b]
            rb_r <= par_q;
            rm_r <= uf_min;
            // ra != rb is exactly "these two were not yet in the same
            // one-level class", which is the right convergence test.
            if (ra_r != par_q) changed <= 1'b1;

            par_wa_r <= ua_r;
            par_wd_r <= uf_min;
            par_we_r <= 1'b1;
            state    <= S_A_W2;
        end

        S_A_W2: begin
            par_wa_r <= ub_r;
            par_wd_r <= rm_r;
            par_we_r <= 1'b1;
            if (PA_HOOK != 0) begin            // no shortcut writes, see PASS A
                k     <= k + 12'd1;
                state <= S_A_ML;
            end else
                state <= S_A_W3;
        end

        S_A_W3: begin
            par_wa_r <= ra_r;
            par_wd_r <= rm_r;
            par_we_r <= 1'b1;
            state    <= S_A_W4;
        end

        S_A_W4: begin
            par_wa_r <= rb_r;
            par_wd_r <= rm_r;
            par_we_r <= 1'b1;
            k        <= k + 12'd1;
            state    <= S_A_ML;
        end

        S_ROUND: begin
            dbg_rounds <= round + 3'd1;
            if (changed && (round < (MAX_ROUNDS - 1))) begin
                round   <= round + 3'd1;
                changed <= 1'b0;
                k       <= 12'd0;
                state   <= S_A_ML;
            end else begin
                i     <= 12'd1;
                state <= S_B_RI;
            end
        end

        //================================================================
        // PASS B -- one increasing-order pointer jump per label.  Runs once.
        //================================================================
        S_B_RI: begin
            if (i > lmax_hold) begin
                i     <= 12'd1;
                state <= S_C_RI;
            end else begin
                par_ra_r <= i[LBW-1:0];
                state    <= S_B_W1;
            end
        end

        S_B_W1: state <= S_B_W2;

        S_B_W2: begin                          // par_q = parent[i]
            p_hold   <= par_q;
            par_ra_r <= par_q;
            state    <= S_B_W3;
        end

        S_B_W3: state <= S_B_W4;

        S_B_W4: begin                          // par_q = parent[parent[i]]
            if (par_q != p_hold) begin
                par_wa_r <= i[LBW-1:0];
                par_wd_r <= par_q;
                par_we_r <= 1'b1;
            end
            i     <= i + 12'd1;
            state <= S_B_RI;
        end

        //================================================================
        // PASS C -- fold every non-root's record into its root's.
        //================================================================
        S_C_RI: begin
            if (i > lmax_hold) begin
                i     <= 12'd1;
                state <= S_D_RD;
            end else begin
                par_ra_r <= i[LBW-1:0];
                state    <= S_C_K1;
            end
        end

        S_C_K1: state <= S_C_CK;

        S_C_CK: begin                          // par_q = root of i
            if (par_q == i[LBW-1:0]) begin     // a root: nothing to fold
                i     <= i + 12'd1;
                state <= S_C_RI;
            end else begin
                p_hold    <= par_q;
                frec_ra_r <= i[LBW-1:0];
                state     <= S_C_P1;
            end
        end

        S_C_P1: state <= S_C_RP;

        S_C_RP: begin                          // frec_q = frec[i]
            reci_hold <= frec_q;
            frec_ra_r <= p_hold;
            state     <= S_C_R1;
        end

        S_C_R1: state <= S_C_WR;

        S_C_WR: begin                          // frec_q = frec[root]
            frec_wa_r <= p_hold;
            frec_wd_r <= rec_comb;
            frec_we_r <= 1'b1;
            i         <= i + 12'd1;
            state     <= S_C_RI;
        end

        //================================================================
        // PASS D -- sweep the roots, reject the ones whose SHAPE says they are
        // background rather than a target, keep the NBLOB largest survivors.
        //
        // Five clocks per label rather than three.  The two extra are the
        // bounding-box dimensions and their product: one 11x11 multiply in the
        // pixel-clock group is not something to fold into an existing state on
        // a design whose worst path is already accounted for.
        //================================================================
        S_D_RD: begin
            if (i > lmax_hold) begin
                // Pass E's sweep starts here.  With BOX_GAP = 0 e_hit is a
                // constant 0, so the states still run and simply publish the
                // same boxes -- 128 clocks of blanking, and one code path
                // instead of two.  The synthesiser folds the comparators away.
                e_a     <= 4'd0;
                e_b     <= 4'd1;
                e_round <= 3'd0;
                state   <= S_E_CK;
            end
            else begin
                par_ra_r  <= i[LBW-1:0];
                frec_ra_r <= i[LBW-1:0];
                state     <= S_D_W1;
            end
        end

        S_D_W1: state <= S_D_DIM;

        S_D_DIM: begin                         // par_q and frec_q valid
            // x1 >= x0 and y1 >= y0 always: x0/x1 are a running min/max of the
            // same coordinate and y0/y1 come from a raster scan, so neither
            // subtract can borrow and no clamp is needed.
            w_r      <= d_x1 - d_x0 + 11'd1;
            h_r      <= d_y1 - d_y0 + 11'd1;
            isroot_r <= (par_q == i[LBW-1:0]);
            state    <= S_D_MUL;
        end

        S_D_MUL: begin
            // Both operands widened to 22 bits BY HAND.  Verilog's
            // context-determined sizing would do it anyway -- the assignment
            // width propagates into the expression -- but at 1920x1080 the
            // product needs 21 bits and an 11-bit truncation here would not
            // fail loudly: fill_min would come out small and every blob would
            // pass the fill test, silently reverting half of this change.  Not
            // a rule to leave to the synthesiser's reading of the standard.
            bbox_r <= {11'd0, w_r} * {11'd0, h_r};
            state  <= S_D_INS;
        end

        S_D_INS: begin
            if (d_reject && (dbg_reject != 12'hFFF))
                dbg_reject <= dbg_reject + 12'd1;

            if (d_accept) begin
                if (nfound != 8'hFF) nfound <= nfound + 8'd1;

                // Slot 0 is handled OUTSIDE the loop and the loop starts at 1.
                // That is not tidying -- it is what keeps `j-1` in range.
                //
                // gt_prev[0] is hardwired 0, so slot 0 can only ever take the
                // new entry; the shift-down arm is unreachable there.  But TD's
                // elaborator does not do that reachability analysis: with the
                // loop starting at 0 the unrolled source still contains
                // top_area[-1] and synthesis stops with
                //   HDL-8007 ERROR: index -1 is out of range [0:7] for 'top_area'
                // iverilog returns x for an out-of-range read instead, and since
                // the branch never executes, every dtb.v check still passed --
                // so this only surfaced in TD.  Splitting the first slot out
                // means no negative index exists in the source at all.
                if (gt[0]) begin
                    top_area[0] <= frec_q[63:44];
                    top_x0[0]   <= frec_q[43:33];
                    top_x1[0]   <= frec_q[32:22];
                    top_y0[0]   <= frec_q[21:11];
                    top_y1[0]   <= frec_q[10:0];
                end

                for (j = 1; j < NBLOB; j = j + 1) begin
                    if (gt[j]) begin
                        if (!gt_prev[j]) begin
                            top_area[j] <= frec_q[63:44];
                            top_x0[j]   <= frec_q[43:33];
                            top_x1[j]   <= frec_q[32:22];
                            top_y0[j]   <= frec_q[21:11];
                            top_y1[j]   <= frec_q[10:0];
                        end else begin
                            top_area[j] <= top_area[j-1];
                            top_x0[j]   <= top_x0[j-1];
                            top_x1[j]   <= top_x1[j-1];
                            top_y0[j]   <= top_y0[j-1];
                            top_y1[j]   <= top_y1[j-1];
                        end
                    end
                end
            end
            i     <= i + 12'd1;
            state <= S_D_RD;
        end

        //----------------------------------------------------------------
        // PASS E -- one candidate pair per clock.  See [9b].
        //
        // The union goes into e_a (the lower slot, so a sweep that has
        // already passed e_a cannot leave a merged box behind it unexamined)
        // and e_b's area is zeroed, which is what makes it invalid.  e_b's
        // coordinates are left alone deliberately: S_PUB writes all geometry
        // unconditionally, and an invalid slot's coordinates are never read.
        //----------------------------------------------------------------
        S_E_CK: begin
            if (e_hit) begin
                top_x0[e_a]   <= (ea_x0 < eb_x0) ? top_x0[e_a] : top_x0[e_b];
                top_x1[e_a]   <= (ea_x1 > eb_x1) ? top_x1[e_a] : top_x1[e_b];
                top_y0[e_a]   <= (ea_y0 < eb_y0) ? top_y0[e_a] : top_y0[e_b];
                top_y1[e_a]   <= (ea_y1 > eb_y1) ? top_y1[e_a] : top_y1[e_b];
                top_area[e_a] <= e_sum[20] ? AREA_MAX : e_sum[19:0];
                top_area[e_b] <= 20'd0;
            end

            // Plain nested counters rather than "restart on change": the
            // sweep is 64 clocks and the whole of pass E is 128, against
            // ~18,000 spare in blanking, so there is nothing to win by
            // converging early and a fixed count cannot fail to terminate.
            if (e_b == (NBLOB - 1)) begin
                if (e_a >= (NBLOB - 2)) begin
                    if (e_round >= (BOX_ROUNDS - 1)) state <= S_PUB;
                    else begin
                        e_round <= e_round + 3'd1;
                        e_a     <= 4'd0;
                        e_b     <= 4'd1;
                    end
                end else begin
                    e_a <= e_a + 4'd1;
                    e_b <= e_a + 4'd2;
                end
            end else
                e_b <= e_b + 4'd1;
        end

        S_PUB: begin
            for (j = 0; j < NBLOB; j = j + 1) begin
                blob_x0[j*12 +: 12] <= {1'b0, top_x0[j]};
                blob_x1[j*12 +: 12] <= {1'b0, top_x1[j]};
                blob_y0[j*12 +: 12] <= {1'b0, top_y0[j]};
                blob_y1[j*12 +: 12] <= {1'b0, top_y1[j]};
                // ovf_bad trims the publish to blob 0 -- see OVF_TRIM.  The
                // GEOMETRY is written unconditionally so that a later frame
                // which re-validates a slot does not show one frame of stale
                // coordinates before its own numbers land.
                blob_valid[j]       <= (top_area[j] != 20'd0)
                                     & (ovf_bad ? (j == 0) : 1'b1);
            end
            blob_count <= nfound;
            stale_n    <= 2'd0;
            state      <= S_IDLE;
        end

        default: state <= S_IDLE;

        endcase

        //----------------------------------------------------------------
        // THE ABORT HAS TO BE LAST.
        //
        // A frame boundary with the passes still running means they did not
        // fit in blanking.  Drop them: the previous frame's boxes stay
        // published and ovf_time says the reading is stale.
        //
        // ⚠ THIS USED TO LIVE IN THE frame_start BLOCK ABOVE, WHERE IT WAS
        // DEAD CODE.  Both are non-blocking assignments to `state` in ONE
        // procedural block, so the last one executed wins -- and every
        // non-idle arm of the case above assigns `state`.  The abort therefore
        // did nothing in precisely the situation it exists for, while looking
        // correct and while ovf_time still went high.  It is the same ordering
        // rule the S_IDLE arm's comment relies on to make the startd handoff
        // work, pointed the other way.
        //
        // What that cost, if it ever fired: fsm_run stays high into the new
        // frame, so the port muxes at [7] and [8] keep the pass side connected
        // and BOTH of the scan's write paths are silently discarded --
        // parent[i] = i is never written for the new frame (its 2048-clock
        // init window passes with par_we following par_we_r) and the new
        // frame's feature records never land.  The frame after an overrun then
        // labels a fresh picture against the previous frame's flattened
        // forest, which comes out as unrelated objects merged into one target.
        // Two frames of wrong boxes, then it heals -- so on a bench it reads
        // as an intermittent glitch rather than as a bug.
        //
        // Safe here: frame_start is the RISING edge of vs and the startd
        // countdown runs from the FALLING edge plus eight, so the two can
        // never assign `state` on the same clock.
        //----------------------------------------------------------------
        if (frame_start && (state != S_IDLE)) begin
            ovf_time <= 1'b1;
            state    <= S_IDLE;

            // A SUSTAINED overrun must not keep showing the last good boxes
            // -- that is what "a box stayed on screen after the object left"
            // is.  Hold for STALE_HOLD frames, then blank.  stale_n is left
            // at the rail afterwards: nothing republishes while the passes
            // keep overrunning, so blob_valid simply stays clear until an
            // S_PUB resets the counter.
            if (stale_n >= STALE_HOLD) blob_valid <= {NBLOB{1'b0}};
            else                       stale_n    <= stale_n + 2'd1;
        end
    end
end

//========================================================================
// [10] MASK PASS-THROUGH + per-pixel box membership (MASK_EN, 2026-10-09)
//
// Ported from the teammate's Anlogic7 ccl_blob.  Two clocks: NBLOB x 4
// coordinate compares, then AND with blob_valid -- the only pixel-domain
// logic this adds, so it is split in two.
//
// ⚠ ONE FRAME LATE: blob_* is published in frame N's blanking and held all
// of frame N+1, so out_inbox is "frame N's boxes" over "frame N+1's mask".
//========================================================================
generate if (MASK_EN != 0) begin : g_mask
    integer bj;   // not j: j belongs to [9]'s always block

    wire [12:0] mk_x = {1'b0, in_px} + MASK_SHIFT;
    wire [12:0] mk_y = {1'b0, in_py} + MASK_SHIFT;

    reg [NBLOB-1:0] xin_r, yin_r;
    reg             mk_vs1, mk_de1, mk_m1;
    reg [11:0]      mk_px1, mk_py1;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            xin_r  <= {NBLOB{1'b0}}; yin_r  <= {NBLOB{1'b0}};
            mk_vs1 <= 1'b0; mk_de1 <= 1'b0; mk_m1 <= 1'b0;
            mk_px1 <= 12'd0; mk_py1 <= 12'd0;
            out_vs <= 1'b0; out_de <= 1'b0; out_mask <= 1'b0;
            out_px <= 12'd0; out_py <= 12'd0;
            out_inbox <= {NBLOB{1'b0}};
        end else begin
            mk_vs1 <= in_vs;
            mk_de1 <= in_de;
            mk_m1  <= in_mask & in_de;
            mk_px1 <= mk_x[11:0];
            mk_py1 <= mk_y[11:0];
            for (bj = 0; bj < NBLOB; bj = bj + 1) begin
                xin_r[bj] <= (mk_x >= {1'b0, blob_x0[bj*12 +: 12]})
                          && (mk_x <= {1'b0, blob_x1[bj*12 +: 12]});
                yin_r[bj] <= (mk_y >= {1'b0, blob_y0[bj*12 +: 12]})
                          && (mk_y <= {1'b0, blob_y1[bj*12 +: 12]});
            end

            out_vs    <= mk_vs1;
            out_de    <= mk_de1;
            out_mask  <= mk_m1;
            out_px    <= mk_px1;
            out_py    <= mk_py1;
            out_inbox <= xin_r & yin_r & blob_valid & {NBLOB{mk_de1}};
        end
    end
end else begin : g_nomask
    always @(posedge clk) begin
        out_vs <= 1'b0; out_de <= 1'b0; out_mask <= 1'b0;
        out_px <= 12'd0; out_py <= 12'd0; out_inbox <= {NBLOB{1'b0}};
    end
end endgenerate

endmodule
