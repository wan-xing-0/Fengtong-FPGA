//---------------------------------------------------------------------------
// motion_frame_drawer -- block-level frame differencing, drawn as a bounding
// box around whatever moved.
//
// Ported from the competition project's motion_frame_drawer v2.1 (RGB565,
// 1280x720).  That file records a long retreat: v3.1's counter array caused
// what its author called catastrophic SSO, v2.2/v2.3 left signal-integrity
// residue on screen, and v2.4's placement "landed on garbage" and corrupted
// the top half of the picture.  v2.1 -- 256x32 blocks, five partial sums, a
// 2-bit sticky counter per block -- was the stable point they stopped at, at
// the cost of only five columns horizontally, too coarse to see a moving arm.
//
// WHAT CHANGED IN THE PORT
//
//   Block geometry.  256x32 does not tile 1920x1080: 1920/256 = 7.5 and
//   1080/32 = 33.75, so the right 128 columns and the bottom 24 rows would
//   never reach block_last and would sit permanently dead.  1080 has no
//   power-of-two factor above 8, so no power-of-two block tiles it either.
//   This uses 128x72 -- 15 x 15 blocks, exact in both directions, and 128:72
//   is 16:9 so the cells are the same shape as the screen.  y_tile comes from
//   a divide-by-72 counter rather than a bit slice; x_tile is still px[10:7].
//
//   Block area is no longer a power of two (9216, not 8192), so the >>13 that
//   used to be an exact divide is only a scaling now.  That is fine -- the
//   average is never compared against anything but the same block's average
//   from the previous frame -- but it does shift what MOTION_THRESH means.
//
//   The sticky counters moved into the same block RAM as the reference level,
//   as {counter, reference} -- 6 bits per block then, 13 now that the
//   reference is a fractional background model (2026-09-08, see below).  The
//   original kept the counters in 23 explicit row registers behind a 23-to-1
//   mux; at this grid that would be 15 rows of 30 bits -- 450 flops and a
//   30-bit 15-way mux -- which is the same structure whose earlier revision
//   the source blames for its worst SSO event.  One 256-entry RAM does the job
//   through a read port that the reference needs anyway.
//
//   RGB888 throughout: luma is (R+G+B)[9:6] instead of (r5+g6/2+b5)[6:3],
//   which lands on the same 0..11 range.
//
// 2026-08-10: BOX INSTEAD OF TINT
//   The first bench test came back with "your motion detection is doing edge
//   detection -- make it a box round the moving part instead".  It was not
//   doing edge detection; that is what block differencing looks like.  A
//   uniform object sliding across the frame barely changes the mean of the
//   blocks it is *inside* -- only the blocks straddling its outline see their
//   average move -- so tinting the blocks that changed paints the outline.
//
//   Every tinted block is thrown away now.  Instead the blocks whose sticky
//   counter is non-zero are reduced, as the frame streams past, to the min
//   and max of their tile indices.  At the end of the frame that is the
//   bounding box of everything moving, and the next frame draws it as a
//   rectangle.  Four 4-bit registers and a comparator, no RAM, no second
//   pass: the blocks are already visited in raster order.
//
//   The box is inherently one frame behind -- the bottom-right block does not
//   finish until the last pixel of the frame -- which is the same 16ms lag
//   the sticky counters already carry and is not visible.
//
//   Two guards keep it from twitching.  MIN_BLOCKS ignores a frame in which
//   only one or two blocks moved, so a lone false block in a corner cannot
//   stretch the box across the screen.  HOLD_FRAMES keeps the last good box
//   on screen for half a second after motion stops, instead of blinking out
//   between two waves of a hand.  The 3-frame sticky counter is doing the
//   short-term smoothing, so no extra temporal filter is needed on top.
//
//   The red-object exclusion the tint carried is gone with it.  It existed so
//   the tint would not fight color_replace over the same pixels; a box drawn
//   on the outline of the picture has no such conflict.
//
//===========================================================================
// 2026-09-08: THE REFERENCE IS A BACKGROUND MODEL, NOT THE PREVIOUS FRAME
//===========================================================================
// Bench: "fast motion is fine, but slow motion leaves the box behind."  Both
// halves of that have the same cause and it is not a threshold.
//
// FRAME DIFFERENCING IS A HIGH-PASS FILTER, and it was being asked to see a
// low-frequency signal.  Work the numbers for a hand crossing one 128px block
// in one second at 60fps: 2.1 px per frame, 1.6% of the block width, so even
// against a full-contrast background the block mean moves 0.8% of the luma
// range per frame.  The old block average was FOUR BITS over a 0..12 luma
// range, where one count is 7.4% -- so the entire signal sat an order of
// magnitude below the quantiser, and MOTION_THRESH could have been zero
// without helping.  Nothing crossed the line, so no frame was believed.
//
// The lingering box is the second half of the same fact.  HOLD_FRAMES exists
// so the box does not blink between two waves of a hand, but it is RELOADED
// on every believed frame -- so a slow gesture that scrapes past MIN_BLOCKS
// once every ten frames keeps resetting the hold and the box freezes wherever
// it was last measured while the object walks away from it.  The 09-08 photo
// showed exactly that: "MOTION: 0 BLK" with a green box still on screen.
//
// TWO CHANGES, BOTH NECESSARY, NEITHER SUFFICIENT ALONE:
//
//   RESOLUTION.  blk_avg_now is now blk_sum_final[16:11], six bits over 0..49,
//   so one count is 2% of the luma range instead of 7.4%.
//
//   TIME BASE.  The stored reference is no longer last frame's average but an
//   IIR background, bg += (cur - bg) >> BG_SHIFT, tau = 16 frames = 0.27s.
//   Against a ramp an IIR settles to a CONSTANT LAG of slope x tau, so the
//   1s-per-block gesture above now reads 6.6 counts of separation instead of
//   0.1 -- comfortably over MOTION_THRESH -- and it reads it on EVERY frame,
//   which is what stops the hold from freezing.  Fast motion outruns the
//   filter completely and trips as it always did.
//
//   Doing only one of the two gets nowhere: at 4-bit resolution a 16-frame lag
//   is still under one count, and at 6-bit resolution a one-frame reference is
//   still under one count.
//
// WHY AN IIR AND NOT "REFRESH THE REFERENCE EVERY N FRAMES".  Decimating the
// refresh gives the same lag for a couple of gates less, but the difference
// collapses to zero on the refresh frame and has to climb again, so a block
// goes dead for a stretch of every period and the box stutters.  The IIR has
// no such discontinuity -- the lag is constant, which is the whole point.
//
// WHY IT DOES NOT CHASE MAINS FLICKER.  The residue the loop cannot remove is
// a slope, and 50Hz flicker is a bounded oscillation, not a slope: it shows up
// as about a count of wobble against a threshold of five.
//
// THE WRITE IS PIPELINED ONE STAGE.  The subtract and the add cannot both sit
// in front of the RAM write port on a clock group that closes at +0.058ns, so
// the error is computed on one clock and applied on the next.  Free, because
// the block just written is not read again until the next frame -- and the
// read that lands in between is the NEXT block's address, never this one's.
//
// SEEDING.  The state array has no reset (block RAM), so bg starts at whatever
// was in it and the first frames would read as whole-frame motion for as long
// as the IIR took to converge -- 30-odd frames rather than the single frame
// the old absolute overwrite cost.  bg_seed loads bg = cur directly for the
// first two frames and forces the sticky counters to zero while it does, so
// power-up is silent instead of flashing a full-frame box.
//
// LATENCY 2 clocks: one for the RAM read, one for the output register.
// Unchanged -- none of the above is on the picture path.
//---------------------------------------------------------------------------

`timescale 1ns/1ns

//===========================================================================
// 2026-09-20: TWO THINGS THE DETECTOR KNEW AND WAS THROWING AWAY
//===========================================================================
// Both of the round's bench complaints turn out to be about information the
// module already had, not about anything it measured wrongly, and neither is
// a threshold.
//
// (1) "AN OBJECT SLOWING TO A STOP ENDS WITH A BOX MUCH SMALLER THAN IT IS."
//     The IIR separation is proportional to speed, so deceleration walks the
//     moving-block set down to a couple of cells, and the hold then freezes
//     the LAST believed frame -- necessarily the smallest and most fragmented
//     of the gesture.  SIZE_FLOOR keeps the largest span the dominant box
//     reached during the burst and grows the published box back out to it
//     about its CURRENT centre.  Growing about the centre is what keeps this
//     from re-creating the box-around-the-whole-path failure that a longer
//     sticky counter would.
//
// (2) "SHAKE THE CAMERA AND THE WHOLE PICTURE GETS BOXED."  Not a false
//     positive -- when the view moves, every textured block really does leave
//     its own background.  What is wrong is treating it as an object.  It is
//     separable by COUNT (a gesture is 20-40 blocks of 225, a pan is 150+),
//     so MAX_BLOCKS vetoes the frame outright, and md_inhibit lets a pan-tilt
//     controller say so in advance.
//
//     ⚠ THE HALF OF (2) THAT IS EASY TO MISS: vetoing the frame is not
//     enough.  After the view changes, all 225 stored backgrounds describe
//     the wrong part of the world and the IIR needs 2^BG_SHIFT = 16 frames to
//     forget them, so a detector that merely stops looking during the pan
//     comes back to a full-screen box that then smears over a quarter of a
//     second.  Both paths therefore RE-SEED the background -- the mechanism
//     that already existed for power-up -- which cuts recovery to 2 frames.
//     That is the difference between a step-and-look tracking loop that works
//     and one that is blind after every step.
//
// Neither change touches the measurement: MOTION_THRESH, BG_SHIFT, the sticky
// counters, the spatial guard and the clustering are all exactly as they were
// on 09-19.  (1) resizes a published box, (2) decides whether the frame is
// published at all.
//===========================================================================

module motion_frame_drawer #(
parameter integer IMG_HDISP = 1920,
parameter integer IMG_VDISP = 1080,
parameter integer BLK_W     = 128,     // px[10:7] indexes this; keep it a power of two
parameter integer BLK_H     = 72,      // counted, so it need not be a power of two
parameter integer N_COLS    = 15,      // IMG_HDISP / BLK_W

// Separation between the block's current average and its background model
// that counts as motion, in units of the SIX-BIT average (0..49 over the 0..11
// luma range), so one count is 2% of that range.
//
// 4 means a block has to be >=5 counts, ~10%, clear of its own background.
// Against the 16-frame IIR that is reached by anything crossing a block in
// about a second or faster, and is several times the wobble mains flicker
// puts on a block mean.
//
// HISTORY, so nobody re-runs it: this was 4'd1, then 4'd2 (08-12), against a
// FOUR-bit average and the PREVIOUS FRAME.  Both of those numbers are dead --
// the units changed twice over.  Do not port a value across from an older
// revision of this file or from the competition project.
parameter [5:0]  MOTION_THRESH = 6'd4,

// log2 of the IIR time constant, in frames.  4 = 16 frames = 0.27s at 60Hz.
//
// This is the real sensitivity knob now: the separation an IIR reaches against
// a steadily moving object is (counts per frame) x 2^BG_SHIFT, so raising it
// by one doubles the reach into slower motion AND doubles how long the box
// hangs on after the object stops.  5 (0.53s) is the step if genuinely
// creeping targets have to register; 3 (0.13s) if the tail is too long.
parameter integer BG_SHIFT = 4,

//------------------------------------------------------------------------
// PER-BLOCK ADAPTIVE THRESHOLD -- 2026-09-21 night.  Each block keeps its
// own noise estimate and its threshold becomes
//
//     max(MOTION_THRESH, measured_noise << NOISE_GAIN)
//
// ⚠ WHY A GLOBAL THRESHOLD CANNOT WORK, which is the argument for spending
// RAM bits on this: block noise is not uniform across the frame and never
// could be.  A flat wall's block average is stable to a fraction of a count;
// a block full of bookshelf edges or a window with trees behind it swings by
// several counts with no object anywhere near it, because sensor noise on
// high-contrast texture moves the average around.  ONE threshold has to be
// above the textured blocks' noise or below the flat blocks' signal -- it
// cannot be both, and at 4 it is below the textured blocks' noise.
//
// THAT IS WHAT THE BOARD PHOTO WITH TWO BOXES ON CEILING LIGHTS AND NONE ON
// THE PERSON IS.  MOTION 13 BLK, boxes on a light fitting and a column edge,
// nothing on the human being in the frame.  The lights and the column are
// the highest-contrast things in the room, so they are the noisiest blocks,
// so a global 4 fires there first.  No amount of tuning the single number
// fixes it: raising it kills the person before it kills the lights.
//
// This is the classic Sigma-Delta background estimator, and it is here
// rather than something cleverer because it costs a shift and a compare.
//
// NOISE_GAIN = 1 means "twice the measured noise".  A Gaussian sits inside
// 2x its mean absolute deviation about 95% of the time, so 1 is the value
// that makes the false-positive rate per block small without being
// conservative; 2 (four times) is the step if textured blocks still fire.
//
// 0 makes the threshold the noise itself, which is NOT a disable -- it would
// fire on half of all quiet frames.  Use NOISE_EN for that.
parameter integer NOISE_GAIN = 1,

// How far nz may move in ONE frame, in nz LSBs.  NZF = 4, so 1 LSB is a
// sixteenth of a count and the default takes 16 frames to move the estimate
// by a single count.
//
// ⚠ THE ±STEP IS NOT AN IMPLEMENTATION DETAIL OF AN IIR -- IT IS WHAT MAKES
// THIS SAFE, and the first version of this parameter got it wrong.  That
// version ran a normal IIR on the error and, because an IIR would be dragged
// upwards by a real object sitting in the block, gated it to only learn on
// frames where the block did NOT read moved.
//
// THAT GATE IS UNIMPLEMENTABLE-IN-PRINCIPLE, which is worth writing down
// because it looked obviously right: a block whose own noise EXCEEDS the
// threshold reads moved on every frame, so the gate would never open, so the
// block could never learn to stop firing -- and a block that fires every
// frame on its own noise is the entire population this feature exists to
// suppress.  The gate makes the mechanism blind to its own purpose.
//
// A bounded ±step needs no gate at all.  One frame of a real object moves nz
// by 1/16 of a count whatever the object's contrast is, so outliers cannot
// drag it; a block that jitters EVERY frame moves it every frame and
// converges.  This is the standard robust form (Manzanera-Richefeu) and the
// reason it is stepwise rather than proportional.
//
// COST, STATED HONESTLY: an object that sits in ONE block with sustained
// contrast will slowly raise that block's nz -- at the default, 80 frames
// (1.3s) to climb 5 counts.  Someone waving in place could partially
// suppress the block they wave in.  The blocks around them are unaffected
// and MIN_BLOCKS only needs three, so the object does not vanish; and the
// alternative design cannot suppress noise at all.  If sustained in-place
// motion ever becomes the complaint, lower this rather than re-adding a gate.
parameter integer NZ_STEP = 1,

// 0 disables: the threshold is MOTION_THRESH everywhere, bit-exactly as
// before 2026-09-21, and nz_next folds to a constant so the tool drops the
// stored field. Keeps the A/B to one parameter.
parameter integer NOISE_EN = 1,

//------------------------------------------------------------------------
// GLOBAL MOTION COMPENSATION -- 2026-09-21 night.  Estimate how far the
// whole frame translated since the last one, and compare each block against
// the background of WHERE THAT CONTENT WAS rather than of where it is now.
//
// ⚠⚠ THIS IS THE ONLY MECHANISM IN THIS FILE THAT ADDRESSES CAMERA MOTION
// AT ITS CAUSE, and the reason it is worth a whole estimator is that the
// alternatives are provably insufficient, not merely mistuned:
//
//   MAX_BLOCKS counts blocks.  A flat room panned lights a quarter of the
//     grid (47-81 measured); a cluttered room panned lights nearly all of
//     it; a hand gesture lights 20-40.  The pan and the gesture ranges
//     OVERLAP and which one a frame falls in depends on the SCENE's texture,
//     not on what moved.  No threshold separates overlapping distributions.
//   BOX_FILL_SHIFT measures dispersion, which is scene-independent and was
//     the right idea -- but it works by DELETING boxes, and it deleted real
//     objects (see its comment).  A test that can only subtract cannot make
//     a detector work during camera motion; it can only make it quiet.
//
// Compensation is different in kind: it makes the frame差 MEANINGFUL during
// a pan instead of suppressing it.  A block that matches its displaced
// background reads quiet; only genuinely independent motion survives.  That
// is what "跟踪时仍能检测" requires, and nothing built from thresholds on
// block counts can deliver it.
//
// HOW, AND WHY IT IS THIS CHEAP.  The estimate comes from PROJECTIONS: the
// 15 column sums and 15 row sums of the block averages this module already
// computes.  Two 15-element signals per frame, correlated against the
// previous frame's at offsets -2..+2 blocks, argmin of a sum of absolute
// differences.  Projections turn a 2-D search into two 1-D searches, which
// is what makes the whole thing 55 clocks of blanking and no multiplier.
//
// ⚠ AND THE COMPENSATION ITSELF COSTS NO COPY.  The obvious implementation
// shifts all 225 stored backgrounds, which needs a read-modify-write pass
// with memmove-style direction ordering.  Instead the SHIFT IS APPLIED TO
// THE READ ADDRESS: block (x,y) reads the model at (x-dx, y-dy) and writes
// its update back to (x,y).  That is not a trick to save clocks -- it is
// also more correct, because after the pan block (x,y) genuinely does hold
// the content that was at (x-dx, y-dy), so its model should continue that
// history.  One clamped subtract per axis, no pass, no ordering hazard.
//
// ⚠⚠ THE COST IS THAT THOSE TWO SUBTRACTS ARE IN THE PIXEL DOMAIN, on the
// mstate READ ADDRESS.  Everything else added to this module in 09-21 is
// block-level or blanking-level and cannot affect clk0.  This can.  The
// handoff records clk0 at +0.034ns with the worst path in det_binarize, so
// the margin for a 4-bit subtract and a clamp is thin but the path is not
// the critical one; re-run P&R and check where worst lands.
//
// GRANULARITY, STATED PLAINLY: the estimate is in whole BLOCKS, so 128 px
// horizontally and 72 px vertically.  A slow pan that moves the image 30 px
// between frames estimates as 0 and is not compensated at all.  This helps
// the fast pans that light the whole grid; it does not help creep.  ±2
// blocks is ±256 px per frame, which at 60 Hz is a very fast pan already.
//
// ⚠ DEFAULT IS 0 -- OFF -- AND THAT IS A DEPLOYMENT DECISION, NOT DOUBT
// ABOUT THE CODE.  Three other mechanisms went into this module today and
// only one of them (PERSIST) has been on the board.  Turning on a fourth in
// the same burn, and the one that touches the pixel-domain address path,
// would make the next set of photos uninterpretable -- which is the exact
// mistake BOX_FILL_SHIFT's comment records from this morning.  Burn the
// block-level work first, read the photos, then set this to 1 on its own.
parameter integer GMC_EN = 0,

// Rejection margin for the correlation, in projection LSBs.  A nonzero
// offset is only believed if its SAD beats the zero-offset SAD by this much.
//
// WITHOUT IT THE ESTIMATE JITTERS AND JITTER IS WORSE THAN NO ESTIMATE: on a
// static scene the five SADs differ only by noise, argmin picks a random
// nonzero offset, and the whole model is then read one block sideways --
// which makes every block compare against its NEIGHBOUR's background and
// lights up the entire textured part of the frame.  The failure mode of a
// bad estimate is far worse than the failure mode of no estimate, so the
// test is deliberately biased towards believing nothing happened.
parameter integer GMC_MARGIN = 96,

//------------------------------------------------------------------------
// TEMPORAL PERSISTENCE -- 2026-09-21 evening.  A block must have been moving
// for PERSIST frames before it counts towards a cluster.
//
// ⚠ WHY THIS IS DIFFERENT IN KIND FROM EVERY OTHER GATE IN THIS FILE, and
// the reason it is worth adding a fifth one: MIN_BLOCKS, MIN_BOX_BLK,
// DOM_SHIFT, MAX_BLOCKS and BOX_FILL_SHIFT are ALL SINGLE-FRAME SPATIAL
// TESTS.  Not one of them asks whether anything was in this place a frame
// ago.  Three rounds of board photos have now been answered by tightening
// spatial thresholds, and each time the same trade came back: tight enough
// to kill the false boxes was tight enough to kill real objects, because a
// noise cluster and a small real object ARE THE SAME SHAPE AND SIZE.
//
// They are not the same shape IN TIME.  A speckle cluster is an excursion of
// one block's mean that returns to the background on the next frame.  An
// intruder stays.  That is a separation with real margin in it, and it is
// the one axis this module was not using.
//
// WHAT CHANGES.  The per-block counter already in mstate stops being a
// one-shot reload and becomes a SATURATING UP/DOWN counter:
//
//     PERSIST = 0   moved -> 3, else decay.  Active when non-zero.
//                   EXACTLY the behaviour of every build up to 09-21.
//     PERSIST != 0  moved -> +1 (sat 3), else -1 (sat 0).
//                   Active when the count has reached PERSIST.
//
// Two bits either way, so mstate keeps its 13-bit width and its RAM
// inference, its timing and the 315-RAM resource baseline are untouched.
//
// 2 IS THE DEFAULT AND IT COSTS ONE FRAME OF LATENCY (17ms), which is
// nothing against a person walking and nothing against a servo that needs
// 100ms to move.  It is NOT a half-second smoothing filter and must not grow
// into one -- 3 is the maximum the counter can express and it is there for
// an A/B, not as a recommendation.
//
// ⚠ THE DECAY IS -1, NOT A RESET TO 0, AND THAT MATTERS MORE THAN THE
// THRESHOLD.  A real object routinely fails to light a block for one frame
// (its own interior matches itself, so only its edges register).  A reset
// would drop the block back to unarmed on every such frame and the filter
// would eat exactly the large slow objects it is supposed to keep.  With -1,
// a saturated block survives a single-frame dropout with one to spare.
//
// ⚠ AND WHY A FAST GESTURE IS NOT LOST, which was the first objection to
// this: `moved` compares against the IIR BACKGROUND, not the previous frame.
// A block whose content changes stays different from a background that
// closes only 1/16 of the gap per frame, so it reads moved for many frames
// after the change -- the counter arms on the object's arrival alone and
// does not need it to still be there.  The blocks a fast hand merely passes
// over register on arrival AND on departure for the same reason.
//
// INTERACTION WITH THE CAMERA-MOTION RE-SEED: none needed, and this is worth
// knowing before someone adds some.  A pan lights every block and would ramp
// every counter to 3, which would carpet the first settled frame with armed
// blocks -- except that bg_seed forces new_cnt to 0, md_blind reloads
// seed_cnt every blind frame, and so the counters are already cleared for
// two frames after the camera stops.  The existing recovery covers this one.
//
// 0 DISABLES, restoring the pre-09-21 counter bit for bit.
//------------------------------------------------------------------------
parameter integer PERSIST = 2,

// Box appearance.
parameter [7:0]   BOX_R     = 8'd0,
parameter [7:0]   BOX_G     = 8'd255,
parameter [7:0]   BOX_B     = 8'd0,
parameter integer BOX_THICK = 6,       // line width in pixels

// A frame has to move at least this many blocks before its box is believed.
// 2 -> 3 on 08-12 against isolated false triggers.
parameter [7:0]  MIN_BLOCKS  = 8'd3,

//------------------------------------------------------------------------
// GLOBAL-MOTION VETO -- 2026-09-20.  A frame that moves MORE than this many
// blocks is the CAMERA moving, not an object, and nothing in it is believed.
//
// The bench complaint is "shake the camera and the whole picture gets boxed",
// and it is not a false positive: when the camera pans, every textured block
// in the frame really does see its average leave its own background, so the
// detector is reporting exactly what happened.  What is wrong is the
// INTERPRETATION -- this module exists to find things that move against a
// fixed view, and a moving view invalidates the entire measurement rather
// than adding a big object to it.
//
// The two cases are cleanly separable by COUNT, which is why this is a
// threshold and not something cleverer.  This module's own record puts a real
// hand gesture at 20-40 blocks of 225 (see DOM_SHIFT); a pan lights every
// block with any texture in it, which on a real scene is 150-225.  90 blocks
// is 40% of the grid: more than twice the largest genuine gesture measured so
// far, and far below anything a pan produces.
//
// WHAT HAPPENS ON A VETO, and why it is not just "skip the frame":
//   - the published table is CLEARED, not held.  HOLD_FRAMES exists to bridge
//     gaps in a gesture; there is no gesture here, and holding the last box
//     across a pan is precisely the "box parked on empty picture" failure.
//   - the background is RE-SEEDED (see md_inhibit).  This is the part that is
//     easy to miss: after the view moves, every stored bg belongs to a
//     different piece of the world, and the IIR needs 2^BG_SHIFT = 16 frames
//     to forget it.  Without the re-seed, vetoing the pan frames only defers
//     the full-screen box to the first frame after the pan and then smears it
//     over a quarter of a second.
//
// So a pan costs 1 vetoed frame + 2 seeding frames = 3 frames (50ms) of
// blindness, and detection comes back CLEAN rather than converging.
//
// 8'd255 DISABLES the veto: tot_n saturates at 255, so "> 255" is never true.
// That is the A/B against the 09-19 behaviour, and it is the reason the
// disable value is not 0.
//
// ⚠ IF A GENUINE OBJECT IS EVER VETOED it will show as a large moved_blocks
// reading on the OSD with no box drawn -- that pair is the diagnostic, and it
// says raise this, not that the detector broke.
//
//===========================================================================
// ⚠⚠ 2026-09-21, MEASURED ON THE BOARD: THIS TEST CANNOT BE THE PRIMARY ONE,
// AND THE ARGUMENT ABOVE FOR 90 IS WRONG.  Kept, because it is exactly half
// of a working answer -- see BOX_FILL_SHIFT for the other half.
//
// The 09-20 build went on the board and the OSD was photographed while the
// camera was shaken and while it was panned to follow a walking person.  The
// moved-block readings were 19, 47, 48, 62, 64, 65, 73, 74, 81 -- EVERY ONE
// BELOW 90.  The veto never fired once, which is why that build changed
// nothing about the complaint.
//
// The prediction that a pan lights 150-225 blocks assumed every block has
// texture in it.  THE BLOCK MEAN ONLY MOVES WHERE THERE IS AN EDGE: a flat
// wall, ceiling or desk translated by a few pixels has the same mean it had
// before, so a pan lights only the textured fraction of the grid, and in the
// room those photos were taken in that fraction is a quarter to a third.
//
// SO THE COUNT DEPENDS ON THE SCENE, NOT ON WHAT MOVED, and it puts a pan in
// a flat room (47-81) inside the range this module already documents for a
// hand gesture (20-40).  Two overlapping ranges cannot be separated by a
// threshold between them, at any value -- lowering 90 would start vetoing
// gestures long before it caught these frames.
//
// WHAT IT IS STILL GOOD FOR.  In a CLUTTERED scene the same pan lights
// nearly every block, and that is the case BOX_FILL_SHIFT cannot see (the
// moving blocks are dense as well as everywhere, so the box is full and the
// density test passes it).  The two tests fail on opposite scenes and neither
// is redundant:
//
//     flat scene, pan  -> few blocks, spread out  -> BOX_FILL_SHIFT catches
//     busy scene, pan  -> many blocks, dense      -> MAX_BLOCKS catches
//
// 90 stays because it is above every real-object count measured so far and
// below a whole-grid response.  It is a BACKSTOP now, not the mechanism.
//
// ⚠ 2026-09-21 EVENING: 90 -> 64, BECAUSE A BACKSTOP AT 90 NEVER TOUCHES
// ANYTHING.  A second board round, this time with the gap fixed so the boxes
// are honest, produced a frame reading 83 BLK drawn as a GREEN BORDER AROUND
// THE ENTIRE PANEL, and another at 79 BLK tiled with four boxes.  Both are
// whole-grid responses to a shaken camera and both walked straight under 90 --
// the same way every reading in the 09-20 round did.  A threshold no measured
// failure has ever reached is not a backstop, it is decoration.
//
// WHY 64 AND NOT LOWER.  64 of 225 is 28% of the grid.  The measured bands:
//
//     hand gesture, static camera     20-40   must survive -- the product
//     person walking, static camera   ~13-45  must survive
//     pan in a flat room              47-81   the ones being caught
//     shake producing a full border   79-83   the ones being caught
//
// 64 is above both "must survive" bands and below both "catch" bands, with
// the nearest real reading (45) a third of the way clear.  It is still a
// BACKSTOP -- the 45-block frame in that same round drew five boxes and this
// does not touch it; DOM_SHIFT is what answers that one.
//
// ⚠ AND IT STILL CANNOT SEPARATE THE TWO IN PRINCIPLE.  The bands above
// overlap once the scene changes -- a cluttered pan lights nearly everything
// and a flat pan lights a quarter -- so this number is calibrated to ONE
// room's texture.  Do not read a future failure at, say, 55 blocks as "64 is
// wrong"; read it as the count axis being the wrong axis, which is what the
// long comment above already concluded.
//===========================================================================
parameter [7:0]  MAX_BLOCKS  = 8'd64,

//------------------------------------------------------------------------
// BOX DENSITY -- 2026-09-21.  A published box must be at least
// (its own area >> BOX_FILL_SHIFT) moving blocks, or it is not an object.
//
// THIS IS THE PRIMARY CAMERA-MOTION TEST, and the reason it works where
// MAX_BLOCKS does not is that it measures a property of the MOTION rather
// than of the scene:
//
//     CAMERA MOTION IS DISPERSED.  Every textured patch in the frame moves,
//     wherever it happens to be, so the moving blocks are scattered from
//     corner to corner and the box that encloses them is mostly empty.
//
//     OBJECT MOTION IS COMPACT.  One thing moved, in one place, so the
//     blocks it lights are a connected clump and the box that encloses them
//     is mostly full.
//
// Neither statement mentions how many blocks there are, which is exactly the
// quantity the board measurements showed to be scene-dependent.
//
// THE NUMBERS FROM THOSE SAME PHOTOS.  The full-frame box encloses 225 cells
// and was reported with 64 moving blocks -- 28% full.  A person walking is
// about 4 cells across by 10 down, and a frame difference lights their
// leading and trailing edges, so 20-25 of those 40 cells -- 55% or better.
// 1 (half) sits between the two with room on both sides.
//
// ⚠ THE INTERACTION WITH MERGE_GAP IS THE THING TO WATCH.  MERGE_GAP_X = 4
// and MERGE_GAP_Y = 6 deliberately over-merge, and every dead cell bridged
// that way counts against the density of the result.  A single object split
// into a leading and a trailing strip is still comfortably over half, but
// TWO separate objects fused by the gap can fall under it and BOTH vanish.
// If real objects start disappearing in pairs, that is this interacting with
// MERGE_GAP_X, and the fix is to lower the gap, not this.
//
// 0 DISABLES (area >> 0 is the whole area, which nothing can fill, so the
// disable is written as an explicit compare -- same convention as DOM_SHIFT).
//
//===========================================================================
// ⚠⚠ 2026-09-21 AFTERNOON, MEASURED ON THE BOARD: TURNED OFF.  The paragraph
// above predicted its own failure mode two paragraphs early and then shipped
// the number that triggers it.
//
// The 11:18 build went on the board.  The photograph that settles it reads
// MOTION 54 BLK with NOT ONE BOX DRAWN -- which is exactly the diagnostic
// pair MAX_BLOCKS' comment names ("a large moved_blocks reading with no box
// drawn") and it says a genuine object was being deleted, every frame, in a
// static-camera scene.  A second photo reads 80 BLK with one near-full-frame
// box, and 80 cannot fill half of that box's 180 cells, so the box drawn was
// not the box judged -- see SIZE_FLOOR for that half.
//
// WHY 50% WAS NEVER REACHABLE.  The estimate "a person is 20-25 of 40 cells"
// measured the OBJECT.  What the test divides is the BOX, and MERGE_GAP_X = 4
// / MERGE_GAP_Y = 6 were bridging 512 x 432 px of dead cells into every box
// before it was judged.  The density of a real object was therefore never a
// property of the object at all; the gap set it, and the gap was set to
// over-merge on purpose.
//
// BOTH HALVES OF THAT ARE NOW FIXED, AND THE ORDER MATTERS.  The gap is down
// to 1 x 2 blocks (see MERGE_GAP_X), so boxes hug their object and a density
// test would finally be measuring what it claims to.  It stays OFF anyway for
// this burn: the board complaint is INSENSITIVITY, and re-arming a gate that
// only ever deletes boxes in the same burn that fixes its input would make
// the next photo impossible to read.  Turn it back on -- at 1, now that the
// denominator is honest -- only once boxes are confirmed to appear again.
//
//===========================================================================
// ⭐ 2026-09-22 NIGHT: 0 -> 1.  THE CONDITION THE PARAGRAPH ABOVE SET HAS
// BEEN MET, and it was met by the board round the user reported tonight:
// "静态移动时候大多是 T" -- boxes appear, a track confirms on them, and the
// tracker holds it.  That is the "boxes are confirmed to appear again"
// clause, stated by the person looking at the panel.
//
// ⚠ THIS IS THE ONLY CAMERA-MOTION TEST IN THE FILE THAT HAS NEVER RUN ON
// THE BOARD, and the header above calls it THE PRIMARY one.  Everything the
// last three rounds shipped -- MAX_BLOCKS = 64, DISP_NC/NR, DISP_ACQ_NC/NR --
// is a FRAME-level measurement, and a frame-level measurement cannot answer
// tonight's complaint by construction:
//
//     A BIG OBJECT AND A PAN LOOK THE SAME AT FRAME LEVEL.  Both light many
//     columns and many rows.  That is exactly the 'S' the user sees when a
//     moving object gets close to the lens, and no threshold on ncol/nrow
//     separates them -- the same overlapping-bands argument MAX_BLOCKS lost
//     to on 09-21, one axis over.
//
//     THEY DO NOT LOOK THE SAME PER CLUSTER.  The pan's blocks are scattered,
//     so each cluster's own bounding box is mostly empty.  The object's are a
//     connected clump, so its box is mostly full.  THAT is the axis that
//     separates them, and this parameter is the only thing that measures it.
//
// So this round moves the camera-motion decision DOWN A LEVEL, from the frame
// to the cluster.  TRK_ACQ_BLK_SOFT is the other half and DEPENDS ON THIS ONE
// BEING NON-ZERO -- read its header before touching either.
//
// ⚠ THE FAILURE MODE TO WATCH FOR IS THE 09-21 ONE, and its signature is
// stated there: a large MOTION block count on the OSD with NO BOX DRAWN.  If
// that is what the next photo shows, this goes back to 0 -- one parameter,
// and it restores tonight's board behaviour exactly.
//
// ⚠⚠ THERE IS NO GENTLER SETTING.  THE CHOICE IS 1 OR 0.  The obvious
// hedge -- "if 1/2 is too aggressive, try 1/4" -- was MEASURED as mbtb
// variant D and it does nothing: a pan-shaped cluster fills about 40% of its
// own bounding box, so a 25% floor passes it and the test is off in all but
// name.  Do not ship 2 believing it is a softer version of 1; it is a more
// expensive version of 0.
//
// ⚠ AND IT IS NOT THE ONLY CAMERA-MOTION TEST AT CLUSTER LEVEL, which is why
// it can afford to be the aggressive one.  With MERGE_GAP at its 1x2 minimum
// a pan produces TWO populations, and each mechanism owns one:
//
//     connected + sparse  (a diagonal chain of textured patches)
//         -> one wide box, mostly empty  -> THIS TEST deletes it
//     isolated + dense    (a few adjacent blocks round one patch)
//         -> a small full box, survives  -> TRK_ACQ_BLK_SOFT refuses it
//
// Neither covers both, and that is the second reason the two parameters ship
// in one edit rather than one after the other.
//===========================================================================
parameter integer BOX_FILL_SHIFT = 1,

// ...and, since 2026-09-09, the minimum for ONE box (see [5c]).  The frame
// gate above and this are not the same test and neither replaces the other:
// MIN_BLOCKS asks whether the frame is worth believing at all, this asks
// whether a particular cluster inside a believed frame is an object or a
// speck.
//
// 2 -> 3 on 2026-09-17, against "several small boxes left behind as the object
// comes to rest".  Two blocks is 2/225 of the picture and the floor that means
// anything at all; three is the smallest number that says CLUSTER, and it now
// matches MIN_BLOCKS so a believed frame cannot publish a box that would not
// have been enough to believe the frame in the first place.  Anything a viewer
// would call an object covers far more than three 128x72 cells; what does not
// is the decaying tail of the background model, and that is what this drops.
parameter [7:0]  MIN_BOX_BLK = 8'd3,

// How far apart two block clusters may sit and still be called ONE object.
//
// 1 -> 3 on 09-10, and this is the fix for "one object, several boxes".
//
// A frame difference is a HIGH-PASS: it fires where the picture CHANGES, and
// the interior of a moving object is self-similar, so it does not change --
// only the leading and trailing edges do.  A hand crossing the frame lands on
// the block grid as two or three separate strips with dead blocks between
// them, and strict 8-connectivity is obliged to call those separate objects.
// That is what the bench photos show: never a wrong box, always one object
// wearing three of them.  The same mechanism is visible in the detect chain
// (a local max/min reference is an edge responder too), which is why this was
// never a drawing bug -- the clusters really are disconnected on the grid.
//
// So the merge has to bridge dead blocks.  3 blocks = 384 px across or 216 px
// down, which is the width of the gap those photos show between the leading
// and trailing strips of one hand, and still well under the distance between
// two objects a viewer would call separate.
//
// ⚠ THIS TRADES over-merge FOR under-split, DELIBERATELY.  Two real objects
// within the gap now share a box.  That direction is recoverable by eye; the
// other one is the complaint being fixed.  Lower it if separate objects
// matter more than a clean single box; 1 restores exact 8-connectivity.
//
// ⚠⚠ SPLIT INTO X AND Y ON 2026-09-18 (was one MERGE_GAP = 3 for both), and
// the reason is that THE GAP IS COUNTED IN BLOCKS AND BLOCKS ARE NOT SQUARE.
// BLK_W is 128 px and BLK_H is 72, so the old isotropic 3 meant 384 px
// across but only 216 px down -- two different physical tolerances for one
// physical question ("is this the other edge of the same object").
//
// The 09-18 board report was residual multi-box on a nearly-stopped object,
// "at the edges along the direction of travel -- left/right motion leaves
// them at left and right".  That is this module's own opening argument (a
// frame difference is a high-pass; only the leading and trailing edges of a
// moving object change) and it says the gap to bridge is THE OBJECT'S SIZE
// IN PIXELS.  The objects in those photos run 250-500 px, and 500 px is 3.9
// blocks across -- past the old 3, so they split.  Hence:
//
//   MERGE_GAP_X = 4 blocks = 512 px
//   MERGE_GAP_Y = 6 blocks = 432 px
//
// both now the same order in pixels rather than the same integer in blocks.
//
// ⚠ THE COST IS REAL AND IT IS THE X ONE: two genuinely separate objects
// within 512 px horizontally will share one motion box, and 512 px is a
// quarter of the frame width.  If "two objects, two green boxes" matters
// more than "one object, one green box", MERGE_GAP_X is the first thing to
// lower, and it is the ONLY parameter here that trades those two against
// each other.  This does not touch the detect chain's yellow boxes.
//===========================================================================
// ⚠⚠ 2026-09-21 AFTERNOON: 4/6 BECAME 1/2, AND THE REASON IS NOT A NEW
// JUDGEMENT ABOUT OBJECT SIZE -- IT IS THAT 4/6 WAS NEVER TESTED.
//
// mdtb scales the gap to its 5x5 grid as (4*NC)/15 and (6*NC)/15, which
// evaluate to 1 and 2.  So every one of that bench's 45 checks -- TEST 4/5
// (two clusters stay two boxes), TEST 6 (a real bridge merges), TEST 8 (the
// X/Y asymmetry) -- has been proving the behaviour of a gap of 1 and 2
// BLOCKS, for three rounds, while the hardware ran 4 and 6.  Setting the
// hardware to 1/2 does not enter new territory; it ENTERS the tested one.
//
// WHAT THE BOARD SHOWS 4/6 DOING.  512 px horizontally and 432 px vertically
// are larger than the objects being detected, so the box stopped being a
// measurement of an object and became a measurement of the gap: the photo
// with a hand near the lens has one box swallowing two block-rows of empty
// ceiling above the hand, and the frame's other moving blocks arrive inside
// the bridge and extend it further.  That is the "大框不准" complaint, and it
// is also what made BOX_FILL_SHIFT unreachable -- see there.
//
// 1 AND 2 ARE THE MINIMA THAT STILL CONNECT, which is why they are not
// smaller.  The X test is (bx1 + gx >= c_xt), so gx = 0 refuses a block in
// the very next column and every block in a row becomes its own cluster;
// gx = 1 is 8-connectivity and nothing more.  gy = 1 likewise only reaches
// the row immediately below, so gy = 2 is the smallest value that bridges
// ONE row of dropout -- a torso whose middle band matches the background --
// and TEST 8 is the check that pins it.
//
// ⚠ THE COST MOVED, IT DID NOT GO.  Fragmentation is now the risk instead of
// fusion: one object whose silhouette breaks into two clumps more than one
// column apart will draw two boxes.  DOM_SHIFT (best >> 2) and MIN_BOX_BLK
// are what hold that down, and if "多框 on one object" is the next complaint
// then DOM_SHIFT 2 -> 1 is the knob, NOT a return to 4/6: the 4/6 failure was
// silent and the fragmentation failure is visible.
//===========================================================================
parameter [4:0]  MERGE_GAP_X = 5'd1,
parameter [4:0]  MERGE_GAP_Y = 5'd2,

//------------------------------------------------------------------------
// BOX-LEVEL MERGE -- 2026-09-21 night.  After the frame ends, any two
// PUBLISHED boxes whose extents pass within BOX_GAP_* of each other are
// replaced by their union.
//
// ⚠⚠ WHY THIS IS NOT THE SAME KNOB AS MERGE_GAP ABOVE, WHICH IS THE WHOLE
// POINT AND THE REASON THREE ROUNDS OF TUNING THAT ONE DID NOT CONVERGE.
//
// MERGE_GAP is applied DURING accumulation, block by block, in raster
// order.  So a SINGLE STRAY BLOCK that happens to fall within the gap of a
// box drags that box out to reach it -- one speckle four columns away and
// the box is four columns wider, enclosing nothing.  That is why 4/6
// produced the 大框 photos: the gap was not merging objects, it was letting
// noise stretch them.
//
// This pass runs on COMPLETED boxes.  Both sides must already be a
// published cluster -- past MIN_BOX_BLK, past the dominance test, past
// PERSIST -- so a lone speckle cannot trigger it at all.  The same numeric
// gap is therefore far more selective here, which is what makes it possible
// to hold MERGE_GAP at its minimum (tight boxes that hug their object) AND
// still bridge a dropout (this pass).  One parameter could not do both:
// hugging and bridging pull it in opposite directions.
//
// THE DETECT CHAIN ALREADY HAS THIS.  ccl_blob's pass E is the same
// mechanism on the yellow boxes, added 09-18 for the same complaint, and its
// comment even says the trade is "the same one motion_frame_drawer took
// deliberately" -- referring to MERGE_GAP.  That sentence was true about the
// trade and wrong about the mechanism: the motion chain never had the
// box-level pass.  It does now, and the two chains are finally symmetric.
//
// UNITS ARE BLOCKS AND BLOCKS ARE 128x72, so X and Y are separate and the
// integers differ on purpose:
//   BOX_GAP_X = 3 blocks = 384 px
//   BOX_GAP_Y = 5 blocks = 360 px
// -- the same distance in pixels, which is the thing an object's silhouette
// actually cares about.  Getting this wrong is already in the handoff as
// the cause of "残框留在运动方向边缘".
//
// ⚠ COST, AND IT IS THE HONEST DIRECTION: two genuinely separate objects
// passing within 384 px share one box.  "One person wearing four boxes"
// reads as broken; "two people who walked past each other in one box" reads
// as coarse.  If the second ever matters more, lower these -- they are the
// only knob that moves those two against each other now.
//
// 0 on BOTH disables the pass bit-exactly.
//------------------------------------------------------------------------
parameter [4:0]  BOX_GAP_X = 5'd3,
parameter [4:0]  BOX_GAP_Y = 5'd5,

// Sweeps of the pair list, so a chain A-B-C collapses even though A and C
// never touch.  One pair per clock, NBOX*(NBOX-1)/2 = 6 pairs per sweep.
// 2 is plenty at NBOX = 4 -- the pair order visits slot 0 against all others
// first, so it accumulates a chain within a single sweep in most layouts and
// the second sweep only catches the ones that ran the other way.
parameter integer BOX_ROUNDS = 2,

// ...and the last believed box stays up this many frames after motion stops.
//
// 30 -> 8 on 09-08.  Half a second of hold was sized for a detector that only
// believed the occasional frame, and it is exactly what turned intermittent
// detection into a box parked on empty picture: every believed frame RELOADS
// this counter, so sparse detections kept a stale rectangle up indefinitely.
// With the background model the detection is continuous while an object is
// moving, so the hold only has to bridge the gap between two strokes of a
// gesture -- 8 frames, 0.13s -- and a box that is no longer being refreshed
// clears fast enough to read as tracking rather than as lag.
//
// If the box now BLINKS during a slow gesture, this is the number to raise;
// if it lingers, BG_SHIFT is the one to lower.  They fail differently.
parameter [5:0]  HOLD_FRAMES = 6'd8,

// 2026-09-17.  While the hold is bridging, publish ONLY the largest box.
//
// This is the fix for the one remaining bench complaint about motion: several
// boxes left behind for a fraction of a second as the object comes to rest.
// The mechanism is the hold, not the clustering.  A frame is either believed,
// in which case the whole table is republished, or it is not, in which case
// the table is FROZEN and counted down -- so whatever the last believed frame
// happened to contain stays on screen for HOLD_FRAMES.  As an object
// decelerates the frame-difference residue decays through MOTION_THRESH and
// breaks up on the way, so the last believed frame is reliably the most
// fragmented one of the whole gesture, and that is the snapshot the hold
// freezes.  Lowering HOLD_FRAMES shortens it without changing what it is; the
// fragments are the complaint, not their duration.
//
// During a bridge nothing is being measured, so the honest thing to show is
// the single strongest cluster: "something was moving about here". Four
// fragments claim four objects on evidence that did not even pass the frame
// gate. Believed frames are untouched -- genuine multi-object detection is
// exactly as before, and this only ever REMOVES boxes, never invents one.
//
// 0 restores the 09-09 freeze-everything behaviour for an A/B.
parameter integer HOLD_BEST  = 1,

//------------------------------------------------------------------------
// RELATIVE DOMINANCE -- 2026-09-18.  A box must hold at least
// (largest box >> DOM_SHIFT) blocks to be published, on BELIEVED frames too.
//
// This is what is left of "a little slow-motion multi-boxing" after 09-17.
// HOLD_BEST fixed the bridge frames; this is the other case, and it is not
// the same one: a BELIEVED frame during deceleration can itself contain the
// main cluster plus a couple of decaying satellites that each scrape past
// MIN_BOX_BLK.  An absolute floor cannot separate those from a genuine small
// second object, because they are the same size -- what distinguishes them is
// that they sit next to something several times bigger.
//
// 2 = a quarter.  Deliberately generous: two objects a person is actually
// waving differ by well under 4x in moved-block count, while a decay
// satellite next to a real gesture is typically a tenth of it.  Tighten to 1
// (a half) only if satellites survive, and expect to lose small genuine
// second objects when you do.
//
// 0 DISABLES the test rather than meaning "must equal the largest", which is
// what a bare shift of 0 would compute.  It is written as an explicit compare
// so that an A/B against 09-17 is one parameter.
//
//===========================================================================
// ⚠ 2026-09-21 EVENING: TIGHTENED TO 1, WHICH IS WHAT THE PARAGRAPH ABOVE
// SAYS TO DO -- "tighten to 1 only if satellites survive".  They survived.
//
// The board build with MERGE_GAP at 1/2 restored the sensitivity the density
// gate had been eating, and the complaint immediately became 多框乱跳.  The
// photograph that names the mechanism reads MOTION 13 BLK with TWO boxes, one
// on a ceiling light and one a bare column at the frame edge, AND NO BOX ON
// THE PERSON.  At a quarter, a 3-block noise cluster is publishable whenever
// the largest cluster in the frame is under 12 blocks -- which is most static
// frames, because a static scene's largest cluster is small BY DEFINITION.
//
// THAT IS THE FLAW IN "2 IS DELIBERATELY GENEROUS": the argument compared two
// objects a person is waving, i.e. it assumed the frame HAS a big cluster to
// measure against.  When the frame does not, a quarter of not-much is
// nothing, and the gate passes everything.  A half at least requires a noise
// cluster to be comparable to the real one.
//
// ⚠ THE COST IS THE ONE THE PARAGRAPH ABOVE NAMES, and it is real: a genuine
// small second object next to a large first one is now lost unless it is at
// least half the size.  Two people at similar distance differ by well under
// 2x and both survive; a hand next to a torso does not.  If "the second
// person vanished" becomes the complaint, this is the knob -- and the answer
// is to come back to 2 AND fix the noise clusters with MIN_BOX_BLK instead,
// not to disable both.
//
// 1 is a TESTED value: mdtb's dut_d1 is this configuration and TEST 7 pins
// it (11-block main cluster + 3-block satellite -> exactly one box, and the
// survivor is the main cluster).  Same argument as MERGE_GAP -- the hardware
// is moving to a number the bench already exercises, not away from one.
//===========================================================================
parameter integer DOM_SHIFT  = 1,

//------------------------------------------------------------------------
// PEAK SIZE FLOOR -- 2026-09-20.  The dominant box never shrinks below the
// largest size it reached during the current burst of motion; it is grown
// back out about ITS CURRENT CENTRE, not about where it used to be.
//
// THE COMPLAINT: "an object that is slowing to a stop ends with a box much
// smaller than the object itself."
//
// IT IS NOT A BUG AND NO THRESHOLD FIXES IT.  A frame difference is a
// high-pass and the separation an IIR background reaches against a moving
// object is (counts per frame) x 2^BG_SHIFT -- proportional to SPEED.  As the
// object decelerates that separation falls through MOTION_THRESH block by
// block, strongest edges last, so the moving-block set shrinks from the
// object's footprint down to a couple of cells and the measured box shrinks
// with it.  Then the frame stops passing MIN_BLOCKS, the hold takes over, and
// HOLD_BEST freezes THE LAST BELIEVED FRAME -- which by that argument is
// reliably the smallest and most fragmented one of the whole gesture.  What
// the bench sees as "it ends with a tiny box" is that worst frame held up for
// HOLD_FRAMES.
//
// So the object's true size is information the detector HAD and threw away.
// This keeps it: pk_w/pk_h track the largest span the dominant box reached
// since motion started, and the published box is grown symmetrically about
// its current centre until it is at least that big.  Only ever grown -- a box
// measured larger than the peak raises the peak instead.
//
// WHY NOT JUST LENGTHEN THE STICKY COUNTER, which is the obvious alternative
// (a block would stay "active" for more frames, so the footprint would not
// collapse).  Because the sticky counter remembers WHERE, not HOW BIG: a
// 16-frame sticky on an object crossing a block per frame leaves a 16-block
// trail, and the bounding box of that trail is the object's whole PATH.  That
// is the one-giant-box failure [5c] was written to remove, and it would come
// straight back.  Growing about the current centre cannot do that -- the
// extra extent is bounded by the object's own measured size.
//
// SCOPE: the DOMINANT box only (slot pbest), which is also the only box that
// survives a bridge under HOLD_BEST, so the two agree about what "the target"
// is.  Satellite boxes are left exactly as measured.  Giving every slot its
// own peak needs a box-to-box correspondence across frames that this module
// does not have -- slots are reassigned by priority every frame -- and the
// matching crossbar to build one would land on frame_tick, which [5c] and the
// argmax note both deliberately keep shallow.
//
// THE PEAK IS PER BURST, not permanent: it is reloaded (not maxed) on the
// first believed frame after hold has run out, so a new gesture is sized on
// its own evidence and a big sweep does not permanently inflate later small
// ones.  There is no decay within a burst, deliberately -- a decay fast
// enough to matter would track the deceleration it is there to resist.
//
// COST AT A FRAME EDGE: the grown box is clipped to the grid rather than
// pushed back inside, so an object leaving frame gets a box narrower than the
// peak. That is the honest picture -- part of the object is off-screen.
//
// 0 disables, for a one-parameter A/B against 09-19.
//
//===========================================================================
// ⚠⚠ 2026-09-21 AFTERNOON: TURNED OFF, AND THE 09-21 MORNING "FIX" ABOVE
// FIXED THE WRONG HALF.  This is the 全屏框 generator, still.
//
// THE BUG IS THAT pk_w AND pk_h ARE TRACKED INDEPENDENTLY.  The morning
// round stopped a DISPERSED frame from raising the peak, which closed one
// hole; it left open the one that does not need a dispersed frame at all:
//
//     frame A  a wide flat response, 13 cells x 1 row.  Area 13, so seven
//              moving blocks fill it and it passes any density test there is
//              -> pk_w = 12
//     frame B  a tall thin response, 1 col x 15 rows.  Same arithmetic
//              -> pk_h = 14
//     frame C  a small compact object, grown to 13 x 15 = THE WHOLE FRAME.
//
// No frame ever measured that box.  The peak is a per-dimension maximum over
// a burst, so it reports the product of two frames' worst aspect ratios, and
// `hold` is reloaded by every believed frame so the burst never ends and the
// peak never reloads.  The board photo is MOTION 80 BLK with a box whose left
// edge sits at column 3 and whose other three edges are off the panel: 80
// blocks cannot have measured a 180-cell box, and BOX_FILL_SHIFT was armed in
// that build, which proves the box that was DRAWN was never the box JUDGED --
// the density verdict is computed on pb* and the growth is applied afterwards
// into eb*.
//
// WHAT A REAL FIX WOULD LOOK LIKE, if box shrinkage on deceleration ever
// becomes the complaint again: take BOTH dimensions from the SAME frame (the
// one with the largest area seen in this burst) so the floor can only ever
// restore a box that was actually observed.  That is a coupled peak, it needs
// one more comparator and an area register at seq 6, and it is strictly more
// logic than this parameter -- so it waits until the symptom comes back.
//
// With 0 the grow terms fold away at elaboration and eb* is a registered copy
// of pb*, which is what the 09-19 build drew.
//===========================================================================
parameter integer SIZE_FLOOR = 0,

//===========================================================================
// 2026-09-22: THE DISPERSION VETO.  See [4c].
//
// MAX_BLOCKS cannot separate "the camera moved" from "something large moved"
// and the reason is not that the threshold is mistuned -- it is that block
// COUNT is the wrong measurement.  A pan across a flat scene lights only the
// textured quarter of the grid, so it sits well under any count threshold a
// real object also has to pass.  (Recorded on the competition project as
// well: the two distributions overlap, measured.)
//
// What DOES separate them is where the lit blocks are.  One object occupies
// a few columns and a few rows; a pan sprays motion along both axes at once.
// So: veto a frame in which motion touches at least DISP_NC distinct columns
// AND at least DISP_NR distinct rows.  Both, never either -- a person walking
// past the camera fills one column and ten rows, and an "or" would delete it.
//
// Costs two 15-bit seen-masks and two 4-bit counters, incremented on the
// mv_valid pulses, which are >=BLK_W clocks apart.  No popcount, no blanking
// work: the counts are complete registers by frame_tick.
//
// The veto joins md_blind, so it also RE-SEEDS the background -- which is the
// point.  See the md_inhibit header for why gating only the output is the
// version of this that does not work.
//
// 0 disables, for a one-parameter A/B against the 09-21 build.
parameter integer DISP_EN = 1,
parameter [3:0]   DISP_NC = 4'd9,
parameter [3:0]   DISP_NR = 4'd9,

//===========================================================================
// 2026-09-22 (evening): THE SOFT DISPERSION LEVEL.  See [4d].
//
// DISP_NC/NR above is a HARD verdict: the frame is discarded and the
// background re-seeded.  Because a person walking past must never trip it,
// it has to sit high -- and MOST OF A HAND-HELD SHAKE PASSES UNDERNEATH IT.
// The board photographs show exactly that: `C` on some frames, `?` with a
// frozen box on others, and on the frames in between the detector publishes
// camera-motion clusters that are, per frame, indistinguishable from object
// clusters.  Both remaining complaints ("a random box while I pan" and "the
// random box beats the object") live on those frames.
//
// ⭐ THE ASYMMETRY THIS EXPLOITS: acquiring a track and following one are
// not equally risky.  Following is anchored -- a measurement has to land
// next to a centre we already believe in.  Acquiring has no anchor at all:
// whatever cluster is biggest becomes the target.  So a frame can be too
// polluted to START a track on while still being good enough to keep
// following the target the user is actually pointing at.  One lower pair of
// thresholds buys that distinction for two comparators.
//
// ⚠ IT MUST NOT JOIN md_blind, AND THAT IS THE WHOLE REASON IT IS A
// SEPARATE SIGNAL rather than a second, lower DISP_NC.  A soft frame is
// still the best evidence available; re-seeding the background on it would
// blind the detector precisely when the scene is hardest, and dropping its
// boxes would take the object's box with them.  This is a TRACKER POLICY,
// not a detector verdict.  Nothing upstream of [5f] reads it.
//
// 7/7 = motion spread over 896 x 504 px.  Chosen downwards from the hard
// pair, not upwards from zero: a person filling seven columns AND seven rows
// is very close to the lens, and the only cost when they do trip it is that
// acquisition waits for a calmer frame.  Watch the `S` character on the OSD
// (§-2.5's rule: read the flag, not the box) -- `S` while you pan and never
// otherwise means it is set right.  4'd0 on either disables the soft level
// and restores the morning build's tracker policy exactly.
parameter [3:0]   DISP_ACQ_NC = 4'd7,
parameter [3:0]   DISP_ACQ_NR = 4'd7,

//===========================================================================
// 2026-09-22: THE SINGLE-TARGET TRACKER.  See [5f].
//
// WHY THIS EXISTS.  Everything above publishes MEASUREMENTS: each frame's
// clusters, judged on that frame's evidence alone.  That is the right output
// for a display and the wrong one for a servo, and the two board complaints
// it cannot answer are both consequences:
//
//   "a small box lingers when the object is about to stop" -- frame
//   differencing measures CHANGE, not objects.  A decelerating body lights a
//   shrinking sliver at its edges, so the measured box shrinks with the
//   speed.  Nothing in a per-frame measurement can know the object is still
//   that size, because this frame's evidence says it is not.
//
//   "panning gives fragments and huge boxes" -- during a pan every
//   measurement is real.  They are measurements of the wrong thing.
//
// A tracker answers both because it carries STATE: a size that grows fast and
// decays slowly, and a position that only a nearby measurement is allowed to
// move.  It draws exactly one box, so there is nothing for clutter to draw.
//
// ⚠ IT IS NOT A BETTER DETECTOR AND MUST NOT BE READ AS ONE.  It consumes
// pbshow/pbn -- the same published table the green overlay draws -- so
// anything the detector misses, the tracker misses.  What it adds is
// association (which measurement belongs to the thing I am following),
// persistence, and a bounded size.  If the green boxes are wrong, fix them
// there; do not tune the tracker to hide it.
//===========================================================================
parameter integer TRK_EN = 1,

// The association gate, in BLOCKS, applied about the tracked centre.
// ⚠ SEPARATE PER AXIS AND THAT IS NOT SYMMETRY FOR ITS OWN SAKE: blocks are
// 128x72 px, so one block of x is 1.8 blocks of y in real distance.  A single
// isotropic radius in block units is the MERGE_GAP bug (section 3.-9-C)
// written a second time.
parameter [3:0]   TRK_GATE_X = 4'd3,
parameter [3:0]   TRK_GATE_Y = 4'd3,

// The gate used INSTEAD of the pair above on a soft-dispersed frame (see
// DISP_ACQ_NC).  Tighter, because on such a frame a cluster three blocks out
// is as likely to be a piece of the background sliding past as it is to be
// the target: a confident track should only be moved by something almost on
// top of it.  ⚠ Do not set this to zero thinking it means "do not move" --
// zero is a legal, very tight gate, and a measured centre lands on a
// half-block lattice, so a zero gate accepts only an exact centre match.
// Set it equal to TRK_GATE_X/Y to disable the tightening on its own.
parameter [3:0]   TRK_GATE_SX = 4'd2,
parameter [3:0]   TRK_GATE_SY = 4'd2,

// log2 of the position IIR: the tracked centre moves 1/2^TRK_SHIFT of the way
// to the measurement each frame.
//
// ⚠ THE UPPER LIMIT IS SET BY THE MEASUREMENT LATTICE, not by taste.  The
// centre is held in 1/16 of a block and a measured centre is always a
// multiple of 1/2 a block = 8 of those units, so an error is always a
// multiple of 8 and TRK_SHIFT = 3 still moves by at least one unit.  At 4 the
// shift floors to zero for a one-lattice-step error and the tracker stalls a
// half-block short of its target FOREVER -- a dead zone that looks exactly
// like a tracking bug and is arithmetic.
parameter integer TRK_SHIFT = 2,

// Consecutive associated frames before the box is drawn and target_valid
// rises.  Rejects a one-frame noise cluster becoming a target.
//
// ⚠ 2026-09-22 evening: 2 -> 3, AND IT ONLY MEANS "CONSECUTIVE" BECAUSE OF
// THE UNCONFIRMED-DROP RULE BELOW.  Until that rule existed a coast did not
// clear trk_conf, so a candidate could collect its confirmations one frame
// at a time across a 12-frame coast and still be drawn -- which is what a
// pan produces, and raising this number alone would not have touched it.
parameter [2:0]   TRK_ACQ = 3'd3,

// Frames a CONFIRMED track survives while the camera-motion verdict is
// blinding the detector.  Freeze, not drop: a brief shake leaves the box
// exactly where it was and a sustained pan gives it up honestly.  12 frames
// at ~30 fps = 400 ms.
parameter [3:0]   TRK_COAST = 4'd12,

// Frames a CONFIRMED track survives while the detector is working and
// simply measuring nothing where the track is.
//
// ⚠ SPLIT FROM TRK_COAST ON 2026-09-22 EVENING, AND THE TWO NUMBERS WANT
// OPPOSITE THINGS, which is why one parameter could not serve both:
//   * blind frames  -- long is right.  There is no information at all, and
//     re-acquiring on whatever the new view contains is worse than waiting.
//   * missed frames -- long is the "滞留" complaint itself.  The detector IS
//     looking and reports nothing at the track, so every extra frame is a
//     box sitting on empty floor with a `?` next to it.
// 6 frames = 200 ms, and re-acquisition costs TRK_ACQ frames after that, so
// a genuine pause reads as a short blink rather than a long lie.
// ⚠ Must be >= 1: the expiry is written ">= TRK_MISS - 1" to match
// TRK_COAST's form, and 0 would wrap to 15 and coast almost forever.
parameter [3:0]   TRK_MISS = 4'd6,

// 1 = a track that has not yet reached TRK_ACQ confirmations is DROPPED on
// any frame it fails to associate on, instead of coasting.  See t_unconf for
// the argument; the short version is that without it "TRK_ACQ consecutive
// frames" is not what TRK_ACQ means, because a coast preserves trk_conf.
//
// 0 restores the morning build's behaviour, and it exists because this file
// already has six one-parameter rollbacks (OBJ_EXCL / BG_TRACK / DUP_DEPTH /
// OVF_TRIM / DOM_SHIFT / SIZE_FLOOR) and the handoff's own rule is that each
// mechanism must be independently switchable -- otherwise a board session
// that gets worse cannot say WHICH of the evening's three changes did it.
//
// ⚠ With this at 0, put TRK_ACQ back to 2 as well.  3 was chosen ON TOP of
// this rule; 3 without it is strictly worse than 2 without it -- a longer
// fuse on the same wrong box.
parameter integer TRK_DROP_UNCONF = 1,

// Blocks a cluster needs to START a track.  Deliberately above MIN_BOX_BLK:
// acquiring is a commitment, following an existing track is not.
parameter [7:0]   TRK_ACQ_BLK = 8'd4,

//===========================================================================
// ⭐ THE SOFT-FRAME ACQUISITION FLOOR -- 2026-09-22 NIGHT.
//
// Blocks a cluster needs to start a track ON A SOFT-DISPERSED FRAME.
// 0 = the 09-22-evening behaviour: a soft frame can never acquire, full stop.
//
// WHY THIS EXISTS.  Tonight's board round says the soft gate FIRES CORRECTLY
// on a pan ("移动摄像头大多是 C 和 S") -- DISP_ACQ_NC/NR = 7/7 is the right
// value and is not what changed.  It also says the same gate fires on a big
// near object ("移动物体占画面大一点就是 S"), and there it costs the user the
// one target they are pointing at: 'S' forbids acquisition outright, so the
// box never comes out.
//
// ⚠ THE FIX IS NOT TO RAISE 7/7.  That is the same axis, and the two
// populations overlap on it -- see BOX_FILL_SHIFT's 09-22 note for why a
// frame-level span cannot tell a big object from a pan at any threshold.
// Raising it would stop catching pans before it stopped catching objects.
//
// WHAT CHANGES INSTEAD IS THE SHAPE OF THE RULE.  §-3.1's asymmetry said
// acquisition has no anchor and therefore needs stronger evidence than
// following does.  Last round spent that insight on a BINARY answer -- soft
// frame, no acquisition.  A floor is the same insight with the evidence made
// CONTINUOUS: a soft frame may still acquire, but only on a cluster big
// enough that no amount of background sliding past could have produced it.
//
// ⚠⚠ THIS PARAMETER IS UNSAFE ALONE AND REQUIRES BOX_FILL_SHIFT != 0.
// a_hit already demands pbshow[a_i], and pbshow is pbvalid & dense -- so with
// the density test armed, every candidate reaching this floor is ALREADY
// compact, and "compact AND large" is not something a pan across a flat room
// produces.  With BOX_FILL_SHIFT = 0, dense is all-ones, and this floor
// degenerates into "a soft frame may acquire the biggest blob" -- which is
// precisely the "random box beats the object" failure last round closed.
// ⚠ IF YOU ROLL BOX_FILL_SHIFT BACK TO 0, ROLL THIS BACK TO 0 IN THE SAME
// EDIT.  They are one mechanism in two parameters.
//
// WHY 12.  A third guess without board data, and it is calibrated off the
// only measured numbers there are: a hand gesture with a static camera lights
// 20-40 blocks IN THE WHOLE FRAME, and a near object -- the case that
// prompted this -- is at the top of that band or above it.  12 is comfortably
// under a big near object's single cluster and roughly triple TRK_ACQ_BLK,
// the floor that applies on a clean frame.
//
// HOW TO TUNE IT, and it is the same rule the last two rounds used: READ THE
// FLAG, NOT THE BOX.  A big object should stop producing an unaccompanied 'S'
// with no magenta box.  If a big object still cannot acquire while showing
// 'S', LOWER this.  If a pan starts acquiring again -- a magenta box that
// wanders with the background while 'S' is up -- RAISE it, and only then
// consider 0.
//===========================================================================
parameter [7:0]   TRK_ACQ_BLK_SOFT = 8'd12,

//===========================================================================
// 2026-09-23: TRK_FOLLOW_SPARSE -- the density test gates ACQUIRING, not
// FOLLOWING.  1 = a track already running may associate against a box that
// failed BOX_FILL_SHIFT.  0 = bit-exact 09-22-night behaviour.
//
// ⭐ WHY THIS IS A MECHANISM CHANGE AND NOT A THRESHOLD CHANGE.  The board
// result for BOX_FILL_SHIFT = 1 split exactly along the acquire/follow line:
// the pan case IMPROVED (fewer boxes, mostly 'C'/'S') and the static-object
// case REGRESSED (mostly '?', i.e. the tracker holding a target it could no
// longer measure).  Both halves are the same filter doing the same thing --
// deleting a sparse cluster -- so no value of BOX_FILL_SHIFT can keep one
// and drop the other.  §-4.3 already proved the middle is empty: pan shapes
// fill ~40%, and a real object with a flat interior fills ~50-60%, because
// block-mean differencing only fires where there are EDGES.  Those two
// distributions overlap, which is the third time that same argument has
// landed (block count -> frame span -> cluster fill).
//
// ⚠ SO STOP LOOKING FOR A FOURTH SCALAR ON THIS AXIS.  What separates the
// two cases is not a better measurement of the cluster, it is WHAT THE
// TRACKER IS ABOUT TO DO WITH IT -- §-3.1's asymmetry, applied one level
// down than last time:
//
//   acquiring -- no anchor, so a sparse cluster is indistinguishable from
//                background sliding past.  Density stays REQUIRED.
//   following -- the gate is the anchor.  A cluster that is sparse this
//                frame, two blocks from a centre we already believe, is the
//                same object seen on a frame where only its edges moved.
//                Refusing it does not make the tracker safer, it makes it
//                blind for TRK_MISS frames and then makes it re-acquire.
//
// ⚠ IT DOES NOT WIDEN pbshow.  The green overlay and the exported table are
// still `pbvalid & dense`, so the pan-clutter rectangles the board photo
// showed disappearing stay gone.  The consequence to know before reading a
// photograph: A MAGENTA BOX MAY NOW SIT WHERE NO GREEN BOX IS DRAWN -- that
// is this parameter working, not a bug, and it reads as "following a sparse
// measurement".  It is also the ONE place in this module where the tracker
// and the overlay deliberately see different tables.
//
// Rollback is one parameter and it is bit-exact, because the acquire branch
// carries `dense[a_i]` UNCONDITIONALLY: with TRK_FOLLOW_SPARSE = 0 the
// follow branch reads pbshow again, and pbshow already implies dense, so the
// extra term is redundant rather than additive.  (It is equally redundant
// when BOX_FILL_SHIFT = 0, where dense is all ones.)
//===========================================================================
parameter integer TRK_FOLLOW_SPARSE = 1,

//===========================================================================
// ⭐ HOW LONG A COASTING TRACK IS STILL DRAWN -- 2026-09-24.
//
// The largest value of trk_miss that still puts the magenta box on screen.
// 15 = disabled and BIT-EXACT with the 09-23 build, because trk_miss can
// never exceed max(TRK_COAST, TRK_MISS) - 1 = 11.
//
// THE BOARD COMPLAINT THIS ANSWERS, precisely: "panning is mostly C/S now,
// but a '?' still shows up and flashes a box".  Read that literally -- a '?'
// means the camera-motion verdict said NOTHING on that frame (C and S both
// outrank it in the OSD), so no veto, soft gate or density test is even
// running there.  The box on that frame is a COAST: a position last measured
// up to TRK_COAST frames ago, drawn with no measurement behind it.  During a
// pan that position is stale for a reason no measurement can repair, because
// the anchor is in CAMERA coordinates and the camera is what moved.
//
// ⚠ THIS IS NOT TRK_COAST MADE SHORTER, AND THAT DISTINCTION IS THE WHOLE
// POINT.  TRK_COAST's own comment argues that long is right for blind
// frames -- and it is right, for BELIEVING.  Believing and DRAWING were the
// same number only because nobody had separated them:
//   * believing long  -- correct.  A brief shake or dropout must not cost
//     the identity of the target; re-acquiring on whatever the new view
//     contains is the worse failure (§-3.1, twice proven).
//   * drawing long    -- always wrong.  Every drawn coast frame is a claim
//     about a position with no evidence under it, and the user photographs
//     the box, not the register.
// So the track still lives its full budget, still holds its geometry, still
// re-associates the instant the detector finds it again -- and the 09-23
// "freeze, not drop" behaviour is untouched.  Only the ink stops.
//
// 2 frames (~33 ms) is chosen so a one- or two-frame dropout does not make
// the box flicker while the object is plainly still there, which is the
// stability the freeze was for in the first place.
//
// ⚠ trk_state IS DELIBERATELY *NOT* GATED ON THIS.  A hidden coast still
// prints '?', so the panel now reads:
//     'T' + box    -- locked on a measurement from this frame
//     '?' + NO box -- holding a target it cannot currently measure
//     blank        -- no target at all
// which is strictly MORE separable than before, not less.  §-2.5 required
// that coasting have its own character so a still photo could not confuse a
// parked box with a sliding one; suppressing the sliding box satisfies that
// requirement harder than a character ever could.  ⚠ The other half of
// §-2.5 -- "the character must describe the box on screen" -- is the one
// sentence this change reverses, and it is reversed on purpose: the box and
// the character now answer two different questions, and the pair is the
// readout.
//===========================================================================
parameter [3:0]   TRK_SHOW_MISS = 4'd2,

//===========================================================================
// ⭐⭐ AND A COAST MAY ONLY BE DRAWN WHILE THE CAMERA HAS BEEN QUIET.
// 2026-09-25.  1 = on.  0 = the 09-24 behaviour, BIT-EXACT.
//
// WHY THE 09-24 BUILD DID NOT FIX THE COMPLAINT IT WAS AIMED AT.  The board
// came back with "if a '?' appears while I pan it STILL flashes a box", and
// that is this file being read correctly, not a malfunction:
//
//     '?'  is  trk_miss != 0
//     box  is  trk_miss <= TRK_SHOW_MISS
//
// so trk_miss of 1 or 2 printed '?' AND drew.  TRK_SHOW_MISS shortened the
// coast's ink but left a two-frame overlap, and a pan produces a stream of
// one- and two-frame coasts -- it lives entirely inside the window that was
// left open.
//
// ⚠ AND LOWERING TRK_SHOW_MISS TO 0 IS THE WRONG FIX, which is the whole
// reason this parameter exists instead.  At 0 the box would be exactly "a
// measurement this frame", which is a clean invariant -- and it would make
// the box blink on EVERY dropped frame, including on the static scene that
// the board now reports as mostly 'T'.  That pays for complaint 2 with
// complaint 1, and this project has now twice proven that trading the two
// halves against each other is not progress (§-5.0's clean split, §-4.3's
// overlapping distributions).
//
// ⭐ THE AXIS THAT SEPARATES THEM IS ALREADY IN THIS FILE, AND IT COSTS
// NOTHING.  Ask WHY the detector missed:
//
//   * the camera moved            -- the frozen position is wrong for a
//     reason no amount of waiting repairs, because the anchor is in CAMERA
//     coordinates and the camera is what moved.  Draw nothing, at once.
//   * the object stopped moving   -- frame differencing is a high-pass
//     filter, so a person who pauses generates no motion at all.  The
//     position is still perfectly good.  Keep drawing.
//
// That is not a new measurement -- §-4.1 / §-5.1 are not being reopened.  It
// is cam_motion_r and the CAM_HOLD tail, both of which already exist, read
// by the draw gate instead of only by the tracker.
//
// ⚠⚠ THE SUPPRESSION TERM IS DELIBERATELY BROADER THAN CAM_HOLD'S OWN
// LATCH, AND THIS IS THE ACQUIRE/FOLLOW ASYMMETRY ONE LEVEL DOWN AGAIN.
// CAM_HOLD latches on disp_veto ALONE and its comment argues at length for
// excluding MAX_BLOCKS -- because a large near object trips that veto, and
// locking it out of its own box is complaint 1.  The DRAW gate uses
// cam_motion_r, which includes MAX_BLOCKS and md_inhibit:
//
//     refusing to ACQUIRE costs a real target its box  -> keep it narrow
//     refusing to DRAW A COAST costs nothing at all    -> keep it broad
//
// A coast has no measurement behind it by definition, so there is no
// evidence to lose by declining to paint it.  ⚠ Do not "tidy" these two
// into one signal.
//
// The two terms of cam_recent are tested SEPARATELY (mctb T76 and T77): a
// single test would leave one of them possibly dead while the bench passed.
//===========================================================================
parameter integer TRK_SHOW_QUIET = 1,

//===========================================================================
// ⭐⭐ ...AND ONLY A CLEAN COAST MAY BE DRAWN.  2026-09-28.  1 = on.
// 0 = the 09-25 behaviour, BIT-EXACT (trk_taint is then read by nothing and
// folds away).
//
// A coast is a claim: "the object is where the last measurement put it".
// That claim is only as good as the camera's stillness SINCE that
// measurement.  TRK_SHOW_QUIET checks the camera on the frame being drawn
// (plus the CAM_HOLD tail), and the 09-25 board build still showed
// "panning is mostly C/S, but now and then a box with '?'" -- which is this
// file being read correctly again.  Two holes, both one frame wide:
//
//   * THE RE-SEED FRAMES.  Every blind frame is followed by two frames of
//     bg_seed in which the detector can measure nothing BY CONSTRUCTION
//     (new_cnt is forced to 0).  The tracker books them as ordinary misses,
//     and cam_motion_r is already 0 on them.  After a MAX_BLOCKS veto --
//     which CAM_HOLD deliberately does not latch -- the first re-seed frame
//     reads trk_miss = 2, cam_recent = 0: a '?' with a box drawn at the
//     PRE-PAN position.
//   * THE SOFT FRAMES.  disp_soft_r is in nobody's draw gate.  A miss on an
//     'S' frame draws (the panel shows 'S'), and a miss on the next,
//     unflagged frame draws with '?'.
//
// ⭐ NO NEW TIME CONSTANT.  Not a hold counter reloaded on soft frames: the
// question is not "how long ago did the camera move" but "has it moved
// since the measurement this coast extrapolates", and that is one bit per
// track.  trk_taint is set by any camera-motion evidence (a blind frame, a
// soft frame) and cleared only by a fresh association on a frame that was
// itself not soft.
//
// ⚠ STILL ONLY A COAST IS GATED.  The trk_miss == 0 arm stays unconditional
// -- an 'S' frame with a fresh measurement keeps its box, which is what
// keeps a big near object (the thing that trips 'S' with the camera still)
// from blinking.  Its cost on the static scene: when such an object STOPS,
// the box goes the frame it stops instead of up to TRK_SHOW_MISS frames
// later.
//
// ⚠ AND THIS DOES NOT HELP A PAN THAT RAISES NO FLAG AT ALL.  A pan across
// one textured object in a flat room looks, frame by frame, exactly like
// that object moving; no rule over these signals separates them, and this
// one does not pretend to.
//===========================================================================
parameter integer TRK_SHOW_CLEAN = 1,

//===========================================================================
// ⭐ THE ACQUISITION LOCKOUT AFTER A DISPERSION VETO -- 2026-09-24.
//
// Frames after a hard DISPERSION veto during which no new track may be
// acquired.  0 = disabled and BIT-EXACT with the 09-23 build.
//
// WHY A TIME CONSTANT AND NOT A FOURTH SCALAR.  §-4.1 / §-5.1 proved three
// times over that no frame-level scalar separates ego-motion from object
// motion (block count -> frame span -> cluster fill, all overlapping), and
// that proof is not being re-litigated here.  This parameter measures
// nothing new.  It uses the fact that A PAN IS A SUSTAINED EVENT WHILE THE
// JUDGE IS A PER-FRAME MEASUREMENT: cam_motion_r is `<= md_blind` every
// frame, independently, so a pan that trips the veto on frames 1,2,4,5,7
// leaves 3 and 6 completely unguarded -- and TRK_ACQ consecutive unguarded
// frames is all a box needs.  Filtering a noisy verdict in TIME is
// orthogonal to how precise the verdict is.
//
// ⚠ LATCHED ON disp_veto ALONE, NOT ON md_blind, AND EACH EXCLUSION IS A
// SEPARATE ARGUMENT:
//   * NOT (tot_n > MAX_BLOCKS).  "Too much moved" is tripped by a large
//     NEAR OBJECT as readily as by a pan -- that is the complaint
//     TRK_ACQ_BLK_SOFT exists to answer.  Holding the lockout on it would
//     lock a person walking up to the camera out of their own box for
//     CAM_HOLD extra frames, i.e. it would pay for complaint 2 with
//     complaint 1.  disp_veto is the verdict that actually means "what
//     moved is spread over the whole frame".
//   * NOT md_inhibit.  That is OUR OWN commanded head step: we know its
//     duration and direction, the background is re-seeded through it, and
//     the frames after it are honest.  Blocking acquisition there would
//     just make the servo slow.  ⭐ Inferred ego-motion needs a guard;
//     KNOWN ego-motion does not, and keeping these two apart is the whole
//     reason the head is worth mounting.
//   * NOT disp_soft.  The soft gate already inhibits acquisition on its own
//     frame; extending it in time as well would be a third knob on one
//     mechanism and there is no board evidence asking for it.
//
// 6 frames (~100 ms).  Combined with the two seeded frames md_blind already
// forces and TRK_ACQ = 3, a pan must now look like NOTHING AT ALL for about
// eleven consecutive frames before it can draw a box.
//
// ⚠ IF COMPLAINT 1 (static object) REGRESSES -- longer '?' runs or blank
// where a box belongs -- this is the first thing to take back to 0, because
// it is the only change here that can DELAY a legitimate acquisition.
//===========================================================================
parameter [3:0]   CAM_HOLD = 4'd6,

// 1 = the box is a constant TRK_W_MIN x TRK_H_MIN blocks and never adapts.
// That is the literal "fixed box" and it is the safe fallback -- it cannot
// grow onto anything.  0 = grow by at most one block per frame towards the
// measurement, shrink one block per TRK_DECAY frames, clamped both ends.
//
// ⚠ THE GROWTH RATE LIMIT IS THE WHOLE DIFFERENCE FROM SIZE_FLOOR, which is
// the same idea and failed.  SIZE_FLOOR took a per-axis MAX over a burst with
// no association and no decay, so one bad frame on each axis ratcheted the
// box to the full grid permanently (see its header).  Here a bad frame costs
// one block, it must have passed the gate to cost that, and TRK_DECAY takes
// it back.
parameter integer TRK_FIXED = 0,
parameter [3:0]   TRK_W_MIN = 4'd2,
parameter [3:0]   TRK_H_MIN = 4'd3,
parameter [3:0]   TRK_W_MAX = 4'd7,
parameter [3:0]   TRK_H_MAX = 4'd11,
parameter [4:0]   TRK_DECAY = 5'd16,

// Magenta, and the colour is load-bearing: the green rectangles are the
// per-frame measurement and this is the tracked state.  Two things that
// disagree must not be drawn in the same colour -- section 3.-14 records a
// whole round lost to two readings that looked like one.
parameter [7:0]   TRK_R = 8'd255,
parameter [7:0]   TRK_G = 8'd0,
parameter [7:0]   TRK_B = 8'd255,
parameter integer TRK_THICK = 8,

// 10-21: 0 = draw nothing (neither the green per-frame boxes nor the magenta
// tracker); out_rgb is then rgb_d1, the same 2-clock-delayed input.  Detection,
// tracking, alarms and every exported box/target are untouched -- this only
// gates the final colour mux.  1 = unchanged.
parameter integer DRAW_EN = 1,

// Published box slots.  Was a localparam next to the registers it sizes until
// 2026-09-18, when the face detector needed the boxes on the port list and
// Verilog-2001 required the width to be a parameter.  The reasoning about why 4
// is enough, and about the reduction's timing, is still down at the registers.
parameter integer NBOX = 4
)(
input  wire        clk,
input  wire        rst_n,

input  wire        in_vs,          // HIGH across the visible frame
input  wire        in_de,
input  wire [23:0] in_rgb,

input  wire        motion_frame_en,

// 2026-09-22: draw the TRACKER's single box.  A separate wheel position from
// motion_frame_en rather than a second thing the same position draws, so the
// board comparison is one key press and each picture shows one algorithm.
//
// ⚠ IT GATES DRAWING ONLY.  The tracker runs in every wheel position, same
// as the detector does, because target_x/y must not stop working when the
// operator switches the display -- the identical argument the target's own
// header makes about motion_frame_en.
input  wire        track_en,

//------------------------------------------------------------------------
// 2026-09-20: "THE CAMERA IS ABOUT TO MOVE / IS MOVING".  Hold this high for
// as long as the pan-tilt head is being driven, plus its settling time.
//
// While it is high: no frame is believed, the published table is cleared, and
// the background model is RE-SEEDED every frame (bg := cur, sticky pinned at
// zero).  Two more seeded frames run after it falls, so the first live frame
// already has a background that belongs to the new view.
//
// ⚠ THE RE-SEED IS THE POINT, and it is what a plain "disable the detector
// while the servo runs" scheme gets wrong.  Gating the OUTPUT costs nothing
// and fixes nothing: the stored bg still describes the old view, so the first
// frame after re-enabling reads as whole-frame motion and then takes
// 2^BG_SHIFT = 16 frames to converge.  A step-and-look tracking loop built
// that way is blind for a quarter of a second after EVERY step. With the
// re-seed the recovery is 2 frames, which is what makes small steps viable.
//
// Tie to 1'b0 if there is no head; MAX_BLOCKS still catches the camera being
// bumped or shaken, and the two are complementary -- this one covers the
// motion you commanded, MAX_BLOCKS covers the motion you did not.
input  wire        md_inhibit,

output wire        out_vs,
output wire        out_de,
output wire [23:0] out_rgb,

// 2026-09-04: last completed frame's moving-block count, for the OSD.  Held
// stable for a whole frame -- tot_n itself is a running total that is cleared
// at frame_tick, so reading it directly would show a count ramping up the
// screen as the frame streams past.
output wire [7:0]  moved_blocks,

// 2026-09-18: the published boxes, exported for the face detector, which uses
// them as fallback candidate regions when chroma fails to find a face (see
// face_roi_buf.v).  These are the SAME registers that drive this module's own
// green overlay -- pbx0/pbx1/pby0/pby1 after the believe-this-frame gate, the
// MIN_BOX_BLK floor and the DOM_SHIFT dominance test -- so a box exported here
// is exactly a box drawn on screen, with no second code path to drift.
//
// UNITS: BLOCK INDICES, 0..N_COLS-1, not pixels.  The consumer multiplies by
// BLK_W/BLK_H.  Blocks are 128x72 and therefore NOT square, which has already
// been the root cause of one bug (MERGE_GAP, section 3.-9-C) -- so a consumer
// that treats one of these as a pixel count, or assumes the two axes share a
// scale, is wrong twice over.
output wire [NBOX*4-1:0] box_x0,
output wire [NBOX*4-1:0] box_x1,
output wire [NBOX*4-1:0] box_y0,
output wire [NBOX*4-1:0] box_y1,
output wire [NBOX-1:0]   box_valid,

//------------------------------------------------------------------------
// 2026-09-20: THE TRACKING TARGET -- the centre of the dominant box, for a
// pan-tilt controller to servo on.
//
// PIXELS here, not block indices, and deliberately unlike box_x0..box_y1
// above: those exist to index the frame buffer and a consumer that scaled
// them would be re-deriving BLK_W/BLK_H anyway, whereas the only thing this
// is ever used for is an error term against IMG_HDISP/2, IMG_VDISP/2.  The
// underlying resolution is still one block -- the centre lands on a 64 x 36
// px lattice -- which is finer than any step an SG90-class head can place
// and far finer than the box's own accuracy.
//
// Gated on `hold`, NOT on motion_frame_en: the effect wheel decides whether
// the green rectangles are DRAWN, and a tracking loop must not stop working
// because the operator switched the display to another mode.
//
// This is the centre of the box as drawn, so it carries SIZE_FLOOR's growth.
// That is the wanted behaviour and it is not a rounding detail: the floor
// grows the box symmetrically about the measured centre, so it moves the
// reported target only when the grown box is clipped at a frame edge -- i.e.
// exactly when the object is half out of view and the measured centre is
// biased inwards anyway.
output wire [11:0] target_x,
output wire [11:0] target_y,
output wire        target_valid,

// High for the whole frame after a frame was rejected as camera motion (see
// MAX_BLOCKS) or while md_inhibit is asserted.  For the head controller:
// "the picture is not usable right now", which is the signal to keep the
// servo command where it is rather than to servo on a stale target.
output wire        cam_motion,

// 2026-09-22 (evening): the SOFT dispersion verdict for the frame that just
// ended -- "this frame is too spread out to start a track on".  For the OSD
// only; no servo should act on it, because unlike cam_motion it does not say
// the picture is unusable, only that it is not trustworthy enough for a
// commitment.
//
// ⚠ IT EXISTS BECAUSE OF THE ONE-CHARACTER RULE.  DISP_ACQ_NC/NR is the
// second threshold pair in this module shipped on a guess, and the first one
// (DISP_NC/NR, this morning) shipped with a note saying "read the C flag
// before you look at the boxes".  A threshold with no flag is a threshold
// nobody can tune from a photograph.
output wire        cam_soft,

// 2026-09-22: the tracker's lifecycle, for the OSD.  0 = no track, 1 = track
// coasting (no measurement associated this frame), 2 = locked.
//
// ⚠ ONE CHARACTER ON SCREEN IS WORTH A BURN.  The 09-20 veto shipped with no
// way to see whether it had fired and the photographs could not answer it
// afterwards; the same trap is wide open here, because "the box sat still"
// and "the box was coasting on nothing" look identical in a still frame and
// mean opposite things about whether the detector is working.
output wire [1:0]  trk_state,

// 2026-10-01 evening: the tracker's rectangle, PIXELS, inclusive -- the very
// registers [6] draws the magenta box from (written at TGEO), and the draw
// enable.  For trk_range: the ToF follows this box and labels its corner.
// Not gated on track_en, same rule as target_x/y.
output wire [11:0] trk_box_x0,
output wire [11:0] trk_box_x1,
output wire [11:0] trk_box_y0,
output wire [11:0] trk_box_y1,
output wire        trk_box_v
);

localparam integer MD_SYNC_DLY = 2;
localparam [3:0]   TILE_MAX    = N_COLS - 1;      // 14

// Background model layout.  AVGW integer bits of block average plus BGF
// fractional bits, so the IIR increment does not quantise to zero: with
// BG_SHIFT = 4 the smallest step the filter can take is 1/16 of a count, and
// BGF = 5 keeps that representable with a bit to spare.  Get BGF <= BG_SHIFT
// and bg stalls at a fixed offset from cur -- a dead zone that reads as a
// permanently half-triggered block.
localparam integer AVGW = 6;                      // blk_sum_final[16:11]
localparam integer BGF  = 5;                      // fractional bits on bg
localparam integer BGW  = AVGW + BGF;             // 11
// The per-block NOISE estimate, 2026-09-21 night.  Same trick as bg: NZF
// fractional bits so its own IIR increment does not quantise to zero.  Its
// integer part is an absolute deviation, which cannot exceed the range of
// the average it is a deviation of, so AVGW integer bits is exact.
localparam integer NZF  = 4;                      // fractional bits on nz
localparam integer NZW  = AVGW + NZF;             // 10

localparam integer MSW  = 2 + BGW + NZW;          // {sticky[1:0], bg, nz}

//------------------------------------------------------------------------
// [1] Screen position and block index
//------------------------------------------------------------------------
reg [11:0] px;
reg        de_prev;
reg [6:0]  y_in_blk;               // 0 .. BLK_H-1
reg [3:0]  y_tile;                 // 0 .. 14

// 2026-09-22: the absolute line, for the tracker's pixel-resolution box.
// ⚠ A COUNTER RATHER THAN y_tile*BLK_H + y_in_blk, which is the obvious
// form and is wrong here for two reasons: BLK_H = 72 is not a power of two
// so it costs a shift-add on the PIXEL path, and the sum would have to be
// registered to stay off that path, which puts it one clock behind px.  The
// counter is free and stays aligned with px and y_tile by construction.
reg [11:0] py;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        px <= 12'd0; de_prev <= 1'b0;
        y_in_blk <= 7'd0; y_tile <= 4'd0; py <= 12'd0;
    end else begin
        de_prev <= in_de;

        if (!in_vs) begin
            px       <= 12'd0;
            y_in_blk <= 7'd0;
            y_tile   <= 4'd0;
            py       <= 12'd0;
        end else begin
            if (in_de) px <= px + 1'b1;
            else       px <= 12'd0;

            if (~in_de & de_prev) begin       // end of a line
                py <= py + 1'b1;
                if (y_in_blk == (BLK_H - 1)) begin
                    y_in_blk <= 7'd0;
                    y_tile   <= y_tile + 1'b1;
                end else begin
                    y_in_blk <= y_in_blk + 1'b1;
                end
            end
        end
    end
end

wire [3:0] x_tile = px[10:7];      // BLK_W = 128

// addr = y_tile*15 + x_tile = (y_tile<<4) - y_tile + x_tile.  Shift and add,
// no DSP -- the source lost a whole burn to an inferred multiplier shifting
// the placement and putting chroma noise on every mode.
wire [7:0] blk_addr = {y_tile, 4'b0} - {4'b0, y_tile} + {4'b0, x_tile};

//------------------------------------------------------------------------
// THE COMPENSATED READ ADDRESS -- 2026-09-21 night.  See GMC_EN.
//
// blk_addr is where this block's model is STORED; blk_addr_rd is where the
// model of the content now IN this block was stored last frame.  They differ
// only while the estimator reports a shift.
//
// gmc_dx/gmc_dy are signed offsets in blocks, declared down at the
// estimator.  Clamping rather than wrapping at the edges: content shifted in
// from off-screen has no history, and reusing the edge block's model is the
// mildest available lie -- a wrap would compare the left edge against the
// right edge of the frame, which is a guaranteed false positive on a stripe.
//
// ⚠ WITH GMC_EN = 0 BOTH OFFSETS ARE CONSTANT ZERO, so the whole expression
// folds at elaboration and blk_addr_rd becomes blk_addr.  That is what makes
// the default a true bit-exact disable and not just an untaken branch.
//------------------------------------------------------------------------
wire signed [2:0] gmc_dx, gmc_dy;

wire signed [4:0] rx_s = $signed({1'b0, x_tile}) - $signed({{2{gmc_dx[2]}}, gmc_dx});
wire signed [4:0] ry_s = $signed({1'b0, y_tile}) - $signed({{2{gmc_dy[2]}}, gmc_dy});

wire [3:0] rx = (GMC_EN == 0)                  ? x_tile
              : (rx_s < 0)                     ? 4'd0
              : (rx_s > $signed({1'b0, TILE_MAX})) ? TILE_MAX
                                                 : rx_s[3:0];
wire [3:0] ry = (GMC_EN == 0)                  ? y_tile
              : (ry_s < 0)                     ? 4'd0
              : (ry_s > $signed({1'b0, TILE_MAX})) ? TILE_MAX
                                                 : ry_s[3:0];

wire [7:0] blk_addr_rd = {ry, 4'b0} - {4'b0, ry} + {4'b0, rx};

wire is_blk_first = in_de && (px[6:0] == 7'd0)        && (y_in_blk == 7'd0);
wire is_blk_last  = in_de && (px[6:0] == (BLK_W - 1)) && (y_in_blk == (BLK_H - 1));

reg in_vs_d1;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) in_vs_d1 <= 1'b0;
    else        in_vs_d1 <= in_vs;
end

wire frame_tick = in_vs_d1 & ~in_vs;    // falling edge = start of blanking

//------------------------------------------------------------------------
// [2] 4-bit luma, 0..11
//------------------------------------------------------------------------
wire [7:0] r8 = in_rgb[23:16];
wire [7:0] g8 = in_rgb[15:8];
wire [7:0] b8 = in_rgb[7:0];

wire [9:0] rgb_sum = {2'b0, r8} + {2'b0, g8} + {2'b0, b8};   // 0..765
wire [3:0] cur_y4  = rgb_sum[9:6];                           // 0..11

//------------------------------------------------------------------------
// [3] One running sum per column of the current block row.
// 128 * 72 * 11 = 101376, so 17 bits.  Exactly one entry updates per clock.
//------------------------------------------------------------------------
reg [16:0] sum_x [0:N_COLS-1];

wire [16:0] cur_sum   = sum_x[x_tile];
wire [16:0] cur_y_ext = {13'd0, cur_y4};

integer i;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        for (i = 0; i < N_COLS; i = i + 1)
            sum_x[i] <= 17'd0;
    end else if (in_de) begin
        sum_x[x_tile] <= is_blk_first ? cur_y_ext : (cur_sum + cur_y_ext);
    end
end

wire [16:0] blk_sum_final = cur_sum + cur_y_ext;

// [16:11], not [16:13].  Six bits over a 0..49 span; see RESOLUTION in the
// header for why four was not enough to see slow motion at all.  Still a
// scaling and not a divide -- 9216 is not a power of two -- which does not
// matter because the only thing this is ever compared against is the same
// block's own history.
wire [AVGW-1:0] blk_avg_now = blk_sum_final[16:11];

//------------------------------------------------------------------------
// [4] Per-block state: {sticky counter[1:0], background model[10:0]}.
// Read every pixel so the read data is there when a block finishes; written
// once per block, TWO clocks later (the IIR is pipelined -- see THE WRITE IS
// PIPELINED ONE STAGE).  The extra clock is free because a block is not
// addressed again until the next frame: after is_blk_last the raster has
// already moved on to the next tile.
//
// No reset on the array or its output register -- block RAM again.  bg_seed
// is what covers the undefined contents on the way out of reset.
//------------------------------------------------------------------------
reg [7:0]      wr_addr_r;
reg [AVGW-1:0] wr_avg_r;
reg            wr_pend;
reg [3:0]      wr_xt_r, wr_yt_r;   // the same block's tile indices

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        wr_addr_r <= 8'd0;
        wr_avg_r  <= {AVGW{1'b0}};
        wr_pend   <= 1'b0;
        wr_xt_r   <= 4'd0;
        wr_yt_r   <= 4'd0;
    end else begin
        wr_addr_r <= blk_addr;
        wr_avg_r  <= blk_avg_now;
        wr_pend   <= is_blk_last;
        wr_xt_r   <= x_tile;
        wr_yt_r   <= y_tile;
    end
end

reg [MSW-1:0] mstate [0:255];
reg [MSW-1:0] q;

// q holds mstate[blk_addr from the previous cycle], so on the cycle after
// is_blk_last it is that same block's stored state.
wire [1:0]     prev_cnt = q[MSW-1 : BGW+NZW];
wire [BGW-1:0] prev_bg  = q[BGW+NZW-1 : NZW];
wire [NZW-1:0] prev_nz  = q[NZW-1 : 0];
wire [AVGW-1:0] prev_avg = prev_bg[BGW-1:BGF];    // integer part of bg

wire [AVGW-1:0] absdiff = (wr_avg_r >= prev_avg) ? (wr_avg_r - prev_avg)
                                                 : (prev_avg - wr_avg_r);
//------------------------------------------------------------------------
// THE PER-BLOCK THRESHOLD -- 2026-09-21 night.  See NOISE_GAIN.
//
// MOTION_THRESH is now a FLOOR, not the threshold.  A block whose own
// measured noise says it needs more than 4 counts gets more; nothing ever
// gets less.
//
// The multiply is a shift, so NOISE_GAIN is log2 of the gain: 1 = twice the
// measured noise, 2 = four times.  No DSP, and no inferred multiplier --
// this file's header records a burn lost to one of those.
//------------------------------------------------------------------------
wire [AVGW-1:0] nz_int  = prev_nz[NZW-1:NZF];     // integer part of nz
wire [AVGW+1:0] nz_gain = (NOISE_GAIN == 0) ? {2'b0, nz_int}
                                            : ({2'b0, nz_int} << NOISE_GAIN);

// Saturate rather than wrap: a wrap here would hand a NOISY block a TINY
// threshold, which is the exact opposite of the point and would read on
// screen as "the textured part of the scene is the only thing detected".
wire [AVGW-1:0] nz_thr  = (nz_gain[AVGW+1:AVGW] != 2'b00) ? {AVGW{1'b1}}
                                                          : nz_gain[AVGW-1:0];

wire [AVGW-1:0] thr_eff = (NOISE_EN == 0)              ? MOTION_THRESH[AVGW-1:0]
                        : (nz_thr > MOTION_THRESH[AVGW-1:0]) ? nz_thr
                                                          : MOTION_THRESH[AVGW-1:0];

wire moved = (absdiff > thr_eff);

//------------------------------------------------------------------------
// Seeding.  Two frames after reset the background is loaded outright rather
// than filtered towards, and the sticky counters are pinned at zero so the
// undefined RAM contents cannot draw a box on the way past.  See SEEDING.
//
// 2026-09-20: THE SAME MECHANISM NOW SERVES THE MOVING CAMERA.  A view change
// invalidates all 225 stored backgrounds in exactly the way power-up does --
// every one of them describes a different piece of the world -- so the
// recovery is the same one, and md_blind reloads the counter instead of
// letting it run down.  Nothing about the seeding itself changed; it simply
// stopped being reachable only from reset.
//
// The counter is RELOADED (not held) while blind, so the two seeded frames
// are counted from the LAST blind frame rather than the first.  That is what
// makes a long pan cost the same 2-frame recovery as a short one.
//------------------------------------------------------------------------
reg [1:0] seed_cnt;

// Driven in [5c], which is where tot_n is declared.  Declared here because
// this is the first place it is read.
wire md_blind;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n)          seed_cnt <= 2'd2;
    else if (frame_tick) begin
        if      (md_blind)          seed_cnt <= 2'd2;
        else if (seed_cnt != 2'd0)  seed_cnt <= seed_cnt - 2'd1;
    end
end

wire bg_seed = (seed_cnt != 2'd0);

// Reload to 3 on motion, otherwise decay one frame at a time -- or, with
// PERSIST, count up as well as down.  See TEMPORAL PERSISTENCE.
//
// Both directions saturate rather than wrap, which on a 2-bit counter is not
// a detail: a wrap at either end turns the armed state into a flicker at the
// frame rate, and it would look exactly like the noise this is here to
// remove.
localparam [1:0] PERS2 = PERSIST[1:0];      // the threshold, as a 2-bit compare

wire [1:0] cnt_up = (prev_cnt == 2'd3) ? 2'd3 : (prev_cnt + 2'd1);
wire [1:0] cnt_dn = (prev_cnt == 2'd0) ? 2'd0 : (prev_cnt - 2'd1);

wire [1:0] new_cnt = bg_seed        ? 2'd0 :
                     (PERSIST == 0) ? (moved ? 2'd3   : cnt_dn)
                                    : (moved ? cnt_up : cnt_dn);

//------------------------------------------------------------------------
// The IIR, split across two clocks: subtract here, shift-and-add on the next
// edge.  Everything the write needs is carried forward alongside it.
//
// cur_bg is the current average with the fractional bits zeroed -- the same
// quantity as bg, in the same format, so the difference is meaningful.
//------------------------------------------------------------------------
wire [BGW-1:0] cur_bg = {wr_avg_r, {BGF{1'b0}}};

reg                wr_pend_d;
reg [7:0]          wr_addr_d;
reg [1:0]          cnt_d;
reg [BGW-1:0]      bg_d, cur_d;
reg signed [BGW:0] err_d;
reg                seed_d;

// The noise estimate's pipeline stage, alongside bg's and for the same
// reason: prev_nz comes out of the RAM one clock before the write-back.
reg [NZW-1:0]      nz_d;
reg [AVGW-1:0]     ad_d;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        wr_pend_d <= 1'b0;
        wr_addr_d <= 8'd0;
        cnt_d     <= 2'd0;
        bg_d      <= {BGW{1'b0}};
        cur_d     <= {BGW{1'b0}};
        err_d     <= {(BGW+1){1'b0}};
        seed_d    <= 1'b0;
        nz_d      <= {NZW{1'b0}};
        ad_d      <= {AVGW{1'b0}};
    end else begin
        wr_pend_d <= wr_pend;
        wr_addr_d <= wr_addr_r;
        cnt_d     <= new_cnt;
        bg_d      <= prev_bg;
        cur_d     <= cur_bg;
        err_d     <= $signed({1'b0, cur_bg}) - $signed({1'b0, prev_bg});
        seed_d    <= bg_seed;
        nz_d      <= prev_nz;
        ad_d      <= absdiff;
    end
end

// Truncating (floor) arithmetic shift.  Rounding is not worth a gate here: the
// filter is a low-pass and a half-LSB bias on the increment is a half-LSB bias
// on bg, which is 1/64 of a count against a threshold of five.
wire signed [BGW:0] bg_inc = err_d >>> BG_SHIFT;

// NO CLAMP, AND THAT IS PROVEN NOT ASSUMED.  bg_inc is err/16 and err is
// cur - bg, so bg + bg_inc always lands strictly between bg and cur, both of
// which are inside [0, 2^BGW).  An IIR towards a bounded target cannot leave
// the interval its two operands span, so neither the add nor the subtract can
// wrap -- which is why a saturating add would be dead logic on the widest
// path in this module.
wire [BGW-1:0] bg_next = seed_d ? cur_d : (bg_d + bg_inc[BGW-1:0]);

//------------------------------------------------------------------------
// THE NOISE TRACKER -- 2026-09-21 night.  nz walks one bounded step per
// frame towards this block's absolute deviation, so it settles at the
// block's typical deviation: its noise floor.  See NZ_STEP for why the step
// is bounded rather than proportional, and NOISE_GAIN for what it is for.
//
// EVERY FRAME, UNCONDITIONALLY.  There is no "learn only while quiet" gate;
// NZ_STEP's comment records why such a gate cannot work.  Outlier immunity
// comes from the step bound instead.
//
// Seeding: bg_seed loads nz to the current deviation for the same reason it
// loads bg to the current average -- after a camera move every stored value
// describes a different piece of the world.  absdiff against a freshly
// seeded bg is near zero, so this starts nz LOW and the MOTION_THRESH floor
// carries the second or so while it climbs.  Low rather than high is the
// safe direction: for that second the detector is more sensitive than
// intended, never less.
//------------------------------------------------------------------------
wire [NZW-1:0] nz_tgt = {ad_d, {NZF{1'b0}}};       // absdiff, in nz units

// Saturating up/down by NZ_STEP.  Both ends need the explicit test: nz is
// unsigned, so the decrement borrows rather than going negative, and a wrap
// at the bottom would hand a quiet block a HUGE threshold -- silently
// switching the detector off over most of the frame, which is the worst
// failure this file could have and the one hardest to see in a photograph.
wire [NZW:0] nz_p = {1'b0, nz_d} + NZ_STEP[NZW:0];
wire [NZW:0] nz_m = {1'b0, nz_d} - NZ_STEP[NZW:0];

wire [NZW-1:0] nz_walk = (nz_tgt > nz_d)
                       ? (nz_p[NZW] ? {NZW{1'b1}} : nz_p[NZW-1:0])
                       : (nz_m[NZW] ? {NZW{1'b0}} : nz_m[NZW-1:0]);

wire [NZW-1:0] nz_next = (NOISE_EN == 0) ? {NZW{1'b0}}
                       : seed_d          ? nz_tgt
                                         : nz_walk;

always @(posedge clk) begin
    if (wr_pend_d) mstate[wr_addr_d] <= {cnt_d, bg_next, nz_next};
    // blk_addr_rd, not blk_addr: the model of the content that is HERE NOW,
    // which during a pan was stored somewhere else.  See GMC_EN.  The WRITE
    // above still uses wr_addr_d, derived from the uncompensated blk_addr,
    // so each block's updated model lands in its own slot.
    q <= mstate[blk_addr_rd];
end

//------------------------------------------------------------------------
// [5] Spatial guard.
//
// WHY THIS IS NOT ANOTHER THRESHOLD (2026-09-05)
//   Bench: "roughly right, but it sometimes boxes a part of the picture that
//   is not moving."  MIN_BLOCKS does not fix that and never could -- it is a
//   test on HOW MANY blocks moved, not on WHERE they are.  Once a real gesture
//   has put three blocks over the line the frame is believed, and from then on
//   one false block anywhere on screen is folded into the same running min/max
//   and drags a corner of the box out to meet it.  A single noisy block in the
//   opposite corner is therefore enough to enclose a quiet quarter of the
//   picture, and the 3-frame sticky counter keeps it enclosed for three frames
//   after the block stopped firing.
//
//   Raising MOTION_THRESH again is the move that looks obvious and is wrong:
//   it is zero-sum (08-12 already spent 1 -> 2 and bought twitchiness down at
//   the cost of sensitivity), and it cannot distinguish a false block from a
//   real one because both are single blocks over a level.
//
//   What does distinguish them is that REAL MOTION IS CONTIGUOUS.  An object
//   large enough to matter covers neighbouring blocks; sensor noise does not
//   correlate between neighbours.  So a block is folded into the box only if a
//   block next to it is active too.
//
// WHY ONLY LEFT AND ABOVE
//   Those are the two neighbours already known when a block finishes in raster
//   order, so the test costs no extra line of latency and no line buffer
//   beyond one 15-bit row register.  The cost is that the top-left block of
//   any moving region has neither neighbour and is dropped, so the box can
//   come up one block short at that corner -- which is a far better failure
//   than a box stretched across still picture, and invisible next to the
//   128x72 block granularity the box already has.
//
//   Consequence worth knowing: an isolated single-block movement now never
//   boxes at all.  MIN_BLOCKS = 3 already meant it did not, so nothing that
//   used to draw a box has stopped drawing one.
//------------------------------------------------------------------------
// ...and with PERSIST, a block is active once its counter has REACHED the
// threshold rather than merely left zero.  Everything downstream -- the
// neighbour test, the row map, mv_valid, and so every box and the block
// count on the OSD -- reads this one wire, so the filter applies to the
// published boxes and to `moved_blocks` alike.
//
// ⚠ THAT IS DELIBERATE AND IT IS A CHANGE OF MEANING FOR THE OSD NUMBER.
// Other gates in this file (DOM_SHIFT, BOX_FILL_SHIFT) were built to gate
// PUBLICATION only, so that moved_blocks stayed a raw measurement and the
// pair "big number, no box" stayed diagnostic -- mdtb T7b pins that for
// DOM_SHIFT.  This one gates MEASUREMENT, because a block that has moved
// once is not evidence of anything and counting it was part of why the
// readings could not be interpreted.  Expect every count on the OSD to come
// down; that is the filter working, not sensitivity lost.
wire blk_active = (PERSIST == 0) ? (new_cnt != 2'd0)
                                 : (new_cnt >= PERS2);

//===========================================================================
// [4b] THE GLOBAL MOTION ESTIMATOR -- 2026-09-21 night.  See GMC_EN.
//
// PROJECTIONS.  col_acc[i] is the sum of the 15 block averages in column i,
// row_acc[j] the sum along row j.  Both are accumulated as blocks complete,
// one add per block, using the average this module already computes -- so
// the measurement costs 225 adds per frame spread over the visible frame and
// nothing at all in the blanking interval.
//
// ⚠ WHY PROJECTIONS RATHER THAN A 2-D SEARCH.  A direct search over ±2
// blocks in both axes is 25 candidate displacements, each a sum over 225
// blocks: 5,625 terms.  The projections make it two independent 1-D
// searches, 5 candidates of 11 terms each per axis: 110 terms.  A horizontal
// translation moves the column projection and leaves the row projection
// almost unchanged, which is exactly the separability that makes this valid,
// and it is valid for TRANSLATION only -- a rotating or zooming image is not
// estimated by this and will read as some translation or as nothing.  A pan
// and a tilt are translations, which is what a gimbal produces.
//
// 15 six-bit values sum to at most 945, so 10 bits.
//===========================================================================
localparam integer PJW = 10;

reg [PJW-1:0] col_acc [0:N_COLS-1];
reg [PJW-1:0] row_acc [0:N_COLS-1];
reg [PJW-1:0] col_prv [0:N_COLS-1];
reg [PJW-1:0] row_prv [0:N_COLS-1];

// Declared here, driven by the correlator below: the last clock of the
// correlation window, where the accumulators are retired.
wire g_done;

integer pj;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        for (pj = 0; pj < N_COLS; pj = pj + 1) begin
            col_acc[pj] <= {PJW{1'b0}};
            row_acc[pj] <= {PJW{1'b0}};
        end
    //--------------------------------------------------------------------
    // ⚠ NOT CLEARED AT frame_tick, AND THIS WAS A BUG IN THE FIRST DRAFT.
    // The correlator reads col_acc/row_acc for 55 clocks AFTER frame_tick,
    // so clearing them on that pulse -- the obvious place, and where every
    // other per-frame accumulator in this module is cleared -- hands the
    // correlator 15 zeros and an estimate computed from nothing.  The clear
    // and the snapshot into col_prv/row_prv both happen at g_done, the last
    // clock of the correlation window, which is the first moment the data is
    // no longer needed.
    //--------------------------------------------------------------------
    end else if (g_done) begin
        for (pj = 0; pj < N_COLS; pj = pj + 1) begin
            col_acc[pj] <= {PJW{1'b0}};
            row_acc[pj] <= {PJW{1'b0}};
        end
    end else if (wr_pend && (GMC_EN != 0)) begin
        col_acc[wr_xt_r] <= col_acc[wr_xt_r] + {{(PJW-AVGW){1'b0}}, wr_avg_r};
        row_acc[wr_yt_r] <= row_acc[wr_yt_r] + {{(PJW-AVGW){1'b0}}, wr_avg_r};
    end
end

reg [N_COLS-1:0] row_above;      // active map of the block row above
reg [N_COLS-1:0] row_this;       // ...being accumulated for the current one
reg              left_active;    // previous block in this row

wire neighbour_ok = left_active | row_above[wr_xt_r];

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        row_above   <= {N_COLS{1'b0}};
        row_this    <= {N_COLS{1'b0}};
        left_active <= 1'b0;
    end else if (frame_tick) begin
        row_above   <= {N_COLS{1'b0}};
        row_this    <= {N_COLS{1'b0}};
        left_active <= 1'b0;
    end else if (wr_pend) begin
        row_this[wr_xt_r] <= blk_active;
        left_active       <= blk_active;

        // Last block of a row: this row becomes the row above, and the new row
        // starts empty with no left neighbour.  row_this on the right-hand
        // side is still the pre-update value, so the current block has to be
        // merged in by hand -- the bit assignment below overrides the whole
        // -word one above it, which is exactly what is wanted here.
        if (wr_xt_r == TILE_MAX) begin
            row_above           <= row_this;
            row_above[TILE_MAX] <= blk_active;
            row_this            <= {N_COLS{1'b0}};
            left_active         <= 1'b0;
        end
    end
end

//------------------------------------------------------------------------
// [5b] Bounding box.  One pulse per finished block that is still counted as
// moving AND has a moving neighbour, folded into a running min/max as the
// frame streams past.
//------------------------------------------------------------------------
reg       mv_valid;
reg [3:0] mv_xt, mv_yt;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        mv_valid <= 1'b0; mv_xt <= 4'd0; mv_yt <= 4'd0;
    end else begin
        mv_valid <= wr_pend && blk_active && neighbour_ok;
        mv_xt    <= wr_xt_r;
        mv_yt    <= wr_yt_r;
    end
end

//===========================================================================
// [4c] THE DISPERSION MEASUREMENT -- 2026-09-22.  See DISP_EN.
//
// Two seen-masks and two counters over the SAME mv_valid stream the boxes are
// built from, so the veto judges exactly the blocks the boxes are made of --
// not the raw `moved` bits, which PERSIST and neighbour_ok have already
// filtered.  Reading the unfiltered bits here would veto on sensor noise.
//
// The counters are per-frame and cleared at frame_tick.  frame_tick reads
// them in the same branch that clears them, non-blocking, so it sees the
// completed frame -- the identical construction tot_n uses two sections down,
// and the reason neither needs a separate snapshot register.
//
// One bit test and one 4-bit increment per mv_valid, and mv_valid pulses are
// at least BLK_W clocks apart (a block completes on its last pixel, and the
// next block in the row completes BLK_W pixels later).  Nothing here is close
// to a timing path.
//===========================================================================
reg [N_COLS-1:0] col_seen;
reg [N_COLS-1:0] row_seen;
reg [3:0]        ncol, nrow;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        col_seen <= {N_COLS{1'b0}};
        row_seen <= {N_COLS{1'b0}};
        ncol     <= 4'd0;
        nrow     <= 4'd0;
    end else if (frame_tick) begin
        col_seen <= {N_COLS{1'b0}};
        row_seen <= {N_COLS{1'b0}};
        ncol     <= 4'd0;
        nrow     <= 4'd0;
    end else if (mv_valid) begin
        if (!col_seen[mv_xt]) begin
            col_seen[mv_xt] <= 1'b1;
            ncol            <= ncol + 4'd1;
        end
        if (!row_seen[mv_yt]) begin
            row_seen[mv_yt] <= 1'b1;
            nrow            <= nrow + 4'd1;
        end
    end
end

wire disp_veto = (DISP_EN != 0) && (ncol >= DISP_NC) && (nrow >= DISP_NR);

//===========================================================================
// [4d] THE SOFT DISPERSION LEVEL -- 2026-09-22 evening.  See DISP_ACQ_NC.
//
// Same two counters, a second pair of thresholds, and it goes NOWHERE except
// [5f].  It is deliberately not folded into disp_veto / md_blind: a soft
// frame keeps its boxes, keeps its background, and keeps feeding the green
// overlay.  Only the tracker's acquisition decision and gate width change.
//
// Both axes again, and "and" again, for the identical reason the hard pair
// gives: a person walking past fills one column and many rows, and an "or"
// here would stop the tracker ever acquiring the one target that matters
// most.
//===========================================================================
wire disp_soft = (DISP_EN != 0) && (DISP_ACQ_NC != 4'd0) && (DISP_ACQ_NR != 4'd0)
                 && (ncol >= DISP_ACQ_NC) && (nrow >= DISP_ACQ_NR);

//===========================================================================
// [4e] THE ACQUISITION LOCKOUT COUNTER -- 2026-09-24.  See CAM_HOLD for the
// argument; this is only the plumbing.
//
// ⚠ UPDATED IN A frame_tick BRANCH AND NOWHERE ELSE, because disp_veto is
// combinational off ncol/nrow and frame_tick is the branch that CLEARS them.
// Non-blocking assignment means this branch reads the value the frame just
// finished with -- the identical trap blocks_r / cam_motion_r / dom_min are
// all written against, and the one that silently made the tracker's first
// use of disp_soft always false.
//
// ⚠ RELOADED, NOT INCREMENTED: every vetoed frame restarts the full window,
// so a pan's lockout ends CAM_HOLD frames after its LAST vetoed frame rather
// than after its first.  Same shape as seed_cnt, and for the same reason --
// what matters is how long ago the disturbance stopped.
//
// Costs one 4-bit counter in the blanking domain.  The pixel path is
// untouched, which §5.5 (clk0 worst slack +0.034 ns) makes a hard
// requirement rather than a preference.
//===========================================================================
reg [3:0] cam_hold_r;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n)
        cam_hold_r <= 4'd0;
    else if (frame_tick)
        cam_hold_r <= disp_veto ? CAM_HOLD
                    : ((cam_hold_r != 4'd0) ? (cam_hold_r - 4'd1) : 4'd0);
end

// Read at seq TUPD, which is in the SAME blanking interval and therefore
// after the load above: the vetoed frame itself already cannot acquire
// (t_blind), and the window covers the CAM_HOLD frames that follow it.
wire acq_locked = (cam_hold_r != 4'd0);

//------------------------------------------------------------------------
// [5c] CONNECTED COMPONENTS ON THE BLOCK GRID -- 2026-09-09.
//
// WHAT WAS WRONG WITH ONE BOX.  Until now this section was a single running
// min/max over every moving block in the frame, which is a bounding box of
// the UNION of all motion rather than of any one moving thing.  The 09-08
// bench found it immediately: drag a mouse left to right and the box spans
// the whole path, because the vacated position is still reporting motion (the
// IIR takes 2^BG_SHIFT frames to forget it) while the new one already is.  So
// the box was correct and useless -- "原来框的地方还在" is not a stale box, it
// is one box drawn around two true detections.
//
// Two things follow, and they are the same fix: separate the clusters, and
// the vacated one becomes a box of its own that shrinks and vanishes on the
// IIR's own time constant instead of inflating its neighbour.
//
// THE ALGORITHM -- BOUNDING-BOX ADJACENCY MERGE, not union-find.  Each active
// block, as it completes, is tested against every open box:
//
//     adjacent(B, cell) = B.y1 + 1 >= yt      (B reached the row above)
//                       & B.x0     <= xt + 1  (and overlaps in x, with the
//                       & B.x1 + 1 >= xt       diagonal slack 8-connectivity
//                                              needs)
//
// no match      -> the cell opens a new box
// one match     -> the box grows to include the cell
// several       -> those boxes and the cell become ONE box, and the spare
//                  slots are freed
//
// WHY NOT UNION-FIND.  ccl_blob needs it because it labels 2 million pixels
// and cannot revisit them.  Here the whole picture is 225 cells and a box is
// four 4-bit numbers, so a box can simply absorb another box outright -- the
// merge that union-find defers to a relaxation pass is done on the spot, in
// the arithmetic that was going to run anyway.
//
// WHAT IT COSTS: THE MERGE IS BY BOUNDING BOX, SO IT CAN OVER-MERGE.  Two
// genuinely separate clusters whose boxes are adjacent are joined even if no
// two of their cells touch.  It can never over-SPLIT, which is the direction
// that would matter.  And at 128x72 px per cell, two clusters close enough to
// trip this are within one block of each other on screen -- at which point
// one box around both is arguably the better picture anyway.
//
// TIMING.  A block completes every BLK_W = 128 clocks (blocks finish along the
// last line of a block row), so this has 128 clocks to do work that takes two.
// That slack is why the adjacency tests are registered before the reduction
// runs: the tests are computed from the table, the reduction rewrites it, and
// putting them in one cycle would put the deepest arithmetic in this module on
// the pixel clock for no reason.  The table cannot change between the two
// stages because a write only happens on mrg_v, 128 clocks apart.
//
// If the reduction ever does show up in a timing report, it is a 4-deep
// compare-mux chain over NBOX slots and there are 126 spare clocks to split it
// across -- start there, not at NBOX.
//
// NBOX itself is now a module parameter (it sizes the exported box ports); this
// block is still where the argument for its value lives.
//------------------------------------------------------------------------

reg [3:0] bx0 [0:NBOX-1];
reg [3:0] bx1 [0:NBOX-1];
reg [3:0] by0 [0:NBOX-1];
reg [3:0] by1 [0:NBOX-1];
reg [7:0] bn  [0:NBOX-1];
reg [NBOX-1:0] bvalid;

reg [7:0] tot_n;                    // every counted block, for the OSD
reg       box_ovf;                  // a cluster was dropped for want of a slot

//------------------------------------------------------------------------
// Stage 1: which open boxes is this cell adjacent to.
//
// Widened to 5 bits throughout.  yt and xt reach 0, so yt-1 and xt-1 underflow
// on 4 bits and would compare as 15 -- every box would look adjacent along the
// top and left edges of the picture, which is where a real object entering
// frame arrives. Written as y1+1 >= yt rather than y1 >= yt-1 for that reason.
//------------------------------------------------------------------------

reg [NBOX-1:0] hit;
integer h;

// 6 bits, not 5: a box edge is 4 bits (max 14) and the gap is added to it,
// so the sum leaves 5-bit range as soon as anyone raises a gap past 17.
// The underflow argument above is why the gap is ADDED to the box side and
// never subtracted from the cell side.
//
// gy6 appears ONCE and gx6 TWICE, and that asymmetry is the raster order, not
// an oversight: cells arrive top-to-bottom, so an open box can only ever be
// ABOVE the cell and the Y test is one-sided.  In X a box can be on either
// side, so the gap is allowed at both edges.
wire [5:0] gx6   = {1'b0,  MERGE_GAP_X};
wire [5:0] gy6   = {1'b0,  MERGE_GAP_Y};
wire [5:0] c_xt6 = {2'b00, mv_xt};
wire [5:0] c_yt6 = {2'b00, mv_yt};

always @(*) begin
    for (h = 0; h < NBOX; h = h + 1)
        hit[h] = bvalid[h]
              && (({2'b00, by1[h]} + gy6) >= c_yt6)
              && (({2'b00, bx0[h]}      ) <= (c_xt6 + gx6))
              && (({2'b00, bx1[h]} + gx6) >= c_xt6);
end

reg [NBOX-1:0] hit_r;
reg [3:0]      m_xt, m_yt;
reg            mrg_v;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        hit_r <= {NBOX{1'b0}}; m_xt <= 4'd0; m_yt <= 4'd0; mrg_v <= 1'b0;
    end else begin
        hit_r <= hit;
        m_xt  <= mv_xt;
        m_yt  <= mv_yt;
        mrg_v <= mv_valid;
    end
end

//------------------------------------------------------------------------
// Stage 2: the merged box, and where it goes.
//
// The reduction starts from the CELL rather than from a sentinel, so a cell
// that hit nothing already reads out as a correct 1x1 box and the no-match
// case needs no separate arithmetic.
//------------------------------------------------------------------------
reg [3:0] mg_x0, mg_x1, mg_y0, mg_y1;
reg [8:0] mg_n;
integer r;

always @(*) begin
    mg_x0 = m_xt; mg_x1 = m_xt;
    mg_y0 = m_yt; mg_y1 = m_yt;
    mg_n  = 9'd1;
    for (r = 0; r < NBOX; r = r + 1) begin
        if (hit_r[r]) begin
            if (bx0[r] < mg_x0) mg_x0 = bx0[r];
            if (bx1[r] > mg_x1) mg_x1 = bx1[r];
            if (by0[r] < mg_y0) mg_y0 = by0[r];
            if (by1[r] > mg_y1) mg_y1 = by1[r];
            mg_n = mg_n + {1'b0, bn[r]};
        end
    end
end

// The destination slot: the lowest box this cell hit, or failing that the
// lowest free one.  Both are priority selects over NBOX bits.
//
// A box that the raster has passed -- y1 more than one row back -- can never
// be hit again, but it is NOT free: it still has to be published at frame end.
// So the slots run out per FRAME, not per row, and box_ovf is how that is
// admitted rather than hidden. Dropping the cell is deliberate: the
// alternative is folding it into an unrelated box, which is the one-giant-box
// failure this section exists to remove.
// ⚠ WRITTEN OUT RATHER THAN LOOPED, and NBOX = 4 IS NOT A FREE KNOB.
//
// Two reasons, and neither is style.  The index is a 2-bit reg because that is
// what the box arrays are addressed by, so the width already assumes 4; and
// the looped form of this needs a part-select of the loop's `integer`, which
// is legal Verilog that vendor synthesis is not reliably good at.  An explicit
// priority chain is unambiguous to every tool and reads as exactly what it is.
//
// Raising NBOX means widening tgt and extending both chains here.  The rest of
// the section is written against the parameter and needs nothing.
reg [1:0] tgt;
reg       tgt_ok;

always @(*) begin
    // Prefer a box this cell actually hit; failing that, any free slot.
    if      (hit_r[0])   begin tgt = 2'd0; tgt_ok = 1'b1; end
    else if (hit_r[1])   begin tgt = 2'd1; tgt_ok = 1'b1; end
    else if (hit_r[2])   begin tgt = 2'd2; tgt_ok = 1'b1; end
    else if (hit_r[3])   begin tgt = 2'd3; tgt_ok = 1'b1; end
    else if (!bvalid[0]) begin tgt = 2'd0; tgt_ok = 1'b1; end
    else if (!bvalid[1]) begin tgt = 2'd1; tgt_ok = 1'b1; end
    else if (!bvalid[2]) begin tgt = 2'd2; tgt_ok = 1'b1; end
    else if (!bvalid[3]) begin tgt = 2'd3; tgt_ok = 1'b1; end
    else                 begin tgt = 2'd0; tgt_ok = 1'b0; end
end

//------------------------------------------------------------------------
// The published table, and the frame gate.
//
// MIN_BLOCKS stays a whole-frame test, exactly as before: it is the proven
// guard against a frame of sensor noise and nothing about splitting the boxes
// changes what it is for.  MIN_BOX_BLK is the new per-box one, and it is what
// keeps a two-cell noise pair that got past neighbour_ok from drawing its own
// small rectangle next to the real object.
//------------------------------------------------------------------------
reg [3:0] pbx0 [0:NBOX-1];
reg [3:0] pbx1 [0:NBOX-1];
reg [3:0] pby0 [0:NBOX-1];
reg [3:0] pby1 [0:NBOX-1];
reg [NBOX-1:0] pbvalid;

// ...and the same table after SIZE_FLOOR has grown the dominant box.  This is
// what is drawn and what is exported; pb* stays the raw measurement so the
// peak can be compared against it.  Built one clock after frame_tick -- see
// [5d].
reg [3:0] ebx0 [0:NBOX-1];
reg [3:0] ebx1 [0:NBOX-1];
reg [3:0] eby0 [0:NBOX-1];
reg [3:0] eby1 [0:NBOX-1];

// The block count of each published box, snapshot at publish time alongside
// the geometry.  The density test in [5d] needs the two to describe the same
// frame; see the assignment for what goes wrong if they do not.
reg [7:0] pbn [0:NBOX-1];

// The peak span of the dominant box in the current burst of motion, in
// blocks, as x1-x0 (so a single-block box is 0).  See SIZE_FLOOR.
reg [3:0] pk_w, pk_h;

reg [5:0] hold;
reg [7:0] blocks_r;

assign moved_blocks = blocks_r;

// The published boxes, flattened onto the port bus.  These are the eb*/ey*
// registers the green overlay reads below, unmodified -- see the port
// declaration for the units warning.
//
// 2026-09-20: eb* rather than pb*, so the exported box is still EXACTLY the
// box on screen now that SIZE_FLOOR can grow one of them.  The face detector
// treats these as candidate regions, and a region that is too large costs it
// nothing but a couple of extra scale slots, whereas one that disagrees with
// the picture is the kind of drift the original note was written to prevent.
genvar bxi;
generate
for (bxi = 0; bxi < NBOX; bxi = bxi + 1) begin : box_export
    assign box_x0[bxi*4 +: 4] = ebx0[bxi];
    assign box_x1[bxi*4 +: 4] = ebx1[bxi];
    assign box_y0[bxi*4 +: 4] = eby0[bxi];
    assign box_y1[bxi*4 +: 4] = eby1[bxi];
end
endgenerate
// pbshow, not pbvalid: published AND compact.  Declared in [5d]; the export
// and the overlay must agree, and a dispersed box is not a candidate region
// for the face chain either.
assign box_valid = pbshow;

//------------------------------------------------------------------------
// WHICH SLOT HOLDS THE BIGGEST CLUSTER -- tracked as the boxes grow rather
// than searched for at frame end.  See HOLD_BEST.
//
// Doing it incrementally is a timing decision.  A 4-way argmax over 8-bit
// counts at frame_tick is a two-level comparator tree in one clock, on the
// pclkx1 domain, in a design whose worst path has 0.1ns to spare.  One 8-bit
// compare per block event costs the same logic spread over 225 events that
// arrive 128 clocks apart, and there is nothing to get wrong about the timing.
//
// ⚠ THE COMPARE MUST BE >=, NOT >.  When cells merge, the absorbed slots are
// freed and their counts fold into mg_n -- so if best_i pointed at an absorbed
// slot, the only thing that keeps the pointer valid is that the merged box's
// count is at least as large and therefore takes the pointer on this same
// event.  With a strict > and two boxes of equal count merging, best_i would
// be left pointing at a slot that bvalid just cleared, and the hold would
// publish an empty rectangle from the previous frame.
//------------------------------------------------------------------------
reg [1:0] best_i;
reg [7:0] best_n;
reg [1:0] pbest;

// The dominance floor, combinational off best_n so it is the CURRENT frame's
// largest -- best_n is cleared in the same frame_tick branch that reads this,
// and non-blocking assignment means the read sees the pre-clear value.
wire [7:0] dom_min = (DOM_SHIFT == 0) ? 8'd0 : (best_n >> DOM_SHIFT);

//------------------------------------------------------------------------
// THE CAMERA-MOTION VETO.  tot_n is the whole frame's count and is cleared in
// the frame_tick branch, so like dom_min this is read there before the clear
// lands.  MAX_BLOCKS = 255 can never be exceeded (tot_n saturates at 255),
// which is the documented disable.
//------------------------------------------------------------------------
// 2026-09-22: two vetoes, OR'd, and they are complementary rather than
// redundant -- MAX_BLOCKS catches "too much moved", disp_veto catches "what
// moved is spread over the whole frame".  A pan across a flat scene passes
// the first and fails the second, which is the case the board photographs of
// 09-21 show and the reason the count threshold alone was never going to be
// enough.  See DISP_EN.
wire frame_vetoed = (tot_n > MAX_BLOCKS) || disp_veto;
assign md_blind   = md_inhibit | frame_vetoed;

reg cam_motion_r;
assign cam_motion = cam_motion_r;

// The soft verdict, latched on the same edge and for the same reason: ncol /
// nrow are cleared by frame_tick, so anything reading them later in the
// blanking interval (which is where [5f] runs) reads zero.  ⚠ This is the
// live-versus-registered trap the t_blind comment records; the first version
// of the tracker's use of it read `disp_soft` directly and was silently
// always false.
reg disp_soft_r;
assign cam_soft = disp_soft_r;

integer p;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        for (p = 0; p < NBOX; p = p + 1) begin
            bx0[p]  <= 4'd0; bx1[p]  <= 4'd0;
            by0[p]  <= 4'd0; by1[p]  <= 4'd0;
            bn[p]   <= 8'd0;
            pbx0[p] <= 4'd0; pbx1[p] <= 4'd0;
            pby0[p] <= 4'd0; pby1[p] <= 4'd0;
            pbn[p]  <= 8'd0;
        end
        bvalid   <= {NBOX{1'b0}};
        pbvalid  <= {NBOX{1'b0}};
        tot_n    <= 8'd0;
        box_ovf  <= 1'b0;
        hold     <= 6'd0;
        blocks_r <= 8'd0;
        best_i   <= 2'd0;
        best_n   <= 8'd0;
        pbest    <= 2'd0;
        blv      <= 1'b0;
        bst      <= 1'b0;
        cam_motion_r <= 1'b0;
        disp_soft_r  <= 1'b0;
    end else if (frame_tick) begin
        // Non-blocking, so this captures tot_n as it was before the clear
        // below in this same branch.
        blocks_r <= tot_n;

        cam_motion_r <= md_blind;
        disp_soft_r  <= disp_soft;

        // Default; the believed branch below is the only thing that raises it.
        blv <= 1'b0;

        // THE CAMERA MOVED.  Ahead of the MIN_BLOCKS gate, because this is not
        // a weaker version of it -- MIN_BLOCKS asks whether there is enough
        // evidence, and a pan has far too much.  Everything published is
        // dropped outright rather than held: HOLD_FRAMES bridges gaps in a
        // gesture, and there is no gesture here to bridge.  The background
        // re-seed that goes with this is up at seed_cnt.
        if (md_blind) begin
            pbvalid <= {NBOX{1'b0}};
            hold    <= 6'd0;
            // pk_w/pk_h are cleared by their own always block, on this same
            // condition -- see seq 6.

        // Believe this frame's measurement only if enough blocks agree.
        end else if (tot_n >= MIN_BLOCKS) begin
            for (p = 0; p < NBOX; p = p + 1) begin
                pbx0[p] <= bx0[p]; pbx1[p] <= bx1[p];
                pby0[p] <= by0[p]; pby1[p] <= by1[p];
                // Two floors, and they answer different questions: is this
                // cluster big enough to be an object at all (MIN_BOX_BLK),
                // and is it big enough RELATIVE to the biggest thing in the
                // frame to be a separate one (dom_min).  See DOM_SHIFT.
                pbvalid[p] <= bvalid[p] && (bn[p] >= MIN_BOX_BLK)
                                        && (bn[p] >= dom_min);

                // ⚠ THE BLOCK COUNT HAS TO BE SNAPSHOT WITH THE GEOMETRY.
                // bn[] is live: it is rewritten by every mrg_v, including
                // the one or two that happen on a sub-threshold frame while
                // the hold is bridging.  pb* is NOT rewritten on those
                // frames, so a density test that read bn[] directly would,
                // on every held frame, divide the last believed frame's AREA
                // by the current frame's COUNT -- and suppress the held box
                // for a reason that is pure bookkeeping.
                pbn[p] <= bn[p];
            end
            pbest <= best_i;
            hold  <= HOLD_FRAMES;

            // THE PEAK ITSELF IS UPDATED AT seq 6, NOT HERE -- it has to wait
            // for the density verdict, see [5d].  What is captured here is
            // the two facts that branch cannot reconstruct later: that this
            // frame was believed, and that `hold` was 0 BEFORE the reload on
            // the line above, which is what "a new burst starts now" means.
            blv <= 1'b1;
            bst <= (hold == 6'd0);
        end else if (hold != 6'd0) begin
            hold <= hold - 6'd1;

            // The bridge.  Collapse to the strongest box and leave the
            // geometry alone -- pbx*/pby* are not rewritten, so this is a
            // mask over what is already published and cannot move a box.
            // AND-ing with the old pbvalid keeps it from resurrecting a slot
            // MIN_BOX_BLK had rejected, and makes repeated application on
            // every held frame a no-op after the first.
            if (HOLD_BEST != 0)
                pbvalid <= pbvalid & ({{(NBOX-1){1'b0}}, 1'b1} << pbest);
        end

        bvalid  <= {NBOX{1'b0}};
        tot_n   <= 8'd0;
        box_ovf <= 1'b0;
        best_i  <= 2'd0;
        best_n  <= 8'd0;

    //--------------------------------------------------------------------
    // THE BOX MERGE, one pair per clock through blanking.  See BOX_GAP_X.
    //
    // This branch sits between frame_tick and mrg_v and cannot race either:
    // seq only leaves 0 on the clock AFTER frame_tick, and it is back to 0
    // long before the next visible pixel, which is the only time mrg_v can
    // pulse.
    //
    // The union goes into the LOWER slot and the upper one's pbvalid is
    // cleared -- pbvalid is what every reader tests, so an absorbed slot
    // needs no separate flag.
    //
    // ⚠ pbest HAS TO FOLLOW THE ABSORB, and forgetting this would be a
    // silent bug rather than a visible one.  pbest indexes the dominant box
    // for target_x/target_y -- the coordinates the gimbal controller will
    // steer on -- and for target_valid and the size floor's export
    // override.  If the dominant slot is the one absorbed, pbest would point
    // at a slot whose pbvalid just went low: target_valid drops and the
    // steering target vanishes on exactly the frames where the merge did its
    // job.  Retargeting it to the surviving slot keeps the target pointing at
    // the merged box, which is the larger and more correct one.
    //--------------------------------------------------------------------
    end else if (m_step) begin
        if (m_hit) begin
            pbx0[m_a] <= mu_x0; pbx1[m_a] <= mu_x1;
            pby0[m_a] <= mu_y0; pby1[m_a] <= mu_y1;
            pbn[m_a]  <= mu_n;
            pbvalid[m_b] <= 1'b0;
            if (pbest == m_b) pbest <= m_a;
        end

    end else if (mrg_v) begin
        if (tot_n != 8'hFF) tot_n <= tot_n + 8'd1;

        if (!tgt_ok) begin
            box_ovf <= 1'b1;
        end else begin
            // Absorbed boxes release their slots. Written before the
            // destination so the destination's own bit survives -- a later
            // bit assignment to the same register overrides an earlier one.
            for (p = 0; p < NBOX; p = p + 1)
                if (hit_r[p]) bvalid[p] <= 1'b0;

            bx0[tgt] <= mg_x0; bx1[tgt] <= mg_x1;
            by0[tgt] <= mg_y0; by1[tgt] <= mg_y1;
            bn[tgt]  <= mg_n[8] ? 8'hFF : mg_n[7:0];
            bvalid[tgt] <= 1'b1;

            // Track the biggest cluster as it grows -- see the note above
            // this always block for why >= and not >.
            if (mg_n[8] || (mg_n[7:0] >= best_n)) begin
                best_i <= tgt;
                best_n <= mg_n[8] ? 8'hFF : mg_n[7:0];
            end
        end
    end
end

//===========================================================================
// [5d] THE BLANKING-TIME SEQUENCER -- density, then peak, then size floor.
//
// Everything here runs AFTER the frame has ended, stepped one slot per clock
// by `seq`, and that is a TIMING decision rather than a structural one.
//
// ⚠ THE MISTAKE THIS EXISTS TO AVOID, written down because it was made twice
// while designing it: "there are 11,000 clocks of blanking, so this has
// plenty of time" IS WRONG FOR COMBINATIONAL LOGIC.  A wide computation in a
// single-cycle branch has one clock to settle no matter how idle the clocks
// either side of it are.  Slack only becomes usable by SPREADING THE WORK
// OVER CLOCKS, which is what the sequencer does.  In a design whose worst
// path has 34ps to spare (handoff section 5.5) that distinction is the whole
// reason the box-area multiply is not simply written inline.
//
//   seq 1..4  stage 1: area of slot seq-1        (the multiply)
//   seq 2..5  stage 2: density verdict for slot seq-2
//   seq 6     the peak update -- needs the verdict, see below
//   seq 7     the size floor, into eb*/ey*
//
// Seven clocks, starting at the first clock of blanking, against a blanking
// interval three orders of magnitude longer and a first visible pixel that
// is further away still.
//
// ⚠ WHY THE PEAK UPDATE MOVED HERE FROM frame_tick -- 2026-09-21, and this
// is a REAL BUG FIX, not a tidy-up.  The 09-20 build raised the peak from
// any believed frame, so a single frame of camera shake -- which the count
// veto did not catch, see MAX_BLOCKS -- merged into one near-full-frame box
// and set the peak to the whole grid.  `hold` is reloaded by every believed
// frame, so the burst never ended, so the peak was never reloaded, and from
// then on EVERY box was grown to the full frame.  That is the "超大框和全屏框"
// the board photos show, and it was this module inflating its own output.
//
// The peak may now only be raised by a box that PASSED THE DENSITY TEST, so
// a dispersed camera-motion box cannot poison it.  That verdict does not
// exist until stage 2 has run, which is why the update sits at seq 6 and not
// in the frame_tick bundle.
//===========================================================================
// ⚠ 2026-09-21 NIGHT: THE SCHEDULE GREW A MERGE WINDOW AT THE FRONT, and
// the ORDER is the correctness argument, not the count of clocks.  The box
// merge rewrites pb* and invalidates absorbed slots, so everything that
// READS pb* -- the area multiply, the density verdict, the peak, the export
// -- has to come after the last merge clock.  Putting the merge anywhere but
// first would have the density test judging boxes that are about to be
// replaced, which is the same class of mistake as the pbn[] snapshot note
// below: two stages describing different versions of the same frame.
//
//   seq 1..M      the box merge, one pair per clock       (M = 6*BOX_ROUNDS)
//   seq M+1..M+4  stage 1: area of slot seq-M-1
//   seq M+2..M+5  stage 2: density verdict for slot seq-M-2
//   seq M+6       the peak update
//   seq M+7       the size floor, into eb*/ey*
//
// At BOX_ROUNDS = 2 that is 19 clocks against ~11,000 of blanking -- and the
// 11,000 figure is the REAL one, measured, not the 99,000 that sat wrong in
// five files for three months (handoff §3.-8).  Even so this is three orders
// of magnitude of headroom, and the reason it is spread over clocks at all
// is the one written above: slack between clocks does nothing for a wide
// combinational path inside one clock.
localparam integer MPAIRS = (NBOX * (NBOX - 1)) / 2;      // 6 at NBOX = 4
localparam integer MSEQ   = MPAIRS * BOX_ROUNDS;          // 12 at 2 rounds

// The correlation window runs AFTER the box work, seq MSEQ+8 .. MSEQ+8+54.
// Order does not matter between the two -- the estimator's result is used by
// the NEXT frame, and it reads projections nothing else touches -- so it is
// placed last simply to keep the box schedule's indices readable.
//
// 11 terms x 5 offsets.  The term index is restricted to [2, 12] so that
// i-d stays inside [0, 14] for every offset in [-2, +2]: EVERY OFFSET THEN
// SUMS EXACTLY 11 TERMS and the five SADs are directly comparable.  The
// alternative -- summing whatever is in range and normalising -- needs a
// divide, and without one the offsets with fewer terms win by default, which
// biases the estimate towards the largest shift.  Trimming the window is the
// same fix for free.
localparam integer GTERMS = N_COLS - 4;                   // 11
localparam integer GSEQ   = GTERMS * 5;                   // 55
localparam integer GSTART = MSEQ + 8;
localparam integer SEQ_END = GSTART + GSEQ - 1;           // 74 at defaults

//---------------------------------------------------------------------------
// 2026-09-22: the tracker window, appended after the correlator.  NBOX clocks
// of association (one candidate slot per clock) then one update then one
// geometry clock.
//
// ⚠ IT HAS TO BE AFTER THE DENSITY VERDICT, which is why it is not squeezed
// into the gap at MSEQ+6..MSEQ+7.  The tracker associates against pbshow =
// pbvalid & dense, and `dense` is not complete until stage 2 has walked all
// four slots at MSEQ+2..MSEQ+5.  Placing it earlier would associate against
// a half-updated verdict -- the same "two stages describing different
// versions of the same frame" mistake the pbn[] snapshot note warns about.
//
// It runs whether or not GMC_EN is set: seq counts through the correlator
// window regardless, only g_step is gated, so there is no second schedule to
// keep consistent.  80 clocks of an 11,000-clock blanking interval.
//---------------------------------------------------------------------------
localparam integer TSTART   = SEQ_END + 1;                // 75 at defaults
localparam integer TUPD     = TSTART + NBOX;              // 79
localparam integer TGEO     = TUPD + 1;                   // 80
localparam integer SEQ_LAST = TGEO;

reg [7:0] seq;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n)                    seq <= 8'd0;
    else if (frame_tick)           seq <= 8'd1;
    else if (seq == 8'd0)          seq <= 8'd0;
    else if (seq == SEQ_LAST[7:0]) seq <= 8'd0;
    else                           seq <= seq + 8'd1;
end

//------------------------------------------------------------------------
// THE MERGE WINDOW.  One pair per clock; mpi walks the pair list and wraps,
// so BOX_ROUNDS sweeps need no second counter.
//
// The pair order is (0,1) (0,2) (0,3) (1,2) (1,3) (2,3) -- slot 0 against
// everything first.  That is deliberate: a merge writes the union into the
// LOWER slot, so visiting the low slots first lets one slot accumulate a
// whole chain inside a single sweep.
//------------------------------------------------------------------------
wire m_step = (seq >= 8'd1) && (seq <= MSEQ[7:0]);

//===========================================================================
// THE CORRELATOR.  One term of one offset per clock, both axes in parallel
// (they are independent hardware and share only the counters).  See GMC_EN
// for the algorithm and [4b] for the projections it reads.
//===========================================================================
wire g_step = (GMC_EN != 0) && (seq >= GSTART[7:0]) && (seq <= SEQ_END[7:0]);
assign g_done = (GMC_EN != 0) && (seq == SEQ_END[7:0]);

// gi walks the 11 terms, gd the 5 offsets; gi wrapping advances gd.
reg [3:0] gi;
reg [2:0] gd;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        gi <= 4'd0; gd <= 3'd0;
    end else if (frame_tick) begin
        gi <= 4'd0; gd <= 3'd0;
    end else if (g_step) begin
        if (gi == (GTERMS[3:0] - 4'd1)) begin
            gi <= 4'd0;
            gd <= gd + 3'd1;
        end else begin
            gi <= gi + 4'd1;
        end
    end
end

// Term index into the projections, and the offset applied to the PREVIOUS
// frame's.  i runs [2, 12] and d runs [-2, +2], so i-d is always in [0, 14]
// -- see GTERMS for why that matters more than it looks.
wire [3:0] g_i  = gi + 4'd2;
wire [3:0] g_id = g_i + 4'd2 - {1'b0, gd};        // i - (gd - 2)

wire [PJW-1:0] cx_now = col_acc[g_i];
wire [PJW-1:0] cx_prv = col_prv[g_id];
wire [PJW-1:0] cy_now = row_acc[g_i];
wire [PJW-1:0] cy_prv = row_prv[g_id];

wire [PJW-1:0] adx = (cx_now >= cx_prv) ? (cx_now - cx_prv) : (cx_prv - cx_now);
wire [PJW-1:0] ady = (cy_now >= cy_prv) ? (cy_now - cy_prv) : (cy_prv - cy_now);

// 11 terms of at most 945 each needs 14 bits.
localparam integer SADW = PJW + 4;

reg [SADW-1:0] sad_x [0:4];
reg [SADW-1:0] sad_y [0:4];

integer gk;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        for (gk = 0; gk < 5; gk = gk + 1) begin
            sad_x[gk] <= {SADW{1'b0}};
            sad_y[gk] <= {SADW{1'b0}};
        end
    end else if (frame_tick) begin
        for (gk = 0; gk < 5; gk = gk + 1) begin
            sad_x[gk] <= {SADW{1'b0}};
            sad_y[gk] <= {SADW{1'b0}};
        end
    end else if (g_step) begin
        sad_x[gd] <= sad_x[gd] + {{4{1'b0}}, adx};
        sad_y[gd] <= sad_y[gd] + {{4{1'b0}}, ady};
    end
end

//---------------------------------------------------------------------------
// THE VERDICT, on g_done.  argmin over the five SADs, then the margin test.
//
// ⚠ THE MARGIN TEST IS NOT A REFINEMENT, IT IS WHAT KEEPS THIS SAFE.  On a
// static scene all five SADs are equal up to noise and the argmin is
// therefore a random nonzero offset -- which would read the whole background
// model one block sideways and light up every textured block in the frame.
// A wrong estimate is far more damaging than no estimate, so a nonzero
// offset has to BEAT the zero-offset SAD by GMC_MARGIN before it is
// believed, and anything less resolves to zero.
//
// Written as a flat compare chain rather than a loop: five entries, and the
// chain makes the tie-breaking order explicit -- smaller |offset| wins a
// tie, because the centre is checked first and later offsets need a strict
// improvement.
//---------------------------------------------------------------------------
reg signed [2:0] gdx_r, gdy_r;
assign gmc_dx = (GMC_EN == 0) ? 3'sd0 : gdx_r;
assign gmc_dy = (GMC_EN == 0) ? 3'sd0 : gdy_r;

// Best nonzero candidate per axis, and whether it beat the centre.
function [3:0] pick_best;        // {valid, index[2:0]}
    input [SADW-1:0] s0, s1, s2, s3, s4;
    input integer    margin;
    reg   [SADW-1:0] bv;
    reg   [2:0]      bi;
begin
    bv = s2; bi = 3'd2;                       // the centre, offset 0
    if (s0 + margin[SADW-1:0] < bv) begin bv = s0; bi = 3'd0; end
    if (s1 + margin[SADW-1:0] < bv) begin bv = s1; bi = 3'd1; end
    if (s3 + margin[SADW-1:0] < bv) begin bv = s3; bi = 3'd3; end
    if (s4 + margin[SADW-1:0] < bv) begin bv = s4; bi = 3'd4; end
    pick_best = {1'b1, bi};
end
endfunction

wire [3:0] bx_sel = pick_best(sad_x[0], sad_x[1], sad_x[2], sad_x[3], sad_x[4],
                              GMC_MARGIN);
wire [3:0] by_sel = pick_best(sad_y[0], sad_y[1], sad_y[2], sad_y[3], sad_y[4],
                              GMC_MARGIN);

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        gdx_r <= 3'sd0;
        gdy_r <= 3'sd0;
    end else if (frame_tick && md_blind) begin
        // md_blind already re-seeds every background; an estimate carried
        // across that discontinuity would displace models that are about to
        // be overwritten anyway, and the seeded frames are the ones where
        // the projections are least trustworthy.
        gdx_r <= 3'sd0;
        gdy_r <= 3'sd0;
    end else if (g_done) begin
        gdx_r <= $signed({1'b0, bx_sel[2:0]}) - 3'sd2;
        gdy_r <= $signed({1'b0, by_sel[2:0]}) - 3'sd2;
    end
end

//---------------------------------------------------------------------------
// THE SNAPSHOT.  cur -> prv on the same clock the accumulators are cleared,
// so the next frame correlates against this one.
//---------------------------------------------------------------------------
integer gs;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        for (gs = 0; gs < N_COLS; gs = gs + 1) begin
            col_prv[gs] <= {PJW{1'b0}};
            row_prv[gs] <= {PJW{1'b0}};
        end
    end else if (g_done) begin
        for (gs = 0; gs < N_COLS; gs = gs + 1) begin
            col_prv[gs] <= col_acc[gs];
            row_prv[gs] <= row_acc[gs];
        end
    end
end

reg [2:0] mpi;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n)                          mpi <= 3'd0;
    else if (frame_tick)                 mpi <= 3'd0;
    else if (!m_step)                    mpi <= 3'd0;
    else if (mpi == (MPAIRS[2:0] - 3'd1)) mpi <= 3'd0;
    else                                 mpi <= mpi + 3'd1;
end

reg [1:0] m_a, m_b;
always @(*) begin
    case (mpi)
        3'd0:    begin m_a = 2'd0; m_b = 2'd1; end
        3'd1:    begin m_a = 2'd0; m_b = 2'd2; end
        3'd2:    begin m_a = 2'd0; m_b = 2'd3; end
        3'd3:    begin m_a = 2'd1; m_b = 2'd2; end
        3'd4:    begin m_a = 2'd1; m_b = 2'd3; end
        default: begin m_a = 2'd2; m_b = 2'd3; end
    endcase
end

// Widened to 5 bits so that x1 + gap cannot wrap at the right or bottom edge
// of the grid.  ⚠ THE GAP IS ADDED TO EACH BOX IN TURN, NEVER SUBTRACTED
// FROM THE OTHER: the subtraction underflows at tile 0, which is exactly
// where an object entering frame sits.  ccl_blob's pass E cites this file for
// the same reasoning; it is the one arithmetic trap in an overlap test.
wire [4:0] mgx = BOX_GAP_X;
wire [4:0] mgy = BOX_GAP_Y;

wire [4:0] ma_x0 = {1'b0, pbx0[m_a]};
wire [4:0] ma_x1 = {1'b0, pbx1[m_a]};
wire [4:0] ma_y0 = {1'b0, pby0[m_a]};
wire [4:0] ma_y1 = {1'b0, pby1[m_a]};
wire [4:0] mb_x0 = {1'b0, pbx0[m_b]};
wire [4:0] mb_x1 = {1'b0, pbx1[m_b]};
wire [4:0] mb_y0 = {1'b0, pby0[m_b]};
wire [4:0] mb_y1 = {1'b0, pby1[m_b]};

// Both slots must hold a PUBLISHED box.  pbvalid is the test, and that is
// the whole difference from MERGE_GAP -- see BOX_GAP_X.  An absorbed slot has
// pbvalid cleared, so it cannot be merged twice.
wire m_hit = ((BOX_GAP_X != 0) || (BOX_GAP_Y != 0))
          && pbvalid[m_a] && pbvalid[m_b]
          && (ma_x0 <= (mb_x1 + mgx)) && (mb_x0 <= (ma_x1 + mgx))
          && (ma_y0 <= (mb_y1 + mgy)) && (mb_y0 <= (ma_y1 + mgy));

wire [3:0] mu_x0 = (pbx0[m_a] < pbx0[m_b]) ? pbx0[m_a] : pbx0[m_b];
wire [3:0] mu_x1 = (pbx1[m_a] > pbx1[m_b]) ? pbx1[m_a] : pbx1[m_b];
wire [3:0] mu_y0 = (pby0[m_a] < pby0[m_b]) ? pby0[m_a] : pby0[m_b];
wire [3:0] mu_y1 = (pby1[m_a] > pby1[m_b]) ? pby1[m_a] : pby1[m_b];

wire [8:0] mu_n9 = {1'b0, pbn[m_a]} + {1'b0, pbn[m_b]};
wire [7:0] mu_n  = mu_n9[8] ? 8'hFF : mu_n9[7:0];

// Latched at frame_tick because the peak update reads them five clocks later
// and both are cleared or reloaded in that same branch.
//
//   blv  this frame's measurement was believed and published
//   bst  ...and `hold` was 0 BEFORE it, i.e. this frame starts a new burst.
//        Captured here for the same reason the test used to live inline: by
//        seq 6 the reloaded `hold` says nothing about what came before.
reg blv, bst;

//------------------------------------------------------------------------
// Stage 1: the area of one box, as an explicit shift-and-add.
//
// NOT `w * h`.  This file's header records a burn lost to an inferred
// multiplier shifting the placement and putting chroma noise on every mode,
// and [1] writes its 15x as a shift-and-add for exactly that reason.  h is
// four bits, so the product is four conditional terms; the tool has nothing
// to infer a DSP from.
//
// w and h are spans PLUS ONE -- an area, not a difference -- so a 1x1 box
// reads 1 and the density test is not off by a row and a column on the
// smallest boxes it judges.  Max 15x15 = 225, eight bits.
//------------------------------------------------------------------------
// Slot under stage 1, on seq MSEQ+1 .. MSEQ+4.  The subtraction is done at
// full width and then truncated, rather than slicing seq like the pre-merge
// version did: MSEQ+1 is 13, whose low two bits are not 0, so the old
// seq[1:0]-1 trick silently indexed the wrong slots once the window moved.
wire [7:0] s1_ix = seq - MSEQ[7:0] - 8'd1;
wire [1:0] s1_i  = s1_ix[1:0];

wire [3:0] s1_w = pbx1[s1_i] - pbx0[s1_i] + 4'd1;
wire [3:0] s1_h = pby1[s1_i] - pby0[s1_i] + 4'd1;

wire [7:0] s1_area = (s1_h[0] ? {4'd0, s1_w}        : 8'd0)
                   + (s1_h[1] ? {3'd0, s1_w, 1'b0}  : 8'd0)
                   + (s1_h[2] ? {2'd0, s1_w, 2'b0}  : 8'd0)
                   + (s1_h[3] ? {1'd0, s1_w, 3'b0}  : 8'd0);

reg [7:0] area_r;
reg [1:0] area_i;

//------------------------------------------------------------------------
// Stage 2: the verdict.  Against pbn[], the block count SNAPSHOT taken with
// the geometry at publish time -- see the note at that assignment for why
// the live bn[] is the wrong thing to read here.  See BOX_FILL_SHIFT.
//------------------------------------------------------------------------
reg [NBOX-1:0] dense;

wire [7:0] fill_min = (BOX_FILL_SHIFT == 0) ? 8'd0
                                            : (area_r >> BOX_FILL_SHIFT);

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        area_r <= 8'd0;
        area_i <= 2'd0;
        dense  <= {NBOX{1'b1}};
    end else begin
        if ((seq >= (MSEQ[7:0] + 8'd1)) && (seq <= (MSEQ[7:0] + 8'd4))) begin
            area_r <= s1_area;
            area_i <= s1_i;
        end
        if ((seq >= (MSEQ[7:0] + 8'd2)) && (seq <= (MSEQ[7:0] + 8'd5)))
            dense[area_i] <= (pbn[area_i] >= fill_min);
    end
end

// What is actually drawn and exported: published AND compact.  The density
// test only ever REMOVES a box -- it cannot move one or invent one.
wire [NBOX-1:0] pbshow = pbvalid & dense;

// The dominant box as measured, and how many blocks short of the peak it is.
wire [3:0] pw_now = pbx1[pbest] - pbx0[pbest];
wire [3:0] ph_now = pby1[pbest] - pby0[pbest];

//------------------------------------------------------------------------
// seq 6: THE PEAK.  Raised only by a believed frame whose dominant box also
// passed the density test -- see the bug note in [5d]'s header for what the
// 09-20 build did without that second condition.
//
// `bst` (hold was 0 before this frame) LOADS rather than maxes, which is the
// whole of the per-burst reset: a burst cannot end without hold reaching 0,
// so there is no separate clear.
//
// ⚠ AND THE LOAD HAPPENS ON bst WHETHER OR NOT THE FRAME IS DENSE.  That
// asymmetry is deliberate and it closes a hole that the obvious form of this
// logic leaves open: if a dispersed frame simply "left the peak alone", then
// a burst that OPENS dispersed -- which is precisely what a camera pan does
// -- would inherit the peak of the PREVIOUS burst, and the first compact
// object to follow would be grown to whatever the last one measured.  That
// is the same full-screen-box failure this fix is for, arriving one burst
// late.  A new burst must start from its own evidence or from nothing.
//
// So: bst loads (pw_now if dense, 0 if not), and mid-burst dispersed frames
// are the only case that leaves the peak untouched -- correctly, since they
// are not evidence about an object's size in either direction.
//------------------------------------------------------------------------
wire pk_ok = dense[pbest];

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        pk_w <= 4'd0;
        pk_h <= 4'd0;
    end else if (frame_tick && md_blind) begin
        // The camera moved: no object is being tracked, so nothing about its
        // size is still true.  Same branch the published table is cleared in.
        pk_w <= 4'd0;
        pk_h <= 4'd0;
    end else if ((seq == (MSEQ[7:0] + 8'd6)) && (SIZE_FLOOR != 0) && blv) begin
        if (bst) begin
            pk_w <= pk_ok ? pw_now : 4'd0;
            pk_h <= pk_ok ? ph_now : 4'd0;
        end else if (pk_ok) begin
            if (pw_now > pk_w) pk_w <= pw_now;
            if (ph_now > pk_h) pk_h <= ph_now;
        end
    end
end

wire [3:0] grow_w = ((SIZE_FLOOR != 0) && (pk_w > pw_now)) ? (pk_w - pw_now) : 4'd0;
wire [3:0] grow_h = ((SIZE_FLOOR != 0) && (pk_h > ph_now)) ? (pk_h - ph_now) : 4'd0;

// Split the shortfall either side of the CURRENT centre.  The odd block goes
// to the far side, which is arbitrary and half a block on screen.
wire [3:0] grow_l = {1'b0, grow_w[3:1]};
wire [3:0] grow_r = grow_w - grow_l;
wire [3:0] grow_u = {1'b0, grow_h[3:1]};
wire [3:0] grow_d = grow_h - grow_u;

// 5 bits on the high side so the sum cannot wrap before it is clamped; the
// low side is clamped by the compare instead, which is the same argument
// [5c] makes about never subtracting from the cell index.
wire [4:0] ex1_raw = {1'b0, pbx1[pbest]} + {1'b0, grow_r};
wire [4:0] ey1_raw = {1'b0, pby1[pbest]} + {1'b0, grow_d};

wire [3:0] ex0_n = (pbx0[pbest] > grow_l) ? (pbx0[pbest] - grow_l) : 4'd0;
wire [3:0] ey0_n = (pby0[pbest] > grow_u) ? (pby0[pbest] - grow_u) : 4'd0;
wire [3:0] ex1_n = (ex1_raw > {1'b0, TILE_MAX}) ? TILE_MAX : ex1_raw[3:0];
wire [3:0] ey1_n = (ey1_raw > {1'b0, TILE_MAX}) ? TILE_MAX : ey1_raw[3:0];

integer e;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        for (e = 0; e < NBOX; e = e + 1) begin
            ebx0[e] <= 4'd0; ebx1[e] <= 4'd0;
            eby0[e] <= 4'd0; eby1[e] <= 4'd0;
        end
    end else if (seq == (MSEQ[7:0] + 8'd7)) begin
        for (e = 0; e < NBOX; e = e + 1) begin
            ebx0[e] <= pbx0[e]; ebx1[e] <= pbx1[e];
            eby0[e] <= pby0[e]; eby1[e] <= pby1[e];
        end
        ebx0[pbest] <= ex0_n; ebx1[pbest] <= ex1_n;
        eby0[pbest] <= ey0_n; eby1[pbest] <= ey1_n;
    end
end

//===========================================================================
// [5f] THE SINGLE-TARGET TRACKER -- 2026-09-22.  See TRK_EN for why.
//
// THE UNITS, first, because everything below depends on them.  The tracked
// centre is held in SIXTEENTHS OF A BLOCK: 0..232 for a 15-block axis, eight
// bits, and the two conversions to pixels are shifts (x16 of a 128-wide
// block is 8 px; of a 72-tall block is 4.5 px = <<2 + >>1).  A measured
// centre is (x0+x1+1)/2 blocks, i.e. always a multiple of 8 in these units --
// see TRK_SHIFT for why that lattice sets the IIR's useful range.
//
// THE PIPELINE, one candidate per clock:
//
//   seq TSTART+d   candidate slot d: gate it, keep it if it is the biggest
//                  gated candidate so far
//   seq TUPD       associate / coast / acquire, and move the centre
//   seq TGEO       turn the state into a pixel rectangle for [6]
//
// ⚠ WHY ASSOCIATION IS "BIGGEST INSIDE THE GATE" AND NOT "NEAREST".  Nearest
// is the textbook choice and it is wrong for this detector: a decelerating
// body throws off small satellite clusters (handoff section on DOM_SHIFT),
// and a satellite is by construction NEARER to the last centre than the
// body's own shifted box.  Nearest-neighbour would walk the track onto the
// debris every time the target slowed -- which is precisely the moment the
// board complaint is about.  The gate supplies the "near", the block count
// supplies the "which", and each does the job it is good at.
//===========================================================================
localparam [7:0] TRK_GX16 = {TRK_GATE_X, 4'd0};      // gate, in 1/16 blocks
localparam [7:0] TRK_GY16 = {TRK_GATE_Y, 4'd0};
localparam [7:0] TRK_SX16 = {TRK_GATE_SX, 4'd0};     // the soft-frame gate
localparam [7:0] TRK_SY16 = {TRK_GATE_SY, 4'd0};

// Sized copy of the line width.  A part-select on a `parameter integer` is
// legal Verilog-2001 but not every vendor front end agrees; the localparam
// costs nothing and the rest of this file already reads MSEQ[7:0] the risky
// way only for LOCALparams, which are safe everywhere it is built.
localparam [11:0] TTHK = TRK_THICK;

reg [7:0] trk_x, trk_y;            // centre, 1/16 block
reg [3:0] trk_w, trk_h;            // size, whole blocks
reg       trk_live;                // a track exists
reg [2:0] trk_conf;                // consecutive associated frames, saturating
reg [3:0] trk_miss;                // consecutive frames with no association
reg       trk_taint;               // camera-motion evidence since the last clean measurement
reg [4:0] dec_cnt;                 // frames since the last shrink

// The association accumulator, cleared at frame_tick and read at TUPD.
reg       a_hit;
reg [7:0] a_n;
reg [7:0] a_cx, a_cy;
reg [3:0] a_w, a_h;

// ⭐ THE SOFT-FRAME ACQUISITION FLOOR -- see TRK_ACQ_BLK_SOFT for the whole
// argument.  One 8-bit compare against the winning candidate's block count,
// read at TUPD where a_n has been stable since the last a_step.
//
// ⚠ a_n IS THE WINNER'S COUNT, NOT THE FRAME'S.  tot_n would be the wrong
// signal here by exactly the mistake this round is correcting: a pan's blocks
// sum to a large frame total while every individual cluster stays small, so a
// floor on tot_n would wave through the case it exists to stop.
wire a_soft_ok = (TRK_ACQ_BLK_SOFT != 8'd0) && (a_n >= TRK_ACQ_BLK_SOFT);

// ⚠ EVERY ENABLE IN THIS SECTION CARRIES `TRK_EN != 0`, and the first version
// carried it only on the OUTPUTS.  That version was functionally fine -- with
// trk_show and the target mux gated, nothing downstream could see the state
// machine -- and it was still wrong twice over:
//
//   * nothing folds away.  The registers, the four-way association compare
//     and the pixel-domain rectangle all still synthesise, so "TRK_EN = 0"
//     costs full area and, worse, still contributes to placement in a design
//     with 34 ps of slack.  A rollback switch that does not change the
//     netlist cannot rescue a timing failure, which is most of what a
//     rollback switch is for.
//   * mttb T25 read trk_live = 1 on the disabled instance.  A disable that
//     leaves observable state running is a disable nobody can test, and the
//     handoff's one-parameter-A/B rule depends on being able to test it.
wire       t_en   = (TRK_EN != 0);

wire [7:0] as_ix = seq - TSTART[7:0];
wire       a_step = t_en && (seq >= TSTART[7:0]) && (seq <= (TSTART[7:0] + NBOX - 1));
wire [1:0] a_i    = as_ix[1:0];

// Centre of candidate a_i, in 1/16 blocks: (x0 + x1 + 1) * 8.
wire [4:0] s_xs = {1'b0, pbx0[a_i]} + {1'b0, pbx1[a_i]} + 5'd1;
wire [4:0] s_ys = {1'b0, pby0[a_i]} + {1'b0, pby1[a_i]} + 5'd1;
wire [7:0] s_cx = {s_xs, 3'b000};
wire [7:0] s_cy = {s_ys, 3'b000};

wire [7:0] s_dx = (s_cx >= trk_x) ? (s_cx - trk_x) : (trk_x - s_cx);
wire [7:0] s_dy = (s_cy >= trk_y) ? (s_cy - trk_y) : (trk_y - s_cy);

// The gate narrows on a soft-dispersed frame.  A mux on a constant ahead of
// an 8-bit compare, in the blanking sequencer -- nowhere near the pixel path
// that [6b] had to be split for.
wire [7:0] t_gx = disp_soft_r ? TRK_SX16 : TRK_GX16;
wire [7:0] t_gy = disp_soft_r ? TRK_SY16 : TRK_GY16;

// With no track there is no gate to be inside of, and the floor is raised to
// TRK_ACQ_BLK instead -- acquiring is a commitment, following is not.
wire s_gate = (!trk_live) || ((s_dx <= t_gx) && (s_dy <= t_gy));

// ⚠ AND `blv` -- THE FRAME MUST HAVE BEEN BELIEVED.  pbvalid and pb* are NOT
// cleared on a sub-threshold frame; HOLD_FRAMES deliberately leaves the last
// believed frame's table standing so the green overlay does not blink.  A
// tracker that associated against that table would re-confirm the same stale
// geometry every held frame, so trk_miss would never advance and the OSD
// would report LOCKED while the detector was measuring nothing at all --
// destroying the one distinction the 'T' / 't' character exists to make, and
// giving the coast timer a length of HOLD_FRAMES + TRK_COAST that no
// parameter states.
//
// This is the same live-versus-held trap as the pbn[] snapshot note: the
// question is never "is there a box" but "is there a box FROM THIS FRAME".
// 2026-09-23: the table this scan reads depends on which branch it is in.
// See TRK_FOLLOW_SPARSE.  Following reads pbvalid (density not required);
// acquiring reads pbshow and additionally spells `dense[a_i]` out, so that
// the acquire path states its own requirement instead of inheriting it from
// whatever pbshow happens to be ANDed with today.
//
// ⚠ THE `dense[a_i]` IN THE ACQUIRE BRANCH IS NOT REDUNDANT BOOKKEEPING even
// though pbshow already implies it.  It is what makes TRK_FOLLOW_SPARSE a
// one-parameter rollback: without it, setting TRK_FOLLOW_SPARSE = 0 would be
// the only thing holding density on the acquire path, and a later edit to
// pbshow would silently move the acquire requirement with it.  §-4.2's
// coupling warning ("TRK_ACQ_BLK_SOFT is unsafe unless BOX_FILL_SHIFT != 0")
// is now enforced HERE, on the line that depends on it, rather than in a
// comment two hundred lines away.
wire a_box = trk_live ? ((TRK_FOLLOW_SPARSE != 0) ? pbvalid[a_i] : pbshow[a_i])
                      : pbshow[a_i];

wire s_ok   = blv && a_box && s_gate
              && (trk_live || (dense[a_i] && (pbn[a_i] >= TRK_ACQ_BLK)));

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        a_hit <= 1'b0; a_n <= 8'd0;
        a_cx  <= 8'd0; a_cy <= 8'd0;
        a_w   <= 4'd1; a_h  <= 4'd1;
    end else if (frame_tick) begin
        a_hit <= 1'b0; a_n <= 8'd0;
    end else if (a_step) begin
        // >= rather than > so a later slot of equal size wins, matching the
        // convention best_i uses during accumulation.
        if (s_ok && (!a_hit || (pbn[a_i] >= a_n))) begin
            a_hit <= 1'b1;
            a_n   <= pbn[a_i];
            a_cx  <= s_cx;
            a_cy  <= s_cy;
            a_w   <= pbx1[a_i] - pbx0[a_i] + 4'd1;
            a_h   <= pby1[a_i] - pby0[a_i] + 4'd1;
        end
    end
end

// The centre step.  Signed so a measurement to the left of the track moves
// it left; the sum cannot overflow because an IIR step always lands between
// the two operands.
wire signed [8:0] err_x = $signed({1'b0, a_cx}) - $signed({1'b0, trk_x});
wire signed [8:0] err_y = $signed({1'b0, a_cy}) - $signed({1'b0, trk_y});
wire signed [8:0] inc_x = err_x >>> TRK_SHIFT;
wire signed [8:0] inc_y = err_y >>> TRK_SHIFT;

// The shrink clock.  ⚠ IT COUNTS *CONSECUTIVE* UNDER-MEASURED FRAMES, not
// frames, and the difference is the whole behaviour:
//
//   free-running   -- one small measurement landing on the tick shrinks the
//                     box, so the size follows a FLICKERING measurement down
//                     at the average rate.  That is the board symptom with a
//                     slower clock on it, not a fix for it.
//   consecutive    -- the measurement has to STAY small for TRK_DECAY frames.
//                     A decelerating body's sliver frames are interrupted by
//                     full ones, so the clock keeps restarting and the box
//                     holds; a target that has genuinely got smaller (walked
//                     away) reports small every frame and the box follows.
//
// It also makes the behaviour deterministic for a test, which a free-running
// counter is not: whether a given frame shrinks would depend on the phase a
// counter happened to be in.
//
// ⚠ STRICTLY SMALLER, PER AXIS, AND THE FIRST VERSION GOT BOTH WRONG.  It
// read `(a_w <= trk_w) && (a_h <= trk_h)` -- one condition for both axes, and
// `<=` rather than `<`.  With `<=`, A MEASUREMENT THAT AGREES EXACTLY WITH
// THE TRACKED SIZE COUNTS AS EVIDENCE THE TARGET SHRANK, so a perfectly
// tracked object of constant size walks its own box down to TRK_W_MIN one
// block per TRK_DECAY frames.  mttb T20 caught it as "saturates at 3" reading
// 2; the board would have shown it as the small-box complaint coming back
// with the tracker on, which is the worst possible outcome for a feature
// whose whole purpose is that complaint.
//
// Per axis because the axes are independent measurements: a target turning
// side-on gets narrower without getting shorter, and a single `&&` would
// refuse to give back the width because the height still agreed.
wire under_w = (a_w < trk_w);
wire under_h = (a_h < trk_h);

wire shrink_cand = under_w | under_h;
wire dec_tick    = (dec_cnt >= (TRK_DECAY - 5'd1));

// ⚠ cam_motion_r, NOT md_blind.  md_blind is built from tot_n, which
// frame_tick clears -- by seq TUPD it reads zero and md_blind has decayed to
// bare md_inhibit.  cam_motion_r is the registered verdict for the frame
// that just ended and is the only correct thing to read out here.  This is
// the same live-versus-snapshot trap as the pbn[] note above.
wire t_blind = cam_motion_r;

// The coast expiring, TWO BUDGETS -- see TRK_MISS for why they are separate.
// Both written as ">= X - 1" and evaluated on the frame the miss happens, so
// X counts the coasted frames themselves.  trk_miss is shared: a mixed run
// of blind and missed frames is judged each frame against whichever budget
// that frame belongs to, which is the conservative reading (the shorter
// budget wins as soon as its kind of frame occurs).
wire t_expire_b = (trk_miss >= (TRK_COAST - 4'd1));
wire t_expire_m = (trk_miss >= (TRK_MISS  - 4'd1));

// ⚠ AN UNCONFIRMED TRACK GETS NO COAST AT ALL, and this is the mechanism the
// "random box while I pan" complaint actually needs.  TRK_ACQ asks for N
// associated frames before the box is drawn, but a coast leaves trk_conf
// standing, so without this rule a candidate can collect its N confirmations
// one frame at a time with 12-frame gaps between them -- and a pan is
// exactly a stream of unrelated clusters separated by re-seeded blank
// frames.  Raising TRK_ACQ on its own does not close that; it just makes the
// pan take a few more frames to draw the same wrong box.
//
// With this rule the two numbers finally mean what they say: TRK_ACQ frames
// IN A ROW to earn a box, then the full coast budget to keep it.  Nothing a
// confirmed track does changes, so the shrink/freeze behaviour T20/T21 test
// is untouched.
wire t_unconf = (TRK_DROP_UNCONF != 0) && (trk_conf < TRK_ACQ);

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        trk_x    <= 8'd0;   trk_y    <= 8'd0;
        trk_w    <= TRK_W_MIN; trk_h <= TRK_H_MIN;
        trk_live <= 1'b0;
        trk_conf <= 3'd0;
        trk_miss <= 4'd0;
        trk_taint <= 1'b0;
        dec_cnt  <= 5'd0;
    end else if (t_en && (seq == TUPD[7:0])) begin

        //----------------------------------------------------------------
        // THE CAMERA MOVED.  Freeze the geometry and age the track.
        //
        // ⚠ FREEZE, NOT DROP, and this is the difference between the board
        // photographs and what a security head needs.  A pan produces
        // measurements that are real and about the wrong thing; deleting the
        // track on the first one means re-acquiring on whatever the new view
        // happens to contain.  Holding it for TRK_COAST frames means a brief
        // shake leaves the box exactly where it was, and a sustained pan
        // drops it after 200 ms and re-acquires honestly.
        //----------------------------------------------------------------
        if (t_blind) begin
            dec_cnt <= 5'd0;
            if (trk_live) begin
                if (t_expire_b || t_unconf) begin
                    trk_live <= 1'b0;
                    trk_conf <= 3'd0;
                    trk_miss <= 4'd0;
                    trk_taint <= 1'b0;
                end else begin
                    trk_miss <= trk_miss + 4'd1;
                    trk_taint <= 1'b1;          // TRK_SHOW_CLEAN
                end
            end

        end else if (!trk_live) begin
            // ACQUIRE.  Start at the minimum size and let it grow: an
            // over-large first box would need TRK_DECAY x its excess to come
            // back, and the first frame of a new object is the least
            // trustworthy measurement of its size there is.
            //
            // ⚠ NOT ON A SOFT-DISPERSED FRAME.  See DISP_ACQ_NC: acquisition
            // is the one decision here with no anchor -- whatever cluster is
            // biggest becomes the target -- so it is the one that must not be
            // taken while the frame is full of background sliding past.  This
            // is the "the random box beats the object" complaint: not that
            // the wrong candidate won a contest, but that a contest was held
            // at all on a frame whose candidates are all suspect.
            //
            // ⭐ 2026-09-22 NIGHT: ...UNLESS THE WINNER IS BIG ENOUGH.  The
            // sentence above is still the rule; a_soft_ok is the exception,
            // and TRK_ACQ_BLK_SOFT carries the argument for why an exception
            // is right.  The short form: the paragraph above says the frame's
            // candidates are ALL suspect, and with BOX_FILL_SHIFT armed that
            // is no longer true -- a candidate that is both compact (pbshow,
            // inside a_hit) and large (this floor) is not something a pan
            // across a flat room can manufacture.  The board complaint this
            // answers is a big near object being locked out by its own size.
            //
            // ⚠ WRITTEN AS `!trk_live` WITH THE HIT TEST INSIDE, not as
            // `a_hit && !trk_live && !disp_soft_r`.  Hanging the inhibit on
            // the else-if condition would let a live-less frame fall through
            // to the FOLLOW branch below, which moves trk_x on a track that
            // does not exist -- a silent corruption of the next acquisition's
            // starting point.
            //
            // ⭐ 2026-09-24: ...AND NOT WITHIN CAM_HOLD FRAMES OF A
            // DISPERSION VETO.  The two conditions above are both per-frame,
            // and a pan's verdict is noisy per-frame; see CAM_HOLD.  This
            // term is on the ACQUIRE branch only -- the follow branch below
            // is deliberately untouched, which is §-3.1 / §-5.1's
            // acquire-versus-follow asymmetry used for the third time.
            if (a_hit && (!disp_soft_r || a_soft_ok) && !acq_locked) begin
                trk_live <= 1'b1;
                trk_x    <= a_cx;
                trk_y    <= a_cy;
                trk_w    <= TRK_W_MIN;
                trk_h    <= TRK_H_MIN;
                trk_conf <= 3'd1;
                trk_miss <= 4'd0;
                trk_taint <= disp_soft_r;
                dec_cnt  <= 5'd0;
            end

        end else if (a_hit) begin
            // FOLLOW.
            trk_x    <= trk_x + inc_x[7:0];
            trk_y    <= trk_y + inc_y[7:0];
            trk_miss <= 4'd0;
            // A measurement taken on a soft frame is fresh -- it is drawn
            // this frame -- but it is not CLEAN: the coast that extrapolates
            // it would be extrapolating something a pan may have produced.
            trk_taint <= disp_soft_r;
            if (trk_conf != 3'd7) trk_conf <= trk_conf + 3'd1;

            dec_cnt <= (shrink_cand && !dec_tick) ? (dec_cnt + 5'd1) : 5'd0;

            if (TRK_FIXED == 0) begin
                if (a_w > trk_w) begin
                    if (trk_w < TRK_W_MAX) trk_w <= trk_w + 4'd1;
                end else if (dec_tick && under_w && (trk_w > TRK_W_MIN)) begin
                    trk_w <= trk_w - 4'd1;
                end

                if (a_h > trk_h) begin
                    if (trk_h < TRK_H_MAX) trk_h <= trk_h + 4'd1;
                end else if (dec_tick && under_h && (trk_h > TRK_H_MIN)) begin
                    trk_h <= trk_h - 4'd1;
                end
            end

        end else begin
            dec_cnt <= 5'd0;
            // COAST.  trk_live is guaranteed here by the chain above (the
            // !trk_live case was taken two branches up), so the old
            // `else if (trk_live)` guard is now the else itself.
            //
            // Position and size untouched -- no velocity is extrapolated,
            // deliberately: a wrong velocity flies the box off the screen,
            // and a walking target moves less than the gate in TRK_MISS
            // frames anyway.
            //
            // ⚠ TRK_MISS, NOT TRK_COAST.  This branch is "the detector is
            // working and there is nothing where the track is", which is the
            // 滞留 complaint; the blind branch at the top of the chain is
            // "there is no information", which wants to wait.  Sharing one
            // number made the honest case pay the paranoid case's budget.
            if (t_expire_m || t_unconf) begin
                trk_live <= 1'b0;
                trk_conf <= 3'd0;
                trk_miss <= 4'd0;
                trk_taint <= 1'b0;
            end else begin
                trk_miss <= trk_miss + 4'd1;
                // ⚠ OR, never a plain load: a re-seed frame lands here with
                // disp_soft_r = 0, and it is the blind frame before it that
                // set the bit.  A load would wipe exactly the evidence this
                // bit exists to carry across the re-seed.
                trk_taint <= trk_taint | disp_soft_r;
            end
        end
    end
end

// A track that is BELIEVED: confirmed, alive, not yet expired.  This is what
// the OSD character reports, and up to 2026-09-24 it was also what got drawn.
wire trk_held = t_en && trk_live && (trk_conf >= TRK_ACQ);

// ⭐ AND A TRACK THAT IS DRAWN.  Split on 2026-09-24; TRK_SHOW_MISS carries
// the argument.  trk_miss is updated at seq TUPD and TGEO is TUPD + 1, so the
// value read here is THIS frame's -- the ink stops on the frame the coast
// starts being too old, not one frame later.
//
// ⚠ Only the pixel/geometry path and target_valid follow this.  The tracker's
// own state machine above reads neither; a hidden track keeps coasting,
// keeps its geometry and re-associates normally.
// ⭐ 2026-09-25: "recently, the camera may have moved".  TWO TERMS, AND
// EACH IS LOAD-BEARING:
//   * cam_motion_r -- THIS frame's registered verdict.  Covers md_inhibit
//     and MAX_BLOCKS as well as disp_veto, which CAM_HOLD deliberately does
//     not; see TRK_SHOW_QUIET for why broad is right here and narrow is
//     right there.
//   * acq_locked   -- the CAM_HOLD tail.  Without it the GAPS in a pan's
//     per-frame verdict are unguarded, which is the same hole CAM_HOLD was
//     added to close on the acquire side.  A pan that vetoes frames 1,2,4,5
//     leaves 3 completely quiet, and a one-frame coast drawn on frame 3 is
//     precisely the box the board is photographing.
//
// ⚠ cam_motion_r AND cam_hold_r are both loaded in frame_tick branches, and
// TGEO is later in the SAME blanking interval -- so this reads the verdict
// for the frame that just ended.  A live read of md_blind here would decay
// to bare md_inhibit by seq TUPD (the t_blind comment records that trap).
wire cam_recent = cam_motion_r || acq_locked;

// ⭐ AND A TRACK THAT IS DRAWN.  Split from trk_held on 2026-09-24;
// TRK_SHOW_MISS and TRK_SHOW_QUIET carry the argument between them.
//
// trk_miss is updated at seq TUPD and TGEO is TUPD + 1, so the value read
// here is THIS frame's -- the ink stops on the frame the coast becomes too
// old, not one frame later.
//
// ⚠ A FRESH MEASUREMENT IS NEVER SUPPRESSED (the trk_miss == 0 arm is
// unconditional).  cam_recent only ever gates a COAST.  Otherwise the tail
// of a pan would blank the box of a target the detector has already
// re-acquired and is measuring this very frame -- which is complaint 1 being
// paid for a second time, and it is what T75 asserts cannot happen.
//
// ⚠ Only the pixel/geometry path and target_valid follow this.  The
// tracker's own state machine reads neither; a hidden track keeps coasting,
// keeps its geometry and re-associates normally.
//
// ⭐ 2026-09-28: a third coast term, TRK_SHOW_CLEAN.  cam_recent asks about
// the camera NOW; trk_taint asks about it since the measurement being
// extrapolated.  trk_taint is written at TUPD like trk_miss, so this reads
// the bit as of the frame being drawn.
wire trk_show = trk_held &&
                ((trk_miss == 4'd0) ||
                 ((trk_miss <= TRK_SHOW_MISS) &&
                  ((TRK_SHOW_QUIET == 0) || !cam_recent) &&
                  ((TRK_SHOW_CLEAN == 0) || !trk_taint)));

// ⚠ GATED ON trk_held, NOT ON trk_show AND NOT ON trk_live.  Not trk_live,
// because an unconfirmed track draws nothing and reporting "locked" for it
// would put the OSD and the picture into exactly the disagreement this flag
// is for.  And not trk_show, so that a track whose box has been hidden still
// prints '?' instead of going blank: blank means "nothing tracked" and that
// is a different fact.  See TRK_SHOW_MISS for why the pair is the readout.
//
// ⚠ 2026-09-25: SO '?' WITH NO BOX IS NOW THE NORMAL APPEARANCE OF A PAN,
// and '?' WITH a box means "the object paused while the camera was still".
// The board complaint that produced TRK_SHOW_QUIET was "'?' still flashes a
// box"; the answer is not to silence the character but to make the pair say
// which of the two happened.
assign trk_state = !trk_held          ? 2'd0 :
                   (trk_miss != 4'd0) ? 2'd1 : 2'd2;

//---------------------------------------------------------------------------
// The tracked centre in pixels.  Shifts only -- this module's header records
// a whole burn lost to an inferred multiplier moving the placement.
//   x: 1/16 of a 128-px block = 8 px            -> <<3
//   y: 1/16 of a  72-px block = 4.5 px          -> <<2 + >>1
// ⚠ Hardwired to BLK_W = 128 / BLK_H = 72, exactly like [5e] below.
//---------------------------------------------------------------------------
wire [11:0] trk_cx_px = {1'b0, trk_x, 3'b000};
wire [11:0] trk_cy_px = {2'b00, trk_y, 2'b00} + {5'd0, trk_y[7:1]};

// Half-extents: trk_w * BLK_W/2 = x64, trk_h * BLK_H/2 = x36 = <<5 + <<2.
wire [11:0] trk_hw_px = {2'b00, trk_w, 6'b000000};
wire [11:0] trk_hh_px = {3'b000, trk_h, 5'b00000} + {6'b0, trk_h, 2'b00};

wire [12:0] tx1_raw = {1'b0, trk_cx_px} + {1'b0, trk_hw_px};
wire [12:0] ty1_raw = {1'b0, trk_cy_px} + {1'b0, trk_hh_px};

wire [11:0] tx0_n = (trk_cx_px > trk_hw_px) ? (trk_cx_px - trk_hw_px) : 12'd0;
wire [11:0] ty0_n = (trk_cy_px > trk_hh_px) ? (trk_cy_px - trk_hh_px) : 12'd0;
wire [11:0] tx1_n = (tx1_raw > (IMG_HDISP - 1)) ? (IMG_HDISP - 1) : tx1_raw[11:0];
wire [11:0] ty1_n = (ty1_raw > (IMG_VDISP - 1)) ? (IMG_VDISP - 1) : ty1_raw[11:0];

// Registered rectangle and its four border bands.  All eight are computed in
// the one blanking clock at TGEO so that [6] compares px/py against plain
// registers -- a border test is on the PIXEL path, where this module has
// 34 ps of slack (handoff section 5.5) and no room for an adder.
reg [11:0] tx0, tx1, ty0, ty1;
reg [11:0] txa, txb, tya, tyb;
reg        trk_draw_en;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        tx0 <= 12'd0; tx1 <= 12'd0; ty0 <= 12'd0; ty1 <= 12'd0;
        txa <= 12'd0; txb <= 12'd0; tya <= 12'd0; tyb <= 12'd0;
        trk_draw_en <= 1'b0;
    end else if (t_en && (seq == TGEO[7:0])) begin
        tx0 <= tx0_n;  tx1 <= tx1_n;
        ty0 <= ty0_n;  ty1 <= ty1_n;
        txa <= tx0_n + TTHK - 12'd1;
        tya <= ty0_n + TTHK - 12'd1;
        txb <= (tx1_n >= TTHK) ? (tx1_n - TTHK + 12'd1) : 12'd0;
        tyb <= (ty1_n >= TTHK) ? (ty1_n - TTHK + 12'd1) : 12'd0;
        trk_draw_en <= trk_show;
    end
end

assign trk_box_x0 = tx0;
assign trk_box_x1 = tx1;
assign trk_box_y0 = ty0;
assign trk_box_y1 = ty1;
assign trk_box_v  = trk_draw_en;

//------------------------------------------------------------------------
// [5e] THE TRACKING TARGET -- the dominant box's centre, in pixels.
//
// NO MULTIPLIER, and that is not a micro-optimisation: this file's header
// records a whole burn lost to an inferred multiplier moving the placement
// and putting chroma noise on every mode, so the two constant scalings are
// written as shifts.  x is x BLK_W/2 = x64 for the 128-wide block, which is a
// bare concatenation; y is x BLK_H/2 = x36 = x32 + x4.
//
// ⚠ BOTH ARE HARDWIRED TO BLK_W = 128 AND BLK_H = 72 and there is no way for
// the parameters to say so.  Reshaping the grid means rewriting these two
// lines; the rest of the module survives it.
//------------------------------------------------------------------------
wire [5:0]  cx_sum = {1'b0, ebx0[pbest]} + {1'b0, ebx1[pbest]} + 6'd1;
wire [5:0]  cy_sum = {1'b0, eby0[pbest]} + {1'b0, eby1[pbest]} + 6'd1;
wire [11:0] cx_ext = {6'd0, cx_sum};
wire [11:0] cy_ext = {6'd0, cy_sum};

wire [11:0] box_target_x = (cx_ext << 6);                   // cx_sum * 64
wire [11:0] box_target_y = (cy_ext << 5) + (cy_ext << 2);   // cy_sum * 36
wire        box_target_v = (hold != 6'd0) && pbshow[pbest];

//---------------------------------------------------------------------------
// 2026-09-22: WHICH OF THE TWO THE HEAD STEERS ON.
//
// TRK_EN picks the tracker's state over this frame's dominant box, and the
// default is the tracker for one reason: the box is a MEASUREMENT and a
// servo integrates whatever it is given.  The dominant box jumps between
// clusters between frames, so feeding it to a proportional loop makes the
// head shake at the frame rate even when the target is walking smoothly.
// The tracker's centre has already been through the gate and the IIR, which
// is the same filtering the servo would otherwise have to do itself -- and
// doing it here means the number on the port and the box on the screen are
// the same thing, so a photograph is a valid test of the control input.
//
// Setting TRK_EN = 0 restores the 09-20 behaviour exactly, port for port.
//---------------------------------------------------------------------------
assign target_x     = t_en ? trk_cx_px : box_target_x;
assign target_y     = t_en ? trk_cy_px : box_target_y;
assign target_valid = t_en ? trk_show  : box_target_v;

//------------------------------------------------------------------------
// [6] Draw the rectangles.  Pure coordinate compares -- the box edges sit on
// block boundaries, so the tile index picks the side and the offset inside
// the block picks the line width.  No pixel-space multiply is needed.
//
// NBOX of them now, OR'd. They are independent, so this is NBOX shallow
// compare sets in parallel and one OR tree, not a deeper path than the single
// box was.  Boxes may overlap; drawing is a union, so an overlap reads as two
// rectangles crossing rather than as anything undefined.
//------------------------------------------------------------------------
wire box_on = motion_frame_en && (hold != 6'd0);

wire [6:0] x_in_blk = px[6:0];

reg  border_c;
integer d;

always @(*) begin
    border_c = 1'b0;
    for (d = 0; d < NBOX; d = d + 1) begin
        // eb*/ey* rather than pb*/py* since 2026-09-20: the same table with
        // SIZE_FLOOR applied to the dominant slot.  The validity mask is
        // pbshow -- published and compact; the floor itself resizes a box
        // and never publishes or withdraws one.
        if (box_on && pbshow[d]
            && (x_tile >= ebx0[d]) && (x_tile <= ebx1[d])
            && (y_tile >= eby0[d]) && (y_tile <= eby1[d])
            && (   ((x_tile == ebx0[d]) && (x_in_blk <  BOX_THICK))
                 | ((x_tile == ebx1[d]) && (x_in_blk >= (BLK_W - BOX_THICK)))
                 | ((y_tile == eby0[d]) && (y_in_blk <  BOX_THICK))
                 | ((y_tile == eby1[d]) && (y_in_blk >= (BLK_H - BOX_THICK)))))
            border_c = 1'b1;
    end
end

//------------------------------------------------------------------------
// [6b] THE TRACKER'S RECTANGLE -- 2026-09-22.  Pixel resolution, not block.
//
// ⚠ NOT DRAWN ON THE BLOCK GRID LIKE [6] ABOVE, and the extra comparators
// are the price of the feature rather than a preference.  The tracked centre
// is carried in 1/16 of a block precisely so the IIR can settle between
// block boundaries; quantising the drawing back to whole blocks would put
// 128 px of jitter on screen and the photograph would show a box that jumps
// while the number on target_x is smooth -- two readings of one state that
// disagree, which is the failure mode section 3.-14 cost a round to.
//
// ⚠⚠ AND THE EIGHT COMPARES ARE SPLIT ACROSS TWO CLOCKS, WHICH IS A TIMING
// DECISION AND NOT A STYLE ONE.  This module's own [5d] header states the
// rule it exists to obey -- slack between clocks does nothing for a wide
// combinational path inside one clock -- and the pixel path is where that
// bites: the worst path in the 09-19 build had 34 ps to spare (handoff
// section 5.5), which is nothing.
//
// The first version wrote all eight compares plus the AND/OR tree as one
// expression feeding one register.  Eight 12-bit magnitude compares is
// roughly three LUT levels of carry chain and then two more of reduction,
// against an existing pixel-path budget of five levels TOTAL -- so that
// version's most likely outcome was not a wrong picture but a P&R that came
// back negative and a round spent bisecting which of the day's four changes
// did it.
//
// So:
//   stage 1  the four compares, registered.  They are PARALLEL, so the depth
//            is one comparator, not four.
//   stage 2  the AND/OR of four registered bits -- two levels, trivially.
//
// ⚠ THE LATENCY IS UNCHANGED AND THAT IS WHAT MAKES IT FREE.  border_c is
// combinational from x_tile/y_tile and is registered once into border_d1
// before out_rgb_r.  The tracker's stage-1 register sits in the same place
// as border_d1, and its stage-2 reduction is combinational into the same
// out_rgb_r.  Both therefore describe the same pixel at the same clock --
// no realignment, no extra delay line, and no half-pixel offset between the
// green boxes and the magenta one.
//
// ⚠ AND THE Y COMPARES DID NOT NEED TO BE FAST AT ALL, which is worth
// noticing before adding anything else to this path: py is CONSTANT ACROSS A
// LINE, so yin_d/ybd_d change once per 2200 clocks and their register is a
// formality.  Only the px pair is genuinely per-pixel.  A future edit that
// needs a clock back can pipeline the y pair arbitrarily deep for free.
//------------------------------------------------------------------------
reg xin_d, xbd_d, yin_d, ybd_d;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        xin_d <= 1'b0; xbd_d <= 1'b0; yin_d <= 1'b0; ybd_d <= 1'b0;
    end else begin
        xin_d <= (px >= tx0) && (px <= tx1);
        xbd_d <= (px <= txa) || (px >= txb);
        yin_d <= (py >= ty0) && (py <= ty1);
        ybd_d <= (py <= tya) || (py >= tyb);
    end
end

// Stage 2.  Named _d1 because it is contemporaneous with border_d1, not
// because it is itself registered -- the registers are the four flags above.
wire trk_d1 = track_en && trk_draw_en
              && xin_d && yin_d && (xbd_d | ybd_d);

reg [23:0] rgb_d1;
reg        border_d1;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        rgb_d1 <= 24'd0; border_d1 <= 1'b0;
    end else begin
        rgb_d1 <= in_rgb; border_d1 <= border_c;
    end
end

reg [23:0] out_rgb_r;

// The tracker wins an overlap.  It is the one the head steers on, so where
// the two disagree the useful thing to see is the one that is in control.
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) out_rgb_r <= 24'd0;
    else        out_rgb_r <= (DRAW_EN != 0 && trk_d1)    ? {TRK_R, TRK_G, TRK_B} :
                             (DRAW_EN != 0 && border_d1) ? {BOX_R, BOX_G, BOX_B} : rgb_d1;
end

assign out_rgb = out_rgb_r;

//------------------------------------------------------------------------
// [7] Sync, delayed to match
//------------------------------------------------------------------------
reg [MD_SYNC_DLY-1:0] vs_dly, de_dly;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        vs_dly <= {MD_SYNC_DLY{1'b0}};
        de_dly <= {MD_SYNC_DLY{1'b0}};
    end else begin
        vs_dly <= {vs_dly[MD_SYNC_DLY-2:0], in_vs};
        de_dly <= {de_dly[MD_SYNC_DLY-2:0], in_de};
    end
end

assign out_vs = vs_dly[MD_SYNC_DLY-1];
assign out_de = de_dly[MD_SYNC_DLY-1];

endmodule
