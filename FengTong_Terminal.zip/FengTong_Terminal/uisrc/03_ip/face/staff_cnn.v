//---------------------------------------------------------------------------
// staff_cnn -- the staff recogniser: an INT8 CNN that turns one 64x64 gray face
// patch into a 128-d embedding, scores it against the staff template, and runs
// two liveness logits (eyes closed / mouth open) off the same backbone.
//
// WHAT IT COMPUTES is defined, bit for bit, by tools/staff_id/staff_q.py
// (int_forward, int_live) and tools/staff_id/export_hex.py (golden, match).
// If the two ever disagree, THOSE are the specification.
//
//   norm   min/max stretch of the patch into mA, face_cnn's rule and RCP table
//   P0 L1  mA 1x64x64    -> mB 16x32x32    conv3x3 + pool + requant
//   P1 L2  mB            -> mA 32x16x16
//   P2 LIV mA            -> mB@8192 16x8x8  liveness conv on L2's map
//   P3 L3  mA            -> mB 64x8x8
//   P4 L4  mB            -> mA 64x4x4
//   P5 LFC mB@8192 (1024) -> live0, live1  raw logits (acc + bias, no shift)
//   P6 GDC mA (64 x 16)   -> mB@12288 64    one 4x4 depthwise MAC per channel
//   P7 EMB mB@12288 (64)  -> vram 128 x int13   v' = clamp((v + 2^(SV-1)) >> SV)
//   P8     d = v'.t, nv = v'.v', nt = t.t ;  score = (d^2 << 12) / (nv nt)
//          if d > 0, else 0.  score is cos^2 in Q12: 4096 = identical direction.
//
// WHY A SECOND ENGINE AND NOT face_cnn'S.  face_cnn's schedule is the right
// one (eight output channels side by side, pool on the raw accumulator, one
// input pixel and one 64-bit weight word per clock) and this file copies it,
// down to the pipeline stage numbers.  What it cannot do is be shared: the two
// run on different patches at the same time (face_cnn every ROI, every frame),
// and its map/ROM shapes are 32x32 and three layers.  Eight more multipliers is
// cheaper than an arbiter and a second set of address cases in face_cnn.v.
//
// THE MATCH IS A RATIO, NOT A DOT PRODUCT.  The template is a direction; how
// long the embedding is depends on the patch's contrast and on the person (the
// staff member's is ~3x a stranger's, the stage-2 loss pulls it out).  So the
// score is cos^2 = d^2 / (|v|^2 |t|^2), computed exactly with a shift-add
// multiply and a 13-step restoring division -- ~200 clocks, once per patch,
// with nothing in it wider than one 66-bit subtract per clock.
//
// CLOCKS per patch ~ 1.85 M (L2 and L3 are 0.6 M each), i.e. ~12 ms at 150 MHz:
// one recognition per 60 Hz frame.  Nothing downstream needs more than 10/s.
//
// ROMs, all bare-filename $readmemh -- this file MUST stay in uisrc/03_ip/face/
// beside them (readmemh resolves against the caller, and fails silent):
//   staff_w.hex   9106 x 64  conv P0..P4 then EMB           (export_hex.py)
//   staff_g.hex   1024 x 8   GDC                            (export_hex.py)
//   staff_lf.hex  1024 x 16  liveness FC                    (export_hex.py)
//   staff_b.hex    512 x 32  biases                         (export_hex.py)
//   staff_sh.hex   256 x 8   requant shifts                 (export_hex.py)
//   staff_t.hex    128 x 8   the staff template             (export_hex.py)
//   cnn_rcp.hex    256 x 16  face_cnn's stretch table       (fixed)
// A missing file is an all-zero ROM: score 0 forever, which on the board reads
// exactly like "never recognises the staff member".  grep the synthesis log
// for readmem after every build.
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module staff_cnn #(
parameter integer SV = 5                     // export_hex.SV
)(
input  wire        clk,
input  wire        rst_n,

// patch buffer read port: {row[5:0], col[5:0]}, data one clock after
output reg  [11:0] buf_ra,
input  wire [7:0]  buf_q,

input  wire        start,
output reg         busy,
output reg         done,                    // one clock; outputs valid from here

output reg  [12:0] score,                   // cos^2 in Q12, 0 when cos <= 0
output reg  signed [31:0] live0,            // eyes-closed logit
output reg  signed [31:0] live1             // mouth-open logit
);

//---------------------------------------------------------------------------
// ROMs, maps
//---------------------------------------------------------------------------
reg [63:0] w_rom  [0:9105];
reg [7:0]  g_rom  [0:1023];
reg [15:0] lf_rom [0:1023];
reg [31:0] b_rom  [0:511];
reg [7:0]  sh_rom [0:255];
reg [7:0]  t_rom  [0:127];
reg [15:0] rcp_rom[0:255];

initial begin
    $readmemh("staff_w.hex",  w_rom);
    $readmemh("staff_g.hex",  g_rom);
    $readmemh("staff_lf.hex", lf_rom);
    $readmemh("staff_b.hex",  b_rom);
    $readmemh("staff_sh.hex", sh_rom);
    $readmemh("staff_t.hex",  t_rom);
    $readmemh("cnn_rcp.hex",  rcp_rom);
end

reg  [13:0] w_ra;
reg  [9:0]  g_ra, lf_ra;
reg  [8:0]  b_ra;
reg  [7:0]  d_r;
reg  [6:0]  t_ra;
reg  [63:0] w_q;
reg  [7:0]  g_q;
reg  [15:0] lf_q;
reg  [31:0] b_q;
reg  [7:0]  sh_q;
reg  [7:0]  t_q;
reg  [15:0] rcp_q;

always @(posedge clk) begin
    w_q   <= w_rom[w_ra];
    g_q   <= g_rom[g_ra];
    lf_q  <= lf_rom[lf_ra];
    b_q   <= b_rom[b_ra];
    sh_q  <= sh_rom[b_ra[7:0]];
    t_q   <= t_rom[t_ra];
    rcp_q <= rcp_rom[d_r];
end

// mA: input 64x64, then L2's 32x16x16, then L4's 64x4x4.
// mB: L1's 16x32x32, L3's 64x8x8 at 0, the liveness map at 8192, GDC at 12288.
// Layout everywhere is c*H*W + y*W + x, i.e. torch's (C, H, W).
reg [7:0]  mA [0:8191];
reg [7:0]  mB [0:16383];
reg [13:0] fm_ra;
reg [7:0]  mA_q, mB_q;
reg        mA_we, mB_we;
reg [13:0] m_wa;
reg [7:0]  m_wd;

always @(posedge clk) begin
    mA_q <= mA[fm_ra[12:0]];
    mB_q <= mB[fm_ra];
    if (mA_we) mA[m_wa[12:0]] <= m_wd;
    if (mB_we) mB[m_wa]       <= m_wd;
end

reg [12:0] vram [0:127];                    // P7's output, P8's input
reg [6:0]  v_ra;
reg [12:0] v_q;
reg        v_we;
reg [6:0]  v_wa;
reg [12:0] v_wd;

always @(posedge clk) begin
    v_q <= vram[v_ra];
    if (v_we) vram[v_wa] <= v_wd;
end

//---------------------------------------------------------------------------
// FSM
//---------------------------------------------------------------------------
localparam [4:0] S_IDLE = 5'd0,
                 S_MM   = 5'd1,     // read the patch once: min and max
                 S_MMW  = 5'd2,
                 S_RCP  = 5'd3,
                 S_RCPW = 5'd4,
                 S_NRM  = 5'd5,     // read it again: stretch into mA
                 S_NRMW = 5'd6,
                 S_PS   = 5'd7,     // load the pass's start pointers
                 S_MAC  = 5'd8,     // issue one pre-pool position (or one FC row)
                 S_DRN  = 5'd9,     // wait for its last product to land
                 S_RQ   = 5'd10,    // requant the lanes into the next map
                 S_RQW  = 5'd11,
                 S_MT   = 5'd12,    // P8: d, nv, nt over 128 entries
                 S_MTW  = 5'd13,
                 S_MUL  = 5'd14,    // d^2 and nv*nt, shift-add
                 S_DIV  = 5'd15,    // (d^2 << 12) / (nv nt), restoring
                 S_FIN  = 5'd16;

reg [4:0]  st;
reg [2:0]  ps;                      // pass P0..P7
reg [11:0] n;                       // patch pixel index; FC input index
reg [7:0]  mn, mx;
reg [3:0]  wcnt;

reg [5:0]  g;                       // lane group (GDC: the channel)
reg [4:0]  py, px;                  // pooled output position
reg [1:0]  s;                       // pre-pool position within the 2x2
reg [5:0]  ic;
reg [1:0]  ky, kx;
reg [13:0] wptr, wgrp;
reg [2:0]  j;                       // requant lane

// Per-pass shape (export_hex.py's table).
wire       is_conv = (ps <= 3'd4);
wire       is_lfc  = (ps == 3'd5);
wire       is_gdc  = (ps == 3'd6);
wire       is_emb  = (ps == 3'd7);
wire       rd_B    = (ps == 3'd1) || (ps == 3'd4) || (ps == 3'd5) || (ps == 3'd7);

reg [5:0]  cin_m1;
reg [5:0]  ng_m1;
reg [4:0]  pw_m1;
reg [9:0]  nin_m1;
reg [9:0]  wper;
reg [13:0] wbase;
reg [8:0]  bbase;
reg [2:0]  nl_m1;

always @(*) begin
    cin_m1 = 6'd0; ng_m1 = 6'd0; pw_m1 = 5'd0; nin_m1 = 10'd0;
    wper = 10'd0; wbase = 14'd0; bbase = 9'd0; nl_m1 = 3'd7;
    case (ps)
    3'd0: begin cin_m1 = 6'd0;  ng_m1 = 6'd1;  pw_m1 = 5'd31; wper = 10'd9;   wbase = 14'd0;    bbase = 9'd0;   end
    3'd1: begin cin_m1 = 6'd15; ng_m1 = 6'd3;  pw_m1 = 5'd15; wper = 10'd144; wbase = 14'd18;   bbase = 9'd16;  end
    3'd2: begin cin_m1 = 6'd31; ng_m1 = 6'd1;  pw_m1 = 5'd7;  wper = 10'd288; wbase = 14'd594;  bbase = 9'd48;  end
    3'd3: begin cin_m1 = 6'd31; ng_m1 = 6'd7;  pw_m1 = 5'd7;  wper = 10'd288; wbase = 14'd1170; bbase = 9'd64;  end
    3'd4: begin cin_m1 = 6'd63; ng_m1 = 6'd7;  pw_m1 = 5'd3;  wper = 10'd576; wbase = 14'd3474; bbase = 9'd128; end
    3'd5: begin nin_m1 = 10'd1023; ng_m1 = 6'd0;  bbase = 9'd384; nl_m1 = 3'd1; end
    3'd6: begin nin_m1 = 10'd15;   ng_m1 = 6'd63; bbase = 9'd192; nl_m1 = 3'd0; end
    default: begin nin_m1 = 10'd63; ng_m1 = 6'd15; wper = 10'd64; wbase = 14'd8082; bbase = 9'd256; end
    endcase
end

// The input pixel this clock's MAC wants.  iy/ix run from -1 to H, carried as
// 8-bit signed; out of range reads as the zero padding.  Every map is a power
// of two on a side and every base a power-of-two boundary, so the address is a
// per-pass bit concatenation -- no adders in front of the RAM (face_cnn.v).
wire [5:0]        y_c = {py, s[1]};
wire [5:0]        x_c = {px, s[0]};
wire signed [7:0] iy  = $signed({2'b00, y_c}) + $signed({6'd0, ky}) - 8'sd1;
wire signed [7:0] ix  = $signed({2'b00, x_c}) + $signed({6'd0, kx}) - 8'sd1;
reg               inb;
reg  [13:0]       ain;
always @(*) begin
    case (ps)
    3'd0:    begin inb = (iy[7:6] == 2'b00) && (ix[7:6] == 2'b00);   ain = {2'b00, iy[5:0], ix[5:0]};         end
    3'd1:    begin inb = (iy[7:5] == 3'b000) && (ix[7:5] == 3'b000); ain = {ic[3:0], iy[4:0], ix[4:0]};       end
    3'd2,
    3'd3:    begin inb = (iy[7:4] == 4'd0) && (ix[7:4] == 4'd0);     ain = {1'b0, ic[4:0], iy[3:0], ix[3:0]}; end
    3'd4:    begin inb = (iy[7:3] == 5'd0) && (ix[7:3] == 5'd0);     ain = {2'b00, ic[5:0], iy[2:0], ix[2:0]}; end
    3'd5:    begin inb = 1'b1; ain = {4'b1000, n[9:0]};               end
    3'd6:    begin inb = 1'b1; ain = {4'b0000, g[5:0], n[3:0]};       end
    default: begin inb = 1'b1; ain = {2'b11, 6'd0, n[5:0]};           end
    endcase
end

wire mac_first = is_conv ? ((ic == 6'd0) && (ky == 2'd0) && (kx == 2'd0)) : (n[9:0] == 10'd0);
wire mac_last  = is_conv ? ((ic == cin_m1) && (ky == 2'd2) && (kx == 2'd2)) : (n[9:0] == nin_m1);

//---------------------------------------------------------------------------
// Datapath pipelines.  Stage numbers count clocks after the counters.
//---------------------------------------------------------------------------
reg        rd_v1, rd_v2;
reg [11:0] rd_n1, rd_n2;
reg        nm_vd, nm_v3;
reg [11:0] nm_nd, nm_n3;
reg [7:0]  nm_d;
reg [23:0] nm_p;

reg        p1_v, p1_inb, p1_first, p1_last;
reg        p2_v, p2_inb, p2_first, p2_last;
reg        p3_v, p3_first, p3_last;
reg        p4_v, p4_first, p4_last;
reg        p5_last;
reg signed [8:0]  a_r;
reg        [63:0] w_r;
reg signed [16:0] prod [0:7];
reg signed [31:0] acc  [0:7];
reg signed [31:0] pmx  [0:7];

reg        rq_v1, rq_v3, rq_v4, rq_v5;
reg [2:0]  rq_j1, rq_j3, rq_j4, rq_j5;
reg [13:0] rq_a3, rq_a4, rq_a5;
reg signed [31:0] rq_x, rq_t, rq_r;
reg [4:0]  rq_s3, rq_s4;

wire [7:0] fm_q = rd_B ? mB_q : mA_q;

// Where requant writes lane jj of the current pooled output / group.
function [13:0] aout;
    input [2:0] p;
    input [5:0] gg;
    input [2:0] jj;
    input [4:0] yy, xx;
    case (p)
    3'd0:    aout = {gg[0], jj, yy[4:0], xx[4:0]};                       // B 16x32x32
    3'd1:    aout = {1'b0, gg[1:0], jj, yy[3:0], xx[3:0]};               // A 32x16x16
    3'd2:    aout = {1'b1, 3'b000, gg[0], jj, yy[2:0], xx[2:0]};         // B@8192 16x8x8
    3'd3:    aout = {2'b00, gg[2:0], jj, yy[2:0], xx[2:0]};              // B 64x8x8
    3'd4:    aout = {3'b000, gg[2:0], jj, yy[1:0], xx[1:0]};             // A 64x4x4
    3'd6:    aout = {2'b11, 6'd0, gg[5:0]};                              // B@12288
    default: aout = {7'd0, gg[3:0], jj};                                 // vram / live
    endcase
endfunction

wire [7:0]  rq_c   = rq_r[31] ? 8'd0 : (|rq_r[30:8]) ? 8'd255 : rq_r[7:0];
wire [12:0] rq_v13 = (rq_r < -32'sd4096) ? 13'h1000 : (rq_r > 32'sd4095) ? 13'h0FFF : rq_r[12:0];

// P8
reg        mt_v1, mt_v2, mt_v3;
reg signed [20:0] pd;
reg        [25:0] pv;
reg        [14:0] pt;
reg signed [27:0] dsum;
reg        [31:0] nv;
reg        [21:0] nt;
reg        [63:0] mul_a1, mul_a2, dd, den;
reg        [31:0] mul_b1;
reg        [21:0] mul_b2;
reg        [5:0]  mcnt;
reg        [65:0] rem, dv;
reg        [12:0] q;

integer i;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        st <= S_IDLE; busy <= 1'b0; done <= 1'b0;
        score <= 13'd0; live0 <= 32'sd0; live1 <= 32'sd0;
        buf_ra <= 12'd0;
        ps <= 3'd0; n <= 12'd0; mn <= 8'hFF; mx <= 8'h00; wcnt <= 4'd0;
        g <= 6'd0; py <= 5'd0; px <= 5'd0; s <= 2'd0;
        ic <= 6'd0; ky <= 2'd0; kx <= 2'd0; wptr <= 14'd0; wgrp <= 14'd0; j <= 3'd0;
        w_ra <= 14'd0; g_ra <= 10'd0; lf_ra <= 10'd0; b_ra <= 9'd0; d_r <= 8'd0; t_ra <= 7'd0;
        fm_ra <= 14'd0; mA_we <= 1'b0; mB_we <= 1'b0; m_wa <= 14'd0; m_wd <= 8'd0;
        v_ra <= 7'd0; v_we <= 1'b0; v_wa <= 7'd0; v_wd <= 13'd0;
        rd_v1 <= 1'b0; rd_v2 <= 1'b0; rd_n1 <= 12'd0; rd_n2 <= 12'd0;
        nm_vd <= 1'b0; nm_nd <= 12'd0; nm_d <= 8'd0;
        nm_v3 <= 1'b0; nm_n3 <= 12'd0; nm_p <= 24'd0;
        p1_v <= 1'b0; p1_inb <= 1'b0; p1_first <= 1'b0; p1_last <= 1'b0;
        p2_v <= 1'b0; p2_inb <= 1'b0; p2_first <= 1'b0; p2_last <= 1'b0;
        p3_v <= 1'b0; p3_first <= 1'b0; p3_last <= 1'b0;
        p4_v <= 1'b0; p4_first <= 1'b0; p4_last <= 1'b0;
        p5_last <= 1'b0;
        a_r <= 9'sd0; w_r <= 64'd0;
        rq_v1 <= 1'b0; rq_v3 <= 1'b0; rq_v4 <= 1'b0; rq_v5 <= 1'b0;
        rq_j1 <= 3'd0; rq_j3 <= 3'd0; rq_j4 <= 3'd0; rq_j5 <= 3'd0;
        rq_a3 <= 14'd0; rq_a4 <= 14'd0; rq_a5 <= 14'd0;
        rq_x <= 32'sd0; rq_t <= 32'sd0; rq_r <= 32'sd0; rq_s3 <= 5'd0; rq_s4 <= 5'd0;
        for (i = 0; i < 8; i = i + 1) begin
            prod[i] <= 17'sd0; acc[i] <= 32'sd0; pmx[i] <= 32'sd0;
        end
        mt_v1 <= 1'b0; mt_v2 <= 1'b0; mt_v3 <= 1'b0;
        pd <= 21'sd0; pv <= 26'd0; pt <= 15'd0; dsum <= 28'sd0; nv <= 32'd0; nt <= 22'd0;
        mul_a1 <= 64'd0; mul_a2 <= 64'd0; dd <= 64'd0; den <= 64'd0;
        mul_b1 <= 32'd0; mul_b2 <= 22'd0; mcnt <= 6'd0;
        rem <= 66'd0; dv <= 66'd0; q <= 13'd0;
    end else begin
        done  <= 1'b0;
        mA_we <= 1'b0;
        mB_we <= 1'b0;
        v_we  <= 1'b0;

        //-------------------------------------------------------------------
        // [norm] patch read pipe: buf_ra at +1, buf_q at +2 (face_cnn.v).
        //-------------------------------------------------------------------
        rd_v1 <= (st == S_MM) || (st == S_NRM);
        rd_n1 <= n;
        rd_v2 <= rd_v1;
        rd_n2 <= rd_n1;

        if (rd_v2 && (st == S_MM || st == S_MMW)) begin
            if (buf_q < mn) mn <= buf_q;
            if (buf_q > mx) mx <= buf_q;
        end

        nm_vd <= rd_v2 && (st == S_NRM || st == S_NRMW);
        nm_nd <= rd_n2;
        nm_d  <= buf_q - mn;
        nm_v3 <= nm_vd;
        nm_n3 <= nm_nd;
        nm_p  <= nm_d * rcp_q;
        if (nm_v3) begin
            mA_we <= 1'b1;
            m_wa  <= {2'b00, nm_n3};
            m_wd  <= (nm_p[23:8] + {15'd0, nm_p[7]} > 16'd255) ? 8'd255 : (nm_p[15:8] + {7'd0, nm_p[7]});
        end

        //-------------------------------------------------------------------
        // [mac] 1: addresses.  2: RAM/ROM out.  3: operand select.
        // 4: multiply.  5: accumulate.
        //-------------------------------------------------------------------
        p1_v     <= (st == S_MAC);
        p1_inb   <= inb;
        p1_first <= mac_first;
        p1_last  <= mac_last;
        fm_ra    <= ain;
        w_ra     <= wptr;
        g_ra     <= {g[5:0], n[3:0]};
        lf_ra    <= n[9:0];

        p2_v <= p1_v; p2_inb <= p1_inb; p2_first <= p1_first; p2_last <= p1_last;

        // Every map holds uint8, L1's input included (the float model's input
        // is the stretch in [0,1], so its zero padding is 0 here too).
        a_r <= p2_inb ? $signed({1'b0, fm_q}) : 9'sd0;
        w_r <= is_lfc ? {48'd0, lf_q} : is_gdc ? {56'd0, g_q} : w_q;
        p3_v <= p2_v; p3_first <= p2_first; p3_last <= p2_last;

        for (i = 0; i < 8; i = i + 1)
            prod[i] <= a_r * $signed(w_r[i*8 +: 8]);
        p4_v <= p3_v; p4_first <= p3_first; p4_last <= p3_last;

        if (p4_v)
            for (i = 0; i < 8; i = i + 1)
                acc[i] <= p4_first ? {{15{prod[i][16]}}, prod[i]}
                                   : acc[i] + {{15{prod[i][16]}}, prod[i]};
        p5_last <= p4_v && p4_last;

        //-------------------------------------------------------------------
        // [requant] b_ra counts in S_RQ, so b_q/sh_q line up with rq_v1.
        // 3: + bias.  4: + rounding.  5: shift.  then clamp + write.
        // EMB uses SV instead of the ROM shift and clamps to int13.
        //-------------------------------------------------------------------
        rq_v1 <= (st == S_RQ);
        rq_j1 <= j;

        rq_v3 <= rq_v1;
        rq_j3 <= rq_j1;
        rq_x  <= pmx[rq_j1] + $signed(b_q);
        rq_s3 <= is_emb ? SV[4:0] : sh_q[4:0];
        rq_a3 <= aout(ps, g, rq_j1, py, px);

        rq_v4 <= rq_v3;
        rq_j4 <= rq_j3;
        rq_t  <= rq_x + ((rq_s3 == 5'd0) ? 32'sd0 : (32'sd1 <<< (rq_s3 - 5'd1)));
        rq_s4 <= rq_s3;
        rq_a4 <= rq_a3;

        rq_v5 <= rq_v4;
        rq_j5 <= rq_j4;
        rq_r  <= rq_t >>> rq_s4;
        rq_a5 <= rq_a4;

        if (rq_v3 && is_lfc) begin
            if (rq_j3[0]) live1 <= rq_x;
            else          live0 <= rq_x;
        end
        if (rq_v5 && is_emb) begin
            v_we <= 1'b1;
            v_wa <= rq_a5[6:0];
            v_wd <= rq_v13;
        end
        if (rq_v5 && !is_emb && !is_lfc) begin
            if (rd_B) mA_we <= 1'b1;        // a pass that reads B writes A
            else      mB_we <= 1'b1;
            m_wa <= rq_a5;
            m_wd <= rq_c;
        end

        //-------------------------------------------------------------------
        // [match] after edge 0: v_ra/t_ra.  1: v_q/t_q.  2: products.  3: sums.
        //-------------------------------------------------------------------
        mt_v1 <= (st == S_MT);
        mt_v2 <= mt_v1;
        mt_v3 <= mt_v2;
        pd    <= $signed(v_q) * $signed(t_q);
        pv    <= $signed(v_q) * $signed(v_q);
        pt    <= $signed(t_q) * $signed(t_q);
        if (mt_v3) begin
            dsum <= dsum + {{7{pd[20]}}, pd};
            nv   <= nv + {6'd0, pv};
            nt   <= nt + {7'd0, pt};
        end

        //-------------------------------------------------------------------
        case (st)
        S_IDLE: begin
            if (start) begin
                busy <= 1'b1;
                n    <= 12'd0;
                mn   <= 8'hFF;
                mx   <= 8'h00;
                st   <= S_MM;
            end
        end

        S_MM, S_NRM: begin
            buf_ra <= n;
            n      <= n + 12'd1;
            if (n == 12'd4095) begin
                wcnt <= 4'd0;
                st   <= (st == S_MM) ? S_MMW : S_NRMW;
            end
        end

        S_MMW: begin
            wcnt <= wcnt + 4'd1;
            if (wcnt == 4'd3) st <= S_RCP;
        end

        S_RCP: begin
            d_r  <= mx - mn;
            wcnt <= 4'd0;
            st   <= S_RCPW;
        end

        S_RCPW: begin
            wcnt <= wcnt + 4'd1;
            if (wcnt == 4'd1) begin
                n  <= 12'd0;
                st <= S_NRM;
            end
        end

        S_NRMW: begin                       // last mA write lands at +5
            wcnt <= wcnt + 4'd1;
            if (wcnt == 4'd6) begin
                ps <= 3'd0;
                st <= S_PS;
            end
        end

        S_PS: begin
            g <= 6'd0; py <= 5'd0; px <= 5'd0; s <= 2'd0;
            ic <= 6'd0; ky <= 2'd0; kx <= 2'd0; n <= 12'd0;
            wgrp <= wbase; wptr <= wbase;
            st <= S_MAC;
        end

        S_MAC: begin
            wptr <= wptr + 14'd1;
            if (!is_conv) begin
                n <= n + 12'd1;
                if (n[9:0] == nin_m1) st <= S_DRN;
            end else if (kx == 2'd2) begin
                kx <= 2'd0;
                if (ky == 2'd2) begin
                    ky <= 2'd0;
                    if (ic == cin_m1) begin
                        ic <= 6'd0;
                        st <= S_DRN;
                    end else
                        ic <= ic + 6'd1;
                end else
                    ky <= ky + 2'd1;
            end else
                kx <= kx + 2'd1;
        end

        S_DRN: begin
            if (p5_last) begin
                if (!is_conv) begin
                    for (i = 0; i < 8; i = i + 1)
                        pmx[i] <= acc[i];
                    j    <= 3'd0;
                    b_ra <= bbase + (is_gdc ? {3'd0, g} : {g[5:0], 3'b000});
                    st   <= S_RQ;
                end else begin
                    for (i = 0; i < 8; i = i + 1)
                        if (s == 2'd0 || acc[i] > pmx[i]) pmx[i] <= acc[i];
                    if (s == 2'd3) begin
                        j    <= 3'd0;
                        b_ra <= bbase + {g[5:0], 3'b000};
                        st   <= S_RQ;
                    end else begin
                        s    <= s + 2'd1;
                        wptr <= wgrp;
                        st   <= S_MAC;
                    end
                end
            end
        end

        S_RQ: begin
            j    <= j + 3'd1;
            b_ra <= b_ra + 9'd1;
            if (j == nl_m1) begin
                wcnt <= 4'd0;
                st   <= S_RQW;
            end
        end

        S_RQW: begin                        // last lane's write lands at +6
            wcnt <= wcnt + 4'd1;
            if (wcnt == 4'd6) begin
                s <= 2'd0;
                n <= 12'd0;
                if (is_conv && px != pw_m1) begin
                    px <= px + 5'd1; wptr <= wgrp; st <= S_MAC;
                end else if (is_conv && py != pw_m1) begin
                    px <= 5'd0; py <= py + 5'd1; wptr <= wgrp; st <= S_MAC;
                end else begin
                    px <= 5'd0; py <= 5'd0;
                    wgrp <= wgrp + {4'd0, wper};
                    wptr <= wgrp + {4'd0, wper};
                    if (g != ng_m1) begin
                        g  <= g + 6'd1;
                        st <= S_MAC;
                    end else if (ps == 3'd7) begin
                        n    <= 12'd0;
                        dsum <= 28'sd0; nv <= 32'd0; nt <= 22'd0;
                        st   <= S_MT;
                    end else begin
                        ps <= ps + 3'd1;
                        st <= S_PS;
                    end
                end
            end
        end

        S_MT: begin
            v_ra <= n[6:0];
            t_ra <= n[6:0];
            n    <= n + 12'd1;
            if (n[6:0] == 7'd127) begin
                wcnt <= 4'd0;
                st   <= S_MTW;
            end
        end

        S_MTW: begin                        // last sum lands at +4
            wcnt <= wcnt + 4'd1;
            if (wcnt == 4'd5) begin
                if (dsum <= 28'sd0 || nv == 32'd0) begin
                    q  <= 13'd0;
                    st <= S_FIN;
                end else begin
                    mul_a1 <= {36'd0, dsum}; mul_b1 <= {4'd0, dsum};
                    mul_a2 <= {32'd0, nv};   mul_b2 <= nt;
                    dd <= 64'd0; den <= 64'd0;
                    mcnt <= 6'd0;
                    st <= S_MUL;
                end
            end
        end

        S_MUL: begin                        // 32 steps: dd = d*d, den = nv*nt
            if (mul_b1[0]) dd  <= dd  + mul_a1;
            if (mul_b2[0]) den <= den + mul_a2;
            mul_a1 <= mul_a1 << 1; mul_b1 <= mul_b1 >> 1;
            mul_a2 <= mul_a2 << 1; mul_b2 <= mul_b2 >> 1;
            mcnt <= mcnt + 6'd1;
            if (mcnt == 6'd31) begin
                mcnt <= 6'd0;
                st   <= S_DIV;
            end
        end

        S_DIV: begin                        // 13 steps, quotient bit 12 first
            if (mcnt == 6'd0) begin
                rem  <= {2'b00, dd} << 12;
                dv   <= {2'b00, den} << 12;
                q    <= 13'd0;
                mcnt <= 6'd1;
            end else begin
                if (rem >= dv) begin
                    rem <= rem - dv;
                    q   <= {q[11:0], 1'b1};
                end else
                    q   <= {q[11:0], 1'b0};
                dv   <= dv >> 1;
                mcnt <= mcnt + 6'd1;
                if (mcnt == 6'd13) st <= S_FIN;
            end
        end

        S_FIN: begin
            score <= q;
            busy  <= 1'b0;
            done  <= 1'b1;
            st    <= S_IDLE;
        end

        default: st <= S_IDLE;
        endcase
    end
end

endmodule
