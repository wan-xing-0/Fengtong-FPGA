//---------------------------------------------------------------------------
// face_roi_buf -- turns candidate boxes into 32x32 grayscale patches the
// classifier can read, one patch per ROI.
//
// This is the piece that decides WHAT face_cascade looks at, and therefore the
// piece most likely to be the reason a real face is missed.  The classifier
// itself is bit-exact against OpenCV (fctb, 168 checks), so when a face on the
// board fails to box, suspect the framing and the scale here first.
//
// WHERE THE BOXES COME FROM
// Two sources, deliberately unlike each other:
//   * skin blobs -- face_skin -> det_morph_open -> ccl_blob, area-sorted.  The
//     primary source.  Chroma finds a face on a wall of any brightness.
//   * motion boxes -- motion_frame_drawer's published block boxes.  The
//     fallback, for someone under a strange lamp whose chroma lands outside the
//     skin box but who is nonetheless moving.
// Skin boxes fill the slots first because they are the better evidence; motion
// boxes take whatever is left and are dropped if their centre already sits
// inside a chosen ROI, which is what stops one person eating all four slots.
//
// THE SCALE PROBLEM, AND WHY THE FIRST ANSWER WAS NOT A COMPROMISE BUT A BUG
// A 24x24 classifier window only fires on a face that is about 24 pixels across
// IN THE PATCH.  So the patch has to be cut at a size proportional to the face,
// which is exactly what a candidate box gives -- its size IS the scale estimate.
// The patch is therefore the box, re-sampled to 32x32.
//
// The 09-19 version snapped the side to a POWER OF TWO so that re-sampling was
// "take every 2^n-th pixel" -- a mask and a shift.  Its header called the
// resulting sqrt(2) scale error a compromise.  It is not: window times stride
// means the only detectable face widths were WIN*2^n = 24/48/96/192/384/768 px,
// an octave ladder with NOTHING in between, against a cascade that tolerates
// about +-12%.  Two thirds of all subject distances were unreachable by
// arithmetic, not by tuning.  The board said exactly that -- a face at ~760 px
// (the 768 rung) was boxed, the same face a hand's width nearer or farther was
// not, and nothing else about the picture had changed.
//
// SO THE STRIDE IS A DDA (Bresenham) NOW, NOT A SHIFT.  Per ROI and per axis an
// accumulator holds (n+1)*side and the next sample point is its top bits, i.e.
// floor(n*side/32).  One add and one compare per axis per ROI: still no divide,
// no multiply and no line buffer, and it RETIRES the four variable barrel
// shifters the mask version needed in the pixel path, which were the expensive
// part.  side is now free to take any value, so the face lands at the window's
// size to within the accuracy of the candidate box itself.
//
// The one thing the DDA cannot do is emit two samples from one pixel, so side
// must be at least BUFN.  That is SIDE_MIN, and it is not a restriction: a side
// under 32 was upsampling, which cannot create detail a 24px window needs.
//
// SIDE = 1.5 x THE BOX, and the 1.5 is not arbitrary.  The window is 24 of the
// patch's 32 pixels, so at the centre slide position it covers 75% of the ROI.
// A skin blob is tighter than a face -- hair and eyes are not skin -- so the
// window wants to be about 15% wider than the blob.  0.75 x 1.5 = 1.125, which
// is that margin.  Nothing rounds it any more.
//
// TWO SIDES PER CANDIDATE (NSCALE).  1.125 x the blob is a good estimate of the
// face, not an exact one: glasses and brows cut a skin mask in half and hair
// hides a forehead.  A horizontally split blob keeps its WIDTH, so cm and the
// scale survive -- what drifts is the centre, and the estimate with it, by about
// 20%.  The cascade will not absorb that either.  So every accepted candidate is
// enrolled TWICE, at side and at 1.25 x side, which together cover face/blob
// ratios of roughly 1.0 to 1.6 and also widen the slide range (the window slides
// over +-side/8, so a bigger rung reaches a worse-centred face).
//
// That spends ROI SLOTS, not clocks: a full 9-position scan is 6,416 clocks, so
// four ROIs are ~1% of a frame (section 3.-10-D).  Because slots no longer map
// one-to-one to faces, dbg_nroi counts CANDIDATES rather than slots -- the OSD's
// FACES reading has to keep meaning "faces offered to the classifier", or the
// n=0 / n>0-m=0 split in section 3.-10-H stops pointing anywhere.
//
// WHY THE BUFFER IS DOUBLE-BANKED
// The pixel side fills a patch across the whole visible frame; the classifier
// reads a patch across the whole visible frame too, because a 25,664-clock scan
// does not fit in the ~11,000-clock frame-end window (section 3.-8 -- `vs` is a
// 5-line sync pulse, not the frame interval, and assuming otherwise is what
// starved ccl_blob's publish pass).  So writer and reader are concurrent, and
// they are given separate banks rather than an arbiter.  Two banks of four
// patches is 4 ERAMs total and removes the entire question.
//
// The swap is held off while the classifier is mid-scan (`rd_busy`).  A held-off
// swap costs one frame of freshness and nothing else: the writer simply refills
// the same bank, and the reader's bank is untouched either way.
//
// ONE RAM PER ROI, not one RAM with four regions.  Overlapping ROIs can want to
// store the same incoming pixel in the same clock, and four independent RAMs
// answer that with no arbitration at all.  A single RAM would need either a
// write arbiter or a guarantee that ROIs never overlap, and the dedup rule above
// is about centres, so it does not give that guarantee.
//
// vs POLARITY: in_vs is HIGH across the visible frame, like af_out_vs and
// det_binarize's in_vs.  NOT the 5-line sync pulse.
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module face_roi_buf #(
parameter integer IMG_HDISP = 1920,
parameter integer IMG_VDISP = 1080,

parameter integer BUFN   = 32,      // patch is BUFN x BUFN
parameter integer NROI   = 4,
parameter integer NSKIN  = 8,       // ccl_blob's NBLOB on the skin chain

// Motion grid, must match motion_frame_drawer.
parameter integer BLK_W  = 128,
parameter integer BLK_H  = 72,

// ROI side in PIXELS, clamped to SIDE_MIN .. SIDE_MAX.  SIDE_MIN must be BUFN or
// more: the DDA emits at most one sample per pixel, so a shorter side would want
// two patch columns out of one pixel and would silently drop one.  SIDE_MAX
// keeps the ROI inside the SHORTER frame axis, which is what guarantees no
// sample point ever lands outside the picture -- the origin clamp below can only
// slide the ROI, it cannot shrink it.
parameter integer SIDE_MIN = 32,
parameter integer SIDE_MAX = IMG_VDISP,

// Y_TOP (10-04) -- no ROI starts above this line.  0 = the old clamp, bit-exact.
// The picture's first ~6 lines are not picture: the 12:13 board recording shows
// a flat band and a wrongly-coloured band there on every frame (somewhere
// upstream of af_out, so the face chain sees it too).  A ROI at y0 = 0 puts that
// garbage in patch row 0, and the per-patch min/max stretch then squashes the
// face.  On that recording, frames where the best ROI sat at y0 = 0 drew a box
// 5-16% of the time against 43% for y0 > 20.  The y origin clamps to
// [Y_TOP, IMG_VDISP - side], so SIDE_MAX must be <= IMG_VDISP - Y_TOP (the
// caller lowers it to 1072 with Y_TOP = 8).
parameter integer Y_TOP = 0,

// RANK_TOP (10-04) -- the order skin candidates compete for the NROI slots.
// 0 = ccl_blob's order (by area), bit-exact.  1 = by blob TOP edge, highest in
// the picture first (ties keep area order).  Two candidates fill all four
// slots, so with area order a far face (small blob) loses to the bigger skin-
// coloured things in the room -- the wooden cabinet, a chair, the arms -- and
// is never classified at all: on the 12:13 recording 78% of faces under 250 px
// had no ROI.  A face is above its own body and above most furniture.
// Held-out, with RANK_FLOOR 4 + AR_SHIFT 2 + Y_TOP 8 (system_top FACE_ROI2 has
// the numbers): faces < 250 px boxed 0.00 -> 0.58, >= 400 px 0.74 -> 0.85.
// Costs 5 clocks before selection (see [2a]) and eight small multiplies.
parameter integer RANK_TOP = 0,
// RANK_FLOOR: see [2a].  4 = a blob under 1/16 of the biggest blob's box area
// goes to the back of the queue.  0 = no floor.
parameter integer RANK_FLOOR = 4,

// How many sides each accepted candidate is enrolled at: 1 or 2.  The second is
// 1.25 x the first.  Set to 1 to get back the single-ROI-per-face behaviour
// bit-exactly (useful for bisecting a recall change, since it halves the slots
// in play without touching any other arithmetic).
parameter integer NSCALE = 2,

// A skin blob smaller than this is noise, not a face.  ccl_blob's MIN_AREA
// already drops specks by area; this is about the box being too small to hold a
// face at all, so it is in pixels of side.
parameter integer MIN_SIDE = 24,

//---------------------------------------------------------------------------
// THE THREE REJECTS BELOW ARE ALL 09-19 NIGHT (section 3.-14) AND THEY ALL
// EXIST FOR THE SAME BOARD PHOTOGRAPH: a shaken camera pointed at a blank wall
// put a frame-sized red box on screen, with a pooled vote of 4 -- HIGHER than
// either of the two real faces photographed the same evening.  So the votes
// cannot separate these and neither can the cascade: the patch really does
// look like a face to a 20-stage LBP once you shrink half a room into 32x32.
//
// They have to be rejected on GEOMETRY, before the classifier ever sees them,
// and each of the three answers a different thing that was wrong with that box.
//---------------------------------------------------------------------------

// [1] MAX_SIDE -- a candidate whose long edge exceeds this is not a face.
//
// The classifier window covers WIN/BUFN of the ROI and the ROI is 1.5x the
// candidate, so the detectable face is 1.125 x MAX_SIDE wide.  720 therefore
// tops out at an 810px face in a 1080-tall frame, which is as close as a head
// can get and still be a head.  The wall box measured cm ~= 715 BEFORE the
// SIDE_MAX clamp, i.e. it was claiming a face two thirds of the frame across.
//
// ⚠️ DO NOT LOWER THIS TO CHASE THE WALL BOX.  The correctly-detected big face
// in the same photo set measured cm ~= 557, and the gap between 557 and 715 is
// the entire margin available.  The wall box is caught by [2], not by this.
// 10-02 night: system_top passes 1080 when FACE_SKIN_REL=1.  With FRAME_MODE 1
// the ROI comes off the blob's SHORT edge, so a close face whose face+neck blob
// is 720..800 tall (ccl_blob MAX_H still caps it at 800) is a face, and those
// were the remaining no-ROI misses on the first lab recording.
parameter integer MAX_SIDE = 720,

// [2] MB_MAX_SIDE -- the same ceiling for MOTION-sourced candidates, and much
// tighter, because a motion cluster is not a face-shaped thing.
//
// A motion box is whatever moved: a torso, a whole shaken frame, a door.  Its
// size is a statement about the moving REGION and not about any head inside it,
// so the 1.5x-and-classify pipeline that works on a skin blob has no reason to
// work here.  400 keeps the case motion candidates were added for -- a head
// moving through a scene where the skin gate has failed -- and drops the two
// board photographs that produced garbage boxes (cm ~= 715 and ~= 609, both
// motion-sourced, both with MOTION well above zero on the OSD).
//
// Set to MAX_SIDE to disable the distinction, or to 0 to switch motion off as
// a candidate source entirely.  It is NOT a guess which one is better: read
// the FACES candidate count on a green-cast scene first -- if it is 0 with this
// at 400, motion was contributing nothing real there anyway.
parameter integer MB_MAX_SIDE = 400,

// [3] AR_SHIFT -- long edge <= short edge << AR_SHIFT.  1 means 2:1.
//
// A face blob is about 1:1.4.  A shadow band, a strip of wall between two
// highlights, and a motion cluster smeared along the direction of travel are
// all much longer than they are wide, and cm takes the LONG edge -- so without
// this a 900x100 streak enrols as a 1350px square ROI that contains almost none
// of the streak.  Costs one compare at ph4.  0 disables the test.
parameter integer AR_SHIFT = 1,

// [4] MIN_CONTRAST -- a patch flatter than this is not classified at all.
//
// LBP is contrast-INVARIANT by construction, which is exactly what makes it
// good on faces under uneven light and exactly what makes it useless at
// telling a flat noisy patch from a textured one: the codes come out of
// whatever gradient exists, however tiny.  A max-minus-min floor over the 1024
// sampled cells is the cheapest possible guard and it costs two 8-bit compares
// per slot, in the sampling path, accumulated as the patch is written.
//
// 24/255 is deliberately low -- it is a sanity floor for blank wall and lens
// cap, NOT a quality threshold.  The wall photograph had specular highlights
// and would very likely have passed it, which is why it is [1]/[2] that catch
// that one.  0 disables.
parameter integer MIN_CONTRAST = 24,

// Clocks of quiet de that mean the visible frame has ended.  UNITS: CLOCKS, so
// it must be scaled in any bench with a shorter line blanking than the hardware
// -- leaving the hardware's 512 in a bench whose whole horizontal blank is 12
// clocks means frame_end never fires and every test passes having run nothing.
// That exact mistake is recorded twice in HANDOFF section 4.
parameter integer VB_GUARD = 512,

//---------------------------------------------------------------------------
// FRAME_MODE (2026-10-02 evening, for face_cnn) -- how a SKIN candidate is
// turned into its two ROIs.  Motion candidates always use mode 0.
//
//   0  rung 1 = 1.5 x the long edge, centred on the blob; rung 2 = 1.25 x
//      rung 1, concentric.  The 09-19 geometry, sized for a 24-px window.
//   1  rung 1 = 1.5 x the SHORT edge, centred on the TOP SQUARE of the blob
//      (centre y = y0 + short/2); rung 2 = mode 0's rung 1.
//
// Why: a skin blob is usually face + neck, so its long edge is the height of
// both and its centre is on the chin.  Mode 0 then hands the classifier a
// patch in which the face is ~10 px of 32 and sits in the upper half -- what
// the board showed as "candidates but no face" (FACES n>0 / m=0).  The face is
// the top square of such a blob, and the short edge is the face's width, so
// mode 1's rung 1 puts a ~20 px face in the middle of the patch.  Rung 2 keeps
// the old framing as the second hypothesis, for the blobs mode 1 frames wrong
// (half a face lit, a hand merged in beside it); face_detect's score NMS keeps
// whichever rung found the face more confidently.  Both are what
// tools/face_cnn/board_sim.py simulates, and what the CNN is trained on.
// Same phases, same adder depth: rung 1's side and centre are a mux in front
// of the existing org() calls.
//---------------------------------------------------------------------------
parameter integer FRAME_MODE = 0,

//---------------------------------------------------------------------------
// PB_HEAD (2026-10-30) -- head ROIs from the PERSON boxes (pb_*, grid_det).
//   0  off, bit-exact (pb_* ignored).
//   1  slot 0 = side 5/8 w, top at box top + 3/16 w, centred on the box,
//      w = width of the widest valid person box.
//   2  + slot 1 = side 3/4 w at box top + 1/8 w (the second hypothesis).
// Why: on the board the skin chain stops proposing a face past ~1.4 m (face
// < ~250 px), and at any range once the spotlight is on the person (face +
// lit chest join into one blob, ROI 3-4x the face, CNN says no).  The person
// box does not depend on skin colour at all.  Three board recordings (10-28
// 20:35 / 21:54, 10-30 18:48), CNN in the board's colour domain, per frame:
// faces 180-250 px boxed 0.00-0.23 on the board -> 0.50-0.74 from these two
// slots, 250-400 px 0.24-0.35 -> 0.61-0.87, 0 / 1451 face-less person boxes
// fired.  Geometry measured there: the face centre sits 0.46..0.54 w below
// the box top, its side is 0.43..0.82 w.  Both slots are rung 2 for the dup
// rule (sr2 = 1), so the skin chain's own ROI on the same face is still
// taken; skin candidates fill the slots that are left.
// PB_MIN_W: narrower person boxes give no head slot (face < ~28 px).
//---------------------------------------------------------------------------
parameter integer PB_HEAD  = 0,
parameter integer PB_MIN_W = 64
)(
input  wire        clk,
input  wire        rst_n,

//--- pixel side -----------------------------------------------------------
input  wire        in_vs,          // HIGH across the visible frame
input  wire        in_de,
input  wire [7:0]  in_r,
input  wire [7:0]  in_g,
input  wire [7:0]  in_b,

//--- candidate boxes, latched at the start of each visible frame -----------
// Skin chain, from the second ccl_blob.  Already sorted by area.
input  wire [NSKIN*12-1:0] skin_x0,
input  wire [NSKIN*12-1:0] skin_x1,
input  wire [NSKIN*12-1:0] skin_y0,
input  wire [NSKIN*12-1:0] skin_y1,
input  wire [NSKIN-1:0]    skin_valid,

// Motion chain, block indices (0..N_COLS-1) rather than pixels.
input  wire [NROI*4-1:0]   mb_x0,
input  wire [NROI*4-1:0]   mb_x1,
input  wire [NROI*4-1:0]   mb_y0,
input  wire [NROI*4-1:0]   mb_y1,
input  wire [NROI-1:0]     mb_valid,

// Person boxes (PB_HEAD), pixels, x1/y1 EXCLUSIVE (grid_post's convention).
// Snapshotted on one clock at selection start.  Tie to 0 when PB_HEAD = 0.
input  wire [NROI*12-1:0]  pb_x0,
input  wire [NROI*12-1:0]  pb_y0,
input  wire [NROI*12-1:0]  pb_x1,
input  wire [NROI-1:0]     pb_valid,

//--- classifier side ------------------------------------------------------
input  wire [11:0] rd_addr,        // {roi[1:0], row[4:0], col[4:0]}
output wire [7:0]  rd_data,        // one clock after rd_addr
input  wire        rd_busy,        // classifier is mid-scan: hold the swap

// Published geometry of the bank the classifier is reading, and a pulse when a
// new bank becomes available.
output reg  [NROI*12-1:0] roi_x0,
output reg  [NROI*12-1:0] roi_y0,
output reg  [NROI*12-1:0] roi_side, // ROI side in pixels; the patch spans it
output reg  [NROI-1:0]    roi_valid,
output reg         roi_ready,      // one clock, a fresh bank is readable

//--- instrumentation ------------------------------------------------------
output reg  [3:0]  dbg_nroi,       // ROIs selected this frame
output reg         dbg_swap_held,  // a swap was skipped because rd_busy

// 09-19 night, section 3.-14.  Without these two the new gates are invisible
// from the board: "no red box" reads identically whether the skin chain found
// nothing or found something the gates threw away.  They answer the question
// the next board session will certainly ask -- is the gate doing its job, or
// is it eating every face.
output reg  [3:0]  dbg_nrej,       // candidates rejected on geometry, saturating
output reg         dbg_flat        // >=1 slot withheld on contrast this frame
);

localparam integer AW = 11;         // {bank, row[4:0], col[4:0]}

//---------------------------------------------------------------------------
// [1] Luma, and coordinates.
//
// Y = (77R + 150G + 29B)/256, the BT.601 full-range row.  Computed here rather
// than taken from face_skin so that this module has no latency relationship to
// that one -- the two taps are independent and stay that way.
//
// The coordinate generator runs one clock AHEAD of the luma register, which is
// the idiom det_bin3x3 section [5] settles: it is what makes px read 0 on the
// first active pixel instead of 1.  Getting it backwards dropped column 0 of
// every row there.
//---------------------------------------------------------------------------
reg [15:0] y_acc;
reg [7:0]  y_r;

always @(posedge clk) begin
    y_acc <= 16'd77 * in_r + 16'd150 * in_g + 16'd29 * in_b;
    y_r   <= y_acc[15:8];
end

// y_r lags in_de by TWO registers, so everything that has to line up with a
// pixel's luma -- the sample gate, px/py, and the frame-edge detector -- keys
// off de_dly[1], the two-deep copy.  A one-deep copy would shift every patch a
// pixel and a column, which is invisible on its own and wrecks the framing the
// classifier depends on.
reg [1:0]  de_dly, vs_dly;
reg [11:0] px, py;
reg        pde_prev;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        de_dly <= 2'b0; vs_dly <= 2'b0;
        px <= 12'd0; py <= 12'd0; pde_prev <= 1'b0;
    end else begin
        de_dly   <= {de_dly[0], in_de};
        vs_dly   <= {vs_dly[0], in_vs};
        pde_prev <= de_dly[1];
        if (!vs_dly[1]) begin
            px <= 12'd0;
            py <= 12'd0;
        end else if (de_dly[1]) begin
            px <= px + 12'd1;
        end else begin
            px <= 12'd0;
            if (pde_prev) py <= py + 12'd1;
        end
    end
end

// Frame edges, derived from de the way ccl_blob and det_overlay do since
// section 3.-8 -- NOT from vs, which is a 5-line pulse.  A frame has ended when
// de has been quiet for longer than any line blanking.
reg [11:0] quiet;
reg        frame_open;
reg        frame_end;              // one clock at the end of the visible frame

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        quiet <= 12'd0; frame_open <= 1'b0; frame_end <= 1'b0;
    end else begin
        frame_end <= 1'b0;
        if (de_dly[1]) begin
            quiet <= 12'd0;
            frame_open <= 1'b1;
        end else if (quiet < VB_GUARD) begin
            quiet <= quiet + 12'd1;
        end else if (frame_open) begin
            frame_open <= 1'b0;
            frame_end  <= 1'b1;
        end
    end
end

//---------------------------------------------------------------------------
// [2] ROI selection, one candidate every NPH clocks, in the blanking that
// follows a frame.
//
// Sequential rather than combinational on purpose: picking four of twelve boxes,
// computing two sides and two clamped origins for each and testing each against
// the ones already chosen is a deep pile of comparators, and there is a whole
// frame to do it in.  The first sample point of the smallest possible ROI is at
// least 32 pixels in, so selection is finished before it could matter.
//
// ONE CANDIDATE PER CLOCK WAS NOT SEQUENTIAL ENOUGH -- 09-19, from the board.
// That version stepped `cand` once per clock but still evaluated the ENTIRE
// chain inside that one clock: box mux, cw/ch, cm, 1.5x, clamp, 1.25x, clamp,
// centre, org()'s subtract and double clamp, and the final +side-1.  TD put it
// at 13.287ns of data path against a 6.666ns budget -- SWNS -6.832ns, 23 logic
// levels with 10 chained ADDERs, Fmax 74MHz on a 150MHz clock -- and the ten
// worst paths in the whole design were all this one chain, motion_frame_drawer
// /pby0 to sx1/sy1 here.
//
// That is not a margin problem, it is a WRONG ANSWER problem, and it is worth
// being precise about why: sx0/sy0/sd were clocked while the carry chains were
// still propagating, so the geometry the sampler and then the classifier used
// was a half-computed value whose error depended on the candidate's magnitude.
// On the board that reads as a detector that works occasionally -- a small
// candidate settles in time, a large one does not -- with boxes drawn at the
// wrong place and a candidate count that flickers 0/1/2 frame to frame.  All
// three of those were reported from the board and all three look like
// classifier or threshold faults.  None of them is one.  The classifier is
// bit-exact (fctb) and was never involved.
//
// SO THE CHAIN IS CUT INTO NPH PHASES, at most two 12-bit adds deep each.  The
// phases do NOT overlap between candidates: the dup test reads slots that
// earlier candidates wrote, so candidate n+1 must not enter the pipe until n
// has retired.  That costs (NSKIN+NROI)*NPH = 72 clocks instead of 12, against
// the ~98,000 clocks of vertical blanking that follow frame_end.  Neither
// number is close to tight, so the cheap non-overlapping form is the right one
// and an overlapped pipe would only buy back clocks nothing is short of.
//
// The ARITHMETIC IS UNCHANGED: same two sides, same clamps, same dup rule, same
// candidate-major slot order.  Only the clock boundaries moved.  A bench that
// passed before this change passes after it, given NPH clocks per candidate to
// settle -- which is why frtb drives selection by frame_end and not by a fixed
// clock count.
//---------------------------------------------------------------------------
reg [11:0] sx0 [0:NROI-1];         // chosen ROI origin, pixels
reg [11:0] sy0 [0:NROI-1];
reg [11:0] sx1 [0:NROI-1];         // and its far edge, kept rather than re-derived:
reg [11:0] sy1 [0:NROI-1];         // the dup test below would otherwise need four
                                   // variable shifts in one combinational block
reg [11:0] sd  [0:NROI-1];         // ROI side, pixels
reg [NROI-1:0] sv;
reg [NROI-1:0] sr2;                // this slot is a candidate's second rung
reg [2:0]  nsel;                   // how many slots are filled
reg [3:0]  ncand;                  // how many CANDIDATES got at least one slot

reg [3:0]  cand;                   // 0..NSKIN-1 skin, then NSKIN.. motion
reg        selecting;

// Phase within the current candidate.  A localparam and not a parameter: the
// phase assignments below are hand-balanced against a 6.666ns budget, so a
// caller raising the count would not move any work and lowering it would put
// two adder chains back in one clock.
localparam integer NPH     = 6;
localparam [2:0]   PH_LAST = 3'd5;
reg [2:0]  ph;

// Pipeline registers.  ONE set, not one per candidate -- candidates are
// processed strictly one at a time, see the header.  The comment on each is the
// phase that WRITES it; the expressions below say which phase reads it.
reg [11:0] p_cx0, p_cy0;           // ph0: the box, out of the mux
reg [11:0] p_cw,  p_ch;            // ph0
reg        p_cvalid;               // ph0
reg        p_is_mb;                // ph0: candidate came from the motion grid
reg [11:0] p_cm;                   // ph1: the longer of the two
reg [11:0] p_cn;                   // ph1: and the shorter, for the aspect test
reg [12:0] p_ccx, p_ccy;           // ph1: the centre
reg [11:0] p_s1;                   // ph2: 1.5 * cm, clamped
reg [11:0] p_sa;                   // ph2: 1.5 * cn, clamped (FRAME_MODE 1)
reg [12:0] p_ccya;                 // ph2: y0 + cn/2, the top square's centre
reg [11:0] p_r1s;                  // ph3: rung 1's side, whichever rule chose it
reg [11:0] p_s2;                   // ph3: rung 2's side
reg [11:0] p_r1x0, p_r1y0;         // ph3: rung-1 origin
reg [11:0] p_r2x0, p_r2y0;         // ph4: rung-2 origin
reg        p_take;                 // ph4: this candidate has earned a slot
reg        p_rej;                  // ph4: ...and would have, but for a gate
reg [3:0]  nrej;                   // ph5: how many of those there were

// The candidate under consideration, as a pixel box.
reg [11:0] cx0, cx1, cy0, cy1;
reg        cvalid;

// Width and height, off the mux, at ph0.  The max that used to sit on the same
// clock is now at ph1 and reads the registered pair.
wire [11:0] cw = cx1 - cx0 + 12'd1;
wire [11:0] ch = cy1 - cy0 + 12'd1;
wire [11:0] cm = (p_cw > p_ch) ? p_cw : p_ch;
wire [11:0] cn = (p_cw > p_ch) ? p_ch : p_cw;

//---------------------------------------------------------------------------
// The four geometry rejects, all evaluated at ph4 off ph1's registers.  Each
// is one compare; none feeds another; none of them is on the same clock as an
// adder chain.  See the parameter block for what each is for.
//
// They are written as `(PARAM == 0) || test` so that a zeroed parameter folds
// the whole comparator away at elaboration rather than leaving a compare
// against 0 that can never fail.
//---------------------------------------------------------------------------
wire cm_ceiling_ok = p_is_mb ? ((MB_MAX_SIDE != 0) && (p_cm <= MB_MAX_SIDE))
                             : ((MAX_SIDE    == 0) || (p_cm <= MAX_SIDE));

// Widened before the shift, not after: {4'b0,p_cn} keeps 1920 << 2 from
// wrapping in twelve bits and reading as a PASS on a streak that should fail.
wire [15:0] ar_lim = {4'b0, p_cn} << AR_SHIFT;
wire ar_ok = (AR_SHIFT == 0) || ({4'b0, p_cm} <= ar_lim);

// The two sides for this candidate.  s1 = 1.5*cm at ph2, s2 = 1.25*s1 at ph3.
// Splitting them is the point: s1's clamp fed s2's adder, which fed s2's clamp,
// and all four were one clock deep.  No rounding to a power of two: see header.
wire [12:0] s1_raw = {1'b0, p_cm} + {2'b0, p_cm[11:1]};
wire [11:0] s1 = (s1_raw < SIDE_MIN) ? SIDE_MIN[11:0] :
                 (s1_raw > SIDE_MAX) ? SIDE_MAX[11:0] : s1_raw[11:0];

// At the top of the range the two rungs collapse onto each other.  That is
// harmless -- it scans the same ROI twice -- and it is preferable to letting the
// second rung run off the bottom of the frame, which would sample rows that do
// not exist and leave whatever the previous frame wrote in those patch rows.
wire [13:0] s2_raw = {2'b0, p_s1} + {4'b0, p_s1[11:2]};

// FRAME_MODE 1, at ph2 beside s1: the same 1.5x and clamp on the SHORT edge,
// and the top square's centre.  When the blob is wider than tall cn is its
// height and y0 + cn/2 is simply its centre, so a wide blob is not shifted.
wire [12:0] sa_raw = {1'b0, p_cn} + {2'b0, p_cn[11:1]};
wire [11:0] sa = (sa_raw < SIDE_MIN) ? SIDE_MIN[11:0] :
                 (sa_raw > SIDE_MAX) ? SIDE_MAX[11:0] : sa_raw[11:0];
wire [12:0] ccya = {1'b0, p_cy0} + {2'b0, p_cn[11:1]};
wire        fm1  = (FRAME_MODE != 0) && !p_is_mb;
wire [11:0] r1s  = fm1 ? p_sa : p_s1;
wire [11:0] s2 = (s2_raw > SIDE_MAX) ? SIDE_MAX[11:0] : s2_raw[11:0];

// Centre the ROI on the candidate, then clamp it inside the frame.  A face at
// the edge of the picture is the normal case, not an exception, so clamping
// rather than rejecting matters: it keeps the face in the patch even though it
// stops being centred.
// At ph1, alongside cm -- both read the same ph0 registers, so they are two
// parallel adds and not a chain.
wire [12:0] ccx = {1'b0, p_cx0} + {2'b0, p_cw[11:1]};
wire [12:0] ccy = {1'b0, p_cy0} + {2'b0, p_ch[11:1]};

// Centre a ROI of side sd_i on c, then slide it inside [0, lim).  One function
// instead of four copies because there are now two sides per candidate.
// lo is the lowest legal origin (0, or Y_TOP on the y axis); lo and lim are
// constants at every call, so the extra compare folds to a constant one.
function [11:0] org;
    input [12:0] c;
    input [11:0] sd_i;
    input [12:0] lim;
    input [12:0] lo;
    reg signed [14:0] raw;
    reg [12:0] hi;
    begin
        raw = $signed({2'b0, c}) - $signed({4'b0, sd_i[11:1]});
        hi  = ({1'b0, sd_i} >= lim - lo) ? lo : (lim - {1'b0, sd_i});
        org = (raw < $signed({2'b0, lo})) ? lo[11:0] :
              (raw > $signed({2'b0, hi})) ? hi[11:0] : raw[11:0];
    end
endfunction

// Rung 1 at ph3 (needs p_s1, written at ph2), rung 2 at ph4 (needs p_s2,
// written at ph3).  Each phase therefore holds two org() calls, which are
// independent of each other -- one subtract and one clamp deep, not four.
wire [11:0] r1x0 = org(p_ccx, r1s, IMG_HDISP[12:0], 13'd0);
wire [11:0] r1y0 = org(fm1 ? p_ccya : p_ccy, r1s, IMG_VDISP[12:0], Y_TOP[12:0]);
wire [11:0] r2x0 = org(p_ccx, p_s2, IMG_HDISP[12:0], 13'd0);
wire [11:0] r2y0 = org(p_ccy, p_s2, IMG_VDISP[12:0], Y_TOP[12:0]);

// Is this candidate's centre already inside a chosen ROI?  This is what stops
// the same person filling every slot from both sources at once.
//
// Rung-2 slots are SKIPPED here.  A rung-2 box is the same candidate at 1.25x,
// so counting it would let the second scale of one face shadow a genuinely
// different face nearby -- the dup rule is about candidates, and rung 2 is not
// one.  Four flip-flops to keep that distinction instead of letting the bigger
// box quietly tighten the spacing two people have to keep.
//
// Evaluated at ph4 on the REGISTERED centre.  Sixteen comparators and an OR
// tree, no adder -- it shares ph4 with rung 2's two org() calls and neither
// feeds the other.
reg dup;
integer d;
always @(*) begin
    dup = 1'b0;
    for (d = 0; d < NROI; d = d + 1)
        if (sv[d] && !sr2[d]
            && (p_ccx[11:0] >= sx0[d]) && (p_ccx[11:0] <= sx1[d])
            && (p_ccy[11:0] >= sy0[d]) && (p_ccy[11:0] <= sy1[d]))
            dup = 1'b1;
end

//---------------------------------------------------------------------------
// [2a] RANK_TOP: reorder the skin candidates before selection.
//   key = {small, top edge}: highest in the picture first, EXCEPT that a blob
//   whose box area is under 1/2^RANK_FLOOR of some other blob's goes behind
//   every bigger one.  Top-edge order alone hands two of the four slots to a
//   ceiling-light speck on a close-face shot (rec_1950_b: big faces 0.89 ->
//   0.52); the floor gives them back (0.89) and keeps the far-face gain.
//   fe_d[0]  snapshot skin_* (ONE published set even if ccl_blob publishes
//            mid-selection), w and h
//   fe_d[1]  area = w * h (eight small DSP multiplies, registered)
//   fe_d[2]  small[i] = some valid j has area[j] > area[i] << RANK_FLOOR
//            (56 parallel compares + OR); key = {small, y0}, invalid = all 1s
//   fe_d[3]  rank[i] = how many candidates sort before i (56 compares + a
//            7-input popcount; ties by index, so area order)
//   fe_d[4]  k_*[p] = the candidate whose rank is p (one-hot 8:1 per output)
//   sel_start = fe_d[4]: selection begins the clock after k_* lands.
// RANK_TOP = 0: k_* ARE skin_* and sel_start IS frame_end -- bit-exact.
// RANK_FLOOR = 0: no floor, pure top-edge order.
// The rank logic hard-codes NSKIN = 8 (3-bit ranks).
//---------------------------------------------------------------------------
wire [NSKIN*12-1:0] k_x0, k_x1, k_y0, k_y1;
wire [NSKIN-1:0]    k_valid;
wire                sel_start;

generate if (RANK_TOP != 0) begin : g_rank
    reg [4:0] fe_d;
    reg [NSKIN*12-1:0] q_x0, q_x1, q_y0, q_y1;
    reg [NSKIN-1:0]    q_v;
    reg [11:0]         bw   [0:NSKIN-1];
    reg [11:0]         bh   [0:NSKIN-1];
    reg [23:0]         area [0:NSKIN-1];
    reg [12:0]         key  [0:NSKIN-1];
    reg [2:0]          rnk  [0:NSKIN-1];
    reg [NSKIN*12-1:0] o_x0, o_x1, o_y0, o_y1;
    reg [NSKIN-1:0]    o_v;
    integer i, j;
    reg [3:0] cnt;
    reg       sm;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            fe_d <= 5'd0;
            q_x0 <= {NSKIN*12{1'b0}}; q_x1 <= {NSKIN*12{1'b0}};
            q_y0 <= {NSKIN*12{1'b0}}; q_y1 <= {NSKIN*12{1'b0}};
            q_v  <= {NSKIN{1'b0}};
            o_x0 <= {NSKIN*12{1'b0}}; o_x1 <= {NSKIN*12{1'b0}};
            o_y0 <= {NSKIN*12{1'b0}}; o_y1 <= {NSKIN*12{1'b0}};
            o_v  <= {NSKIN{1'b0}};
            for (i = 0; i < NSKIN; i = i + 1) begin
                bw[i] <= 12'd0; bh[i] <= 12'd0; area[i] <= 24'd0;
                key[i] <= 13'h1FFF; rnk[i] <= 3'd0;
            end
        end else begin
            fe_d <= {fe_d[3:0], frame_end};
            if (frame_end) begin
                q_x0 <= skin_x0; q_x1 <= skin_x1;
                q_y0 <= skin_y0; q_y1 <= skin_y1;
                q_v  <= skin_valid;
                for (i = 0; i < NSKIN; i = i + 1) begin
                    bw[i] <= skin_x1[i*12 +: 12] - skin_x0[i*12 +: 12] + 12'd1;
                    bh[i] <= skin_y1[i*12 +: 12] - skin_y0[i*12 +: 12] + 12'd1;
                end
            end
            if (fe_d[0])
                for (i = 0; i < NSKIN; i = i + 1)
                    area[i] <= bw[i] * bh[i];
            if (fe_d[1]) begin
                for (i = 0; i < NSKIN; i = i + 1) begin
                    sm = 1'b0;
                    for (j = 0; j < NSKIN; j = j + 1)
                        if ((RANK_FLOOR != 0) && (j != i) && q_v[j]
                            && ({4'd0, area[j]} > ({4'd0, area[i]} << RANK_FLOOR)))
                            sm = 1'b1;
                    key[i] <= q_v[i] ? {sm, q_y0[i*12 +: 12]} : 13'h1FFF;
                end
            end
            if (fe_d[2]) begin
                for (i = 0; i < NSKIN; i = i + 1) begin
                    cnt = 4'd0;
                    for (j = 0; j < NSKIN; j = j + 1)
                        if ((j != i) && ((key[j] < key[i]) || ((key[j] == key[i]) && (j < i))))
                            cnt = cnt + 4'd1;
                    rnk[i] <= cnt[2:0];
                end
            end
            if (fe_d[3]) begin
                for (i = 0; i < NSKIN; i = i + 1)
                    for (j = 0; j < NSKIN; j = j + 1)
                        if (rnk[j] == i) begin
                            o_x0[i*12 +: 12] <= q_x0[j*12 +: 12];
                            o_x1[i*12 +: 12] <= q_x1[j*12 +: 12];
                            o_y0[i*12 +: 12] <= q_y0[j*12 +: 12];
                            o_y1[i*12 +: 12] <= q_y1[j*12 +: 12];
                            o_v[i]           <= q_v[j];
                        end
            end
        end
    end
    assign k_x0 = o_x0;  assign k_x1 = o_x1;
    assign k_y0 = o_y0;  assign k_y1 = o_y1;
    assign k_valid = o_v;
    assign sel_start = fe_d[4];
end else begin : g_norank
    assign k_x0 = skin_x0;  assign k_x1 = skin_x1;
    assign k_y0 = skin_y0;  assign k_y1 = skin_y1;
    assign k_valid = skin_valid;
    assign sel_start = frame_end;
end endgenerate

//---------------------------------------------------------------------------
// [2b] PB_HEAD: the head slots, computed from ONE snapshot of pb_* taken at
// sel_start (all fields on the same clock -- a box half from one grid_post
// publish and half from the next would frame nothing).  Registered pipeline,
// at most two 12-bit adds per clock; each step runs on the clock its hd bit
// is high:
//   sel_start  snapshot pb_*        hd[0] keys {valid, width}
//   hd[1]      widest of 0/1, 2/3   hd[2] widest, its x0 / y0 / width
//   hd[3]      raw sides, tops, centre, MIN_W gate
//   hd[4]      side clamps          hd[5] origins -> h*_*
//   hd[6]      = sel_go: the FSM below starts with the head slots filled.
// Ties go to the lower box index.  Hard-codes NROI = 4 person boxes (as the
// rank logic hard-codes NSKIN = 8).  PB_HEAD = 0: sel_go IS sel_start and
// h_ok is 0, so nothing is pre-filled -- bit-exact.
//---------------------------------------------------------------------------
wire        sel_go;
wire [11:0] h1x0, h1y0, h1sd, h2x0, h2y0, h2sd;
wire        h_ok;

// Top-anchored version of org(): the ROI starts at t (not centred on it) and
// slides inside [lo, lim).
function [11:0] topc;
    input [12:0] t;
    input [11:0] sd_i;
    input [12:0] lim;
    input [12:0] lo;
    reg [12:0] hi;
    begin
        hi   = ({1'b0, sd_i} >= lim - lo) ? lo : (lim - {1'b0, sd_i});
        topc = (t < lo) ? lo[11:0] : (t > hi) ? hi[11:0] : t[11:0];
    end
endfunction

generate if (PB_HEAD != 0) begin : g_head
    reg [6:0]  hd;
    reg [NROI*12-1:0] b_x0, b_y0, b_x1;
    reg [NROI-1:0]    b_v;
    reg [12:0] key [0:3];                      // {valid, width}
    reg [12:0] ka, kb;
    reg [11:0] xa, ya, xb, yb;
    reg        hv;
    reg [11:0] hw, hx, hy;
    reg [12:0] s1r, s2r, t1, t2, cx;
    reg        okw;
    reg [11:0] s1, s2;
    reg [12:0] t1q, t2q, cxq;
    reg        okq;
    reg [11:0] o1x, o1y, o1s, o2x, o2y, o2s;
    reg        o_ok;
    integer i;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            hd <= 7'd0;
            b_x0 <= {NROI*12{1'b0}}; b_y0 <= {NROI*12{1'b0}}; b_x1 <= {NROI*12{1'b0}};
            b_v  <= {NROI{1'b0}};
            for (i = 0; i < 4; i = i + 1) key[i] <= 13'd0;
            ka <= 13'd0; kb <= 13'd0; xa <= 12'd0; ya <= 12'd0; xb <= 12'd0; yb <= 12'd0;
            hv <= 1'b0; hw <= 12'd0; hx <= 12'd0; hy <= 12'd0;
            s1r <= 13'd0; s2r <= 13'd0; t1 <= 13'd0; t2 <= 13'd0; cx <= 13'd0; okw <= 1'b0;
            s1 <= SIDE_MIN[11:0]; s2 <= SIDE_MIN[11:0]; t1q <= 13'd0; t2q <= 13'd0; cxq <= 13'd0; okq <= 1'b0;
            o1x <= 12'd0; o1y <= 12'd0; o1s <= SIDE_MIN[11:0];
            o2x <= 12'd0; o2y <= 12'd0; o2s <= SIDE_MIN[11:0]; o_ok <= 1'b0;
        end else begin
            hd <= {hd[5:0], sel_start};
            if (sel_start) begin
                b_x0 <= pb_x0; b_y0 <= pb_y0; b_x1 <= pb_x1; b_v <= pb_valid;
            end
            if (hd[0])
                for (i = 0; i < 4; i = i + 1)
                    key[i] <= {b_v[i], b_x1[i*12 +: 12] - b_x0[i*12 +: 12]};
            if (hd[1]) begin
                if (key[0] >= key[1]) begin ka <= key[0]; xa <= b_x0[0 +: 12];  ya <= b_y0[0 +: 12];  end
                else                  begin ka <= key[1]; xa <= b_x0[12 +: 12]; ya <= b_y0[12 +: 12]; end
                if (key[2] >= key[3]) begin kb <= key[2]; xb <= b_x0[24 +: 12]; yb <= b_y0[24 +: 12]; end
                else                  begin kb <= key[3]; xb <= b_x0[36 +: 12]; yb <= b_y0[36 +: 12]; end
            end
            if (hd[2]) begin
                if (ka >= kb) begin hv <= ka[12]; hw <= ka[11:0]; hx <= xa; hy <= ya; end
                else          begin hv <= kb[12]; hw <= kb[11:0]; hx <= xb; hy <= yb; end
            end
            if (hd[3]) begin
                s1r <= {2'b0, hw[11:1]} + {4'b0, hw[11:3]};                         // 5/8 w
                s2r <= {2'b0, hw[11:1]} + {3'b0, hw[11:2]};                         // 3/4 w
                t1  <= {1'b0, hy} + {4'b0, hw[11:3]} + {5'b0, hw[11:4]};            // + 3/16 w
                t2  <= {1'b0, hy} + {4'b0, hw[11:3]};                               // + 1/8 w
                cx  <= {1'b0, hx} + {2'b0, hw[11:1]};
                okw <= hv && (hw >= PB_MIN_W);
            end
            if (hd[4]) begin
                s1  <= (s1r < SIDE_MIN) ? SIDE_MIN[11:0] : (s1r > SIDE_MAX) ? SIDE_MAX[11:0] : s1r[11:0];
                s2  <= (s2r < SIDE_MIN) ? SIDE_MIN[11:0] : (s2r > SIDE_MAX) ? SIDE_MAX[11:0] : s2r[11:0];
                t1q <= t1; t2q <= t2; cxq <= cx; okq <= okw;
            end
            if (hd[5]) begin
                o1x <= org(cxq, s1, IMG_HDISP[12:0], 13'd0);
                o1y <= topc(t1q, s1, IMG_VDISP[12:0], Y_TOP[12:0]);
                o1s <= s1;
                o2x <= org(cxq, s2, IMG_HDISP[12:0], 13'd0);
                o2y <= topc(t2q, s2, IMG_VDISP[12:0], Y_TOP[12:0]);
                o2s <= s2;
                o_ok <= okq;
            end
        end
    end
    assign sel_go = hd[6];
    assign h1x0 = o1x; assign h1y0 = o1y; assign h1sd = o1s;
    assign h2x0 = o2x; assign h2y0 = o2y; assign h2sd = o2s;
    assign h_ok = o_ok;
end else begin : g_nohead
    assign sel_go = sel_start;
    assign h1x0 = 12'd0; assign h1y0 = 12'd0; assign h1sd = SIDE_MIN[11:0];
    assign h2x0 = 12'd0; assign h2y0 = 12'd0; assign h2sd = SIDE_MIN[11:0];
    assign h_ok = 1'b0;
end endgenerate

// How many slots the head pre-fills this selection, and which.
localparam integer NHEAD = (PB_HEAD > 1 && NROI > 1) ? 2 : (PB_HEAD != 0) ? 1 : 0;
wire [NROI-1:0] h_mask = !h_ok ? {NROI{1'b0}} :
                         (NHEAD == 2) ? {{(NROI-2){1'b0}}, 2'b11} :
                         (NHEAD == 1) ? {{(NROI-1){1'b0}}, 1'b1} : {NROI{1'b0}};
wire [2:0]      h_nsel = !h_ok ? 3'd0 : NHEAD[2:0];

// Candidate multiplexer.  Skin boxes 0..NSKIN-1 come from the packed ccl_blob
// buses (through [2a]); motion boxes NSKIN.. are block indices and are widened
// to pixels.
integer c;
always @(*) begin
    cx0 = 12'd0; cx1 = 12'd0; cy0 = 12'd0; cy1 = 12'd0; cvalid = 1'b0;
    for (c = 0; c < NSKIN; c = c + 1)
        if (cand == c) begin
            cx0    = k_x0[c*12 +: 12];
            cx1    = k_x1[c*12 +: 12];
            cy0    = k_y0[c*12 +: 12];
            cy1    = k_y1[c*12 +: 12];
            cvalid = k_valid[c];
        end
    for (c = 0; c < NROI; c = c + 1)
        if (cand == NSKIN + c) begin
            cx0    = mb_x0[c*4 +: 4] * BLK_W;
            cx1    = mb_x1[c*4 +: 4] * BLK_W + (BLK_W - 1);
            cy0    = mb_y0[c*4 +: 4] * BLK_H;
            cy1    = mb_y1[c*4 +: 4] * BLK_H + (BLK_H - 1);
            cvalid = mb_valid[c];
        end
end

integer s;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        for (s = 0; s < NROI; s = s + 1) begin
            sx0[s] <= 12'd0; sy0[s] <= 12'd0;
            sx1[s] <= 12'd0; sy1[s] <= 12'd0;
            sd[s]  <= SIDE_MIN[11:0];
        end
        sv        <= {NROI{1'b0}};
        sr2       <= {NROI{1'b0}};
        nsel      <= 3'd0;
        ncand     <= 4'd0;
        cand      <= 4'd0;
        selecting <= 1'b0;
        ph        <= 3'd0;
        p_cvalid  <= 1'b0;
        p_is_mb   <= 1'b0;
        p_cm      <= 12'd0;
        p_cn      <= 12'd0;
        p_take    <= 1'b0;
        p_rej     <= 1'b0;
        nrej      <= 4'd0;
    end else if (sel_go) begin
        // Selection runs in the blanking that FOLLOWS a frame, so the list is
        // settled before the next frame's first pixel arrives.  Doing it at the
        // start of the visible frame instead loses the first few samples of row
        // 0 for any ROI at the top-left corner -- 72 clocks of selection against
        // a sample spacing that is one pixel when side is 32.
        //
        // frame_end also re-arms the phase counter, so a selection somehow still
        // running when the next frame ends is abandoned rather than resumed
        // mid-candidate.  It cannot happen at 72 against ~98,000, but a resumed
        // pipe would write a slot from two different candidates' halves and that
        // is not a failure worth leaving reachable.
        //
        // PB_HEAD: the head slots ([2b]) go in first, marked rung 2 so the dup
        // test below does not let them shadow the skin ROI of the same face.
        sv        <= h_mask;
        sr2       <= h_mask;
        nsel      <= h_nsel;
        ncand     <= {3'd0, h_ok};
        if (h_mask[0]) begin
            sx0[0] <= h1x0;                 sy0[0] <= h1y0;
            sx1[0] <= h1x0 + h1sd - 12'd1;  sy1[0] <= h1y0 + h1sd - 12'd1;
            sd [0] <= h1sd;
        end
        if ((NROI > 1) && h_mask[NROI > 1 ? 1 : 0] && (NHEAD == 2)) begin
            sx0[1] <= h2x0;                 sy0[1] <= h2y0;
            sx1[1] <= h2x0 + h2sd - 12'd1;  sy1[1] <= h2y0 + h2sd - 12'd1;
            sd [1] <= h2sd;
        end
        cand      <= 4'd0;
        selecting <= 1'b1;
        ph        <= 3'd0;
        p_cvalid  <= 1'b0;
        p_take    <= 1'b0;
        p_rej     <= 1'b0;
        nrej      <= 4'd0;
    end else if (selecting) begin
        case (ph)
        //-------------------------------------------------------------------
        // ph0.  Latch the box out of the twelve-way mux, and take the two
        // subtracts with it -- the mux is a LUT tree, so one add rides free.
        //-------------------------------------------------------------------
        3'd0: begin
            p_cx0    <= cx0;
            p_cy0    <= cy0;
            p_cw     <= cw;
            p_ch     <= ch;
            p_cvalid <= cvalid;
            // Which source the box came from, carried alongside it because the
            // ceiling is different for the two and `cand` will have moved on by
            // the time ph4 decides.
            p_is_mb  <= (cand >= NSKIN);
            ph       <= 3'd1;
        end

        //-------------------------------------------------------------------
        // ph1.  The max and the two centre adds, all three reading ph0.
        //-------------------------------------------------------------------
        3'd1: begin
            p_cm  <= cm;
            p_cn  <= cn;
            p_ccx <= ccx;
            p_ccy <= ccy;
            ph    <= 3'd2;
        end

        //-------------------------------------------------------------------
        // ph2.  s1 alone: one add and a two-sided clamp.  This is the phase
        // that used to feed s2's add in the same clock.
        //-------------------------------------------------------------------
        3'd2: begin
            p_s1   <= s1;
            p_sa   <= sa;
            p_ccya <= ccya;
            ph   <= 3'd3;
        end

        //-------------------------------------------------------------------
        // ph3.  s2, and rung 1's origin.  Both read p_s1; neither reads the
        // other.
        //-------------------------------------------------------------------
        3'd3: begin
            p_s2   <= fm1 ? p_s1 : s2;
            p_r1s  <= r1s;
            p_r1x0 <= r1x0;
            p_r1y0 <= r1y0;
            ph     <= 3'd4;
        end

        //-------------------------------------------------------------------
        // ph4.  Rung 2's origin, and the accept decision.
        //
        // p_take is registered here rather than re-evaluated at ph5 so that the
        // dup comparators and the slot writes are never in the same clock.  It
        // reads nsel, which ph5 of the PREVIOUS candidate has already updated --
        // that ordering is why the phases must not overlap.
        //-------------------------------------------------------------------
        3'd4: begin
            p_r2x0 <= r2x0;
            p_r2y0 <= r2y0;
            p_take <= p_cvalid && !dup && (nsel < NROI)
                      && (p_cm >= MIN_SIDE) && cm_ceiling_ok && ar_ok;

            // The same expression with the two new gates inverted: a candidate
            // that cleared everything the 09-19 rejects did not exist for, and
            // was then stopped by one of them.  Deliberately NOT counting the
            // dup, slot-full and MIN_SIDE cases -- those are old behaviour and
            // lumping them in would make the readout say "the new gates are
            // eating candidates" on a frame where they did nothing.
            p_rej  <= p_cvalid && !dup && (nsel < NROI)
                      && (p_cm >= MIN_SIDE) && !(cm_ceiling_ok && ar_ok);
            ph     <= 3'd5;
        end

        //-------------------------------------------------------------------
        // ph5.  Commit, and step to the next candidate.  Only adds left.
        //-------------------------------------------------------------------
        default: begin
            if (p_take) begin
                // Rung 1.  sx1/sy1 are stored rather than re-derived because the
                // dup test reads them combinationally.
                sx0[nsel] <= p_r1x0;
                sy0[nsel] <= p_r1y0;
                sx1[nsel] <= p_r1x0 + p_r1s - 12'd1;
                sy1[nsel] <= p_r1y0 + p_r1s - 12'd1;
                sd [nsel] <= p_r1s;
                sv [nsel] <= 1'b1;
                sr2[nsel] <= 1'b0;
                ncand     <= ncand + 4'd1;

                // Rung 2, only when a slot is left.  Slots go out candidate-
                // major, so with NROI=4 and NSCALE=2 two candidates take
                // everything and a third gets nothing -- acceptable because the
                // skin chain hands candidates over sorted by area, so the two
                // dropped are the two smallest.  Set NSCALE=1 to trade the
                // scale rung for two more faces.
                if ((NSCALE > 1) && ((nsel + 3'd1) < NROI)) begin
                    sx0[nsel + 3'd1] <= p_r2x0;
                    sy0[nsel + 3'd1] <= p_r2y0;
                    sx1[nsel + 3'd1] <= p_r2x0 + p_s2 - 12'd1;
                    sy1[nsel + 3'd1] <= p_r2y0 + p_s2 - 12'd1;
                    sd [nsel + 3'd1] <= p_s2;
                    sv [nsel + 3'd1] <= 1'b1;
                    sr2[nsel + 3'd1] <= 1'b1;
                    nsel <= nsel + 3'd2;
                end else begin
                    nsel <= nsel + 3'd1;
                end
            end

            if (p_rej && (nrej != 4'd15)) nrej <= nrej + 4'd1;

            p_take <= 1'b0;
            p_rej  <= 1'b0;
            if (cand == NSKIN + NROI - 1) begin
                selecting <= 1'b0;
            end else begin
                cand <= cand + 4'd1;
                ph   <= 3'd0;
            end
        end
        endcase
    end
end

//---------------------------------------------------------------------------
// [3] Sampling.  For ROI r, patch cell (row, col) is frame pixel
// (sy0 + floor(row*side/BUFN), sx0 + floor(col*side/BUFN)).
//
// Both floors come out of an accumulator instead of a divider: acc holds
// (n+1)*side, so acc's top bits ARE floor((n+1)*side/BUFN) when BUFN is 32.
// One add per sample per axis, no divide, no multiply, and -- unlike the mask
// version this replaces -- no variable shifter anywhere in the pixel path.
//
// The comparison is EQUALITY against the next sample point, not a range test.
// That is what makes the wrap harmless: px - sx0 wraps to at least 4096-SIDE_MAX
// when the pixel is left of the ROI, and every sample point is below side, so a
// wrapped value can never match one.  No separate "px >= sx0" compare is needed,
// same as before.
//
// Both accumulators are held in reset outside their active window rather than
// re-armed on an edge: the column DDA through every horizontal blank, the row
// DDA through the whole vertical blank.  The row one matters -- the selector
// writes sd[] during that blank, so resetting across all of it is what
// guarantees the accumulator starts from the side this frame will actually use
// rather than the previous frame's.
//---------------------------------------------------------------------------
reg wr_bank;
wire [NROI*8-1:0] qbus;

// One bit per slot: the patch just sampled into the write bank has enough
// dynamic range to be worth classifying.  Measured as the patch is written and
// consumed by the bank swap below, so it describes exactly the bank the
// classifier is about to read.  See MIN_CONTRAST in the parameter block.
wire [NROI-1:0] ctr_ok;

// One clock after the last active pixel of a line, and py still reads that
// line's index for this clock (the py counter increments in the same branch).
wire line_end = pde_prev && !de_dly[1];

genvar gi;
generate
for (gi = 0; gi < NROI; gi = gi + 1) begin : roi_store
    reg [7:0] patch [0:(1 << AW) - 1];

    wire [11:0] sdg = sd[gi];
    wire [11:0] dx  = px - sx0[gi];
    wire [11:0] dy  = py - sy0[gi];

    // Row DDA.  Advances once per sampled line, at that line's end.
    reg [16:0] yacc;                   // (row+1) * side, 32*1080 fits in 17
    reg [11:0] nxt_dy;
    reg [4:0]  row;
    reg        rdone;

    wire row_hit = sv[gi] && !rdone && (dy == nxt_dy);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            yacc <= 17'd0; nxt_dy <= 12'd0; row <= 5'd0; rdone <= 1'b0;
        end else if (!frame_open) begin
            yacc   <= {5'b0, sdg};
            nxt_dy <= 12'd0;
            row    <= 5'd0;
            rdone  <= 1'b0;
        end else if (line_end && row_hit) begin
            nxt_dy <= yacc[16:5];
            yacc   <= yacc + {5'b0, sdg};
            if (row == BUFN - 1) rdone <= 1'b1;
            else                 row   <= row + 5'd1;
        end
    end

    // Column DDA.  Advances once per sampled pixel of a sampled line.
    reg [16:0] xacc;
    reg [11:0] nxt_dx;
    reg [4:0]  col;
    reg        cdone;

    wire hit = de_dly[1] && row_hit && !cdone && (dx == nxt_dx);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            xacc <= 17'd0; nxt_dx <= 12'd0; col <= 5'd0; cdone <= 1'b0;
        end else if (!de_dly[1]) begin
            xacc   <= {5'b0, sdg};
            nxt_dx <= 12'd0;
            col    <= 5'd0;
            cdone  <= 1'b0;
        end else if (hit) begin
            nxt_dx <= xacc[16:5];
            xacc   <= xacc + {5'b0, sdg};
            if (col == BUFN - 1) cdone <= 1'b1;
            else                 col   <= col + 5'd1;
        end
    end

    // The last cell of a row and of a patch is written with col/row still at
    // BUFN-1: the done flag stops the NEXT write, not this one.
    always @(posedge clk)
        if (hit) patch[{wr_bank, row, col}] <= y_r;

    //-----------------------------------------------------------------------
    // Dynamic range of the same samples, on the same enable.  Two 8-bit
    // compares off `hit`, in parallel with the RAM write and not in series
    // with anything -- this is the pixel path and it has 34ps of margin.
    //
    // Re-armed on !frame_open, which is the identical condition the row DDA
    // resets on, so the pair always describes the frame the patch came from.
    // It survives frame_end by one clock: frame_open drops on the clock BEFORE
    // frame_end is asserted, so the publication below reads the accumulated
    // values and the re-arm lands at the end of that same clock.
    //-----------------------------------------------------------------------
    reg [7:0] pmin, pmax;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            pmin <= 8'hFF; pmax <= 8'h00;
        end else if (!frame_open) begin
            pmin <= 8'hFF; pmax <= 8'h00;
        end else if (hit) begin
            if (y_r < pmin) pmin <= y_r;
            if (y_r > pmax) pmax <= y_r;
        end
    end

    // pmax >= pmin as well as the range test: a slot that was never written
    // still holds the 255/0 re-arm, and 0 - 255 in eight bits is 1, which
    // would read as "low contrast but not zero" instead of "no patch at all".
    assign ctr_ok[gi] = (MIN_CONTRAST == 0)
                     || ((pmax >= pmin) && ((pmax - pmin) >= MIN_CONTRAST));

    // Registered read of the OTHER bank.  rd_addr's ROI field does not change
    // during a scan, so muxing the four registered outputs with the CURRENT
    // rd_addr rather than a delayed copy gives the same answer -- and saves
    // carrying a delayed select.
    //
    // The result leaves through a flat bus rather than being read back as
    // roi_store[gi].q: hierarchical references into a generate block work in
    // iverilog but are not something to rely on in TD.
    reg [7:0] q;
    always @(posedge clk)
        q <= patch[{~wr_bank, rd_addr[9:5], rd_addr[4:0]}];

    assign qbus[gi*8 +: 8] = q;
end
endgenerate

assign rd_data = qbus[rd_addr[11:10]*8 +: 8];

//---------------------------------------------------------------------------
// [4] Bank swap and publication.
//
// Both happen together: the geometry the classifier needs describes the bank it
// is about to read, so publishing one without the other would box a face at the
// wrong place on screen -- and that failure looks exactly like a detector bug.
//---------------------------------------------------------------------------
integer pj;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        wr_bank       <= 1'b0;
        roi_x0        <= {NROI*12{1'b0}};
        roi_y0        <= {NROI*12{1'b0}};
        roi_side      <= {NROI*12{1'b0}};
        roi_valid     <= {NROI{1'b0}};
        roi_ready     <= 1'b0;
        dbg_nroi      <= 4'd0;
        dbg_swap_held <= 1'b0;
        dbg_nrej      <= 4'd0;
        dbg_flat      <= 1'b0;
    end else begin
        roi_ready <= 1'b0;
        if (frame_end) begin
            // CANDIDATES, not slots -- see the header.  Sampled at frame_end,
            // which is the clock the selector is re-armed on, so this is the
            // count the frame just finished was filled from.
            dbg_nroi <= ncand;
            // Both sampled on the same clock as dbg_nroi and from the same
            // frame's work, so the three read as one sentence on the OSD:
            // this many candidates were taken, this many were thrown out on
            // geometry, and whether anything was thrown out on contrast.
            dbg_nrej <= nrej;
            dbg_flat <= |(sv & ~ctr_ok);
            if (rd_busy) begin
                dbg_swap_held <= 1'b1;
            end else begin
                dbg_swap_held <= 1'b0;
                wr_bank       <= ~wr_bank;
                for (pj = 0; pj < NROI; pj = pj + 1) begin
                    roi_x0[pj*12 +: 12] <= sx0[pj];
                    roi_y0[pj*12 +: 12] <= sy0[pj];
                    roi_side[pj*12 +: 12] <= sd[pj];
                end
                // The contrast gate is applied HERE and not at selection time,
                // because it is a property of the pixels that were sampled and
                // those do not exist until the frame has been walked.  Slots
                // the selector filled but the picture turned out to be flat in
                // are published invalid: face_detect then ages their boxes out
                // on its normal miss path, which is what should happen when a
                // region stops being worth looking at.
                roi_valid <= sv & ctr_ok;
                roi_ready <= 1'b1;
            end
        end
    end
end

endmodule
