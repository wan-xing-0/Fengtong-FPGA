//---------------------------------------------------------------------------
// face_skin -- chroma-keyed skin mask, the candidate-region front end of the
// face detector.
//
// Output interface is deliberately identical to det_binarize's bit output, so
// this drops straight into the existing det_morph_open -> ccl_blob pair as a
// SECOND instance of each.  That reuse is the whole design: connected-component
// labelling, area sorting, gap merging, overflow handling and the frame-end
// publish timing are all already written, debugged over five rounds on the
// board, and none of it cares whether the mask means "differs from the
// background" or "looks like skin".
//
// WHY A SKIN MASK AND NOT THE EXISTING LUMA BLOBS
// The L5 detect chain thresholds LUMA against a local background estimate, so it
// finds whatever contrasts with the surface.  A face on a mid-grey wall has
// almost no luma contrast and produces no blob at all, so the classifier would
// never be handed a window to look at.  Chroma is the opposite: skin sits in a
// tight, well-known Cb/Cr box that almost nothing else in a room occupies, and
// it is nearly independent of illumination level.  The motion boxes are wired in
// alongside as a fallback (see face_roi_buf), which covers the other direction:
// someone in an unusual light who is nonetheless moving.
//
// THE RULE
// The Cb/Cr bounds are the standard Chai-Ngan skin locus, 77..127 and 133..173.
// They are parameters because they are the one thing likely to want tuning on
// the board under the actual lamp -- but tune them LAST.  The failure this
// detector is most likely to show first is a framing or scale problem in
// face_roi_buf, and widening the chroma box to chase that just floods
// ccl_blob with wall-coloured blobs.
//
// ⭐ 09-19 LATE: THIS RULE WAS MEASURED AND LEFT ALONE.  READ THIS BEFORE
// REWRITING IT, BECAUSE THE OBVIOUS REWRITE HAS ALREADY BEEN TRIED AND IT
// CHANGES NOTHING.
//
// The board was showing FACES 0/0 on a live face and, on a near-monochrome
// portrait, a box on the LIPS.  The hypothesis was that this module taps
// af_out_*, which is after isp_auto_level's three independent per-channel
// stretches (a grey-world correction -- isp_saturate's header calls it
// actively desaturating) and before isp_saturate's compensating 1.25x.  So
// the picture judged here has less chroma than the picture on the TV, and
// Chai-Ngan's binding edge Cr >= 133 is only five counts above neutral.
//
// The replacement tried was the difference Cr - Cb, which is immune to a
// colour cast (the green coefficients nearly cancel: Cr - Cb = (171R - 22G -
// 149B)/256) and sits at exactly 0 for neutral grey at any brightness.  It
// was scored against this rule on twenty colours -- skin at three tones, each
// desaturated by half and by three-quarters, green- and teal-cast faces, a
// near-monochrome face, lips, grey walls, wood, sky, foliage, saturated red --
// with both rules' arithmetic cross-checked against cv2.cvtColor.
//
// THE TWO RULES AGREED ON ALL TWENTY.  Not one case separated them.  The
// premise was simply wrong: skin desaturated by half still reads Cr=142, and
// by three-quarters still reads Cr=135, so this box does NOT lose real skin to
// the grey-world stretch.  The cases that do fail here -- a green-cast face at
// Cr=124, a near-monochrome one at Cr=130 -- fail under BOTH rules, because
// in those pictures the face genuinely is not red-dominant.
//
// SO THE REAL CAUSES WERE ELSEWHERE, and both are fixed or filed:
//   * "a face is only occasionally detected" was the CLASSIFIER SCAN, not this
//     mask: the cascade's accept region is ~1px wide and FACE_STEP was 4, so
//     the sweep visited 9 of 81 positions and missed the accepting pixel about
//     seven times in eight.  FACE_STEP is 1 now; see system_top.
//   * "0/0 on a green-cast picture" is a WHITE BALANCE problem.  No chroma
//     rule can find a red-dominant region in a picture where the face is not
//     red-dominant.  That belongs in the ISP (a real AWB, or WB_R/G/B retuned
//     under the bench lamp), not here.
//
// ⚠ DO NOT "fix" recall by widening these bounds.  Towards neutral they run
// into grey walls, which is what MIN_AREA and MAX_W/MAX_H then have to fight;
// and the measurement above says there is no recall there to win.  fstb.v
// locks the twenty scored colours in so this does not get re-litigated.
//
// ⭐⭐ 10-02 NIGHT: THE "WHITE BALANCE PROBLEM" ABOVE IS NOW MEASURED, AND IT IS
// THE WHOLE MISS RATE.  SKIN_REL=1 is the fix; SKIN_REL=0 is the rule above,
// bit-exact (fstb runs on the defaults, so it still tests that rule).
// The first board recording of the CNN build (lab, fluorescent tubes, 90 s)
// was run through tools/face_cnn/try_images.py: 30 Haar faces, 0 boxes, and
// 27 of the 30 misses were "no skin ROI at all" -- the CNN was never asked.
// The face's cheeks read median Cr 128 / Cb 106 (Cr >= 133 passed 0-5% of the
// face) because the WHOLE PICTURE is green: frame median Cr ~119 / Cb ~116.
// But the face RELATIVE to the frame was stable across every frame and both
// subjects: dCr +10..+21, dCb -9..-16.  So the box is now placed relative to
// the previous frame's mean chroma -- a grey-world reference for this one
// side branch only, leaving the ISP (and every colour-keyed chain) alone:
//     mCr + REL_CR_D <= Cr <= mCr + REL_SPAN
//     mCb - REL_SPAN <= Cb <= mCb - REL_CB_D
// Offline on that recording (board_sim, same arithmetic): hit 0% -> 83%.
// The mean is sum >> MEAN_SHIFT, no divider; 2^21 is 1.1% above 1920x1080, so
// mean reads ~1.3 counts low, which the measured offsets already include.
// It is the PREVIOUS frame's mean (latched at the visible frame's end), so a
// frame is judged against one constant box, never one that moves mid-frame.
// The cost of the relative box is that wood / orange furniture in a green
// room now reads as skin; that is the CNN's job, and the measured false
// boxes on that recording were chairs and a T-shirt print -- training data.
//
// A luma guard is also applied.  Very dark pixels have almost no chroma
// information -- the RGB values are small so the differences that make up Cb/Cr
// are small and noise-dominated -- and without the guard the darkest parts of
// the frame drift in and out of the skin box frame to frame.  That was visible
// as flicker in the old motion chain for the same reason.
//
// COST AND TIMING
// Three register stages, each a short adder tree, and the widest constant
// multiply is 8x8.  It is a side branch off af_out_*, so nothing here is in the
// display path -- but it is still pclkx1, which has ~0.1ns of margin (section
// 5.2), hence pipelining something that would fit in one stage on paper.
//
// vs POLARITY: in_vs is HIGH across the visible frame, matching det_binarize's
// in_vs and af_out_vs.  It is NOT the 5-line sync pulse -- see section 3.-8 and
// the fpga_vs_is_sync_pulse note.  This module only delays it, so it cannot get
// that wrong, but the next person editing this file should know which one it is.
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module face_skin #(
// Chroma bounds, inclusive.  Tune on the board, but see the header: tune this
// LAST, after the ROI geometry is known to be right -- and read the 09-19
// measurement there before assuming these are what is holding recall back.
parameter [7:0] CB_LO = 8'd77,
parameter [7:0] CB_HI = 8'd127,
parameter [7:0] CR_LO = 8'd133,
parameter [7:0] CR_HI = 8'd173,

// Luma guard.  Below CB_LO's worth of light there is no usable chroma; above
// Y_HI the sensor is clipping and the ratios are meaningless.
parameter [7:0] Y_LO  = 8'd40,
parameter [7:0] Y_HI  = 8'd250,

// 1 = chroma box relative to the previous frame's mean (see header, 10-02
// night); CB_LO..CR_HI are then unused.  0 = the fixed box, bit-exact.
parameter        SKIN_REL   = 0,
parameter [7:0]  REL_CR_D   = 8'd6,     // Cr at least this far above the mean
parameter [7:0]  REL_CB_D   = 8'd4,     // Cb at least this far below the mean
parameter [7:0]  REL_SPAN   = 8'd48,    // and neither more than this far away
parameter integer MEAN_SHIFT = 21,      // mean = sum >> this (1080p: 2^21)

// 1 = (SKIN_REL only) REL_CR_D / REL_CB_D scale with the pixel's own luma,
// D * min(Y, 128) >> 7: full strength at Y >= 128, half at Y = 64.  0 = the
// fixed offsets, bit-exact.  See [3].
parameter        SKIN_YSCALE = 0,

// 1 = Y, Cb and Cr each averaged over this pixel and the three before it on
// the row (zero before the row start) before any compare; the frame mean of
// [2b] stays on the raw values.  0 = bit-exact without it.  See [2d].
// +2 clocks of latency when on.
parameter        SKIN_HAVG   = 0
)(
input  wire        clk,
input  wire        rst_n,

input  wire        in_vs,          // HIGH across the visible frame
input  wire        in_de,
input  wire [7:0]  in_r,
input  wire [7:0]  in_g,
input  wire [7:0]  in_b,

output reg         out_vs,
output reg         out_de,
output reg         out_bin         // 1 = this pixel looks like skin
);

//---------------------------------------------------------------------------
// [1] Stage 1 -- the six weighted terms.
//
// Y  =  ( 77R + 150G +  29B) / 256
// Cb = 128 + (-43R -  85G + 128B) / 256
// Cr = 128 + (128R - 107G -  21B) / 256
//
// which is the usual JPEG/BT.601 full-range matrix at 1/256.  The negative
// coefficients are collected as positive terms and subtracted in stage 2, so
// everything here is unsigned.
//---------------------------------------------------------------------------
reg [15:0] y_pos;
reg [15:0] cb_neg, cb_pos;
reg [15:0] cr_neg, cr_pos;
reg        vs_1, de_1;

always @(posedge clk) begin
    if (!rst_n) begin
        vs_1 <= 1'b0;
        de_1 <= 1'b0;
    end else begin
        y_pos  <= 16'd77 * in_r + 16'd150 * in_g + 16'd29 * in_b;
        cb_neg <= 16'd43 * in_r + 16'd85  * in_g;
        cb_pos <= {in_b, 7'b0};                         // 128 * B
        cr_neg <= 16'd107 * in_g + 16'd21 * in_b;
        cr_pos <= {in_r, 7'b0};                         // 128 * R
        vs_1   <= in_vs;
        de_1   <= in_de;
    end
end

//---------------------------------------------------------------------------
// [2] Stage 2 -- fold to Y, Cb, Cr.
//
// Cb and Cr are centred at 128 and the matrix guarantees they stay inside
// 0..255 for any legal RGB, so the subtract cannot underflow for real pixel
// values.  It is clamped anyway: this runs on demosaiced sensor data that has
// been through gamma, auto-level and saturation, and an out-of-gamut excursion
// there would otherwise wrap a bright pixel into the middle of the skin box.
//---------------------------------------------------------------------------
reg [7:0] y_2, cb_2, cr_2;
reg       vs_2, de_2;

wire signed [17:0] cb_raw = 18'sd32768 + $signed({2'b0, cb_pos}) - $signed({2'b0, cb_neg});
wire signed [17:0] cr_raw = 18'sd32768 + $signed({2'b0, cr_pos}) - $signed({2'b0, cr_neg});

always @(posedge clk) begin
    if (!rst_n) begin
        vs_2 <= 1'b0;
        de_2 <= 1'b0;
    end else begin
        y_2  <= y_pos[15:8];
        cb_2 <= cb_raw[17] ? 8'd0 : cb_raw[16] ? 8'd255 : cb_raw[15:8];
        cr_2 <= cr_raw[17] ? 8'd0 : cr_raw[16] ? 8'd255 : cr_raw[15:8];
        vs_2 <= vs_1;
        de_2 <= de_1;
    end
end

//---------------------------------------------------------------------------
// [2b] SKIN_REL only -- frame mean of Cb/Cr and the box around it.
//
// Sums run over every de pixel of the visible frame and are published at its
// end (vs falling), so the box used for frame N comes from frame N-1 and is
// constant across frame N.  Before the first full frame the mean is 128, i.e.
// a box close to the fixed one.  The four bounds are registered off the two
// means, so stage 3 still compares against registers, not adders.  Each bound
// saturates at 0 / 255: a wrap would put the box on the far side of the axis.
// With SKIN_REL=0 none of this reaches out_bin and synthesis drops it.
//---------------------------------------------------------------------------
reg  [31:0] sum_cb, sum_cr;
reg         vs_2d;
reg  [7:0]  m_cb, m_cr;
reg  [7:0]  t_cb_lo, t_cb_hi, t_cr_lo, t_cr_hi;

wire [31:0] q_cb = sum_cb >> MEAN_SHIFT;
wire [31:0] q_cr = sum_cr >> MEAN_SHIFT;
wire [8:0]  w_cr_lo = {1'b0, m_cr} + {1'b0, REL_CR_D};
wire [8:0]  w_cr_hi = {1'b0, m_cr} + {1'b0, REL_SPAN};
wire [8:0]  w_cb_hi = {1'b0, m_cb} - {1'b0, REL_CB_D};
wire [8:0]  w_cb_lo = {1'b0, m_cb} - {1'b0, REL_SPAN};

always @(posedge clk) begin
    if (!rst_n) begin
        vs_2d  <= 1'b0;
        sum_cb <= 32'd0;
        sum_cr <= 32'd0;
        m_cb   <= 8'd128;
        m_cr   <= 8'd128;
    end else begin
        vs_2d <= vs_2;
        if (vs_2d && !vs_2) begin
            m_cb   <= (|q_cb[31:8]) ? 8'd255 : q_cb[7:0];
            m_cr   <= (|q_cr[31:8]) ? 8'd255 : q_cr[7:0];
            sum_cb <= 32'd0;
            sum_cr <= 32'd0;
        end else if (vs_2 && de_2) begin
            sum_cb <= sum_cb + cb_2;
            sum_cr <= sum_cr + cr_2;
        end
    end
end

always @(posedge clk) begin
    t_cr_lo <= w_cr_lo[8] ? 8'd255 : w_cr_lo[7:0];
    t_cr_hi <= w_cr_hi[8] ? 8'd255 : w_cr_hi[7:0];
    t_cb_hi <= w_cb_hi[8] ? 8'd0   : w_cb_hi[7:0];
    t_cb_lo <= w_cb_lo[8] ? 8'd0   : w_cb_lo[7:0];
end

//---------------------------------------------------------------------------
// [2c] SKIN_YSCALE only -- per-pixel offsets, registered beside y_2 so stage 3
// stays one add + one compare per bound.  y_pos[15:8] is the stage-1 register
// that y_2 is taken from, so off_* and y_2 describe the same pixel.
//
// WHY (10-03 evening, board recording 14:47 + "dark = no box" report): chroma
// distance from grey shrinks with the light.  On the lab footage the centre of
// a face sits only dCr +3.5 / dCb -12 off the frame mean in good light (it
// passes on the cheeks); at 0.6x light dCb is -6, at 0.4x -4 = REL_CB_D, and
// the mask collapses: offline hit 82% -> 33%.  The CNN was not the stage that
// failed (CNN-no stayed <= 8%).  Scaling the offsets with Y: 90 / 92 / 94% at
// 1.0 / 0.6 / 0.4x, and fewer raw false boxes on the no-face clips (0.03 ->
// 0.01/frame) -- a dim patch was never skin evidence just by being off-grey.
//---------------------------------------------------------------------------
wire [7:0]  y_1   = y_pos[15:8];
wire [7:0]  y_c   = y_1[7] ? 8'd128 : y_1;            // min(Y, 128)
wire [15:0] p_cr  = REL_CR_D * y_c;
wire [15:0] p_cb  = REL_CB_D * y_c;
reg  [7:0]  off_cr_2, off_cb_2;

always @(posedge clk) begin
    off_cr_2 <= p_cr[14:7];
    off_cb_2 <= p_cb[14:7];
end

//---------------------------------------------------------------------------
// [2d] SKIN_HAVG only -- 4-tap horizontal box on Y, Cb, Cr, two stages.
//
// WHY (10-05, FACE DBG recording): the board drew its ROIs smaller than the
// face and off it, where board_sim fed the recorded picture framed the whole
// face, and every stage from here to face_roi_buf was then shown bit-exact
// against board_sim on a recorded frame.  So the board's mask is not the
// recording's mask: the recording is 720p H.264, and the per-pixel sensor
// noise at 1080p is exactly what it smooths away.  This decision is per
// pixel, on a chroma margin of a few codes (REL_CR_D 6 / REL_CB_D 4), so noise
// of that size breaks a face into fragments that the opening then erodes.
// Offline (1601 DBG frames, ccl modelled bit-exact): the board boxed frontal
// faces < 250 / 250-400 / >= 400 px at 0.32 / 0.53 / 0.66; the clean recording
// through the same chain gives 0.70 / 0.87 / 0.80; sigma-2..3 noise added to
// it gives 0.05-0.36 / 0.26-0.78 / 0.62-0.71 -- the board's range, and the
// simulated ROIs move toward the board's.  The noise is a proxy (its true
// level is not known).  With this box and FACE_CCL_SEEN the same noise gives
// 0.64-0.69 / 0.87-0.91 / 0.74-0.79.  Clean cost: <= 0.03 on frontal faces
// here, and on the 10-04 held-out set 0.61/0.82/0.88 -> 0.59/0.81/0.87, 3/4
// views 0.65 -> 0.69, false-box frames on no-face clips 0.020 -> 0.014.
// An 8x1 box (registers only) or 4x4 (three line buffers) measured 1-3
// points better on big faces under noise and halved the remaining merge-list
// overflows; 4x1 was kept because the proxy cannot separate them.  If the
// FACE DBG view still shows the face as several orange blobs, widen to 8 first.
//
// Stage A: sum of the four taps >> 2.  The taps shift in zero while de is low,
// so a row's first pixels average against zeros, never against the previous
// row (board_sim mirrors this exactly).  Stage B: the YSCALE offsets from the
// AVERAGED luma, the same relation [2c] has to y_2, so the decision below sees
// one consistent pixel.  The output is the average of x-3..x at position x:
// a 1.5 px shift of the mask, below anything the ROI framing resolves.
//---------------------------------------------------------------------------
wire [7:0] y_d, cb_d, cr_d, off_cr_d, off_cb_d;
wire       vs_d, de_d;

generate if (SKIN_HAVG != 0) begin : g_havg
    reg  [7:0] y_t1, y_t2, y_t3, cb_t1, cb_t2, cb_t3, cr_t1, cr_t2, cr_t3;
    reg  [7:0] y_a, cb_a, cr_a, y_b, cb_b, cr_b, ocr_b, ocb_b;
    reg        vs_a, de_a, vs_b, de_b;

    wire [9:0]  y_s  = y_2  + y_t1  + y_t2  + y_t3;
    wire [9:0]  cb_s = cb_2 + cb_t1 + cb_t2 + cb_t3;
    wire [9:0]  cr_s = cr_2 + cr_t1 + cr_t2 + cr_t3;
    wire [7:0]  y_ac = y_a[7] ? 8'd128 : y_a;          // min(Y, 128)
    wire [15:0] q_cr = REL_CR_D * y_ac;
    wire [15:0] q_cb = REL_CB_D * y_ac;

    always @(posedge clk) begin
        if (!rst_n) begin
            y_t1 <= 8'd0; y_t2 <= 8'd0; y_t3 <= 8'd0;
            cb_t1 <= 8'd0; cb_t2 <= 8'd0; cb_t3 <= 8'd0;
            cr_t1 <= 8'd0; cr_t2 <= 8'd0; cr_t3 <= 8'd0;
            vs_a <= 1'b0; de_a <= 1'b0; vs_b <= 1'b0; de_b <= 1'b0;
        end else begin
            y_t1  <= de_2 ? y_2  : 8'd0;  y_t2  <= y_t1;  y_t3  <= y_t2;
            cb_t1 <= de_2 ? cb_2 : 8'd0;  cb_t2 <= cb_t1; cb_t3 <= cb_t2;
            cr_t1 <= de_2 ? cr_2 : 8'd0;  cr_t2 <= cr_t1; cr_t3 <= cr_t2;
            vs_a <= vs_2; de_a <= de_2;
            vs_b <= vs_a; de_b <= de_a;
        end
    end

    always @(posedge clk) begin
        y_a  <= y_s[9:2];  cb_a <= cb_s[9:2];  cr_a <= cr_s[9:2];
        y_b  <= y_a;       cb_b <= cb_a;       cr_b <= cr_a;
        ocr_b <= q_cr[14:7];
        ocb_b <= q_cb[14:7];
    end

    assign y_d = y_b;  assign cb_d = cb_b;  assign cr_d = cr_b;
    assign off_cr_d = ocr_b;  assign off_cb_d = ocb_b;
    assign vs_d = vs_b;  assign de_d = de_b;
end else begin : g_nohavg
    assign y_d = y_2;  assign cb_d = cb_2;  assign cr_d = cr_2;
    assign off_cr_d = off_cr_2;  assign off_cb_d = off_cb_2;
    assign vs_d = vs_2;  assign de_d = de_2;
end endgenerate

wire ysc_ok = ({1'b0, cr_d} >= {1'b0, m_cr} + {1'b0, off_cr_d})
           && ({1'b0, cr_d} <= {1'b0, t_cr_hi})
           && ({1'b0, cb_d} + {1'b0, off_cb_d} <= {1'b0, m_cb})
           && (cb_d >= t_cb_lo);

//---------------------------------------------------------------------------
// [3] Stage 3 -- the decision (on the [2d] averages with SKIN_HAVG).  Six compares, against constants (SKIN_REL=0)
// or against the four registered bounds of [2b] (SKIN_REL=1).
//---------------------------------------------------------------------------
wire abs_ok = (cb_d >= CB_LO)   && (cb_d <= CB_HI)
           && (cr_d >= CR_LO)   && (cr_d <= CR_HI);
wire rel_ok = (cb_d >= t_cb_lo) && (cb_d <= t_cb_hi)
           && (cr_d >= t_cr_lo) && (cr_d <= t_cr_hi);

always @(posedge clk) begin
    if (!rst_n) begin
        out_vs  <= 1'b0;
        out_de  <= 1'b0;
        out_bin <= 1'b0;
    end else begin
        out_vs  <= vs_d;
        out_de  <= de_d;
        out_bin <= de_d
                && (SKIN_REL ? (SKIN_YSCALE ? ysc_ok : rel_ok) : abs_ok)
                && (y_d  >= Y_LO)  && (y_d  <= Y_HI);
    end
end

endmodule
