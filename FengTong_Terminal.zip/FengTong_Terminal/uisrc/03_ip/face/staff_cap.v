//---------------------------------------------------------------------------
// staff_cap -- cuts the 64x64 gray patch the staff recogniser (staff_cnn)
// reads: an AREA-AVERAGED resample of a square around the biggest face box.
//
// WHAT IT COMPUTES is defined, bit for bit, by tools/staff_id/staff_q.py
// (cap_request, cap_patch, luma_bgr).  If the two ever disagree, THOSE are the
// specification.
//
//   box     the widest valid face_detect box of the frame (ties: lowest slot)
//   square  side = clamp(s + (s >> 4), 64, SIDE_MAX), s = box width;
//           centred on the box, clamped into [0, W-side] x [Y_TOP, H-side]
//   patch   bin n per axis = [floor(n side / 64), floor((n+1) side / 64)),
//           avg = min(255, (sum * RCPA[cnt] + 2^15) >> 16), RCPA[c] = round(65536 / c)
//   luma    (77R + 150G + 29B) >> 8, face_roi_buf's
//
// WHY AREA AVERAGE AND NOT face_roi_buf's NEAREST-NEIGHBOUR DDA.  face_cnn sees
// 32x32 and was trained on exactly the board's point samples, aliasing and all.
// The recogniser was distilled from SFace on area-resampled crops; at a 300 px
// face a 1-in-5 point sample turns hair and glasses into patterns that set has
// never contained.  A box filter costs one adder per pixel and 64 column sums.
//
// WHY 1/16 AND NOT THE 1.0625 IT LOOKS LIKE.  box_study.py: the board's face
// box is 1.07 x the YuNet box at the median, and the student's training crop is
// 1.1 x YuNet (train_student.S0), so 1/16 brings the board crop to it.  dy is 0
// on purpose: the box sits ~5% high on the staff and ~1% low on stranger B, a
// spread that train_staff --jit covers rather than a bias worth correcting.
//
// TIMING.  The square for frame N+1 is chosen at the end of frame N from the
// boxes face_detect published then, and the patch of frame N+1 is readable from
// the end of frame N+1 (double-banked; the swap waits while staff_cnn is still
// reading, rd_busy, exactly like face_roi_buf).  So the patch lags the box by
// one frame -- 17 ms, nothing at walking speed.
//
// STREAMING.  Per line, pixels inside the square run through a horizontal bin
// accumulator; each finished bin (at most one per clock, in increasing order)
// goes through a 2-stage read-modify-write into a 64-entry column-sum RAM, and
// on the last line of a row bin it goes to the divider instead and lands in the
// patch.  The RMW never collides: bin b is written the clock bin b+1 is read.
//
// vs POLARITY: in_vs is HIGH across the visible frame (face_roi_buf's tap).
//
// HOLD (10-27, 17:12 video): in a liveness challenge face_detect dropped the
// staff member's box for 6 s at 1.3 m (mouth open, then closed again) while
// the face sat still in the same place -- no box, no patch, no result, so
// staff_ctrl saw the face "lost" and failed the challenge.  With hold_en
// (system_top: staff_ctrl is in a challenge) a frame without any valid box
// re-uses the last chosen square, for at most HOLD_FR such frames in a row.
// Nothing is guessed: the patch is re-read where the face was, and it is
// staff_cnn's score on it that decides whether the face is still there (a
// person who walked off scores as background and LOST_T runs as before).
// HOLD_FR = 0 or hold_en = 0: the 10-11 behaviour bit for bit.
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module staff_cap #(
parameter integer IMG_HDISP = 1920,
parameter integer IMG_VDISP = 1080,
parameter integer NROI      = 4,
parameter integer Y_TOP     = 8,          // face_roi_buf's: the first lines are not picture; >= 1
parameter integer SIDE_MIN  = 64,
parameter integer SIDE_MAX  = 1072,       // <= IMG_VDISP - Y_TOP, and cnt <= 17*17
parameter integer VB_GUARD  = 512,        // a de gap longer than this ends the frame
parameter integer HOLD_FR   = 0           // 10-27: boxless frames that re-use the last square (<= 254)
)(
input  wire        clk,
input  wire        rst_n,
input  wire        hold_en,               // 10-27: HOLD allowed (staff_ctrl challenge)

input  wire        in_vs,
input  wire        in_de,
input  wire [7:0]  in_r,
input  wire [7:0]  in_g,
input  wire [7:0]  in_b,

// face_detect's published boxes (raw, not face_smooth's)
input  wire [NROI*12-1:0] box_x0,
input  wire [NROI*12-1:0] box_x1,
input  wire [NROI*12-1:0] box_y0,
input  wire [NROI*12-1:0] box_y1,
input  wire [NROI-1:0]    box_vld,

// reader side
input  wire [11:0] rd_addr,               // {row[5:0], col[5:0]}
output reg  [7:0]  rd_data,               // one clock after rd_addr
input  wire        rd_busy,

output reg         patch_ready,           // one clock: a fresh patch is readable
output reg  [11:0] patch_x0,              // its square, frame pixels
output reg  [11:0] patch_y0,
output reg  [11:0] patch_side,
output reg         dbg_held               // a finished patch was dropped (rd_busy)
);

//---------------------------------------------------------------------------
// [1] luma and coordinates -- face_roi_buf's generator, same two-deep de
//---------------------------------------------------------------------------
reg [15:0] y_acc;
reg [7:0]  y_r;
always @(posedge clk) begin
    y_acc <= 16'd77 * in_r + 16'd150 * in_g + 16'd29 * in_b;
    y_r   <= y_acc[15:8];
end

reg [1:0]  de_dly, vs_dly;
reg [11:0] px, py;
reg        pde_prev;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        de_dly <= 2'b0; vs_dly <= 2'b0;
        px <= 12'd0; py <= 12'd0; pde_prev <= 1'b0;
    end else begin
        de_dly   <= {de_dly[0], in_de};
        vs_dly   <= {vs_dly[0], in_vs};
        pde_prev <= de_dly[1];
        if (!vs_dly[1]) begin
            px <= 12'd0;
            py <= 12'd0;
        end else if (de_dly[1]) begin
            px <= px + 12'd1;
        end else begin
            px <= 12'd0;
            if (pde_prev) py <= py + 12'd1;
        end
    end
end

reg [11:0] quiet;
reg        frame_open, frame_end;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        quiet <= 12'd0; frame_open <= 1'b0; frame_end <= 1'b0;
    end else begin
        frame_end <= 1'b0;
        if (de_dly[1]) begin
            quiet <= 12'd0;
            frame_open <= 1'b1;
        end else if (quiet < VB_GUARD) begin
            quiet <= quiet + 12'd1;
        end else if (frame_open) begin
            frame_open <= 1'b0;
            frame_end  <= 1'b1;
        end
    end
end

wire       pv   = de_dly[1];             // y_r, px, py describe one pixel
wire       eol  = pde_prev && !de_dly[1]; // the clock after a line's last pixel

//---------------------------------------------------------------------------
// [2] at frame end: pick the widest box, turn it into the next frame's square.
//     A small sequencer, one box per clock then four arithmetic clocks -- the
//     blanking after frame_end is ~11,000 clocks (vs is a sync pulse, see
//     face_roi_buf), this needs NROI + 5.
//---------------------------------------------------------------------------
reg [2:0]  sel_i;
reg        sel_run;
reg        best_v;
reg [11:0] bx0, bx1, by0, by1, bw;
reg [3:0]  sq_ph;
reg [12:0] sd_raw;                       // s + (s >> 4), up to 13 bits
reg [11:0] sd;
reg [12:0] cx2, cy2;                     // 2 x centre
reg signed [13:0] ox2, oy2;
reg [11:0] nx0, ny0, nside;
reg        nvalid;
reg        have_last;                    // HOLD: some frame has chosen a box
reg [7:0]  hcnt;                         // HOLD: boxless frames since that one

wire [11:0] cand_x0 = box_x0[sel_i*12 +: 12];
wire [11:0] cand_x1 = box_x1[sel_i*12 +: 12];
wire [11:0] cand_y0 = box_y0[sel_i*12 +: 12];
wire [11:0] cand_y1 = box_y1[sel_i*12 +: 12];
wire [11:0] cand_w  = cand_x1 - cand_x0 + 12'd1;

// the square being captured this frame
reg [11:0] cx0, cy0, cside;
reg        cvalid;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        sel_i <= 3'd0; sel_run <= 1'b0; best_v <= 1'b0;
        bx0 <= 12'd0; bx1 <= 12'd0; by0 <= 12'd0; by1 <= 12'd0; bw <= 12'd0;
        sq_ph <= 4'd0; sd_raw <= 13'd0; sd <= 12'd0; cx2 <= 13'd0; cy2 <= 13'd0;
        ox2 <= 14'sd0; oy2 <= 14'sd0; nx0 <= 12'd0; ny0 <= 12'd0; nside <= 12'd0; nvalid <= 1'b0;
        have_last <= 1'b0; hcnt <= 8'hff;
    end else begin
        if (frame_end) begin
            sel_i <= 3'd0; sel_run <= 1'b1; best_v <= 1'b0; sq_ph <= 4'd0;
        end else if (sel_run) begin
            if (box_vld[sel_i] && (!best_v || cand_w > bw)) begin
                best_v <= 1'b1;
                bx0 <= cand_x0; bx1 <= cand_x1; by0 <= cand_y0; by1 <= cand_y1; bw <= cand_w;
            end
            if (sel_i == NROI - 1) begin
                sel_run <= 1'b0;
                sq_ph   <= 4'd1;
            end
            sel_i <= sel_i + 3'd1;
        end else if (sq_ph == 4'd1) begin
            sd_raw <= {1'b0, bw} + {5'd0, bw[11:4]};
            cx2    <= {1'b0, bx0} + {1'b0, bx1} + 13'd1;
            cy2    <= {1'b0, by0} + {1'b0, by1} + 13'd1;
            sq_ph  <= 4'd2;
        end else if (sq_ph == 4'd2) begin
            sd    <= (sd_raw < SIDE_MIN) ? SIDE_MIN[11:0] : (sd_raw > SIDE_MAX) ? SIDE_MAX[11:0] : sd_raw[11:0];
            sq_ph <= 4'd3;
        end else if (sq_ph == 4'd3) begin
            ox2   <= $signed({1'b0, cx2}) - $signed({2'b00, sd});
            oy2   <= $signed({1'b0, cy2}) - $signed({2'b00, sd});
            sq_ph <= 4'd4;
        end else if (sq_ph == 4'd4) begin
            // (c2 - side) >> 1, then clamp; a negative half is below any clamp floor
            nx0 <= ox2[13] ? 12'd0
                 : (ox2[12:1] > IMG_HDISP - sd) ? (IMG_HDISP - sd) : ox2[12:1];
            ny0 <= (oy2[13] || oy2[12:1] < Y_TOP) ? Y_TOP[11:0]
                 : (oy2[12:1] > IMG_VDISP - sd) ? (IMG_VDISP - sd) : oy2[12:1];
            nside  <= sd;
            // HOLD: without a box this frame bx0..bw still hold the last chosen
            // box (only a valid candidate writes them), so nx0/ny0/nside above
            // are that frame's square again.
            nvalid <= best_v || (hold_en && have_last && (hcnt < HOLD_FR));
            if (best_v) begin
                have_last <= 1'b1; hcnt <= 8'd0;
            end else if (hcnt != 8'hff)
                hcnt <= hcnt + 8'd1;
            sq_ph  <= 4'd0;
        end
    end
end

//---------------------------------------------------------------------------
// [3] the bin walk.  Row bins per frame, column bins per line; each a DDA on
//     acc = (n+1) * side, edge = acc >> 6.  Latch the square at the first
//     pixel of a frame, so a box chosen during blanking applies to the whole
//     next frame and never to half of one.
//---------------------------------------------------------------------------
reg        fr_first;                     // waiting for the frame's first pixel
reg        cap_done;                     // all 64 row bins written this frame
reg        wbank;

reg [5:0]  rby;                          // row bin
reg [17:0] racc;                         // (rby+1) * side
reg [11:0] ly;                           // line index inside the square
reg        ly_in;                        // this line is inside the square
reg        rfirst;                       // first line of row bin rby
reg [4:0]  rlines;                       // lines seen in row bin rby (1..17)

reg [5:0]  cbx;                          // column bin
reg [17:0] cacc;
reg [11:0] lx;
reg        lx_in;
reg [16:0] hs;                           // pixels summed in the current column bin
reg [4:0]  hc;                           // and how many

wire [11:0] redge = racc[17:6];          // ly + 1 at the row bin's last line
wire [11:0] cedge = cacc[17:6];

// this pixel, inside the square?  (x run starts at cx0)
wire       x_start = pv && (px == cx0);
wire       in_px   = pv && ly_in && (x_start || lx_in);
wire [11:0] lx_now = x_start ? 12'd0 : lx;
wire       bin_end = in_px && (lx_now + 12'd1 == (x_start ? {6'd0, cside[11:6]} : cedge));
wire [16:0] hs_now = (x_start ? 17'd0 : hs) + {9'd0, y_r};
wire [4:0]  hc_now = (x_start ? 5'd0 : hc) + 5'd1;
wire       last_line = (ly + 12'd1 == redge);

// emission pipe: E0 -> E1 (column-sum read) -> E2 (add, write / divide)
reg        e1_v, e2_v;
reg [5:0]  e1_b, e2_b;
reg [16:0] e1_hs, e2_hs;
reg [4:0]  e1_hc, e2_hc;
reg        e1_first, e2_first, e1_last, e2_last;
reg [4:0]  e1_rl, e2_rl;
reg [5:0]  e1_by, e2_by;

reg [16:0] csum [0:63];
reg [5:0]  cs_ra;
reg [16:0] cs_q;

// divider pipe: D1 cnt -> D2 RCPA -> D3 product -> round/clamp/write.
// staff_rcpa.hex: round(65536 / c) for c = 0..289 (0 -> 0), export_hex.py.
// Bare filename: this file stays beside it in uisrc/03_ip/face/.
reg  [16:0] rcpa_rom [0:289];
initial $readmemh("staff_rcpa.hex", rcpa_rom);

reg        d1_v, d2_v, d3_v;
reg [16:0] d1_s, d2_s;
reg [8:0]  d1_cnt;
reg [16:0] d2_r;
reg [33:0] d3_p;
reg [11:0] d1_a, d2_a, d3_a;

wire [16:0] e2_sum = (e2_first ? 17'd0 : cs_q) + e2_hs;
wire [33:0] d3_pr  = d3_p + 34'd32768;

always @(posedge clk) begin
    cs_q <= csum[cs_ra];
    if (e2_v && !e2_last) csum[e2_b] <= e2_sum;
end

reg  [7:0] pbuf [0:8191];
reg        pb_we;
reg [12:0] pb_wa;
reg [7:0]  pb_wd;
always @(posedge clk) begin
    if (pb_we) pbuf[pb_wa] <= pb_wd;
    rd_data <= pbuf[{~wbank, rd_addr}];
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        fr_first <= 1'b1; cap_done <= 1'b0; wbank <= 1'b0;
        cx0 <= 12'd0; cy0 <= 12'd0; cside <= 12'd64; cvalid <= 1'b0;
        rby <= 6'd0; racc <= 18'd0; ly <= 12'd0; ly_in <= 1'b0; rfirst <= 1'b1; rlines <= 5'd0;
        cbx <= 6'd0; cacc <= 18'd0; lx <= 12'd0; lx_in <= 1'b0; hs <= 17'd0; hc <= 5'd0;
        e1_v <= 1'b0; e2_v <= 1'b0; e1_b <= 6'd0; e2_b <= 6'd0; e1_hs <= 17'd0; e2_hs <= 17'd0;
        e1_hc <= 5'd0; e2_hc <= 5'd0; e1_first <= 1'b0; e2_first <= 1'b0; e1_last <= 1'b0; e2_last <= 1'b0;
        e1_rl <= 5'd0; e2_rl <= 5'd0; e1_by <= 6'd0; e2_by <= 6'd0; cs_ra <= 6'd0;
        d1_v <= 1'b0; d2_v <= 1'b0; d3_v <= 1'b0; d1_s <= 17'd0; d2_s <= 17'd0; d1_cnt <= 9'd0;
        d2_r <= 17'd0; d3_p <= 34'd0; d1_a <= 12'd0; d2_a <= 12'd0; d3_a <= 12'd0;
        pb_we <= 1'b0; pb_wa <= 13'd0; pb_wd <= 8'd0;
        patch_ready <= 1'b0; patch_x0 <= 12'd0; patch_y0 <= 12'd0; patch_side <= 12'd0; dbg_held <= 1'b0;
    end else begin
        patch_ready <= 1'b0;
        pb_we <= 1'b0;

        // ---- frame boundaries
        if (frame_end) begin
            if (cvalid && cap_done && !rd_busy) begin
                wbank       <= ~wbank;
                patch_ready <= 1'b1;
                patch_x0    <= cx0;
                patch_y0    <= cy0;
                patch_side  <= cside;
                dbg_held    <= 1'b0;
            end else if (cvalid && cap_done)
                dbg_held    <= 1'b1;
            fr_first <= 1'b1;
        end

        if (pv && fr_first) begin            // first pixel of a frame: adopt the square
            fr_first <= 1'b0;
            cx0 <= nx0; cy0 <= ny0; cside <= nside; cvalid <= nvalid;
            cap_done <= 1'b0;
            rby <= 6'd0; racc <= {6'd0, nside}; ly <= 12'd0; rfirst <= 1'b1; rlines <= 5'd0;
            ly_in <= 1'b0;                   // Y_TOP >= 1: line 0 is never in the square
        end

        // ---- line boundaries: the line just ended was line `ly` of the square
        if (eol && !fr_first) begin
            lx_in <= 1'b0;
            if (ly_in) begin
                if (last_line) begin
                    rby    <= rby + 6'd1;
                    racc   <= racc + {6'd0, cside};
                    rfirst <= 1'b1;
                    rlines <= 5'd0;
                    if (rby == 6'd63) begin
                        ly_in    <= 1'b0;
                        cap_done <= 1'b1;
                    end
                end else begin
                    rfirst <= 1'b0;
                    rlines <= rlines + 5'd1;
                end
                ly <= ly + 12'd1;
            end else if (cvalid && !cap_done && (py + 12'd1 == cy0))
                ly_in <= 1'b1;               // the next line is the square's first
        end

        // ---- pixels inside the square
        if (in_px) begin
            if (bin_end) begin
                hs    <= 17'd0;
                hc    <= 5'd0;
                cbx   <= x_start ? 6'd1 : cbx + 6'd1;
                cacc  <= (x_start ? {6'd0, cside} : cacc) + {6'd0, cside};
                lx_in <= !(lx_now + 12'd1 == cside);
            end else begin
                hs    <= hs_now;
                hc    <= hc_now;
                if (x_start) begin
                    cbx  <= 6'd0;
                    cacc <= {6'd0, cside};
                end
                lx_in <= 1'b1;
            end
            lx <= lx_now + 12'd1;
        end

        // E0 -> E1
        e1_v     <= bin_end;
        e1_b     <= x_start ? 6'd0 : cbx;
        e1_hs    <= hs_now;
        e1_hc    <= hc_now;
        e1_first <= rfirst;
        e1_last  <= last_line;
        e1_rl    <= rlines + 5'd1;
        e1_by    <= rby;
        cs_ra    <= x_start ? 6'd0 : cbx;
        // E1 -> E2 (cs_q now holds csum[e1_b])
        e2_v <= e1_v; e2_b <= e1_b; e2_hs <= e1_hs; e2_hc <= e1_hc;
        e2_first <= e1_first; e2_last <= e1_last; e2_rl <= e1_rl; e2_by <= e1_by;
        // E2: add, then either write the column sum back or hand it to the divider
        // (the column-sum write is in the RAM block below)
        d1_v   <= e2_v && e2_last;
        d1_s   <= e2_sum;
        d1_cnt <= e2_hc * e2_rl;
        d1_a   <= {e2_by, e2_b};
        // D1 -> D2 -> D3 -> write
        d2_v <= d1_v; d2_s <= d1_s; d2_r <= rcpa_rom[d1_cnt]; d2_a <= d1_a;
        d3_v <= d2_v; d3_p <= d2_s * d2_r; d3_a <= d2_a;
        if (d3_v) begin
            pb_we <= 1'b1;
            pb_wa <= {wbank, d3_a};
            pb_wd <= (|d3_pr[33:24]) ? 8'd255 : d3_pr[23:16];
        end
    end
end

endmodule
