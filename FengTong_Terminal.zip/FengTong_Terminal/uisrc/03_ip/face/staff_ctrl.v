//---------------------------------------------------------------------------
// staff_ctrl -- staff verification: identity (staff_cnn's score) + a random
// liveness challenge (open the mouth / blink), then PASS.  2026-10-12.
//
//   IDLE   recognition counter: +1 per staff_cnn result with score >= THR_REC,
//          -2 per result below (floor 0), cleared after IDLE_GAP ticks with no
//          result.  At REC_ON: pick a challenge (LFSR, or CH_MODE), ask for its
//          prompt, go to CHAL.
//          STRANGER (10-12 night, user): a face up for GRACE_N judged results
//          without being recognised -> "身份核验未通过" (CLIP_FAIL), at most
//          once per FAIL_GAP ticks, before the alarm's own voice (hold_voice
//          covers the queued clip).
//   CHAL   the prompt is queued until the player is free; the window (T_MOUTH /
//          T_BLINK ticks) runs from the moment it is issued.  Liveness:
//            arm    OPEN_N CONSECUTIVE results with the challenge logit BELOW
//                   its threshold, each on a frame recognised at >= THR_LIVE
//            event  armed, then EV_N consecutive results ABOVE it, same
//                   condition.  Counting an event disarms.
//          MOUTH_EV / BLINK_EV events -> PASS (10-12 night, user: one open or
//          one blink passed too easily -- 3 opens / 2 blinks now, and the
//          prompts clip 7 / 8 say so: change both together).  The re-arm is
//          what makes the count mean separate movements: one long open with
//          a few detector drop-outs in it does not reach OPEN_N consecutive
//          closed results (per-frame TPR mouth ~1, blink without glasses
//          0.63 -> 0.37^8 ~ 4e-4 per position), so it stays one event.
//          The arm-then-event order is the anti-photo part: a printed or
//          on-screen face gives a near-constant logit, so it can satisfy one
//          of the two, never both.  The THR_LIVE condition ties the event to
//          the recognised face (a second person cannot do the blinking).
//          Window over: replay the prompt RETRY times (events so far are
//          kept), then COOL.  No result at >= THR_REC for LOST_T ticks: COOL
//          at once.  Both ways into COOL queue CLIP_FAIL.
//   PASS   pass = 1 (system_top: alarm off -- spot and voice --, banner
//          "员工 PASS").  "身份核验通过" is queued on entry.  Held while the
//          staff member is still recognised; LEAVE_T ticks without a result at
//          >= THR_REC -> IDLE.
//   COOL   COOL_T ticks of nothing, so a failed attempt cannot hold the alarm
//          voice off indefinitely (hold_voice is low here once CLIP_FAIL is
//          out), then IDLE.
//   NEAR   (10-24, user; NEAR_SIDE != 0) between IDLE and CHAL.  At REC_ON go
//          here instead and queue "身份核验，请走近" (CLIP_NEAR; not again
//          within NEAR_GAP ticks of the last one).  The challenge starts once
//          NEAR_N consecutive recognised results have side >= NEAR_SIDE and
//          CLIP_NEAR has been issued -- so its prompt queues behind it.  No
//          result at >= THR_REC for LOST_T ticks: back to IDLE, silently (a
//          far staff member is not a failure).  hold_voice is high here.
//          Why (10-24 23:00 video): challenges started at 1.7-3 m, where the
//          eyes are a few pixels; 5 of 8 ended in LOST_T -> "未通过" -> COOL ->
//          re-recognised -> prompt again, the "混乱" the user heard.
//          side = staff_cap's patch side (box width + 1/16, frame pixels).
//          Box width x distance ~ 300 px m (same video, ToF status 00/04),
//          so 2 m ~ 150 px box ~ side 160.  NEAR_SIDE = 0: no NEAR, the
//          10-12 behaviour bit for bit.
//
// GRACE (10-12): the alarm's "please leave" fires the frame a face is boxed;
// recognition needs REC_ON results after that.  Without a grace the staff
// member hears the alarm first and the prompt 2.6 s later.  So while a face is
// up (face_any) and fewer than GRACE_N results have been judged since it came
// (the counter clears with rec_cnt, after IDLE_GAP ticks without a result),
// hold_voice is high too: a stranger's alarm waits GRACE_N results (~0.2 s),
// the staff member's never starts.
//
// hold_voice = grace, CHAL, or a clip of ours is queued or going out.  system_top
// ORs it into alert_ctrl's player_busy: the alarm voice waits (it does not drop --
// see alert_ctrl) while a prompt is due or the person is answering it; the spot
// is not touched until PASS.  The `play` term (10-12 night): CLIP_FAIL leaves
// from COOL / IDLE, where nothing else holds; req_pend clears the clock play
// goes out and the player's busy only rises the clock after, so without it the
// alarm could start in that one clock and be ignored by the player.
//
// VOICE ARBITRATION: play is registered and only issued when player_busy was
// low the clock before, and player_busy must include every other source that
// can start the player in the same clock (vo_play, the mode announcement's
// pending/edge terms) -- the same rule alert_ctrl follows.
//
// Numbers: tools/staff_id/ (eval_nw.py, train_live_q.py).  THR_REC = cos 0.80 in
// Q12 (4096 cos^2): staff 97-99 % per frame on held-out recordings, strangers
// 0; the teammate peaked at cos 0.65, so do not go below 0.70 (2008).
// LTHR_* are q_live.npz "lthr" (export_hex.py prints them): 0.5 % per-frame
// false trigger on the training negatives.  Blink is weak through glasses
// (per-frame TPR ~0.15), good without (0.63) -- hence the blink prompt asks
// for the glasses to come off.
//
// 10-27 (17:12 video: 2 challenges, both LOST_T 4.7 s / 9.3 s in, each then
// "未通过" and the alarm's "警告" 0 s after it).  Offline on the same frames
// (YuNet box -> staff_q golden) the staff member is cos 0.93-0.99 the whole
// time, mouth open and glasses off included; the board read 0.0-0.66 or
// nothing because face_detect's box dropped out (6 s at 1.3 m) or sat low.
//   LOST_LIVE = 1   in a challenge, a result at >= THR_LIVE keeps the face too
//                   (the events already accept those), not only >= THR_REC.
//   FAIL_QUIET      hold_voice stays high this many ticks after CLIP_FAIL is
//                   issued, so the alarm's next clip does not follow it at
//                   once.  Counted from the issue (clip 9 is 1.57 s long).
// Both 0: the 10-24 behaviour bit for bit.  (The box drop-outs themselves are
// bridged in staff_cap, HOLD_FR.)
//
// VERIFY_ALL (10-28, user on the 20:35 video: "我队友 ... 不失能射灯和播报身份核验
// 请走近就给出身份核验未通过的结论").  Before, a face that was not recognised got
// CLIP_FAIL straight from IDLE after GRACE_N results, spot on, and again every
// FAIL_GAP while it stayed (5 times in 75 s, between the alarm's 警告s).  Now
// EVERY face goes through NEAR first -- spot dark (spot_seq near), clip 10
// "身份核验，请走近":
//   * recognised there (rec_cnt reaches REC_ON, counted as in IDLE) -> the
//     normal NEAR -> challenge path;
//   * not recognised VER_T ticks after clip 10 is issued -> CLIP_FAIL, COOL,
//     and that face is done: no second verification until no result has come
//     for STR_REARM ticks (str_done).  The alarm takes over after FAIL_QUIET.
// While verifying, any result keeps the face (lost), not only >= THR_REC.
// 0 = the 10-27 behaviour bit for bit (str_fail from IDLE, FAIL_GAP).
//
// VERIFY_ALL = 2 (10-28 night, user on the 21:54 video: "请走近 ... 后续没有让张嘴
// 啊，直接身份核验失败了").  The stranger gets the SAME visible procedure as the
// staff member: at VER_T, instead of CLIP_FAIL, the liveness challenge starts
// (prompt, the spot's flashes, OSD MOUTH) with `sv` set:
//   * events count without the THR_LIVE condition (it is not the staff face);
//     MOUTH_EV / BLINK_EV of them -> CLIP_FAIL ("you did it, you are still not
//     staff"), never PASS;
//   * window over -> CLIP_FAIL, no retry; any result keeps the face (lost);
//   * recognised meanwhile (REC_ON results >= THR_REC, as in IDLE) -> sv drops,
//     the counts restart, and it is a staff challenge from there.
// Every way out is CLIP_FAIL + COOL + str_done, as at VER_T in mode 1.
// 1 = mode 1 bit for bit (sv never rises).
//
// NV_CLOSE (10-31, user on the 10-30 23:25 video: "通过后 ... 已经再次出现射灯和红框
// 了但是迟迟等不来活体检测播报").  Mode 2 started the stranger's challenge VER_T
// after clip 10 WHEREVER the face was.  A staff member coming back from 3 m is
// not recognised there, so they got the stranger's "请张嘴" at 3 m, the face
// detector lost them for 3 s (LOST_T) -> "未通过" -> COOL -> str_done -- and from
// then on only recognition (8 results at cos >= 0.80) could start anything,
// with the alarm spot on their face.  The video: face at 58 s, "请张嘴" 60.3,
// "未通过" 64.6, the real prompt 71.7, PASS 74.5.  PB_HEAD (10-30) frames
// 1.1-2 m faces, so this got more frequent.
//   NV_CLOSE = 1   the stranger's challenge also waits until the face is close:
//                  NEAR_N consecutive results with side >= NEAR_SIDE (any score;
//                  close_n), as near_go does for the recognised face.  While
//                  far it stays in NEAR (spot dark, 请走近 again every NEAR_GAP,
//                  and it can still be recognised -> the staff path).
//   VER_FAR_T      ticks after clip 10's issue: still unrecognised and never
//                  close -> CLIP_FAIL, COOL, str_done (+ str_far).  120 = 12 s
//                  ~ VER_T + prompt + T_MOUTH, the longest the alarm waited before.
//   FAR_REVERIFY   a face judged by VER_FAR_T (str_far) that later comes close
//                  (close_n in IDLE) is verified once more (rev_go) -- the staff
//                  member who stood far too long gets a real chance up close.
// NV_CLOSE = 0: the 10-28 behaviour bit for bit (VER_FAR_T / FAR_REVERIFY unused).
//
// PASS_MAX_T (10-31 night, user on the 10-31 21:39 video: "pass 后迟迟不结束 pass 状态而
// 不重启活体检测（在我脸近的时候）").  PASS was held as long as the staff member
// was recognised (LEAVE_T only counts ticks WITHOUT a recognised result), so a
// face kept close stayed PASS for good -- 272 s .. 301 s on that video, ended
// only by turning the head away.  Since PB_HEAD (10-30) frames faces out to
// ~2 m, walking away does not end it either.  Now PASS also ends PASS_MAX_T
// ticks after it began; the face is then verified again (IDLE -> NEAR ->
// challenge).  0 = no limit, the 10-31 behaviour bit for bit.
// NEAR_SKIP_CLOSE (same night): a RECOGNISED face that is already close when
// it is recognised does not get clip 10 "身份核验，请走近" -- it goes straight on
// to the challenge prompt (after PASS_MAX_T the staff member is standing right
// there).  The unrecognised face's clip 10 (VERIFY_ALL) is unchanged.  0 = clip
// 10 whatever the distance, the 10-31 behaviour bit for bit.
//
// cos_bcd / cos_v: the latest result as cos x 100, two BCD digits (99 max),
// for the OSD.  isqrt of score * 10000 / 4096, 7 clocks after each result.
// cos_v drops 1 s after the last result.
//
// Time base: one tick = TICK_CLKS clocks (0.1 s at 150 MHz).  Tests shrink it.
//---------------------------------------------------------------------------
`timescale 1ns/1ns

module staff_ctrl #(
parameter integer TICK_CLKS = 15_000_000,
parameter [12:0]  THR_REC   = 13'd2622,     // cos 0.80
parameter [12:0]  THR_LIVE  = 13'd1475,     // cos 0.60
parameter signed [31:0] LTHR_EYE   = 32'sd54470,
parameter signed [31:0] LTHR_MOUTH = 32'sd5290,
parameter integer REC_ON    = 8,
parameter integer GRACE_N   = 12,           // > REC_ON: results judged before the alarm may speak
parameter integer IDLE_GAP  = 5,
parameter integer OPEN_N    = 8,            // consecutive closed results to (re-)arm: 0.13 s at 60/s
parameter integer EV_N      = 2,
parameter integer MOUTH_EV  = 3,            // events to pass -- clip 7 says "三次"
parameter integer BLINK_EV  = 2,            // clip 8 says "两次"
parameter integer T_MOUTH   = 80,           // ticks from the prompt: 1.2 s prompt + ~7 s
parameter integer T_BLINK   = 120,          // 3.0 s prompt + ~9 s (glasses off)
parameter integer RETRY     = 1,
parameter integer LOST_T    = 30,
parameter integer LEAVE_T   = 50,
parameter integer COOL_T    = 50,
parameter integer FAIL_GAP  = 100,          // ticks between two stranger CLIP_FAILs (10 s)
parameter integer CH_MODE   = 0,            // 0 random, 1 mouth only, 2 blink only
parameter [11:0]  NEAR_SIDE = 12'd0,        // 0 = no NEAR state
parameter integer NEAR_N    = 3,
parameter integer NEAR_GAP  = 100,          // ticks between two CLIP_NEARs (10 s)
parameter integer LOST_LIVE = 0,            // 10-27: 1 = THR_LIVE results also reset lost in a challenge
parameter integer FAIL_QUIET = 0,           // 10-27: ticks (<= 255) the alarm voice waits after CLIP_FAIL
parameter integer VERIFY_ALL = 0,           // 10-28: 1 = every face goes through NEAR (needs NEAR_SIDE != 0); 2 = + the stranger's challenge
parameter integer VER_T     = 40,           // 10-28: ticks after clip 10 before "not recognised" (mode 2: before the stranger's prompt) (< 255)
parameter integer STR_REARM = 50,           // 10-28: ticks without a result before a failed face is verified again (< 255)
parameter integer NV_CLOSE  = 0,            // 10-31: 1 = the stranger's challenge waits for the face to be close (see header)
parameter integer VER_FAR_T = 120,          // 10-31: ticks after clip 10: never close -> CLIP_FAIL (< 255)
parameter integer FAR_REVERIFY = 1,         // 10-31: a far-judged face is verified again once it comes close
parameter integer PASS_MAX_T = 0,           // 10-31 night: ticks a PASS lasts at most (<= 255), 0 = no limit
parameter integer NEAR_SKIP_CLOSE = 0,      // 10-31 night: 1 = no clip 10 for a recognised face already close
parameter [3:0]   CLIP_PASS  = 4'd6,
parameter [3:0]   CLIP_MOUTH = 4'd7,
parameter [3:0]   CLIP_BLINK = 4'd8,
parameter [3:0]   CLIP_FAIL  = 4'd9,
parameter [3:0]   CLIP_NEAR  = 4'd10
)(
input  wire        clk,
input  wire        rst_n,
input  wire        en,

input  wire        face_any,               // face_detect shows a face (any slot)
input  wire        res_v,                  // staff_cnn done
input  wire [12:0] score,
input  wire signed [31:0] live0,           // eyes closed
input  wire signed [31:0] live1,           // mouth open
input  wire [11:0] side,                   // the judged patch's side (NEAR)

input  wire        player_busy,
output reg         play,
output reg  [3:0]  clip,
output reg         pass,
output wire        hold_voice,

output reg  [2:0]  state,                  // 0 idle 1 mouth 2 blink 3 pass 4 cool 5 near
output reg  [7:0]  cos_bcd,
output reg         cos_v
);

localparam [2:0] S_IDLE = 3'd0, S_CHM = 3'd1, S_CHB = 3'd2, S_PASS = 3'd3, S_COOL = 3'd4,
                 S_NEAR = 3'd5;

//---------------------------------------------------------------------------
// tick, LFSR
//---------------------------------------------------------------------------
reg [27:0] tick_cnt;
wire       tick = (tick_cnt == TICK_CLKS - 1);
always @(posedge clk or negedge rst_n)
    if (!rst_n)    tick_cnt <= 28'd0;
    else if (tick) tick_cnt <= 28'd0;
    else           tick_cnt <= tick_cnt + 28'd1;

reg [15:0] lfsr;
always @(posedge clk or negedge rst_n)
    if (!rst_n) lfsr <= 16'hACE1;
    else        lfsr <= {lfsr[14:0], lfsr[15] ^ lfsr[13] ^ lfsr[12] ^ lfsr[10]};

//---------------------------------------------------------------------------
// the state machine
//---------------------------------------------------------------------------
wire rec_ok  = (score >= THR_REC);
wire live_ok = (score >= THR_LIVE);
wire in_ch   = (state == S_CHM) || (state == S_CHB);
wire signed [31:0] lv   = (state == S_CHB) ? live0 : live1;
wire signed [31:0] lthr = (state == S_CHB) ? LTHR_EYE : LTHR_MOUTH;
wire lv_on   = (lv >= lthr);

reg [4:0]  rec_cnt;
reg [4:0]  judged;                         // results since the face came (IDLE), saturating
reg [7:0]  gap;                            // ticks since the last result
reg [7:0]  tmr;                            // window / leave / cool timer
reg [7:0]  lost;
reg [3:0]  open_n, ev_n;                   // consecutive closed / open results
reg        armed;
reg [3:0]  ev_cnt;                         // events counted in this challenge
reg [7:0]  fgap;                           // ticks since the last CLIP_FAIL
reg [1:0]  tries;
reg        req_pend;
reg [3:0]  req_clip;
reg [3:0]  near_n;                         // consecutive recognised results at side >= NEAR_SIDE
reg [7:0]  ngap;                           // ticks since the last CLIP_NEAR
reg [7:0]  fq;                             // FAIL_QUIET ticks left
reg        nv;                             // VERIFY_ALL: in NEAR, not recognised yet
reg        str_done;                       // VERIFY_ALL: this face already failed
reg        sv;                             // VERIFY_ALL 2: a stranger's challenge
reg [3:0]  close_n;                        // NV_CLOSE: consecutive results at side >= NEAR_SIDE, any score
reg        str_far;                        // NV_CLOSE: str_done came from VER_FAR_T (judged far away)
reg [7:0]  ptmr;                           // PASS_MAX_T: ticks since the pass

assign hold_voice = in_ch || req_pend || play || (state == S_NEAR) || (fq != 8'd0) ||
                    ((state == S_IDLE) && face_any && (judged < GRACE_N));

wire live_g   = live_ok || sv;              // sv: the events are the stranger's own
wire ev_hit   = res_v && lv_on && live_g && (armed || OPEN_N == 0) && (ev_n + 4'd1 >= EV_N);
wire [3:0] ev_need = (state == S_CHB) ? BLINK_EV[3:0] : MOUTH_EV[3:0];
wire pass_hit = ev_hit && (ev_cnt + 4'd1 >= ev_need) && !sv;
wire sfin_hit = ev_hit && (ev_cnt + 4'd1 >= ev_need) && sv;     // stranger done -> CLIP_FAIL
wire sv_rec   = sv && res_v && rec_ok && (rec_cnt + 5'd1 >= REC_ON);
wire rec_on   = res_v && rec_ok && (rec_cnt + 5'd1 >= REC_ON);
wire str_due  = res_v && face_any && (judged + 5'd1 == GRACE_N) && !rec_on;
wire str_fail = str_due && (VERIFY_ALL == 0) && (fgap >= FAIL_GAP);
wire rev_go   = (NV_CLOSE != 0) && (FAR_REVERIFY != 0) && (VERIFY_ALL == 2) && str_done && str_far &&
                face_any && (close_n >= NEAR_N) && !rec_on;     // IDLE only (used there)
wire ver_go   = (str_due && (VERIFY_ALL != 0) && !str_done) || rev_go;
wire pick_blink = (CH_MODE == 2) ? 1'b1 : (CH_MODE == 1) ? 1'b0 : lfsr[7];
wire [7:0] t_win = (state == S_CHB) ? T_BLINK[7:0] : T_MOUTH[7:0];
wire near_ok  = res_v && rec_ok && (side >= NEAR_SIDE);
wire near_go  = near_ok && (near_n + 4'd1 >= NEAR_N) && !req_pend && !nv;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        state <= S_IDLE; pass <= 1'b0; play <= 1'b0; clip <= 4'd0;
        rec_cnt <= 5'd0; gap <= 8'd0; tmr <= 8'd0; lost <= 8'd0;
        open_n <= 4'd0; ev_n <= 4'd0; tries <= 2'd0;
        armed <= 1'b0; ev_cnt <= 4'd0; fgap <= 8'hff;
        req_pend <= 1'b0; req_clip <= 4'd0; judged <= 5'd0;
        near_n <= 4'd0; ngap <= 8'hff; fq <= 8'd0; nv <= 1'b0; str_done <= 1'b0; sv <= 1'b0;
        close_n <= 4'd0; str_far <= 1'b0; ptmr <= 8'd0;
    end else if (!en) begin
        state <= S_IDLE; pass <= 1'b0; play <= 1'b0;
        rec_cnt <= 5'd0; gap <= 8'd0; tmr <= 8'd0; lost <= 8'd0;
        open_n <= 4'd0; ev_n <= 4'd0; tries <= 2'd0;
        armed <= 1'b0; ev_cnt <= 4'd0; fgap <= 8'hff;
        req_pend <= 1'b0; judged <= 5'd0;
        near_n <= 4'd0; ngap <= 8'hff; fq <= 8'd0; nv <= 1'b0; str_done <= 1'b0; sv <= 1'b0;
        close_n <= 4'd0; str_far <= 1'b0; ptmr <= 8'd0;
    end else begin
        if (tick && gap >= STR_REARM) begin str_done <= 1'b0; str_far <= 1'b0; end  // the face has gone (set below wins)
        // NV_CLOSE: closeness of the face, any score (IDLE's rev_go, NEAR's stranger gate)
        if (NV_CLOSE != 0 && res_v)
            close_n <= (side < NEAR_SIDE) ? 4'd0 : (close_n != 4'd15) ? close_n + 4'd1 : close_n;
        // ---- voice: issue a queued clip when nobody else can start the player
        play <= 1'b0;
        if (tick && fq != 8'd0) fq <= fq - 8'd1;
        if (req_pend && !player_busy && !play) begin
            play     <= 1'b1;
            clip     <= req_clip;
            req_pend <= 1'b0;
            if (req_clip == CLIP_FAIL && FAIL_QUIET != 0) fq <= FAIL_QUIET[7:0];
        end

        if (res_v)              gap <= 8'd0;
        else if (tick && gap != 8'hff) gap <= gap + 8'd1;
        if (tick && fgap != 8'hff) fgap <= fgap + 8'd1;     // a CLIP_FAIL below wins
        if (tick && ngap != 8'hff) ngap <= ngap + 8'd1;     // a CLIP_NEAR below wins

        case (state)
        S_IDLE: begin
            if (tick && gap >= IDLE_GAP) begin rec_cnt <= 5'd0; judged <= 5'd0; end
            if (res_v && judged != 5'd31) judged <= judged + 5'd1;
            if (str_fail) begin
                req_pend <= 1'b1; req_clip <= CLIP_FAIL; fgap <= 8'd0;
            end
            if (ver_go) begin                                // VERIFY_ALL: everyone through NEAR
                state <= S_NEAR; nv <= 1'b1;
                lost  <= 8'd0; near_n <= 4'd0; tmr <= 8'd0;
                if (NV_CLOSE != 0) close_n <= 4'd0;
                if (rev_go) begin str_done <= 1'b0; str_far <= 1'b0; end   // the one re-verification
                if (ngap >= NEAR_GAP) begin
                    req_pend <= 1'b1; req_clip <= CLIP_NEAR; ngap <= 8'd0;
                end
            end
            if (res_v) begin
                if (rec_ok) begin
                    if (rec_cnt + 5'd1 >= REC_ON && NEAR_SIDE != 0) begin
                        state  <= S_NEAR;
                        lost   <= 8'd0; near_n <= 4'd0;
                        rec_cnt <= 5'd0;
                        if (ngap >= NEAR_GAP && !(NEAR_SKIP_CLOSE != 0 && side >= NEAR_SIDE)) begin
                            req_pend <= 1'b1; req_clip <= CLIP_NEAR; ngap <= 8'd0;
                        end else
                            req_pend <= 1'b0;           // a queued stranger CLIP_FAIL was this face
                    end else if (rec_cnt + 5'd1 >= REC_ON) begin
                        state    <= pick_blink ? S_CHB : S_CHM;
                        req_pend <= 1'b1;
                        req_clip <= pick_blink ? CLIP_BLINK : CLIP_MOUTH;
                        tmr <= 8'd0; lost <= 8'd0; open_n <= 4'd0; ev_n <= 4'd0; tries <= 2'd0;
                        armed <= 1'b0; ev_cnt <= 4'd0;
                        rec_cnt  <= 5'd0;
                    end else
                        rec_cnt <= rec_cnt + 5'd1;
                end else
                    rec_cnt <= (rec_cnt > 5'd2) ? rec_cnt - 5'd2 : 5'd0;
            end
        end

        S_CHM, S_CHB: begin
            if (tick) begin
                if (!req_pend && tmr != 8'hff) tmr <= tmr + 8'd1;
                if (lost != 8'hff)             lost <= lost + 8'd1;
            end
            if (res_v && (rec_ok || (LOST_LIVE != 0 && live_ok) || sv)) lost <= 8'd0;
            // VERIFY_ALL 2: the stranger may still be recognised (IDLE's count)
            if (sv && res_v) begin
                if (sv_rec)      rec_cnt <= 5'd0;
                else if (rec_ok) rec_cnt <= rec_cnt + 5'd1;
                else             rec_cnt <= (rec_cnt > 5'd2) ? rec_cnt - 5'd2 : 5'd0;
            end
            if (res_v) begin
                if (!live_g)
                    ev_n <= 4'd0;                       // open_n untouched: not this face
                else if (!lv_on) begin
                    ev_n <= 4'd0;
                    if (open_n != 4'd15) open_n <= open_n + 4'd1;
                    if (open_n + 4'd1 >= OPEN_N) armed <= 1'b1;
                end else begin
                    open_n <= 4'd0;
                    if (ev_n != 4'd15) ev_n <= ev_n + 4'd1;
                    if (ev_hit) begin
                        armed  <= 1'b0;
                        ev_cnt <= ev_cnt + 4'd1;
                    end
                    if (pass_hit) begin
                        state    <= S_PASS;
                        pass     <= 1'b1;
                        req_pend <= 1'b1;               // replaces a prompt not yet issued
                        req_clip <= CLIP_PASS;
                        tmr      <= 8'd0;
                        ptmr     <= 8'd0;
                    end
                end
            end
            // the ways out without a pass; a pass in the same clock wins
            if (sv_rec) begin                       // recognised: a staff challenge from here
                sv <= 1'b0; ev_cnt <= 4'd0; armed <= 1'b0; open_n <= 4'd0; ev_n <= 4'd0;
            end else if (sfin_hit) begin
                state <= S_COOL; tmr <= 8'd0; sv <= 1'b0; str_done <= 1'b1; rec_cnt <= 5'd0;
                req_pend <= 1'b1; req_clip <= CLIP_FAIL; fgap <= 8'd0;
            end else if (!pass_hit) begin
                if (lost >= LOST_T) begin
                    state <= S_COOL; tmr <= 8'd0;
                    req_pend <= 1'b1; req_clip <= CLIP_FAIL; fgap <= 8'd0;   // replaces a prompt
                    if (sv) begin sv <= 1'b0; str_done <= 1'b1; rec_cnt <= 5'd0; end
                end else if (!req_pend && tmr >= t_win) begin
                    if (tries < RETRY && !sv) begin
                        tries    <= tries + 2'd1;
                        tmr      <= 8'd0;
                        req_pend <= 1'b1;
                        req_clip <= (state == S_CHB) ? CLIP_BLINK : CLIP_MOUTH;
                    end else begin
                        state <= S_COOL; tmr <= 8'd0;
                        req_pend <= 1'b1; req_clip <= CLIP_FAIL; fgap <= 8'd0;
                        if (sv) begin sv <= 1'b0; str_done <= 1'b1; rec_cnt <= 5'd0; end
                    end
                end
            end
        end

        S_NEAR: begin
            if (tick && lost != 8'hff) lost <= lost + 8'd1;
            if (res_v && (rec_ok || nv)) lost <= 8'd0;          // verifying: any result is the face
            if (res_v)                 near_n <= !near_ok ? 4'd0 : (near_n != 4'd15) ? near_n + 4'd1 : near_n;
            // VERIFY_ALL: recognise here as IDLE does; the verdict clock runs from clip 10's issue
            if (nv) begin
                if (tick && !req_pend && tmr != 8'hff) tmr <= tmr + 8'd1;
                if (res_v) begin
                    if (rec_ok && rec_cnt + 5'd1 >= REC_ON) begin nv <= 1'b0; rec_cnt <= 5'd0; end
                    else if (rec_ok)                         rec_cnt <= rec_cnt + 5'd1;
                    else rec_cnt <= (rec_cnt > 5'd2) ? rec_cnt - 5'd2 : 5'd0;
                end
            end
            if (near_go) begin
                state    <= pick_blink ? S_CHB : S_CHM;
                req_pend <= 1'b1;
                req_clip <= pick_blink ? CLIP_BLINK : CLIP_MOUTH;
                tmr <= 8'd0; lost <= 8'd0; open_n <= 4'd0; ev_n <= 4'd0; tries <= 2'd0;
                armed <= 1'b0; ev_cnt <= 4'd0;
            end else if (nv && !req_pend && tmr >= VER_T && VERIFY_ALL == 2 &&
                         (NV_CLOSE == 0 || close_n >= NEAR_N)) begin
                // the stranger's challenge (rec_cnt carries on counting in it)
                state    <= pick_blink ? S_CHB : S_CHM;
                req_pend <= 1'b1;
                req_clip <= pick_blink ? CLIP_BLINK : CLIP_MOUTH;
                tmr <= 8'd0; lost <= 8'd0; open_n <= 4'd0; ev_n <= 4'd0; tries <= 2'd0;
                armed <= 1'b0; ev_cnt <= 4'd0; nv <= 1'b0; sv <= 1'b1;
            end else if (nv && !req_pend && NV_CLOSE != 0 && VERIFY_ALL == 2 && tmr >= VER_FAR_T) begin
                // 10-31: never came close -> the far stranger's verdict
                state <= S_COOL; tmr <= 8'd0; nv <= 1'b0; str_done <= 1'b1; str_far <= 1'b1; rec_cnt <= 5'd0;
                req_pend <= 1'b1; req_clip <= CLIP_FAIL; fgap <= 8'd0;
            end else if (nv && !req_pend && tmr >= VER_T && !(NV_CLOSE != 0 && VERIFY_ALL == 2)) begin
                state <= S_COOL; tmr <= 8'd0; nv <= 1'b0; str_done <= 1'b1; rec_cnt <= 5'd0;
                req_pend <= 1'b1; req_clip <= CLIP_FAIL; fgap <= 8'd0;
            end else if (lost >= LOST_T) begin
                state <= S_IDLE; rec_cnt <= 5'd0; judged <= 5'd0; nv <= 1'b0;
            end
        end

        S_PASS: begin
            if (res_v && rec_ok)             tmr <= 8'd0;
            else if (tick && tmr != 8'hff)   tmr <= tmr + 8'd1;
            if (tick && ptmr != 8'hff)       ptmr <= ptmr + 8'd1;
            if (tmr >= LEAVE_T || (PASS_MAX_T != 0 && ptmr >= PASS_MAX_T)) begin
                state <= S_IDLE; pass <= 1'b0; rec_cnt <= 5'd0; judged <= 5'd0;
            end
        end

        default: begin                      // S_COOL
            if (tick && tmr != 8'hff) tmr <= tmr + 8'd1;
            if (tmr >= COOL_T) begin
                state <= S_IDLE; rec_cnt <= 5'd0; judged <= 5'd0;
            end
        end
        endcase
    end
end

//---------------------------------------------------------------------------
// cos x 100 for the OSD: r = isqrt((score * 625) >> 8), one bit per clock
//---------------------------------------------------------------------------
reg  [13:0] sq_v;
reg  [6:0]  sq_r;
reg  [2:0]  sq_b;
reg         sq_run;
reg  [3:0]  age;                            // ticks since the last result
wire [6:0]  sq_t  = sq_r | (7'd1 << sq_b);
wire [13:0] sq_tt = sq_t * sq_t;
wire [6:0]  c99   = (sq_r > 7'd99) ? 7'd99 : sq_r;
wire [6:0]  c_t   = c99 / 7'd10;
wire [6:0]  c_u   = c99 % 7'd10;
wire [23:0] sq_in = {11'd0, score} * 24'd625;     // <= 4096 * 625, then >> 8 <= 10000

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        sq_v <= 14'd0; sq_r <= 7'd0; sq_b <= 3'd0; sq_run <= 1'b0;
        cos_bcd <= 8'd0; cos_v <= 1'b0; age <= 4'd0;
    end else begin
        if (res_v) begin
            sq_v   <= sq_in[21:8];
            sq_r   <= 7'd0;
            sq_b   <= 3'd6;
            sq_run <= 1'b1;
            age    <= 4'd0;
        end else begin
            if (tick && age != 4'd15) age <= age + 4'd1;
            if (sq_run) begin
                if (sq_tt <= sq_v) sq_r <= sq_t;
                if (sq_b == 3'd0) sq_run <= 1'b0;
                else              sq_b   <= sq_b - 3'd1;
            end
        end
        if (!sq_run && !res_v) begin
            cos_bcd <= {c_t[3:0], c_u[3:0]};
            cos_v   <= en && (age < 4'd10);
        end
    end
end

endmodule
