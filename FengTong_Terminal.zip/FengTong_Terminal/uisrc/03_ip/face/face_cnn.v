//---------------------------------------------------------------------------
// face_cnn -- a small INT8 CNN that classifies a whole 32x32 ROI patch as
// face / not-face.  A drop-in for face_cascade: same buffer read port, same
// start/busy/done handshake, same result outputs, so face_detect (mapping,
// NMS, hold, atomic publish) is used unmodified.  system_top picks one of the
// two with FACE_CLS.
//
// WHY IT REPLACES THE CASCADE INSTEAD OF RE-CHECKING ITS ACCEPTS (10-02)
// The board read FACES n>0 / m=0 with a real face in front of the camera:
// candidates arrive, the cascade accepts none.  A second-opinion stage
// downstream of the cascade would have seen exactly nothing.  The cascade's
// accept region is ~1 px wide and ~+-12% in scale (face_detect MIN_NEIGHBORS
// notes), and the ROI framing from a skin blob is not that precise.  A CNN
// trained on patches with the framing jitter of face_roi_buf built in is the
// thing that absorbs it -- that is the whole reason for this module.
//
// WHAT IT COMPUTES is defined, bit for bit, by tools/face_cnn/cnn_ref.py.  Read
// that header first; this file only maps it onto a schedule.
//   norm  : min/max stretch of the patch into m0      (2 x 1024 reads)
//   L1    : m0 (1x32x32)  -> m1 (8x16x16)    conv3x3 + pool + requant
//   L2    : m1            -> m0 (16x8x8)
//   L3    : m0            -> m1 (32x4x4)
//   FC    : m1 (512)      -> 4 outputs: score, box centre x/y, box side
//
// THE BOX HEAD (2026-10-02 evening).  The first version reported the middle
// WIN/BUFN of the ROI as the face, whatever the face did -- the board called
// that "box incomplete": a skin blob that runs face + neck centres the ROI on
// the chin.  Now the FC has four outputs and three of them are the face box in
// patch pixels.  They go through the same requant as a conv channel (the FC
// scales are powers of two, see cnn_ref.py), so the box costs four more lanes
// of the FC that were idle anyway and one decode clock.  face_w is new; with
// face_detect's VAR_W=1 the drawn box is (ox, oy, w) mapped to the frame.
//
// THE SCHEDULE.  Eight output channels are computed side by side (eight 9x8
// multipliers), one input pixel and one 64-bit weight word per clock.  For each
// pooled output and lane group the four pre-pool positions are accumulated one
// after another and only their running MAX is kept -- pooling the raw
// accumulator is exact because bias-add, shift, ReLU and clamp are all monotone
// and the bias is per channel.  So no pre-pool map is ever stored, and the
// requant runs once per pooled output, serially over the eight lanes.
//   clocks/patch ~ 9,216 + 36,864 + 36,864 + 512 MACs, plus ~6 clocks of
//   pipeline drain per pre-pool position, plus 2,048 for norm:  ~100k, i.e.
//   ~4% of a frame per ROI and ~16% for all four.  face_detect has no
//   deadline anyway (it holds the bank swap with rd_busy).
//
// ROMs, all bare-filename $readmemh -- this file MUST stay in uisrc/03_ip/face/
// beside them (memory: readmemh resolves against the caller, and fails silent):
//   cnn_w.hex   729 x 64  conv weights, lane 0 in the low byte   (generated)
//   cnn_wfc.hex 512 x 32  FC weights, output k in byte k         (generated)
//   cnn_b.hex    64 x 32  biases: 56 conv, 4 FC, 4 zero          (generated)
//   cnn_sh.hex   64 x 8   requant shifts, same layout            (generated)
//   cnn_rcp.hex 256 x 16  round(65280/d) for the stretch         (fixed)
// The generated four come from tools/face_cnn/train_export.py.  Retraining is
// "replace the four files and rebuild" -- nothing in this file changes.  After
// synthesis, grep the log for readmem: a missing file is an all-zero ROM, and
// an all-zero ROM is a classifier that says "no face" forever, which on the
// board looks exactly like a recall problem.
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module face_cnn #(
parameter integer BUFN  = 32,
parameter integer BUFAW = 12,                // {roi[1:0], row[4:0], col[4:0]}
parameter integer WIN   = 24,                // face_w's reset value only

// Decision threshold on the integer logit.  train_export.py bakes its chosen
// operating point into the FC bias, so 0 here IS that point; report.txt says
// how many logit units one unit of float logit is, for moving it on the board.
parameter signed [31:0] THR = 32'sd0
)(
input  wire        clk,
input  wire        rst_n,

output reg  [BUFAW-1:0] buf_ra,
input  wire [7:0]       buf_q,              // one clock after buf_ra

input  wire        start,
input  wire [1:0]  roi_sel,
output reg         busy,
output reg         done,                    // one clock

// The face box in patch pixels: top-left (face_ox, face_oy), side face_w.  It
// may run past the patch's far edge (ox + w > 32) when the face does;
// face_detect maps it with the same scl() either way.
output reg         face_found,
output reg  [5:0]  face_ox,
output reg  [5:0]  face_oy,
output reg  [5:0]  face_w,
// Confidence 1..15 when found (the rounded float logit + 1), 0 when not.
// face_detect's NMS_SCORE keeps the higher of two overlapping boxes by this.
output reg  [3:0]  face_nacc,
output reg  signed [31:0] score             // the integer logit, for debug
);

localparam [5:0] OFS = (BUFN - WIN) / 2;

//---------------------------------------------------------------------------
// ROMs and the two feature-map RAMs
//---------------------------------------------------------------------------
reg [63:0] w_rom   [0:728];
reg [31:0] wfc_rom [0:511];
reg [31:0] b_rom   [0:63];
reg [7:0]  sh_rom  [0:63];
reg [15:0] rcp_rom [0:255];

initial begin
    $readmemh("cnn_w.hex",   w_rom);
    $readmemh("cnn_wfc.hex", wfc_rom);
    $readmemh("cnn_b.hex",   b_rom);
    $readmemh("cnn_sh.hex",  sh_rom);
    $readmemh("cnn_rcp.hex", rcp_rom);
end

reg  [9:0]  w_ra;
reg  [8:0]  wfc_ra;
reg  [5:0]  b_ra;
reg  [7:0]  d_r;                            // mx - mn, the rcp address
reg  [63:0] w_q;
reg  [31:0] wfc_q;
reg  [31:0] b_q;
reg  [7:0]  sh_q;
reg  [15:0] rcp_q;

always @(posedge clk) begin
    w_q   <= w_rom[w_ra];
    wfc_q <= wfc_rom[wfc_ra];
    b_q   <= b_rom[b_ra];
    sh_q  <= sh_rom[b_ra];
    rcp_q <= rcp_rom[d_r];
end

// m0: normalised input (1x32x32), later L2's output (16x8x8).
// m1: L1's output (8x16x16), later L3's output (32x4x4).
// Layout everywhere is c*H*W + y*W + x, i.e. torch's (C, H, W).
reg [7:0]  m0 [0:1023];
reg [7:0]  m1 [0:2047];
reg [10:0] fm_ra;
reg [7:0]  m0_q, m1_q;
reg        m0_we, m1_we;
reg [10:0] m_wa;
reg [7:0]  m_wd;

always @(posedge clk) begin
    m0_q <= m0[fm_ra[9:0]];
    m1_q <= m1[fm_ra];
    if (m0_we) m0[m_wa[9:0]] <= m_wd;
    if (m1_we) m1[m_wa]      <= m_wd;
end

//---------------------------------------------------------------------------
// FSM
//---------------------------------------------------------------------------
localparam [3:0] S_IDLE = 4'd0,
                 S_MM   = 4'd1,     // read the patch once: min and max
                 S_MMW  = 4'd2,
                 S_RCP  = 4'd3,     // d_r -> rcp_q
                 S_RCPW = 4'd4,
                 S_NRM  = 4'd5,     // read it again: stretch into m0
                 S_NRMW = 4'd6,
                 S_MAC  = 4'd7,     // issue one pre-pool position (or the FC)
                 S_DRN  = 4'd8,     // wait for its last product to land
                 S_RQ   = 4'd9,     // requant the eight lanes into the next map
                 S_RQW  = 4'd10,
                 S_FIN  = 4'd11;

reg [3:0]  st;
reg [1:0]  roi;
reg [9:0]  n;                       // patch pixel index, also the FC input index
reg [7:0]  mn, mx;
reg [3:0]  wcnt;

reg [1:0]  lay;                     // 0..2 conv, 3 FC
reg [1:0]  g;                       // lane group
reg [3:0]  py, px;                  // pooled output position
reg [1:0]  s;                       // pre-pool position within the 2x2
reg [3:0]  ic;
reg [1:0]  ky, kx;
reg [9:0]  wptr, wgrp;
reg [2:0]  j;                       // requant lane

// Per-layer shape.  wgrp needs no base table: the weight words are laid out
// layer by layer, group by group, so it only ever adds wper.
reg [3:0]  cin_m1;
reg [1:0]  ng_m1;
reg [3:0]  pw_m1;
reg [5:0]  cbase;
reg [7:0]  wper;

always @(*) begin
    case (lay)
    2'd0:    begin cin_m1 = 4'd0;  ng_m1 = 2'd0; pw_m1 = 4'd15; cbase = 6'd0;  wper = 8'd9;   end
    2'd1:    begin cin_m1 = 4'd7;  ng_m1 = 2'd1; pw_m1 = 4'd7;  cbase = 6'd8;  wper = 8'd72;  end
    default: begin cin_m1 = 4'd15; ng_m1 = 2'd3; pw_m1 = 4'd3;  cbase = 6'd24; wper = 8'd144; end
    endcase
end

// The input pixel this clock's MAC wants.  iy/ix run from -1 to H, carried as
// 6-bit signed; out of range reads as the zero padding.  Every map is a power
// of two on a side, so the address is a per-layer bit concatenation -- no
// variable shifts and no adders in front of the RAM, deliberately: this sits in
// pclkx1, whose slack is measured in tenths of a nanosecond.
wire [4:0]        y_c  = {py, s[1]};
wire [4:0]        x_c  = {px, s[0]};
wire signed [5:0] iy   = $signed({1'b0, y_c}) + $signed({4'b0000, ky}) - 6'sd1;
wire signed [5:0] ix   = $signed({1'b0, x_c}) + $signed({4'b0000, kx}) - 6'sd1;
reg               inb;
reg  [10:0]       ain;
always @(*) begin
    case (lay)
    2'd0:    begin inb = !iy[5] && !ix[5];                       ain = {1'b0, iy[4:0], ix[4:0]};           end
    2'd1:    begin inb = !iy[5] && !ix[5] && !iy[4] && !ix[4];   ain = {ic[2:0], iy[3:0], ix[3:0]};       end
    default: begin inb = (iy[5:3] == 3'b000) && (ix[5:3] == 3'b000); ain = {1'b0, ic[3:0], iy[2:0], ix[2:0]}; end
    endcase
end

// Where requant writes lane j of the current pooled output, same idea.
reg  [10:0]       aout;
always @(*) begin
    case (lay)
    2'd0:    aout = {rq_j1, py[3:0], px[3:0]};                    // 8 x 16 x 16
    2'd1:    aout = {1'b0, g[0], rq_j1, py[2:0], px[2:0]};       // 16 x 8 x 8
    default: aout = {2'b00, g[1:0], rq_j1, py[1:0], px[1:0]};     // 32 x 4 x 4
    endcase
end

wire mac_first = (lay == 2'd3) ? (n == 10'd0)   : ((ic == 4'd0) && (ky == 2'd0) && (kx == 2'd0));
wire mac_last  = (lay == 2'd3) ? (n == 10'd511) : ((ic == cin_m1) && (ky == 2'd2) && (kx == 2'd2));

//---------------------------------------------------------------------------
// Datapath pipelines.  Stage numbers count clocks after the counters.
//---------------------------------------------------------------------------
// patch read (norm passes)
reg        rd_v1, rd_v2;
reg [9:0]  rd_n1, rd_n2;
reg        nm_vd, nm_v3;
reg [9:0]  nm_nd, nm_n3;
reg [7:0]  nm_d;
reg [23:0] nm_p;

// MAC
reg        p1_v, p1_inb, p1_first, p1_last;
reg        p2_v, p2_inb, p2_first, p2_last;
reg        p3_v, p3_first, p3_last;
reg        p4_v, p4_first, p4_last;
reg        p5_last;
reg signed [8:0]  a_r;
reg        [63:0] w_r;
reg signed [16:0] prod [0:7];
reg signed [31:0] acc  [0:7];
reg signed [31:0] pmx  [0:7];       // running max over the 2x2

// requant
reg        rq_v1, rq_v3, rq_v4, rq_v5;
reg [2:0]  rq_j1, rq_j3, rq_j4, rq_j5;
reg [10:0] rq_a3, rq_a4, rq_a5;
reg signed [31:0] rq_x, rq_t, rq_r;
reg [4:0]  rq_s3, rq_s4;

wire [7:0] fm_q = lay[0] ? m1_q : m0_q;     // lay 0,2 read m0; 1,3 read m1

// FC results.  fc_v0 is the raw score (lane 0 before its shift); fc_r[k] is
// lane k after requant, i.e. cnn_ref's r_k.
reg signed [31:0] fc_v0;
reg [7:0]  fc_r [0:3];
wire [7:0] rq_c = rq_r[31] ? 8'd0 : (|rq_r[30:8]) ? 8'd255 : rq_r[7:0];

// S_FIN's decode, cnn_ref.decode: w = clamp(r3, 4, 40); o = clamp(r - w/2, 0, 31).
// The ceilings are what keep face_detect's frame coordinates inside 12 bits: a
// box that starts inside the ROI and is at most 1.25 ROI wide ends below 3216.
wire [5:0] dec_w  = (fc_r[3] < 8'd4) ? 6'd4 : (fc_r[3] > 8'd40) ? 6'd40 : fc_r[3][5:0];
wire signed [9:0] dec_xs = $signed({2'b00, fc_r[1]}) - $signed({5'd0, dec_w[5:1]});
wire signed [9:0] dec_ys = $signed({2'b00, fc_r[2]}) - $signed({5'd0, dec_w[5:1]});
wire [5:0] dec_ox = dec_xs[9] ? 6'd0 : (dec_xs > 10'sd31) ? 6'd31 : dec_xs[5:0];
wire [5:0] dec_oy = dec_ys[9] ? 6'd0 : (dec_ys > 10'sd31) ? 6'd31 : dec_ys[5:0];
wire [3:0] dec_cf = (fc_r[0] > 8'd14) ? 4'd15 : (fc_r[0][3:0] + 4'd1);

integer i;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        st <= S_IDLE; busy <= 1'b0; done <= 1'b0;
        face_found <= 1'b0; face_ox <= OFS; face_oy <= OFS; face_w <= WIN[5:0]; face_nacc <= 4'd0;
        fc_v0 <= 32'sd0;
        for (i = 0; i < 4; i = i + 1) fc_r[i] <= 8'd0;
        score <= 32'sd0;
        buf_ra <= {BUFAW{1'b0}};
        roi <= 2'd0; n <= 10'd0; mn <= 8'hFF; mx <= 8'h00; wcnt <= 4'd0;
        lay <= 2'd0; g <= 2'd0; py <= 4'd0; px <= 4'd0; s <= 2'd0;
        ic <= 4'd0; ky <= 2'd0; kx <= 2'd0; wptr <= 10'd0; wgrp <= 10'd0; j <= 3'd0;
        w_ra <= 10'd0; wfc_ra <= 9'd0; b_ra <= 6'd0; d_r <= 8'd0;
        fm_ra <= 11'd0; m0_we <= 1'b0; m1_we <= 1'b0; m_wa <= 11'd0; m_wd <= 8'd0;
        rd_v1 <= 1'b0; rd_v2 <= 1'b0; rd_n1 <= 10'd0; rd_n2 <= 10'd0;
        nm_vd <= 1'b0; nm_nd <= 10'd0; nm_d <= 8'd0;
        nm_v3 <= 1'b0; nm_n3 <= 10'd0; nm_p <= 24'd0;
        p1_v <= 1'b0; p1_inb <= 1'b0; p1_first <= 1'b0; p1_last <= 1'b0;
        p2_v <= 1'b0; p2_inb <= 1'b0; p2_first <= 1'b0; p2_last <= 1'b0;
        p3_v <= 1'b0; p3_first <= 1'b0; p3_last <= 1'b0;
        p4_v <= 1'b0; p4_first <= 1'b0; p4_last <= 1'b0;
        p5_last <= 1'b0;
        a_r <= 9'sd0; w_r <= 64'd0;
        rq_v1 <= 1'b0; rq_v3 <= 1'b0; rq_v4 <= 1'b0; rq_v5 <= 1'b0;
        rq_j1 <= 3'd0; rq_j3 <= 3'd0; rq_j4 <= 3'd0; rq_j5 <= 3'd0; rq_a3 <= 11'd0; rq_a4 <= 11'd0; rq_a5 <= 11'd0;
        rq_x <= 32'sd0; rq_t <= 32'sd0; rq_r <= 32'sd0; rq_s3 <= 5'd0; rq_s4 <= 5'd0;
        for (i = 0; i < 8; i = i + 1) begin
            prod[i] <= 17'sd0; acc[i] <= 32'sd0; pmx[i] <= 32'sd0;
        end
    end else begin
        done  <= 1'b0;
        m0_we <= 1'b0;
        m1_we <= 1'b0;

        //-------------------------------------------------------------------
        // [norm] patch read pipe: buf_ra at +1, buf_q at +2.
        //-------------------------------------------------------------------
        rd_v1 <= (st == S_MM) || (st == S_NRM);
        rd_n1 <= n;
        rd_v2 <= rd_v1;
        rd_n2 <= rd_n1;

        if (rd_v2 && (st == S_MM || st == S_MMW)) begin
            if (buf_q < mn) mn <= buf_q;
            if (buf_q > mx) mx <= buf_q;
        end

        // (q - mn) * rcp, then +128 >> 8.  q >= mn by construction, and
        // (q-mn)*rcp <= d*round(65280/d) < 65408, so the result is <= 255 and
        // the clamp below is belt and braces, kept so it matches cnn_ref.
        // The subtract gets its own clock: buf_q arrives through
        // face_roi_buf's 4:1 bank mux, and mux + subtract + 8x16 multiply in
        // one pclkx1 cycle is not a bet worth making.
        nm_vd <= rd_v2 && (st == S_NRM || st == S_NRMW);
        nm_nd <= rd_n2;
        nm_d  <= buf_q - mn;
        nm_v3 <= nm_vd;
        nm_n3 <= nm_nd;
        nm_p  <= nm_d * rcp_q;
        if (nm_v3) begin
            m0_we <= 1'b1;
            m_wa  <= {1'b0, nm_n3};
            m_wd  <= (nm_p[23:8] + {15'd0, nm_p[7]} > 16'd255) ? 8'd255 : (nm_p[15:8] + {7'd0, nm_p[7]});
        end

        //-------------------------------------------------------------------
        // [mac] stage 1: addresses.  stage 2: RAM/ROM out.  stage 3: operand
        // select.  stage 4: multiply.  stage 5: accumulate.
        //-------------------------------------------------------------------
        p1_v     <= (st == S_MAC);
        p1_inb   <= (lay == 2'd3) ? 1'b1 : inb;
        p1_first <= mac_first;
        p1_last  <= mac_last;
        fm_ra    <= (lay == 2'd3) ? {1'b0, n} : ain;
        w_ra     <= wptr;
        wfc_ra   <= n[8:0];

        p2_v <= p1_v; p2_inb <= p1_inb; p2_first <= p1_first; p2_last <= p1_last;

        // L1's input is x - 128; later layers' activations are uint8.  The
        // padding is zero in THAT signed domain, which is what torch's
        // padding=1 does to an input that was centred before the conv.
        a_r <= !p2_inb ? 9'sd0 :
               (lay == 2'd0) ? ($signed({1'b0, fm_q}) - 9'sd128) : $signed({1'b0, fm_q});
        w_r <= (lay == 2'd3) ? {32'd0, wfc_q} : w_q;
        p3_v <= p2_v; p3_first <= p2_first; p3_last <= p2_last;

        for (i = 0; i < 8; i = i + 1)
            prod[i] <= a_r * $signed(w_r[i*8 +: 8]);
        p4_v <= p3_v; p4_first <= p3_first; p4_last <= p3_last;

        if (p4_v)
            for (i = 0; i < 8; i = i + 1)
                acc[i] <= p4_first ? {{15{prod[i][16]}}, prod[i]}
                                   : acc[i] + {{15{prod[i][16]}}, prod[i]};
        p5_last <= p4_v && p4_last;

        //-------------------------------------------------------------------
        // [requant] b_ra IS the address register (it counts in S_RQ), so b_q
        // and sh_q line up with rq_v1 -- one stage earlier than the MAC's w_q,
        // whose address goes through w_ra first.  1: ROM out.  3: + bias.
        // 4: + rounding.  5: shift.  6: clamp, write.  The shift and the clamp
        // are separate clocks because a 32-bit barrel shifter into a 23-input
        // OR is too deep for pclkx1.
        //-------------------------------------------------------------------
        rq_v1 <= (st == S_RQ);
        rq_j1 <= j;

        rq_v3 <= rq_v1;
        rq_j3 <= rq_j1;
        rq_x  <= pmx[rq_j1] + $signed(b_q);
        rq_s3 <= sh_q[4:0];
        rq_a3 <= aout;

        rq_v4 <= rq_v3;
        rq_j4 <= rq_j3;
        rq_t  <= rq_x + ((rq_s3 == 5'd0) ? 32'sd0 : (32'sd1 <<< (rq_s3 - 5'd1)));
        rq_s4 <= rq_s3;
        rq_a4 <= rq_a3;

        rq_v5 <= rq_v4;
        rq_j5 <= rq_j4;
        rq_r  <= rq_t >>> rq_s4;
        rq_a5 <= rq_a4;

        // The FC pass goes through the same pipe but lands in registers.
        if (rq_v3 && (lay == 2'd3) && (rq_j3 == 3'd0))
            fc_v0 <= rq_x;
        if (rq_v5 && (lay == 2'd3) && !rq_j5[2])
            fc_r[rq_j5[1:0]] <= rq_c;

        if (rq_v5 && (lay != 2'd3)) begin
            if (lay[0]) m0_we <= 1'b1;      // L2 writes m0
            else        m1_we <= 1'b1;      // L1, L3 write m1
            m_wa <= rq_a5;
            m_wd <= rq_c;
        end

        //-------------------------------------------------------------------
        case (st)
        S_IDLE: begin
            if (start) begin
                roi        <= roi_sel;
                busy       <= 1'b1;
                face_found <= 1'b0;
                face_nacc  <= 4'd0;
                n          <= 10'd0;
                mn         <= 8'hFF;
                mx         <= 8'h00;
                st         <= S_MM;
            end
        end

        S_MM, S_NRM: begin
            buf_ra <= {roi, n};
            n      <= n + 10'd1;
            if (n == 10'd1023) begin
                wcnt <= 4'd0;
                st   <= (st == S_MM) ? S_MMW : S_NRMW;
            end
        end

        S_MMW: begin
            wcnt <= wcnt + 4'd1;
            if (wcnt == 4'd3) st <= S_RCP;
        end

        S_RCP: begin
            d_r  <= mx - mn;
            wcnt <= 4'd0;
            st   <= S_RCPW;
        end

        S_RCPW: begin                       // d_r -> rcp_q is one ROM clock
            wcnt <= wcnt + 4'd1;
            if (wcnt == 4'd1) begin
                n  <= 10'd0;
                st <= S_NRM;
            end
        end

        S_NRMW: begin                       // last m0 write lands at +5; MAC first reads m0 at +9
            wcnt <= wcnt + 4'd1;
            if (wcnt == 4'd6) begin
                lay <= 2'd0; g <= 2'd0; py <= 4'd0; px <= 4'd0; s <= 2'd0;
                ic <= 4'd0; ky <= 2'd0; kx <= 2'd0;
                wptr <= 10'd0; wgrp <= 10'd0;
                st <= S_MAC;
            end
        end

        S_MAC: begin
            if (lay == 2'd3) begin
                n <= n + 10'd1;
                if (n == 10'd511) st <= S_DRN;
            end else begin
                wptr <= wptr + 10'd1;
                if (kx == 2'd2) begin
                    kx <= 2'd0;
                    if (ky == 2'd2) begin
                        ky <= 2'd0;
                        if (ic == cin_m1) begin
                            ic <= 4'd0;
                            st <= S_DRN;
                        end else
                            ic <= ic + 4'd1;
                    end else
                        ky <= ky + 2'd1;
                end else
                    kx <= kx + 2'd1;
            end
        end

        S_DRN: begin
            if (p5_last) begin
                if (lay == 2'd3) begin
                    // No pooling on the FC: the four sums go to requant as-is.
                    for (i = 0; i < 8; i = i + 1)
                        pmx[i] <= acc[i];
                    j    <= 3'd0;
                    b_ra <= 6'd56;
                    st   <= S_RQ;
                end else begin
                    for (i = 0; i < 8; i = i + 1)
                        if (s == 2'd0 || acc[i] > pmx[i]) pmx[i] <= acc[i];
                    if (s == 2'd3) begin
                        j  <= 3'd0;
                        b_ra <= cbase + {1'b0, g, 3'b000};
                        st <= S_RQ;
                    end else begin
                        s    <= s + 2'd1;
                        wptr <= wgrp;
                        st   <= S_MAC;
                    end
                end
            end
        end

        S_RQ: begin
            j    <= j + 3'd1;
            b_ra <= b_ra + 6'd1;
            if (j == 3'd7) begin
                wcnt <= 4'd0;
                st   <= S_RQW;
            end
        end

        S_RQW: begin                        // last lane's write lands at +6
            wcnt <= wcnt + 4'd1;
            if (wcnt == 4'd6 && lay == 2'd3) begin
                st <= S_FIN;
            end else if (wcnt == 4'd6) begin
                s <= 2'd0;
                if (px != pw_m1) begin
                    px <= px + 4'd1; wptr <= wgrp; st <= S_MAC;
                end else if (py != pw_m1) begin
                    px <= 4'd0; py <= py + 4'd1; wptr <= wgrp; st <= S_MAC;
                end else begin
                    px <= 4'd0; py <= 4'd0;
                    wgrp <= wgrp + {2'd0, wper};
                    wptr <= wgrp + {2'd0, wper};
                    if (g != ng_m1) begin
                        g <= g + 2'd1;
                    end else begin
                        g   <= 2'd0;
                        lay <= lay + 2'd1;
                        if (lay == 2'd2)
                            n <= 10'd0;
                    end
                    st <= S_MAC;
                end
            end
        end

        S_FIN: begin
            score      <= fc_v0;
            face_found <= fc_v0 > THR;
            face_nacc  <= (fc_v0 > THR) ? dec_cf : 4'd0;
            face_ox    <= dec_ox;
            face_oy    <= dec_oy;
            face_w     <= dec_w;
            busy       <= 1'b0;
            done       <= 1'b1;
            st         <= S_IDLE;
        end

        default: st <= S_IDLE;
        endcase
    end
end

endmodule
