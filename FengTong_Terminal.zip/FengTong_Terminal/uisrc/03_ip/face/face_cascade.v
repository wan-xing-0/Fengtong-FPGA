//---------------------------------------------------------------------------
// face_cascade -- OpenCV LBP frontal-face cascade, evaluated on one 32x32 ROI
// at a time.  This is the classifier half of the face detector; face_skin and
// face_roi_sel produce the candidate boxes and face_roi_buf samples the pixels.
//
// WHY LBP AND NOT HAAR
// The plan of record (HANDOFF 6.7) said Viola-Jones/Haar.  Same family, but the
// LBP cascade in OpenCV's tree is 20 stages / 139 weak classifiers / 136 feature
// rectangles, against 25 stages / 2913 features for haarcascade_frontalface.
// Twenty times less ROM and twenty times less work per window, the same zero-DSP
// arithmetic (adds, subtracts and compares only), and OpenCV ships it trained.
// Nothing else about the plan changes.
//
// WHERE THIS SITS -- THE HARD CONSTRAINT
// This is a SIDE BRANCH.  It never touches the pixel path.  pclkx1 has ~0.1ns of
// setup margin (section 5.2), so the rule from the L5 detect layer applies
// unchanged: tap the pixel stream read-only, compute out of band, hand back only
// box coordinates.  The only pixel-domain logic the face feature adds anywhere
// lives in face_skin (a threshold, same shape as det_binarize) and face_roi_buf
// (a write-only sampler).  This module talks to nothing but its own RAMs and ROMs.
//
// AND IT DOES NOT RUN IN THE BLANKING INTERVAL EITHER
// The other lesson of section 3.-8: `vs` is a 5-line sync pulse, so the frame-end
// window is ~11,000 clocks, not the ~99,000 everything used to assume.  A full
// ROI scan is ~24,000 clocks, so it would not fit and would be silently
// truncated -- exactly the failure that starved ccl_blob's publish pass.
// Instead this runs during the VISIBLE part of the next frame, where 2.47M clocks
// go spare, reading face_roi_buf's completed snapshot of the previous frame.
// Nothing here is rate-coupled to the video.
//
// COST -- MEASURED, not estimated (fctb prints it)
//   worst ROI in the bench      6,416 clocks
//   4 ROIs                     25,664 clocks, ~1% of a 2.47M-clock frame
//   The arithmetic bound is far higher (9 positions x 139 weaks x 19 clocks +
//   3,140 to build the integral image = ~27,000 per ROI) and it is never
//   approached, because the cascade rejects most windows in the first two or
//   three stages -- which is the entire point of a cascade.
//   There is no attempt to squeeze these numbers.  Spending 19 clocks on a weak
//   classifier that could take 6 buys a state machine where every RAM read is a
//   separate state, and that is the right trade in a design with 0.1ns of margin
//   and a whole frame of idle time.  The 1% figure is also the headroom argument
//   for adding scales later: see face_roi_buf.v on power-of-two ROI snapping.
//
// ARITHMETIC
// One LBP feature is a 3x3 grid of equal blocks.  Each of the 8 outer block sums
// is compared against the centre block sum; the 8 results pack into a code, the
// code selects a bit out of a 256-bit subset, and that bit picks one of two leaf
// values to add to the stage accumulator.  A stage rejects when its accumulator
// lands below the stage threshold.  Leaves and thresholds are Q8.8; the
// quantisation was measured against float on 11,025 real windows and changed
// NOTHING -- see tools/gen_lbp_rom.py.
//
// THE FOUR ROMs ARE GENERATED -- edit tools/gen_lbp_rom.py, never the hex.  That
// script also cross-checks a from-scratch reimplementation of this algorithm
// against cv2.CascadeClassifier itself on a real face, which is the only way to
// catch a wrong LBP bit order: a testbench comparing this RTL against my own
// Python would happily agree on the same mistake.
//
// $readmemh uses bare filenames, per the note in osd_font_rom.v: TD resolves them
// against the calling file's directory and a FAILED LOAD IS COMPLETELY SILENT.
// After synthesis grep the log for readmem; the only expected hit is the DDR IP's
// HDL-5105.  fctb asserts the ROMs are non-empty for the same reason.
//
// EVERY RAM READ TAKES A STATE, AND THAT IS DELIBERATE
// All the memories here are synchronous-read: an address registered at the end of
// cycle n returns data at the end of cycle n+1, so the data is usable in cycle
// n+2, not n+1.  The first draft of this module collapsed those waits in three
// places (weak_q, rect_q and ii_qb) and every one of them would have read stale
// data.  Hence S_W1/S_W3/S_SUB1 below, which look like they do nothing and are
// load-bearing.  A FOURTH one (S_STG0, for stage_ra) was missing from the first
// draft too, and its symptom is worth knowing because it does not look like a
// timing bug: stage 0 was fine (stage_ra is 0 out of reset) and every stage
// after it ran the PREVIOUS stage's weak classifiers, which reads as an
// off-by-one in the stage counter.  If you merge a state, re-run fctb -- it
// fails loudly on all four.
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module face_cascade #(
// Geometry.  BUFN/WIN/STEP give (BUFN-WIN)/STEP+1 = 3 positions per axis.
parameter integer BUFN   = 32,
parameter integer WIN    = 24,
parameter integer STEP   = 4,

// Cascade shape; must match the generated hex files.  ftb checks these against
// the file line counts, because a short $readmemh is silent.
parameter integer NSTAGE = 20,
parameter integer NWEAK  = 139,
parameter integer NRECT  = 136,

// Derived.  Verilog-2001 cannot compute these in a port list.
parameter integer IIW    = BUFN + 1,               // 33 columns
parameter integer IIN    = (BUFN + 1) * (BUFN + 1),// 1089 entries
parameter integer IIAW   = 11,                     // clog2(1089)
parameter integer IIDW   = 18,                     // 32*32*255 = 261,120
parameter integer BUFAW  = 12                      // {roi[1:0], row[4:0], col[4:0]}
)(
input  wire        clk,
input  wire        rst_n,

// ROI pixel buffer, read-only.
output reg  [BUFAW-1:0] buf_ra,
input  wire [7:0]       buf_q,

// Job interface.  Pulse `start` with an ROI index; `busy` falls when the whole
// 9-position scan has finished.
input  wire        start,
input  wire [1:0]  roi_sel,
output reg         busy,
output reg         done,           // one clock, after the last window

// Result for the ROI as a whole.
output reg         face_found,
output reg  [5:0]  face_ox,        // slide offset of the first accepting window
output reg  [5:0]  face_oy,

// HOW MANY of the NPOS2 windows accepted, not just whether any did.
//
// ⭐ WHAT THIS NUMBER IS ACTUALLY WORTH -- MEASURED, 09-19 late, and it is NOT
// what OpenCV's minNeighbors default suggests.
//
// The plan when this port was added was to require several accepting windows
// before publishing, the way cv2.detectMultiScale requires minNeighbors=3.
// Running lbpcascade_frontalface's own golden model over the two faces it
// accepts in the test image, at one-pixel steps across the full 9x9 slide
// range, gives:
//
//     face A:  1 accepting window out of 81
//     face B:  3 accepting windows out of 81
//
// So a real face here produces ONE to THREE accepts, not a cluster.  This
// cascade is 20 stages and 139 weak classifiers -- a tenth the size of the
// Haar alternative -- and its accept region is about a pixel wide.  A
// threshold of 2 would have rejected face A outright: half the true positives,
// thrown away to suppress false ones.
//
// cv2 gets away with 3 because detectMultiScale sweeps DOZENS of scale rungs
// at 1.1x each, so a true face accepts at many (scale, position) pairs and the
// neighbours come from the SCALE axis.  This design has two rungs at 1.25x.
// The evidence density is an order of magnitude lower and the OpenCV default
// does not transfer.
//
// The count is still exported, and face_detect still pools and thresholds it,
// because it is the only instrumentation that can answer "how much agreement
// do real faces actually get on the board" -- see MIN_NEIGHBORS there, which
// is set to 1 for the reason above.  Reading it on the OSD is how the next
// session finds out whether that can ever be raised.
//
// Saturating at 15: the internal counter is 8-bit because 81 windows can in
// principle all accept, but the consumers and the OSD's one character cell are
// 4-bit, and the measurements above say the real values are single digits.
output reg  [3:0]  face_nacc,

// Per-window result, one pulse per window position.  Only the bench consumes
// these, and they are what lets it compare against OpenCV window by window
// rather than only on the aggregate.
output reg         win_done,
output reg         win_accept,
output reg  [4:0]  win_stages,     // stages passed; NSTAGE means accepted
output reg  [7:0]  win_code        // last LBP code evaluated
);

localparam integer NPOS  = (BUFN - WIN) / STEP + 1;      // 3
localparam integer NPOS2 = NPOS * NPOS;                  // 9

//---------------------------------------------------------------------------
// [1] The generated cascade, in four ROMs.
//
// subset is the big one and the only one that wants a block RAM: indexed by
// {weak, code[7:5]} it costs one 32-bit read instead of hauling all 256 bits of
// a weak classifier's subset around.  code[4:0] then picks the bit.  That split
// is what makes the lookup cheap.
//---------------------------------------------------------------------------
reg [19:0] rect_rom   [0:NRECT-1];       // {x[4:0], y[4:0], w[4:0], h[4:0]}
reg [39:0] weak_rom   [0:NWEAK-1];       // {feat[7:0], leaf0[15:0], leaf1[15:0]}
reg [31:0] subset_rom [0:NWEAK*8-1];
reg [31:0] stage_rom  [0:NSTAGE-1];      // {wstart[7:0], wcount[7:0], thr[15:0]}

initial begin
    $readmemh("lbp_rect.hex",   rect_rom);
    $readmemh("lbp_weak.hex",   weak_rom);
    $readmemh("lbp_subset.hex", subset_rom);
    $readmemh("lbp_stage.hex",  stage_rom);
end

reg [19:0] rect_q;
reg [39:0] weak_q;
reg [31:0] subset_q;
reg [31:0] stage_q;

reg  [7:0]  rect_ra;
reg  [7:0]  weak_ra;
reg  [10:0] subset_ra;
reg  [4:0]  stage_ra;

always @(posedge clk) begin
    rect_q   <= rect_rom[rect_ra];
    weak_q   <= weak_rom[weak_ra];
    subset_q <= subset_rom[subset_ra];
    stage_q  <= stage_rom[stage_ra];
end

//---------------------------------------------------------------------------
// [2] Integral image, 33x33 of 18 bits, one true dual-port ERAM.
//
// Port A writes during the build and reads during evaluation; port B always
// reads.  That split is what lets a single RAM serve both phases: the build
// needs the row above read while the current row is written (B reads, A writes),
// and evaluation needs two reads per clock to collect 16 corners in 8 issues.
// No reset on the array -- same reason as the font ROM, it is what keeps this
// inferrable as RAM rather than 19,602 flops.
//---------------------------------------------------------------------------
reg [IIDW-1:0] ii [0:IIN-1];
reg [IIDW-1:0] ii_qa, ii_qb;
reg [IIAW-1:0] ii_aa, ii_ab;
reg [IIDW-1:0] ii_wd;
reg            ii_we;

always @(posedge clk) begin
    if (ii_we) ii[ii_aa] <= ii_wd;
    else       ii_qa     <= ii[ii_aa];
end

always @(posedge clk) ii_qb <= ii[ii_ab];

//---------------------------------------------------------------------------
// [3] State machine.
//---------------------------------------------------------------------------
localparam [4:0] S_IDLE  = 5'd0,
                 S_ZERO  = 5'd1,    // clear row 0 and column 0 of the integral image
                 S_BUILD = 5'd2,    // running sum over the ROI, 3 clocks per pixel
                 S_STG0  = 5'd3,    // stage_ra settling
                 S_STG   = 5'd4,    // stage descriptor valid; point at its first weak
                 S_W1    = 5'd5,    // weak_ra settling
                 S_W2    = 5'd6,    // weak_q valid; point at its feature rectangle
                 S_W3    = 5'd7,    // rect_ra settling
                 S_W4    = 5'd8,    // rect_q valid; precompute row bases and column offsets
                 S_CORN  = 5'd9,    // 10 clocks: 8 issues of 2 corners, 2 to drain
                 S_BLK   = 5'd10,   // the 9 block sums
                 S_SUB0  = 5'd11,   // 8 compares -> code, issue the subset read
                 S_SUB1  = 5'd12,   // subset_ra settling
                 S_ACC   = 5'd13,   // subset_q valid; accumulate the chosen leaf
                 S_THR   = 5'd14,   // stage threshold compare
                 S_NEXT  = 5'd15;   // retire the window, advance the slide position

reg [4:0]  st;
reg [1:0]  roi;

// integral-image build
reg [4:0]  br, bc;                  // ROI row / column
reg [1:0]  bph;                     // 0 issue, 1 settle, 2 compute+write
reg [6:0]  zc;                      // zeroing counter, 0..2*BUFN
reg [IIDW-1:0] rowacc;

// window scan
reg [5:0]  ox, oy;                  // slide offset inside the buffer

// 0..NPOS2-1.  EIGHT BITS, not four.  NPOS2 was 9 while STEP was 4 and this
// counter was declared [3:0]; STEP=1 makes it 81 and a 4-bit counter would
// wrap at 15, ending every ROI a sixth of the way through its scan and doing
// it silently.  Widened deliberately past any STEP this module would be given:
// STEP=1 is the densest possible scan and 81 < 256.
reg [7:0]  pos;
reg [4:0]  si;                      // stage index
reg [7:0]  wi;                      // absolute weak index
reg [7:0]  wleft;                   // weaks remaining in this stage
reg signed [23:0] acc;
reg        acc_first;               // first weak of a stage starts the sum at 0
reg [3:0]  ck;                      // corner phase, 0..9
reg        any_accept;
reg [7:0]  n_acc;                   // accepting windows so far in this ROI

// feature geometry, computed once per weak in S_W4
reg [IIAW-1:0] rbase [0:3];
reg [5:0]      coff  [0:3];

reg [IIDW-1:0] p [0:15];            // the 16 corners

// A block is at most 8x8 of 8-bit pixels so its sum fits in 15 bits, but the
// partial p0-p1-p2 goes negative, hence signed and 20 wide.
reg signed [19:0] b00, b01, b02, b10, b11, b12, b20, b21, b22;

reg [7:0] code;

// ROM field slices, named so the state machine reads as prose.
wire [7:0]  w_feat  = weak_q[39:32];
wire [15:0] w_leaf0 = weak_q[31:16];
wire [15:0] w_leaf1 = weak_q[15:0];
wire [4:0]  r_x     = rect_q[19:15];
wire [4:0]  r_y     = rect_q[14:10];
wire [4:0]  r_w     = rect_q[9:5];
wire [4:0]  r_h     = rect_q[4:0];
wire [7:0]  s_start = stage_q[31:24];
wire [7:0]  s_count = stage_q[23:16];
wire signed [15:0] s_thr = stage_q[15:0];

// Corner i of the 4x4 grid sits at row y+oy+(i/4)*h, column x+ox+(i%4)*w.  Issue
// q covers corners 2q and 2q+1, which share a row (2q and 2q+1 never straddle a
// multiple of 4) -- so one row base and two column offsets per issue.  This
// indexing is OpenCV's setOffsets; getting it wrong is exactly what the cv2
// cross-check in the generator exists to catch.
// Issue q covers corners 2q and 2q+1: j = q>>1 for both, k = 0,1 on even q and
// 2,3 on odd q.  Two corners that share a row means one row base and two column
// offsets per issue, which is why the pairing is by 2 and not by 4.
wire [1:0] q_j  = ck[2:1];
wire [1:0] q_ka = ck[0] ? 2'd2 : 2'd0;
wire [1:0] q_kb = q_ka | 2'd1;

// The 8 compare results, packed the way OpenCV packs them.  Bit 7 is the
// top-left block and the sense is >=; do not "tidy" either.
wire [7:0] code_now = {(b00 >= b11), (b01 >= b11), (b02 >= b11), (b12 >= b11),
                       (b22 >= b11), (b21 >= b11), (b20 >= b11), (b10 >= b11)};

// row*IIW with IIW==33, as (row<<5)+row.  No DSP, same trick as the rest of the
// project's stride arithmetic.
function [IIAW-1:0] row_base;
    input [6:0] row;
    begin
        row_base = {row, 5'b0} + {4'b0, row};
    end
endfunction

always @(posedge clk) begin
    if (!rst_n) begin
        st         <= S_IDLE;
        busy       <= 1'b0;
        done       <= 1'b0;
        win_done   <= 1'b0;
        win_accept <= 1'b0;
        win_stages <= 5'd0;
        win_code   <= 8'd0;
        face_found <= 1'b0;
        face_ox    <= 6'd0;
        face_oy    <= 6'd0;
        ii_we      <= 1'b0;
        buf_ra     <= {BUFAW{1'b0}};
        rect_ra    <= 8'd0;
        weak_ra    <= 8'd0;
        subset_ra  <= 11'd0;
        stage_ra   <= 5'd0;
        roi        <= 2'd0;
        any_accept <= 1'b0;
        face_nacc  <= 4'd0;
        n_acc      <= 8'd0;
        acc        <= 24'sd0;
    end else begin
        done     <= 1'b0;
        win_done <= 1'b0;
        ii_we    <= 1'b0;

        case (st)
        //-------------------------------------------------------------------
        S_IDLE: begin
            if (start) begin
                roi        <= roi_sel;
                busy       <= 1'b1;
                any_accept <= 1'b0;
                n_acc      <= 8'd0;
                face_found <= 1'b0;
                zc         <= 7'd0;
                st         <= S_ZERO;
            end
        end

        //-------------------------------------------------------------------
        // Row 0 and column 0 of the integral image are zero by definition.
        // Writing them explicitly costs 65 clocks and buys the evaluation path
        // freedom from special-casing a zero corner, which would otherwise mean
        // a mux on all 16 corner reads -- on a clock with 0.1ns to spare.
        S_ZERO: begin
            ii_we <= 1'b1;
            ii_wd <= {IIDW{1'b0}};
            // zc is 7 bits and ii_aa is IIAW; the zero-extend must be explicit.
            // Writing zc[IIAW-1:0] selects past the end of zc, which iverilog
            // fills with x -- the whole integral image then goes x, every stage
            // compare becomes x, and the cascade "accepts" every window.
            if (zc <= BUFN) ii_aa <= {{(IIAW-7){1'b0}}, zc}; // row 0, every column
            else            ii_aa <= row_base(zc - BUFN);   // column 0, rows 1..BUFN
            if (zc == 2*BUFN) begin
                br     <= 5'd0;
                bc     <= 5'd0;
                bph    <= 2'd0;
                rowacc <= {IIDW{1'b0}};
                st     <= S_BUILD;
            end else begin
                zc <= zc + 7'd1;
            end
        end

        //-------------------------------------------------------------------
        // ii[r+1][c+1] = ii[r][c+1] + (this row's sum up to and including c).
        // Three clocks per pixel because buf_q and ii_qb are both synchronous
        // reads: issue, settle, use.  3,072 clocks against a 2.47M-clock frame,
        // so there is nothing to buy by pipelining it.
        S_BUILD: begin
            case (bph)
            2'd0: begin
                buf_ra <= {roi, br, bc};
                ii_ab  <= row_base({2'b0, br}) + {5'b0, bc} + 11'd1;
                bph    <= 2'd1;
            end
            2'd1: bph <= 2'd2;
            default: begin
                rowacc <= rowacc + {{(IIDW-8){1'b0}}, buf_q};
                ii_we  <= 1'b1;
                ii_aa  <= row_base({2'b0, br} + 7'd1) + {5'b0, bc} + 11'd1;
                ii_wd  <= ii_qb + rowacc + {{(IIDW-8){1'b0}}, buf_q};
                bph    <= 2'd0;
                if (bc == BUFN - 1) begin
                    bc     <= 5'd0;
                    rowacc <= {IIDW{1'b0}};
                    if (br == BUFN - 1) begin
                        ox       <= 6'd0;
                        oy       <= 6'd0;
                        pos      <= 8'd0;
                        si       <= 5'd0;
                        stage_ra <= 5'd0;
                        st       <= S_STG0;
                    end else begin
                        br <= br + 5'd1;
                    end
                end else begin
                    bc <= bc + 5'd1;
                end
            end
            endcase
        end

        //-------------------------------------------------------------------
        // stage_ra settling.  This state is the whole reason stage counts used to
        // come out wrong in both directions: S_THR set stage_ra to the next stage
        // and jumped straight here, so S_STG read the PREVIOUS stage's weak range
        // out of stage_q and every stage after the first ran the wrong weaks.
        // Stage 0 was unaffected -- stage_ra is 0 out of reset -- which is what
        // made the symptom look like an off-by-one in the counter instead.
        S_STG0: st <= S_STG;

        // stage_q is valid here.
        S_STG: begin
            wi        <= s_start;
            wleft     <= s_count;
            weak_ra   <= s_start;
            acc_first <= 1'b1;
            st        <= S_W1;
        end

        S_W1: st <= S_W2;                       // weak_ra settling -- load-bearing

        S_W2: begin
            rect_ra <= w_feat;                  // weak_q is valid now
            st      <= S_W3;
        end

        S_W3: st <= S_W4;                       // rect_ra settling -- load-bearing

        S_W4: begin                             // rect_q is valid now
            rbase[0] <= row_base({2'b0, r_y} + {1'b0, oy});
            rbase[1] <= row_base({2'b0, r_y} + {1'b0, oy} + {2'b0, r_h});
            rbase[2] <= row_base({2'b0, r_y} + {1'b0, oy} + {1'b0, r_h, 1'b0});
            rbase[3] <= row_base({2'b0, r_y} + {1'b0, oy} + {2'b0, r_h} + {1'b0, r_h, 1'b0});
            coff[0]  <= {1'b0, r_x} + ox;
            coff[1]  <= {1'b0, r_x} + ox + {1'b0, r_w};
            coff[2]  <= {1'b0, r_x} + ox + {r_w, 1'b0};
            coff[3]  <= {1'b0, r_x} + ox + {1'b0, r_w} + {r_w, 1'b0};
            ck       <= 4'd0;
            st       <= S_CORN;
        end

        // Ten clocks.  Issues 0..7 each fetch a corner pair; captures lag the
        // issues by two because the read is synchronous, so ck 2..9 capture pair
        // ck-2.  The two extra clocks are the drain.
        S_CORN: begin
            if (ck <= 4'd7) begin
                ii_aa <= rbase[q_j] + {{(IIAW-6){1'b0}}, coff[q_ka]};
                ii_ab <= rbase[q_j] + {{(IIAW-6){1'b0}}, coff[q_kb]};
            end
            if (ck >= 4'd2) begin
                p[{ck[2:0] - 3'd2, 1'b0}]        <= ii_qa;
                p[{ck[2:0] - 3'd2, 1'b0} | 4'd1] <= ii_qb;
            end
            if (ck == 4'd9) st <= S_BLK;
            else            ck <= ck + 4'd1;
        end

        // Block (j,k) = p[4j+k] - p[4j+k+1] - p[4(j+1)+k] + p[4(j+1)+k+1].
        // Constant indices, so this is wiring and adders, no mux.
        S_BLK: begin
            b00 <= $signed({2'b0, p[0]})  - $signed({2'b0, p[1]})  - $signed({2'b0, p[4]})  + $signed({2'b0, p[5]});
            b01 <= $signed({2'b0, p[1]})  - $signed({2'b0, p[2]})  - $signed({2'b0, p[5]})  + $signed({2'b0, p[6]});
            b02 <= $signed({2'b0, p[2]})  - $signed({2'b0, p[3]})  - $signed({2'b0, p[6]})  + $signed({2'b0, p[7]});
            b10 <= $signed({2'b0, p[4]})  - $signed({2'b0, p[5]})  - $signed({2'b0, p[8]})  + $signed({2'b0, p[9]});
            b11 <= $signed({2'b0, p[5]})  - $signed({2'b0, p[6]})  - $signed({2'b0, p[9]})  + $signed({2'b0, p[10]});
            b12 <= $signed({2'b0, p[6]})  - $signed({2'b0, p[7]})  - $signed({2'b0, p[10]}) + $signed({2'b0, p[11]});
            b20 <= $signed({2'b0, p[8]})  - $signed({2'b0, p[9]})  - $signed({2'b0, p[12]}) + $signed({2'b0, p[13]});
            b21 <= $signed({2'b0, p[9]})  - $signed({2'b0, p[10]}) - $signed({2'b0, p[13]}) + $signed({2'b0, p[14]});
            b22 <= $signed({2'b0, p[10]}) - $signed({2'b0, p[11]}) - $signed({2'b0, p[14]}) + $signed({2'b0, p[15]});
            st  <= S_SUB0;
        end

        // Pack the code and read the subset word it selects.  code_now is the
        // combinational form; `code` is only kept so the bench can see it.
        S_SUB0: begin
            code      <= code_now;
            subset_ra <= {wi, 3'b0} | {8'b0, code_now[7:5]};
            st        <= S_SUB1;
        end

        S_SUB1: st <= S_ACC;                    // subset_ra settling -- load-bearing

        // subset_q is valid now.  A set bit takes leaf0, a clear bit leaf1.
        S_ACC: begin
            win_code <= code;
            acc <= (acc_first ? 24'sd0 : acc) +
                   (subset_q[code[4:0]] ? $signed({{8{w_leaf0[15]}}, w_leaf0})
                                        : $signed({{8{w_leaf1[15]}}, w_leaf1}));
            acc_first <= 1'b0;
            if (wleft == 8'd1) begin
                st <= S_THR;
            end else begin
                wleft   <= wleft - 8'd1;
                wi      <= wi + 8'd1;
                weak_ra <= wi + 8'd1;
                st      <= S_W1;
            end
        end

        //-------------------------------------------------------------------
        // Stage boundary.  acc was assigned one clock ago, so it has settled.
        S_THR: begin
            if (acc < $signed({{8{s_thr[15]}}, s_thr})) begin
                win_done   <= 1'b1;             // rejected by stage si
                win_accept <= 1'b0;
                win_stages <= si;
                st         <= S_NEXT;
            end else if (si == NSTAGE - 1) begin
                win_done   <= 1'b1;             // survived every stage: a face
                win_accept <= 1'b1;
                win_stages <= NSTAGE[4:0];
                n_acc <= n_acc + 8'd1;
                if (!any_accept) begin
                    any_accept <= 1'b1;
                    face_ox    <= ox;
                    face_oy    <= oy;
                end
                st <= S_NEXT;
            end else begin
                si       <= si + 5'd1;
                stage_ra <= si + 5'd1;
                st       <= S_STG0;
            end
        end

        // One window retired.  Advance the slide position, or finish the ROI.
        // Every position is scanned even after an accept: the extra work is
        // bounded and small, and it is what lets ftb compare this module against
        // OpenCV window by window instead of only on the aggregate.
        S_NEXT: begin
            if (pos == NPOS2 - 1) begin
                face_found <= any_accept;
                // n_acc's last increment happened in S_THR one clock ago, so
                // it has settled -- the same reason any_accept can be read
                // here.  face_nacc is only ever sampled by the caller on done.
                face_nacc  <= (n_acc > 8'd15) ? 4'd15 : n_acc[3:0];
                busy       <= 1'b0;
                done       <= 1'b1;
                st         <= S_IDLE;
            end else begin
                pos      <= pos + 8'd1;
                si       <= 5'd0;
                stage_ra <= 5'd0;
                if (ox == (NPOS - 1) * STEP) begin
                    ox <= 6'd0;
                    oy <= oy + STEP[5:0];
                end else begin
                    ox <= ox + STEP[5:0];
                end
                st <= S_STG0;
            end
        end

        default: st <= S_IDLE;
        endcase
    end
end

endmodule
