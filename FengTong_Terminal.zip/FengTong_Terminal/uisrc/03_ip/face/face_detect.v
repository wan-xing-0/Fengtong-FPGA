//---------------------------------------------------------------------------
// face_detect -- runs face_cascade over the ROI patches and turns the verdicts
// back into frame-coordinate boxes.
//
// One instance of face_cascade is time-shared across the ROIs rather than one
// per ROI.  A full 9-position scan measures 6,416 clocks (fctb), so four of
// them is ~1% of a 2.47M-clock visible frame; four copies of the classifier
// would buy nothing and cost four sets of ROMs.
//
// THE COORDINATE MAPPING IS THE PART THAT CAN BE SILENTLY WRONG
// face_cascade reports an accept as a slide offset inside a BUFN x BUFN patch.
// The patch was cut from the frame at (roi_x0, roi_y0) with side roi_side, so a
// patch coordinate p maps back to roi_x0 + floor(p*side/BUFN) and the WIN-cell
// window maps to a box floor(WIN*side/BUFN) across.
//
// roi_side used to be a power of two (published as an exponent, roi_k) and both
// terms were plain shifts.  It is an arbitrary side since the 09-19 late DDA change,
// so the two products go through scl() below: a shift-add over the multiplier's
// six bits.  Still no divide and no multiply operator in this module -- the /
// BUFN is the >> 5 that closes scl(), and it is exact, not a rounding.
//
// Getting that mapping wrong does not look like a mapping bug on screen.  It
// looks like the detector finding faces in the wrong place -- which reads as a
// classifier problem, and the classifier is the one part already proved correct.
// So: the box this publishes is the classifier's window, mapped, and nothing
// else.  No smoothing, no centre-of-gravity, no rescaling to "look better".
//
// OUTPUT FORMAT is ccl_blob's, so det_overlay draws it unmodified -- a second
// instance with NBLOB=4 and a red BOX_RGB.  Reusing the overlay is worth more
// than it looks: its clipping, its thickness handling and its latch-through-the-
// blanking timing are all already right.
//
// PERSISTENCE.  A face that is found in one frame and missed in the next would
// flicker, and a single-scale cascade misses often -- a head turn of 15 degrees
// is enough.  So each box is held for HOLD_FRAMES frames after its last sighting.
// This is the same trick motion_frame_drawer uses and for the same reason; the
// difference is that here the hold is per ROI slot, and a slot's hold is
// cancelled the moment that ROI stops being a candidate at all, so a box cannot
// outlive the region it describes.
//
// WHY THERE IS NO FRAME-END DEADLINE HERE
// Section 3.-8's lesson, applied: this does not run in the blanking, it runs
// across the visible frame, and it is started by roi_ready rather than by a
// frame edge.  If a scan somehow overran a whole frame, face_roi_buf would
// simply hold its bank swap (rd_busy) and this would pick up the next pulse.
// Nothing is truncated and nothing is starved -- there is no deadline to miss.
//
// ⭐ PUBLICATION IS ATOMIC, AND THAT IS NOT A STYLE CHOICE (09-19 night, 3.-14)
// The sweep takes tens of thousands of clocks and it writes its slots ONE AT A
// TIME: S_MAP sets slot 0, then slot 1, then 2, then 3, and only after all four
// does S_NMS fold the concentric rungs together and S_VOTE apply the cut.  So
// for most of the sweep the working set is a MIXTURE -- some slots holding this
// sweep's answer, some still holding the last one, and no suppression applied
// to either.
//
// det_overlay latches its boxes once per frame, and it opens that latch on
// exactly the condition face_roi_buf raises roi_ready on: de quiet for
// VB_GUARD clocks.  The latch then stays open until de rises, ~10,500 clocks
// later -- and the sweep starts inside that window.  So what the overlay
// captured was the working set a few thousand clocks into the sweep: typically
// slot 0 and slot 1 freshly written (which with NSCALE=2 are the SAME candidate
// at two rungs), NMS not yet run, slots 2 and 3 stale.
//
// On screen that is a big box with a small box inside it, and it is what the
// board showed on 09-19 evening.  The tell that it was a publication race and
// not an NMS failure: the OSD's FACES count read 1 on the very same frame.  The
// OSD digit is drawn near the bottom of the picture, ~2.3M clocks in, by which
// time the sweep HAD finished and NMS HAD collapsed the pair.  Two readers, two
// different instants, one non-atomic register file.
//
// The fix is the obvious one and it costs four registers plus a valid: the FSM
// works on w_*, and the published face_* take the whole set in one clock at the
// end of S_VOTE.  Whenever the overlay latches, it sees a complete sweep with
// suppression and the MIN_NEIGHBORS cut already applied.  The cost is that a
// box appears one frame later than it could have; the benefit is that a box on
// screen is always a box this module actually meant to publish.
//---------------------------------------------------------------------------

`timescale 1ns/1ns

module face_detect #(
parameter integer NROI   = 4,
parameter integer BUFN   = 32,
parameter integer WIN    = 24,
parameter integer STEP   = 4,

// Frames a box survives without being re-found.  16 at 60fps is ~270ms, short
// enough that a box does not trail a moving head and long enough to ride out
// the misses a single-scale cascade makes on a turning face.  Raised from 8 on
// 09-19 late: the board showed the accept itself flickering frame to frame, which is
// what this parameter exists to absorb.
parameter [5:0]   HOLD_FRAMES = 6'd16,

// Which of two mutually-overlapping boxes survives suppression (see [NMS]).
// 1 keeps the LOWER slot index, which with NSCALE=2 in face_roi_buf is the
// rung-1 box -- 1.5x the candidate rather than 1.875x.  Set to 0 to keep the
// bigger one instead.  There is no better rule available: face_cascade reports
// accept/reject and no score, so neither box can claim more confidence than the
// other, and this is the honest place to put that choice rather than burying it.
parameter integer NMS_KEEP_FIRST = 1,

// MINIMUM NEIGHBOURS -- how many accepting windows a box must be backed by
// before it is published.  This is cv2.detectMultiScale's minNeighbors.
//
// ⭐ IT IS DELIBERATELY 1, WHICH MEANS NO CUT.  Do not raise it without new
// measurements, and read this before assuming OpenCV's default of 3 applies.
//
// The intent when this was added was 2, to kill the boxes the board was
// showing on a nose and a mouth.  Measuring first is what stopped that:
// running lbpcascade_frontalface's golden model over both faces it accepts in
// the test image, at ONE-pixel steps over the whole 9x9 slide range, gives
//
//     face A:  1 accepting window out of 81
//     face B:  3 accepting windows out of 81
//
// A true face here is one to three isolated accepts, not a cluster, because
// this cascade is a tenth the size of the Haar one and its accept region is
// about a pixel wide.  MIN_NEIGHBORS=2 would have rejected face A -- half the
// true positives sacrificed, and it would have looked exactly like the recall
// problem being fixed in the same round.
//
// cv2's 3 is safe for cv2 because detectMultiScale sweeps dozens of 1.1x
// scale rungs, so the neighbours come from the SCALE axis.  Two rungs at 1.25x
// cannot supply that, and a default copied across without checking the scan
// geometry it was measured on is the kind of borrowed number this file has
// already been burnt by once (the LBP bit order, section 3.-10-B).
//
// SO WHY KEEP THE MECHANISM AT ALL?  Because the real fix for the false boxes
// was upstream -- face_skin was finding only the LIPS of a desaturated face,
// so the ROI framed a mouth and the classifier correctly reported a mouth-
// shaped patch -- and because the pooled count is the only instrumentation
// that can tell the next session whether the evidence density ever improves
// enough to threshold on.  It is printed on the OSD's FACES row.
//
// RAISE IT TO 2 ONLY IF the board shows real faces reading 2 or more on that
// row.  If real faces read 1 there, this parameter cannot help and the false
// positives have to be attacked geometrically instead.
parameter [3:0]   MIN_NEIGHBORS = 4'd1,

//---------------------------------------------------------------------------
// 2026-10-02 evening, for face_cnn.  All three default to the cascade-era
// behaviour, so frtb / fitb / fntb test exactly what they always tested.
//
// VAR_W      0: the box side is WIN (the cascade's fixed window).
//            1: the box side is cas_w, the classifier's own estimate.  face_cnn
//               regresses the face box; drawing WIN instead is what the board
//               called "box incomplete".
// NMS_SCORE  0: concentric-rung NMS, mutual centre containment, votes pooled.
//            1: score NMS.  Two boxes are the same face when EITHER centre is
//               inside the other box (an ear-centred ROI regresses a box that
//               overlaps the face box without being concentric with it -- the
//               "ear gets its own box" report), and the one with the higher
//               cas_nacc (= face_cnn's confidence) survives, ties to the lower
//               slot.  No pooling: a confidence is not a vote count.
// CLIP_W/H   the published box is clamped to the frame.  A face at the picture
//            edge regresses a box that runs off it, and det_overlay draws only
//            the in-frame part of a box -- an unclamped box loses its far edge.
//            0 disables (cascade boxes never leave the ROI, which is in-frame).
//---------------------------------------------------------------------------
parameter integer VAR_W     = 0,
parameter integer NMS_SCORE = 0,
parameter integer CLIP_W    = 0,
parameter integer CLIP_H    = 0,

// CONFIRM GATE (10-03 evening).  1 = off, bit-exact.  N > 1: an accept that
// does not land on a box already on screen is only published once the same
// place (centre-in rule, as NMS_SCORE) has been accepted in N consecutive
// sweeps, MISS_TOL missed sweeps forgiven.  Acquiring needs proof, following
// does not -- a published face keeps its box through single-sweep misses via
// HOLD_FRAMES exactly as before.
//
// Why: on the 14:47 board recording the false boxes (a hand, the cat print on
// the T-shirt, an ear) each fired for one or two sweeps; a face fires every
// sweep.  Replayed through board_sim.FaceTrack at the board's ~57.7 sweeps/s,
// N = 6 (~0.1 s) took the no-face clips from 0.22-0.23 to 0.00-0.03 of frames
// showing a false box, face coverage 0.96 -> 0.94.  The cost is ~0.1 s before
// a NEW face gets its box.  board_sim.FaceTrack is the reference model.
parameter integer CONFIRM   = 1,
parameter integer MISS_TOL  = 0
)(
input  wire        clk,
input  wire        rst_n,
input  wire        en,

//--- from face_roi_buf ----------------------------------------------------
input  wire [NROI*12-1:0] roi_x0,
input  wire [NROI*12-1:0] roi_y0,
input  wire [NROI*12-1:0] roi_side,
input  wire [NROI-1:0]    roi_valid,
input  wire        roi_ready,       // one clock: a fresh bank is readable

//--- to/from face_cascade -------------------------------------------------
output reg         cas_start,
output reg  [1:0]  cas_roi,
input  wire        cas_busy,
input  wire        cas_done,
input  wire        cas_found,
input  wire [5:0]  cas_ox,
input  wire [5:0]  cas_oy,
input  wire [3:0]  cas_nacc,        // accepting windows, for MIN_NEIGHBORS
input  wire [5:0]  cas_w,           // box side in patch pixels; read only if VAR_W

output wire        rd_busy,         // to face_roi_buf: hold the bank swap

//--- published boxes, in ccl_blob's format so det_overlay takes them as-is --
// Written ONLY at the end of S_VOTE, all five in one clock.  See the header's
// PUBLICATION IS ATOMIC note before adding a writer anywhere else.
output reg  [NROI*12-1:0] face_x0,
output reg  [NROI*12-1:0] face_x1,
output reg  [NROI*12-1:0] face_y0,
output reg  [NROI*12-1:0] face_y1,
output reg  [NROI-1:0]    face_vld,
output reg  [7:0]         face_count,
output reg                pub,         // one clock: face_* just took a new sweep (face_smooth)

//--- instrumentation ------------------------------------------------------
output reg  [3:0]  dbg_hits,        // ROIs that accepted in the last sweep

// The best pooled vote count of the last sweep, AFTER scale-ladder pooling
// and BEFORE the MIN_NEIGHBORS cut.  This is the number that says whether
// MIN_NEIGHBORS is set sanely: it reads 0 when nothing accepted, 1 when only
// isolated accepts are happening (either accidents, or real faces the ROI is
// framing badly), and 2+ when the evidence is clustered the way a real
// detection clusters.  Saturates at 15, which nine windows times two rungs
// cannot reach anyway.
output reg  [3:0]  dbg_nacc
);

localparam [2:0] S_IDLE = 3'd0,
                 S_KICK = 3'd1,     // cas_start asserted
                 S_WAIT = 3'd2,     // scanning
                 S_MAP  = 3'd3,     // scl() results registered, box being formed
                 S_NMS  = 3'd4,     // pairwise overlap suppression + vote pooling
                 S_VOTE = 3'd5,     // MIN_NEIGHBORS cut, one clock, all slots
                 S_CF   = 3'd6,     // CONFIRM: scan published boxes + candidates
                 S_CU   = 3'd7;     // CONFIRM: update the candidate, decide

reg [2:0] st;
reg [2:0] idx;                      // which ROI slot the sweep is on
reg [3:0] hits;

// The mapping, split across S_WAIT -> S_MAP.  See the scl() header for why one
// clock was not enough.
reg [11:0] m_dx, m_dy, m_w;
reg        m_found;
reg        m_raw;                   // the classifier's verdict, before the CONFIRM gate
reg [3:0]  m_nacc;

// Pooled accepting-window count per slot.  Written in S_MAP from the sweep,
// added together across concentric pairs in S_NMS, tested in S_VOTE.  A held
// box keeps the count it was published with, so ageing out over HOLD_FRAMES
// is unaffected by the cut.
reg [3:0]  votes [0:NROI-1];

// THE WORKING SET.  Everything the sweep does happens here; face_* only ever
// see the finished article.  Same layout as the outputs so the commit is a
// straight copy and nothing can be reordered between the two.
reg [NROI*12-1:0] w_x0, w_x1, w_y0, w_y1;
reg [NROI-1:0]    w_vld;

// A sweep is in progress from the moment it is kicked until the last ROI
// retires.  face_roi_buf keys its bank swap off this.
assign rd_busy = (st != S_IDLE);

//---------------------------------------------------------------------------
// The mapping, for the ROI the classifier has just finished.
//
// scl(m, sd) = floor(m * sd / BUFN), with BUFN = 32 folded into the final >> 5.
// The multiply is a conditional-add over m's six bits, so it costs six 18-bit
// adds -- no DSP, and no dependence on WIN or STEP holding any particular
// value.  A plain `*` here would be outside the pixel path and safe on timing,
// but TD will infer a multiplier for it and this module has no business owning
// one.
//
// TWO THINGS ABOUT THOSE SIX ADDS, both learned from the 09-19 timing report.
//
// [a] They must be a TREE, not a chain.  `acc = acc + term` in a for loop is
// six adders in series by the semantics of the assignment, and TD builds
// exactly that: ~9ns of carry chain against a 6.666ns budget.  The explicit
// three-deep tree below is the same arithmetic in half the depth.
//
// [b] Even the tree does not leave room for the frame-coordinate add and the
// +width-1 on the same clock, so the caller registers scl()'s result and forms
// the box on the NEXT clock (S_WAIT -> S_MAP).  That is why this function is
// called on cas_done and not where the box is written.
//
// This module's sibling failure is worth stating plainly, because it cost a
// board session: face_roi_buf had the same shape of bug (section [2] there),
// and a detector whose ROI geometry and whose box mapping are BOTH sampled
// mid-carry looks exactly like a classifier that does not work.  The classifier
// is bit-exact and was never the problem either time.
//---------------------------------------------------------------------------
function [11:0] scl;
    input [5:0]  m;
    input [11:0] sd;
    reg   [17:0] a0, a1, a2, a3, a4, a5;
    reg   [17:0] t0, t1, t2, acc;
    begin
        a0 = m[0] ? {6'b0, sd}       : 18'd0;
        a1 = m[1] ? {5'b0, sd, 1'b0} : 18'd0;
        a2 = m[2] ? {4'b0, sd, 2'b0} : 18'd0;
        a3 = m[3] ? {3'b0, sd, 3'b0} : 18'd0;
        a4 = m[4] ? {2'b0, sd, 4'b0} : 18'd0;
        a5 = m[5] ? {1'b0, sd, 5'b0} : 18'd0;
        t0  = a0 + a1;
        t1  = a2 + a3;
        t2  = a4 + a5;
        acc = t0 + t1 + t2;
        // 63 * 1080 = 68,040, so bit 17 can never be set and [16:5] is a lossless
        // 12-bit result.  Slicing [17:5] instead would be 13 bits into 12.
        scl = acc[16:5];
    end
endfunction

wire [11:0] sd_now  = roi_side[idx[1:0]*12 +: 12];
wire [11:0] bx_base = roi_x0[idx[1:0]*12 +: 12];
wire [11:0] by_base = roi_y0[idx[1:0]*12 +: 12];

// S_WAIT registers these three; S_MAP adds the frame-coordinate base.  map_w is
// scl of a CONSTANT, so it folds to two shifts and an add (24/32 = 3/4) and
// could have stayed where the box is written -- it is registered alongside the
// other two only so that all three terms of the box come from the same clock.
wire [11:0] map_dx = scl(cas_ox, sd_now);
wire [11:0] map_dy = scl(cas_oy, sd_now);
wire [11:0] map_w  = scl((VAR_W != 0) ? cas_w : WIN[5:0], sd_now);

//---------------------------------------------------------------------------
// [NMS] Pairwise overlap suppression, and vote pooling on the same walk.
//
// WHY IT IS NEEDED AT ALL.  face_roi_buf enrols every candidate at two sides
// (NSCALE=2), and the two rungs are CONCENTRIC by construction -- 1.5x and
// 1.875x the same candidate box, centred on the same point.  When the face is
// findable at both, both slots accept and the overlay draws two concentric
// boxes, which reads on screen as "one face detected as two", a big box with a
// small box inside it.  That is not a false positive and not a threshold
// problem: it is the scale ladder working, being reported raw.
//
// THE TEST is mutual centre-containment: b's centre inside a AND a's centre
// inside b.  Concentric boxes pass it always (same centre), two genuinely
// different faces fail it as soon as either centre leaves the other's box, and
// -- unlike an IoU threshold -- it needs no multiply, no area and no divide.
// The centres are compared at 2x so the halving never happens either: 2*cx
// within [2*x0, 2*x1] is the same predicate, and {x0,1'b0} is a shift.
//
// Six pairs are walked ONE PER CLOCK rather than compared all at once.  Doing
// all six combinationally is 24 comparators and four adds into one OR tree, and
// this module has just been through what happens when arithmetic of that depth
// is put in a single clock.  Six clocks, once per sweep, cost nothing.
//
// Walking them in order also makes suppression transitive for free: pair (0,1)
// having already cleared slot 1 means pair (1,2) sees slot 1 invalid and leaves
// slot 2 alone, so three concentric rungs would collapse to one box and not two.
//---------------------------------------------------------------------------
reg [2:0] pr;                       // which of the six pairs
reg [1:0] pa, pb;

always @(*) begin
    case (pr)
    3'd0:    begin pa = 2'd0; pb = 2'd1; end
    3'd1:    begin pa = 2'd0; pb = 2'd2; end
    3'd2:    begin pa = 2'd0; pb = 2'd3; end
    3'd3:    begin pa = 2'd1; pb = 2'd2; end
    3'd4:    begin pa = 2'd1; pb = 2'd3; end
    default: begin pa = 2'd2; pb = 2'd3; end
    endcase
end

wire [11:0] ax0 = w_x0[pa*12 +: 12];
wire [11:0] ax1 = w_x1[pa*12 +: 12];
wire [11:0] ay0 = w_y0[pa*12 +: 12];
wire [11:0] ay1 = w_y1[pa*12 +: 12];
wire [11:0] bx0 = w_x0[pb*12 +: 12];
wire [11:0] bx1 = w_x1[pb*12 +: 12];
wire [11:0] by0 = w_y0[pb*12 +: 12];
wire [11:0] by1 = w_y1[pb*12 +: 12];

// Twice each centre.
wire [12:0] acx2 = {1'b0, ax0} + {1'b0, ax1};
wire [12:0] acy2 = {1'b0, ay0} + {1'b0, ay1};
wire [12:0] bcx2 = {1'b0, bx0} + {1'b0, bx1};
wire [12:0] bcy2 = {1'b0, by0} + {1'b0, by1};

wire b_in_a = (bcx2 >= {ax0, 1'b0}) && (bcx2 <= {ax1, 1'b0})
           && (bcy2 >= {ay0, 1'b0}) && (bcy2 <= {ay1, 1'b0});
wire a_in_b = (acx2 >= {bx0, 1'b0}) && (acx2 <= {bx1, 1'b0})
           && (acy2 >= {by0, 1'b0}) && (acy2 <= {by1, 1'b0});

wire pair_dup = w_vld[pa] && w_vld[pb]
              && ((NMS_SCORE != 0) ? (b_in_a || a_in_b) : (b_in_a && a_in_b));

// Score NMS: which of the pair loses.  b loses unless it is strictly better.
wire b_wins = (NMS_SCORE != 0) && (votes[pb] > votes[pa]);

// Concentric agreement is EVIDENCE, not just redundancy.  Before 09-19 late the
// loser's accept was simply discarded; now its window count is added to the
// survivor's, so a face found once at rung 1 and once at rung 2 reaches a
// pooled 2 and clears MIN_NEIGHBORS, while a lone accept at one scale does
// not.  Suppression and voting are therefore the same mechanism seen twice:
// boxes that agree merge, and what they agree on is how much evidence the
// merged box carries.  Saturating at 15 costs one mux and keeps the 4-bit
// width honest -- 18 windows could otherwise wrap to a value below the cut.
wire [4:0] pool_raw = {1'b0, votes[pa]} + {1'b0, votes[pb]};
wire [3:0] pooled   = pool_raw[4] ? 4'd15 : pool_raw[3:0];

// Best surviving vote count, for the OSD.  Four slots explicitly rather than a
// loop: this module already hard-codes NROI=4 in the pair table above, and a
// reduction written as a chain is what the scl() header warns about.
// The MIN_NEIGHBORS verdict, per slot, read by S_VOTE for BOTH the working set
// and the commit.  One expression and not two: the published valid and the
// working valid must never be able to disagree about a slot.
wire keep0 = w_vld[0] && (votes[0] >= MIN_NEIGHBORS);
wire keep1 = w_vld[1] && (votes[1] >= MIN_NEIGHBORS);
wire keep2 = w_vld[2] && (votes[2] >= MIN_NEIGHBORS);
wire keep3 = w_vld[3] && (votes[3] >= MIN_NEIGHBORS);
wire [NROI-1:0] keep = {keep3, keep2, keep1, keep0};

// PRE-cut, deliberately: w_vld and not keep.  The whole job of this readout is
// to say whether MIN_NEIGHBORS is set sanely, and a cut box reading 0 instead
// of the 1 it actually scored makes "nothing accepted" and "accepted but below
// the threshold" indistinguishable -- which is the one distinction the number
// exists to make.  fntb T8a/T8d hold this down.
wire [3:0] v0 = w_vld[0] ? votes[0] : 4'd0;
wire [3:0] v1 = w_vld[1] ? votes[1] : 4'd0;
wire [3:0] v2 = w_vld[2] ? votes[2] : 4'd0;
wire [3:0] v3 = w_vld[3] ? votes[3] : 4'd0;
wire [3:0] vm01 = (v0 > v1) ? v0 : v1;
wire [3:0] vm23 = (v2 > v3) ? v2 : v3;
wire [3:0] vmax = (vm01 > vm23) ? vm01 : vm23;

// Hold counters, one per slot.
reg [5:0] hold [0:NROI-1];

//---------------------------------------------------------------------------
// CONFIRM candidate table.  Only reached with CONFIRM > 1.
//
// One entry per place the classifier has recently accepted: its centre, half
// side, how many consecutive sweeps it has been seen in (saturating at 7),
// missed sweeps, and whether this sweep already counted it -- the two framings
// of one face accepting in the same sweep must count once.  An unmatched
// accept takes the first free entry, else the lowest count (lowest index on a
// tie), and is rewritten with the accept's own geometry so it follows motion.
// Ageing is in S_VOTE.
//
// S_CF is 2 + NROI + NCAND clocks: cf_ld registers the accept's centre (m_*
// landed on the clock that entered S_CF), then one target per clock -- the
// four published boxes (any hit = following) and the four candidates (first
// hit = match; the replacement victim is tracked alongside).  The target is
// registered (r_*) and compared the clock after, so no clock has the 4:1 mux,
// the centre adds AND the compare in series -- pclkx1 has ~0.1 ns to spare.
//---------------------------------------------------------------------------
localparam integer NCAND = 4;
reg [11:0] c_cx   [0:NCAND-1];
reg [11:0] c_cy   [0:NCAND-1];
reg [11:0] c_h    [0:NCAND-1];
reg [2:0]  c_cnt  [0:NCAND-1];
reg [1:0]  c_miss [0:NCAND-1];
reg [NCAND-1:0] c_vld, c_seen;

reg  [11:0] n_cx, n_cy, n_h;        // the accept under test
reg  [2:0]  q;
reg  [11:0] r_cx, r_cy, r_h;        // the target being compared (one clock behind q)
reg         r_ok, r_box, r_v;
reg  [1:0]  r_q;
reg         cf_ld, cf_follow, cf_hit, cf_vfree;
reg  [1:0]  cf_k, cf_vic;
reg  [2:0]  cf_vcnt;

// centre = (x0 + x1) >> 1 with x1 = x0 + w - 1  ==  x0 + ((w - 1) >> 1), exactly
// (2*x0 is even), 12-bit wrap included -- S_MAP's box wraps the same way.
wire [11:0] m_wm1 = m_w - 12'd1;
wire [11:0] n_cxw = bx_base + m_dx + {1'b0, m_wm1[11:1]};
wire [11:0] n_cyw = by_base + m_dy + {1'b0, m_wm1[11:1]};

wire [1:0]  qs    = q[1:0];
wire        t_box = !q[2];          // q 0..3 published box, 4..7 candidate
wire [11:0] q_x0  = w_x0[qs*12 +: 12];
wire [11:0] q_x1  = w_x1[qs*12 +: 12];
wire [11:0] q_y0  = w_y0[qs*12 +: 12];
wire [11:0] q_y1  = w_y1[qs*12 +: 12];
wire [12:0] q_cx2 = {1'b0, q_x0} + {1'b0, q_x1};
wire [12:0] q_cy2 = {1'b0, q_y0} + {1'b0, q_y1};
wire [12:0] q_wd  = {1'b0, q_x1} - {1'b0, q_x0} + 13'd1;
wire [11:0] t_cx  = t_box ? q_cx2[12:1] : c_cx[qs];
wire [11:0] t_cy  = t_box ? q_cy2[12:1] : c_cy[qs];
wire [11:0] t_h   = t_box ? q_wd[12:1]  : c_h[qs];
wire        t_ok  = t_box ? w_vld[qs]   : c_vld[qs];
wire [11:0] t_dx  = (n_cx > r_cx) ? n_cx - r_cx : r_cx - n_cx;
wire [11:0] t_dy  = (n_cy > r_cy) ? n_cy - r_cy : r_cy - n_cy;
wire [11:0] t_hm  = (n_h > r_h) ? n_h : r_h;
wire        t_in  = r_ok && (t_dx <= t_hm) && (t_dy <= t_hm);

wire [1:0]  cu_k   = cf_hit ? cf_k : cf_vic;
wire [2:0]  cu_old = c_cnt[cf_k];
wire [2:0]  cu_cnt = !cf_hit          ? 3'd1
                   : c_seen[cf_k]     ? cu_old
                   : (cu_old == 3'd7) ? 3'd7 : cu_old + 3'd1;

integer i;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        st         <= S_IDLE;
        idx        <= 3'd0;
        hits       <= 4'd0;
        cas_start  <= 1'b0;
        cas_roi    <= 2'd0;
        w_x0       <= {NROI*12{1'b0}};
        w_x1       <= {NROI*12{1'b0}};
        w_y0       <= {NROI*12{1'b0}};
        w_y1       <= {NROI*12{1'b0}};
        w_vld      <= {NROI{1'b0}};
        face_x0    <= {NROI*12{1'b0}};
        face_x1    <= {NROI*12{1'b0}};
        face_y0    <= {NROI*12{1'b0}};
        face_y1    <= {NROI*12{1'b0}};
        face_vld   <= {NROI{1'b0}};
        face_count <= 8'd0;
        pub        <= 1'b0;
        dbg_hits   <= 4'd0;
        m_dx       <= 12'd0;
        m_dy       <= 12'd0;
        m_w        <= 12'd0;
        m_found    <= 1'b0;
        m_raw      <= 1'b0;
        m_nacc     <= 4'd0;
        n_cx       <= 12'd0;
        n_cy       <= 12'd0;
        n_h        <= 12'd0;
        q          <= 3'd0;
        r_cx       <= 12'd0;
        r_cy       <= 12'd0;
        r_h        <= 12'd0;
        r_ok       <= 1'b0;
        r_box      <= 1'b0;
        r_v        <= 1'b0;
        r_q        <= 2'd0;
        cf_ld      <= 1'b0;
        cf_follow  <= 1'b0;
        cf_hit     <= 1'b0;
        cf_vfree   <= 1'b0;
        cf_k       <= 2'd0;
        cf_vic     <= 2'd0;
        cf_vcnt    <= 3'd7;
        c_vld      <= {NCAND{1'b0}};
        c_seen     <= {NCAND{1'b0}};
        dbg_nacc   <= 4'd0;
        pr         <= 3'd0;
        for (i = 0; i < NROI; i = i + 1) begin
            hold[i]  <= 6'd0;
            votes[i] <= 4'd0;
        end
        for (i = 0; i < NCAND; i = i + 1) begin
            c_cx[i]   <= 12'd0;
            c_cy[i]   <= 12'd0;
            c_h[i]    <= 12'd0;
            c_cnt[i]  <= 3'd0;
            c_miss[i] <= 2'd0;
        end
    end else begin
        cas_start <= 1'b0;
        // High on the clock face_* hold the commit (both written by S_VOTE).
        pub       <= (st == S_VOTE);

        //-------------------------------------------------------------------
        // A slot whose ROI has stopped being a candidate loses its box at once.
        // Without this a box could outlive the region it was measured in, and
        // then sit still on screen while the person walks away -- which is
        // exactly the "stale box" failure the detect chain spent two rounds on
        // (STALE_HOLD, section 3.-7).
        //
        // This is the ONE writer of face_vld outside the commit, and it only
        // ever CLEARS.  Clearing early cannot draw a box that was not meant to
        // be drawn -- it can only retire one a frame sooner -- so it does not
        // reopen the atomicity hole the commit exists to close.
        //-------------------------------------------------------------------
        if (roi_ready) begin
            for (i = 0; i < NROI; i = i + 1)
                if (!roi_valid[i]) begin
                    hold[i]               <= 6'd0;
                    w_vld[i]              <= 1'b0;
                    face_vld[i]           <= 1'b0;
                    votes[i]              <= 4'd0;
                end
        end

        case (st)
        S_IDLE: begin
            // Only start on a fresh bank.  Re-scanning the same patches would
            // burn clocks to reach the same verdict.
            if (en && roi_ready) begin
                idx  <= 3'd0;
                hits <= 4'd0;
                st   <= S_KICK;
            end else if (!en) begin
                w_vld    <= {NROI{1'b0}};
                face_vld <= {NROI{1'b0}};
                c_vld    <= {NCAND{1'b0}};
                c_seen   <= {NCAND{1'b0}};
            end
        end

        S_KICK: begin
            if (roi_valid[idx[1:0]]) begin
                cas_roi   <= idx[1:0];
                cas_start <= 1'b1;
                st        <= S_WAIT;
            end else begin
                // Nothing to classify in this slot; age its box like any other
                // miss so a box does not freeze when its ROI flickers.
                if (hold[idx[1:0]] != 6'd0) begin
                    hold[idx[1:0]] <= hold[idx[1:0]] - 6'd1;
                    if (hold[idx[1:0]] == 6'd1) w_vld[idx[1:0]] <= 1'b0;
                end
                if (idx == NROI - 1) begin
                    dbg_hits <= hits;
                    pr       <= 3'd0;
                    st       <= S_NMS;
                end else begin
                    idx <= idx + 3'd1;
                    st  <= S_KICK;
                end
            end
        end

        // Register the three scaled offsets and the verdict.  No frame
        // coordinate is added here -- that is S_MAP's one job.
        S_WAIT: begin
            if (cas_done) begin
                m_dx    <= map_dx;
                m_dy    <= map_dy;
                m_w     <= map_w;
                m_found <= cas_found;
                m_raw   <= cas_found;
                m_nacc  <= cas_nacc;
                if (CONFIRM > 1 && cas_found) begin
                    cf_ld     <= 1'b1;
                    cf_follow <= 1'b0;
                    cf_hit    <= 1'b0;
                    cf_vfree  <= 1'b0;
                    cf_vic    <= 2'd0;
                    cf_vcnt   <= 3'd7;
                    st        <= S_CF;
                end else begin
                    st      <= S_MAP;
                end
            end
        end

        S_CF: begin
            if (cf_ld) begin
                n_cx  <= n_cxw;
                n_cy  <= n_cyw;
                n_h   <= {1'b0, m_w[11:1]};
                q     <= 3'd0;
                r_v   <= 1'b0;
                cf_ld <= 1'b0;
            end else begin
                // stage 1: register target q
                r_cx  <= t_cx;
                r_cy  <= t_cy;
                r_h   <= t_h;
                r_ok  <= t_ok;
                r_box <= t_box;
                r_q   <= qs;
                r_v   <= 1'b1;
                if (q != 3'd7) q <= q + 3'd1;        // holds at 7 until target 7 is compared
                // stage 2: compare target r_q.  Target 7 (candidate 3) is the
                // only one with !r_box && r_q == 3, so that is the exit.
                if (r_v) begin
                    if (r_box) begin
                        if (t_in) cf_follow <= 1'b1;
                    end else begin
                        if (t_in && !cf_hit) begin
                            cf_hit <= 1'b1;
                            cf_k   <= r_q;
                        end
                        if (!c_vld[r_q]) begin
                            if (!cf_vfree) begin
                                cf_vfree <= 1'b1;
                                cf_vic   <= r_q;
                            end
                        end else if (!cf_vfree && (c_cnt[r_q] < cf_vcnt)) begin
                            cf_vic  <= r_q;
                            cf_vcnt <= c_cnt[r_q];
                        end
                        if (r_q == 2'd3) st <= S_CU;
                    end
                end
            end
        end

        S_CU: begin
            c_cx[cu_k]   <= n_cx;
            c_cy[cu_k]   <= n_cy;
            c_h[cu_k]    <= n_h;
            c_cnt[cu_k]  <= cu_cnt;
            c_miss[cu_k] <= 2'd0;
            c_vld[cu_k]  <= 1'b1;
            c_seen[cu_k] <= 1'b1;
            m_found      <= cf_follow || (cu_cnt >= CONFIRM);
            st           <= S_MAP;
        end

        // Form the box.  idx has not moved, so bx_base/by_base still describe
        // the ROI the registered offsets were measured in.
        S_MAP: begin
            if (m_found) begin
                w_x0[idx[1:0]*12 +: 12] <= bx_base + m_dx;
                w_y0[idx[1:0]*12 +: 12] <= by_base + m_dy;
                w_x1[idx[1:0]*12 +: 12] <= bx_base + m_dx + m_w - 12'd1;
                w_y1[idx[1:0]*12 +: 12] <= by_base + m_dy + m_w - 12'd1;
                w_vld[idx[1:0]]         <= 1'b1;
                votes[idx[1:0]]         <= m_nacc;
                hold[idx[1:0]]          <= HOLD_FRAMES;
            end else if (hold[idx[1:0]] != 6'd0) begin
                hold[idx[1:0]] <= hold[idx[1:0]] - 6'd1;
                if (hold[idx[1:0]] == 6'd1) w_vld[idx[1:0]] <= 1'b0;
            end
            // raw accepts: with CONFIRM > 1 a gated accept still counts
            if (m_raw) hits <= hits + 4'd1;

            if (idx == NROI - 1) begin
                // dbg_hits counts ACCEPTS, before suppression.  Keeping it raw
                // is deliberate: it and face_count differing is how "one face
                // found at two scales" is told apart from "two faces", and
                // folding suppression into both would hide exactly that.
                dbg_hits <= hits + (m_raw ? 4'd1 : 4'd0);
                pr       <= 3'd0;
                st       <= S_NMS;
            end else begin
                idx <= idx + 3'd1;
                st  <= S_KICK;
            end
        end

        // One pair per clock, six clocks.  The survivor absorbs the loser's
        // votes as well as taking its place.
        S_NMS: begin
            if (pair_dup && (NMS_SCORE != 0)) begin
                if (b_wins) begin
                    w_vld[pa] <= 1'b0;
                    hold[pa]  <= 6'd0;
                end else begin
                    w_vld[pb] <= 1'b0;
                    hold[pb]  <= 6'd0;
                end
            end else if (pair_dup) begin
                if (NMS_KEEP_FIRST != 0) begin
                    w_vld[pb]  <= 1'b0;
                    hold[pb]   <= 6'd0;
                    votes[pa]  <= pooled;
                    votes[pb]  <= 4'd0;
                end else begin
                    w_vld[pa]  <= 1'b0;
                    hold[pa]   <= 6'd0;
                    votes[pb]  <= pooled;
                    votes[pa]  <= 4'd0;
                end
            end
            if (pr == 3'd5) st <= S_VOTE;
            else            pr <= pr + 3'd1;
        end

        //-------------------------------------------------------------------
        // The MIN_NEIGHBORS cut, one clock for all four slots.
        //
        // It runs AFTER pooling, which is the whole point: the cut is applied
        // to the merged evidence for a location, not to each rung separately.
        // face_vld and votes read here are the post-NMS values -- pair (2,3)
        // was handled on the clock that entered this state, so its writes have
        // landed.
        //
        // hold[] is cleared with the box.  Leaving it running would let a
        // rejected box reappear on a later frame's ageing path without ever
        // having cleared the cut, which is the "stale box" failure in a new
        // costume.
        //-------------------------------------------------------------------
        S_VOTE: begin
            for (i = 0; i < NROI; i = i + 1) begin
                if (w_vld[i] && (votes[i] < MIN_NEIGHBORS)) begin
                    w_vld[i] <= 1'b0;
                    hold[i]  <= 6'd0;
                    votes[i] <= 4'd0;
                end
            end

            //---------------------------------------------------------------
            // THE COMMIT.  Five registers, one clock, no condition -- the whole
            // sweep becomes visible at once or not at all.  `keep` and not
            // w_vld: the cut above lands at the end of THIS clock, so reading
            // w_vld here would publish the pre-cut valid and undo the cut for
            // exactly one frame.
            //---------------------------------------------------------------
            face_x0  <= w_x0;
            face_y0  <= w_y0;
            for (i = 0; i < NROI; i = i + 1) begin
                face_x1[i*12 +: 12] <= ((CLIP_W != 0) && (w_x1[i*12 +: 12] > CLIP_W - 1))
                                       ? CLIP_W[11:0] - 12'd1 : w_x1[i*12 +: 12];
                face_y1[i*12 +: 12] <= ((CLIP_H != 0) && (w_y1[i*12 +: 12] > CLIP_H - 1))
                                       ? CLIP_H[11:0] - 12'd1 : w_y1[i*12 +: 12];
            end
            face_vld <= keep;

            // CONFIRM ageing: a candidate not seen this sweep spends a miss
            for (i = 0; i < NCAND; i = i + 1) begin
                if (c_vld[i] && !c_seen[i]) begin
                    if ({1'b0, c_miss[i]} + 3'd1 > MISS_TOL) c_vld[i] <= 1'b0;
                    else                                     c_miss[i] <= c_miss[i] + 2'd1;
                end else if (c_seen[i]) begin
                    c_miss[i] <= 2'd0;
                end
            end
            c_seen <= {NCAND{1'b0}};

            dbg_nacc <= vmax;
            st       <= S_IDLE;
        end

        default: st <= S_IDLE;
        endcase

        // face_count trails the PUBLISHED face_vld by a clock, which is fine:
        // the OSD prints it and det_overlay reads face_vld directly, and both
        // only change at the commit.  It is deliberately derived from face_vld
        // and not from w_vld -- the whole point of 3.-14 is that the number on
        // the OSD and the boxes on the screen describe the same sweep.  Each
        // term is widened before adding -- a sum of 1-bit values is 1-bit
        // arithmetic in Verilog and would report 0 for two faces.
        face_count <= {7'b0, face_vld[0]} + {7'b0, face_vld[1]}
                    + {7'b0, face_vld[2]} + {7'b0, face_vld[3]};
    end
end

endmodule


//---------------------------------------------------------------------------
// face_smooth (2026-10-04) -- the magenta box's position IIR, for the red boxes
//
// Lives in this file so the TD file lists do not change.  Sits between
// face_detect and the face overlay; system_top bypasses it when FACE_SMOOTH=0,
// so 0 is the 10-03 bit exactly.
//
// WHY.  face_detect publishes the CNN's regressed box raw, every sweep, and the
// regression is noisy sweep to sweep: on the 23:57 board recording a face that
// is barely moving had its box jump 24 px (median) / 66 px (p90) in centre and
// 27 / 86 px in size between consecutive 30 fps frames.  Part of that is the
// score NMS handing the face to the other framing's slot, whose regression
// differs.  The magenta tracker never showed this because its centre moves 1/4
// of the way to each measurement.
//
// WHAT.  Per output slot: 2*centre and extent (x1-x0, y1-y0) in 1/16 px.  At
// each commit (face_detect's pub), every new box looks for a box SHOWN at the
// previous commit that it matches -- either centre inside the other, the
// NMS_SCORE rule -- first match in slot order.  Match: centre moves 1/2^SC and
// extent 1/2^SS of the way from that box.  No match: snap.  So
//   * matching is by geometry, not slot index -- a face that changes slot
//     (framing swap, candidate reorder) keeps its smoothing;
//   * a box far from every old box (more than half a box away) snaps, which
//     is the IIR's gate -- a real jump is not dragged across the screen;
//   * the box SET is exactly face_detect's: this never creates, holds or
//     removes a box (CONFIRM / HOLD_FRAMES / roi clears stay authoritative).
//     A slot face_detect clears between commits is cleared here at once.
//
// SC=2 / SS=3 is measured, board_sim.FaceSmooth replaying all held-out face
// clips through FaceTrack(6): per-frame jump p90 centre 58 -> 31 px, extent
// 67 -> 17 px, centre error vs Haar p50 0.051 -> 0.054 of the face (i.e. no
// visible lag).  SC=3 halves the jump again but the error grows to 0.071 --
// the box starts trailing a moving head.  !! board_sim.FaceSmooth is the bit-
// exact reference (fsmtb); change both or neither.
//
// With SC != SS the two edges are no longer a convex mix of old and new edges,
// so an edge can leave the frame by a few pixels -- hence the clamps.
//
// PUBLICATION IS ATOMIC (3.-14 again): the pass reads the old shown set,
// builds the new one in p_* / po_*, and out_* take it in one clock.  ~37
// clocks after pub, once per sweep.  Old boxes stay on screen until then.
//---------------------------------------------------------------------------
module face_smooth #(
parameter integer NROI   = 4,       // the 2-bit indices below assume 4
parameter integer SC     = 2,       // centre step 1/2^SC
parameter integer SS     = 3,       // extent step 1/2^SS
parameter integer CLIP_W = 1920,
parameter integer CLIP_H = 1080
)(
input  wire        clk,
input  wire        rst_n,
input  wire        en,              // low: forget everything, show nothing
input  wire        pub,
input  wire [NROI*12-1:0] in_x0,
input  wire [NROI*12-1:0] in_x1,
input  wire [NROI*12-1:0] in_y0,
input  wire [NROI*12-1:0] in_y1,
input  wire [NROI-1:0]    in_vld,
output reg  [NROI*12-1:0] out_x0,
output reg  [NROI*12-1:0] out_x1,
output reg  [NROI*12-1:0] out_y0,
output reg  [NROI*12-1:0] out_y1,
output reg  [NROI-1:0]    out_vld
);

localparam integer F = 4;           // fraction bits: a 1-px error still moves at SS <= 4

localparam [2:0] S_IDLE = 3'd0,
                 S_LD   = 3'd1,     // new box i -> n_*
                 S_CMP  = 3'd2,     // old shown boxes, one per clock, compared a clock later
                 S_D    = 3'd3,     // error to the matched box
                 S_ACC  = 3'd4,     // IIR step (or snap)
                 S_OUT  = 3'd5,     // integer box + clamps, into slot i of the new set
                 S_COM  = 3'd6;     // commit

reg [2:0] st;
reg [1:0] i, j, r_j, m_k;
reg       m_hit, r_v, r_ok, n_v;

// memory = the set shown at the last commit (d_vld is NOT touched by clears)
reg [15:0] d_cx [0:NROI-1];         // 2*centre << F
reg [15:0] d_cy [0:NROI-1];
reg [15:0] d_sx [0:NROI-1];         // (x1-x0) << F
reg [15:0] d_sy [0:NROI-1];
reg [NROI-1:0] d_vld;

// the new set under construction
reg [15:0] p_cx [0:NROI-1];
reg [15:0] p_cy [0:NROI-1];
reg [15:0] p_sx [0:NROI-1];
reg [15:0] p_sy [0:NROI-1];
reg [NROI*12-1:0] po_x0, po_x1, po_y0, po_y1;
reg [NROI-1:0]    p_v;

reg [11:0] n_x0, n_x1, n_y0, n_y1;  // new box i
reg [11:0] r_x0, r_x1, r_y0, r_y1;  // old shown box r_j
reg [15:0] t_cx, t_cy, t_sx, t_sy;  // new box i in state units
reg [15:0] b_cx, b_cy, b_sx, b_sy;  // the matched old state
reg signed [16:0] e_cx, e_cy, e_sx, e_sy;
reg [15:0] s_cx, s_cy, s_sx, s_sy;  // slot i's new state

// either centre inside the other, compared at 2x (face_detect's NMS rule)
wire [12:0] n_c2x = {1'b0, n_x0} + {1'b0, n_x1};
wire [12:0] n_c2y = {1'b0, n_y0} + {1'b0, n_y1};
wire [12:0] r_c2x = {1'b0, r_x0} + {1'b0, r_x1};
wire [12:0] r_c2y = {1'b0, r_y0} + {1'b0, r_y1};
wire n_in_r = (n_c2x >= {r_x0, 1'b0}) && (n_c2x <= {r_x1, 1'b0})
           && (n_c2y >= {r_y0, 1'b0}) && (n_c2y <= {r_y1, 1'b0});
wire r_in_n = (r_c2x >= {n_x0, 1'b0}) && (r_c2x <= {n_x1, 1'b0})
           && (r_c2y >= {n_y0, 1'b0}) && (r_c2y <= {n_y1, 1'b0});
wire m_now  = r_ok && (n_in_r || r_in_n);

// the steps, in their own signed wires so >>> stays arithmetic
wire signed [16:0] st_cx = e_cx >>> SC;
wire signed [16:0] st_cy = e_cy >>> SC;
wire signed [16:0] st_sx = e_sx >>> SS;
wire signed [16:0] st_sy = e_sy >>> SS;

// integer box from slot i's new state; the low edge floors at 0, the high clamps
wire signed [17:0] lo_x = $signed({2'b0, s_cx}) - $signed({2'b0, s_sx});
wire signed [17:0] lo_y = $signed({2'b0, s_cy}) - $signed({2'b0, s_sy});
wire        [16:0] hi_x = {1'b0, s_cx} + {1'b0, s_sx};
wire        [16:0] hi_y = {1'b0, s_cy} + {1'b0, s_sy};
wire [11:0] o_x0 = lo_x[17] ? 12'd0 : lo_x[16:5];
wire [11:0] o_y0 = lo_y[17] ? 12'd0 : lo_y[16:5];
wire [11:0] o_x1 = (hi_x[16:5] > CLIP_W - 1) ? CLIP_W[11:0] - 12'd1 : hi_x[16:5];
wire [11:0] o_y1 = (hi_y[16:5] > CLIP_H - 1) ? CLIP_H[11:0] - 12'd1 : hi_y[16:5];

integer k;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        st      <= S_IDLE;
        i       <= 2'd0;  j <= 2'd0;  r_j <= 2'd0;  m_k <= 2'd0;
        m_hit   <= 1'b0;  r_v <= 1'b0;  r_ok <= 1'b0;  n_v <= 1'b0;
        d_vld   <= {NROI{1'b0}};
        p_v     <= {NROI{1'b0}};
        out_vld <= {NROI{1'b0}};
        out_x0  <= {NROI*12{1'b0}};  out_x1 <= {NROI*12{1'b0}};
        out_y0  <= {NROI*12{1'b0}};  out_y1 <= {NROI*12{1'b0}};
        po_x0   <= {NROI*12{1'b0}};  po_x1  <= {NROI*12{1'b0}};
        po_y0   <= {NROI*12{1'b0}};  po_y1  <= {NROI*12{1'b0}};
        n_x0 <= 12'd0;  n_x1 <= 12'd0;  n_y0 <= 12'd0;  n_y1 <= 12'd0;
        r_x0 <= 12'd0;  r_x1 <= 12'd0;  r_y0 <= 12'd0;  r_y1 <= 12'd0;
        t_cx <= 16'd0;  t_cy <= 16'd0;  t_sx <= 16'd0;  t_sy <= 16'd0;
        b_cx <= 16'd0;  b_cy <= 16'd0;  b_sx <= 16'd0;  b_sy <= 16'd0;
        e_cx <= 17'sd0; e_cy <= 17'sd0; e_sx <= 17'sd0; e_sy <= 17'sd0;
        s_cx <= 16'd0;  s_cy <= 16'd0;  s_sx <= 16'd0;  s_sy <= 16'd0;
        for (k = 0; k < NROI; k = k + 1) begin
            d_cx[k] <= 16'd0;  d_cy[k] <= 16'd0;  d_sx[k] <= 16'd0;  d_sy[k] <= 16'd0;
            p_cx[k] <= 16'd0;  p_cy[k] <= 16'd0;  p_sx[k] <= 16'd0;  p_sy[k] <= 16'd0;
        end
    end else if (!en) begin
        st      <= S_IDLE;
        d_vld   <= {NROI{1'b0}};
        out_vld <= {NROI{1'b0}};
    end else begin
        case (st)
        S_IDLE: begin
            if (pub) begin
                i  <= 2'd0;
                st <= S_LD;
            end else begin
                // face_detect's roi clear (only ever clears).  Not during a
                // pass: there out_* is the OLD set and in_vld the new one.
                out_vld <= out_vld & in_vld;
            end
        end

        S_LD: begin
            n_x0  <= in_x0[i*12 +: 12];
            n_x1  <= in_x1[i*12 +: 12];
            n_y0  <= in_y0[i*12 +: 12];
            n_y1  <= in_y1[i*12 +: 12];
            n_v   <= in_vld[i];
            j     <= 2'd0;
            r_v   <= 1'b0;
            m_hit <= 1'b0;
            st    <= S_CMP;
        end

        S_CMP: begin
            t_cx <= {n_c2x[11:0], 4'b0};
            t_cy <= {n_c2y[11:0], 4'b0};
            t_sx <= {n_x1 - n_x0, 4'b0};
            t_sy <= {n_y1 - n_y0, 4'b0};
            // stage 1: register old shown box j
            r_x0 <= out_x0[j*12 +: 12];
            r_x1 <= out_x1[j*12 +: 12];
            r_y0 <= out_y0[j*12 +: 12];
            r_y1 <= out_y1[j*12 +: 12];
            r_ok <= d_vld[j];
            r_j  <= j;
            r_v  <= 1'b1;
            if (j != 2'd3) j <= j + 2'd1;
            // stage 2: compare box r_j; the first match wins
            if (r_v) begin
                if (m_now && !m_hit) begin
                    m_hit <= 1'b1;
                    m_k   <= r_j;
                end
                if (r_j == 2'd3) st <= S_D;
            end
        end

        S_D: begin
            b_cx <= d_cx[m_k];  b_cy <= d_cy[m_k];
            b_sx <= d_sx[m_k];  b_sy <= d_sy[m_k];
            e_cx <= $signed({1'b0, t_cx}) - $signed({1'b0, d_cx[m_k]});
            e_cy <= $signed({1'b0, t_cy}) - $signed({1'b0, d_cy[m_k]});
            e_sx <= $signed({1'b0, t_sx}) - $signed({1'b0, d_sx[m_k]});
            e_sy <= $signed({1'b0, t_sy}) - $signed({1'b0, d_sy[m_k]});
            st   <= S_ACC;
        end

        // b + step lands between b and the target, so 16 bits of the modular
        // sum are the exact result.
        S_ACC: begin
            s_cx <= m_hit ? b_cx + st_cx[15:0] : t_cx;
            s_cy <= m_hit ? b_cy + st_cy[15:0] : t_cy;
            s_sx <= m_hit ? b_sx + st_sx[15:0] : t_sx;
            s_sy <= m_hit ? b_sy + st_sy[15:0] : t_sy;
            st   <= S_OUT;
        end

        S_OUT: begin
            p_cx[i] <= s_cx;  p_cy[i] <= s_cy;
            p_sx[i] <= s_sx;  p_sy[i] <= s_sy;
            p_v[i]  <= n_v;
            po_x0[i*12 +: 12] <= o_x0;
            po_x1[i*12 +: 12] <= o_x1;
            po_y0[i*12 +: 12] <= o_y0;
            po_y1[i*12 +: 12] <= o_y1;
            if (i == 2'd3) st <= S_COM;
            else begin
                i  <= i + 2'd1;
                st <= S_LD;
            end
        end

        S_COM: begin
            for (k = 0; k < NROI; k = k + 1) begin
                d_cx[k] <= p_cx[k];  d_cy[k] <= p_cy[k];
                d_sx[k] <= p_sx[k];  d_sy[k] <= p_sy[k];
            end
            d_vld   <= p_v;
            out_x0  <= po_x0;  out_x1 <= po_x1;
            out_y0  <= po_y0;  out_y1 <= po_y1;
            out_vld <= p_v;
            st      <= S_IDLE;
        end

        default: st <= S_IDLE;
        endcase
    end
end

endmodule
