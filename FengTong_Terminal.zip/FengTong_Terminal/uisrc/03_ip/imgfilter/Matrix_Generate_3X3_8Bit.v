module Matrix_Generate_3X3_8Bit
#(
    parameter   [10:0]  IMG_HDISP = 11'd1280,            //  ͼ����ȣ�1280*720@60Hz
    parameter   [10:0]  IMG_VDISP = 11'd720,
    parameter   [10:0]  DELAY_NUM = 11'd10              //  �����ڶ��е����һ��֮��ļ������
)
(  
    //  ȫ��ʱ���븴λ
    input  wire                 clk                     ,
    input  wire                 rst_n                   ,
    
    //  ������ͼ����������
    input  wire                 per_img_vsync           ,   //  ����ͼ��ͬ����Ч�ź�
    input  wire                 per_img_href            ,   //  ����ͼ������Ч�ź�
    input  wire     [7:0]       per_img_gray            ,   //  ����Ҷ�ͼ������
    
    //  �������ͼ���������
    output wire                 matrix_img_vsync        ,   //  ���ͼ��ͬ����Ч�ź�
    output wire                 matrix_img_href         ,   //  ���ͼ������Ч�ź�
    output wire                 matrix_top_edge_flag    ,   //  ���ͼ���ϱ߽��־
    output wire                 matrix_bottom_edge_flag ,   //  ���ͼ���±߽��־
    output wire                 matrix_left_edge_flag   ,   //  ���ͼ����߽��־
    output wire                 matrix_right_edge_flag  ,   //  ���ͼ���ұ߽��־
    output reg      [7:0]       matrix_p11              ,   //  3X3 �������
    output reg      [7:0]       matrix_p12              ,
    output reg      [7:0]       matrix_p13              ,
    output reg      [7:0]       matrix_p21              ,
    output reg      [7:0]       matrix_p22              ,
    output reg      [7:0]       matrix_p23              ,
    output reg      [7:0]       matrix_p31              ,  
    output reg      [7:0]       matrix_p32              ,
    output reg      [7:0]       matrix_p33              
);
//----------------------------------------------------------------------
//  href �� vsync ������
reg             [10:0]          hcnt;

always @(posedge clk or negedge rst_n)
begin
    if(!rst_n)
        hcnt <= 11'b0;
    else
    begin
        if(per_img_href == 1'b1)
            hcnt <= hcnt + 1'b1;
        else
            hcnt <= 11'b0;
    end
end

reg                             per_img_href_dly;

always @(posedge clk or negedge rst_n)
begin
    if(!rst_n)
        per_img_href_dly <= 1'b0;
    else
        per_img_href_dly <= per_img_href;
end

wire img_href_neg = ~per_img_href & per_img_href_dly;       //  per_img_href ���½���

reg             [10:0]          vcnt;

always @(posedge clk or negedge rst_n)
begin
    if(!rst_n)
        vcnt <= 11'b0;
    else
    begin
        if(per_img_vsync == 1'b0)
            vcnt <= 11'b0;
        else if(img_href_neg == 1'b1)
            vcnt <= vcnt + 1'b1;
        else
            vcnt <= vcnt;
    end
end

//----------------------------------------------------------------------
//  ʹ������ FIFO ��Ϊԭʼ�����л���
reg             [12:0]          extend_last_row_cnt;

always @(posedge clk or negedge rst_n)
begin
    if(!rst_n)
        extend_last_row_cnt <= 13'b0;
    else
    begin
        if((per_img_href == 1'b1)&&(vcnt == IMG_VDISP - 1'b1)&&(hcnt == IMG_HDISP - 1'b1))
            extend_last_row_cnt <= 13'd1;
        else if((extend_last_row_cnt > 13'b0)&&(extend_last_row_cnt < DELAY_NUM + IMG_HDISP))
            extend_last_row_cnt <= extend_last_row_cnt + 1'b1;
        else
            extend_last_row_cnt <= 13'b0;
    end
end

wire extend_last_row_en = (extend_last_row_cnt > DELAY_NUM) ? 1'b1 : 1'b0;

wire                            fifo1_wenb;
wire            [7:0]           fifo1_wdata;
wire                            fifo1_renb;
wire            [7:0]           fifo1_rdata;

wire                            fifo2_wenb;
wire            [7:0]           fifo2_wdata;
wire                            fifo2_renb;
wire            [7:0]           fifo2_rdata;

assign fifo1_wenb  = per_img_href;
assign fifo1_wdata = per_img_gray;
assign fifo1_renb  = per_img_href & (vcnt > 11'b0) | extend_last_row_en;

assign fifo2_wenb  = per_img_href & (vcnt > 11'b0);
assign fifo2_wdata = fifo1_rdata;
assign fifo2_renb  = per_img_href & (vcnt > 11'b1) | extend_last_row_en;


//8-2048
//fifo_sync_0 sync_fifo_u1 (
//		.clock (clk),          //input    clock
//		.data (fifo1_wdata),            //input    [7:0]    data
//		.rdreq (fifo1_renb),          //input    rdreq
//		.wrreq (fifo1_wenb),          //input    wrreq
//		.sclr (sclr),            //input    sclr
//		.empty (),          //output    empty
//		.full (),            //output    full
//		.usedw (),          //output    [10:0]    usedw
//		.q (fifo1_rdata)                   //output    [7:0]    q
//);
//
//fifo_sync_0 sync_fifo_u2 (
//		.clock (clk),          //input    clock
//		.data (fifo2_wdata),            //input    [7:0]    data
//		.rdreq (fifo2_renb),          //input    rdreq
//		.wrreq (fifo2_wenb),          //input    wrreq
//		.sclr (sclr),            //input    sclr
//		.empty (),          //output    empty
//		.full (),            //output    full
//		.usedw (),          //output    [10:0]    usedw
//		.q (fifo2_rdata)                   //output    [7:0]    q
//);
 fifo_bil_filter u1_fifo (
     .aclr   (~rst_n     ),
     .clock  (clk        ),
     .data   (fifo1_wdata),
     .rdreq  (fifo1_renb ),
     .wrreq  (fifo1_wenb ),
     .empty  (           ),
     .full   (           ),
     .usedw  (           ),
     .q      (fifo1_rdata)
 );

 fifo_bil_filter u2_fifo (
     .aclr   (~rst_n     ),
     .clock  (clk        ),
     .data   (fifo2_wdata),
     .rdreq  (fifo2_renb ),
     .wrreq  (fifo2_wenb ),
     .empty  (           ),
     .full   (           ),
     .usedw  (           ),
     .q      (fifo2_rdata)
 );

//----------------------------------------------------------------------
//  �� FIFO �������ݣ��γ� 3x3 ����
always @(posedge clk or negedge rst_n)
begin
    if(!rst_n)
    begin
        {matrix_p11, matrix_p12, matrix_p13} <= 24'h0;
        {matrix_p21, matrix_p22, matrix_p23} <= 24'h0;
        {matrix_p31, matrix_p32, matrix_p33} <= 24'h0;
    end
    else
    begin
        {matrix_p11, matrix_p12, matrix_p13} <= {matrix_p12, matrix_p13, fifo2_rdata};      //  �� 1 ������
        {matrix_p21, matrix_p22, matrix_p23} <= {matrix_p22, matrix_p23, fifo1_rdata};      //  �� 2 ������
        {matrix_p31, matrix_p32, matrix_p33} <= {matrix_p32, matrix_p33, per_img_gray};     //  �� 3 ������
    end
end

reg             [1:0]           vsync;
reg             [1:0]           href;
reg             [1:0]           top_edge_flag;
reg             [1:0]           bottom_edge_flag;
reg             [1:0]           left_edge_flag;
reg             [1:0]           right_edge_flag;

always @(posedge clk or negedge rst_n)
begin
    if(!rst_n)
        vsync <= 2'b0;
    else
    begin
        if((per_img_href == 1'b1)&&(vcnt == 11'd1)&&(hcnt == 11'b0))
            vsync[0] <= 1'b1;
        else if(extend_last_row_cnt == DELAY_NUM + IMG_HDISP)//�ȴ�һ���� href ���ߺ��پ��� 1290 ��ʱ�������� vsync����֤���һ������Ҳ�ܱ�����
            vsync[0] <= 1'b0;
        else
            vsync[0] <= vsync[0];
        vsync[1] <= vsync[0];
    end
end

always @(posedge clk or negedge rst_n)
begin
    if(!rst_n)
    begin
        href             <= 2'b0;
        top_edge_flag    <= 2'b0;
        bottom_edge_flag <= 2'b0;
        left_edge_flag   <= 2'b0;
        right_edge_flag  <= 2'b0;
    end
    else
    begin
        href[0]             <= per_img_href & (vcnt > 11'b0) | extend_last_row_en;
        href[1]             <= href[0];
        top_edge_flag[0]    <= per_img_href & (vcnt == 11'd1);
        top_edge_flag[1]    <= top_edge_flag[0];
        bottom_edge_flag[0] <= extend_last_row_en;
        bottom_edge_flag[1] <= bottom_edge_flag[0];
        left_edge_flag[0]   <= per_img_href & (vcnt > 11'b0) & (hcnt == 11'b0) | (extend_last_row_cnt == DELAY_NUM + 1'b1);
        left_edge_flag[1]   <= left_edge_flag[0];
        right_edge_flag[0]  <= per_img_href & (vcnt > 11'b0) & (hcnt == IMG_HDISP - 1'b1) | (extend_last_row_cnt == DELAY_NUM + IMG_HDISP);
        right_edge_flag[1]  <= right_edge_flag[0];
    end
end

assign matrix_img_vsync        = vsync[1];
assign matrix_img_href         = href[1];
assign matrix_top_edge_flag    = top_edge_flag[1];
assign matrix_bottom_edge_flag = bottom_edge_flag[1];
assign matrix_left_edge_flag   = left_edge_flag[1];
assign matrix_right_edge_flag  = right_edge_flag[1];

endmodule