//---------------------------------------------------------------------------
// fifo_bil_filter -- portable replacement for the Altera scfifo wrapper the
// source project used as a line buffer inside Matrix_Generate_3X3/5X5_8Bit.
//
// The original (sources_1/ip/fifo_bil_filter/fifo_bil_filter.v) was:
//     scfifo, 8 bit x 2048, lpm_showahead = "ON",
//     add_ram_output_register = "ON", lpm_hint = "RAM_BLOCK_TYPE=M4K"
// none of which Anlogic TD understands.
//
// Show-ahead (FWFT) is NOT optional here: Matrix_Generate_3X3_8Bit.v line 180
// latches q in the SAME cycle it asserts rdreq.  A standard (non-FWFT) FIFO
// would slide every line buffer by one pixel -- the picture still comes up,
// it just goes soft along edges, so that kind of bug is easy to miss.
//
// Built as a read-ahead ring buffer so the storage infers block RAM.  A
// continuously addressed asynchronous read would infer distributed RAM
// instead, and 14 instances x 16 Kibit of LUT RAM does not fit the part.
//
// One 1080p line is 1920 entries, well inside the 2048 depth, so the depth
// carries over from 720p unchanged.
//---------------------------------------------------------------------------
`timescale 1ns/1ns

module fifo_bil_filter #(
    parameter integer DWIDTH = 8,
    parameter integer AWIDTH = 11
)(
    input  wire                 aclr,
    input  wire                 clock,
    input  wire [DWIDTH-1:0]    data,
    input  wire                 rdreq,
    input  wire                 wrreq,
    output wire                 empty,
    output wire                 full,
    output wire [AWIDTH-1:0]    usedw,
    output wire [DWIDTH-1:0]    q
);

    localparam integer DEPTH = (1 << AWIDTH);

    reg  [DWIDTH-1:0] mem [0:DEPTH-1];

    reg  [AWIDTH-1:0] wr_ptr;
    reg  [AWIDTH-1:0] rd_ptr;
    reg  [AWIDTH  :0] count;

    wire do_wr = wrreq & ~full;
    wire do_rd = rdreq & ~empty;

    assign empty = (count == 0);
    assign full  = (count == DEPTH);
    assign usedw = count[AWIDTH-1:0];

    always @(posedge clock or posedge aclr) begin
        if (aclr) begin
            wr_ptr <= {AWIDTH{1'b0}};
            rd_ptr <= {AWIDTH{1'b0}};
            count  <= {(AWIDTH+1){1'b0}};
        end else begin
            if (do_wr) wr_ptr <= wr_ptr + 1'b1;
            if (do_rd) rd_ptr <= rd_ptr + 1'b1;
            case ({do_wr, do_rd})
                2'b10:   count <= count + 1'b1;
                2'b01:   count <= count - 1'b1;
                default: count <= count;
            endcase
        end
    end

    // No reset on the storage or the output register -- that is what lets the
    // tool map this to block RAM.
    always @(posedge clock) begin
        if (do_wr) mem[wr_ptr] <= data;
    end

    // Read ahead one entry so q always presents the word the next rdreq pops.
    wire [AWIDTH-1:0] rd_addr = do_rd ? (rd_ptr + 1'b1) : rd_ptr;
    reg  [DWIDTH-1:0] q_r;

    always @(posedge clock) begin
        q_r <= mem[rd_addr];
    end

    assign q = q_r;

endmodule
