// =================================================================
//  guided_filter_5x5_proc
//
//  �Ե����˲� (Self-Guided Filter), 5x5 ���� (N = 25), �� 8-bit ͨ��.
//  ���� color_convert ��ʵ���� 3 �� (R/G/B ��һ��) ���ɵõ���ͨ��
//  RGB 5x5 �Ե����˲����.
//
//  --------------------------------------------------------------
//  ��ѧ��ʽ (��ͨ��, �Ե���: I = guide):
//      mean_I  = sum(I)  / N
//      mean_II = sum(I�0�5) / N
//      var_I   = mean_II - mean_I�0�5
//      a       = var_I / (var_I + eps)
//      b       = (1 - a) * mean_I
//      q       = a * I + b
//
//  ������� N: ͨƪ�� N�0�5��var, N��mean, ��:
//      var_N�0�5  = N��sum(I�0�5) - (sum I)�0�5            (= N�0�5��var_I)
//      denom   = var_N�0�5 + N�0�5��eps                 (= N�0�5��(var_I+eps))
//      a       = var_N�0�5 / denom                  (ά������ȷ)
//      mean    �� round(2^16/N) ���Ƴ˷� + ���� 16
//
//  ��ģ��: N = 25, ������ EPS_625 = 625��eps (�������).
//  --------------------------------------------------------------
//  ��ˮ�߽ṹ (���� 3x3 v3 ���, �ڴ���λ���ϱ���һ��):
//      1   : 25 ������ƽ�� + 5 �������غ�
//      2   : 5 ����ƽ���� + �����غ� S
//      3   : T (sum I�0�5) / S�0�5 / mean_raw           (����)
//      4a  : T25 = 25��T  = (T<<4)+(T<<3)+T        (�������һ��, �� 3 ���ӷ���)
//      4b  : var625 = T25-S�0�5 / denom = +EPS / mean
//      5a  : �� denom ��/�� 13-bit ���� + ������־   (�� 26-bit ���ȱ���)
//      5b  : �߰�����Ͱ������� 13-bit ���ȱ���     (�� div_shift / div_norm)
//      6   : ���� LUT (recip �� 16384/div_norm, 8-bit)
//      7   : product = var625 �� recip             (34-bit)
//      8   : a_Q10 = product >> (4+div_shift), ���͵� 1024
//      9   : a��I �� (1-a)��mean �����˷� (�õ� 10 �ĵ��������� p33)
//      10  : ��� + ���� 10 �õ� 8-bit �˲�����
//      out : ����Ĵ��� (����Ե bypass ѡ��)
//  C_LATENCY = 12 (10 ����ˮ�� + 4a / 5a ����һ��)
//  �ⲿ SYNC_DLY = �������� 3 �� + 12 �� + 1 ����� = 16 ��
//
//  --------------------------------------------------------------
//  λ���Ƶ� (N=25, 8-bit ����):
//    sq_ij:           16      (max 65025)
//    row_sum_p_i:     11      (max 5*255 = 1275)
//    row_sum_sq_i:    19      (max 5*65025 = 325125)
//    S:               13      (max 25*255 = 6375)
//    T:               21      (max 25*65025 = 1,625,625)
//    S�0�5:              26      (max 6375�0�5 = 40,640,625)
//    T25:             26      (max 25*T = 40,640,625)
//    mean_raw:        25      (S * 2622, max 6375*2622 = 16,715,250)
//    EPS_625:         22      (����, �Ƽ� 100k ~ 1M)
//    var625:          26      (���� max �� 12��13��65025 �� 10.1M)
//    denom:           26      (max var625 + max EPS_625 < 2^26)
//    recip:           8       (1/x ���)
//    product:         34      (= 26 + 8)
//    a_Q10:           11      (���͵� 1024)
//    a*I, (1-a)*mean: 19      (= 11 + 8)
// =================================================================
module guided_filter_5x5_proc
#(
    parameter   [10:0]  IMG_HDISP = 11'd1280,
    parameter   [10:0]  IMG_VDISP = 11'd720,
    // ���򻯲��� eps �� 625 �� (��Ϊ N�0�5=625, �� 625��var ������� 25).
    // Ĭ�� 22'd524288 (�� 2^19, eps��839, ǿƽ��չʾ, �� 3x3 ǿ���൱).
    // �Ƽ���λ (eps Խ��Խƽ��):
    //   eps�� 200 ->  22'd125000   (����)
    //   eps�� 500 ->  22'd312500   (��)
    //   eps�� 800 ->  22'd500000   (��ǿ)
    //   eps��1500 ->  22'd937500   (ǿ)
    //   eps��2500 ->  22'd1562500  (��ǿ, �ӽ���ֵ�˲�)
    parameter   [21:0]  EPS_625   = 22'd524288
)
(
    input  wire                 clk             ,
    input  wire                 rst_n           ,
    input  wire                 per_img_vsync   ,
    input  wire                 per_img_href    ,
    input  wire     [7:0]       per_img_gray    ,
    output reg                  post_img_vsync  ,
    output reg                  post_img_href   ,
    output reg      [7:0]       post_img_gray
);

// ============================================================
// 5x5 ��������
// ============================================================
wire                            matrix_img_vsync;
wire                            matrix_img_href;
wire                            matrix_top_edge_flag;
wire                            matrix_bottom_edge_flag;
wire                            matrix_left_edge_flag;
wire                            matrix_right_edge_flag;
wire            [7:0]           matrix_p11, matrix_p12, matrix_p13, matrix_p14, matrix_p15;
wire            [7:0]           matrix_p21, matrix_p22, matrix_p23, matrix_p24, matrix_p25;
wire            [7:0]           matrix_p31, matrix_p32, matrix_p33, matrix_p34, matrix_p35;
wire            [7:0]           matrix_p41, matrix_p42, matrix_p43, matrix_p44, matrix_p45;
wire            [7:0]           matrix_p51, matrix_p52, matrix_p53, matrix_p54, matrix_p55;

Matrix_Generate_5X5_8Bit
#(
    .IMG_HDISP  (IMG_HDISP  ),
    .IMG_VDISP  (IMG_VDISP  )
)
u_Matrix_Generate_5X5_8Bit
(
    .clk                    (clk                    ),
    .rst_n                  (rst_n                  ),
    .per_img_vsync          (per_img_vsync          ),
    .per_img_href           (per_img_href           ),
    .per_img_gray           (per_img_gray           ),
    .matrix_img_vsync       (matrix_img_vsync       ),
    .matrix_img_href        (matrix_img_href        ),
    .matrix_top_edge_flag   (matrix_top_edge_flag   ),
    .matrix_bottom_edge_flag(matrix_bottom_edge_flag),
    .matrix_left_edge_flag  (matrix_left_edge_flag  ),
    .matrix_right_edge_flag (matrix_right_edge_flag ),
    .matrix_p11(matrix_p11), .matrix_p12(matrix_p12), .matrix_p13(matrix_p13), .matrix_p14(matrix_p14), .matrix_p15(matrix_p15),
    .matrix_p21(matrix_p21), .matrix_p22(matrix_p22), .matrix_p23(matrix_p23), .matrix_p24(matrix_p24), .matrix_p25(matrix_p25),
    .matrix_p31(matrix_p31), .matrix_p32(matrix_p32), .matrix_p33(matrix_p33), .matrix_p34(matrix_p34), .matrix_p35(matrix_p35),
    .matrix_p41(matrix_p41), .matrix_p42(matrix_p42), .matrix_p43(matrix_p43), .matrix_p44(matrix_p44), .matrix_p45(matrix_p45),
    .matrix_p51(matrix_p51), .matrix_p52(matrix_p52), .matrix_p53(matrix_p53), .matrix_p54(matrix_p54), .matrix_p55(matrix_p55)
);

// ============================================================
// ��ˮ�ߵ� 1 ��: 25 ������ƽ�� + 5 �������غ� (1 ��)
// ============================================================
reg [15:0] sq11, sq12, sq13, sq14, sq15;
reg [15:0] sq21, sq22, sq23, sq24, sq25;
reg [15:0] sq31, sq32, sq33, sq34, sq35;
reg [15:0] sq41, sq42, sq43, sq44, sq45;
reg [15:0] sq51, sq52, sq53, sq54, sq55;
reg [10:0] row_sum_p1, row_sum_p2, row_sum_p3, row_sum_p4, row_sum_p5;

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        {sq11, sq12, sq13, sq14, sq15} <= 80'd0;
        {sq21, sq22, sq23, sq24, sq25} <= 80'd0;
        {sq31, sq32, sq33, sq34, sq35} <= 80'd0;
        {sq41, sq42, sq43, sq44, sq45} <= 80'd0;
        {sq51, sq52, sq53, sq54, sq55} <= 80'd0;
        row_sum_p1 <= 11'd0; row_sum_p2 <= 11'd0; row_sum_p3 <= 11'd0;
        row_sum_p4 <= 11'd0; row_sum_p5 <= 11'd0;
    end else begin
        sq11 <= matrix_p11 * matrix_p11;  sq12 <= matrix_p12 * matrix_p12;  sq13 <= matrix_p13 * matrix_p13;
        sq14 <= matrix_p14 * matrix_p14;  sq15 <= matrix_p15 * matrix_p15;
        sq21 <= matrix_p21 * matrix_p21;  sq22 <= matrix_p22 * matrix_p22;  sq23 <= matrix_p23 * matrix_p23;
        sq24 <= matrix_p24 * matrix_p24;  sq25 <= matrix_p25 * matrix_p25;
        sq31 <= matrix_p31 * matrix_p31;  sq32 <= matrix_p32 * matrix_p32;  sq33 <= matrix_p33 * matrix_p33;
        sq34 <= matrix_p34 * matrix_p34;  sq35 <= matrix_p35 * matrix_p35;
        sq41 <= matrix_p41 * matrix_p41;  sq42 <= matrix_p42 * matrix_p42;  sq43 <= matrix_p43 * matrix_p43;
        sq44 <= matrix_p44 * matrix_p44;  sq45 <= matrix_p45 * matrix_p45;
        sq51 <= matrix_p51 * matrix_p51;  sq52 <= matrix_p52 * matrix_p52;  sq53 <= matrix_p53 * matrix_p53;
        sq54 <= matrix_p54 * matrix_p54;  sq55 <= matrix_p55 * matrix_p55;

        row_sum_p1 <= ((matrix_p11 + matrix_p12) + (matrix_p13 + matrix_p14)) + matrix_p15;
        row_sum_p2 <= ((matrix_p21 + matrix_p22) + (matrix_p23 + matrix_p24)) + matrix_p25;
        row_sum_p3 <= ((matrix_p31 + matrix_p32) + (matrix_p33 + matrix_p34)) + matrix_p35;
        row_sum_p4 <= ((matrix_p41 + matrix_p42) + (matrix_p43 + matrix_p44)) + matrix_p45;
        row_sum_p5 <= ((matrix_p51 + matrix_p52) + (matrix_p53 + matrix_p54)) + matrix_p55;
    end
end

// ============================================================
// ��ˮ�ߵ� 2 ��: 5 ����ƽ���� + �����غ� S (1 ��)
// ============================================================
reg [18:0] row_sum_sq1, row_sum_sq2, row_sum_sq3, row_sum_sq4, row_sum_sq5;
reg [12:0] S;

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        row_sum_sq1 <= 19'd0; row_sum_sq2 <= 19'd0; row_sum_sq3 <= 19'd0;
        row_sum_sq4 <= 19'd0; row_sum_sq5 <= 19'd0;
        S <= 13'd0;
    end else begin
        row_sum_sq1 <= ((sq11 + sq12) + (sq13 + sq14)) + sq15;
        row_sum_sq2 <= ((sq21 + sq22) + (sq23 + sq24)) + sq25;
        row_sum_sq3 <= ((sq31 + sq32) + (sq33 + sq34)) + sq35;
        row_sum_sq4 <= ((sq41 + sq42) + (sq43 + sq44)) + sq45;
        row_sum_sq5 <= ((sq51 + sq52) + (sq53 + sq54)) + sq55;
        S           <= ((row_sum_p1 + row_sum_p2) + (row_sum_p3 + row_sum_p4)) + row_sum_p5;
    end
end

// ============================================================
// ��ˮ�ߵ� 3 ��: T (sum I�0�5), S�0�5, mean_raw ���м��� (1 ��)
//   mean_factor 12'd2622 �� round(2^16 / 25)
//   ѡ 2622 ���� 2621: ʹ S=6375 ʱ mean = 255 (���� 254), S=25 ʱ mean = 1
// ============================================================
reg [20:0] T;
reg [25:0] S_sq;
reg [24:0] mean_raw;

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        T <= 21'd0; S_sq <= 26'd0; mean_raw <= 25'd0;
    end else begin
        T        <= ((row_sum_sq1 + row_sum_sq2) + (row_sum_sq3 + row_sum_sq4)) + row_sum_sq5;
        S_sq     <= S * S;
        mean_raw <= S * 12'd2622;
    end
end

// ============================================================
// ��ˮ�ߵ� 4a ��: T25 = 25��T ������һ�� (1 ��)
//   = (T<<4) + (T<<3) + T = 16T + 8T + T  (3-input �ӷ�, �ۺϺ� 2 ���ӷ���)
//   �Ͽ� T �� 25T �� -S�0�5 �� +EPS_625 ���� 3 �� 26-bit �ӷ���.
// ============================================================
reg [25:0] T25;
reg [25:0] S_sq_s4;
reg [24:0] mean_raw_s4;

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        T25 <= 26'd0; S_sq_s4 <= 26'd0; mean_raw_s4 <= 25'd0;
    end else begin
        T25         <= {T, 4'b0} + {T, 3'b0} + T;       // 16T + 8T + T = 25T
        S_sq_s4     <= S_sq;
        mean_raw_s4 <= mean_raw;
    end
end

// ============================================================
// ��ˮ�ߵ� 4b ��: var625, denom, mean (1 ��)
// ============================================================
reg [25:0] var625;
reg [25:0] denom;
reg [7:0]  mean;

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        var625 <= 26'd0; denom <= 26'd0; mean <= 8'd0;
    end else begin
        var625 <= T25 - S_sq_s4;
        denom  <= T25 - S_sq_s4 + {4'b0, EPS_625};
        mean   <= mean_raw_s4[23:16];                    // mean_raw / 2^16
    end
end

// ============================================================
// ��ˮ�ߵ� 5a ��: �� denom ��/�� 13-bit ���� + ������־ (1 ��)
// ============================================================
reg        denom_top_half_r5a;       // 1 = MSB �� [25:13], 0 = MSB �� [12:0]
reg [12:0] denom_top_r5a;            // denom[25:13]
reg [12:0] denom_bot_r5a;            // denom[12:0]
reg [25:0] var625_r5a;
reg [7:0]  mean_r5a;

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        denom_top_half_r5a <= 1'b0;
        denom_top_r5a <= 13'd0; denom_bot_r5a <= 13'd0;
        var625_r5a <= 26'd0; mean_r5a <= 8'd0;
    end else begin
        denom_top_half_r5a <= |denom[25:13];
        denom_top_r5a      <= denom[25:13];
        denom_bot_r5a      <= denom[12:0];
        var625_r5a         <= var625;
        mean_r5a           <= mean;
    end
end

// ============================================================
// ��ˮ�ߵ� 5b ��: ����ѡ���İ������� 13-bit ���ȱ��� (1 ��)
//   ÿ· 13-bit casex (Լ 3 �� LUT), �� 26-bit �������ȱ����Լһ��.
//   div_norm = denom ���� MSB Ϊ���λ�� 8 ������λ (�� MSB '1')
//   div_shift = denom_msb_index - 7
// ============================================================
reg [4:0]  div_shift_comb;
reg [7:0]  div_norm_comb;

always @(*) begin
    if(denom_top_half_r5a) begin
        // MSB ���� denom[25:13], shift ��Χ 6..18
        casex(denom_top_r5a)
            13'b1????????????: begin div_shift_comb = 5'd18; div_norm_comb = denom_top_r5a[12:5]; end
            13'b01???????????: begin div_shift_comb = 5'd17; div_norm_comb = denom_top_r5a[11:4]; end
            13'b001??????????: begin div_shift_comb = 5'd16; div_norm_comb = denom_top_r5a[10:3]; end
            13'b0001?????????: begin div_shift_comb = 5'd15; div_norm_comb = denom_top_r5a[9:2];  end
            13'b00001????????: begin div_shift_comb = 5'd14; div_norm_comb = denom_top_r5a[8:1];  end
            13'b000001???????: begin div_shift_comb = 5'd13; div_norm_comb = denom_top_r5a[7:0];  end
            13'b0000001??????: begin div_shift_comb = 5'd12; div_norm_comb = {denom_top_r5a[6:0], denom_bot_r5a[12]};       end
            13'b00000001?????: begin div_shift_comb = 5'd11; div_norm_comb = {denom_top_r5a[5:0], denom_bot_r5a[12:11]};    end
            13'b000000001????: begin div_shift_comb = 5'd10; div_norm_comb = {denom_top_r5a[4:0], denom_bot_r5a[12:10]};    end
            13'b0000000001???: begin div_shift_comb = 5'd9;  div_norm_comb = {denom_top_r5a[3:0], denom_bot_r5a[12:9]};     end
            13'b00000000001??: begin div_shift_comb = 5'd8;  div_norm_comb = {denom_top_r5a[2:0], denom_bot_r5a[12:8]};     end
            13'b000000000001?: begin div_shift_comb = 5'd7;  div_norm_comb = {denom_top_r5a[1:0], denom_bot_r5a[12:7]};     end
            default:           begin div_shift_comb = 5'd6;  div_norm_comb = {denom_top_r5a[0],   denom_bot_r5a[12:6]};     end
        endcase
    end else begin
        // MSB ���� denom[12:0], shift ��Χ 0..5
        casex(denom_bot_r5a)
            13'b1????????????: begin div_shift_comb = 5'd5; div_norm_comb = denom_bot_r5a[12:5]; end
            13'b01???????????: begin div_shift_comb = 5'd4; div_norm_comb = denom_bot_r5a[11:4]; end
            13'b001??????????: begin div_shift_comb = 5'd3; div_norm_comb = denom_bot_r5a[10:3]; end
            13'b0001?????????: begin div_shift_comb = 5'd2; div_norm_comb = denom_bot_r5a[9:2];  end
            13'b00001????????: begin div_shift_comb = 5'd1; div_norm_comb = denom_bot_r5a[8:1];  end
            default:           begin div_shift_comb = 5'd0; div_norm_comb = denom_bot_r5a[7:0];  end
        endcase
    end
end

reg [4:0]  div_shift;
reg [7:0]  div_norm;
reg [25:0] var625_r;
reg [7:0]  mean_r;

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        div_shift <= 5'd0; div_norm <= 8'd0;
        var625_r  <= 26'd0; mean_r  <= 8'd0;
    end else begin
        div_shift <= div_shift_comb;
        div_norm  <= div_norm_comb;
        var625_r  <= var625_r5a;
        mean_r    <= mean_r5a;
    end
end

// ============================================================
// ��ˮ�ߵ� 6 ��: �������ұ� recip �� 16384/div_norm (1 ��)
//   1/x ���� N �޹ص�ͨ��ӳ��, LUT �� 3x3 ���� (�����е� idx*4+2 ����).
// ============================================================
reg [7:0] recip_lut;
always @(*) begin
    case(div_norm[7:2])
        6'd0:  recip_lut = 8'd255; 6'd1:  recip_lut = 8'd255; 6'd2:  recip_lut = 8'd255; 6'd3:  recip_lut = 8'd255;
        6'd4:  recip_lut = 8'd255; 6'd5:  recip_lut = 8'd255; 6'd6:  recip_lut = 8'd255; 6'd7:  recip_lut = 8'd255;
        6'd8:  recip_lut = 8'd255; 6'd9:  recip_lut = 8'd255; 6'd10: recip_lut = 8'd255; 6'd11: recip_lut = 8'd255;
        6'd12: recip_lut = 8'd255; 6'd13: recip_lut = 8'd255; 6'd14: recip_lut = 8'd255; 6'd15: recip_lut = 8'd255;
        6'd16: recip_lut = 8'd248; 6'd17: recip_lut = 8'd234; 6'd18: recip_lut = 8'd221; 6'd19: recip_lut = 8'd210;
        6'd20: recip_lut = 8'd200; 6'd21: recip_lut = 8'd191; 6'd22: recip_lut = 8'd182; 6'd23: recip_lut = 8'd174;
        6'd24: recip_lut = 8'd167; 6'd25: recip_lut = 8'd161; 6'd26: recip_lut = 8'd155; 6'd27: recip_lut = 8'd149;
        6'd28: recip_lut = 8'd144; 6'd29: recip_lut = 8'd139; 6'd30: recip_lut = 8'd134; 6'd31: recip_lut = 8'd130;
        6'd32: recip_lut = 8'd126; 6'd33: recip_lut = 8'd122; 6'd34: recip_lut = 8'd119; 6'd35: recip_lut = 8'd115;
        6'd36: recip_lut = 8'd112; 6'd37: recip_lut = 8'd109; 6'd38: recip_lut = 8'd106; 6'd39: recip_lut = 8'd104;
        6'd40: recip_lut = 8'd101; 6'd41: recip_lut = 8'd99;  6'd42: recip_lut = 8'd96;  6'd43: recip_lut = 8'd94;
        6'd44: recip_lut = 8'd92;  6'd45: recip_lut = 8'd90;  6'd46: recip_lut = 8'd88;  6'd47: recip_lut = 8'd86;
        6'd48: recip_lut = 8'd84;  6'd49: recip_lut = 8'd83;  6'd50: recip_lut = 8'd81;  6'd51: recip_lut = 8'd80;
        6'd52: recip_lut = 8'd78;  6'd53: recip_lut = 8'd77;  6'd54: recip_lut = 8'd75;  6'd55: recip_lut = 8'd74;
        6'd56: recip_lut = 8'd72;  6'd57: recip_lut = 8'd71;  6'd58: recip_lut = 8'd70;  6'd59: recip_lut = 8'd69;
        6'd60: recip_lut = 8'd68;  6'd61: recip_lut = 8'd67;  6'd62: recip_lut = 8'd66;  6'd63: recip_lut = 8'd65;
        default: recip_lut = 8'd64;
    endcase
end

reg [7:0]  recip_r;
reg [4:0]  div_shift_r;
reg [25:0] var625_r2;
reg [7:0]  mean_r2;

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        recip_r <= 8'd0; div_shift_r <= 5'd0;
        var625_r2 <= 26'd0; mean_r2 <= 8'd0;
    end else begin
        recip_r     <= recip_lut;
        div_shift_r <= div_shift;
        var625_r2   <= var625_r;
        mean_r2     <= mean_r;
    end
end

// ============================================================
// ��ˮ�ߵ� 7 ��: product = var625 �� recip (1 ��, 1 �� 26x8 �˷���)
// ============================================================
reg [33:0] product;
reg [4:0]  div_shift_r2;
reg [7:0]  mean_r3;

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        product <= 34'd0; div_shift_r2 <= 5'd0; mean_r3 <= 8'd0;
    end else begin
        product      <= var625_r2 * recip_r;
        div_shift_r2 <= div_shift_r;
        mean_r3      <= mean_r2;
    end
end

// ============================================================
// ��ˮ�ߵ� 8 ��: a_Q10 = product >> (4 + div_shift), ���͵� 1024 (1 ��)
//   ע��: ��������ʽ case (���� product[(4+shift)+:12]),
//          ��Ϊ +: ����ѡ���ƫ���������ǳ���, ��̬ƫ�Ʋ����ۺ�.
// ============================================================
reg [11:0] raw_a_temp;
always @(*) begin
    case(div_shift_r2)
        5'd0:  raw_a_temp = product[4  +: 12];
        5'd1:  raw_a_temp = product[5  +: 12];
        5'd2:  raw_a_temp = product[6  +: 12];
        5'd3:  raw_a_temp = product[7  +: 12];
        5'd4:  raw_a_temp = product[8  +: 12];
        5'd5:  raw_a_temp = product[9  +: 12];
        5'd6:  raw_a_temp = product[10 +: 12];
        5'd7:  raw_a_temp = product[11 +: 12];
        5'd8:  raw_a_temp = product[12 +: 12];
        5'd9:  raw_a_temp = product[13 +: 12];
        5'd10: raw_a_temp = product[14 +: 12];
        5'd11: raw_a_temp = product[15 +: 12];
        5'd12: raw_a_temp = product[16 +: 12];
        5'd13: raw_a_temp = product[17 +: 12];
        5'd14: raw_a_temp = product[18 +: 12];
        5'd15: raw_a_temp = product[19 +: 12];
        5'd16: raw_a_temp = product[20 +: 12];
        5'd17: raw_a_temp = product[21 +: 12];
        5'd18: raw_a_temp = product[22 +: 12];
        default: raw_a_temp = 12'd0;
    endcase
end

reg [10:0] a_Q10;
reg [7:0]  mean_r4;

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        a_Q10 <= 11'd0; mean_r4 <= 8'd0;
    end else begin
        a_Q10   <= (raw_a_temp > 12'd1024) ? 11'd1024 : raw_a_temp[10:0];
        mean_r4 <= mean_r3;
    end
end

// ============================================================
// ���������ӳ��� - ����� 9 ���� a��I �˷�
//   matrix_p33 �� ���� 10 �� �� �� 9 ���Ĵ�
//   (�� 3x3 v3 �� p22_dly_c һ��)
// ============================================================
reg [7:0] p33_dly_c [0:9];
integer kk;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        for(kk = 0; kk < 10; kk = kk + 1)
            p33_dly_c[kk] <= 8'd0;
    end else begin
        p33_dly_c[0] <= matrix_p33;
        for(kk = 0; kk < 9; kk = kk + 1)
            p33_dly_c[kk+1] <= p33_dly_c[kk];
    end
end

// ============================================================
// ��ˮ�ߵ� 9 ��: �����˷� a��I �� (1-a)��mean (1 ��, 2 �� 11x8 �˷���)
// ============================================================
wire [10:0] one_minus_a = 11'd1024 - a_Q10;

reg [18:0] a_mul_I;
reg [18:0] inv_a_mul_mean;

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        a_mul_I <= 19'd0; inv_a_mul_mean <= 19'd0;
    end else begin
        a_mul_I        <= a_Q10       * p33_dly_c[9];
        inv_a_mul_mean <= one_minus_a * mean_r4;
    end
end

// ============================================================
// ��ˮ�ߵ� 10 ��: ��� + ���� 10 �õ��������� (1 ��)
// ============================================================
wire [19:0] q_sum = a_mul_I + inv_a_mul_mean;

reg [7:0] filtered_pixel;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)
        filtered_pixel <= 8'd0;
    else
        filtered_pixel <= q_sum[17:10];
end

// ============================================================
// ͬ���ź���: C_LATENCY = 12 (�� 3x3 v3 һ��)
// ============================================================
localparam C_LATENCY = 12;
reg [C_LATENCY-1:0] sync_vsync, sync_href, sync_edge;

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        sync_vsync <= {C_LATENCY{1'b0}};
        sync_href  <= {C_LATENCY{1'b0}};
        sync_edge  <= {C_LATENCY{1'b0}};
    end else begin
        sync_vsync <= {sync_vsync[C_LATENCY-2:0], matrix_img_vsync};
        sync_href  <= {sync_href[C_LATENCY-2:0],  matrix_img_href};
        sync_edge  <= {sync_edge[C_LATENCY-2:0],
                       matrix_top_edge_flag | matrix_bottom_edge_flag |
                       matrix_left_edge_flag | matrix_right_edge_flag};
    end
end

// �������س��ӳ��� (���ڱ�Ե bypass, 12 �ĺ��� filtered_pixel �׶�)
reg [7:0] p33_dly [0:C_LATENCY-1];
integer k;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        for(k = 0; k < C_LATENCY; k = k + 1)
            p33_dly[k] <= 8'd0;
    end else begin
        p33_dly[0] <= matrix_p33;
        for(k = 0; k < C_LATENCY-1; k = k + 1)
            p33_dly[k+1] <= p33_dly[k];
    end
end

// ============================================================
// ���: ��Ե���� bypass (ֱ�����ԭʼ��������), �ڲ��������˲����
// ============================================================
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)
        post_img_gray <= 8'd0;
    else
        post_img_gray <= sync_edge[C_LATENCY-1] ? p33_dly[C_LATENCY-1] : filtered_pixel;
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        post_img_vsync <= 1'b0;
        post_img_href  <= 1'b0;
    end else begin
        post_img_vsync <= sync_vsync[C_LATENCY-1];
        post_img_href  <= sync_href[C_LATENCY-1];
    end
end

endmodule
