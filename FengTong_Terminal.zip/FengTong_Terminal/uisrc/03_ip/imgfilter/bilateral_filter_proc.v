module bilateral_filter_proc
#(
    parameter   [10:0]  IMG_HDISP = 11'd1280,
    parameter   [10:0]  IMG_VDISP = 11'd720
)
(
    input  wire                 clk             ,
    input  wire                 rst_n           ,
    input  wire                 per_img_vsync   ,
    input  wire                 per_img_href    ,
    input  wire     [7:0]       per_img_gray    ,
    output reg                  post_img_vsync  ,
    output reg                  post_img_href   ,
    output reg      [7:0]       post_img_gray
);

wire                            matrix_img_vsync;
wire                            matrix_img_href;
wire                            matrix_top_edge_flag;
wire                            matrix_bottom_edge_flag;
wire                            matrix_left_edge_flag;
wire                            matrix_right_edge_flag;
wire            [7:0]           matrix_p11, matrix_p12, matrix_p13;
wire            [7:0]           matrix_p21, matrix_p22, matrix_p23;
wire            [7:0]           matrix_p31, matrix_p32, matrix_p33;

Matrix_Generate_3X3_8Bit
#(
    .IMG_HDISP  (IMG_HDISP  ),
    .IMG_VDISP  (IMG_VDISP  )
)
u_Matrix_Generate_3X3_8Bit
(
    .clk                    (clk                    ),
    .rst_n                  (rst_n                  ),
    .per_img_vsync          (per_img_vsync          ),
    .per_img_href           (per_img_href           ),
    .per_img_gray           (per_img_gray           ),
    .matrix_img_vsync       (matrix_img_vsync       ),
    .matrix_img_href        (matrix_img_href        ),
    .matrix_top_edge_flag   (matrix_top_edge_flag   ),
    .matrix_bottom_edge_flag(matrix_bottom_edge_flag),
    .matrix_left_edge_flag  (matrix_left_edge_flag  ),
    .matrix_right_edge_flag (matrix_right_edge_flag ),
    .matrix_p11             (matrix_p11             ),
    .matrix_p12             (matrix_p12             ),
    .matrix_p13             (matrix_p13             ),
    .matrix_p21             (matrix_p21             ),
    .matrix_p22             (matrix_p22             ),
    .matrix_p23             (matrix_p23             ),
    .matrix_p31             (matrix_p31             ),
    .matrix_p32             (matrix_p32             ),
    .matrix_p33             (matrix_p33             )
);

// ============================================================
// ��ˮ�ߵ� 1 ����������Բ1 �ģ�
// ============================================================
reg [7:0] abs11, abs12, abs13, abs21, abs23, abs31, abs32, abs33;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        abs11 <= 8'd0; abs12 <= 8'd0; abs13 <= 8'd0; abs21 <= 8'd0;
        abs23 <= 8'd0; abs31 <= 8'd0; abs32 <= 8'd0; abs33 <= 8'd0;
    end else begin
        abs11 <= (matrix_p11 >= matrix_p22) ? (matrix_p11 - matrix_p22) : (matrix_p22 - matrix_p11);
        abs12 <= (matrix_p12 >= matrix_p22) ? (matrix_p12 - matrix_p22) : (matrix_p22 - matrix_p12);
        abs13 <= (matrix_p13 >= matrix_p22) ? (matrix_p13 - matrix_p22) : (matrix_p22 - matrix_p13);
        abs21 <= (matrix_p21 >= matrix_p22) ? (matrix_p21 - matrix_p22) : (matrix_p22 - matrix_p21);
        abs23 <= (matrix_p23 >= matrix_p22) ? (matrix_p23 - matrix_p22) : (matrix_p22 - matrix_p23);
        abs31 <= (matrix_p31 >= matrix_p22) ? (matrix_p31 - matrix_p22) : (matrix_p22 - matrix_p31);
        abs32 <= (matrix_p32 >= matrix_p22) ? (matrix_p32 - matrix_p22) : (matrix_p22 - matrix_p32);
        abs33 <= (matrix_p33 >= matrix_p22) ? (matrix_p33 - matrix_p22) : (matrix_p22 - matrix_p33);
    end
end

// ============================================================
// ���ƶȲ��ұ�������߼���
// ============================================================
wire [9:0] sim11, sim12, sim13, sim21, sim22, sim23, sim31, sim32, sim33;
Similary_LUT u1(.Pre_Data(abs11), .Post_Data(sim11));
Similary_LUT u2(.Pre_Data(abs12), .Post_Data(sim12));
Similary_LUT u3(.Pre_Data(abs13), .Post_Data(sim13));
Similary_LUT u4(.Pre_Data(abs21), .Post_Data(sim21));
Similary_LUT u5(.Pre_Data(8'd0 ), .Post_Data(sim22));
Similary_LUT u6(.Pre_Data(abs23), .Post_Data(sim23));
Similary_LUT u7(.Pre_Data(abs31), .Post_Data(sim31));
Similary_LUT u8(.Pre_Data(abs32), .Post_Data(sim32));
Similary_LUT u9(.Pre_Data(abs33), .Post_Data(sim33));

// ============================================================
// ��ˮ�ߵ� 2 ����Ȩ�� = ���ƶ� * ��˹ϵ����1 �ģ�
// ============================================================
//36 48 36
//48 64 48
//36 48 36

localparam [6:0] G11 = 7'd36, G12 = 7'd48, G13 = 7'd36;
localparam [6:0] G21 = 7'd48, G22 = 7'd64, G23 = 7'd48;
localparam [6:0] G31 = 7'd36, G32 = 7'd48, G33 = 7'd36;

//localparam [6:0] G11 = 7'd4, G12 = 7'd6, G13 = 7'd4;
//localparam [6:0] G21 = 7'd6, G22 = 7'd1, G23 = 7'd6;
//localparam [6:0] G31 = 7'd4, G32 = 7'd6, G33 = 7'd4;

reg [16:0] w11, w12, w13, w21, w22, w23, w31, w32, w33;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        w11 <= 17'd0; w12 <= 17'd0; w13 <= 17'd0;
        w21 <= 17'd0; w22 <= 17'd0; w23 <= 17'd0;
        w31 <= 17'd0; w32 <= 17'd0; w33 <= 17'd0;
    end else begin
        w11 <= sim11 * G11;  w12 <= sim12 * G12;  w13 <= sim13 * G13;
        w21 <= sim21 * G21;  w22 <= sim22 * G22;  w23 <= sim23 * G23;
        w31 <= sim31 * G31;  w32 <= sim32 * G32;  w33 <= sim33 * G33;
    end
end

// ============================================================
// ��ˮ�ߵ� 3 ������Ȩ���س˻� + Ȩ�غͣ�1 �ģ�
// ============================================================
reg [7:0] p11_d1, p12_d1, p13_d1, p21_d1, p22_d1, p23_d1, p31_d1, p32_d1, p33_d1;
reg [7:0] p11_d2, p12_d2, p13_d2, p21_d2, p22_d2, p23_d2, p31_d2, p32_d2, p33_d2;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        p11_d1 <= 8'd0; p12_d1 <= 8'd0; p13_d1 <= 8'd0;
        p21_d1 <= 8'd0; p22_d1 <= 8'd0; p23_d1 <= 8'd0;
        p31_d1 <= 8'd0; p32_d1 <= 8'd0; p33_d1 <= 8'd0;
        p11_d2 <= 8'd0; p12_d2 <= 8'd0; p13_d2 <= 8'd0;
        p21_d2 <= 8'd0; p22_d2 <= 8'd0; p23_d2 <= 8'd0;
        p31_d2 <= 8'd0; p32_d2 <= 8'd0; p33_d2 <= 8'd0;
    end else begin
        p11_d1 <= matrix_p11; p12_d1 <= matrix_p12; p13_d1 <= matrix_p13;
        p21_d1 <= matrix_p21; p22_d1 <= matrix_p22; p23_d1 <= matrix_p23;
        p31_d1 <= matrix_p31; p32_d1 <= matrix_p32; p33_d1 <= matrix_p33;
        p11_d2 <= p11_d1; p12_d2 <= p12_d1; p13_d2 <= p13_d1;
        p21_d2 <= p21_d1; p22_d2 <= p22_d1; p23_d2 <= p23_d1;
        p31_d2 <= p31_d1; p32_d2 <= p32_d1; p33_d2 <= p33_d1;
    end
end

reg [24:0] wp11, wp12, wp13, wp21, wp22, wp23, wp31, wp32, wp33;
reg [19:0] ws_tmp1, ws_tmp2, ws_tmp3;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        wp11 <= 25'd0; wp12 <= 25'd0; wp13 <= 25'd0;
        wp21 <= 25'd0; wp22 <= 25'd0; wp23 <= 25'd0;
        wp31 <= 25'd0; wp32 <= 25'd0; wp33 <= 25'd0;
        ws_tmp1 <= 20'd0; ws_tmp2 <= 20'd0; ws_tmp3 <= 20'd0;
    end else begin
        wp11 <= p11_d2 * w11;  wp12 <= p12_d2 * w12;  wp13 <= p13_d2 * w13;
        wp21 <= p21_d2 * w21;  wp22 <= p22_d2 * w22;  wp23 <= p23_d2 * w23;
        wp31 <= p31_d2 * w31;  wp32 <= p32_d2 * w32;  wp33 <= p33_d2 * w33;
        ws_tmp1 <= w11 + w12 + w13;
        ws_tmp2 <= w21 + w22 + w23;
        ws_tmp3 <= w31 + w32 + w33;
    end
end

// ============================================================
// ��ˮ�ߵ� 4 ������Ȩ������� + ��Ȩ����ͣ�1 �ģ�
// ============================================================
reg [27:0] wp_sum_tmp1, wp_sum_tmp2, wp_sum_tmp3;
reg [21:0] w_sum;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        wp_sum_tmp1 <= 28'd0;
        wp_sum_tmp2 <= 28'd0;
        wp_sum_tmp3 <= 28'd0;
        w_sum       <= 22'd0;
    end else begin
        wp_sum_tmp1 <= wp11 + wp12 + wp13;
        wp_sum_tmp2 <= wp21 + wp22 + wp23;
        wp_sum_tmp3 <= wp31 + wp32 + wp33;
        w_sum       <= ws_tmp1 + ws_tmp2 + ws_tmp3;
    end
end

// ============================================================
// ��ˮ�ߵ� 5 �����������ؼ�Ȩ�� + ����Ȩ�غͣ�1 �ģ�
// ============================================================
reg [29:0] wp_sum;
reg [21:0] w_sum_r;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        wp_sum  <= 30'd0;
        w_sum_r <= 22'd0;
    end else begin
        wp_sum  <= wp_sum_tmp1 + wp_sum_tmp2 + wp_sum_tmp3;
        w_sum_r <= w_sum;
    end
end

// ============================================================
// ��ˮ�ߵ� 6a ������һ��������1 �ģ�
// ============================================================
reg [4:0]  div_shift_comb;
reg [7:0]  div_norm_comb;
always @(*) begin
    casex(w_sum_r)
        22'b1?????????????????????: begin div_shift_comb = 5'd14; div_norm_comb = w_sum_r[21:14]; end
        22'b01????????????????????: begin div_shift_comb = 5'd13; div_norm_comb = w_sum_r[20:13]; end
        22'b001???????????????????: begin div_shift_comb = 5'd12; div_norm_comb = w_sum_r[19:12]; end
        22'b0001??????????????????: begin div_shift_comb = 5'd11; div_norm_comb = w_sum_r[18:11]; end
        22'b00001?????????????????: begin div_shift_comb = 5'd10; div_norm_comb = w_sum_r[17:10]; end
        22'b000001????????????????: begin div_shift_comb = 5'd9;  div_norm_comb = w_sum_r[16:9];  end
        22'b0000001???????????????: begin div_shift_comb = 5'd8;  div_norm_comb = w_sum_r[15:8];  end
        22'b00000001??????????????: begin div_shift_comb = 5'd7;  div_norm_comb = w_sum_r[14:7];  end
        22'b000000001?????????????: begin div_shift_comb = 5'd6;  div_norm_comb = w_sum_r[13:6];  end
        22'b0000000001????????????: begin div_shift_comb = 5'd5;  div_norm_comb = w_sum_r[12:5];  end
        22'b00000000001???????????: begin div_shift_comb = 5'd4;  div_norm_comb = w_sum_r[11:4];  end
        22'b000000000001??????????: begin div_shift_comb = 5'd3;  div_norm_comb = w_sum_r[10:3];  end
        22'b0000000000001?????????: begin div_shift_comb = 5'd2;  div_norm_comb = w_sum_r[9:2];   end
        22'b00000000000001????????: begin div_shift_comb = 5'd1;  div_norm_comb = w_sum_r[8:1];   end
        default:                   begin div_shift_comb = 5'd0;  div_norm_comb = w_sum_r[7:0];   end
    endcase
end

reg [4:0]  div_shift;
reg [7:0]  div_norm;
reg [29:0] wp_sum_r6a;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        div_shift  <= 5'd0;
        div_norm   <= 8'd0;
        wp_sum_r6a <= 30'd0;
    end else begin
        div_shift  <= div_shift_comb;
        div_norm   <= div_norm_comb;
        wp_sum_r6a <= wp_sum;
    end
end

// ============================================================
// ��ˮ�ߵ� 6b �����������ұ���1 �ģ�
// ============================================================
reg [7:0] recip_lut;
always @(*) begin
    case(div_norm[7:2])
        6'd0:  recip_lut = 8'd255; 6'd1:  recip_lut = 8'd255; 6'd2:  recip_lut = 8'd255; 6'd3:  recip_lut = 8'd255;
        6'd4:  recip_lut = 8'd255; 6'd5:  recip_lut = 8'd255; 6'd6:  recip_lut = 8'd255; 6'd7:  recip_lut = 8'd255;
        6'd8:  recip_lut = 8'd255; 6'd9:  recip_lut = 8'd255; 6'd10: recip_lut = 8'd255; 6'd11: recip_lut = 8'd255;
        6'd12: recip_lut = 8'd255; 6'd13: recip_lut = 8'd255; 6'd14: recip_lut = 8'd255; 6'd15: recip_lut = 8'd255;
        6'd16: recip_lut = 8'd248; 6'd17: recip_lut = 8'd234; 6'd18: recip_lut = 8'd221; 6'd19: recip_lut = 8'd210;
        6'd20: recip_lut = 8'd200; 6'd21: recip_lut = 8'd191; 6'd22: recip_lut = 8'd182; 6'd23: recip_lut = 8'd174;
        6'd24: recip_lut = 8'd167; 6'd25: recip_lut = 8'd161; 6'd26: recip_lut = 8'd155; 6'd27: recip_lut = 8'd149;
        6'd28: recip_lut = 8'd144; 6'd29: recip_lut = 8'd139; 6'd30: recip_lut = 8'd134; 6'd31: recip_lut = 8'd130;
        6'd32: recip_lut = 8'd126; 6'd33: recip_lut = 8'd122; 6'd34: recip_lut = 8'd119; 6'd35: recip_lut = 8'd115;
        6'd36: recip_lut = 8'd112; 6'd37: recip_lut = 8'd109; 6'd38: recip_lut = 8'd106; 6'd39: recip_lut = 8'd104;
        6'd40: recip_lut = 8'd101; 6'd41: recip_lut = 8'd99;  6'd42: recip_lut = 8'd96;  6'd43: recip_lut = 8'd94;
        6'd44: recip_lut = 8'd92;  6'd45: recip_lut = 8'd90;  6'd46: recip_lut = 8'd88;  6'd47: recip_lut = 8'd86;
        6'd48: recip_lut = 8'd84;  6'd49: recip_lut = 8'd83;  6'd50: recip_lut = 8'd81;  6'd51: recip_lut = 8'd80;
        6'd52: recip_lut = 8'd78;  6'd53: recip_lut = 8'd77;  6'd54: recip_lut = 8'd75;  6'd55: recip_lut = 8'd74;
        6'd56: recip_lut = 8'd72;  6'd57: recip_lut = 8'd71;  6'd58: recip_lut = 8'd70;  6'd59: recip_lut = 8'd69;
        6'd60: recip_lut = 8'd68;  6'd61: recip_lut = 8'd67;  6'd62: recip_lut = 8'd66;  6'd63: recip_lut = 8'd65;
        default: recip_lut = 8'd64;
    endcase
end

reg [4:0]  div_shift_r;
reg [7:0]  recip_r;
reg [29:0] wp_sum_r;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        div_shift_r <= 5'd0;
        recip_r     <= 8'd0;
        wp_sum_r    <= 30'd0;
    end else begin
        div_shift_r <= div_shift;
        recip_r     <= recip_lut;
        wp_sum_r    <= wp_sum_r6a;
    end
end

// ============================================================
// ��ˮ�ߵ� 7 �������� wp_sum * recip��1 �ģ�
// ============================================================
reg [37:0] div_product;
reg [4:0]  div_shift_r2;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        div_product  <= 38'd0;
        div_shift_r2 <= 5'd0;
    end else begin
        div_product  <= wp_sum_r * recip_r;
        div_shift_r2 <= div_shift_r;
    end
end

// ============================================================
// ��ˮ�ߵ� 8 ������λ����ȡ�����1 �ģ�
// recip_lut �� 16384 / div_norm = 2^14 / div_norm
// div_product = wp_sum * recip �� wp_sum * 2^14 / div_norm
// result = wp_sum / w_sum = div_product >> (14 + div_shift)
// ============================================================
// ��ȫ��ȡ��ֹ�����ͨ�� bit[8] �жϲ����б��ͽض�
reg [7:0] filtered_pixel;
reg [8:0] raw9;
always @(*) begin
    case(div_shift_r2)
        5'd0:  raw9 = div_product[14+0  +: 9];
        5'd1:  raw9 = div_product[14+1  +: 9];
        5'd2:  raw9 = div_product[14+2  +: 9];
        5'd3:  raw9 = div_product[14+3  +: 9];
        5'd4:  raw9 = div_product[14+4  +: 9];
        5'd5:  raw9 = div_product[14+5  +: 9];
        5'd6:  raw9 = div_product[14+6  +: 9];
        5'd7:  raw9 = div_product[14+7  +: 9];
        5'd8:  raw9 = div_product[14+8  +: 9];
        5'd9:  raw9 = div_product[14+9  +: 9];
        5'd10: raw9 = div_product[14+10 +: 9];
        5'd11: raw9 = div_product[14+11 +: 9];
        5'd12: raw9 = div_product[14+12 +: 9];
        5'd13: raw9 = div_product[14+13 +: 9];
        5'd14: raw9 = div_product[14+14 +: 9];
        default: raw9 = 9'd0;
    endcase
end
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)
        filtered_pixel <= 8'd0;
    else
        filtered_pixel <= raw9[8] ? 8'd255 : raw9[7:0];
end

// ============================================================
// �ź�ͬ�����Ӿ��������ʼ����ˮ���ӳ�Ϊ 8 ��
// post_img_gray ���������� 1 �ļĴ棬���ͬ��������ȡ 8 ��ƥ��
// ============================================================
localparam C_LATENCY = 9;
reg [C_LATENCY-1:0] sync_vsync, sync_href, sync_edge;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        sync_vsync <= {C_LATENCY{1'b0}};
        sync_href  <= {C_LATENCY{1'b0}};
        sync_edge  <= {C_LATENCY{1'b0}};
    end else begin
        sync_vsync <= {sync_vsync[C_LATENCY-2:0], matrix_img_vsync};
        sync_href  <= {sync_href[C_LATENCY-2:0],  matrix_img_href};
        sync_edge  <= {sync_edge[C_LATENCY-2:0],  matrix_top_edge_flag | matrix_bottom_edge_flag | matrix_left_edge_flag | matrix_right_edge_flag};
    end
end

// ���������ؽ����ӳ٣����ڱ߽���·���
reg [7:0] p22_dly [0:C_LATENCY-1];
integer k;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        for(k = 0; k < C_LATENCY; k = k + 1)
            p22_dly[k] <= 8'd0;
    end else begin
        p22_dly[0] <= matrix_p22;
        for(k = 0; k < C_LATENCY-1; k = k + 1)
            p22_dly[k+1] <= p22_dly[k];
    end
end

// ============================================================
// ���
// ============================================================
always @(posedge clk or negedge rst_n) begin
    if(!rst_n)
        post_img_gray <= 8'd0;
    else
        post_img_gray <= sync_edge[C_LATENCY-1] ? p22_dly[C_LATENCY-1] : filtered_pixel;
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        post_img_vsync <= 1'b0;
        post_img_href  <= 1'b0;
    end else begin
        post_img_vsync <= sync_vsync[C_LATENCY-1];
        post_img_href  <= sync_href[C_LATENCY-1];
    end
end

endmodule