`timescale 1ns/1ps

// evs_cmd_rx bench (2026-10-29): PC -> FPGA EVCMD datagrams.
//
// The stack's receive port is modelled the way uiudp_rx drives it: valid high
// for the payload bytes of one datagram, one byte per clock, low between
// datagrams.  Each case below says what must come out on the video clock.
//
//   1. a good SET_MODE datagram            -> exactly one O_cmd_stb, cmd 1 arg 2
//   2. bad XOR                             -> nothing
//   3. bad magic (one letter)              -> nothing
//   4. 7 bytes (no XOR byte)               -> nothing
//   5. good, then 10 bytes of padding      -> accepted (trailing bytes ignored)
//   6. two good datagrams 20 clocks apart  -> two strobes, in order
//   7. cmd/arg are held until the next command (read long after the strobe)
//   8. valid drops for one clock after byte 4: two datagrams of 4 + 4 bytes,
//      neither is a command (the parser must restart on every rising valid)
// Plus O_accept (Ethernet clock) once per accepted datagram, never otherwise.
// Cases 2..4 and 8 are the ones that go green on an RTL that skips a check, so the
// bench is not one that can only pass.
module tb_cmd_rx;

reg eclk = 1'b0;
reg vclk = 1'b0;
reg erst = 1'b1;
reg vrst_n = 1'b0;
always #(4.0)    eclk = ~eclk;
always #(3.3333) vclk = ~vclk;

reg       rx_valid = 1'b0;
reg [7:0] rx_data = 8'd0;
wire      accept;
wire      cmd_stb;
wire [7:0] cmd, arg;

evs_cmd_rx dut (
    .I_clk(eclk), .I_reset(erst),
    .I_rx_valid(rx_valid), .I_rx_data(rx_data),
    .O_accept(accept),
    .I_video_clk(vclk), .I_video_rst_n(vrst_n),
    .O_cmd_stb(cmd_stb), .O_cmd(cmd), .O_arg(arg)
);

integer errors = 0;
task fail;
    input [1023:0] msg;
    begin
        errors = errors + 1;
        $display("[%0t] FAIL: %0s", $time, msg);
        $fflush;
    end
endtask

// what came out
integer n_stb = 0, n_accept = 0;
reg [7:0] got_cmd [0:15];
reg [7:0] got_arg [0:15];
always @(posedge vclk) begin
    // On the strobe clock itself, as system_top's eth_set_mode reads them.
    // Sampled just after the edge (#0.1) so it sees the new register values.
    #0.1;
    if (cmd_stb) begin
        if (n_stb < 16) begin
            got_cmd[n_stb] = cmd;
            got_arg[n_stb] = arg;
        end
        n_stb = n_stb + 1;
    end
end
always @(posedge eclk) if (accept) n_accept = n_accept + 1;

reg [7:0] pkt [0:31];

task send;
    input integer len;
    integer i;
    begin
        @(negedge eclk);
        for (i = 0; i < len; i = i + 1) begin
            rx_valid = 1'b1;
            rx_data = pkt[i];
            @(negedge eclk);
        end
        rx_valid = 1'b0;
        rx_data = 8'd0;
    end
endtask

// The eight bytes of pkt, valid low for one clock after byte `cut`.
task send_split;
    input integer cut;
    integer i;
    begin
        @(negedge eclk);
        for (i = 0; i < 8; i = i + 1) begin
            if (i == cut) begin
                rx_valid = 1'b0;
                rx_data = 8'd0;
                @(negedge eclk);
            end
            rx_valid = 1'b1;
            rx_data = pkt[i];
            @(negedge eclk);
        end
        rx_valid = 1'b0;
        rx_data = 8'd0;
    end
endtask

task make;
    input [7:0] c;
    input [7:0] a;
    integer i;
    reg [7:0] x;
    begin
        pkt[0] = "E"; pkt[1] = "V"; pkt[2] = "C"; pkt[3] = "M"; pkt[4] = "D";
        pkt[5] = c; pkt[6] = a;
        x = 8'd0;
        for (i = 0; i < 7; i = i + 1) x = x ^ pkt[i];
        pkt[7] = x;
        for (i = 8; i < 32; i = i + 1) pkt[i] = 8'd0;
    end
endtask

task settle;
    begin
        repeat (40) @(posedge vclk);
    end
endtask

task expect_count;
    input integer want;
    input [1023:0] what;
    begin
        if (n_stb !== want) begin
            $display("            strobes %0d, want %0d", n_stb, want);
            fail(what);
        end
        if (n_accept !== want) begin
            $display("            accepts %0d, want %0d", n_accept, want);
            fail(what);
        end
    end
endtask

initial begin
    #100;
    vrst_n = 1'b1;
    #100;
    erst = 1'b0;
    settle;

    // 1
    make(8'd1, 8'd2);
    send(8); settle;
    expect_count(1, "case 1: a good datagram did not give exactly one command");
    if (got_cmd[0] !== 8'd1 || got_arg[0] !== 8'd2) fail("case 1: cmd / arg wrong");

    // 2
    make(8'd1, 8'd3); pkt[7] = pkt[7] ^ 8'h01;
    send(8); settle;
    expect_count(1, "case 2: bad XOR was accepted");

    // 3
    make(8'd1, 8'd3); pkt[2] = "X"; pkt[7] = pkt[7] ^ "C" ^ "X";   // XOR still right
    send(8); settle;
    expect_count(1, "case 3: bad magic was accepted");

    // 4
    make(8'd1, 8'd3);
    send(7); settle;
    expect_count(1, "case 4: a 7-byte datagram was accepted");

    // 5
    make(8'd3, 8'd1);
    send(18); settle;
    expect_count(2, "case 5: a good datagram with padding was not accepted");
    if (got_cmd[1] !== 8'd3 || got_arg[1] !== 8'd1) fail("case 5: cmd / arg wrong");

    // 6
    make(8'd1, 8'd0);
    send(8);
    repeat (20) @(negedge eclk);
    make(8'd2, 8'd0);
    send(8); settle;
    expect_count(4, "case 6: two datagrams did not give two commands");
    if (got_cmd[2] !== 8'd1 || got_arg[2] !== 8'd0) fail("case 6: first cmd / arg wrong");
    if (got_cmd[3] !== 8'd2) fail("case 6: second cmd wrong");

    // 7
    repeat (2000) @(posedge vclk);
    if (cmd !== 8'd2) fail("case 7: O_cmd not held");

    // 8
    make(8'd1, 8'd1);
    send_split(4); settle;
    expect_count(4, "case 8: a datagram split by a valid gap was accepted");

    $display("--- summary: %0d commands, %0d accepts", n_stb, n_accept);
    if (errors == 0) $display("\n=== TB_CMD_RX PASS ===\n");
    else             $display("\n=== TB_CMD_RX FAIL (%0d errors) ===\n", errors);
    $finish;
end

initial begin
    #2_000_000;
    $display("\n=== TB_CMD_RX FAIL: TIMEOUT ===");
    $finish;
end

endmodule
