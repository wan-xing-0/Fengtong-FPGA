#!/bin/sh
# Simulation entry point for the ETHA UDP video path.
#
# Run it as a single command, e.g. from the Claude Code prompt:
#   ! sh C:/Users/DengYaqi/Desktop/udp/with_udp/ethernet_video/sim/run_sim.sh <mode>
#
#   (no argument)  fast    128x64 frame-abort + throughput bench.  Proves the
#                          recovery mechanism in ~1.5 ms of simulated time;
#                          use this while iterating.
#   real                   true 960x540 out of 1920x1080, i.e. the
#                          synthesised parameters.  Checks the counter widths
#                          (FRAME_PIXELS 518400 against sampled_pixels[19:0]),
#                          packet_count=758 and the real ~65 MB/s write duty
#                          cycle against the read path.  Minutes, not seconds.
#   unit                   byte-exact packetizer bench: EVS1 header fields by
#                          absolute offset, bank alternation, and the abort
#                          contract (a complete bank still goes out whole).
#   core                   small smoke test of the whole core, 4x2 frame.
#   dump                   fast mode plus tb_frame_abort.vcd for waveforms.
#   aux                    EVS1 video + EVDBG1 status + EVQC1 QC records through
#                          evs_aux_tx, status packets forced to collide with
#                          video; every frame must arrive, every record 3x.
#   aux_v2                 aux with QC_V2=1: 48-byte EVQC2, qc_ext checked
#                          byte-exact at offsets 28..43 (2026-10-09).
#   aux_legacy             the same traffic with the v1.0 release point
#                          (LEGACY_RELEASE=1); PASS means the lost-datagram
#                          hazard the fix is for was reproduced.  At this
#                          small geometry it is NOT (see aux_real below).
#   aux_real / aux_legacy_real   the same two at 960x540, minutes each.
#   burst                  2026-10-09 full-resolution bursts: every frame
#                          pixel-exact against the phase in its own header,
#                          4-frame runs 0..3, queued QC trigger, a skipped VS
#                          that must not eat a phase, timed bursts.
#   burst_real             one QC burst at 960x540 (phases 1 and 3 sample the
#                          real line's last column).  Several minutes.
#   cmd                    2026-10-29 PC -> FPGA EVCMD datagrams (evs_cmd_rx):
#                          good / bad XOR / bad magic / short / padded / two in
#                          a row, across to the video clock.
#   aux_v3                 aux_v2 with QC_VER=3 (the 10-29 qc_ext layout byte).
#   all                    unit + core + fast + aux + burst + cmd + aux_v3.
#
# The real uiudp_stack is deliberately NOT in these lists: uiudp_tx.v
# instantiates PH1_LOGIC_SHIFTER, an Anlogic hard primitive no open simulator
# can elaborate.  The benches model that interface instead -- including the
# rule that a request is only latched while busy is low, which is what the
# back-to-back datagrams of the ping-pong banks now depend on.  Everything
# under test -- sampler, vendor CDC FIFO, bridge, packetizer -- is plain
# behavioural RTL.
set -e

IVERILOG=C:/iverilog/bin/iverilog.exe
VVP=C:/iverilog/bin/vvp.exe

SIM_DIR=$(dirname "$0")
cd "$SIM_DIR"

RTL="../rtl/evs_video_tx_core.v
../rtl/evs_burst_ctrl.v
../rtl/evs_video_sampler.v
../rtl/evs_async_frame_fifo.v
../rtl/evs_udp_packetizer.v
../vendor_udp_stack/async_fifo/udp_pkg_buf.v"

run_one() {
    top=$1
    out=$2
    params=$3
    plusargs=$4
    shift 4
    echo "=== compiling $top ==="
    $IVERILOG -g2005 -Wall -o "$out" -s "$top" $params "$@"
    echo "=== running $top ==="
    $VVP "$out" $plusargs
}

MODE=${1:-fast}

case "$MODE" in
    unit)
        run_one tb_evs_udp_packetizer tb_pkt.vvp "" "" \
            tb_evs_udp_packetizer.v ../rtl/evs_udp_packetizer.v
        ;;
    core)
        run_one tb_evs_video_tx_core tb_core.vvp "" "" \
            tb_evs_video_tx_core.v $RTL
        ;;
    fast)
        run_one tb_frame_abort tb_frame_abort.vvp "" "" tb_frame_abort.v $RTL
        ;;
    dump)
        run_one tb_frame_abort tb_frame_abort.vvp "" "+dump" tb_frame_abort.v $RTL
        ;;
    real)
        run_one tb_frame_abort tb_frame_abort_real.vvp \
            "-Ptb_frame_abort.OUT_W=960 -Ptb_frame_abort.OUT_H=540
             -Ptb_frame_abort.H_TOTAL=2200 -Ptb_frame_abort.H_ACTIVE=1920
             -Ptb_frame_abort.V_TOTAL=1125 -Ptb_frame_abort.V_ACTIVE=1080
             -Ptb_frame_abort.FRAMES_AFTER_ABORT=1
             -Ptb_frame_abort.TIMEOUT_NS=90000000" \
            "+stop_on_mismatch" tb_frame_abort.v $RTL
        ;;
    aux)
        run_one tb_aux_tx tb_aux.vvp "" "" \
            tb_aux_tx.v ../rtl/evs_aux_tx.v $RTL
        ;;
    aux_v2)
        # 2026-10-09: the same traffic with EVQC2 (48-byte records, qc_ext)
        run_one tb_aux_tx tb_aux_v2.vvp "-Ptb_aux_tx.QC_V2=1" ""             tb_aux_tx.v ../rtl/evs_aux_tx.v $RTL
        ;;
    aux_v3)
        # 2026-10-29: EVQC2 with version byte 3, as the endpoint builds it
        run_one tb_aux_tx tb_aux_v3.vvp "-Ptb_aux_tx.QC_V2=1 -Ptb_aux_tx.QC_VER=3" "" \
            tb_aux_tx.v ../rtl/evs_aux_tx.v $RTL
        ;;
    cmd)
        run_one tb_cmd_rx tb_cmd_rx.vvp "" "" tb_cmd_rx.v ../rtl/evs_cmd_rx.v
        ;;
    aux_legacy)
        run_one tb_aux_tx tb_aux_legacy.vvp "-Ptb_aux_tx.LEGACY_RELEASE=1" "" \
            tb_aux_tx.v ../rtl/evs_aux_tx.v $RTL
        ;;
    # 2026-10-05: aux_legacy at 128x64 did NOT reproduce the loss -- a 256-byte
    # line fills a 1368-byte bank slower than the stack sends it, so the bank
    # is rarely ready on the cycle the stack goes idle.  At 960x540 an even
    # line is a 1920-byte burst that fills faster than the send, which is the
    # board's situation.  Several minutes each.
    aux_real)
        run_one tb_aux_tx tb_aux_real.vvp \
            "-Ptb_aux_tx.OUT_W=960 -Ptb_aux_tx.OUT_H=540
             -Ptb_aux_tx.H_TOTAL=2200 -Ptb_aux_tx.H_ACTIVE=1920
             -Ptb_aux_tx.V_TOTAL=1125 -Ptb_aux_tx.V_ACTIVE=1080
             -Ptb_aux_tx.FRAMES=2 -Ptb_aux_tx.TIMEOUT_NS=90000000" \
            "" tb_aux_tx.v ../rtl/evs_aux_tx.v $RTL
        ;;
    aux_legacy_real)
        run_one tb_aux_tx tb_aux_legacy_real.vvp \
            "-Ptb_aux_tx.OUT_W=960 -Ptb_aux_tx.OUT_H=540
             -Ptb_aux_tx.H_TOTAL=2200 -Ptb_aux_tx.H_ACTIVE=1920
             -Ptb_aux_tx.V_TOTAL=1125 -Ptb_aux_tx.V_ACTIVE=1080
             -Ptb_aux_tx.FRAMES=2 -Ptb_aux_tx.TIMEOUT_NS=90000000
             -Ptb_aux_tx.LEGACY_RELEASE=1" \
            "" tb_aux_tx.v ../rtl/evs_aux_tx.v $RTL
        ;;
    burst)
        run_one tb_burst tb_burst.vvp "" "" tb_burst.v $RTL
        ;;
    burst_real)
        run_one tb_burst tb_burst_real.vvp \
            "-Ptb_burst.OUT_W=960 -Ptb_burst.OUT_H=540
             -Ptb_burst.H_TOTAL=2200 -Ptb_burst.H_ACTIVE=1920
             -Ptb_burst.V_TOTAL=1125 -Ptb_burst.V_ACTIVE=1080
             -Ptb_burst.REAL=1 -Ptb_burst.TIMEOUT_NS=110000000" \
            "" tb_burst.v $RTL
        ;;
    all)
        sh "$0" unit
        sh "$0" core
        sh "$0" fast
        sh "$0" aux
        sh "$0" burst
        sh "$0" cmd
        sh "$0" aux_v3
        ;;
    *)
        echo "unknown mode: $MODE (expected fast, real, unit, core, dump, aux, aux_v2, aux_v3, aux_legacy, aux_real, aux_legacy_real, burst, burst_real, cmd or all)" >&2
        exit 1
        ;;
esac
