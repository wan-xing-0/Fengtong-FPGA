`timescale 1ns/1ps

// Full-resolution burst bench (2026-10-09): evs_burst_ctrl + the phase-aware
// sampler + flags through the core and the packetizer, against the same UDP
// stack model as tb_frame_abort.
//
// WHAT IT PROVES
//   1. Every frame arrives complete and PIXEL-EXACT against the decimation
//      phase its own header claims -- (x,y) = (2sx+ox, 2sy+oy) for phase
//      {oy,ox}.  This is what catches the sampler keeping the wrong column
//      or row, or a line-end low byte lost across the DE falling edge (phase
//      x-odd samples the last column of every line).
//   2. Header flags: non-members are exactly 0 (the v1.0 stream); members
//      have bit1 set, bit0 clear, and come in runs of four CONSECUTIVE frame
//      sequence numbers with phases 0,1,2,3 and one source / id; ids step by
//      one per burst; QC bursts are source 0, timed ones source 1.
//   3. A QC trigger that arrives while a burst runs is queued, not lost.
//   4. A frame the sampler SKIPS (Ethernet side still busy at the VS edge)
//      does not consume a phase: the bench stalls the stack across a VS edge
//      in the middle of a burst and still expects 0,1,2,3.
//   5. No timed burst while I_timer_en is low; timed bursts once it is high.
//   6. Security rule (10-09): with nobody present the bursts are NORMAL
//      (source 1); while level 1 (motion, unconfirmed) is present there is
//      no burst at all; level 2 / 3 with someone present gives ALARM bursts
//      of source 2 / 3, the first one within two frames of the alarm
//      starting (not up to a period late); when they leave (level still 3,
//      present low) the bursts go back to NORMAL at once.
//   7. Staff verification (10-29): while I_sec_hold is high there is no
//      security burst at all, even with a level-2 alarm present; staff_pass
//      rising gives exactly ONE burst, source 1 with flags bit0 set, within a
//      few frames; nothing more until the hold falls; then NORMAL again.
//      Bit0 is 0 on every other member frame.
//
// REAL=1 runs one QC burst at 960x540 out of 1920x1080 (the synthesised
// geometry), which is the only size where a line's last sampled column sits
// on the real 1920-wide line end.  Several minutes.
module tb_burst #(
    parameter integer OUT_W = 128,
    parameter integer OUT_H = 64,
    parameter integer H_TOTAL  = 320,
    parameter integer H_ACTIVE = 256,
    parameter integer V_TOTAL  = 144,
    parameter integer V_ACTIVE = 128,
    parameter integer TIMEOUT_NS = 60_000_000,
    parameter integer REAL = 0
);

localparam integer FRAME_BYTES = OUT_W * OUT_H * 2;
localparam integer EXP_PACKETS = (FRAME_BYTES + 1367) / 1368;
localparam integer V_TOP     = (V_TOTAL - V_ACTIVE) / 2;
localparam integer VS_RISE   = 4;
localparam integer VS_FALL   = V_TOP + V_ACTIVE + 4;
localparam integer WIRE_OVERHEAD = 66;
localparam integer TIMER_VS  = 5;
localparam integer QC_DELAY  = (REAL != 0) ? 0 : 2;
localparam integer STAFF_DELAY = 2;

reg vclk = 1'b0;
reg eclk = 1'b0;
reg vrst_n = 1'b0;
reg erst = 1'b1;
always #(3.3333) vclk = ~vclk;
always #(4.0)    eclk = ~eclk;

//--------------------------------------------------------------------------
// video source: every source pixel distinct within a 256 period
//--------------------------------------------------------------------------
reg [15:0] hcnt = 16'd0;
reg [15:0] vcnt = 16'd0;
always @(negedge vclk) begin
    if (!vrst_n) begin
        hcnt <= 16'd0;
        vcnt <= 16'd0;
    end else if (hcnt == H_TOTAL - 1) begin
        hcnt <= 16'd0;
        vcnt <= (vcnt == V_TOTAL - 1) ? 16'd0 : vcnt + 16'd1;
    end else begin
        hcnt <= hcnt + 16'd1;
    end
end
wire in_vactive = (vcnt >= V_TOP) && (vcnt < V_TOP + V_ACTIVE);
wire src_de = in_vactive && (hcnt < H_ACTIVE);
wire src_vs = (vcnt >= VS_RISE) && (vcnt < VS_FALL);
wire [15:0] px = hcnt;
wire [15:0] py = vcnt - V_TOP;
wire [23:0] src_rgb = {px[7:0], py[7:0], px[7:0] + py[7:0]};

// Source pixel (2*sx + ox, 2*sy + oy) through RGB888 -> RGB565.  Because x
// and y enter different channels, a wrong column shows in R and a wrong row
// in G -- never both silently.
function [15:0] expect_rgb565;
    input integer sx;
    input integer sy;
    input integer ox;
    input integer oy;
    reg [7:0] r, g, b;
    begin
        r = (2 * sx + ox) % 256;
        g = (2 * sy + oy) % 256;
        b = (r + g) % 256;
        expect_rgb565 = {r[7:3], g[7:2], b[7:3]};
    end
endfunction

//--------------------------------------------------------------------------
// DUT
//--------------------------------------------------------------------------
reg qc_trig = 1'b0;
reg timer_en = 1'b0;
reg [1:0] alarm_level = 2'd0;
reg present = 1'b0;
reg sec_hold = 1'b0;
reg staff_pass = 1'b0;
wire udp_req, udp_valid;
wire [7:0] udp_data;
wire [15:0] udp_len;
wire video_frame_dropped, fifo_overflow, packetizer_error;
wire [31:0] debug_status;
wire [7:0] debug_counts;
reg udp_busy;

evs_video_tx_core #(
    .OUT_WIDTH(OUT_W), .OUT_HEIGHT(OUT_H), .SESSION_ID(32'hA5A5_0001),
    .BURST_TIMER_VS(TIMER_VS), .BURST_QC_DELAY_VS(QC_DELAY),
    .BURST_STAFF_DELAY_VS(STAFF_DELAY)
) dut (
    .I_video_clk(vclk), .I_video_rst_n(vrst_n),
    .I_video_vs(src_vs), .I_video_de(src_de), .I_video_rgb(src_rgb),
    .I_qc_trig(qc_trig), .I_timer_en(timer_en),
    .I_alarm_level(alarm_level), .I_present(present),
    .I_sec_hold(sec_hold), .I_staff_pass(staff_pass),
    .I_eth_clk(eclk), .I_eth_reset(erst), .I_udp_busy(udp_busy),
    .O_udp_req(udp_req), .O_udp_valid(udp_valid), .O_udp_data(udp_data),
    .O_udp_len(udp_len),
    .O_video_frame_dropped(video_frame_dropped),
    .O_fifo_overflow(fifo_overflow),
    .O_packetizer_error(packetizer_error),
    .O_debug_status(debug_status), .O_debug_counts(debug_counts)
);

integer skipped_vs = 0;
integer started_vs = 0;
always @(posedge vclk) begin
    if (dut.u_sampler.I_vs && !dut.u_sampler.vs_d && vrst_n) begin
        if (dut.sampler_frame_started) started_vs = started_vs + 1;
        else skipped_vs = skipped_vs + 1;
    end
end

//--------------------------------------------------------------------------
// checking infrastructure
//--------------------------------------------------------------------------
integer errors = 0;
task fail;
    input [1023:0] msg;
    begin
        errors = errors + 1;
        if (errors <= 20) $display("[%0t] FAIL: %0s", $time, msg);
        $fflush;
    end
endtask

function [31:0] crc32_tb;
    input [31:0] crc_in;
    input [7:0] data;
    integer k;
    reg [31:0] c;
    begin
        c = crc_in ^ data;
        for (k = 0; k < 8; k = k + 1)
            c = c[0] ? ((c >> 1) ^ 32'hEDB88320) : (c >> 1);
        crc32_tb = c;
    end
endfunction

//--------------------------------------------------------------------------
// UDP stack model
//--------------------------------------------------------------------------
localparam [1:0] K_IDLE = 2'd0;
localparam [1:0] K_ACK  = 2'd1;
localparam [1:0] K_DATA = 2'd2;
localparam [1:0] K_WIRE = 2'd3;

reg [1:0] stk_state = K_IDLE;
reg [15:0] stk_delay = 16'd0;
reg [15:0] rx_len = 16'd0;
reg [15:0] rx_cnt = 16'd0;
reg [7:0] rx_buf [0:1499];
reg stall_stack = 1'b0;

reg [7:0] fbuf [0:FRAME_BYTES-1];
integer fbytes = 0;
integer next_idx = 0;
reg [31:0] cur_seq = 32'hFFFF_FFFF;
reg [7:0] cur_flags = 8'd0;
reg frame_tracking = 1'b0;
integer frames_complete = 0;
integer frames_incomplete = 0;

localparam integer MAXF = 260;
reg [31:0] log_seq   [0:MAXF-1];
reg [7:0]  log_flags [0:MAXF-1];
integer n_log = 0;

task check_video;
    integer i, sx, sy, base, bad, ox, oy;
    reg [31:0] crc, hcrc, seq;
    reg [15:0] idx, cnt, plen, e;
    reg [7:0] flags;
    begin
        if (!(rx_buf[0] == "E" && rx_buf[1] == "V" && rx_buf[2] == "S" && rx_buf[3] == "1"))
            fail("EVS1 magic wrong");
        seq   = {rx_buf[12], rx_buf[13], rx_buf[14], rx_buf[15]};
        idx   = {rx_buf[16], rx_buf[17]};
        cnt   = {rx_buf[18], rx_buf[19]};
        flags = rx_buf[25];
        plen  = {rx_buf[26], rx_buf[27]};
        hcrc  = {rx_buf[28], rx_buf[29], rx_buf[30], rx_buf[31]};
        if (cnt !== EXP_PACKETS[15:0]) fail("packet_count wrong");
        if (plen !== rx_len - 16'd32) fail("payload_count disagrees with udp_len");
        crc = 32'hFFFF_FFFF;
        for (i = 0; i < plen; i = i + 1)
            crc = crc32_tb(crc, rx_buf[32 + i]);
        if (~crc !== hcrc) fail("payload CRC32 mismatch");

        if (!frame_tracking || seq !== cur_seq) begin
            if (frame_tracking && next_idx != 0) begin
                frames_incomplete = frames_incomplete + 1;
                $display("[%0t]   frame seq=%0d abandoned after %0d/%0d packets",
                         $time, cur_seq, next_idx, EXP_PACKETS);
            end
            cur_seq = seq;
            cur_flags = flags;
            frame_tracking = 1'b1;
            next_idx = 0;
            fbytes = 0;
        end
        if (flags !== cur_flags) fail("flags differ between packets of one frame");

        if (idx !== next_idx[15:0]) begin
            fail("packet_index not contiguous");
            frame_tracking = 1'b0;
            next_idx = 0;
            fbytes = 0;
        end else begin
            for (i = 0; i < plen; i = i + 1)
                fbuf[fbytes + i] = rx_buf[32 + i];
            fbytes = fbytes + plen;
            next_idx = next_idx + 1;
            if (next_idx == EXP_PACKETS) begin
                ox = flags[2];
                oy = flags[3];
                bad = 0;
                for (sy = 0; sy < OUT_H; sy = sy + 1)
                    for (sx = 0; sx < OUT_W; sx = sx + 1) begin
                        e = expect_rgb565(sx, sy, ox, oy);
                        base = 2 * (sy * OUT_W + sx);
                        if (fbuf[base] !== e[15:8] || fbuf[base + 1] !== e[7:0]) begin
                            if (bad < 4)
                                $display("            phase (%0d,%0d) sx=%0d sy=%0d got %02x%02x want %02x%02x",
                                         ox, oy, sx, sy, fbuf[base], fbuf[base + 1], e[15:8], e[7:0]);
                            bad = bad + 1;
                        end
                    end
                if (bad != 0) begin
                    $display("[%0t]   frame seq=%0d flags=%02x: %0d pixels wrong", $time, seq, flags, bad);
                    fail("frame content does not match the phase in its header");
                end else begin
                    frames_complete = frames_complete + 1;
                    $display("[%0t]   frame seq=%0d flags=%02x (member %0d phase %0d src %0d id %0d) pixel-exact",
                             $time, seq, flags, flags[1], flags[3:2], flags[5:4], flags[7:6]);
                    $fflush;
                end
                if (n_log < MAXF) begin
                    log_seq[n_log] = seq;
                    log_flags[n_log] = flags;
                    n_log = n_log + 1;
                end
                frame_tracking = 1'b0;
                next_idx = 0;
                fbytes = 0;
            end
        end
    end
endtask

always @(posedge eclk or posedge erst) begin
    if (erst) begin
        stk_state <= K_IDLE;
        udp_busy <= 1'b0;
        stk_delay <= 16'd0;
        rx_cnt <= 16'd0;
        rx_len <= 16'd0;
    end else begin
        case (stk_state)
            K_IDLE: begin
                if (udp_valid) fail("udp_valid asserted while the stack is idle");
                if (udp_req && !stall_stack) begin
                    stk_delay <= 16'd3;
                    stk_state <= K_ACK;
                end
            end
            K_ACK: begin
                if (udp_valid) fail("udp_valid asserted before the stack acknowledged");
                if (stk_delay != 16'd0) begin
                    stk_delay <= stk_delay - 16'd1;
                end else begin
                    udp_busy <= 1'b1;
                    rx_len <= udp_len;
                    rx_cnt <= 16'd0;
                    stk_state <= K_DATA;
                end
            end
            K_DATA: begin
                if (udp_valid) begin
                    rx_buf[rx_cnt] <= udp_data;
                    rx_cnt <= rx_cnt + 16'd1;
                    if (rx_cnt + 16'd1 == rx_len) begin
                        stk_delay <= WIRE_OVERHEAD[15:0];
                        stk_state <= K_WIRE;
                    end
                end
            end
            K_WIRE: begin
                if (udp_valid) fail("udp_valid continued past udp_len");
                if (stk_delay != 16'd0) begin
                    stk_delay <= stk_delay - 16'd1;
                end else begin
                    udp_busy <= 1'b0;
                    check_video;
                    stk_state <= K_IDLE;
                end
            end
        endcase
    end
end

//--------------------------------------------------------------------------
// test sequence
//--------------------------------------------------------------------------
integer qc_triggers = 0;

task pulse_qc;
    begin
        @(negedge vclk); qc_trig = 1'b1;
        @(negedge vclk); qc_trig = 1'b0;
        qc_triggers = qc_triggers + 1;
        $display("[%0t] qc_trig #%0d (burst active=%0d phase=%0d)", $time, qc_triggers,
                 dut.u_burst.active, dut.u_burst.phase);
        $fflush;
    end
endtask

// Holds the stack from just after the bridge has handed over the last byte
// of the frame in flight until the next VS edge has gone by.  The final bank
// cannot leave, the packetizer is not ready at that edge, so the sampler
// skips the frame -- without the FIFO ever filling (the frame is complete).
task skip_one_frame;
    integer before;
    begin
        wait (dut.packet_src_valid && dut.packet_src_last && dut.packetizer_src_ready);
        @(posedge eclk);
        stall_stack = 1'b1;
        before = skipped_vs;
        wait (skipped_vs > before);
        @(posedge eclk);
        stall_stack = 1'b0;
        $display("[%0t] stalled the stack across one VS edge: frame skipped mid-burst", $time);
        $fflush;
    end
endtask

integer k, j, bursts_qc, bursts_timer, last_id, have_id, timer_on_seq, stop_frames;
integer seq_l1, seq_l2, seq_l3, seq_off, b_src, b_seq;
integer n_alarm2, n_alarm3, n_normal_after, first_alarm;
integer seq_hold, seq_pass, seq_rel, n_staff, n_normal_rel, staff_seq;

task wait_frames;
    input integer n;
    integer target;
    begin
        target = frames_complete + n;
        wait (frames_complete >= target || errors > 50);
    end
endtask

task set_security;
    input [1:0] level;
    input       who;
    begin
        @(negedge vclk);
        alarm_level = level;
        present = who;
        $display("[%0t] security: level %0d, present %0d (frame_sequence %0d)", $time,
                 level, who, dut.frame_sequence);
        $fflush;
    end
endtask

initial begin
    seq_l1 = 0; seq_l2 = 0; seq_l3 = 0; seq_off = 0;
    seq_hold = 0; seq_pass = 0; seq_rel = 0;
    #100;
    vrst_n = 1'b1;
    #200;
    erst = 1'b0;

    if (REAL != 0) begin
        // One QC burst from the very first frame: frames 1..4 = phases 0..3.
        pulse_qc;
        stop_frames = 5;
    end else begin
        wait (dut.frame_sequence >= 1);
        pulse_qc;                                   // burst A (QC)
        wait (dut.u_burst.active && dut.u_burst.phase == 2'd1);
        pulse_qc;                                   // burst B, queued during A
        wait (dut.u_burst.active && dut.u_burst.burst_id == 2'd2 && dut.u_burst.phase == 2'd1);
        skip_one_frame;                             // inside B
        wait (!dut.u_burst.active);
        timer_on_seq = dut.frame_sequence;
        timer_en = 1'b1;                            // security mode from here
        wait_frames(16);                            // nobody there: NORMAL bursts
        set_security(2'd1, 1'b1);                   // motion, not confirmed
        seq_l1 = dut.frame_sequence;
        wait_frames(14);
        set_security(2'd2, 1'b1);                   // a face: ALARM level 2
        seq_l2 = dut.frame_sequence;
        wait_frames(14);
        set_security(2'd3, 1'b1);                   // (a new episode, no face)
        seq_l3 = dut.frame_sequence;
        wait_frames(14);
        set_security(2'd3, 1'b0);                   // they left; level still 3
        seq_off = dut.frame_sequence;
        wait_frames(14);
        // 10-29 staff verification: the hold first, then the face (so no
        // alarm can start in between), a pass while held, then release.
        @(negedge vclk); sec_hold = 1'b1;
        seq_hold = dut.frame_sequence;
        $display("[%0t] sec_hold 1 (frame_sequence %0d)", $time, seq_hold);
        set_security(2'd2, 1'b1);
        wait_frames(14);                            // verifying: no burst at all
        @(negedge vclk); staff_pass = 1'b1;
        seq_pass = dut.frame_sequence;
        $display("[%0t] staff_pass 1 (frame_sequence %0d)", $time, seq_pass);
        wait_frames(18);                            // one staff record, then nothing
        @(negedge vclk); staff_pass = 1'b0;
        set_security(2'd0, 1'b0);
        @(negedge vclk); sec_hold = 1'b0;
        seq_rel = dut.frame_sequence;
        $display("[%0t] sec_hold 0 (frame_sequence %0d)", $time, seq_rel);
        stop_frames = frames_complete + 14;
    end

    wait (frames_complete + frames_incomplete >= stop_frames || errors > 50);
    #1000;

    // ---- burst structure, from the frame log ----------------------------
    bursts_qc = 0;
    bursts_timer = 0;
    n_alarm2 = 0;
    n_alarm3 = 0;
    n_normal_after = 0;
    n_staff = 0;
    n_normal_rel = 0;
    staff_seq = -1;
    first_alarm = -1;
    have_id = 0;
    last_id = 0;
    k = 0;
    while (k < n_log) begin
        if (log_flags[k] == 8'd0) begin
            k = k + 1;
        end else begin
            if (log_flags[k][1] !== 1'b1)
                fail("member flags: bit1 must be 1");
            if (log_flags[k][0] === 1'b1 && log_flags[k][5:4] !== 2'd1)
                fail("member flags: bit0 (staff record) on a source other than 1");
            if (log_flags[k][3:2] !== 2'd0) begin
                fail("a burst does not start at phase 0");
                k = k + 1;
            end else begin
                if (k + 3 >= n_log) begin
                    $display("  (burst at seq %0d cut by the end of the run)", log_seq[k]);
                    k = n_log;
                end else begin
                    for (j = 1; j < 4; j = j + 1) begin
                        if (log_seq[k + j] !== log_seq[k] + j)
                            fail("burst frames are not consecutive sequence numbers");
                        if (log_flags[k + j] !== {log_flags[k][7:4], j[1:0], 1'b1, log_flags[k][0]})
                            fail("burst phase / source / id / staff bit wrong");
                    end
                    if (have_id && log_flags[k][7:6] !== last_id[1:0] + 2'd1)
                        fail("burst id did not step by one");
                    have_id = 1;
                    last_id = log_flags[k][7:6];
                    b_src = log_flags[k][5:4];
                    b_seq = log_seq[k];
                    if (b_src == 0) bursts_qc = bursts_qc + 1;
                    else begin
                        if (REAL == 0 && b_seq <= timer_on_seq)
                            fail("security burst before I_timer_en");
                        if (b_src == 1 && log_flags[k][0]) begin
                            n_staff = n_staff + 1;
                            staff_seq = b_seq;
                            if (b_seq <= seq_pass || b_seq > seq_pass + STAFF_DELAY + 6)
                                fail("staff record not within a few frames of staff_pass");
                        end else if (b_src == 1) begin
                            bursts_timer = bursts_timer + 1;
                            // A normal burst decided just before someone
                            // arrived may still start a few frames later
                            // (queued behind a running burst at worst).
                            if (b_seq > seq_l1 + 5 && b_seq <= seq_off)
                                fail("NORMAL burst while someone was present");
                            if (b_seq > seq_off) n_normal_after = n_normal_after + 1;
                            // Already running when the hold rose: may finish.
                            if (b_seq > seq_hold + 2 && b_seq <= seq_rel)
                                fail("NORMAL burst while sec_hold was high");
                            if (seq_rel != 0 && b_seq > seq_rel) n_normal_rel = n_normal_rel + 1;
                        end else begin
                            if (b_seq <= seq_l2)
                                fail("ALARM burst before level 2/3 (level 1 must give none)");
                            if (b_seq > seq_off + 7)
                                fail("ALARM burst more than a period after they left");
                            if (first_alarm < 0) first_alarm = b_seq;
                            if (b_src == 2) n_alarm2 = n_alarm2 + 1;
                            if (b_src == 3) begin
                                n_alarm3 = n_alarm3 + 1;
                                if (b_seq <= seq_l3)
                                    fail("level-3 burst before level 3");
                            end
                        end
                    end
                    $display("  burst id %0d src %0d at seq %0d..%0d", log_flags[k][7:6],
                             log_flags[k][5:4], log_seq[k], log_seq[k] + 3);
                    k = k + 4;
                end
            end
        end
    end

    $display("--- summary");
    $display("  frames complete / abandoned : %0d / %0d", frames_complete, frames_incomplete);
    $display("  VS edges started / skipped  : %0d / %0d", started_vs, skipped_vs);
    $display("  QC triggers / QC bursts     : %0d / %0d", qc_triggers, bursts_qc);
    $display("  normal bursts (src 1)       : %0d (%0d after they left)", bursts_timer, n_normal_after);
    $display("  alarm bursts level 2 / 3    : %0d / %0d", n_alarm2, n_alarm3);
    $display("  staff records               : %0d (at seq %0d, staff_pass at %0d)", n_staff, staff_seq, seq_pass);
    $display("  normal bursts after release : %0d", n_normal_rel);
    if (REAL == 0)
        $display("  first alarm burst at seq %0d, level 2 set at seq %0d", first_alarm, seq_l2);
    if (frames_incomplete != 0) fail("frames were abandoned");
    if (bursts_qc != qc_triggers) fail("a QC trigger did not produce exactly one burst");
    if (REAL == 0) begin
        if (bursts_timer < 1) fail("no normal burst in security mode with nobody present");
        if (skipped_vs < 1) fail("the skip scenario did not skip a frame");
        if (n_alarm2 < 2) fail("too few level-2 alarm bursts");
        if (n_alarm3 < 1) fail("no level-3 alarm burst");
        if (n_normal_after < 1) fail("no normal burst after they left");
        if (first_alarm < 0 || first_alarm > seq_l2 + 2)
            fail("first alarm burst not within two frames of the alarm");
        if (n_staff != 1) fail("staff_pass did not give exactly one staff record");
        if (n_normal_rel < 1) fail("no normal burst after the hold fell");
    end

    if (errors == 0) $display("\n=== TB_BURST PASS ===\n");
    else             $display("\n=== TB_BURST FAIL (%0d errors) ===\n", errors);
    $finish;
end

initial begin
    #(TIMEOUT_NS);
    $display("\n=== TB_BURST FAIL: TIMEOUT ===");
    $display("  frames_complete=%0d abandoned=%0d errors=%0d burst active=%0d phase=%0d",
             frames_complete, frames_incomplete, errors, dut.u_burst.active, dut.u_burst.phase);
    $finish;
end

endmodule
