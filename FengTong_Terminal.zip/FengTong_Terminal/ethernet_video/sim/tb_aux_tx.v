`timescale 1ns/1ps

// evs_aux_tx bench: EVS1 video, EVDBG1 status and EVQC1 workpiece records
// sharing one modelled UDP stack.
//
// WHAT IT PROVES
//   1. Every video frame still arrives complete and pixel-exact while status
//      packets are forced to collide with it constantly (DIAG_TICK is cut
//      from 1 s to ~24 us, so a status packet competes for almost every
//      inter-packet gap of a streaming frame).
//   2. EVDBG1 keeps its 16-byte layout.
//   3. Each valid QC record arrives exactly QC_REPEAT times, in repeat order,
//      byte-exact and with a correct XOR; a record with bit 127 clear is never
//      sent; a record that replaces a pending one cuts its repeats short and
//      restarts with its own.
//   4. With LEGACY_RELEASE=1 (the release point eth_a_video_endpoint used up
//      to v1.0) the same traffic loses video datagrams.  That run is expected
//      to fail, and the bench reports PASS only if it does -- so the failure
//      the fix is for is demonstrated, not just argued.
//
// The stack model is tb_frame_abort's: a request is only latched while busy
// is low, busy rises as the acknowledgement, exactly udp_len bytes are taken,
// and busy stays high for the wire time afterwards.  Any byte outside that
// window is a failure, which is exactly how the legacy hazard shows up.
module tb_aux_tx #(
    parameter integer OUT_W = 128,
    parameter integer OUT_H = 64,
    parameter integer H_TOTAL  = 320,
    parameter integer H_ACTIVE = 256,
    parameter integer V_TOTAL  = 144,
    parameter integer V_ACTIVE = 128,
    parameter integer FRAMES   = 6,
    parameter integer TIMEOUT_NS = 20_000_000,
    parameter        LEGACY_RELEASE = 1'b0,
    // 2026-10-09: 1 = EVQC2 (48 bytes, qc_ext at 28..43); 0 = EVQC1 as before
    parameter        QC_V2 = 1'b0,
    // 2026-10-29: EVQC2 byte 5 (3 = the 10-29 qc_ext layout the endpoint sends)
    parameter [7:0]  QC_VER = 8'd2
);
// EVDBG1 byte 11 bits 7:1 (10-29): an asymmetric pattern, so a shifted or
// dropped bit shows.
localparam [6:0] UI_STATE = 7'b1010011;

localparam integer FRAME_BYTES = OUT_W * OUT_H * 2;
localparam integer EXP_PACKETS = (FRAME_BYTES + 1367) / 1368;

localparam integer V_TOP     = (V_TOTAL - V_ACTIVE) / 2;
localparam integer VS_RISE   = 4;
localparam integer VS_FALL   = V_TOP + V_ACTIVE + 4;

localparam integer WIRE_OVERHEAD = 66;  // preamble+MAC+IP+UDP+FCS+IFG

localparam [31:0] DIAG_TICK = 32'd3000;
localparam [31:0] QC_GAP    = 32'd2000;
localparam integer QC_REPEAT = 3;
localparam [1:0] QC_REPEAT2 = 2'd3;
localparam [7:0] QC_REPEAT8 = 8'd3;

reg vclk = 1'b0;
reg eclk = 1'b0;
reg vrst_n = 1'b0;
reg erst = 1'b1;

always #(3.3333) vclk = ~vclk;
always #(4.0)    eclk = ~eclk;

//--------------------------------------------------------------------------
// video source (same pattern as tb_frame_abort)
//--------------------------------------------------------------------------
reg [15:0] hcnt = 16'd0;
reg [15:0] vcnt = 16'd0;

always @(negedge vclk) begin
    if (!vrst_n) begin
        hcnt <= 16'd0;
        vcnt <= 16'd0;
    end else if (hcnt == H_TOTAL - 1) begin
        hcnt <= 16'd0;
        vcnt <= (vcnt == V_TOTAL - 1) ? 16'd0 : vcnt + 16'd1;
    end else begin
        hcnt <= hcnt + 16'd1;
    end
end

wire in_vactive = (vcnt >= V_TOP) && (vcnt < V_TOP + V_ACTIVE);
wire src_de = in_vactive && (hcnt < H_ACTIVE);
wire src_vs = (vcnt >= VS_RISE) && (vcnt < VS_FALL);
wire [15:0] px = hcnt;
wire [15:0] py = vcnt - V_TOP;
wire [23:0] src_rgb = {px[7:0], py[7:0], px[7:0] + py[7:0]};

function [15:0] expect_rgb565;
    input integer sx;
    input integer sy;
    reg [7:0] r, g, b;
    begin
        r = (2 * sx) % 256;
        g = (2 * sy) % 256;
        b = (r + g) % 256;
        expect_rgb565 = {r[7:3], g[7:2], b[7:3]};
    end
endfunction

//--------------------------------------------------------------------------
// QC record source (video clock)
//--------------------------------------------------------------------------
reg qc_trig = 1'b0;
reg [127:0] qc_rec = 128'd0;
reg [127:0] qc_ext = 128'd0;

// Every byte different and tied to the record's sequence number, so a byte
// taken from the wrong offset or the wrong record cannot match by accident.
function [127:0] make_ext;
    input [7:0] seq;
    integer i;
    begin
        make_ext = 128'd0;
        for (i = 0; i < 16; i = i + 1)
            make_ext = {make_ext[119:0], seq ^ (8'h11 * i[7:0]) ^ 8'hA5};
    end
endfunction

function [127:0] make_rec;
    input valid;
    input [7:0] seq;
    reg [15:0] x, y, z, top, base;
    reg [11:0] w, h;
    begin
        x = 16'd20 + seq;
        y = 16'd40 + seq * 2;
        z = 16'd10 + seq * 3;
        top = 16'd250 - seq;
        base = 16'd280;
        w = 12'd300 + seq;
        h = 12'd200 + seq;
        make_rec = {valid, valid, 6'd0, x, y, z, top, base, w, h, seq, 8'd0};
    end
endfunction

//--------------------------------------------------------------------------
// DUT: the real video core and the auxiliary mux, exactly as the endpoint
// wires them
//--------------------------------------------------------------------------
wire v_req, v_valid;
wire [7:0] v_data;
wire [15:0] v_len;
wire v_busy;
wire s_req, s_valid;
wire [7:0] s_data;
wire [15:0] s_len;
wire video_frame_dropped, fifo_overflow, packetizer_error;
wire [31:0] debug_status;
wire [7:0] debug_counts;
wire [7:0] qc_sent;
reg udp_busy;

evs_video_tx_core #(
    .OUT_WIDTH(OUT_W), .OUT_HEIGHT(OUT_H), .SESSION_ID(32'hA5A5_0001)
) dut (
    .I_video_clk(vclk), .I_video_rst_n(vrst_n),
    .I_video_vs(src_vs), .I_video_de(src_de), .I_video_rgb(src_rgb),
    .I_qc_trig(1'b0), .I_timer_en(1'b0), .I_alarm_level(2'd0), .I_present(1'b0),
    .I_sec_hold(1'b0), .I_staff_pass(1'b0),
    .I_eth_clk(eclk), .I_eth_reset(erst), .I_udp_busy(v_busy),
    .O_udp_req(v_req), .O_udp_valid(v_valid), .O_udp_data(v_data),
    .O_udp_len(v_len),
    .O_video_frame_dropped(video_frame_dropped),
    .O_fifo_overflow(fifo_overflow),
    .O_packetizer_error(packetizer_error),
    .O_debug_status(debug_status), .O_debug_counts(debug_counts)
);

evs_aux_tx #(
    .DIAG_TICK(DIAG_TICK), .QC_GAP(QC_GAP), .QC_REPEAT(QC_REPEAT2),
    .LEGACY_RELEASE(LEGACY_RELEASE), .QC_V2(QC_V2), .QC_VER(QC_VER)
) aux (
    .I_clk(eclk), .I_reset(erst),
    .I_udp_busy(udp_busy),
    .O_udp_req(s_req), .O_udp_valid(s_valid), .O_udp_data(s_data), .O_udp_len(s_len),
    .I_video_req(v_req), .I_video_valid(v_valid), .I_video_data(v_data), .I_video_len(v_len),
    .O_video_busy(v_busy),
    .I_debug_status(debug_status), .I_debug_counts(debug_counts), .I_phy_link(1'b1),
    .I_ui_state(UI_STATE), .I_diag_kick(1'b0),
    .I_video_clk(vclk), .I_video_rst_n(vrst_n),
    .I_qc_trig(qc_trig), .I_qc_rec(qc_rec), .I_qc_ext(qc_ext),
    .O_qc_sent(qc_sent)
);

//--------------------------------------------------------------------------
// checking infrastructure
//--------------------------------------------------------------------------
integer errors = 0;

task fail;
    input [1023:0] msg;
    begin
        errors = errors + 1;
        if (errors <= 20)
            $display("[%0t] FAIL: %0s", $time, msg);
        $fflush;
    end
endtask

task say;
    input [1023:0] msg;
    begin
        $display("[%0t] %0s", $time, msg);
        $fflush;
    end
endtask

function [31:0] crc32_tb;
    input [31:0] crc_in;
    input [7:0] data;
    integer k;
    reg [31:0] c;
    begin
        c = crc_in ^ data;
        for (k = 0; k < 8; k = k + 1)
            c = c[0] ? ((c >> 1) ^ 32'hEDB88320) : (c >> 1);
        crc32_tb = c;
    end
endfunction

//--------------------------------------------------------------------------
// expected QC records
//--------------------------------------------------------------------------
localparam integer NREC = 8;
reg [127:0] exp_rec [0:NREC-1];
reg [127:0] exp_ext [0:NREC-1];
reg         exp_sent [0:NREC-1];      // trigger has been issued
reg         exp_valid [0:NREC-1];
reg         exp_replaced [0:NREC-1];  // a newer record arrived before its repeats ended
integer     exp_fseq_min [0:NREC-1];
integer     got_count [0:NREC-1];
integer     qc_packets = 0;
integer     diag_packets = 0;
integer     video_datagrams = 0;
integer     n_rec = 0;

//--------------------------------------------------------------------------
// UDP stack model
//--------------------------------------------------------------------------
localparam [1:0] K_IDLE = 2'd0;
localparam [1:0] K_ACK  = 2'd1;
localparam [1:0] K_DATA = 2'd2;
localparam [1:0] K_WIRE = 2'd3;

reg [1:0] stk_state = K_IDLE;
reg [15:0] stk_delay = 16'd0;
reg [15:0] rx_len = 16'd0;
reg [15:0] rx_cnt = 16'd0;
reg [7:0] rx_buf [0:1499];

reg [7:0] fbuf [0:FRAME_BYTES-1];
integer fbytes = 0;
integer next_idx = 0;
reg [31:0] cur_seq = 32'hFFFF_FFFF;
reg frame_tracking = 1'b0;
integer frames_complete = 0;
integer frames_incomplete = 0;

task check_video;
    integer i, sx, sy, base, bad;
    reg [31:0] crc, hcrc, seq;
    reg [15:0] idx, cnt, plen, e;
    begin
        video_datagrams = video_datagrams + 1;
        if (rx_buf[4] !== 8'd1) fail("EVS1 version != 1");
        if ({rx_buf[6], rx_buf[7]} !== 16'd32) fail("EVS1 header length != 32");
        seq  = {rx_buf[12], rx_buf[13], rx_buf[14], rx_buf[15]};
        idx  = {rx_buf[16], rx_buf[17]};
        cnt  = {rx_buf[18], rx_buf[19]};
        plen = {rx_buf[26], rx_buf[27]};
        hcrc = {rx_buf[28], rx_buf[29], rx_buf[30], rx_buf[31]};
        if (cnt !== EXP_PACKETS[15:0]) fail("EVS1 packet_count wrong");
        if (plen !== rx_len - 16'd32) fail("EVS1 payload_count disagrees with udp_len");

        crc = 32'hFFFF_FFFF;
        for (i = 0; i < plen; i = i + 1)
            crc = crc32_tb(crc, rx_buf[32 + i]);
        if (~crc !== hcrc) fail("EVS1 payload CRC32 mismatch");

        if (!frame_tracking || seq !== cur_seq) begin
            if (frame_tracking && next_idx != 0) begin
                frames_incomplete = frames_incomplete + 1;
                $display("[%0t]   frame seq=%0d abandoned after %0d/%0d packets",
                         $time, cur_seq, next_idx, EXP_PACKETS);
                $fflush;
            end
            cur_seq = seq;
            frame_tracking = 1'b1;
            next_idx = 0;
            fbytes = 0;
        end

        if (idx !== next_idx[15:0]) begin
            fail("EVS1 packet_index not contiguous (a video datagram was lost)");
            frame_tracking = 1'b0;
            next_idx = 0;
            fbytes = 0;
        end else begin
            for (i = 0; i < plen; i = i + 1)
                fbuf[fbytes + i] = rx_buf[32 + i];
            fbytes = fbytes + plen;
            next_idx = next_idx + 1;
            if (next_idx == EXP_PACKETS) begin
                bad = 0;
                for (sy = 0; sy < OUT_H; sy = sy + 1)
                    for (sx = 0; sx < OUT_W; sx = sx + 1) begin
                        e = expect_rgb565(sx, sy);
                        base = 2 * (sy * OUT_W + sx);
                        if (fbuf[base] !== e[15:8] || fbuf[base + 1] !== e[7:0])
                            bad = bad + 1;
                    end
                if (bad != 0) begin
                    $display("[%0t]   frame seq=%0d: %0d pixels wrong", $time, seq, bad);
                    fail("frame pixel content does not match the source pattern");
                end else begin
                    frames_complete = frames_complete + 1;
                    $display("[%0t]   frame seq=%0d COMPLETE and pixel-exact", $time, seq);
                    $fflush;
                end
                frame_tracking = 1'b0;
                next_idx = 0;
                fbytes = 0;
            end
        end
    end
endtask

task check_diag;
    begin
        diag_packets = diag_packets + 1;
        if (rx_len !== 16'd16) fail("EVDBG1 length != 16");
        if (rx_buf[4] !== "G" || rx_buf[5] !== "1") fail("EVDBG1 magic wrong");
        if (rx_buf[13] !== 8'h0d || rx_buf[14] !== 8'h0a || rx_buf[15] !== 8'h01)
            fail("EVDBG1 trailer wrong");
        if (rx_buf[11] !== {UI_STATE, 1'b1}) fail("EVDBG1 byte 11 != {ui_state, phy_link}");
    end
endtask

task check_qc;
    integer i, k, found, fseq_now;
    reg [7:0] x;
    reg [127:0] rec, ext;
    reg [15:0] fseq;
    begin
        qc_packets = qc_packets + 1;
        if (!QC_V2) begin
            if (rx_len !== 16'd32) fail("EVQC1 length != 32");
            if (rx_buf[4] !== "1") fail("EVQC1 magic wrong");
            if (rx_buf[5] !== 8'd1) fail("EVQC1 version != 1");
            if (rx_buf[28] !== 8'd0 || rx_buf[29] !== 8'd0 || rx_buf[30] !== 8'd0)
                fail("EVQC1 reserved bytes not zero");
            x = 8'd0;
            for (i = 0; i < 31; i = i + 1)
                x = x ^ rx_buf[i];
            if (x !== rx_buf[31]) fail("EVQC1 XOR mismatch");
        end else begin
            if (rx_len !== 16'd48) fail("EVQC2 length != 48");
            if (rx_buf[4] !== "2") fail("EVQC2 magic wrong");
            if (rx_buf[5] !== QC_VER) fail("EVQC2 version byte != QC_VER");
            if (rx_buf[44] !== 8'd0 || rx_buf[45] !== 8'd0 || rx_buf[46] !== 8'd0)
                fail("EVQC2 reserved bytes not zero");
            x = 8'd0;
            for (i = 0; i < 47; i = i + 1)
                x = x ^ rx_buf[i];
            if (x !== rx_buf[47]) fail("EVQC2 XOR mismatch");
        end
        if (rx_buf[7] !== QC_REPEAT8) fail("EVQC repeat total wrong");
        if (rx_buf[10] !== 8'd0 || rx_buf[11] !== 8'd0)
            fail("EVQC reserved bytes 10..11 not zero");
        rec = 128'd0;
        for (i = 0; i < 16; i = i + 1)
            rec = {rec[119:0], rx_buf[12 + i]};
        ext = 128'd0;
        for (i = 0; i < 16; i = i + 1)
            ext = {ext[119:0], rx_buf[28 + i]};
        fseq = {rx_buf[8], rx_buf[9]};
        fseq_now = dut.frame_sequence;

        found = -1;
        for (k = 0; k < n_rec; k = k + 1)
            if (exp_rec[k][15:8] == rec[15:8])
                found = k;
        if (found < 0) begin
            fail("EVQC1 carries a record the bench never triggered");
        end else begin
            if (!exp_valid[found]) fail("EVQC1 sent a record whose valid bit is clear");
            if (rec !== exp_rec[found]) fail("EVQC1 record bytes differ from qc_rec");
            if (QC_V2 && ext !== exp_ext[found]) fail("EVQC2 qc_ext bytes differ from qc_ext");
            if (rx_buf[6] !== got_count[found]) fail("EVQC1 repeat index out of order");
            if (fseq < exp_fseq_min[found] || fseq > fseq_now)
                fail("EVQC1 frame_sequence outside [trigger, now]");
            got_count[found] = got_count[found] + 1;
            $display("[%0t]   EVQC1 seq=%0d repeat %0d/%0d fseq=%0d", $time,
                     rec[15:8], rx_buf[6], QC_REPEAT, fseq);
            $fflush;
        end
    end
endtask

task dispatch;
    begin
        if (rx_buf[0] == "E" && rx_buf[1] == "V" && rx_buf[2] == "S" && rx_buf[3] == "1")
            check_video;
        else if (rx_buf[0] == "E" && rx_buf[1] == "V" && rx_buf[2] == "D" && rx_buf[3] == "B")
            check_diag;
        else if (rx_buf[0] == "E" && rx_buf[1] == "V" && rx_buf[2] == "Q" && rx_buf[3] == "C")
            check_qc;
        else
            fail("datagram with an unknown magic (corrupted or misaligned)");
    end
endtask

always @(posedge eclk or posedge erst) begin
    if (erst) begin
        stk_state <= K_IDLE;
        udp_busy <= 1'b0;
        stk_delay <= 16'd0;
        rx_cnt <= 16'd0;
        rx_len <= 16'd0;
    end else begin
        case (stk_state)
            K_IDLE: begin
                if (s_valid) fail("udp_valid asserted while the stack is idle");
                if (s_req) begin
                    stk_delay <= 16'd3;
                    stk_state <= K_ACK;
                end
            end
            K_ACK: begin
                if (s_valid) fail("udp_valid asserted before the stack acknowledged");
                if (stk_delay != 16'd0) begin
                    stk_delay <= stk_delay - 16'd1;
                end else begin
                    udp_busy <= 1'b1;
                    rx_len <= s_len;
                    rx_cnt <= 16'd0;
                    stk_state <= K_DATA;
                end
            end
            K_DATA: begin
                if (s_valid) begin
                    rx_buf[rx_cnt] <= s_data;
                    rx_cnt <= rx_cnt + 16'd1;
                    if (rx_cnt + 16'd1 == rx_len) begin
                        stk_delay <= WIRE_OVERHEAD[15:0];
                        stk_state <= K_WIRE;
                    end
                end
            end
            K_WIRE: begin
                if (s_valid) fail("udp_valid while the stack is still sending the previous datagram");
                if (stk_delay != 16'd0) begin
                    stk_delay <= stk_delay - 16'd1;
                end else begin
                    udp_busy <= 1'b0;
                    dispatch;
                    stk_state <= K_IDLE;
                end
            end
        endcase
    end
end

//--------------------------------------------------------------------------
// test sequence
//--------------------------------------------------------------------------
task trigger;
    input valid;
    input [7:0] seq;
    begin
        @(negedge vclk);
        exp_rec[n_rec] = make_rec(valid, seq);
        exp_ext[n_rec] = make_ext(seq);
        exp_valid[n_rec] = valid;
        exp_sent[n_rec] = 1'b1;
        exp_replaced[n_rec] = 1'b0;
        exp_fseq_min[n_rec] = dut.frame_sequence;
        got_count[n_rec] = 0;
        // qc_thick latches the record on the trigger clock and holds it.
        qc_rec = exp_rec[n_rec];
        qc_ext = exp_ext[n_rec];
        qc_trig = 1'b1;
        @(negedge vclk);
        qc_trig = 1'b0;
        n_rec = n_rec + 1;
    end
endtask

task wait_us;
    input integer us;
    begin
        #(us * 1000);
    end
endtask

integer k, missing;

initial begin
    say(LEGACY_RELEASE ? "tb_aux_tx: LEGACY_RELEASE=1, expecting lost video datagrams"
                       : "tb_aux_tx: fixed release, expecting zero loss");
    #100;
    vrst_n = 1'b1;
    #200;
    erst = 1'b0;

    // let the first frame get going, then fire records at various phases
    wait (dut.frame_sequence >= 1);
    wait_us(40);
    trigger(1'b1, 8'd1);           // ordinary record
    wait_us(120);
    trigger(1'b0, 8'd2);           // valid bit clear: must never be sent
    wait_us(60);
    trigger(1'b1, 8'd3);
    wait_us(5);                    // before its second repeat (QC_GAP = 16 us)
    exp_replaced[n_rec - 1] = 1'b1;
    trigger(1'b1, 8'd4);           // replaces 3
    wait (dut.frame_sequence >= 3);
    wait_us(30);
    trigger(1'b1, 8'd5);

    wait (frames_complete + frames_incomplete >= FRAMES || errors > 50);
    wait_us(100);                  // let the last repeats drain

    say("--- summary");
    $display("  video datagrams : %0d", video_datagrams);
    $display("  frames complete : %0d", frames_complete);
    $display("  frames abandoned: %0d", frames_incomplete);
    $display("  EVDBG1 packets  : %0d", diag_packets);
    $display("  EVQC1 packets   : %0d (DUT counter %0d)", qc_packets, qc_sent);

    missing = 0;
    for (k = 0; k < n_rec; k = k + 1) begin
        $display("  record seq=%0d valid=%0d replaced=%0d received %0d time(s)",
                 exp_rec[k][15:8], exp_valid[k], exp_replaced[k], got_count[k]);
        if (exp_valid[k] && !exp_replaced[k] && got_count[k] != QC_REPEAT) missing = missing + 1;
        // A replaced record may not even have had its first slot yet.
        if (exp_valid[k] && exp_replaced[k] && got_count[k] >= QC_REPEAT)
            missing = missing + 1;
        if (!exp_valid[k] && got_count[k] != 0) missing = missing + 1;
    end
    if (missing != 0) fail("QC records not received the expected number of times");
    if (diag_packets < 20) fail("too few EVDBG1 packets to have exercised the collision case");
    if (frames_incomplete != 0) fail("video frames were abandoned");

    if (LEGACY_RELEASE) begin
        if (errors != 0)
            $display("\n=== TB_AUX_TX PASS (legacy release reproduced the loss: %0d errors) ===\n", errors);
        else
            $display("\n=== TB_AUX_TX FAIL (legacy release did NOT reproduce the loss) ===\n");
    end else begin
        if (errors == 0)
            $display("\n=== TB_AUX_TX PASS ===\n");
        else
            $display("\n=== TB_AUX_TX FAIL (%0d errors) ===\n", errors);
    end
    $finish;
end

initial begin
    #(TIMEOUT_NS);
    $display("\n=== TB_AUX_TX FAIL: TIMEOUT ===");
    $display("  frames_complete=%0d abandoned=%0d diag=%0d qc=%0d errors=%0d",
             frames_complete, frames_incomplete, diag_packets, qc_packets, errors);
    if (LEGACY_RELEASE && errors != 0)
        $display("  (legacy run: errors were seen, so the loss WAS reproduced)");
    $finish;
end

endmodule
