`timescale 1ns/1ps

// Frame-abort recovery and sustained-throughput bench for evs_video_tx_core.
//
// WHAT IT REPRODUCES
//
// On 2026-09-21 the board sent 6 correct EVS1 packets and then stopped for
// good: the sampler cut the first frame at the FIFO high-water mark without
// ever producing a last byte, so the bridge and the packetizer waited forever
// for the remainder of a frame that no longer existed and frame_sequence
// stayed at 1.  Here the same condition is produced on purpose by stalling
// the UDP stack model until the FIFO backs up, then releasing it.  The bench
// fails on timeout if the recovery path does not exist -- which is exactly
// how the original defect would have been caught.
//
// WHY THE STALL IS RELEASED BEFORE THE ABORT IS CHECKED
//
// Recovery is inherently a two-step affair and the bench has to follow it.
// The sampler queues the abort marker only once the FIFO is back below its
// high-water mark, and the bridge can only reach that marker after consuming
// the bytes already queued ahead of it.  Both need the stack to be draining
// again, so waiting for abort_count while still stalled can never succeed.
// That also mirrors the board, where the stall was a transient ARP/diagnostic
// arbitration gap rather than a permanent one.
//
// WHY THIS GEOMETRY
//
// OUT_WIDTH/OUT_HEIGHT are already parameters of the DUT, so no RTL is
// modified for the bench.  The frame must be big enough that the FIFO
// actually backs up past ALMOST_FULL_WORDS (8000) while everything
// downstream is full: two payload banks (2736) + skid (8) + output register
// plus whatever already went out (2 datagrams, 2736) absorb ~5.5 KB, so a
// 10 KB frame is quietly swallowed whole and never triggers afull -- the
// first version of this bench failed exactly that way.  128x64 gives 16384
// frame bytes against a ~13.5 KB threshold, and still costs only ~46k video
// clocks per frame instead of the real design's ~2.5M.  PAYLOAD_BYTES stays
// 1368, so packet_count is 12 with a 1336-byte final packet and the
// short-last-packet path is exercised too.
//
// THE UDP STACK IS MODELLED, NOT INSTANTIATED
//
// uiudp_tx instantiates PH1_LOGIC_SHIFTER, an Anlogic hard primitive that no
// open simulator can elaborate.  The model below reproduces the part of the
// contract the packetizer depends on: a request is only latched while busy is
// low, busy then rises as the acknowledgement, exactly udp_len bytes are
// consumed, and busy stays high for the remaining wire time.  It asserts on
// any byte arriving outside that window, which is what guards the new
// back-to-back request path.
// Defaults are the fast geometry.  Override from the command line to re-run
// the identical scenario at the real 960x540 / 1920x1080 sizes, which is what
// checks the counter widths (FRAME_PIXELS 518400 against sampled_pixels[19:0])
// and packet_count=758 rather than just the mechanism:
//
//   -Ptb_frame_abort.OUT_W=960 -Ptb_frame_abort.OUT_H=540
//   -Ptb_frame_abort.H_TOTAL=2200 -Ptb_frame_abort.H_ACTIVE=1920
//   -Ptb_frame_abort.V_TOTAL=1125 -Ptb_frame_abort.V_ACTIVE=1080
//   -Ptb_frame_abort.TIMEOUT_NS=200000000
module tb_frame_abort #(
    parameter integer OUT_W = 128,
    parameter integer OUT_H = 64,
    // Source timing.  256x128 active decimates by two to exactly 128x64,
    // which is what keeps the sampler's pixel counter in step with
    // FRAME_PIXELS.  The blanking ratio is close to the real 2200/1125 so the
    // write-side duty cycle (~60 MB/s average, 150 MB/s burst) stays
    // representative.
    parameter integer H_TOTAL  = 320,
    parameter integer H_ACTIVE = 256,
    parameter integer V_TOTAL  = 144,
    parameter integer V_ACTIVE = 128,
    parameter integer TIMEOUT_NS = 20_000_000,
    // How many pixel-exact frames to demand after the abort.  Each real-
    // geometry frame costs 16.5 ms of simulated time, so the real run asks
    // for fewer and leans on the FIFO high-water measurement below instead.
    parameter integer FRAMES_AFTER_ABORT = 3
);

localparam integer FRAME_BYTES = OUT_W * OUT_H * 2;
localparam integer EXP_PACKETS = (FRAME_BYTES + 1367) / 1368;

localparam integer V_TOP     = (V_TOTAL - V_ACTIVE) / 2;
localparam integer VS_RISE   = 4;
localparam integer VS_FALL   = V_TOP + V_ACTIVE + 4;

localparam integer WIRE_OVERHEAD = 66;  // preamble+MAC+IP+UDP+FCS+IFG

reg vclk = 1'b0;
reg eclk = 1'b0;
reg vrst_n = 1'b0;
reg erst = 1'b1;

// 150 MHz video / 125 MHz Ethernet, same ratio as the real design.
always #(3.3333) vclk = ~vclk;
always #(4.0)    eclk = ~eclk;

//--------------------------------------------------------------------------
// video source
//--------------------------------------------------------------------------
reg [15:0] hcnt = 16'd0;
reg [15:0] vcnt = 16'd0;

always @(negedge vclk) begin
    if (!vrst_n) begin
        hcnt <= 16'd0;
        vcnt <= 16'd0;
    end else if (hcnt == H_TOTAL - 1) begin
        hcnt <= 16'd0;
        vcnt <= (vcnt == V_TOTAL - 1) ? 16'd0 : vcnt + 16'd1;
    end else begin
        hcnt <= hcnt + 16'd1;
    end
end

wire in_vactive = (vcnt >= V_TOP) && (vcnt < V_TOP + V_ACTIVE);
wire src_de = in_vactive && (hcnt < H_ACTIVE);
wire src_vs = (vcnt >= VS_RISE) && (vcnt < VS_FALL);
wire [15:0] px = hcnt;
wire [15:0] py = vcnt - V_TOP;
wire [23:0] src_rgb = {px[7:0], py[7:0], px[7:0] + py[7:0]};

// Independent model of what the sampler must produce for sampled pixel
// (sx,sy): source pixel (2*sx, 2*sy) through the RGB888->RGB565 truncation.
function [15:0] expect_rgb565;
    input integer sx;
    input integer sy;
    reg [7:0] r, g, b;
    begin
        r = (2 * sx) % 256;
        g = (2 * sy) % 256;
        b = (r + g) % 256;
        expect_rgb565 = {r[7:3], g[7:2], b[7:3]};
    end
endfunction

//--------------------------------------------------------------------------
// DUT
//--------------------------------------------------------------------------
wire udp_req, udp_valid;
wire [7:0] udp_data;
wire [15:0] udp_len;
wire video_frame_dropped, fifo_overflow, packetizer_error;
wire [31:0] debug_status;
wire [7:0] debug_counts;
reg udp_busy;

evs_video_tx_core #(
    .OUT_WIDTH(OUT_W), .OUT_HEIGHT(OUT_H), .SESSION_ID(32'hA5A5_0001)
) dut (
    .I_video_clk(vclk), .I_video_rst_n(vrst_n),
    .I_video_vs(src_vs), .I_video_de(src_de), .I_video_rgb(src_rgb),
    .I_qc_trig(1'b0), .I_timer_en(1'b0), .I_alarm_level(2'd0), .I_present(1'b0),
    .I_sec_hold(1'b0), .I_staff_pass(1'b0),
    .I_eth_clk(eclk), .I_eth_reset(erst), .I_udp_busy(udp_busy),
    .O_udp_req(udp_req), .O_udp_valid(udp_valid), .O_udp_data(udp_data),
    .O_udp_len(udp_len),
    .O_video_frame_dropped(video_frame_dropped),
    .O_fifo_overflow(fifo_overflow),
    .O_packetizer_error(packetizer_error),
    .O_debug_status(debug_status), .O_debug_counts(debug_counts)
);

//--------------------------------------------------------------------------
// stream-level instrumentation
//--------------------------------------------------------------------------
// A frame-level compare says a byte is wrong but not which stage produced
// it.  These two snoops check the same expected byte stream where the
// sampler writes it and where the bridge hands it to the packetizer, so the
// failing stage is identified rather than inferred.
integer samp_idx = 0;
integer deliv_idx = 0;
integer samp_errors = 0;
integer deliv_errors = 0;
reg stream_check = 1'b0;
reg samp_armed = 1'b0;
reg deliv_armed = 1'b0;

function [7:0] expect_byte_at;
    input integer idx;
    integer pixel, ex, ey;
    reg [15:0] e;
    begin
        pixel = idx >> 1;
        ex = pixel % OUT_W;
        ey = pixel / OUT_W;
        e = expect_rgb565(ex, ey);
        expect_byte_at = (idx % 2) ? e[7:0] : e[15:8];
    end
endfunction

always @(posedge vclk) begin
    if (dut.sampler_wr_en) begin
        if (dut.sampler_word[9] && dut.sampler_word[8]) begin
            samp_armed = 1'b0;            // abort marker: no picture data
        end else begin
            if (dut.sampler_word[9]) begin
                samp_idx = 0;
                samp_armed = stream_check;
            end
            if (samp_armed && dut.sampler_word[7:0] !== expect_byte_at(samp_idx)) begin
                if (samp_errors < 6)
                    $display("[%0t]   SAMPLER byte %0d (pkt %0d, off %0d): got %02x want %02x",
                             $time, samp_idx, samp_idx / 1368, samp_idx % 1368,
                             dut.sampler_word[7:0], expect_byte_at(samp_idx));
                samp_errors = samp_errors + 1;
            end
            samp_idx = samp_idx + 1;
        end
    end
end

always @(posedge eclk) begin
    if (dut.packet_start) begin
        deliv_idx = 0;
        deliv_armed = stream_check;
    end
    if (dut.packet_abort) deliv_armed = 1'b0;
    if (dut.packet_src_valid && dut.packetizer_src_ready) begin
        if (deliv_armed && dut.packet_src_byte !== expect_byte_at(deliv_idx)) begin
            if (deliv_errors < 6)
                $display("[%0t]   BRIDGE byte %0d (pkt %0d, off %0d): got %02x want %02x",
                         $time, deliv_idx, deliv_idx / 1368, deliv_idx % 1368,
                         dut.packet_src_byte, expect_byte_at(deliv_idx));
            deliv_errors = deliv_errors + 1;
        end
        deliv_idx = deliv_idx + 1;
    end
end

//--------------------------------------------------------------------------
// FIFO occupancy monitor
//--------------------------------------------------------------------------
// Counting delivered frames only proves the read path kept up on average.
// The peak FIFO fill is the direct measurement: the CDC FIFO is 8 Ki words
// against a ~1 MB frame, so it can only ride out the per-line write burst,
// never a frame-scale deficit.  A peak that creeps towards ALMOST_FULL_WORDS
// (8000) means the margin is thin even if no frame was actually lost yet --
// which is precisely the state the board was in.
localparam integer AFULL_WORDS = 8000;

reg [15:0] fifo_peak = 16'd0;
reg peak_arm = 1'b0;
wire [15:0] fifo_used = {3'b000, dut.u_frame_fifo.u_fifo.wrusedw};

always @(posedge vclk) begin
    if (peak_arm && fifo_used > fifo_peak)
        fifo_peak <= fifo_used;
end

//--------------------------------------------------------------------------
// checking infrastructure
//--------------------------------------------------------------------------
integer errors = 0;

task fail;
    input [1023:0] msg;
    begin
        errors = errors + 1;
        $display("[%0t] FAIL: %0s", $time, msg);
        $fflush;
    end
endtask

// vvp buffers stdout whenever it is redirected to a file, so a long run
// otherwise shows nothing at all until it exits -- which is impossible to
// tell apart from a hang.  Flush after every progress line instead.
task say;
    input [1023:0] msg;
    begin
        $display("[%0t] %0s", $time, msg);
        $fflush;
    end
endtask

function [31:0] crc32_tb;
    input [31:0] crc_in;
    input [7:0] data;
    integer k;
    reg [31:0] c;
    begin
        c = crc_in ^ data;
        for (k = 0; k < 8; k = k + 1)
            c = c[0] ? ((c >> 1) ^ 32'hEDB88320) : (c >> 1);
        crc32_tb = c;
    end
endfunction

//--------------------------------------------------------------------------
// UDP stack model
//--------------------------------------------------------------------------
localparam [1:0] K_IDLE = 2'd0;
localparam [1:0] K_ACK  = 2'd1;
localparam [1:0] K_DATA = 2'd2;
localparam [1:0] K_WIRE = 2'd3;

reg [1:0] stk_state = K_IDLE;
reg [15:0] stk_delay = 16'd0;
reg [15:0] rx_len = 16'd0;
reg [15:0] rx_cnt = 16'd0;
reg [7:0] rx_buf [0:1499];
integer datagrams_done = 0;
reg stall_stack = 1'b0;

// frame reassembly state
reg [7:0] fbuf [0:FRAME_BYTES-1];
integer fbytes = 0;
integer next_idx = 0;
reg [31:0] cur_seq = 32'hFFFF_FFFF;
reg frame_tracking = 1'b0;
integer frames_complete = 0;
integer frames_incomplete = 0;

task check_and_collect;
    integer i;
    integer sx, sy, base;
    integer mism_count, probe, row_bad;
    reg [31:0] crc, hcrc, seq;
    reg [15:0] idx, cnt, w, h, plen;
    reg [15:0] e, pe;
    reg mismatch;
    begin
        if (!(rx_buf[0] == "E" && rx_buf[1] == "V" && rx_buf[2] == "S" && rx_buf[3] == "1"))
            fail("EVS1 magic wrong");
        if (rx_buf[4] !== 8'd1) fail("version != 1");
        if (rx_buf[5] !== 8'd0) fail("message type != preview");
        if ({rx_buf[6], rx_buf[7]} !== 16'd32) fail("header length != 32");
        if (rx_buf[24] !== 8'd1) fail("pixel format != RGB565");

        seq  = {rx_buf[12], rx_buf[13], rx_buf[14], rx_buf[15]};
        idx  = {rx_buf[16], rx_buf[17]};
        cnt  = {rx_buf[18], rx_buf[19]};
        w    = {rx_buf[20], rx_buf[21]};
        h    = {rx_buf[22], rx_buf[23]};
        plen = {rx_buf[26], rx_buf[27]};
        hcrc = {rx_buf[28], rx_buf[29], rx_buf[30], rx_buf[31]};

        if (w !== OUT_W[15:0]) fail("header width wrong");
        if (h !== OUT_H[15:0]) fail("header height wrong");
        if (cnt !== EXP_PACKETS[15:0]) fail("header packet_count wrong");
        if (plen !== rx_len - 16'd32) fail("payload_count disagrees with udp_len");
        if (idx >= cnt) fail("packet_index >= packet_count");

        crc = 32'hFFFF_FFFF;
        for (i = 0; i < plen; i = i + 1)
            crc = crc32_tb(crc, rx_buf[32 + i]);
        crc = ~crc;
        if (crc !== hcrc) fail("payload CRC32 mismatch");

        // Frame reassembly.  A new sequence number abandons any partial
        // frame, which is what the abort case must look like from here.
        if (!frame_tracking || seq !== cur_seq) begin
            if (frame_tracking && next_idx != 0) begin
                frames_incomplete = frames_incomplete + 1;
                $display("[%0t]   frame seq=%0d abandoned after %0d/%0d packets",
                         $time, cur_seq, next_idx, EXP_PACKETS);
                $fflush;
            end
            cur_seq = seq;
            frame_tracking = 1'b1;
            next_idx = 0;
            fbytes = 0;
        end

        if (idx !== next_idx[15:0]) begin
            fail("packet_index not contiguous within a frame");
            next_idx = 0;
            fbytes = 0;
            frame_tracking = 1'b0;
        end else begin
            if (fbytes + plen > FRAME_BYTES) begin
                fail("frame payload overruns the expected frame size");
                frame_tracking = 1'b0;
            end else begin
                for (i = 0; i < plen; i = i + 1)
                    fbuf[fbytes + i] = rx_buf[32 + i];
                fbytes = fbytes + plen;
                next_idx = next_idx + 1;
                if (next_idx == EXP_PACKETS) begin
                    if (fbytes != FRAME_BYTES) begin
                        fail("complete frame has the wrong byte count");
                    end else begin
                        // Full pixel-accurate compare.  This is what catches a
                        // ping-pong bank mix-up: header and CRC would both be
                        // self-consistent while the picture is interleaved.
                        mismatch = 1'b0;
                        mism_count = 0;
                        for (sy = 0; sy < OUT_H; sy = sy + 1)
                            for (sx = 0; sx < OUT_W; sx = sx + 1) begin
                                e = expect_rgb565(sx, sy);
                                base = 2 * (sy * OUT_W + sx);
                                if (fbuf[base] !== e[15:8] || fbuf[base + 1] !== e[7:0]) begin
                                    if (mism_count < 12)
                                        $display("            mismatch #%0d at sx=%0d sy=%0d: got %02x%02x want %02x%02x",
                                                 mism_count, sx, sy,
                                                 fbuf[base], fbuf[base + 1], e[15:8], e[7:0]);
                                    if (!mismatch) begin
                                        // First mismatch only.  Its position
                                        // separates the two candidate causes:
                                        // a decimation drift shows up as the
                                        // received value matching a NEARBY
                                        // source pixel, while a bad expected-
                                        // pattern model is wrong from (0,0).
                                        $display("[%0t]   first mismatch at sx=%0d sy=%0d (byte %0d): got %02x%02x want %02x%02x",
                                                 $time, sx, sy, base,
                                                 fbuf[base], fbuf[base + 1], e[15:8], e[7:0]);
                                        // Show which source column the
                                        // received high byte would match.
                                        for (probe = 0; probe < 8; probe = probe + 1) begin
                                            pe = expect_rgb565(sx + probe - 4, sy);
                                            if (fbuf[base] === pe[15:8] && fbuf[base + 1] === pe[7:0])
                                                $display("            received value matches source sx=%0d (offset %0d)",
                                                         sx + probe - 4, probe - 4);
                                        end
                                        $fflush;
                                    end
                                    mismatch = 1'b1;
                                    mism_count = mism_count + 1;
                                end
                            end
                        if (mismatch) begin
                            $display("[%0t]   %0d of %0d pixels mismatched",
                                     $time, mism_count, OUT_W * OUT_H);
                            // Row/column histogram of the failures: a
                            // decimation fault hits whole rows, a packet
                            // boundary fault hits a periodic column stride.
                            for (sy = 0; sy < OUT_H; sy = sy + 1) begin
                                row_bad = 0;
                                for (sx = 0; sx < OUT_W; sx = sx + 1) begin
                                    e = expect_rgb565(sx, sy);
                                    base = 2 * (sy * OUT_W + sx);
                                    if (fbuf[base] !== e[15:8] || fbuf[base + 1] !== e[7:0])
                                        row_bad = row_bad + 1;
                                end
                                if (row_bad != 0)
                                    $display("            row sy=%0d: %0d bad", sy, row_bad);
                            end
                            $fflush;
                            fail("frame pixel content does not match the source pattern");
                            // No point burning minutes of real-geometry
                            // simulation on further frames: the first one
                            // carries the whole diagnosis.
                            if ($test$plusargs("stop_on_mismatch")) begin
                                $display("   stage attribution: sampler stream errors=%0d, bridge handover errors=%0d",
                                         samp_errors, deliv_errors);
                                $display("\n=== TB_FRAME_ABORT FAIL (content) ===\n");
                                $finish;
                            end
                        end
                        else begin
                            frames_complete = frames_complete + 1;
                            $display("[%0t]   frame seq=%0d COMPLETE and pixel-exact (%0d packets)",
                                     $time, seq, EXP_PACKETS);
                            $fflush;
                        end
                    end
                    frame_tracking = 1'b0;
                    next_idx = 0;
                    fbytes = 0;
                end
            end
        end
    end
endtask

always @(posedge eclk or posedge erst) begin
    if (erst) begin
        stk_state <= K_IDLE;
        udp_busy <= 1'b0;
        stk_delay <= 16'd0;
        rx_cnt <= 16'd0;
        rx_len <= 16'd0;
    end else begin
        case (stk_state)
            K_IDLE: begin
                if (udp_valid) fail("udp_valid asserted while the stack is idle");
                if (udp_req && !stall_stack) begin
                    stk_delay <= 16'd3;
                    stk_state <= K_ACK;
                end
            end
            K_ACK: begin
                if (udp_valid) fail("udp_valid asserted before the stack acknowledged");
                if (stk_delay != 16'd0) begin
                    stk_delay <= stk_delay - 16'd1;
                end else begin
                    udp_busy <= 1'b1;
                    rx_len <= udp_len;
                    rx_cnt <= 16'd0;
                    stk_state <= K_DATA;
                end
            end
            K_DATA: begin
                if (udp_valid) begin
                    rx_buf[rx_cnt] <= udp_data;
                    rx_cnt <= rx_cnt + 16'd1;
                    if (rx_cnt + 16'd1 == rx_len) begin
                        stk_delay <= WIRE_OVERHEAD[15:0];
                        stk_state <= K_WIRE;
                    end
                end
            end
            K_WIRE: begin
                if (udp_valid) fail("udp_valid continued past udp_len (datagram overrun)");
                if (stk_delay != 16'd0) begin
                    stk_delay <= stk_delay - 16'd1;
                end else begin
                    udp_busy <= 1'b0;
                    datagrams_done = datagrams_done + 1;
                    check_and_collect;
                    stk_state <= K_IDLE;
                end
            end
        endcase
    end
end

//--------------------------------------------------------------------------
// test sequence
//--------------------------------------------------------------------------
integer frames_at_release;
integer aborts_at_release;

initial begin
    if ($test$plusargs("dump")) begin
        $dumpfile("tb_frame_abort.vcd");
        $dumpvars(0, tb_frame_abort);
    end

    vrst_n = 1'b0;
    erst = 1'b1;
    repeat (20) @(posedge eclk);
    erst = 1'b0;
    repeat (20) @(posedge vclk);
    vrst_n = 1'b1;

    $display("[%0t] geometry %0dx%0d, %0d frame bytes, %0d packets/frame",
             $time, OUT_W, OUT_H, FRAME_BYTES, EXP_PACKETS);
    $fflush;
    say("--- phase 1: normal start, expect datagrams to flow");
    wait (datagrams_done >= 2);
    if (errors != 0) begin
        $display("phase 1 already failed, stopping");
        $finish;
    end

    say("--- phase 2: stalling the UDP stack to force a FIFO high-water cut");
    stall_stack = 1'b1;
    // The sampler raising abort_pending IS the fault being reproduced: the
    // frame has been cut and its final byte will never be produced.  Before
    // this fix, that was the end of the story and everything downstream
    // waited forever.
    wait (dut.u_sampler.abort_pending === 1'b1);
    say("  sampler cut the frame at the high-water mark (abort queued)");
    if (fifo_overflow !== 1'b1) fail("overflow flag not raised when the frame was cut");

    say("--- phase 3: releasing the stack, expect an in-band abort marker");
    frames_at_release = frames_complete;
    stall_stack = 1'b0;
    wait (dut.abort_count != 4'd0);
    aborts_at_release = dut.abort_count;
    $display("[%0t]   bridge consumed the abort marker (abort_count=%0d)",
             $time, dut.abort_count);
    $fflush;
    if (dut.abort_seen !== 1'b1) fail("abort_seen not set after an abort");

    say("--- phase 4: expect clean resynchronisation on the next frame");
    // Pixel-exact frames after the abort prove the next frame re-synchronised
    // on a fresh start marker, and the armed high-water monitor shows how
    // much read-side margin there actually is in steady state.
    peak_arm = 1'b1;
    stream_check = 1'b1;
    wait (frames_complete >= frames_at_release + FRAMES_AFTER_ABORT);

    if (dut.abort_count != aborts_at_release)
        fail("further aborts occurred after recovery: read path is too slow");
    if (packetizer_error === 1'b1)
        fail("packetizer reported a frame error");

    $display("[%0t] --- summary", $time);
    $display("  datagrams sent      : %0d", datagrams_done);
    $display("  frames complete     : %0d", frames_complete);
    $display("  frames abandoned    : %0d", frames_incomplete);
    $display("  aborts (DUT counter): %0d", dut.abort_count);
    $display("  done   (DUT counter): %0d", dut.done_count);
    $display("  frame_sequence      : %0d", dut.frame_sequence);
    $display("  FIFO peak in steady state: %0d of %0d words (%0d%% of high-water)",
             fifo_peak, AFULL_WORDS, (fifo_peak * 100) / AFULL_WORDS);

    // A steady-state peak anywhere near the high-water mark means the read
    // path is only just keeping up and any extra arbitration delay on the
    // board would cut frames again.
    if (fifo_peak >= AFULL_WORDS)
        fail("FIFO reached the high-water mark in steady state");
    else if (fifo_peak > (AFULL_WORDS / 2))
        fail("FIFO peak above 50% of the high-water mark: too little margin");

    if (frames_incomplete < 1)
        fail("expected at least one abandoned frame from the forced abort");
    // One sequence number went to the frame that was cut, then one to each
    // frame demanded after the abort.  Deriving the bound from the parameter
    // instead of hard-coding the fast geometry's 4 keeps the check strict in
    // every mode: a literal 3 is unsatisfiable whenever FRAMES_AFTER_ABORT is
    // 1, which is exactly what the real geometry runs with.
    if (dut.frame_sequence < 1 + FRAMES_AFTER_ABORT)
        fail("frame_sequence did not advance past the aborted frame");

    if (errors == 0)
        $display("\n=== TB_FRAME_ABORT PASS ===\n");
    else
        $display("\n=== TB_FRAME_ABORT FAIL (%0d errors) ===\n", errors);
    $finish;
end

// Deadlock detector.  The original defect presented exactly as "everything
// stops and never restarts", so a timeout here is a real result, not just
// bench housekeeping.
initial begin
    #TIMEOUT_NS;
    $display("\n=== TB_FRAME_ABORT FAIL: TIMEOUT ===");
    $display("  datagrams=%0d frames_complete=%0d abort_count=%0d frame_sequence=%0d",
             datagrams_done, frames_complete, dut.abort_count, dut.frame_sequence);
    $display("  bridge_state=%0d packetizer_ready=%0b fifo_empty=%0b fifo_afull=%0b",
             debug_status[10:8], debug_status[11], debug_status[2], debug_status[3]);
    $display("  sampler abort_pending=%0b capture_frame=%0b",
             dut.u_sampler.abort_pending, dut.u_sampler.capture_frame);
    $finish;
end

endmodule
