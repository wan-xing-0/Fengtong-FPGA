`timescale 1ns/1ps

module tb_evs_video_tx_core;
reg video_clk = 0;
reg eth_clk = 0;
reg video_rst_n = 0;
reg eth_reset = 1;
reg vs = 0;
reg de = 0;
reg [23:0] rgb = 0;
reg udp_busy = 0;
wire udp_req, udp_valid;
wire [7:0] udp_data;
wire [15:0] udp_len;
wire dropped, overflow, packet_error;
wire [31:0] debug_status;
wire [7:0] debug_counts;
integer x, y;
integer req_count = 0;
integer valid_count = 0;

always #3.367 video_clk = ~video_clk;
always #4 eth_clk = ~eth_clk;

evs_video_tx_core #(.OUT_WIDTH(4), .OUT_HEIGHT(2)) dut (
    .I_video_clk(video_clk), .I_video_rst_n(video_rst_n),
    .I_video_vs(vs), .I_video_de(de), .I_video_rgb(rgb),
    .I_qc_trig(1'b0), .I_timer_en(1'b0), .I_alarm_level(2'd0), .I_present(1'b0),
    .I_sec_hold(1'b0), .I_staff_pass(1'b0),
    .I_eth_clk(eth_clk), .I_eth_reset(eth_reset), .I_udp_busy(udp_busy),
    .O_udp_req(udp_req), .O_udp_valid(udp_valid), .O_udp_data(udp_data),
    .O_udp_len(udp_len), .O_video_frame_dropped(dropped),
    .O_fifo_overflow(overflow), .O_packetizer_error(packet_error),
    .O_debug_status(debug_status), .O_debug_counts(debug_counts)
);

always @(posedge eth_clk) begin
    udp_busy <= udp_req;
    if (udp_req && !udp_busy) req_count <= req_count + 1;
    if (udp_valid) valid_count <= valid_count + 1;
end

task send_frame;
begin
    @(posedge video_clk); vs <= 1;
    for (y = 0; y < 4; y = y + 1) begin
        for (x = 0; x < 8; x = x + 1) begin
            @(posedge video_clk); de <= 1; rgb <= {x[7:0], y[7:0], 8'h55};
        end
        @(posedge video_clk); de <= 0;
    end
    @(posedge video_clk); vs <= 0;
    repeat (8) @(posedge video_clk);
end
endtask

initial begin
    repeat (8) @(posedge eth_clk);
    eth_reset <= 0;
    video_rst_n <= 1;
    repeat (20) @(posedge video_clk);
    send_frame;
    repeat (1000) @(posedge eth_clk);
    $display("RESULT req=%0d valid=%0d len=%0d dropped=%0b overflow=%0b error=%0b state=%0d fifo_empty=%0b",
             req_count, valid_count, udp_len, dropped, overflow, packet_error,
             dut.bridge_state, dut.fifo_empty);
    if (req_count == 0) $fatal(1, "No UDP request generated");
    $finish;
end
endmodule
