`timescale 1ns/1ps

// Byte-exact unit bench for evs_udp_packetizer.
//
// PAYLOAD_BYTES=4 over a 10-byte frame gives three packets (4/4/2), so every
// header field and the payload ordering can be checked by absolute byte
// offset -- a granularity tb_frame_abort.v does not attempt.  With the
// ping-pong banks this also pins down the bank alternation: packets 0 and 2
// come out of bank 0 and packet 1 out of bank 1, so a bank/metadata mismatch
// shows up as a wrong index or a wrong payload byte right here.
//
// TEST 2 is the abort contract.  A bank that is already complete is a
// datagram whose length has been promised to uiudp_stack, so an abort must
// let it finish; only the partially filled bank may be dropped.  Truncating
// a datagram would desynchronize the stack's byte counter, which is worse
// than the lock-up the abort path exists to prevent.
module tb_evs_udp_packetizer;

localparam integer WIRE_OVERHEAD = 6;

reg clk = 1'b0;
reg reset = 1'b1;
reg frame_start = 1'b0;
reg frame_abort = 1'b0;
reg [31:0] frame_sequence = 32'h0000_002A;
reg [7:0] frame_flags = 8'hB6;     // 10-09: header byte 25, latched per frame
reg [15:0] width = 16'd5;
reg [15:0] height = 16'd1;
reg [31:0] frame_bytes = 32'd10;
reg src_valid = 1'b0;
reg [7:0] src_byte = 8'd0;
reg src_last = 1'b0;
wire src_ready;
wire ready_for_frame;
reg udp_busy = 1'b0;
wire udp_req, udp_valid;
wire [7:0] udp_data;
wire [15:0] udp_len;
wire frame_done, frame_error;
reg [7:0] captured [0:511];
integer captured_count = 0;
integer datagrams = 0;
integer i;
integer errors = 0;
integer errors_mark = 0;

// Without this the per-test "ok" line prints even when a check above it just
// failed, which is actively misleading when skimming a log.
task report;
    input [511:0] what;
    begin
        if (errors == errors_mark)
            $display("%0s ok", what);
        else
            $display("%0s FAILED (%0d errors)", what, errors - errors_mark);
        errors_mark = errors;
    end
endtask

always #4 clk = ~clk;

evs_udp_packetizer #(.PAYLOAD_BYTES(4), .SESSION_ID(32'h1234_5678)) dut (
    .I_clk(clk), .I_reset(reset), .I_frame_start(frame_start),
    .I_frame_abort(frame_abort),
    .I_frame_sequence(frame_sequence), .I_frame_flags(frame_flags),
    .I_width(width), .I_height(height),
    .I_frame_bytes(frame_bytes), .I_src_valid(src_valid), .I_src_byte(src_byte),
    .I_src_last(src_last), .O_src_ready(src_ready), .I_udp_busy(udp_busy),
    .O_udp_req(udp_req), .O_udp_valid(udp_valid), .O_udp_data(udp_data),
    .O_udp_len(udp_len), .O_ready_for_frame(ready_for_frame),
    .O_frame_done(frame_done), .O_frame_error(frame_error)
);

// Same stack contract as tb_frame_abort.v: a request is only latched while
// busy is low, busy is the acknowledgement, exactly udp_len bytes are taken,
// and busy stays high for the remaining wire time.
localparam [1:0] K_IDLE = 2'd0;
localparam [1:0] K_DATA = 2'd1;
localparam [1:0] K_WIRE = 2'd2;
reg [1:0] stk = K_IDLE;
reg [15:0] rx_n = 16'd0;
reg [15:0] rx_len = 16'd0;
reg [15:0] wire_cnt = 16'd0;

always @(posedge clk) begin
    if (reset) begin
        stk <= K_IDLE;
        udp_busy <= 1'b0;
        rx_n <= 16'd0;
    end else begin
        case (stk)
            K_IDLE: if (udp_req) begin
                udp_busy <= 1'b1;
                rx_len <= udp_len;
                rx_n <= 16'd0;
                stk <= K_DATA;
            end
            K_DATA: if (udp_valid) begin
                captured[captured_count] = udp_data;
                captured_count = captured_count + 1;
                rx_n <= rx_n + 16'd1;
                if (rx_n + 16'd1 == rx_len) begin
                    wire_cnt <= WIRE_OVERHEAD[15:0];
                    stk <= K_WIRE;
                end
            end
            K_WIRE: begin
                if (udp_valid) begin
                    $display("FAIL: udp_valid continued past udp_len");
                    errors = errors + 1;
                end
                if (wire_cnt != 16'd0) begin
                    wire_cnt <= wire_cnt - 16'd1;
                end else begin
                    udp_busy <= 1'b0;
                    datagrams = datagrams + 1;
                    stk <= K_IDLE;
                end
            end
        endcase
    end
end

task send_byte;
    input [7:0] value;
    input is_last;
    begin
        wait (src_ready === 1'b1);
        @(negedge clk);
        src_byte = value;
        src_last = is_last;
        src_valid = 1'b1;
        @(posedge clk);
        @(negedge clk);
        src_valid = 1'b0;
        src_last = 1'b0;
    end
endtask

// O_frame_done fires as soon as the last payload byte has been handed over,
// while the stack model is still counting out that datagram's wire time.
// Anything that reads the datagram counter has to wait for the model to come
// back to idle first, or the last datagram of one test lands in the next
// test's tally.
task drain_stack;
    begin
        wait (stk === K_IDLE);
        repeat (2) @(posedge clk);
    end
endtask

task pulse_start;
    begin
        @(negedge clk); frame_start = 1'b1;
        @(posedge clk);
        @(negedge clk); frame_start = 1'b0;
    end
endtask

task expect_byte;
    input integer index;
    input [7:0] expected;
    begin
        if (captured[index] !== expected) begin
            $display("FAIL byte[%0d]: got %02x expected %02x", index, captured[index], expected);
            errors = errors + 1;
        end
    end
endtask

task expect_eq;
    input integer got;
    input integer want;
    input [511:0] what;
    begin
        if (got !== want) begin
            $display("FAIL %0s: got %0d expected %0d", what, got, want);
            errors = errors + 1;
        end
    end
endtask

initial begin
    repeat (3) @(posedge clk);
    reset = 1'b0;

    // ---- TEST 1: a complete 10-byte frame, checked byte by byte ---------
    pulse_start;
    // Changing the input after the start must not reach this frame's
    // headers: the flags are latched with the rest of the frame metadata.
    @(negedge clk); frame_flags = 8'h5A;
    for (i = 0; i < 10; i = i + 1)
        send_byte(i[7:0], i == 9);

    wait (frame_done === 1'b1);
    drain_stack;
    if (frame_error) begin
        $display("FAIL packetizer raised frame_error");
        errors = errors + 1;
    end
    expect_eq(captured_count, 106, "captured bytes");
    expect_eq(datagrams, 3, "datagram count");

    // Three packets: headers at 0, 36 and 72.  Validates framing, packet
    // indices, total packet count, lengths and payload order across banks.
    expect_byte(0, "E");  expect_byte(1, "V");  expect_byte(2, "S");  expect_byte(3, "1");
    expect_byte(16, 8'd0); expect_byte(17, 8'd0); expect_byte(18, 8'd0); expect_byte(19, 8'd3);
    expect_byte(32, 8'd0); expect_byte(33, 8'd1); expect_byte(34, 8'd2); expect_byte(35, 8'd3);
    expect_byte(36, "E"); expect_byte(52, 8'd0); expect_byte(53, 8'd1);
    expect_byte(68, 8'd4); expect_byte(69, 8'd5); expect_byte(70, 8'd6); expect_byte(71, 8'd7);
    expect_byte(72, "E"); expect_byte(88, 8'd0); expect_byte(89, 8'd2);
    expect_byte(98, 8'd0); expect_byte(99, 8'd2); // final payload length
    expect_byte(104, 8'd8); expect_byte(105, 8'd9);
    expect_byte(25, 8'hB6); expect_byte(61, 8'hB6); expect_byte(97, 8'hB6); // flags, every packet
    report("TEST 1 (3 packets / 10 bytes / EVS1 headers by offset)");

    // ---- TEST 2: abort mid-frame ---------------------------------------
    // Five bytes: the first four complete bank 0, the fifth starts bank 1.
    // The abort must still let bank 0 go out whole and must drop bank 1.
    frame_sequence = 32'h0000_002B;
    captured_count = 0;
    datagrams = 0;
    pulse_start;
    for (i = 0; i < 5; i = i + 1)
        send_byte(8'hC0 + i[7:0], 1'b0);

    @(negedge clk); frame_abort = 1'b1;
    @(posedge clk);
    @(negedge clk); frame_abort = 1'b0;

    wait (ready_for_frame === 1'b1);
    drain_stack;
    expect_eq(datagrams, 1, "datagrams after abort");
    expect_eq(captured_count, 36, "bytes after abort");
    expect_byte(0, "E");
    expect_byte(16, 8'd0); expect_byte(17, 8'd0);       // packet_index 0
    expect_byte(26, 8'd0); expect_byte(27, 8'd4);       // payload length 4
    expect_byte(32, 8'hC0); expect_byte(35, 8'hC3);     // bank 0 payload intact
    if (frame_error === 1'b1) begin
        $display("FAIL abort raised frame_error (it is not an error path)");
        errors = errors + 1;
    end
    report("TEST 2 (abort keeps the complete bank, drops the partial one)");

    // ---- TEST 3: the next frame must be clean --------------------------
    frame_sequence = 32'h0000_002C;
    frame_flags = 8'h00;
    captured_count = 0;
    datagrams = 0;
    pulse_start;
    for (i = 0; i < 10; i = i + 1)
        send_byte(8'h10 + i[7:0], i == 9);

    wait (frame_done === 1'b1);
    drain_stack;
    expect_eq(datagrams, 3, "datagrams in the frame after an abort");
    expect_eq(captured_count, 106, "bytes in the frame after an abort");
    expect_byte(16, 8'd0); expect_byte(17, 8'd0);       // index restarts at 0
    expect_byte(32, 8'h10);
    expect_byte(52, 8'd0); expect_byte(53, 8'd1);
    expect_byte(68, 8'h14);
    expect_byte(88, 8'd0); expect_byte(89, 8'd2);
    expect_byte(104, 8'h18); expect_byte(105, 8'h19);
    expect_byte(12, 8'd0); expect_byte(13, 8'd0);
    expect_byte(14, 8'd0); expect_byte(15, 8'h2C);      // sequence tracked
    expect_byte(25, 8'h00); expect_byte(97, 8'h00);     // flags tracked too
    if (frame_error === 1'b1) begin
        $display("FAIL frame_error on the frame after an abort");
        errors = errors + 1;
    end
    report("TEST 3 (packet index and sequence resynchronise after the abort)");

    if (errors == 0)
        $display("\n=== TB_EVS_UDP_PACKETIZER PASS ===\n");
    else
        $display("\n=== TB_EVS_UDP_PACKETIZER FAIL (%0d errors) ===\n", errors);
    $finish;
end

initial begin
    #500_000;
    $display("\n=== TB_EVS_UDP_PACKETIZER FAIL: TIMEOUT ===");
    $display("  datagrams=%0d captured=%0d ready_for_frame=%0b",
             datagrams, captured_count, ready_for_frame);
    $finish;
end

endmodule
