`timescale 1ns/1ps

// Tagged byte FIFO between the pclkx1 observer and the 125 MHz packetizer.
// The underlying generated FIFO uses asynchronous reset with synchronous
// release in each clock domain.  It is kept as a separate wrapper so replacing
// the vendor IP later does not change video or packetizer interfaces.
module evs_async_frame_fifo #(
    parameter integer ADDR_WIDTH = 13,
    parameter integer ALMOST_FULL_WORDS = 8000
) (
    input  wire       I_reset,
    input  wire       I_wr_clk,
    input  wire       I_wr_en,
    input  wire [9:0] I_wr_word,
    output wire       O_almost_full,
    output wire       O_full,
    input  wire       I_rd_clk,
    input  wire       I_rd_en,
    output wire [9:0] O_rd_word,
    output wire       O_rd_valid,
    output wire       O_empty
);

wire unused_aempty;
wire [ADDR_WIDTH-1:0] unused_wrusedw;
wire [ADDR_WIDTH-1:0] unused_rdusedw;

udp_pkg_buf #(
    .DATA_WIDTH_W(10),
    .DATA_WIDTH_R(10),
    .ADDR_WIDTH_W(ADDR_WIDTH),
    .ADDR_WIDTH_R(ADDR_WIDTH),
    .AL_FULL_NUM(ALMOST_FULL_WORDS),
    .AL_EMPTY_NUM(2),
    // The bridge issues one read and waits for O_rd_valid before consuming
    // the returned word.  Use the registered, non-show-ahead interface so
    // valid is a read-response pulse; show-ahead makes valid a level while
    // non-empty and can skip the first (frame-start) word as the RAM output
    // catches up with the empty-flag CDC.
    .SHOW_AHEAD_EN(1'b0),
    .OUTREG_EN("OUTREG")
) u_fifo (
    .rst(I_reset),
    .clkw(I_wr_clk),
    .clkr(I_rd_clk),
    .we(I_wr_en),
    .di(I_wr_word),
    .re(I_rd_en),
    .dout(O_rd_word),
    .valid(O_rd_valid),
    .full_flag(O_full),
    .empty_flag(O_empty),
    .afull(O_almost_full),
    .aempty(unused_aempty),
    .wrusedw(unused_wrusedw),
    .rdusedw(unused_rdusedw)
);

endmodule
