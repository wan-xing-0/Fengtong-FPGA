`timescale 1ns/1ps

// EVS1 application packetizer.  It is deliberately independent from the
// video clock domain and from uiudp_stack internals.  A preceding async FIFO
// supplies RGB565 bytes; this module accepts one complete frame at a time and
// emits one UDP datagram per EVS1 packet.
//
// I_frame_start is asserted for one cycle before the first source byte.  The
// caller supplies fixed frame metadata, allowing total-packet-count to appear
// in every packet header before payload transmission begins.
//
// TWO PAYLOAD BANKS (why filling and sending are separate state machines)
//
// With a single payload buffer O_src_ready is low for the whole request +
// header + payload transmission, roughly 1400 clocks per 1368 bytes.  That
// caps the sustained source rate at ~1368/2768 of one byte per clock, about
// 62 MB/s, and the sampler needs ~65 MB/s averaged over two video lines --
// permanently short, so the CDC FIFO creeps up to its high-water mark and the
// frame is cut every time no matter how well the abort path recovers.  Two
// banks let one fill while the other is on the wire, which lifts the
// sustained rate to the send-side limit of ~118 MB/s.
//
// FRAME ABORT
//
// I_frame_abort means the source stream was cut and the remaining bytes of
// the current frame will never arrive.  It stops filling at once, but it
// deliberately does NOT touch banks that are already complete: those are
// whole datagrams whose length was already promised to uiudp_stack, and
// truncating one mid-transmission would desynchronize the stack's byte
// counter.  O_ready_for_frame simply stays low until the send side has
// drained them, so the deferral needs no special state.
module evs_udp_packetizer #(
    parameter [31:0] SESSION_ID    = 32'h0000_0001,
    parameter integer PAYLOAD_BYTES = 1368
) (
    input  wire        I_clk,
    input  wire        I_reset,
    input  wire        I_frame_start,
    input  wire        I_frame_abort,
    input  wire [31:0] I_frame_sequence,
    input  wire [7:0]  I_frame_flags,     // EVS1 header byte 25 (evs_burst_ctrl.v)
    input  wire [15:0] I_width,
    input  wire [15:0] I_height,
    input  wire [31:0] I_frame_bytes,
    input  wire        I_src_valid,
    input  wire [7:0]  I_src_byte,
    input  wire        I_src_last,
    output wire        O_src_ready,
    input  wire        I_udp_busy,
    output reg         O_udp_req,
    output reg         O_udp_valid,
    output reg  [7:0]  O_udp_data,
    output reg  [15:0] O_udp_len,
    output wire        O_ready_for_frame,
    output reg         O_frame_done,
    output reg         O_frame_error
);

// Banks are addressed as {bank, index} rather than bank*PAYLOAD_BYTES so the
// payload address stays a plain concatenation.  The image project's worst
// setup path already runs through a BRAM address, so no adder or multiplier
// is put on this one.  Requires PAYLOAD_BYTES <= 2048.
localparam integer BANK_ADDR_BITS = 11;

localparam [1:0] F_IDLE = 2'd0;
localparam [1:0] F_FILL = 2'd1;

localparam [2:0] S_IDLE    = 3'd0;
localparam [2:0] S_REQUEST = 3'd1;
localparam [2:0] S_HEADER  = 3'd2;
localparam [2:0] S_PAYLOAD = 3'd3;
localparam [2:0] S_FINISH  = 3'd4;

reg [7:0] payload_mem [0:(2<<BANK_ADDR_BITS)-1];

reg [1:0]  fill_state;
reg        fill_bank;
reg [15:0] fill_count;
reg [31:0] crc_reg;

reg        bank_ready [0:1];
reg [15:0] bank_len   [0:1];
reg [31:0] bank_crc   [0:1];
reg [15:0] bank_index [0:1];
reg        bank_last  [0:1];

reg [2:0]  send_state;
reg        send_bank;
reg [5:0]  header_index;
reg [15:0] payload_read_index;
reg [15:0] hdr_len;
reg [15:0] hdr_index;
reg [31:0] hdr_crc;
reg        hdr_last;

reg [15:0] packet_count;
reg [15:0] next_packet_index;
reg [31:0] frame_sequence;
reg [7:0]  frame_flags;
reg [15:0] frame_width;
reg [15:0] frame_height;
reg [31:0] expected_frame_bytes;
reg [31:0] accepted_frame_bytes;

function [31:0] crc32_byte;
    input [31:0] crc_in;
    input [7:0] data;
    integer k;
    reg [31:0] c;
    begin
        c = crc_in ^ data;
        for (k = 0; k < 8; k = k + 1)
            c = c[0] ? ((c >> 1) ^ 32'hEDB88320) : (c >> 1);
        crc32_byte = c;
    end
endfunction

function [7:0] header_byte;
    input [5:0] index;
    begin
        case (index)
            6'd0: header_byte = "E";  6'd1: header_byte = "V";
            6'd2: header_byte = "S";  6'd3: header_byte = "1";
            6'd4: header_byte = 8'd1;  6'd5: header_byte = 8'd0; // preview
            6'd6: header_byte = 8'd0;  6'd7: header_byte = 8'd32;
            6'd8: header_byte = SESSION_ID[31:24];
            6'd9: header_byte = SESSION_ID[23:16];
            6'd10: header_byte = SESSION_ID[15:8];
            6'd11: header_byte = SESSION_ID[7:0];
            6'd12: header_byte = frame_sequence[31:24];
            6'd13: header_byte = frame_sequence[23:16];
            6'd14: header_byte = frame_sequence[15:8];
            6'd15: header_byte = frame_sequence[7:0];
            6'd16: header_byte = hdr_index[15:8];
            6'd17: header_byte = hdr_index[7:0];
            6'd18: header_byte = packet_count[15:8];
            6'd19: header_byte = packet_count[7:0];
            6'd20: header_byte = frame_width[15:8];
            6'd21: header_byte = frame_width[7:0];
            6'd22: header_byte = frame_height[15:8];
            6'd23: header_byte = frame_height[7:0];
            6'd24: header_byte = 8'd1; // RGB565
            6'd25: header_byte = frame_flags;
            6'd26: header_byte = hdr_len[15:8];
            6'd27: header_byte = hdr_len[7:0];
            6'd28: header_byte = hdr_crc[31:24];
            6'd29: header_byte = hdr_crc[23:16];
            6'd30: header_byte = hdr_crc[15:8];
            default: header_byte = hdr_crc[7:0];
        endcase
    end
endfunction

wire fill_bank_busy = bank_ready[fill_bank];
wire [31:0] crc_next = crc32_byte(crc_reg, I_src_byte);

assign O_src_ready = (fill_state == F_FILL) && !fill_bank_busy;

// A new frame may only be admitted once nothing of the previous one is left
// anywhere in the module.  This is also what defers an abort until the
// already-complete datagrams of the aborted frame have gone out intact.
assign O_ready_for_frame = (fill_state == F_IDLE) && (send_state == S_IDLE)
                        && !bank_ready[0] && !bank_ready[1];

// Both state machines live in one block because they share bank_ready: the
// fill side sets it, the send side clears it.  They never target the same
// index in the same cycle, because O_src_ready keeps the fill side off any
// bank that is still marked ready.
always @(posedge I_clk or posedge I_reset) begin
    if (I_reset) begin
        fill_state <= F_IDLE;
        fill_bank <= 1'b0;
        fill_count <= 16'd0;
        crc_reg <= 32'hFFFF_FFFF;
        bank_ready[0] <= 1'b0;
        bank_ready[1] <= 1'b0;
        send_state <= S_IDLE;
        send_bank <= 1'b0;
        header_index <= 6'd0;
        payload_read_index <= 16'd0;
        hdr_len <= 16'd0;
        hdr_index <= 16'd0;
        hdr_crc <= 32'd0;
        hdr_last <= 1'b0;
        packet_count <= 16'd0;
        next_packet_index <= 16'd0;
        accepted_frame_bytes <= 32'd0;
        expected_frame_bytes <= 32'd0;
        O_udp_req <= 1'b0;
        O_udp_valid <= 1'b0;
        O_udp_data <= 8'd0;
        O_udp_len <= 16'd0;
        O_frame_done <= 1'b0;
        O_frame_error <= 1'b0;
    end else begin
        O_udp_req <= 1'b0;
        O_udp_valid <= 1'b0;
        O_frame_done <= 1'b0;

        // ---- fill side -------------------------------------------------
        if (I_frame_abort) begin
            fill_state <= F_IDLE;
            fill_count <= 16'd0;
            crc_reg <= 32'hFFFF_FFFF;
        end else begin
            case (fill_state)
                F_IDLE: if (I_frame_start) begin
                    frame_sequence <= I_frame_sequence;
                    frame_flags <= I_frame_flags;
                    frame_width <= I_width;
                    frame_height <= I_height;
                    expected_frame_bytes <= I_frame_bytes;
                    packet_count <= (I_frame_bytes + PAYLOAD_BYTES - 1) / PAYLOAD_BYTES;
                    next_packet_index <= 16'd0;
                    accepted_frame_bytes <= 32'd0;
                    fill_count <= 16'd0;
                    fill_bank <= 1'b0;
                    send_bank <= 1'b0;
                    crc_reg <= 32'hFFFF_FFFF;
                    O_frame_error <= 1'b0;
                    if (I_frame_bytes != 0)
                        fill_state <= F_FILL;
                    else
                        O_frame_error <= 1'b1;
                end
                default: if (I_src_valid && !fill_bank_busy) begin
                    payload_mem[{fill_bank, fill_count[BANK_ADDR_BITS-1:0]}] <= I_src_byte;
                    accepted_frame_bytes <= accepted_frame_bytes + 1'b1;
                    if ((fill_count + 1'b1 == PAYLOAD_BYTES[15:0]) || I_src_last) begin
                        bank_len[fill_bank] <= fill_count + 1'b1;
                        bank_crc[fill_bank] <= ~crc_next;
                        bank_index[fill_bank] <= next_packet_index;
                        bank_last[fill_bank] <= I_src_last;
                        bank_ready[fill_bank] <= 1'b1;
                        next_packet_index <= next_packet_index + 1'b1;
                        fill_bank <= ~fill_bank;
                        fill_count <= 16'd0;
                        crc_reg <= 32'hFFFF_FFFF;
                        if (I_src_last)
                            fill_state <= F_IDLE;
                    end else begin
                        fill_count <= fill_count + 1'b1;
                        crc_reg <= crc_next;
                    end
                end
            endcase
        end

        // ---- send side -------------------------------------------------
        case (send_state)
            S_IDLE: begin
                // Wait for the stack to be genuinely idle before requesting.
                // Back-to-back datagrams mean I_udp_busy may still be high
                // from the previous one, and uiudp_tx only latches a request
                // while it is low -- taking that stale level as the ack of
                // this request would start streaming data into a stack still
                // sitting in IDLE.  A single payload buffer could never hit
                // this, because filling always outlasted the previous frame.
                if (bank_ready[send_bank] && !I_udp_busy) begin
                    hdr_len <= bank_len[send_bank];
                    hdr_index <= bank_index[send_bank];
                    hdr_crc <= bank_crc[send_bank];
                    hdr_last <= bank_last[send_bank];
                    O_udp_len <= bank_len[send_bank] + 16'd32;
                    send_state <= S_REQUEST;
                end
            end
            S_REQUEST: begin
                O_udp_req <= 1'b1;
                if (I_udp_busy) begin
                    header_index <= 6'd0;
                    send_state <= S_HEADER;
                end
            end
            S_HEADER: begin
                O_udp_valid <= 1'b1;
                O_udp_data <= header_byte(header_index);
                if (header_index == 6'd31) begin
                    payload_read_index <= 16'd0;
                    send_state <= S_PAYLOAD;
                end else begin
                    header_index <= header_index + 1'b1;
                end
            end
            S_PAYLOAD: begin
                O_udp_valid <= 1'b1;
                O_udp_data <= payload_mem[{send_bank, payload_read_index[BANK_ADDR_BITS-1:0]}];
                if (payload_read_index + 1'b1 == hdr_len) begin
                    bank_ready[send_bank] <= 1'b0;
                    send_bank <= ~send_bank;
                    send_state <= hdr_last ? S_FINISH : S_IDLE;
                end else begin
                    payload_read_index <= payload_read_index + 1'b1;
                end
            end
            S_FINISH: begin
                if (accepted_frame_bytes == expected_frame_bytes)
                    O_frame_done <= 1'b1;
                else
                    O_frame_error <= 1'b1;
                send_state <= S_IDLE;
            end
            default: send_state <= S_IDLE;
        endcase
    end
end

endmodule
