`timescale 1ns/1ps

// HDMI-display observer: down-samples a frame-active-high RGB888 stream by
// two in both directions and emits tagged RGB565 bytes.  It never exposes a
// ready/backpressure signal to the HDMI path.
//
// Tag encoding on O_word[9:8], consumed by the bridge in evs_video_tx_core:
//
//   10 = first byte of a frame     00 = interior byte
//   01 = final byte of a frame     11 = FRAME ABORT (payload byte is a reason
//                                       code and carries no picture data)
//
// A real frame is always at least two bytes long, so "first AND last" can
// never occur naturally.  That free code point is what lets an abort travel
// in-band through the existing 10-bit CDC FIFO: no extra FIFO width, no extra
// ERAM, and no second CDC path to constrain.
//
// DECIMATION PHASE (2026-10-09, full-resolution bursts -- evs_burst_ctrl.v)
// I_phase = {y odd, x odd} picks which of the four 2x2 sub-grids this frame
// keeps; it and I_flags are latched on the VS rising edge of a frame that is
// actually started, and held for the whole frame.  Phase 0 keeps (even, even)
// exactly as before.  O_frame_flags is held from that edge until the next
// started frame, which is what lets the Ethernet side sample it as a
// quasi-static bus when it picks up this frame's first byte (see
// evs_video_tx_core).
module evs_video_sampler #(
    parameter integer OUT_WIDTH  = 960,
    parameter integer OUT_HEIGHT = 540
) (
    input  wire        I_pclk,
    input  wire        I_rst_n,
    input  wire        I_vs,
    input  wire        I_de,
    input  wire [23:0] I_rgb,
    input  wire        I_eth_can_start,
    input  wire        I_fifo_almost_full,
    input  wire [1:0]  I_phase,
    input  wire [7:0]  I_flags,
    output wire        O_frame_started,
    output reg  [7:0]  O_frame_flags,
    output reg         O_wr_en,
    output reg  [9:0]  O_word,
    output reg         O_frame_dropped,
    output reg         O_overflow
);

localparam integer FRAME_PIXELS = OUT_WIDTH * OUT_HEIGHT;
localparam [7:0] ABORT_REASON_AFULL = 8'hA0;

reg vs_d;
reg de_d;
reg capture_frame;
reg x_odd;
reg y_odd;
reg emit_low;
reg first_byte;
reg low_is_last;
reg [7:0] low_byte;
reg [19:0] sampled_pixels;
reg abort_pending;
reg px_sel;
reg py_sel;
wire [15:0] rgb565 = {I_rgb[23:19], I_rgb[15:10], I_rgb[7:3]};

// A frame may only be started when the Ethernet branch is idle AND the FIFO
// has room AND no abort marker is still waiting to be written.  That last
// term is what guarantees ordering: because the marker and the following
// frame-start marker travel through the same FIFO, refusing to start a frame
// while abort_pending is set makes the marker strictly precede the next
// start.  No extra synchronizer is needed for the abort to cross the CDC.
wire frame_start_ok = I_eth_can_start && !I_fifo_almost_full && !abort_pending;
assign O_frame_started = I_vs && !vs_d && frame_start_ok;

always @(posedge I_pclk or negedge I_rst_n) begin
    if (!I_rst_n) begin
        vs_d <= 1'b0;
        de_d <= 1'b0;
        capture_frame <= 1'b0;
        x_odd <= 1'b0;
        y_odd <= 1'b0;
        emit_low <= 1'b0;
        first_byte <= 1'b0;
        low_is_last <= 1'b0;
        low_byte <= 8'd0;
        sampled_pixels <= 20'd0;
        abort_pending <= 1'b0;
        px_sel <= 1'b0;
        py_sel <= 1'b0;
        O_frame_flags <= 8'd0;
        O_wr_en <= 1'b0;
        O_word <= 10'd0;
        O_frame_dropped <= 1'b0;
        O_overflow <= 1'b0;
    end else begin
        vs_d <= I_vs;
        de_d <= I_de;
        O_wr_en <= 1'b0;
        O_frame_dropped <= 1'b0;

        // Frame starts are evaluated before active pixels.  If the Ethernet
        // branch is unavailable, skip the complete frame rather than creating
        // a partial preview frame.
        if (I_vs && !vs_d) begin
            capture_frame <= frame_start_ok;
            x_odd <= 1'b0;
            y_odd <= 1'b0;
            emit_low <= 1'b0;
            first_byte <= frame_start_ok;
            sampled_pixels <= 20'd0;
            if (frame_start_ok) begin
                px_sel <= I_phase[0];
                py_sel <= I_phase[1];
                O_frame_flags <= I_flags;
            end else begin
                O_frame_dropped <= 1'b1;
            end
        end

        if (capture_frame) begin
            // A FIFO high-water mark is a fault guard, not a throttle.  The
            // active HDMI frame continues untouched, but the preview frame is
            // cut here -- so its final byte will never be produced, and an
            // explicit abort marker has to be queued.  Without it the bridge
            // and the packetizer wait forever for the remainder of a frame
            // that no longer exists, which is exactly the lock-up observed on
            // the board on 2026-09-21 (frame_sequence stuck at 1).
            if (I_fifo_almost_full) begin
                capture_frame <= 1'b0;
                emit_low <= 1'b0;
                abort_pending <= 1'b1;
                O_overflow <= 1'b1;
                O_frame_dropped <= 1'b1;
            end else if (emit_low) begin
                O_wr_en <= 1'b1;
                O_word <= {1'b0, low_is_last, low_byte};
                emit_low <= 1'b0;
                // The second RGB565 byte occupies the clock immediately
                // after a sampled pixel.  Pixel-position tracking must still
                // advance in that clock, otherwise horizontal decimation
                // would drift from x=0,2,4... to x=0,3,6....
                if (I_de)
                    x_odd <= ~x_odd;
            end else if (I_de && (y_odd == py_sel) && (x_odd == px_sel)) begin
                // A sampled column is never the clock right after a sampled
                // column (they are two apart), so the emit_low branch above
                // can only ever land on a column this phase does not keep.
                // With px_sel = 1 the line's last sample is x = H-1 and its
                // low byte goes out on the first clock after DE falls; the
                // emit_low branch does not need DE, and the DE-falling block
                // below only touches x_odd / y_odd.
                O_wr_en <= 1'b1;
                O_word <= {first_byte, 1'b0, rgb565[15:8]};
                first_byte <= 1'b0;
                low_byte <= rgb565[7:0];
                low_is_last <= (sampled_pixels == FRAME_PIXELS - 1);
                sampled_pixels <= sampled_pixels + 1'b1;
                emit_low <= 1'b1;
                // ~x_odd, not 1: x_odd is the parity of the column, and it
                // has to keep toggling on every DE clock whichever column is
                // sampled.  (Phase 0 samples at x_odd = 0, so ~x_odd = 1 is
                // exactly what this line used to say.)
                x_odd <= ~x_odd;
            end else if (I_de) begin
                x_odd <= ~x_odd;
            end

            if (de_d && !I_de) begin
                x_odd <= 1'b0;
                y_odd <= ~y_odd;
            end
        end

        // Write the queued abort marker once the FIFO has drained back below
        // the high-water mark.  capture_frame is necessarily 0 here (it was
        // cleared in the same cycle abort_pending was set, and cannot be set
        // again while abort_pending holds), so this can never race a payload
        // write for O_wr_en.
        if (abort_pending && !capture_frame && !I_fifo_almost_full) begin
            O_wr_en <= 1'b1;
            O_word <= {1'b1, 1'b1, ABORT_REASON_AFULL};
            abort_pending <= 1'b0;
        end
    end
end

endmodule
