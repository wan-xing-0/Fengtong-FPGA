`timescale 1ns/1ps

// Low-rate auxiliary datagrams that share the UDP endpoint with the EVS1 video
// stream: the once-a-second EVDBG1 status packet (moved here unchanged from
// eth_a_video_endpoint) and the EVQC1 workpiece record (new, 2026-10-04).
//
// HANDING THE STACK BACK (the reason this is its own module)
//
// The endpoint used to release the stack mux on the cycle after the last
// auxiliary byte.  uiudp_tx's busy is not the end of the user transfer: it is
// I_udp_ip_tbusy from uiip_arp_tx, which only falls once the datagram has
// passed the 8-deep PH1_LOGIC_SHIFTER and the IP layer.  The packetizer, in
// turn, decides to request on the same "stack idle" cycle the auxiliary FSM
// does, then sits in S_REQUEST behind a masked busy of 0.  When the mux was
// released while the stack was still busy with the auxiliary datagram, the
// packetizer saw busy 0 -> 1 and took it as the acknowledgement of its own
// request: it streamed a whole video datagram into a stack that was not
// listening, and the stack, back in IDLE, found its request already gone.
// One video packet vanished -- no CRC error, done_count still counted, the
// frame simply never completed on the host.  That happened on roughly every
// status packet sent while a frame was streaming, i.e. ~0.4 frames/s, which
// is the order of the 0.37/s the 2026-09-28 host log shows.
//
// A_DRAIN fixes it by holding the mux until the stack's busy has fallen.
// The packetizer's request, held all along, is then the only one the stack
// sees, and the busy edge it gets next is a genuine acknowledgement.
// LEGACY_RELEASE=1 restores the old release point; it exists only so the
// testbench can show the failure, and must stay 0 in the build.
//
// EVQC1 (32 bytes)
//   0..4   "EVQC1"
//   5      version (1)
//   6      repeat index, 0 .. QC_REPEAT-1
//   7      QC_REPEAT
//   8..9   video frame_sequence[15:0] when the record arrived in this domain;
//          the host captures the first complete frame after it
//   10..11 0
//   12..27 qc_rec[127:0], most significant byte first (layout: qc_thick.v)
//   28..30 0
//   31     XOR of bytes 0..30
// EVQC2 (48 bytes, QC_V2 = 1, 2026-10-09) -- the same record plus qc_ext:
//   0..4   "EVQC2"
//   5      version (2)
//   6..27  as EVQC1
//   28..43 qc_ext[127:0], most significant byte first (layout: system_top,
//          the qc_ext block next to eth_a_video_endpoint): shape, surface
//          defects, mean colour, defect box
//   44..46 0
//   47     XOR of bytes 0..46
//   qc_ext is latched in the video domain on the same trigger as qc_rec and
//   crosses exactly the way qc_rec does (sampled with it, below).
//   QC_V2 = 0 sends EVQC1, byte for byte as before.
//   2026-10-29: byte 5 is QC_VER.  2 = the 10-09 qc_ext layout; the endpoint
//   now sends 3 = the 10-29 layout (standard-part mode and verdict, stain_detect
//   in place of qc_defect -- system_top's qc_ext block).  Same 48 bytes.
// Each record is sent QC_REPEAT times, QC_GAP clocks apart, because UDP gives
// no delivery guarantee and one record per workpiece is all there is.  The
// host de-duplicates on qc_rec's sequence byte.  A newer record replaces a
// pending one and restarts its repeats.
//
// EVDBG1 byte 11 (2026-10-29): bit 0 phy_link as before, bits 7:1 I_ui_state,
// the board's modes for the receiver's GUI (layout at the endpoint).  An old
// receiver reads only bit 0.  I_diag_kick (one Ethernet clock, a command was
// just accepted) brings the next status packet forward to DIAG_KICK clocks
// from now, long enough for the command to reach the video side and the new
// state to come back through the endpoint's synchronizer.
//
// qc_rec crosses from the video clock as a quasi-static bus: qc_thick holds it
// from one trigger to the next (one workpiece apart), the toggle below flips
// two video clocks after the trigger, and the Ethernet side samples the bus
// only after the toggle has passed a two-flop synchronizer.  The bus is
// therefore stable for many Ethernet clocks around the sampling edge, and the
// path is covered by the clock groups in timing.sdc.
module evs_aux_tx #(
    parameter [31:0] DIAG_TICK      = 32'd125_000_000,  // 1 s at 125 MHz
    parameter [31:0] QC_GAP         = 32'd12_500_000,   // 100 ms
    parameter [1:0]  QC_REPEAT      = 2'd3,
    parameter        LEGACY_RELEASE = 1'b0,
    parameter        QC_V2          = 1'b0,
    parameter [7:0]  QC_VER         = 8'd2,               // EVQC2 byte 5
    parameter [31:0] DIAG_KICK      = 32'd12_500          // 100 us at 125 MHz
) (
    input  wire         I_clk,
    input  wire         I_reset,
    // stack side
    input  wire         I_udp_busy,
    output wire         O_udp_req,
    output wire         O_udp_valid,
    output wire [7:0]   O_udp_data,
    output wire [15:0]  O_udp_len,
    // video packetizer side
    input  wire         I_video_req,
    input  wire         I_video_valid,
    input  wire [7:0]   I_video_data,
    input  wire [15:0]  I_video_len,
    output wire         O_video_busy,
    // EVDBG1 content
    input  wire [31:0]  I_debug_status,
    input  wire [7:0]   I_debug_counts,
    input  wire         I_phy_link,
    input  wire [6:0]   I_ui_state,      // Ethernet clock (synchronized by the endpoint)
    input  wire         I_diag_kick,     // Ethernet clock, one clock
    // QC record, video clock domain
    input  wire         I_video_clk,
    input  wire         I_video_rst_n,
    input  wire         I_qc_trig,
    input  wire [127:0] I_qc_rec,
    input  wire [127:0] I_qc_ext,        // EVQC2 only; ignored when QC_V2 = 0
    // diagnostics
    output reg  [7:0]   O_qc_sent
);

localparam [1:0] A_IDLE  = 2'd0;
localparam [1:0] A_REQ   = 2'd1;
localparam [1:0] A_DATA  = 2'd2;
localparam [1:0] A_DRAIN = 2'd3;

localparam [5:0] DIAG_LAST = 6'd15;
localparam [5:0] QC_LAST   = QC_V2 ? 6'd47 : 6'd31;
localparam [15:0] QC_LEN   = QC_V2 ? 16'd48 : 16'd32;

//--------------------------------------------------------------------------
// video clock: trigger -> toggle, two clocks late so qc_rec has settled
//--------------------------------------------------------------------------
reg qc_trig_d1, qc_trig_d2, qc_toggle;

always @(posedge I_video_clk or negedge I_video_rst_n) begin
    if (!I_video_rst_n) begin
        qc_trig_d1 <= 1'b0;
        qc_trig_d2 <= 1'b0;
        qc_toggle <= 1'b0;
    end else begin
        qc_trig_d1 <= I_qc_trig;
        qc_trig_d2 <= qc_trig_d1;
        if (qc_trig_d2) qc_toggle <= ~qc_toggle;
    end
end

//--------------------------------------------------------------------------
// Ethernet clock
//--------------------------------------------------------------------------
reg qc_sync1, qc_sync2, qc_sync3;
reg [1:0] qc_arm;
reg [127:0] qc_rec_eth;
reg [127:0] qc_ext_eth;
reg [15:0] qc_fseq_eth;
reg [1:0] qc_left;
reg [31:0] qc_gap;

reg [31:0] diag_count;
reg [1:0] a_state;
reg a_active, a_kind_qc, a_req, a_valid;
reg [5:0] a_index;
reg [7:0] a_xor;
reg [127:0] tx_rec;
reg [127:0] tx_ext;
reg [15:0] tx_fseq;
reg [1:0] tx_rep;

// The Ethernet side comes out of reset (PHY ready) long after the video side
// may have toggled.  The first edges after reset only align qc_sync3 with
// the current level; they are not a new record.
wire qc_new = (qc_arm == 2'd3) && (qc_sync2 ^ qc_sync3);

wire diag_due = (diag_count == DIAG_TICK - 1'b1);
wire qc_due   = (qc_left != 2'd0) && (qc_gap == 32'd0);
wire stack_free = !I_udp_busy && !I_video_req && !I_video_valid;

function [7:0] diag_byte;
    input [5:0] index;
    begin
        case (index)
            6'd0: diag_byte = "E"; 6'd1: diag_byte = "V";
            6'd2: diag_byte = "D"; 6'd3: diag_byte = "B";
            6'd4: diag_byte = "G"; 6'd5: diag_byte = "1";
            6'd6: diag_byte = I_debug_status[31:24];
            6'd7: diag_byte = I_debug_status[23:16];
            6'd8: diag_byte = I_debug_status[15:8];
            6'd9: diag_byte = I_debug_status[7:0];
            // Saturating {abort_count, done_count}.  The bridge state this
            // byte used to repeat is already in status bits [10:8]; these two
            // nibbles are what distinguish "recovered from an abort and kept
            // completing frames" from "never aborted" on the board.
            6'd10: diag_byte = I_debug_counts;
            6'd11: diag_byte = {I_ui_state, I_phy_link};
            6'd12: diag_byte = {7'd0, I_udp_busy};
            6'd13: diag_byte = 8'h0d;
            6'd14: diag_byte = 8'h0a;
            default: diag_byte = 8'h01;
        endcase
    end
endfunction

function [7:0] qc_byte;
    input [5:0] index;
    begin
        case (index)
            6'd0: qc_byte = "E"; 6'd1: qc_byte = "V";
            6'd2: qc_byte = "Q"; 6'd3: qc_byte = "C";
            6'd4: qc_byte = QC_V2 ? "2" : "1";
            6'd5: qc_byte = QC_V2 ? QC_VER : 8'd1;
            6'd6: qc_byte = {6'd0, tx_rep};
            6'd7: qc_byte = {6'd0, QC_REPEAT};
            6'd8: qc_byte = tx_fseq[15:8];
            6'd9: qc_byte = tx_fseq[7:0];
            6'd12: qc_byte = tx_rec[127:120];
            6'd13: qc_byte = tx_rec[119:112];
            6'd14: qc_byte = tx_rec[111:104];
            6'd15: qc_byte = tx_rec[103:96];
            6'd16: qc_byte = tx_rec[95:88];
            6'd17: qc_byte = tx_rec[87:80];
            6'd18: qc_byte = tx_rec[79:72];
            6'd19: qc_byte = tx_rec[71:64];
            6'd20: qc_byte = tx_rec[63:56];
            6'd21: qc_byte = tx_rec[55:48];
            6'd22: qc_byte = tx_rec[47:40];
            6'd23: qc_byte = tx_rec[39:32];
            6'd24: qc_byte = tx_rec[31:24];
            6'd25: qc_byte = tx_rec[23:16];
            6'd26: qc_byte = tx_rec[15:8];
            6'd27: qc_byte = tx_rec[7:0];
            6'd28: qc_byte = QC_V2 ? tx_ext[127:120] : 8'd0;
            6'd29: qc_byte = QC_V2 ? tx_ext[119:112] : 8'd0;
            6'd30: qc_byte = QC_V2 ? tx_ext[111:104] : 8'd0;
            6'd31: qc_byte = QC_V2 ? tx_ext[103:96] : a_xor;
            6'd32: qc_byte = QC_V2 ? tx_ext[95:88] : 8'd0;
            6'd33: qc_byte = QC_V2 ? tx_ext[87:80] : 8'd0;
            6'd34: qc_byte = QC_V2 ? tx_ext[79:72] : 8'd0;
            6'd35: qc_byte = QC_V2 ? tx_ext[71:64] : 8'd0;
            6'd36: qc_byte = QC_V2 ? tx_ext[63:56] : 8'd0;
            6'd37: qc_byte = QC_V2 ? tx_ext[55:48] : 8'd0;
            6'd38: qc_byte = QC_V2 ? tx_ext[47:40] : 8'd0;
            6'd39: qc_byte = QC_V2 ? tx_ext[39:32] : 8'd0;
            6'd40: qc_byte = QC_V2 ? tx_ext[31:24] : 8'd0;
            6'd41: qc_byte = QC_V2 ? tx_ext[23:16] : 8'd0;
            6'd42: qc_byte = QC_V2 ? tx_ext[15:8] : 8'd0;
            6'd43: qc_byte = QC_V2 ? tx_ext[7:0] : 8'd0;
            6'd47: qc_byte = QC_V2 ? a_xor : 8'd0;
            default: qc_byte = 8'd0;
        endcase
    end
endfunction

wire [7:0] a_byte = a_kind_qc ? qc_byte(a_index) : diag_byte(a_index);

assign O_video_busy = a_active ? 1'b0 : I_udp_busy;
assign O_udp_req    = a_active ? a_req : I_video_req;
assign O_udp_valid  = a_active ? a_valid : I_video_valid;
assign O_udp_data   = a_active ? a_byte : I_video_data;
assign O_udp_len    = a_active ? (a_kind_qc ? QC_LEN : 16'd16) : I_video_len;

always @(posedge I_clk or posedge I_reset) begin
    if (I_reset) begin
        qc_sync1 <= 1'b0;
        qc_sync2 <= 1'b0;
        qc_sync3 <= 1'b0;
        qc_arm <= 2'd0;
        qc_rec_eth <= 128'd0;
        qc_ext_eth <= 128'd0;
        qc_fseq_eth <= 16'd0;
        qc_left <= 2'd0;
        qc_gap <= 32'd0;
        diag_count <= 32'd0;
        a_state <= A_IDLE;
        a_active <= 1'b0;
        a_kind_qc <= 1'b0;
        a_req <= 1'b0;
        a_valid <= 1'b0;
        a_index <= 6'd0;
        a_xor <= 8'd0;
        tx_rec <= 128'd0;
        tx_ext <= 128'd0;
        tx_fseq <= 16'd0;
        tx_rep <= 2'd0;
        O_qc_sent <= 8'd0;
    end else begin
        qc_sync1 <= qc_toggle;
        qc_sync2 <= qc_sync1;
        qc_sync3 <= qc_sync2;
        if (qc_arm != 2'd3) qc_arm <= qc_arm + 1'b1;

        if (qc_gap != 32'd0) qc_gap <= qc_gap - 1'b1;
        if (!diag_due) diag_count <= diag_count + 1'b1;

        // A record that arrives while one is going out does not disturb it:
        // the bytes come from tx_*, loaded when the datagram was granted.
        if (qc_new) begin
            qc_rec_eth <= I_qc_rec;
            qc_ext_eth <= QC_V2 ? I_qc_ext : 128'd0;
            qc_fseq_eth <= I_debug_status[31:16];
            if (I_qc_rec[127]) begin
                qc_left <= QC_REPEAT;
                qc_gap <= 32'd0;
            end
        end

        case (a_state)
            A_IDLE: begin
                a_req <= 1'b0;
                a_valid <= 1'b0;
                a_active <= 1'b0;
                if (stack_free && (qc_due || diag_due) && !qc_new) begin
                    a_active <= 1'b1;
                    a_state <= A_REQ;
                    // A record wins over the status packet; the status packet
                    // simply waits for the next free slot.
                    a_kind_qc <= qc_due;
                    if (qc_due) begin
                        tx_rec <= qc_rec_eth;
                        tx_ext <= qc_ext_eth;
                        tx_fseq <= qc_fseq_eth;
                        tx_rep <= QC_REPEAT - qc_left;
                        qc_left <= qc_left - 1'b1;
                        qc_gap <= QC_GAP;
                    end else begin
                        diag_count <= 32'd0;
                    end
                end
            end
            A_REQ: begin
                a_req <= 1'b1;
                if (I_udp_busy) begin
                    a_req <= 1'b0;
                    a_valid <= 1'b1;
                    a_index <= 6'd0;
                    a_xor <= 8'd0;
                    a_state <= A_DATA;
                end
            end
            A_DATA: begin
                a_valid <= 1'b1;
                a_xor <= a_xor ^ a_byte;
                if (a_index == (a_kind_qc ? QC_LAST : DIAG_LAST)) begin
                    a_valid <= 1'b0;
                    if (a_kind_qc && O_qc_sent != 8'hFF)
                        O_qc_sent <= O_qc_sent + 1'b1;
                    if (LEGACY_RELEASE) begin
                        a_active <= 1'b0;
                        a_state <= A_IDLE;
                    end else begin
                        a_state <= A_DRAIN;
                    end
                end else begin
                    a_index <= a_index + 1'b1;
                end
            end
            A_DRAIN: begin
                if (!I_udp_busy) begin
                    a_active <= 1'b0;
                    a_state <= A_IDLE;
                end
            end
            default: a_state <= A_IDLE;
        endcase

        // Last, so it wins over the reload A_IDLE does when it sends: a
        // status packet already going out may describe the old state.
        if (I_diag_kick)
            diag_count <= DIAG_TICK - DIAG_KICK;
    end
end

endmodule
