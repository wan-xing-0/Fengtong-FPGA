`timescale 1ns/1ps

// Portable video-to-UDP core.  This is the sole planned bridge between the
// image-processing project and the Ethernet subsystem.  It exposes no ready
// signal to the video side, therefore HDMI timing always remains authoritative.
//
// READ-SIDE THROUGHPUT (why the bridge looks the way it does)
//
// The sampler writes one byte per video clock for the whole active part of
// every even line: 1920 bytes per 2-line period at 150 MHz, i.e. ~65 MB/s
// averaged over two lines and 150 MB/s in burst.  The CDC FIFO is only 8 Ki
// words while a frame is ~1 MB, so the FIFO cannot absorb a frame-scale
// deficit -- the read side has to sustain the per-line rate, not the
// per-frame rate.  Frame decimation does NOT relax this, because the sampler
// writes at the source line rate regardless of how many frames are kept.
//
// The vendor FIFO gates its read enable internally (rd_en_s = re & ~empty),
// has a fixed two-cycle response (valid = re_r2 & ~empty_r2) and applies no
// backpressure of its own.  So holding `re` asserted returns one word per
// clock, which is 125 MB/s.  What that costs is a small skid buffer: once a
// read is issued its word WILL arrive two cycles later whether or not the
// consumer is ready, so up to two in-flight words plus the held word must
// have somewhere to land.  The previous issue-one-and-wait model was correct
// but ran at ~5 clocks per byte (~25 MB/s, ~20 MB/s after packetizer send
// gaps) -- roughly 3.3x short, which is why every frame hit the high-water
// mark no matter how the abort path behaved.
//
// FULL-RESOLUTION BURSTS (2026-10-09): evs_burst_ctrl picks the sampler's
// decimation phase per frame and the EVS1 header flags byte that names it.
// Tie I_qc_trig and I_timer_en low and every frame is phase 0 with flags 0,
// i.e. the v1.0 stream bit for bit (I_alarm_level / I_present then unused).
// 2026-10-29: I_sec_hold / I_staff_pass go straight to evs_burst_ctrl (staff
// verification: no security pictures, one staff record on a pass).
module evs_video_tx_core #(
    parameter integer OUT_WIDTH = 960,
    parameter integer OUT_HEIGHT = 540,
    parameter [31:0] SESSION_ID = 32'h0000_0001,
    parameter integer BURST_TIMER_VS = 60,
    parameter integer BURST_QC_DELAY_VS = 2,
    parameter integer BURST_STAFF_DELAY_VS = 2
) (
    input  wire        I_video_clk,
    input  wire        I_video_rst_n,
    input  wire        I_video_vs,
    input  wire        I_video_de,
    input  wire [23:0] I_video_rgb,
    input  wire        I_qc_trig,          // video clock, one clock per workpiece
    input  wire        I_timer_en,         // video clock, level (security mode)
    input  wire [1:0]  I_alarm_level,      // video clock, alert_ctrl level 0..3
    input  wire        I_present,          // video clock, motion or a face now
    input  wire        I_sec_hold,         // video clock, level: no security bursts
    input  wire        I_staff_pass,       // video clock, level: staff verified
    input  wire        I_eth_clk,
    input  wire        I_eth_reset,
    input  wire        I_udp_busy,
    output wire        O_udp_req,
    output wire        O_udp_valid,
    output wire [7:0]  O_udp_data,
    output wire [15:0] O_udp_len,
    output wire        O_video_frame_dropped,
    output wire        O_fifo_overflow,
    output wire        O_packetizer_error,
    output wire [31:0] O_debug_status,
    output wire [7:0]  O_debug_counts
);

localparam [31:0] FRAME_BYTES = OUT_WIDTH * OUT_HEIGHT * 2;
localparam [15:0] FRAME_WIDTH16 = OUT_WIDTH;
localparam [15:0] FRAME_HEIGHT16 = OUT_HEIGHT;

// Kept on the historical numbering so EVDBG1 captures stay comparable with
// the 2026-09-21 board logs: "bridge=3" still means "streaming a frame".
localparam [2:0] B_WAIT_START = 3'd0;
localparam [2:0] B_STREAM     = 3'd3;

localparam integer SKID_DEPTH = 8;
localparam [4:0] SKID_LIMIT = 5'd8;

wire fifo_almost_full, fifo_full, fifo_empty;
wire [9:0] fifo_word;
wire fifo_valid;
wire fifo_re;
wire sampler_wr_en;
wire [9:0] sampler_word;
wire packetizer_ready, packetizer_src_ready;
wire packetizer_done;
reg can_start_eth;
reg can_start_video_meta, can_start_video;
reg [31:0] frame_sequence;
reg video_vs_seen, video_de_seen, video_write_seen;
reg video_vs_seen_meta, video_vs_seen_eth;
reg video_de_seen_meta, video_de_seen_eth;
reg video_write_seen_meta, video_write_seen_eth;
reg packet_start_seen;
reg abort_seen;
reg [3:0] abort_count;
reg [3:0] done_count;
reg [2:0] bridge_state;
reg fifo_re_r;
reg [2:0] outstanding;
reg [9:0] skid_mem [0:SKID_DEPTH-1];
reg [2:0] skid_wr_ptr, skid_rd_ptr;
reg [3:0] skid_count;
reg packet_start;
reg packet_abort;
reg packet_src_valid, packet_src_last;
reg [7:0] packet_src_byte;
reg [7:0] packet_flags;
wire [1:0] burst_phase;
wire [7:0] burst_flags;
wire sampler_frame_started;
wire [7:0] sampler_frame_flags;

// Sticky activity flags make the otherwise internal video/FIFO stages visible
// to the endpoint's low-rate diagnostic datagram.  They are diagnostic only;
// no control decision crosses clock domains through these bits.
always @(posedge I_video_clk or negedge I_video_rst_n) begin
    if (!I_video_rst_n) begin
        video_vs_seen <= 1'b0;
        video_de_seen <= 1'b0;
        video_write_seen <= 1'b0;
    end else begin
        if (I_video_vs) video_vs_seen <= 1'b1;
        if (I_video_de) video_de_seen <= 1'b1;
        if (sampler_wr_en) video_write_seen <= 1'b1;
    end
end

always @(posedge I_eth_clk or posedge I_eth_reset) begin
    if (I_eth_reset) begin
        video_vs_seen_meta <= 1'b0;
        video_vs_seen_eth <= 1'b0;
        video_de_seen_meta <= 1'b0;
        video_de_seen_eth <= 1'b0;
        video_write_seen_meta <= 1'b0;
        video_write_seen_eth <= 1'b0;
        packet_start_seen <= 1'b0;
    end else begin
        video_vs_seen_meta <= video_vs_seen;
        video_vs_seen_eth <= video_vs_seen_meta;
        video_de_seen_meta <= video_de_seen;
        video_de_seen_eth <= video_de_seen_meta;
        video_write_seen_meta <= video_write_seen;
        video_write_seen_eth <= video_write_seen_meta;
        if (packet_start) packet_start_seen <= 1'b1;
    end
end

// Bit 7 was held_valid and bit 6 was read_pending; both registers are gone
// with the skid-buffer read path.  They now carry the outgoing source-byte
// valid and a sticky "an abort marker was processed" flag, which is the one
// bit that tells a board test whether the recovery path actually ran.
assign O_debug_status = {
    frame_sequence[15:0],
    packet_start_seen,
    video_write_seen_eth,
    video_de_seen_eth,
    video_vs_seen_eth,
    packetizer_ready,
    bridge_state,
    packet_src_valid,
    abort_seen,
    fifo_valid,
    fifo_full,
    fifo_almost_full,
    fifo_empty,
    can_start_video,
    can_start_eth
};

assign O_debug_counts = {abort_count, done_count};

// Synchronize only the Ethernet-domain admission decision into the video
// domain.  FIFO capacity is intentionally NOT part of can_start_eth: afull is
// generated in the FIFO write clock domain and must never feed eth_clk logic.
// The sampler combines this synchronized permission with afull locally at the
// frame boundary, eliminating the former pclkx1 -> eth_tx_clk CDC path.
always @(posedge I_video_clk or negedge I_video_rst_n) begin
    if (!I_video_rst_n) begin
        can_start_video_meta <= 1'b0;
        can_start_video <= 1'b0;
    end else begin
        can_start_video_meta <= can_start_eth;
        can_start_video <= can_start_video_meta;
    end
end

evs_burst_ctrl #(
    .TIMER_VS(BURST_TIMER_VS), .QC_DELAY_VS(BURST_QC_DELAY_VS),
    .STAFF_DELAY_VS(BURST_STAFF_DELAY_VS)
) u_burst (
    .I_clk(I_video_clk), .I_rst_n(I_video_rst_n), .I_vs(I_video_vs),
    .I_qc_trig(I_qc_trig), .I_timer_en(I_timer_en),
    .I_alarm_level(I_alarm_level), .I_present(I_present),
    .I_sec_hold(I_sec_hold), .I_staff_pass(I_staff_pass),
    .I_frame_started(sampler_frame_started),
    .O_phase(burst_phase), .O_flags(burst_flags)
);

evs_video_sampler #(
    .OUT_WIDTH(OUT_WIDTH), .OUT_HEIGHT(OUT_HEIGHT)
) u_sampler (
    .I_pclk(I_video_clk), .I_rst_n(I_video_rst_n),
    .I_vs(I_video_vs), .I_de(I_video_de), .I_rgb(I_video_rgb),
    .I_eth_can_start(can_start_video), .I_fifo_almost_full(fifo_almost_full),
    .I_phase(burst_phase), .I_flags(burst_flags),
    .O_frame_started(sampler_frame_started), .O_frame_flags(sampler_frame_flags),
    .O_wr_en(sampler_wr_en), .O_word(sampler_word),
    .O_frame_dropped(O_video_frame_dropped), .O_overflow(O_fifo_overflow)
);

evs_async_frame_fifo u_frame_fifo (
    .I_reset(I_eth_reset),
    .I_wr_clk(I_video_clk), .I_wr_en(sampler_wr_en), .I_wr_word(sampler_word),
    .O_almost_full(fifo_almost_full), .O_full(fifo_full),
    .I_rd_clk(I_eth_clk), .I_rd_en(fifo_re), .O_rd_word(fifo_word),
    .O_rd_valid(fifo_valid), .O_empty(fifo_empty)
);

assign fifo_re = fifo_re_r;

// Mirrors the vendor FIFO's internal rd_en_s so in-flight reads can be
// counted without relying on anything the wrapper does not expose.
wire fifo_rd_accept = fifo_re_r && !fifo_empty;

// Words already committed to a skid slot: the ones sitting in skid_mem, the
// ones in flight, AND the read being accepted in this very cycle.  That last
// term is not optional.  `outstanding` only moves on the next edge, and in
// steady state -- one read accepted and one word returned per clock -- it sits
// at its two-cycle-latency value of 2 and never grows, so an in-cycle accept
// left out of the total is counted by nothing at all.  That let one extra read
// be issued while the consumer was stalled: skid_count reached 9 in an 8-slot
// buffer, skid_wr_ptr lapped skid_rd_ptr by a full turn, and the oldest word
// was clobbered by the word exactly SKID_DEPTH positions later.  On the wire
// that appeared as one byte per packet -- payload offset 1 -- holding the
// frame byte 8 further on, with the header CRC still self-consistent because
// the packetizer had faithfully accepted whatever the bridge handed it.
wire [4:0] skid_load = {1'b0, skid_count} + {2'b0, outstanding}
                                          + {4'b0, fifo_rd_accept};
wire skid_room_ok = (skid_load < SKID_LIMIT);

wire [9:0] skid_head = skid_mem[skid_rd_ptr];
wire skid_avail = (skid_count != 4'd0);
wire head_abort = skid_head[9] && skid_head[8];
wire head_start = skid_head[9] && !skid_head[8];
wire head_last  = skid_head[8];

// The output register is loadable when it is empty or being consumed this
// cycle.  packet_src_valid is held until the packetizer takes it, which is
// what makes the source interface a real ready/valid pair -- the previous
// fire-and-forget pulse could be lost if the packetizer left S_FILL on the
// very byte that completed a packet.
wire out_free = !packet_src_valid || packetizer_src_ready;

reg pop_req;
reg fwd_req;
reg start_req;
reg abort_req;

always @(*) begin
    pop_req   = 1'b0;
    fwd_req   = 1'b0;
    start_req = 1'b0;
    abort_req = 1'b0;
    if (skid_avail) begin
        // Abort must be tested before start.  An abort marker has bit 9 set
        // as well, so checking start first would make B_WAIT_START mistake
        // an abort for a frame header -- including the case where a frame is
        // cut before its first byte was ever written.
        if (head_abort) begin
            pop_req   = 1'b1;
            abort_req = 1'b1;
        end else if (bridge_state == B_WAIT_START) begin
            if (head_start) begin
                // Hold the start marker until the packetizer is genuinely
                // idle.  If the packetizer is still draining the datagrams
                // of an aborted frame, a start pulse would be ignored and
                // the new frame would stream with no frame context.
                if (packetizer_ready && out_free) begin
                    pop_req   = 1'b1;
                    fwd_req   = 1'b1;
                    start_req = 1'b1;
                end
            end else begin
                // Stale interior/last byte of a frame that was skipped or
                // aborted: discard so the stream re-synchronizes on the next
                // start marker.  Needs no output-register space.
                pop_req = 1'b1;
            end
        end else begin
            if (out_free) begin
                pop_req = 1'b1;
                fwd_req = 1'b1;
            end
        end
    end
end

always @(posedge I_eth_clk or posedge I_eth_reset) begin
    if (I_eth_reset) begin
        bridge_state <= B_WAIT_START;
        fifo_re_r <= 1'b0;
        outstanding <= 3'd0;
        skid_wr_ptr <= 3'd0;
        skid_rd_ptr <= 3'd0;
        skid_count <= 4'd0;
        packet_start <= 1'b0;
        packet_abort <= 1'b0;
        packet_src_valid <= 1'b0;
        packet_src_last <= 1'b0;
        packet_src_byte <= 8'd0;
        packet_flags <= 8'd0;
        frame_sequence <= 32'd0;
        abort_seen <= 1'b0;
        abort_count <= 4'd0;
        done_count <= 4'd0;
    end else begin
        packet_start <= 1'b0;
        packet_abort <= 1'b0;

        // Keep a read in flight whenever the FIFO has data and the skid
        // buffer can still accept every word already committed plus this
        // one.  Asserting re while empty is harmless: the FIFO masks it.
        fifo_re_r <= !fifo_empty && skid_room_ok;

        if (fifo_rd_accept && !fifo_valid)
            outstanding <= outstanding + 1'b1;
        else if (!fifo_rd_accept && fifo_valid)
            outstanding <= outstanding - 1'b1;

        if (fifo_valid) begin
            skid_mem[skid_wr_ptr] <= fifo_word;
            skid_wr_ptr <= skid_wr_ptr + 1'b1;
        end

        if (pop_req)
            skid_rd_ptr <= skid_rd_ptr + 1'b1;

        if (fifo_valid && !pop_req)
            skid_count <= skid_count + 1'b1;
        else if (!fifo_valid && pop_req)
            skid_count <= skid_count - 1'b1;

        if (abort_req) begin
            // Drop the byte still sitting in the output register: it belongs
            // to the dead frame, and the packetizer would otherwise take it
            // as the first byte of the next one.
            packet_src_valid <= 1'b0;
            packet_abort <= 1'b1;
            abort_seen <= 1'b1;
            if (abort_count != 4'hF)
                abort_count <= abort_count + 1'b1;
            bridge_state <= B_WAIT_START;
        end else begin
            if (fwd_req) begin
                packet_src_valid <= 1'b1;
                packet_src_byte <= skid_head[7:0];
                packet_src_last <= skid_head[8];
            end else if (packet_src_valid && packetizer_src_ready) begin
                packet_src_valid <= 1'b0;
            end

            if (start_req) begin
                packet_start <= 1'b1;
                frame_sequence <= frame_sequence + 1'b1;
                bridge_state <= B_STREAM;
                // sampler_frame_flags is a pclkx1 register, sampled here as a
                // QUASI-STATIC bus, no synchronizer.  It was written on this
                // frame's VS edge, its start marker was written at the first
                // DE tens of lines later and then had to cross the FIFO's own
                // gray-code synchronizer, so it has been stable for tens of
                // microseconds by now.  It is rewritten only on a started VS
                // edge, and the next VS edge is a whole frame (16.7 ms) away:
                // this frame was admitted with the packetizer idle, so its
                // start marker is taken as soon as it reaches the skid head,
                // within the first active line.  Same argument as qc_rec in
                // evs_aux_tx; covered by the pclkx1 / eth_tx_clk clock group.
                packet_flags <= sampler_frame_flags;
            end else if (fwd_req && head_last) begin
                bridge_state <= B_WAIT_START;
            end
        end

        if (packetizer_done && done_count != 4'hF)
            done_count <= done_count + 1'b1;
    end
end

// Do not start sampling a new video frame until the previous one has cleared
// the packetizer and the read path is drained.  The PHY/UDP wrapper may later
// AND this with its link-up state without changing the video interface.
always @(posedge I_eth_clk or posedge I_eth_reset) begin
    if (I_eth_reset) can_start_eth <= 1'b0;
    else can_start_eth <= packetizer_ready && (bridge_state == B_WAIT_START)
                                           && (skid_count == 4'd0);
end

evs_udp_packetizer #(.SESSION_ID(SESSION_ID)) u_packetizer (
    .I_clk(I_eth_clk), .I_reset(I_eth_reset),
    .I_frame_start(packet_start), .I_frame_abort(packet_abort),
    .I_frame_sequence(frame_sequence), .I_frame_flags(packet_flags),
    .I_width(FRAME_WIDTH16), .I_height(FRAME_HEIGHT16), .I_frame_bytes(FRAME_BYTES),
    .I_src_valid(packet_src_valid), .I_src_byte(packet_src_byte), .I_src_last(packet_src_last),
    .O_src_ready(packetizer_src_ready), .I_udp_busy(I_udp_busy),
    .O_udp_req(O_udp_req), .O_udp_valid(O_udp_valid), .O_udp_data(O_udp_data),
    .O_udp_len(O_udp_len), .O_ready_for_frame(packetizer_ready),
    .O_frame_done(packetizer_done), .O_frame_error(O_packetizer_error)
);

endmodule
