`timescale 1ns/1ps

// Full-resolution capture by phase-shifted decimation (2026-10-09,
// PLAN_FULLRES_CAPTURE.md).
//
// The preview stream is 1920x1080 decimated 2:2 to 960x540: every frame keeps
// the pixels at (even x, even y).  A BURST is four consecutive SENT frames that
// keep (x odd?, y odd?) = (0,0), (1,0), (0,1), (1,1) instead; the PC interleaves
// them back into one 1920x1080 picture.  Each frame is still exactly a 960x540
// frame -- same byte count, same write rhythm into the CDC FIFO, same packet
// count -- so the bandwidth, the FIFO margin and the packetizer are unchanged.
// That is the whole point: nothing on the proven data path moves.
//
// What this module decides is only WHICH phase the sampler uses for the next
// frame it starts, plus the EVS1 header flags that tell the PC what it got:
//
//   flags[0]    staff record (2026-10-29): the one burst taken when a staff
//               member passes verification ("员工 PASS" on the picture).
//               Only with source 1; 0 on every other frame
//   flags[1]    this frame is a member of a full-resolution burst
//   flags[3:2]  phase 0..3: bit 2 = x odd, bit 3 = y odd
//   flags[5:4]  burst source: 0 QC (qc_trig)
//                             1 security, nobody there ("normal" record),
//                               or the staff record when flags[0] is set
//                             2 security alarm, level 2 (a face was seen)
//                             3 security alarm, level 3 (motion >= 2 s, no face)
//   flags[7:6]  burst id, +1 per burst, lets the PC keep two bursts apart
//
// A frame that is not a burst member has flags = 0 and phase (0,0): bit-
// identical to the v1.0 stream, so an older receiver keeps working.
//
// PHASE ONLY ADVANCES ON A FRAME THE SAMPLER REALLY STARTED.  The sampler skips
// a whole frame whenever the Ethernet side is still busy (frame_start_ok low);
// a skipped frame must not consume a phase, otherwise the PC would receive
// phases 0,2,3 and never 1.  I_frame_started is the sampler's own "I latched
// your outputs and started" pulse, on the VS rising edge.
//
// The outputs are a mux on state registers that only change between frames;
// the sampler latches them on the VS rising edge and holds them for the whole
// frame.
//
// QC bursts wait QC_DELAY_VS frame starts (VS edges, started or not) after
// qc_trig: qc_stable rises on the clock qc_thick commits, and the OSD's
// "稳定 #n" row is drawn from the following frame on.  The card should show it.
// A trigger that arrives while a burst runs is remembered and served next.
//
// SECURITY (2026-10-09, user's rule).  While I_timer_en (security mode) is
// high, a period timer counts VS edges and every TIMER_VS of them (~1 s)
// decides what this second's burst is, from alert_ctrl's level and "someone
// is there right now":
//
//   level 2 or 3 AND present  -> alarm burst, source = level (2 or 3)
//   nobody present            -> normal burst, source 1
//   anything else (level 1:   -> no burst this second.  Motion that is not
//   moving, not yet confirmed)   confirmed is neither an alarm nor "normal".
//
// The level stays 2/3 for REARM_S (5 s) after the intruder leaves; the
// present term is what stops the alarm pictures the moment they go, as asked.
// The PC keeps every alarm burst and one normal burst per its own interval
// (no resynthesis to change it).  Normal bursts are simply not sent while
// someone is there, so a record that falls due during an alarm is taken from
// the first normal burst after it -- "the scene after the intruder left".
// The moment an alarm starts (level 2/3 and present become true together) a
// burst is requested at once and the period restarts, so the first alarm
// picture is not up to a second late.  TIMER_VS = 0 turns the security
// bursts off.
//
// STAFF (2026-10-29, user's rule).  I_sec_hold high = no security burst at
// all, alarm or normal: system_top holds it while a face is being verified
// (the "请走近" / mouth / blink states) and from a pass until 30 s after it
// ends (spot_seq's mute).  A request already queued when the hold rises is dropped; a
// burst already running finishes.  When the hold falls with an alarm still
// on, that counts as the alarm starting (a burst at once).  The one exception
// is the staff record: I_staff_pass rising (in security mode) requests ONE
// burst STAFF_DELAY_VS frame starts later -- by then aim_label has drawn the
// green "员工 PASS" banner, which is the picture asked for -- sent as source 1
// with flags[0] set.  QC first, then staff, then the timer, if two are due.
module evs_burst_ctrl #(
    parameter integer TIMER_VS       = 60,   // ~1 s at 60 Hz; 0 = no timer
    parameter integer QC_DELAY_VS    = 2,
    parameter integer STAFF_DELAY_VS = 2
) (
    input  wire       I_clk,
    input  wire       I_rst_n,
    input  wire       I_vs,
    input  wire       I_qc_trig,          // one clock, pclkx1
    input  wire       I_timer_en,         // security mode
    input  wire [1:0] I_alarm_level,      // alert_ctrl's level (sec_level)
    input  wire       I_present,          // motion or a face right now
    input  wire       I_sec_hold,         // level: no security bursts (staff verification / pass)
    input  wire       I_staff_pass,       // level: staff_ctrl's pass
    input  wire       I_frame_started,    // one clock, on a started VS edge
    output wire [1:0] O_phase,            // {y odd, x odd}
    output wire [7:0] O_flags
);

localparam [1:0] SRC_QC     = 2'd0;
localparam [1:0] SRC_NORMAL = 2'd1;
localparam [3:0]  QC_DELAY4    = QC_DELAY_VS;
localparam [3:0]  STAFF_DELAY4 = STAFF_DELAY_VS;
localparam [15:0] TIMER_LAST = (TIMER_VS > 0) ? TIMER_VS - 1 : 0;

reg vs_d;
wire vs_rise = I_vs && !vs_d;

reg        active;
reg [1:0]  phase;
reg [1:0]  src;
reg        staff_b;                // the running burst is the staff record
reg [1:0]  burst_id;
reg        qc_pend;
reg [3:0]  qc_wait;
reg        staff_pend;
reg [3:0]  staff_wait;
reg        staff_d;
reg        timer_pend;
reg [1:0]  timer_src;
reg [15:0] timer_cnt;
reg        alarm_d;

wire qc_ready    = qc_pend && (qc_wait == 4'd0);
wire staff_ready = staff_pend && (staff_wait == 4'd0);

wire sec_on     = I_timer_en && (TIMER_VS != 0);
wire sec_free   = sec_on && !I_sec_hold;
wire alarm_on   = sec_free && I_present && I_alarm_level[1];   // level 2 or 3
wire quiet      = sec_free && !I_present;
wire alarm_rise = alarm_on && !alarm_d;
wire period_end = vs_rise && (timer_cnt == TIMER_LAST);
wire new_req    = (alarm_rise || period_end) && (alarm_on || quiet);
wire staff_rise = sec_on && I_staff_pass && !staff_d;

// Straight from the state registers, NOT registered again.  The sampler
// latches these on the very clock I_frame_started advances the state, so
// they must show the phase that frame is getting.  A registered copy lags
// one clock: a burst activated on the clock before a frame start would hand
// that frame the idle (0, flags 0) outputs while the state machine counted
// it as phase 0 -- and the PC would never see phase 0.  A 2-input mux on
// registers is not a timing concern.
assign O_phase = active ? phase : 2'd0;
assign O_flags = active ? {burst_id, src, phase, 1'b1, staff_b} : 8'd0;

always @(posedge I_clk or negedge I_rst_n) begin
    if (!I_rst_n) begin
        vs_d <= 1'b0;
        active <= 1'b0;
        phase <= 2'd0;
        src <= SRC_QC;
        staff_b <= 1'b0;
        burst_id <= 2'd0;
        qc_pend <= 1'b0;
        qc_wait <= 4'd0;
        staff_pend <= 1'b0;
        staff_wait <= 4'd0;
        staff_d <= 1'b0;
        timer_pend <= 1'b0;
        timer_src <= SRC_NORMAL;
        timer_cnt <= 16'd0;
        alarm_d <= 1'b0;
    end else begin
        vs_d <= I_vs;
        alarm_d <= alarm_on;
        staff_d <= I_staff_pass;

        // ---- requests ----------------------------------------------------
        if (I_qc_trig) begin
            qc_pend <= 1'b1;
            qc_wait <= QC_DELAY4;
        end else if (vs_rise && qc_pend && qc_wait != 4'd0) begin
            qc_wait <= qc_wait - 1'b1;
        end

        if (!sec_on) begin
            staff_pend <= 1'b0;
        end else if (staff_rise) begin
            staff_pend <= 1'b1;
            staff_wait <= STAFF_DELAY4;
        end else if (vs_rise && staff_pend && staff_wait != 4'd0) begin
            staff_wait <= staff_wait - 1'b1;
        end

        // A request queues behind a running burst (four frames out of sixty,
        // so it waits at most that long); a newer decision replaces an older
        // one that has not started yet.
        if (!sec_on) begin
            timer_cnt <= 16'd0;
            timer_pend <= 1'b0;
        end else if (alarm_rise || period_end) begin
            timer_cnt <= 16'd0;
            if (new_req) begin
                timer_pend <= 1'b1;
                timer_src <= alarm_on ? I_alarm_level : SRC_NORMAL;
            end
        end else if (vs_rise) begin
            timer_cnt <= timer_cnt + 1'b1;
        end

        // ---- burst sequencing --------------------------------------------
        // Checked in this order on purpose: a frame that starts on the very
        // clock a burst becomes active latched the idle outputs, so it is a
        // plain frame and the burst begins with the next one.
        if (active) begin
            if (I_frame_started) begin
                if (phase == 2'd3) begin
                    active <= 1'b0;
                    phase <= 2'd0;
                end else begin
                    phase <= phase + 1'b1;
                end
            end
        end else if (!I_frame_started && (qc_ready || staff_ready || timer_pend)) begin
            active <= 1'b1;
            phase <= 2'd0;
            burst_id <= burst_id + 1'b1;
            if (qc_ready) begin
                src <= SRC_QC;
                staff_b <= 1'b0;
                qc_pend <= I_qc_trig;     // a trigger on this very clock stays queued
            end else if (staff_ready) begin
                src <= SRC_NORMAL;
                staff_b <= 1'b1;
                staff_pend <= staff_rise;
            end else begin
                src <= timer_src;
                staff_b <= 1'b0;
                // A decision made on this very clock stays queued.
                timer_pend <= sec_on && new_req;
            end
        end

        // The hold cancels a queued security decision, whatever set it above.
        if (I_sec_hold)
            timer_pend <= 1'b0;
    end
end

endmodule
