`timescale 1ns/1ps

// PC -> FPGA control datagrams (2026-10-29): the receiver's GUI switches the
// board's modes the way its keys do.  uiudp_stack's receive port (O_R_udp_*)
// has been left open since v1.0; this module listens on it.
//
// EVCMD, 8 bytes of UDP payload, sent to the board (192.168.137.2:6002):
//   0..4  "EVCMD"
//   5     command   1  application mode    arg 0 原图 / 1 安防 / 2 质检 / 3 人脸
//                   2  key2 short press    arg ignored (the current mode's key2)
//                   3  standard part       arg 0 任意 / 1 标准件
//                   anything else is passed on; system_top ignores it
//   6     argument
//   7     XOR of bytes 0..6
// The command is taken on the clock its eighth byte arrives, if the first
// seven matched -- not when valid falls: for datagrams under 26 bytes
// uiudp_rx ends the payload by its own count, which includes the UDP header,
// so the clock valid falls is the vendor's business, not this module's.
// Wrong magic, a bad XOR or fewer than 8 bytes: dropped, silently.  Bytes after
// the eighth are ignored (Ethernet pads a short frame; a longer datagram is
// still one command).  The stack has already matched the board's IP address;
// the port is not checked (nothing else is ever sent to the board).
//
// I_clk is the stack's I_uclk, the 125 MHz eth_tx_clk its transmit side uses
// too.  A command crosses to the video clock as a toggle plus a held
// {cmd, arg} bus -- the way evs_aux_tx brings qc_rec the other way: the bus is
// written on the clock the toggle flips and does not change until the next
// command, at least one datagram time (microseconds) later, and the video side
// reads it only after the toggle has passed two flops.  The bus path is
// covered by the pclkx1 / eth_tx_clk clock group in timing.sdc.
//
// O_accept (Ethernet clock) lets evs_aux_tx send the next EVDBG1 status packet
// early, so the GUI sees the new mode at once instead of within a second.
module evs_cmd_rx (
    input  wire       I_clk,
    input  wire       I_reset,
    input  wire       I_rx_valid,     // uiudp_stack O_R_udp_valid
    input  wire [7:0] I_rx_data,      //             O_R_udp_data
    output reg        O_accept,       // Ethernet clock, one clock per command
    input  wire       I_video_clk,
    input  wire       I_video_rst_n,
    output reg        O_cmd_stb,      // video clock, one clock per command
    output reg  [7:0] O_cmd,          // video clock: the new value ON the strobe clock,
    output reg  [7:0] O_arg           //   held until the next command
);

function [7:0] magic;
    input [3:0] i;
    begin
        case (i)
            4'd0: magic = "E"; 4'd1: magic = "V"; 4'd2: magic = "C";
            4'd3: magic = "M"; 4'd4: magic = "D";
            default: magic = 8'd0;
        endcase
    end
endfunction

//--------------------------------------------------------------------------
// Ethernet clock: parse, then publish
//--------------------------------------------------------------------------
reg       rx_d;
reg [3:0] idx;        // index of the byte arriving now; saturates at 8
reg       ok;         // every byte so far as expected
reg [7:0] x;          // XOR of the bytes so far
reg [7:0] c_cmd, c_arg;
reg [7:0] h_cmd, h_arg;
reg       tog;

always @(posedge I_clk or posedge I_reset) begin
    if (I_reset) begin
        rx_d <= 1'b0;
        idx <= 4'd0;
        ok <= 1'b0;
        x <= 8'd0;
        c_cmd <= 8'd0;
        c_arg <= 8'd0;
        h_cmd <= 8'd0;
        h_arg <= 8'd0;
        tog <= 1'b0;
        O_accept <= 1'b0;
    end else begin
        rx_d <= I_rx_valid;
        O_accept <= 1'b0;
        if (I_rx_valid) begin
            // The first byte of a datagram is the clock valid rises.
            if (!rx_d) begin
                idx <= 4'd1;
                ok <= (I_rx_data == magic(4'd0));
                x <= I_rx_data;
            end else if (idx != 4'd8) begin
                idx <= idx + 1'b1;
                if (idx < 4'd5) ok <= ok && (I_rx_data == magic(idx));
                if (idx == 4'd5) c_cmd <= I_rx_data;
                if (idx == 4'd6) c_arg <= I_rx_data;
                if (idx < 4'd7) x <= x ^ I_rx_data;
                // idx 7: the XOR byte -- the command is complete on this clock
                if (idx == 4'd7 && ok && (I_rx_data == x)) begin
                    h_cmd <= c_cmd;
                    h_arg <= c_arg;
                    tog <= ~tog;
                    O_accept <= 1'b1;
                end
            end
        end else begin
            idx <= 4'd0;
            ok <= 1'b0;
        end
    end
end

//--------------------------------------------------------------------------
// video clock
//--------------------------------------------------------------------------
reg s1, s2, s3;

always @(posedge I_video_clk or negedge I_video_rst_n) begin
    if (!I_video_rst_n) begin
        s1 <= 1'b0;
        s2 <= 1'b0;
        s3 <= 1'b0;
        O_cmd_stb <= 1'b0;
        O_cmd <= 8'd0;
        O_arg <= 8'd0;
    end else begin
        s1 <= tog;
        s2 <= s1;
        s3 <= s2;
        O_cmd_stb <= s2 ^ s3;
        if (s2 ^ s3) begin
            O_cmd <= h_cmd;
            O_arg <= h_arg;
        end
    end
end

endmodule
