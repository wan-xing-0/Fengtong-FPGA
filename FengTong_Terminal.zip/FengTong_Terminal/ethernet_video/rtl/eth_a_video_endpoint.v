`timescale 1ns/1ps

// ETHA PHY/UDP endpoint for evs_video_tx_core. Keep this module independent
// from system_top: the image project only supplies final display RGB signals
// and, since 2026-10-04, the QC workpiece record (tie I_qc_trig low to omit).
// 2026-10-09: I_qc_trig also starts a full-resolution burst (evs_burst_ctrl),
// and in security mode (I_burst_timer_en) a burst every BURST_TIMER_VS frames
// is an alarm burst (I_alarm_level 2/3 with someone I_present) or a normal one
// (nobody present).  Both enables low = the 10-05 stream exactly.
// 2026-10-29: the reverse direction.  EVCMD datagrams from the PC come out as
// O_cmd_stb / O_cmd / O_arg on the video clock (evs_cmd_rx); the board's modes
// go back in every EVDBG1 status packet (I_ui_state, byte 11 bits 7:1):
//   [1:0] application mode 0 原图 / 1 安防 / 2 质检 / 3 人脸
//   [2]   standard part selected (质检)     [3] 安防 view: 1 single target
//   [4]   人脸 capture view                  [5] 人脸 debug view
//   [6]   staff verified (staff_pass)
// and I_sec_hold / I_staff_pass reach evs_burst_ctrl (staff verification).
// Tie the command outputs off and the new inputs low = the 10-09 behaviour.
module eth_a_video_endpoint #(
    parameter [47:0] LOCAL_MAC  = 48'h02_00_00_00_00_01,
    parameter [31:0] LOCAL_IP   = {8'd192, 8'd168, 8'd137, 8'd2},
    parameter [15:0] LOCAL_PORT = 16'd6002,
    parameter [31:0] DEST_IP    = {8'd192, 8'd168, 8'd137, 8'd1},
    parameter [15:0] DEST_PORT  = 16'd6001,
    parameter integer BURST_TIMER_VS    = 60,
    parameter integer BURST_QC_DELAY_VS = 2,
    parameter integer BURST_STAFF_DELAY_VS = 2,
    parameter        QC_V2             = 1'b1,     // 10-09: EVQC2 (qc_ext), see evs_aux_tx
    parameter [7:0]  QC_VER            = 8'd3      // 10-29: qc_ext layout 3 (system_top)
) (
    input  wire        I_clk_25m,
    output wire        O_eth_phy_rst_n,
    input  wire [3:0]  I_eth_rgmii_rxd,
    input  wire        I_eth_rgmii_rx_ctl,
    input  wire        I_eth_rgmii_rxc,
    output wire [3:0]  O_eth_rgmii_txd,
    output wire        O_eth_rgmii_tx_ctl,
    output wire        O_eth_rgmii_txc,
    input  wire        I_video_clk,
    input  wire        I_video_rst_n,
    input  wire        I_video_vs,
    input  wire        I_video_de,
    input  wire [23:0] I_video_rgb,
    input  wire        I_qc_trig,
    input  wire [127:0] I_qc_rec,
    input  wire [127:0] I_qc_ext,
    input  wire        I_burst_timer_en,
    input  wire [1:0]  I_alarm_level,
    input  wire        I_present,
    input  wire        I_sec_hold,
    input  wire        I_staff_pass,
    input  wire [6:0]  I_ui_state,
    output wire        O_cmd_stb,
    output wire [7:0]  O_cmd,
    output wire [7:0]  O_arg,
    output wire        O_video_frame_dropped,
    output wire        O_fifo_overflow,
    output wire        O_packetizer_error
);

wire pll_lock, clk_125, clk_125_90, clk_25, phy_ready;
wire net_reset = ~phy_ready;
wire gmii_tx_valid;
wire [7:0] gmii_tx_data;
wire gmii_rx_clk, gmii_rx_valid;
wire [7:0] gmii_rx_data;
wire udp_busy, udp_req, udp_valid;
wire [7:0] udp_data;
wire [15:0] udp_len;
wire video_udp_busy;
wire stack_udp_req, stack_udp_valid;
wire [7:0] stack_udp_data;
wire [15:0] stack_udp_len;
wire phy_link;
wire [31:0] video_debug_status;
wire [7:0] video_debug_counts;
wire [7:0] qc_sent;
wire rx_udp_valid;
wire [7:0] rx_udp_data;
wire cmd_accept;
reg [6:0] ui_meta, ui_eth;

eth_pll u_eth_pll (
    .refclk(I_clk_25m), .reset(1'b0), .lock(pll_lock),
    .clk0_out(clk_125), .clk1_out(clk_125_90), .clk2_out(clk_25)
);

uiphyrst #(.CLK_FREQ(32'd25_000_000)) u_phy_reset (
    .I_CLK(clk_25), .I_rstn(pll_lock), .I_phyrst(pll_lock),
    .O_phyrst(O_eth_phy_rst_n), .O_phyrst_done(phy_ready)
);

evs_video_tx_core #(
    .BURST_TIMER_VS(BURST_TIMER_VS), .BURST_QC_DELAY_VS(BURST_QC_DELAY_VS),
    .BURST_STAFF_DELAY_VS(BURST_STAFF_DELAY_VS)
) u_video_tx (
    .I_video_clk(I_video_clk), .I_video_rst_n(I_video_rst_n),
    .I_video_vs(I_video_vs), .I_video_de(I_video_de), .I_video_rgb(I_video_rgb),
    .I_qc_trig(I_qc_trig), .I_timer_en(I_burst_timer_en),
    .I_alarm_level(I_alarm_level), .I_present(I_present),
    .I_sec_hold(I_sec_hold), .I_staff_pass(I_staff_pass),
    .I_eth_clk(clk_125), .I_eth_reset(net_reset), .I_udp_busy(video_udp_busy),
    .O_udp_req(udp_req), .O_udp_valid(udp_valid), .O_udp_data(udp_data),
    .O_udp_len(udp_len), .O_video_frame_dropped(O_video_frame_dropped),
    .O_fifo_overflow(O_fifo_overflow), .O_packetizer_error(O_packetizer_error),
    .O_debug_status(video_debug_status), .O_debug_counts(video_debug_counts)
);

// The board's modes for EVDBG1 byte 11.  Quasi-static (they change on a key
// press or a command), so a plain two-flop synchronizer per bit is enough: a
// packet sent during the one clock bits disagree shows a mix once, and the
// next one is right.
always @(posedge clk_125 or posedge net_reset) begin
    if (net_reset) begin
        ui_meta <= 7'd0;
        ui_eth <= 7'd0;
    end else begin
        ui_meta <= I_ui_state;
        ui_eth <= ui_meta;
    end
end

evs_cmd_rx u_cmd_rx (
    .I_clk(clk_125), .I_reset(net_reset),
    .I_rx_valid(rx_udp_valid), .I_rx_data(rx_udp_data),
    .O_accept(cmd_accept),
    .I_video_clk(I_video_clk), .I_video_rst_n(I_video_rst_n),
    .O_cmd_stb(O_cmd_stb), .O_cmd(O_cmd), .O_arg(O_arg)
);

// The low-rate EVDBG1 status datagram and the EVQC1 workpiece record share
// the proven UDP endpoint with video.  EVDBG1 remains useful after bring-up:
// it identifies whether the display tap, sampler, FIFO or packetizer stopped
// without adding pins or applying backpressure to HDMI.  See evs_aux_tx.v for
// why the stack is handed back only once its busy has fallen.
evs_aux_tx #(.QC_V2(QC_V2), .QC_VER(QC_VER)) u_aux_tx (
    .I_clk(clk_125), .I_reset(net_reset),
    .I_udp_busy(udp_busy),
    .O_udp_req(stack_udp_req), .O_udp_valid(stack_udp_valid),
    .O_udp_data(stack_udp_data), .O_udp_len(stack_udp_len),
    .I_video_req(udp_req), .I_video_valid(udp_valid),
    .I_video_data(udp_data), .I_video_len(udp_len),
    .O_video_busy(video_udp_busy),
    .I_debug_status(video_debug_status), .I_debug_counts(video_debug_counts),
    .I_phy_link(phy_link), .I_ui_state(ui_eth), .I_diag_kick(cmd_accept),
    .I_video_clk(I_video_clk), .I_video_rst_n(I_video_rst_n),
    .I_qc_trig(I_qc_trig), .I_qc_rec(I_qc_rec), .I_qc_ext(I_qc_ext),
    .O_qc_sent(qc_sent)
);

uiudp_stack #(.CRC_GEN_EN(1'b1), .INTER_FRAME_GAP(4'd12)) u_udp_stack (
    .I_uclk(clk_125), .I_reset(net_reset),
    .I_mac_local_addr(LOCAL_MAC), .I_udp_local_port(LOCAL_PORT), .I_ip_local_addr(LOCAL_IP),
    .I_udp_dest_port(DEST_PORT), .I_ip_dest_addr(DEST_IP),
    .O_W_udp_busy(udp_busy), .I_W_udp_req(stack_udp_req), .I_W_udp_valid(stack_udp_valid),
    .I_W_udp_data(stack_udp_data), .I_W_udp_len(stack_udp_len),
    .O_R_udp_valid(rx_udp_valid), .O_R_udp_data(rx_udp_data), .O_R_udp_len(), .O_R_udp_src_port(),
    .I_gmii_rclk(gmii_rx_clk), .I_gmii_rvalid(gmii_rx_valid), .I_gmii_rdata(gmii_rx_data),
    .I_gmii_tclk(clk_125), .O_gmii_tvalid(gmii_tx_valid), .O_gmii_tdata(gmii_tx_data),
    .O_ip_rerror(), .O_mac_rerror()
);

rgmii_interface u_rgmii (
    .speed_10_100(1'b0), .gmii_tx_clk_d(clk_125), .gmii_tx_reset_d(net_reset),
    .gmii_tx_reset(net_reset), .gmii_tx_clk(clk_125), .gmii_txd(gmii_tx_data),
    .gmii_tx_en(gmii_tx_valid), .gmii_tx_er(), .gmii_rx_reset(net_reset),
    .gmii_rx_clk(gmii_rx_clk), .gmii_rxd(gmii_rx_data), .gmii_rx_dv(gmii_rx_valid),
    .gmii_rx_er(), .rgmii_txd(O_eth_rgmii_txd), .rgmii_tx_ctl(O_eth_rgmii_tx_ctl),
    .rgmii_txc(O_eth_rgmii_txc), .rgmii_rxd(I_eth_rgmii_rxd),
    .rgmii_rx_ctl(I_eth_rgmii_rx_ctl), .rgmii_rxc(I_eth_rgmii_rxc),
    .gmii_crs(), .gmii_col(), .link_status(phy_link), .clock_speed(), .duplex_status()
);

endmodule
