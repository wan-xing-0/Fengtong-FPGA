"""EVS1 UDP video receiver for Windows.

It accepts only complete RGB565 preview frames and always displays the newest
complete frame.  The module has no hardware dependency and its packet encoder
is intentionally available to the unit tests and later FPGA-vector tests.
"""
from __future__ import annotations

import argparse
import binascii
import functools
import socket
import struct
import sys
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from evs_status import board_state, describe_status, is_status
from fullres import (ALARM_SOURCES, SRC_NAMES, SRC_QC, SRC_STAFF, BurstAssembler,
                     PhaseZeroImage, parse_flags)
from qc_record import QcTracker, QcWriter, is_qc
from snapshots import (DEFAULT_JPEG_QUALITY, AlarmBuffer, IntervalPolicy, SecurityPolicy, Snapshot,
                       SnapshotWriter)
from win_tuning import end_tuning, raise_current_thread, tune_process

MAGIC = b"EVS1"
VERSION = 1
HEADER_SIZE = 32
TYPE_PREVIEW = 0
TYPE_STILL = 1
PIXEL_RGB565 = 1
HEADER = struct.Struct("!4sBBHIIHHHHBBHI")

# How often the OpenCV window is serviced when no frame is completing.  Only
# needs to be responsive to a keypress, not to the packet rate.
GUI_SERVICE_S = 0.05
# ~0.5 s of datagrams (a frame is ~1 MB, 60 frames/s).  8 MiB gave only 130 ms
# of slack (§1.1); Windows usually grants this much -- the startup line prints
# what was actually granted.
DEFAULT_RCVBUF = 32 << 20
# GIL hand-over interval.  The default 5 ms lets the display thread hold the
# interpreter for up to 5 ms at a time (~230 datagrams); 1 ms keeps the receive
# thread's turn short without measurable overhead.
SWITCH_INTERVAL_S = 0.001
# Corner thumbnail of the newest QC card on the live window.
QC_THUMB_W = 320
QC_THUMB_S = 5.0
DEFAULT_QC_RULES = Path(__file__).with_name("qc_rules.json")
WINDOW_NAME = "EVS1 FPGA Preview"
DEFAULT_VIEW_SCALE = 1.25
# The FPGA sends a security burst about every second in security mode, except
# during an unconfirmed level-1 motion (then none at all, for as long as it
# lasts).  No burst for this long = not in security mode, or an FPGA without
# bursts: the normal record falls back to single 960x540 frames.  Generous so
# a long level-1 spell does not flip the fallback on.
FULLRES_STALE_S = 30.0
# 2026-10-29 (user): the normal security record every 30 min, was 60 s.
DEFAULT_NORMAL_INTERVAL_S = 1800.0
# 2026-10-29 (user): alarm pictures closer together -- people walk fast.  They
# are live 960x540 frames now, so the interval is no longer tied to the FPGA's
# one burst a second.
DEFAULT_ALARM_INTERVAL_S = 0.3
# The FPGA sends an alarm burst about once a second while the alarm lasts and
# someone is there.  No burst this long after the last one = they left: the
# live pictures taken since are dropped (snapshots.AlarmBuffer).
ALARM_HOLD_S = 1.4


def _interval_text(seconds: float) -> str:
    if seconds >= 60 and seconds % 60 == 0:
        return f"{seconds / 60:g} 分钟"
    return f"{seconds:g} s "


@dataclass(frozen=True)
class PacketHeader:
    message_type: int
    session_id: int
    sequence: int
    packet_index: int
    packet_count: int
    width: int
    height: int
    pixel_format: int
    flags: int
    payload_length: int
    payload_crc32: int


@dataclass
class PartialFrame:
    header: PacketHeader
    packets: dict[int, bytes] = field(default_factory=dict)
    first_seen: float = field(default_factory=time.monotonic)

    def add(self, header: PacketHeader, payload: bytes) -> bool:
        if header.packet_index >= self.header.packet_count:
            return False
        if (header.packet_count, header.width, header.height, header.pixel_format) != (
            self.header.packet_count, self.header.width, self.header.height,
            self.header.pixel_format,
        ):
            return False
        self.packets.setdefault(header.packet_index, payload)
        return True

    def complete(self) -> bytes | None:
        if len(self.packets) != self.header.packet_count:
            return None
        data = b"".join(self.packets[i] for i in range(self.header.packet_count))
        if self.header.pixel_format == PIXEL_RGB565 and len(data) != self.header.width * self.header.height * 2:
            return None
        return data


@dataclass
class ReceiverStats:
    packets_ok: int = 0
    packets_bad: int = 0
    frames_complete: int = 0
    frames_dropped: int = 0
    status_packets: int = 0
    qc_packets: int = 0      # EVQC1 seen here, i.e. with QC capture switched off


def parse_datagram(datagram: bytes) -> tuple[PacketHeader, bytes] | None:
    if len(datagram) < HEADER_SIZE:
        return None
    magic, version, msg_type, header_len, session, seq, index, count, width, height, fmt, flags, length, crc = HEADER.unpack_from(datagram)
    if magic != MAGIC or version != VERSION or header_len != HEADER_SIZE:
        return None
    payload = datagram[HEADER_SIZE:]
    if not count or index >= count or length != len(payload):
        return None
    if (binascii.crc32(payload) & 0xFFFFFFFF) != crc:
        return None
    return PacketHeader(msg_type, session, seq, index, count, width, height, fmt, flags, length, crc), payload


def make_datagram(header: PacketHeader, payload: bytes) -> bytes:
    """Test helper and reference encoding for FPGA packet-vector generation."""
    crc = binascii.crc32(payload) & 0xFFFFFFFF
    return HEADER.pack(MAGIC, VERSION, header.message_type, HEADER_SIZE,
                       header.session_id, header.sequence, header.packet_index,
                       header.packet_count, header.width, header.height,
                       header.pixel_format, header.flags, len(payload), crc) + payload


class FrameReassembler:
    def __init__(self, timeout_s: float = 0.20) -> None:
        self.timeout_s = timeout_s
        self.frames: dict[tuple[int, int, int], PartialFrame] = {}
        self.stats = ReceiverStats()
        self.last_status: str | None = None
        # 2026-10-29: EVDBG1 byte 11 -> the board's modes (evs_status.BoardState)
        # for the control bar; written here, read by the display thread (one
        # reference assignment, no lock needed).
        self.board = None
        # 757 of every 758 packets belong to the same frame as the one before
        # it, and neither the expiry sweep nor the stale-partial sweep can
        # change state while the key is unchanged.  Remembering the last key
        # lets the common packet skip both O(n) scans -- see accept().
        self.last_key: tuple[int, int, int] | None = None
        # Newest EVS1 sequence seen in any packet; EVQC1 carries only the low
        # 16 bits of the frame it refers to and is extended against this.
        self.last_sequence: int | None = None

    def expire(self, now: float | None = None) -> None:
        now = time.monotonic() if now is None else now
        old = [key for key, frame in self.frames.items() if now - frame.first_seen > self.timeout_s]
        for key in old:
            del self.frames[key]
            self.stats.frames_dropped += 1

    def accept(self, datagram: bytes, now: float | None = None) -> tuple[PacketHeader, bytes] | None:
        # The FPGA's once-a-second EVDBG1 telemetry currently shares this
        # port with video.  Count it separately: treating it as a malformed
        # video packet is what made the 2026-09-21 board log show thousands
        # of "CRC errors" that were never video at all.
        if is_status(datagram):
            self.stats.status_packets += 1
            self.last_status = describe_status(datagram)
            self.board = board_state(datagram)
            return None
        # EVQC1 workpiece records (2026-10-04) share the port too.  The receive
        # thread normally hands them to QcTracker before they get here; this
        # only counts them when QC capture is off, so they are not "bad".
        if is_qc(datagram):
            self.stats.qc_packets += 1
            return None
        parsed = parse_datagram(datagram)
        if parsed is None:
            self.stats.packets_bad += 1
            return None
        header, payload = parsed
        self.stats.packets_ok += 1
        self.last_sequence = header.sequence
        now = time.monotonic() if now is None else now
        key = (header.message_type, header.session_id, header.sequence)

        # Both sweeps below are O(number of pending frames) and used to run on
        # every single packet.  The dict itself stays small (a new preview
        # sequence retires older partials), so this is a fixed per-packet cost
        # at ~46000 packets/s, not a growing one -- it does NOT by itself
        # explain the 10-40 fps episodes in the 2026-09-23 30-minute run.
        #
        # Neither sweep can change anything while the key is unchanged: expiry
        # is bounded by the frame timeout (still swept at least once per frame,
        # i.e. ~60x/s, plus on every socket timeout in run()), and no partial
        # frame can become "older than this sequence" without the sequence
        # itself changing.  So the 757-out-of-758 same-frame packets skip both.
        if key != self.last_key:
            self.last_key = key
            self.expire(now)
            # Preview is newest-frame-first: receiving a newer sequence
            # abandons older partial previews in the same session.
            if header.message_type == TYPE_PREVIEW:
                older = [k for k in self.frames
                         if k[0] == TYPE_PREVIEW and k[1] == header.session_id
                         and k[2] < header.sequence]
                for old_key in older:
                    del self.frames[old_key]
                    self.stats.frames_dropped += 1

        frame = self.frames.get(key)
        if frame is None:
            frame = self.frames[key] = PartialFrame(header=header, first_seen=now)
        if not frame.add(header, payload):
            self.stats.packets_bad += 1
            return None
        result = frame.complete()
        if result is None:
            return None
        del self.frames[key]
        # This key is gone, so let the next packet run a full sweep -- that
        # puts the expiry sweep on a once-per-frame cadence, which is what the
        # 200 ms timeout needs, without paying for it per packet.
        self.last_key = None
        self.stats.frames_complete += 1
        return header, result


def rgb565_to_bgr_reference(data: bytes, width: int, height: int):
    """Readable reference conversion, kept as the test oracle.

    Builds about ten 518400-element temporaries per frame, which at 60 fps is
    the single largest CPU cost in the receive loop -- see rgb565_to_bgr.
    """
    import numpy as np
    words = np.frombuffer(data, dtype=">u2").astype(np.uint16).reshape(height, width)
    r = ((words >> 11) & 0x1F) * 255 // 31
    g = ((words >> 5) & 0x3F) * 255 // 63
    b = (words & 0x1F) * 255 // 31
    return np.dstack((b, g, r)).astype(np.uint8)


@functools.lru_cache(maxsize=1)
def _rgb565_lut():
    """All 65536 RGB565 words run once through the reference -> (65536, 3)."""
    import numpy as np
    words = np.arange(65536, dtype=">u2").tobytes()
    return rgb565_to_bgr_reference(words, 256, 256).reshape(65536, 3)


def rgb565_to_bgr(data: bytes, width: int, height: int):
    """Table lookup, bit-identical to the reference by construction.

    Not cv2.COLOR_BGR5652BGR: OpenCV expands channels by plain left shift
    (5-bit max -> 248, not 255), up to 7 LSB darker than the v1.0 reference;
    test_rgb565_matches_reference caught exactly that.  The table is built
    from the reference itself, so it cannot drift, and each frame costs one
    gather instead of ten full-frame temporaries.
    """
    import numpy as np
    words = np.frombuffer(data, dtype=">u2")
    return _rgb565_lut()[words].reshape(height, width, 3)


class LatestFrame:
    """Single-slot mailbox between the receive and display threads.

    Holds only the newest complete frame.  Putting a frame while the previous
    one is still unread overwrites it and counts a display skip: the viewer is
    behind, so the older frame is stale anyway.  This is what decouples the
    two sides -- a slow display can only skip frames, it can never delay
    recvfrom() and make the kernel drop datagrams (ETHERNET_V1.md §15.2).
    """

    def __init__(self) -> None:
        self._cond = threading.Condition()
        self._item = None
        self.skipped = 0

    def put(self, item) -> None:
        with self._cond:
            if self._item is not None:
                self.skipped += 1
            self._item = item
            self._cond.notify()

    def get(self, timeout: float):
        """Newest frame, or None if nothing arrived within `timeout`."""
        with self._cond:
            if self._item is None:
                self._cond.wait(timeout)
            item, self._item = self._item, None
            return item


class ReceiveThread(threading.Thread):
    """recvfrom() + reassembly only; complete frames go to a LatestFrame.

    With QC capture on, EVQC1 records go to `qc_tracker` and every complete
    frame is offered to it too; the jobs it returns are only queued here --
    conversion, drawing and disk all happen on the QcWriter thread.

    With `bursts` (fullres.BurstAssembler) every complete frame is also
    offered there -- it must see all four phases, including the ones the
    display skips.  Finished QC bursts go to the tracker; finished timer
    bursts go to `timer_bursts` (a LatestFrame) for the display thread's
    snapshot policy.  Still no pixel work on this thread: a burst is four
    references to frames that were already reassembled.
    """

    def __init__(self, sock: socket.socket, reassembler: FrameReassembler,
                 slot: LatestFrame, qc_tracker: QcTracker | None = None,
                 qc_writer: QcWriter | None = None, bursts=None,
                 timer_bursts: LatestFrame | None = None) -> None:
        super().__init__(name="evs-receive", daemon=True)
        self.sock = sock
        self.reassembler = reassembler
        self.slot = slot
        self.qc_tracker = qc_tracker
        self.qc_writer = qc_writer
        self.bursts = bursts
        self.timer_bursts = timer_bursts
        self.stop_event = threading.Event()
        self.error: BaseException | None = None
        self.raised_priority = False
        self._timing_lock = threading.Lock()
        self._busy = 0.0
        self._worst_gap = 0.0

    def take_timing(self) -> tuple[float, float]:
        """(seconds spent in recv+reassembly, longest gap between two
        recvfrom() calls) since the previous call; resets both."""
        with self._timing_lock:
            result = (self._busy, self._worst_gap)
            self._busy = self._worst_gap = 0.0
        return result

    def run(self) -> None:
        self.raised_priority = raise_current_thread()
        tick = time.perf_counter()
        try:
            while not self.stop_event.is_set():
                t0 = time.perf_counter()
                gap = t0 - tick
                tick = t0
                try:
                    datagram, _peer = self.sock.recvfrom(2048)
                except TimeoutError:
                    self.reassembler.expire()
                    datagram = None
                qc = self.qc_tracker
                complete = None
                done_bursts = []
                if datagram is not None:
                    if qc is not None and is_qc(datagram):
                        for job in qc.on_datagram(datagram, self.reassembler.last_sequence):
                            self.qc_writer.submit(job)
                    else:
                        complete = self.reassembler.accept(datagram)
                if complete:
                    wall = time.time()
                    self.slot.put((complete[0], complete[1], wall))
                    h = complete[0]
                    if h.pixel_format == PIXEL_RGB565:
                        if self.bursts is not None:
                            done_bursts = self.bursts.on_frame(h, complete[1], wall)
                        if qc is not None:
                            for job in qc.on_frame(h.sequence, complete[1], h.width, h.height, wall):
                                self.qc_writer.submit(job)
                if self.bursts is not None and self.bursts.open:
                    done_bursts += self.bursts.sweep()
                for burst in done_bursts:
                    if burst.src == SRC_QC:
                        if qc is not None:
                            for job in qc.on_burst(burst):
                                self.qc_writer.submit(job)
                    elif self.timer_bursts is not None:
                        self.timer_bursts.put(burst)
                if qc is not None and qc.pending:
                    for job in qc.sweep():
                        self.qc_writer.submit(job)
                busy = time.perf_counter() - t0
                with self._timing_lock:
                    self._busy += busy
                    if gap > self._worst_gap:
                        self._worst_gap = gap
        except BaseException as exc:  # surfaced by the display loop
            self.error = exc


class Recorder:
    """--record-video / --record-dir, unchanged from v1.0 but out of the loop.

    Both run on the display thread: MP4 writing is optional and off in the
    stability runs, and TYPE_STILL messages are not sent by the v1.0 RTL.
    """

    def __init__(self, args: argparse.Namespace) -> None:
        self.video_path = args.record_video
        self.video_fps = args.record_fps
        self.still_dir = Path(args.record_dir) if args.record_dir else None
        if self.still_dir:
            self.still_dir.mkdir(parents=True, exist_ok=True)
        self.video_writer = None
        self.video_size = None

    def frame(self, header: PacketHeader, bgr) -> None:
        import cv2
        if self.video_path:
            size = (header.width, header.height)
            if self.video_writer is None or self.video_size != size:
                if self.video_writer is not None:
                    self.video_writer.release()
                self.video_size = size
                self.video_writer = cv2.VideoWriter(
                    self.video_path, cv2.VideoWriter_fourcc(*"mp4v"),
                    self.video_fps, size)
                if not self.video_writer.isOpened():
                    raise SystemExit("无法创建录像文件；请检查输出路径或 OpenCV 编码器。")
            self.video_writer.write(bgr)
        if self.still_dir and header.message_type == TYPE_STILL:
            cv2.imwrite(str(self.still_dir / f"still_{header.session_id:08x}_{header.sequence:08d}.png"), bgr)

    def close(self) -> None:
        if self.video_writer is not None:
            self.video_writer.release()
            self.video_writer = None


def run(args: argparse.Namespace) -> None:
    try:
        import cv2
        import numpy as np  # noqa: F401
    except ImportError as exc:
        raise SystemExit("请先执行：py -m pip install -r requirements.txt") from exc

    for line in tune_process():
        print(line)
    sys.setswitchinterval(SWITCH_INTERVAL_S)

    # 2026-10-29: relative --snapshot-dir / --qc-dir are taken next to this
    # script, as snapshot_server does, so the two agree whatever directory
    # PowerShell is in.
    here = Path(__file__).resolve().parent
    for name in ("snapshot_dir", "qc_dir"):
        value = getattr(args, name)
        if value and not Path(value).is_absolute():
            setattr(args, name, str(here / value))

    recorder = Recorder(args)
    snapshot_writer = None
    snapshot_policy = None
    security = None
    if args.snapshot_dir:
        snapshot_writer = SnapshotWriter(Path(args.snapshot_dir), args.snapshot_quality)
        if args.snapshot_interval > 0:
            snapshot_policy = IntervalPolicy(args.snapshot_interval)
        if not args.no_fullres:
            security = SecurityPolicy(args.alarm_interval,
                                      args.snapshot_interval if args.snapshot_interval > 0
                                      else float("inf"))
        print(f"存图：{Path(args.snapshot_dir).resolve()}，JPEG 质量 {args.snapshot_quality}；按 s 手动存一张。")
        if security:
            print(f"  安防模式（都是 960x540，和实时画面一样，不拼全分辨率）："
                  + ("异常报警存短视频" if args.alarm_mode == "video"
                     else f"报警期间每 {args.alarm_interval:g} s 存一张") + "；无人时正常记录"
                  + (f"每 {_interval_text(args.snapshot_interval)}一张" if snapshot_policy else "关闭")
                  + "，撞上报警则顺延到报警结束后；员工核验通过存一张员工记录"
                  "（核验中和通过后 FPGA 不发安防图）。")
        if snapshot_policy:
            print(f"  其他模式 / 旧 bit（无全分辨率）：每 {_interval_text(args.snapshot_interval)}存一张 960x540。")
    qc_tracker = qc_writer = qc_rules = None
    if not args.no_qc:
        try:
            import PIL  # noqa: F401
        except ImportError as exc:
            raise SystemExit("质检卡片需要 Pillow：py -m pip install -r requirements.txt"
                             "（或加 --no-qc 关闭质检存图）") from exc
        from qc_card import find_fonts, render_card
        from qc_rules import RulesFile, judge
        fonts = find_fonts(args.qc_font)
        if not fonts.found:
            print("警告：没找到中文字体（微软雅黑 / 黑体 / 宋体），卡片上的中文会显示成方框；"
                  "可用 --qc-font 指定 .ttf/.ttc 文件。")
        qc_rules = RulesFile(Path(args.qc_rules) if args.qc_rules else None)
        qc_tracker = QcTracker(frame_offset=args.qc_frame_offset,
                               wait_burst=not args.no_fullres)
        qc_writer = QcWriter(
            Path(args.qc_dir), rgb565_to_bgr,
            lambda bgr, rec, wall, verdict: render_card(bgr, rec, wall, verdict, fonts),
            lambda rec: judge(rec, qc_rules.refresh()),
            args.qc_quality)
        rules = qc_rules.rules
        print(f"质检存图：{Path(args.qc_dir).resolve()}，每个工件一张卡片 + 一张原图；"
              f"字体 {Path(fonts.regular).name if fonts.found else '无'}；"
              f"合格判定 {'开启' if rules.enabled and rules.checks else '预留（未开启）'}"
              + (f"；规则文件错误：{qc_rules.error}" if qc_rules.error else ""))
    thumb = None
    thumb_until = 0.0
    shown_since_print = 0
    reassembler = FrameReassembler(args.timeout_ms / 1000.0)
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    # A 960x540 frame is 758 datagrams of ~1400 bytes, just over 1 MB, and the
    # FPGA emits ~46000 datagrams per second.  The default receive buffer holds
    # about 45 of them, so anything that stalls this loop for more than a
    # millisecond makes the kernel drop the rest of the frame and no frame ever
    # completes.  Ask for several frames' worth of slack.
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, args.rcvbuf)
    except OSError as exc:
        print(f"警告：无法设置接收缓冲区：{exc}")
    actual_rcvbuf = sock.getsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF)
    try:
        sock.bind((args.bind, args.port))
    except PermissionError as exc:
        sock.close()
        end_tuning()
        # WinError 10013 on 6001 has so far always been an auto-start NI
        # service holding the port: NIDomainService (nidmsrv) or lkTimeSync
        # (lktsrv) -- ETHERNET_V1.md §15.5.
        raise SystemExit(
            f"无法绑定 UDP {args.port}：{exc}\n"
            f"  多半是端口被占用。查占用者：Get-NetUDPEndpoint -LocalPort {args.port}\n"
            "  已见过：nidmsrv → Stop-Service -Name NIDomainService；"
            "lktsrv → Stop-Service -Name lkTimeSync（管理员 PowerShell）") from None
    sock.settimeout(0.2)
    print(f"正在监听 UDP {args.bind}:{args.port}，按 q 退出。")
    print(f"接收缓冲区：请求 {args.rcvbuf} 字节，实际 {actual_rcvbuf} 字节"
          f"（约 {actual_rcvbuf // 1400} 个包）。")

    slot = LatestFrame()
    bursts = timer_bursts = None
    if not args.no_fullres:
        bursts = BurstAssembler()
        timer_bursts = LatestFrame()
        print("全分辨率：质检卡片、安防定时存图用 FPGA 的 4 帧换相位拼成 1920x1080"
              "（旧 bit 没有 burst 时自动退回 960x540）；--no-fullres 关闭。")
    receiver = ReceiveThread(sock, reassembler, slot, qc_tracker, qc_writer,
                             bursts, timer_bursts)
    receiver.start()
    print("收包线程已启动。")
    reported_priority = False

    # Resizable window, opened at --view-scale times the frame size on the
    # first frame; dragging an edge keeps the aspect ratio.  OpenCV does the
    # scaling on this thread inside imshow -- nothing new on the receive side.
    cv2.namedWindow(WINDOW_NAME, cv2.WINDOW_NORMAL | cv2.WINDOW_KEEPRATIO)
    window_sized = False
    held_since_print = 0
    last_timer_burst = float("-inf")
    alarm_buf = None
    clip_rec = clip_writer = None
    if security is not None and args.alarm_mode == "video":
        from clips import ClipRecorder, ClipWriter
        from sec_events import AlertLog
        clip_writer = ClipWriter(Path(args.snapshot_dir))
        # 11-01: the phone push / page banner must not wait for the video to finish
        alert_log = AlertLog(Path(args.snapshot_dir))
        clip_rec = ClipRecorder(clip_writer.submit, pre_s=args.clip_pre, post_s=args.clip_post,
                                max_s=args.clip_max, hold_s=ALARM_HOLD_S,
                                on_alarm_start=alert_log.add)
        print(f"  异常报警存短视频：报警前 {args.clip_pre:g} s + 报警全程 + 结束后 {args.clip_post:g} s，"
              f"每段最长 {args.clip_max:g} s，960x540 15 帧/秒（--alarm-mode stills 改回截图）。")
    elif security is not None:
        alarm_buf = AlarmBuffer(ALARM_HOLD_S)

    # 2026-10-29: mode buttons under the picture (evs_control); keys 1..5 too.
    control = None
    if not args.no_control:
        from evs_control import BOARD_ADDR, Commander, ControlBar
        try:
            import PIL  # noqa: F401
            from qc_card import find_fonts
            bar_fonts = find_fonts(args.qc_font)
            control = ControlBar(Commander((args.board_ip, BOARD_ADDR[1]), args.bind),
                                 bar_fonts.regular, bar_fonts.bold)
            cv2.setMouseCallback(WINDOW_NAME,
                                 lambda ev, x, y, _f, _p: control.on_mouse(ev, x, y))
            print(f"控制栏：点击画面下方按钮，或按 1 原图 / 2 安防 / 3 质检 / 5 = key2；"
                  f"命令发往 {args.board_ip}:{BOARD_ADDR[1]}（--no-control 关闭）。")
        except ImportError:
            print("控制栏需要 Pillow，已关闭（py -m pip install -r requirements.txt）。")
            control = None

    def show(img) -> None:
        if control is not None:
            control.update_state(reassembler.board)
            img = control.compose(img)
        cv2.imshow(WINDOW_NAME, img)

    last_print = time.monotonic()
    skipped_at_print = 0
    last_bgr = None
    last_header = None
    last_wall = 0.0
    # Display-side wall time since the last print.  The receive thread keeps
    # its own busy time and worst recvfrom() gap: at ~46 packets/ms that gap
    # is what overflows the socket buffer, so it is the number to watch.
    t_cvt = t_show = t_gui = 0.0
    try:
        while True:
            if receiver.error is not None:
                raise receiver.error
            item = slot.get(GUI_SERVICE_S)
            t1 = time.perf_counter()
            # Phases 1..3 of a burst are the picture shifted by one source
            # pixel: shown live, the OSD's one-pixel strokes would flicker in
            # and out.  Keep the previous view for those frames (the receive
            # thread already handed them to the burst assembler).
            if item is not None and bursts is not None:
                f = parse_flags(item[0].flags)
                if f.member and f.phase != 0:
                    held_since_print += 1
                    item = None
            if security is not None and timer_bursts is not None:
                burst = timer_bursts.get(0)
                if burst is not None:
                    last_timer_burst = time.monotonic()
                    alarm = burst.src in ALARM_SOURCES
                    # 2026-10-29: an alarm burst (one a second while it lasts)
                    # only says "alarm now"; the pictures are live frames held
                    # in alarm_buf until the next report confirms them.
                    confirmed = alarm_buf.on_burst(last_timer_burst, alarm, burst.src) \
                        if alarm_buf is not None else []
                    if burst.src == SRC_STAFF:
                        keep, event = security.decide_staff()
                    else:
                        keep, event = security.decide(last_timer_burst, alarm, burst.wall_time)
                    if clip_rec is not None:
                        # 11-01: alarms are clips; the burst only says "alarm now"
                        clip_rec.on_alarm(last_timer_burst, alarm, burst.src, event, burst.wall_time)
                        if alarm:
                            keep = False
                    own = None
                    if keep:
                        # Never stitched: see fullres.PhaseZeroImage.
                        own = Snapshot(
                            PhaseZeroImage(burst, rgb565_to_bgr), burst.wall_time,
                            burst.base_seq, burst.session, burst.src_name,
                            event, burst.src if alarm else None)
                    # in time order, so the index (and the page) reads right
                    for snap in sorted(confirmed + ([own] if own else []), key=lambda s: s.wall_time):
                        snapshot_writer.submit(snap)
            if alarm_buf is not None:
                alarm_buf.expire(time.monotonic())
            if item is not None and item[0].pixel_format == PIXEL_RGB565:
                header, image, wall = item
                if not window_sized:
                    window_sized = True
                    bar_h = 0
                    if control is not None:
                        from evs_control import BAR_H
                        bar_h = round(BAR_H * header.width / 960)
                    cv2.resizeWindow(WINDOW_NAME, round(header.width * args.view_scale),
                                     round((header.height + bar_h) * args.view_scale))
                bgr = rgb565_to_bgr(image, header.width, header.height)
                t2 = time.perf_counter()
                if qc_writer is not None:
                    notice = qc_writer.take_notice()
                    if notice is not None:
                        ch, cw = notice.card.shape[:2]
                        tw = min(QC_THUMB_W, header.width // 3)
                        thumb = cv2.resize(notice.card, (tw, ch * tw // cw),
                                           interpolation=cv2.INTER_AREA)
                        thumb_until = time.monotonic() + QC_THUMB_S
                if thumb is not None and time.monotonic() < thumb_until \
                        and thumb.shape[0] + 16 <= bgr.shape[0]:
                    # Draw on a copy: `bgr` may also be queued to the snapshot
                    # writer, which must get the clean frame.
                    view = bgr.copy()
                    th, tw = thumb.shape[:2]
                    x0 = view.shape[1] - tw - 8
                    view[8:8 + th, x0:x0 + tw] = thumb
                    cv2.rectangle(view, (x0 - 1, 7), (x0 + tw, 8 + th), (255, 255, 255), 1)
                    show(view)
                else:
                    show(bgr)
                t_show += time.perf_counter() - t2
                t_cvt += t2 - t1
                shown_since_print += 1
                last_bgr, last_header, last_wall = bgr, header, wall
                # 11-01: the alarm clip's frames (and its 3 s pre-roll ring)
                if clip_rec is not None:
                    clip_rec.on_frame(time.monotonic(), wall, bgr)
                # 2026-10-29: alarm pictures from the live stream, every
                # --alarm-interval s while the FPGA reports the alarm -- held
                # until the next report confirms them (snapshots.AlarmBuffer).
                # `bgr` is the clean frame (the thumbnail went on a copy).
                if alarm_buf is not None and alarm_buf.active(time.monotonic()):
                    keep, event = security.decide(time.monotonic(), True, wall)
                    if keep:
                        alarm_buf.add(Snapshot(bgr, wall, header.sequence,
                                               header.session_id, SRC_NAMES[alarm_buf.src],
                                               event, alarm_buf.src))
                # Half-resolution timed snapshots only while no timed burst is
                # coming in: an FPGA bit without bursts.  Inside security mode
                # the burst branch above takes the slot.  11-01 (user: 质检
                # pictures turned up as 正常记录): never outside security mode --
                # a 10-29 bit reports the mode (EVDBG1 byte 11); an old bit
                # reports 0 there, and is then taken as before.
                board = reassembler.board
                in_security = board is None or board.raw == 0 or board.mode == 1
                if snapshot_policy and in_security \
                        and time.monotonic() - last_timer_burst > FULLRES_STALE_S \
                        and snapshot_policy.should_capture(time.monotonic(), header.flags):
                    snapshot_writer.submit(Snapshot(bgr, wall, header.sequence,
                                                    header.session_id, snapshot_policy.trigger))
                recorder.frame(header, bgr)
            # waitKey(1) sleeps at least a millisecond; it now runs once per
            # shown frame or per GUI_SERVICE_S idle tick on this thread only,
            # so it no longer competes with recvfrom() at all (§4.2).
            t3 = time.perf_counter()
            key = cv2.waitKey(1) & 0xFF
            t_gui += time.perf_counter() - t3
            if key == ord("q"):
                break
            if control is not None and control.on_key(key):
                pass
            elif key == ord("s") and snapshot_writer and last_bgr is not None:
                snapshot_writer.submit(Snapshot(last_bgr, last_wall, last_header.sequence,
                                                last_header.session_id, "manual"))
            # No new frame for a while (board off, or a burst being held): the
            # bar still has to answer the mouse and show the new mode.
            if control is not None and item is None and last_bgr is not None \
                    and control.state is not reassembler.board:
                show(last_bgr)
            now = time.monotonic()
            if now - last_print >= 2:
                s = reassembler.stats
                elapsed = now - last_print
                t_rx, worst_gap = receiver.take_timing()
                skipped = slot.skipped - skipped_at_print
                skipped_at_print = slot.skipped
                # check_stability.py parses this line and the FPGA line right
                # after it -- keep both formats and their order.
                print(f"显示: {shown_since_print / elapsed:.1f} fps；包: 正确 {s.packets_ok}，错误 {s.packets_bad}，状态 {s.status_packets}；帧: 完成 {s.frames_complete}，丢弃 {s.frames_dropped}")
                # 板测验收要看的就是这一行：frame_sequence 和 done_count 必须持续
                # 增长，abort_count 应保持不变或极少增长。
                if reassembler.last_status:
                    print(f"  FPGA: {reassembler.last_status}")
                print(f"  耗时: 收包 {t_rx * 1000:.0f} ms，转换 {t_cvt * 1000:.0f} ms，"
                      f"显示 {t_show * 1000:.0f} ms，窗口 {t_gui * 1000:.0f} ms，"
                      f"收包最长间隔 {worst_gap * 1000:.1f} ms，显示跳帧 {skipped}"
                      f"（每 {elapsed:.1f} s）")
                if not reported_priority:
                    reported_priority = True
                    print("  收包线程优先级：" + ("HIGHEST" if receiver.raised_priority else "未提升"))
                if snapshot_writer:
                    w = snapshot_writer
                    print(f"  存图: 已存 {w.saved}，队列满丢弃 {w.dropped}，失败 {w.failed}"
                          + (f"（{w.last_error}）" if w.last_error else ""))
                if bursts is not None:
                    print(f"  全分辨率: 完整 {bursts.complete}，缺相位 {bursts.partial}，"
                          f"实时窗口略过的采集帧 {held_since_print}"
                          + (f"；安防报警事件 {security.events}，员工记录 {security.staff}"
                             + (f"，报警尾巴丢弃 {alarm_buf.dropped}" if alarm_buf is not None else "")
                             if security else ""))
                    held_since_print = 0
                if clip_writer is not None:
                    cw = clip_writer
                    print(f"  报警视频: 已存 {cw.saved} 段，编码 {cw.codec or '待定'}，"
                          f"丢帧 {cw.dropped}，失败 {cw.failed}"
                          + (f"（{cw.last_error}）" if cw.last_error else "")
                          + ("，录制中" if clip_rec.clip is not None else ""))
                if qc_writer:
                    q, w = qc_tracker.stats, qc_writer
                    # No "显示:" here: check_stability.py keys on that prefix.
                    print(f"  质检: 工件 {q.records}（包 {q.packets}，重复 {q.duplicates}，"
                          f"无效 {q.invalid}，坏包 {q.bad}），已存 {w.saved}，迟到 {q.late}，"
                          f"无帧 {q.unmatched}，全分辨率 {q.fullres}，半分辨率 {q.half}，"
                          f"队列满丢弃 {w.dropped}，失败 {w.failed}"
                          + (f"（{w.last_error}）" if w.last_error else "")
                          + (f"；规则文件错误：{qc_rules.error}" if qc_rules.error else ""))
                elif s.qc_packets:
                    print(f"  质检: 已关闭，忽略 EVQC1 包 {s.qc_packets} 个")
                t_cvt = t_show = t_gui = 0.0
                shown_since_print = 0
                last_print = now
    finally:
        receiver.stop_event.set()
        receiver.join(1.0)
        recorder.close()
        if clip_rec is not None:
            clip_rec.close()
            clip_writer.close()
            print(f"报警视频结束：共 {clip_writer.saved} 段。")
        if snapshot_writer:
            snapshot_writer.close()
            print(f"存图结束：共 {snapshot_writer.saved} 张。")
        if qc_writer:
            qc_writer.close()
            print(f"质检存图结束：共 {qc_writer.saved} 个工件"
                  + (f"，最后一张 {qc_writer.last_card_path}" if qc_writer.last_card_path else "")
                  + "。")
        sock.close()
        if control is not None:
            control.commander.close()
        cv2.destroyAllWindows()
        end_tuning()


def main() -> None:
    parser = argparse.ArgumentParser(description="EVS1 UDP 视频接收端")
    parser.add_argument("--bind", default="0.0.0.0", help="监听网卡地址")
    parser.add_argument("--port", type=int, default=6001, help="监听 UDP 端口")
    parser.add_argument("--timeout-ms", type=int, default=200, help="不完整帧超时")
    parser.add_argument("--rcvbuf", type=int, default=DEFAULT_RCVBUF,
                        help=f"内核接收缓冲区字节数，默认 {DEFAULT_RCVBUF}")
    parser.add_argument("--record-dir", help="still 图片保存目录；预览帧不落盘")
    parser.add_argument("--record-video", help="预览视频 MP4 输出路径，例如 record.mp4")
    parser.add_argument("--record-fps", type=float, default=30.0, help="录像文件写入帧率，默认 30")
    parser.add_argument("--snapshot-dir", help="定时存图目录，例如 captures；不给则不存图")
    parser.add_argument("--snapshot-interval", type=float, default=DEFAULT_NORMAL_INTERVAL_S,
                        help="正常记录间隔秒数（安防无人时 / 其他模式），默认 1800（30 分钟）；0 表示不存正常记录")
    parser.add_argument("--alarm-interval", type=float, default=DEFAULT_ALARM_INTERVAL_S,
                        help=f"--alarm-mode stills 时报警期间存图间隔秒数，默认 {DEFAULT_ALARM_INTERVAL_S:g}")
    parser.add_argument("--alarm-mode", choices=("video", "stills"), default="video",
                        help="异常报警存短视频（默认）或每隔 --alarm-interval 存一张截图")
    parser.add_argument("--clip-pre", type=float, default=3.0, help="报警视频：报警开始前保留秒数，默认 3")
    parser.add_argument("--clip-post", type=float, default=1.5, help="报警视频：报警结束后再录秒数，默认 1.5")
    parser.add_argument("--clip-max", type=float, default=30.0, help="报警视频：单段最长秒数，默认 30")
    parser.add_argument("--no-fullres", action="store_true",
                        help="不用 FPGA 的 4 帧换相位全分辨率：卡片和定时存图都用 960x540 单帧")
    parser.add_argument("--view-scale", type=float, default=DEFAULT_VIEW_SCALE,
                        help=f"实时窗口初始大小 = 画面 x 倍数，默认 {DEFAULT_VIEW_SCALE}；之后可拖动窗口边缘调整")
    parser.add_argument("--snapshot-quality", type=int, default=DEFAULT_JPEG_QUALITY,
                        help=f"JPEG 质量 1-100，默认 {DEFAULT_JPEG_QUALITY}")
    parser.add_argument("--qc-dir", default="captures/qc",
                        help="质检卡片目录，默认 captures/qc（按日期分子目录）")
    parser.add_argument("--no-qc", action="store_true", help="关闭质检存图（EVQC1 包被忽略）")
    parser.add_argument("--qc-rules", default=str(DEFAULT_QC_RULES),
                        help="合格判定规则 JSON，默认脚本旁的 qc_rules.json（enabled=false 即预留）")
    parser.add_argument("--qc-quality", type=int, default=DEFAULT_JPEG_QUALITY,
                        help=f"质检 JPEG 质量，默认 {DEFAULT_JPEG_QUALITY}")
    parser.add_argument("--qc-frame-offset", type=int, default=2,
                        help="取 FPGA 记录所指帧之后第几帧上卡片，默认 2")
    parser.add_argument("--qc-font", help="中文字体文件；默认自动找微软雅黑 / 黑体 / 宋体")
    parser.add_argument("--no-control", action="store_true",
                        help="不显示画面下方的模式切换按钮（旧 bit 没有这个功能）")
    parser.add_argument("--board-ip", default="192.168.137.2",
                        help="模式切换命令发往的板子地址，默认 192.168.137.2（端口 6002）")
    run(parser.parse_args())


if __name__ == "__main__":
    main()
