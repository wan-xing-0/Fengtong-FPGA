"""Pass/fail rules for the QC workpiece card (ETHERNET_V1.md §17).

Reserved for now: the shipped qc_rules.json has "enabled": false, so every
card shows the verdict slot as 预留 and nothing is judged.  The shape is fixed
so the image side can fill in nominal sizes later without touching code::

    {
      "enabled": true,
      "checks": {
        "length":    {"nominal": 26, "tol": 2},
        "width":     {"nominal": 49, "tol": 2},
        "thickness": {"nominal": 28, "tol": 1.5}
      }
    }

A dimension with no "nominal" is not checked.  The file is re-read whenever
its modification time changes, so tolerances can be tuned while the receiver
runs; a file that fails to parse keeps the last good rules and reports why.

2026-10-09, EVQC2 (record.ext): three more checks next to the dimensions --

    "surface": true      a surface defect (qc_defect) fails the part; a part
                         qc_defect did not see fails as 表面未检测
    "shape":   "圆形"    the voted shape must be this (null = not checked)
    "colour":  "红色"    the colour word must be this (null = not checked)

surface defaults to true.  A record from an EVQC1 bit has no ext: the
dimensions are judged as before, surface is skipped, and a shape / colour
rule fails it as 形状颜色无数据 rather than passing what was never measured.

2026-10-29, a layout-3 record (EVQC2 byte 5 = 3): the FPGA judges and the
card shows that verdict, so the card and the OSD's 判定 row cannot disagree.
任意 mode -> "none" (no verdict box at all); 标准件 -> qc_std's 合格 / 不合格,
or "measuring" if it had not judged yet.  The reasons are worked out here
from the same numbers qc_std used (qc_record.STD_PARTS, by the record's mode): each axis out of
tolerance, then 污渍.  qc_rules.json does not apply to layout 3.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

# Card labels and the QcRecord attribute each check reads.  长/宽/厚 = X/Y/Z
# as qc_thick defines them (X along the picture's x, Z = BASE - TOP).
DIMENSIONS = (
    ("length", "长", "x_mm"),
    ("width", "宽", "y_mm"),
    ("thickness", "厚", "z_mm"),
)


@dataclass(frozen=True)
class Check:
    nominal: float
    tol: float


@dataclass(frozen=True)
class Rules:
    enabled: bool = False
    checks: dict[str, Check] = field(default_factory=dict)
    surface: bool = True
    shape: "str | None" = None
    colour: "str | None" = None


@dataclass(frozen=True)
class Verdict:
    status: str                      # "disabled" | "pass" | "fail" | "none" | "measuring"
    failed: tuple[str, ...] = ()     # card labels of the failing dimensions

    @property
    def text(self) -> str:
        if self.status == "pass":
            return "合格"
        if self.status == "fail":
            return "不合格（" + "、".join(self.failed) + "）"
        if self.status == "measuring":
            return "测量中"
        if self.status == "none":
            return ""
        return "判定：预留"


def parse_rules(data: dict) -> Rules:
    if not isinstance(data, dict):
        raise ValueError("顶层必须是 JSON 对象")
    checks: dict[str, Check] = {}
    for key, _label, _attr in DIMENSIONS:
        spec = (data.get("checks") or {}).get(key)
        if not spec or spec.get("nominal") is None:
            continue
        tol = float(spec.get("tol", 0))
        if tol < 0:
            raise ValueError(f"{key}.tol 不能为负")
        checks[key] = Check(float(spec["nominal"]), tol)
    for key in ("shape", "colour"):
        if data.get(key) is not None and not isinstance(data.get(key), str):
            raise ValueError(f"{key} 必须是字符串或 null")
    return Rules(bool(data.get("enabled", False)), checks,
                 bool(data.get("surface", True)), data.get("shape"), data.get("colour"))


def judge_fpga(record) -> Verdict:
    """Layout 3: qc_std's verdict, with the reasons spelled out.

    10-31: the part is the record's own (方块 / 三棱柱, ext.std_part), and the
    reasons follow the OSD's 原因 row order: 颜色, 形状, then the size axes
    (长 / 宽 / 厚), then 污渍.  Colour / shape use qc_std's own rule: the
    colour class must be one of the part's, the shape class the part's."""
    ext = record.ext
    if not ext.std_mode:
        return Verdict("none")
    if not ext.std_valid:
        return Verdict("measuring")
    if ext.std_pass:
        return Verdict("pass")
    part = ext.std_part
    failed = []
    if ext.colour_valid and ext.colour_cls not in part["colours"]:
        failed.append("颜色")
    if ext.shape_valid and ext.shape != part["shape"]:
        failed.append("形状")
    for label, attr, key, tol in (("长", "x_mm", "x", "tol_xy"), ("宽", "y_mm", "y", "tol_xy"),
                                  ("厚", "z_mm", "z", "tol_z")):
        if abs(getattr(record, attr) - part[key]) > part[tol]:
            failed.append(label)
    if ext.defect:
        failed.append("污渍")
    # qc_std said 不合格 but the reason is not visible from here (a reading
    # that moved between its snapshot and the record): still 不合格.
    return Verdict("fail", tuple(failed) or ("见屏幕判定",))


def judge(record, rules: Rules) -> Verdict:
    ext = getattr(record, "ext", None)
    if ext is not None and getattr(ext, "layout", 2) >= 3:
        return judge_fpga(record)
    if not rules.enabled:
        return Verdict("disabled")
    ext = getattr(record, "ext", None)
    active = bool(rules.checks) or (ext is not None and (rules.surface or rules.shape or rules.colour))
    if not active:
        return Verdict("disabled")
    failed = [label for key, label, attr in DIMENSIONS
              if key in rules.checks
              and abs(getattr(record, attr) - rules.checks[key].nominal) > rules.checks[key].tol]
    if ext is None and (rules.shape or rules.colour):
        # An EVQC1 bit cannot show what the rules ask for; passing it would
        # certify a shape / colour nobody measured.
        failed.append("形状颜色无数据")
    if ext is not None:
        if rules.surface:
            if not ext.obj:
                failed.append("表面未检测")
            elif ext.defect:
                failed.append("表面")
        if rules.shape and ext.shape_name != rules.shape:
            failed.append("形状")
        if rules.colour and ext.colour_name != rules.colour:
            failed.append("颜色")
    return Verdict("fail", tuple(failed)) if failed else Verdict("pass")


class RulesFile:
    """Rules backed by a JSON file, reloaded when the file changes."""

    def __init__(self, path: Path | None) -> None:
        self.path = Path(path) if path else None
        self.rules = Rules()
        self.error: str | None = None
        self._mtime: float | None = None
        self.refresh()

    def refresh(self) -> Rules:
        if self.path is None:
            return self.rules
        try:
            mtime = self.path.stat().st_mtime
        except FileNotFoundError:
            self.rules, self._mtime, self.error = Rules(), None, None
            return self.rules
        if mtime != self._mtime:
            self._mtime = mtime
            try:
                self.rules = parse_rules(json.loads(self.path.read_text(encoding="utf-8")))
                self.error = None
            except (ValueError, TypeError, json.JSONDecodeError) as exc:
                self.error = f"{self.path.name}: {exc}（沿用上一次的规则）"
        return self.rules
