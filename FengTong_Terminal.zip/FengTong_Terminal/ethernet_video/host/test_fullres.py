import json
import socket
import tempfile
import time
import unittest
from pathlib import Path

import numpy as np

from evs_receiver import (FrameReassembler, LatestFrame, PacketHeader, PIXEL_RGB565,
                          ReceiveThread, TYPE_PREVIEW, make_datagram)
from fullres import (SRC_QC, SRC_TIMER, Burst, BurstAssembler, StitchedImage,
                     make_flags, parse_flags, stitch)
from qc_record import QcRecord, QcTracker, QcWriter, make_qc_datagram
from qc_rules import Verdict
from snapshots import SecurityPolicy, Snapshot, SnapshotWriter

W, H = 6, 4          # one phase frame; the stitched picture is 12 x 8


def raw_to_bgr(data, w, h):
    """Test stand-in for rgb565_to_bgr: frames carry BGR bytes directly."""
    return np.frombuffer(data, np.uint8).reshape(h, w, 3)


def full_picture():
    rng = np.random.default_rng(7)
    return rng.integers(0, 256, (2 * H, 2 * W, 3), dtype=np.uint8)


def phase_bytes(full, phase):
    return np.ascontiguousarray(full[phase >> 1::2, phase & 1::2]).tobytes()


def header(seq, flags, w=W, h=H, session=1):
    return PacketHeader(TYPE_PREVIEW, session, seq, 0, 1, w, h, PIXEL_RGB565, flags, 0, 0)


def rec_bytes(seq, x=26, y=49, z=28):
    r = (1 << 127) | (1 << 126) | (x << 104) | (y << 88) | (z << 72) \
        | (250 << 56) | (278 << 40) | (300 << 28) | (200 << 16) | (seq << 8)
    return r.to_bytes(16, "big")


class FlagsTest(unittest.TestCase):
    def test_layout_matches_rtl(self):
        """evs_burst_ctrl.v: {burst_id, src, phase, 1, 0}."""
        self.assertEqual(make_flags(phase=2, src=SRC_TIMER, burst_id=3), 0b11_01_10_10)
        f = parse_flags(0b11_01_10_10)
        self.assertEqual((f.member, f.phase, f.src, f.burst_id, f.x_odd, f.y_odd),
                         (True, 2, SRC_TIMER, 3, 0, 1))
        # tb_burst's log: d2 = id 3, source 1 (normal), phase 0.
        self.assertEqual(make_flags(0, 1, 3), 0xD2)

    def test_security_sources(self):
        from fullres import ALARM_SOURCES, SRC_NAMES
        self.assertEqual(SRC_NAMES[1], "normal")
        self.assertEqual((SRC_NAMES[2], SRC_NAMES[3]), ("alarm_face", "alarm_motion"))
        self.assertEqual(ALARM_SOURCES, (2, 3))

    def test_zero_is_a_plain_frame(self):
        self.assertFalse(parse_flags(0).member)


class StitchTest(unittest.TestCase):
    def burst(self, full, phases):
        b = Burst(1, 100, 1, SRC_QC, W, H, 0.0, 0.0)
        for p in phases:
            b.frames[p] = phase_bytes(full, p)
        return b

    def test_four_phases_rebuild_the_picture_exactly(self):
        full = full_picture()
        out, res, missing = stitch(self.burst(full, range(4)), raw_to_bgr)
        self.assertEqual((res, missing), ("full", []))
        self.assertTrue((out == full).all())

    def test_missing_phase_is_filled_from_its_row_neighbour(self):
        full = full_picture()
        out, res, missing = stitch(self.burst(full, (0, 1, 3)), raw_to_bgr)
        self.assertEqual((res, missing), ("partial", [2]))
        self.assertTrue((out[0::2] == full[0::2]).all())
        self.assertTrue((out[1::2, 1::2] == full[1::2, 1::2]).all())
        self.assertTrue((out[1::2, 0::2] == full[1::2, 1::2]).all())   # from phase 3

    def test_deferred_image_reports_resolution(self):
        full = full_picture()
        img = StitchedImage(self.burst(full, range(4)), raw_to_bgr)
        self.assertTrue((img() == full).all())
        self.assertEqual(img.resolution, "full")


class AssemblerTest(unittest.TestCase):
    def test_four_frames_make_one_burst(self):
        full, a = full_picture(), BurstAssembler()
        done = []
        for p in range(4):
            done += a.on_frame(header(200 + p, make_flags(p, SRC_TIMER, 1)),
                               phase_bytes(full, p), 10.0, now=1.0 + p * 0.016)
        self.assertEqual(len(done), 1)
        b = done[0]
        self.assertEqual((b.base_seq, b.src, b.burst_id, b.complete), (200, SRC_TIMER, 1, True))
        self.assertEqual(a.open, {})

    def test_plain_frames_are_ignored(self):
        a = BurstAssembler()
        self.assertEqual(a.on_frame(header(5, 0), b"", 0.0, now=0.0), [])
        self.assertEqual(a.open, {})

    def test_lost_phase_zero_still_groups_and_times_out(self):
        full, a = full_picture(), BurstAssembler(timeout_s=0.5)
        for p in (1, 2, 3):
            self.assertEqual(a.on_frame(header(300 + p, make_flags(p, SRC_QC, 2)),
                                        phase_bytes(full, p), 0.0, now=1.0), [])
        self.assertEqual(a.sweep(now=1.4), [])
        done = a.sweep(now=1.6)
        self.assertEqual(len(done), 1)
        self.assertEqual((done[0].base_seq, done[0].missing), (300, [0]))
        self.assertEqual(a.partial, 1)

    def test_two_bursts_with_the_same_id_do_not_mix(self):
        full, a = full_picture(), BurstAssembler()
        a.on_frame(header(10, make_flags(0, SRC_TIMER, 1)), phase_bytes(full, 0), 0.0, now=0.0)
        # Same id four bursts later (ids are 2 bits) -- different base.
        a.on_frame(header(250, make_flags(0, SRC_TIMER, 1)), phase_bytes(full, 0), 0.0, now=0.1)
        self.assertEqual(len(a.open), 2)


class QcBurstPairingTest(unittest.TestCase):
    def qc_burst(self, base, full=None):
        full = full_picture() if full is None else full
        b = Burst(1, base, 1, SRC_QC, W, H, 0.0, 123.0)
        for p in range(4):
            b.frames[p] = phase_bytes(full, p)
        return b

    def test_record_then_burst(self):
        t = QcTracker(wait_burst=True)
        self.assertEqual(t.on_datagram(make_qc_datagram(rec_bytes(4), 100), 100, now=1.0), [])
        jobs = t.on_burst(self.qc_burst(102), now=1.1)
        self.assertEqual(len(jobs), 1)
        self.assertEqual((jobs[0].match, jobs[0].frame_seq, t.stats.fullres), ("burst", 102, 1))
        self.assertEqual(t.pending, [])

    def test_burst_then_late_record_repeat(self):
        """First EVQC1 copy lost: the burst completes before the repeat arrives."""
        t = QcTracker(wait_burst=True)
        self.assertEqual(t.on_burst(self.qc_burst(102), now=1.0), [])
        jobs = t.on_datagram(make_qc_datagram(rec_bytes(4), 100, repeat=1), 103, now=1.05)
        self.assertEqual(len(jobs), 1)
        self.assertEqual(jobs[0].repeat, 1)

    def test_an_older_burst_is_not_this_workpiece(self):
        t = QcTracker(wait_burst=True)
        t.on_burst(self.qc_burst(50), now=1.0)                 # previous workpiece
        self.assertEqual(t.on_datagram(make_qc_datagram(rec_bytes(4), 100), 100, now=1.1), [])
        self.assertEqual(len(t.pending), 1)

    def test_no_burst_falls_back_to_the_half_resolution_frame(self):
        t = QcTracker(frame_offset=2, wait_burst=True, burst_wait_s=1.0)
        t.on_datagram(make_qc_datagram(rec_bytes(4), 100), 100, now=1.0)
        self.assertEqual(t.on_frame(101, b"a", 2, 1, 9.0), [])
        self.assertEqual(t.on_frame(102, b"target", 2, 1, 9.1), [])   # remembered only
        self.assertEqual(t.on_frame(103, b"later", 2, 1, 9.2), [])
        self.assertEqual(t.sweep(now=1.9), [])
        jobs = t.sweep(now=2.1)
        self.assertEqual((jobs[0].image, jobs[0].match, t.stats.half), (b"target", "ok", 1))

    def test_without_wait_burst_the_old_behaviour_is_kept(self):
        t = QcTracker(frame_offset=2)
        t.on_datagram(make_qc_datagram(rec_bytes(4), 100), 100, now=1.0)
        self.assertEqual(len(t.on_frame(102, b"c", 2, 1, 9.0)), 1)


class WritersTest(unittest.TestCase):
    def test_qc_writer_stitches_a_burst_job(self):
        full = full_picture()
        with tempfile.TemporaryDirectory() as tmp:
            writer = QcWriter(Path(tmp), raw_to_bgr,
                              lambda bgr, rec, wall, verdict: np.zeros(
                                  (bgr.shape[0] + 5, bgr.shape[1], 3), np.uint8),
                              lambda rec: Verdict("disabled"),
                              encoder=lambda img, q: b"J" + bytes(img.shape[0]))
            t = QcTracker(wait_burst=True)
            t.on_datagram(make_qc_datagram(rec_bytes(7), 100), 100, now=1.0)
            b = Burst(1, 101, 1, SRC_QC, W, H, 0.0, time.time())
            for p in range(4):
                b.frames[p] = phase_bytes(full, p)
            for job in t.on_burst(b, now=1.1):
                writer.submit(job)
            writer.close()
            self.assertEqual((writer.saved, writer.failed), (1, 0), writer.last_error)
            day = next(Path(tmp).iterdir())
            entry = json.loads((day / "index.jsonl").read_text(encoding="utf-8"))
            self.assertEqual((entry["resolution"], entry["missing_phases"]), ("full", []))
            self.assertEqual((entry["width"], entry["height"]), (2 * W, 2 * H + 5))

    def test_snapshot_writer_takes_a_deferred_stitch(self):
        full = full_picture()
        b = Burst(1, 400, 2, SRC_TIMER, W, H, 0.0, time.time())
        for p in (0, 1, 2):
            b.frames[p] = phase_bytes(full, p)
        with tempfile.TemporaryDirectory() as tmp:
            w = SnapshotWriter(Path(tmp), encoder=lambda img, q: b"J")
            w.submit(Snapshot(StitchedImage(b, raw_to_bgr), b.wall_time, 400, 1, "timer"))
            w.close()
            day = next(Path(tmp).iterdir())
            entry = json.loads((day / "index.jsonl").read_text(encoding="utf-8"))
            self.assertEqual((entry["resolution"], entry["missing_phases"]), ("partial", [3]))
            self.assertEqual((entry["width"], entry["height"]), (2 * W, 2 * H))


class ReceiveThreadBurstTest(unittest.TestCase):
    def test_timer_burst_reaches_the_slot_and_qc_burst_the_writer(self):
        # The reassembler only completes an RGB565 frame of exactly w*h*2
        # bytes, so this test sends real-sized payloads and a to_bgr that
        # ignores them; pixel exactness is StitchTest's job.
        rx = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        rx.bind(("127.0.0.1", 0))
        rx.settimeout(0.05)
        tx = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        with tempfile.TemporaryDirectory() as tmp:
            writer = QcWriter(Path(tmp), lambda d, w, h: np.zeros((h, w, 3), np.uint8),
                              lambda bgr, rec, wall, verdict: bgr,
                              lambda rec: Verdict("disabled"),
                              encoder=lambda img, q: b"J")
            tracker = QcTracker(wait_burst=True)
            timer_slot = LatestFrame()
            receiver = ReceiveThread(rx, FrameReassembler(), LatestFrame(), tracker, writer,
                                     BurstAssembler(), timer_slot)
            receiver.start()
            try:
                def send(seq, flags):
                    tx.sendto(make_datagram(header(seq, flags), bytes([seq % 256]) * (W * H * 2)),
                              rx.getsockname())
                    time.sleep(0.005)
                send(10, 0)
                for p in range(4):
                    send(11 + p, make_flags(p, SRC_TIMER, 1))
                tx.sendto(make_qc_datagram(rec_bytes(3), 15), rx.getsockname())
                time.sleep(0.02)
                send(15, 0)
                for p in range(4):
                    send(16 + p, make_flags(p, SRC_QC, 2))
                deadline = time.time() + 2
                while writer.saved < 1 and time.time() < deadline:
                    time.sleep(0.02)
                timed = timer_slot.get(0.5)
            finally:
                receiver.stop_event.set()
                receiver.join(1)
                writer.close()
                rx.close()
                tx.close()
            self.assertIsNotNone(timed)
            self.assertEqual((timed.base_seq, timed.complete), (11, True))
            self.assertEqual((writer.saved, tracker.stats.fullres), (1, 1), writer.last_error)


class SecurityPolicyTest(unittest.TestCase):
    WALL = time.mktime((2026, 10, 9, 15, 30, 12, 0, 0, -1))

    def test_every_alarm_burst_is_kept_and_grouped_into_one_event(self):
        p = SecurityPolicy(alarm_interval_s=1.0, normal_interval_s=60.0)
        got = [p.decide(10.0 + t, True, self.WALL + t) for t in (0.0, 0.98, 2.02, 2.95)]
        self.assertEqual([k for k, _ in got], [True, True, True, True])   # 1 s +- jitter
        self.assertEqual({e for _, e in got}, {"20261009_153012"})
        self.assertEqual(p.events, 1)

    def test_a_gap_starts_a_new_event(self):
        p = SecurityPolicy()
        _, e1 = p.decide(10.0, True, self.WALL)
        _, e2 = p.decide(17.5, True, self.WALL + 7.5)       # > 6 s later
        self.assertNotEqual(e1, e2)
        self.assertEqual(p.events, 2)

    def test_longer_alarm_interval_thins_the_pictures(self):
        p = SecurityPolicy(alarm_interval_s=3.0)
        keep = [p.decide(10.0 + t, True, self.WALL + t)[0] for t in range(7)]
        self.assertEqual(keep, [True, False, False, True, False, False, True])

    def test_normal_record_once_a_minute_and_postponed_by_an_alarm(self):
        p = SecurityPolicy(normal_interval_s=60.0)
        self.assertEqual(p.decide(0.0, False, self.WALL), (True, None))
        self.assertFalse(p.decide(30.0, False, self.WALL)[0])
        # 55..70 s: an alarm.  Normal bursts are not sent then; the minute
        # record that fell due at 60 s is taken by the first one after it.
        for t in range(55, 71):
            self.assertTrue(p.decide(float(t), True, self.WALL + t)[0])
        self.assertEqual(p.decide(71.0, False, self.WALL + 71), (True, None))
        self.assertFalse(p.decide(72.0, False, self.WALL + 72)[0])   # no catch-up burst
        self.assertTrue(p.decide(131.0, False, self.WALL + 131)[0])  # next minute


class CardScaleTest(unittest.TestCase):
    def test_full_resolution_card_is_the_same_card_twice_as_big(self):
        try:
            import PIL  # noqa: F401
        except ImportError:
            self.skipTest("Pillow not installed")
        from qc_card import BAR_HEIGHT, bar_height, find_fonts, render_card
        bgr = np.random.default_rng(3).integers(0, 256, (1080, 1920, 3), dtype=np.uint8)
        card = render_card(bgr, QcRecord.from_bytes(rec_bytes(12)), time.time(),
                           Verdict("disabled"), find_fonts())
        self.assertEqual(bar_height(1920), 2 * BAR_HEIGHT)
        self.assertEqual(card.shape, (1080 + 2 * BAR_HEIGHT, 1920, 3))
        self.assertTrue((card[:1080] == bgr).all())


if __name__ == "__main__":
    unittest.main()
