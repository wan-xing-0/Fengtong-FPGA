import unittest, io, zipfile, xml.etree.ElementTree as ET
import qc_stats
from test_1031 import qrec

class ExportTest(unittest.TestCase):
    def test_reconciliation_and_means(self):
        s = qc_stats.summary([qrec(1), qrec(2, verdict='fail', dev=(2,0,0)), qrec(3, part='any', verdict='none')])
        self.assertEqual(s['total'], s['pass'] + s['fail'])
        self.assertEqual((s['records_total'], s['unjudged']), (3,1))
        self.assertAlmostEqual(s['averages']['x_mm'], 182/3)
        self.assertEqual(s['averages']['dx'], 1)
    def test_workbook_dates_formulas_and_values(self):
        from qc_export import to_xlsx
        data = to_xlsx([qrec(1), qrec(2, day='20261101', time='2026-11-01T10:00:02.000')])
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            for n in z.namelist(): ET.fromstring(z.read(n))
            workbook=z.read('xl/workbook.xml').decode()
            self.assertIn('2026-10-31',workbook)
            self.assertIn('2026-11-01',workbook)
            sheet=z.read('xl/worksheets/sheet1.xml').decode()
            self.assertIn('AVERAGE(',sheet)
            self.assertIn('COUNTIF(',sheet)
            self.assertIn('2026-10-31 10:00:01.000',sheet)
    def test_empty(self):
        from qc_export import to_xlsx
        with zipfile.ZipFile(io.BytesIO(to_xlsx([]))) as z:
            ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
