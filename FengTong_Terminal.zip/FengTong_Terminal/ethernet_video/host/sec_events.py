"""安防事件时间线 + 报警推送（2026-10-31）。

时间线：监控抓拍 index.jsonl 的一行是一张图，报警时每 0.3 s 一张，直接列出来
一个人走过就是几十张。这里把「同类、前后间隔 < GAP_S」的图并成一个事件：

    alarm_face  陌生人（画面里有没核验的人脸）
    alarm_motion 人员入侵（有人形、没有人脸）
    staff       员工通过（绿框 PASS 那一张）
    manual      手动抓拍
  normal / timer（定时记录）不算事件。

报警推送：PushConfig 从 push.json 读（不存在 = 关闭）；Pusher 对每个新的报警
事件（陌生人 / 入侵）发一次，两次之间至少 min_interval_s。格式：

    json        POST {"title", "content", "time", "kind"}    （自建服务）
    serverchan  POST 表单 title / desp                       （Server酱，url 里带 SendKey）
    bark        POST {"title", "body"}                       （Bark，url 到 /<key> 为止）
    wecom       POST {"msgtype": "text", "text": {"content"}} （企业微信群机器人）

本文件不写任何真实地址或密钥：push.json 由使用者自己填，默认没有这个文件。

2026-11-01：报警改成存视频以后，index.jsonl 要等视频录完（报警结束再多录 1.5 s，
一段最长 30 s）才会多一行，推送和网页横幅会晚十几秒到半分钟。所以现在接收端在
**报警一开始**就往 ``<snapshot-dir>/<日期>/alerts.jsonl`` 追加一行（AlertLog.add），
网页服务读这个文件（AlertFeed.fresh）发推送和弹横幅。这天没有 alerts.jsonl（接收
端是旧版或截图模式）就退回读 index.jsonl，行为同 10-31。

测试推送（不用真的报警）：

    py -3.14 sec_events.py test            # 用本目录的 push.json
    py -3.14 sec_events.py test push.json   # 指定别的配置文件时写它的路径
"""
from __future__ import annotations

import json
import re
import sys
import threading
import time
import urllib.parse
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

GAP_S = 10.0
ALERT_FILE = "alerts.jsonl"
DAY_RE = re.compile(r"^\d{8}$")
EVENT_KINDS = {"alarm_face": "陌生人", "alarm_motion": "人员入侵", "staff": "员工通过", "manual": "手动抓拍"}
ALARM_KINDS = ("alarm_face", "alarm_motion")


def events(records: list[dict], gap_s: float = GAP_S) -> list[dict]:
    """Group pictures into events.  records: any order; result newest first."""
    pics = sorted((r for r in records if r.get("trigger") in EVENT_KINDS and "epoch" in r),
                  key=lambda r: r["epoch"])
    out: list[dict] = []
    for r in pics:
        k = r["trigger"]
        last = out[-1] if out else None
        if last is not None and last["kind"] == k and r["epoch"] - last["end_epoch"] < gap_s:
            last["end_epoch"] = r["epoch"]
            last["end"] = r.get("time", "")
            last["count"] += 1
            last["last_file"] = r["file"]
            last["last_day"] = r.get("day", "")
            if r.get("video"):                  # 11-01: alarm clips (clips.py)
                last["last_video"] = r["video"]
            continue
        out.append({"kind": k, "label": EVENT_KINDS[k], "alarm": k in ALARM_KINDS,
                    "start_epoch": r["epoch"], "end_epoch": r["epoch"],
                    "start": r.get("time", ""), "end": r.get("time", ""),
                    "count": 1, "day": r.get("day", ""), "file": r["file"],
                    "last_day": r.get("day", ""), "last_file": r["file"]})
        if r.get("video"):
            out[-1]["video"] = out[-1]["last_video"] = r["video"]
    return out[::-1]


def new_alarms(records: list[dict], since_epoch: float) -> list[dict]:
    """Alarm events that STARTED after since_epoch, oldest first."""
    return [e for e in events(records)[::-1] if e["alarm"] and e["start_epoch"] > since_epoch]


# ---------------------------------------------------------------------------
# push
# ---------------------------------------------------------------------------
FORMATS = ("json", "serverchan", "bark", "wecom")


@dataclass(frozen=True)
class PushConfig:
    enabled: bool = False
    url: str = ""
    format: str = "json"
    min_interval_s: float = 30.0
    title: str = "安防报警"

    @classmethod
    def load(cls, path: Path) -> "PushConfig":
        """Missing file = disabled.  A bad file raises ValueError (say so at start)."""
        path = Path(path)
        if not path.is_file():
            return cls()
        try:
            d = json.loads(path.read_text(encoding="utf-8"))
        except ValueError as exc:
            raise ValueError(f"{path} 不是合法 JSON：{exc}") from None
        if not isinstance(d, dict):
            raise ValueError(f"{path} 顶层必须是对象")
        fmt = d.get("format", "json")
        if fmt not in FORMATS:
            raise ValueError("format 只能是 " + " / ".join(FORMATS))
        url = str(d.get("url", "") or "")
        enabled = bool(d.get("enabled", False)) and bool(url)
        if url and not url.startswith(("http://", "https://")):
            raise ValueError("url 必须以 http:// 或 https:// 开头")
        return cls(enabled, url, fmt, float(d.get("min_interval_s", 30.0)),
                   str(d.get("title", "安防报警")))


def build_request(cfg: PushConfig, event: dict) -> tuple[str, bytes, dict]:
    """(url, body, headers) for one alarm event."""
    when = (event.get("start") or "").replace("T", " ")[:19]
    content = f"{event.get('label', '报警')}  {when}"
    if cfg.format == "serverchan":
        body = urllib.parse.urlencode({"title": cfg.title, "desp": content}).encode("utf-8")
        return cfg.url, body, {"Content-Type": "application/x-www-form-urlencoded; charset=utf-8"}
    if cfg.format == "bark":
        obj = {"title": cfg.title, "body": content}
    elif cfg.format == "wecom":
        obj = {"msgtype": "text", "text": {"content": f"{cfg.title}：{content}"}}
    else:
        obj = {"title": cfg.title, "content": content, "time": when, "kind": event.get("kind")}
    return cfg.url, json.dumps(obj, ensure_ascii=False).encode("utf-8"), \
        {"Content-Type": "application/json; charset=utf-8"}


def _http_post(url: str, body: bytes, headers: dict) -> None:
    req = urllib.request.Request(url, data=body, headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=5) as res:
        res.read()


class Pusher:
    """Sends at most one push per min_interval_s; never raises."""

    def __init__(self, cfg: PushConfig, post: Callable = _http_post,
                 clock: Callable[[], float] = time.monotonic) -> None:
        self.cfg = cfg
        self.post = post
        self.clock = clock
        self.last = None
        self.sent = 0
        self.skipped = 0
        self.last_error: str | None = None

    def notify(self, event: dict) -> bool:
        if not self.cfg.enabled:
            return False
        now = self.clock()
        if self.last is not None and now - self.last < self.cfg.min_interval_s:
            self.skipped += 1
            return False
        self.last = now
        try:
            self.post(*build_request(self.cfg, event))
            self.sent += 1
            self.last_error = None
            return True
        except Exception as exc:                      # a dead webhook must not stop the server
            self.last_error = f"{type(exc).__name__}: {exc}"
            return False


# ---------------------------------------------------------------------------
# alarm start notices (11-01): receiver writes, server reads
# ---------------------------------------------------------------------------
class AlertLog:
    """Receiver side.  add() appends one line the moment an alarm starts; it is
    called from the display thread, so it never raises and never blocks long."""

    def __init__(self, root: Path, clock: Callable[[], float] = time.time) -> None:
        self.root = Path(root)
        self.clock = clock
        self.count = 0
        self.last_error: str | None = None

    def add(self, kind: str, wall: float | None = None) -> bool:
        try:
            from datetime import datetime
            t = self.clock() if wall is None else wall
            d = datetime.fromtimestamp(t)
            day = self.root / d.strftime("%Y%m%d")
            day.mkdir(parents=True, exist_ok=True)
            line = {"epoch": round(t, 3), "time": d.isoformat(timespec="milliseconds"),
                    "trigger": kind, "label": EVENT_KINDS.get(kind, kind)}
            with open(day / ALERT_FILE, "a", encoding="utf-8") as f:
                f.write(json.dumps(line, ensure_ascii=False) + "\n")
            self.count += 1
            return True
        except Exception as exc:                      # a full disk must not stop the video
            self.last_error = f"{type(exc).__name__}: {exc}"
            return False


class AlertFeed:
    """Server side.  fresh(since) = alarm events that started after `since`,
    oldest first, from the newest day.  alerts.jsonl when that day has one,
    else the clip / snapshot index (cache.records) -- the 10-31 behaviour."""

    def __init__(self, root: Path, cache=None) -> None:
        self.root = Path(root)
        self.cache = cache
        self._lock = threading.Lock()
        self._days: dict[str, tuple[int, list[dict]]] = {}     # day -> (offset, rows)

    def _days_with_data(self) -> list[str]:
        days = set()
        if self.root.is_dir():
            days |= {p.name for p in self.root.iterdir() if p.is_dir() and DAY_RE.match(p.name)}
        if self.cache is not None:
            days |= set(self.cache.days())
        return sorted(days, reverse=True)

    def _alerts(self, day: str) -> list[dict] | None:
        path = self.root / day / ALERT_FILE
        with self._lock:
            try:
                size = path.stat().st_size
            except FileNotFoundError:
                self._days.pop(day, None)
                return None
            offset, rows = self._days.get(day, (0, []))
            if size < offset:
                offset, rows = 0, []
            if size > offset:
                with open(path, "rb") as f:
                    f.seek(offset)
                    chunk = f.read(size - offset)
                end = chunk.rfind(b"\n") + 1
                for line in chunk[:end].splitlines():
                    try:
                        r = json.loads(line)
                    except ValueError:
                        continue
                    if isinstance(r, dict) and r.get("trigger") in ALARM_KINDS and "epoch" in r:
                        rows.append(r)
                offset += end
            self._days[day] = (offset, rows)
            return rows

    def fresh(self, since: float) -> list[dict]:
        days = self._days_with_data()
        if not days:
            return []
        rows = self._alerts(days[0])
        if rows is None:
            if self.cache is None:
                return []
            return new_alarms(self.cache.records(days[0]), since)
        out = []
        for r in rows:
            if r["epoch"] > since:
                out.append({"kind": r["trigger"], "label": r.get("label") or EVENT_KINDS[r["trigger"]],
                            "alarm": True, "start_epoch": r["epoch"], "end_epoch": r["epoch"],
                            "start": r.get("time", ""), "end": r.get("time", ""), "count": 0,
                            "day": days[0], "file": "", "last_day": days[0], "last_file": ""})
        return out


class AlarmWatcher:
    """Background thread: every poll_s, new alarm events -> pusher.  `source` is
    an AlertFeed, or (10-31 form) any cache with days() / records(day)."""

    def __init__(self, source, pusher: Pusher, poll_s: float = 2.0) -> None:
        self.cache = source
        self.feed = source if hasattr(source, "fresh") else None
        self.pusher = pusher
        self.poll_s = poll_s
        self.since = time.time()        # nothing that happened before the server started
        self._stop = threading.Event()
        self.thread = threading.Thread(target=self._run, name="alarm-push", daemon=True)

    def check_once(self) -> int:
        if self.feed is not None:
            fresh = self.feed.fresh(self.since)
        else:
            days = self.cache.days()
            if not days:
                return 0
            fresh = new_alarms(self.cache.records(days[0]), self.since)
        for e in fresh:
            self.since = max(self.since, e["start_epoch"])
            self.pusher.notify(e)
        return len(fresh)

    def _run(self) -> None:
        while not self._stop.wait(self.poll_s):
            try:
                self.check_once()
            except Exception as exc:                  # keep watching
                self.pusher.last_error = f"{type(exc).__name__}: {exc}"

    def start(self) -> None:
        self.thread.start()

    def stop(self) -> None:
        self._stop.set()


def _main(argv: list[str]) -> int:
    """py sec_events.py test [push.json]: send one test message now."""
    if len(argv) < 2 or argv[1] != "test":
        print("用法：py -3.14 sec_events.py test [push.json]")
        return 2
    path = Path(argv[2]) if len(argv) > 2 else Path(__file__).with_name("push.json")
    try:
        cfg = PushConfig.load(path)
    except ValueError as exc:
        print(f"推送配置有误：{exc}")
        return 1
    if not cfg.enabled:
        print(f"{path} 里 enabled 不是 true，或者没有 url，所以什么也没发。")
        return 1
    ev = {"label": "测试", "start": time.strftime("%Y-%m-%dT%H:%M:%S"), "kind": "alarm_face"}
    pusher = Pusher(cfg, clock=lambda: 0.0)
    ok = pusher.notify(ev)
    print(f"已发送（{cfg.format}），手机应该很快收到" if ok else f"发送失败：{pusher.last_error}")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(_main(sys.argv))
