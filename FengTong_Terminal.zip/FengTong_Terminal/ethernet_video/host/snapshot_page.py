"""The single page snapshot_server.py serves (2026-10-29).

2026-10-31 (Anlogic_update): + 质检统计 (dashboard, SPC charts, CSV) and 事件时间线
(security pictures grouped into events), and a page-wide alarm banner with a
beep, vibration and a flashing title for every new alarm (polls /api/alerts;
the browser Notification API is not used -- it needs HTTPS).

2026-11-01: light only; alarms are clips (play mark, <video> viewer); 工件记录
splits into 标准件 | 任意工件, the 标准件 side card shows the 方块's drawing
(/std/image) and spec (/api/std).  The 三棱柱 is not offered (user, 11-01).

Two independent views on one page -- 监控抓拍 and 工件记录 -- each with its own
date, filter, latest picture and list, polled only while it is on screen.
Header: the contest logo (/brand/logo), the platform title, the team name and
the team logo (/brand/team); placeholders until the files exist.
Kept apart from the server so the markup can be changed without touching it.
"""

PAGE = r"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>监控抓拍 · 工件记录</title>
<style>
:root{
  --bg:#f3f4f6; --surface:#fff; --ink:#0f1726; --ink2:#3a4352; --muted:#7a8394; --line:#e5e7eb;
  --alarm:#d92d3a; --alarm-soft:#fdecee; --staff:#0f9d6b; --staff-soft:#e6f6ef;
  --normal:#5b6576; --normal-soft:#eef0f3;
  --shadow:0 1px 2px rgba(16,24,40,.04),0 6px 20px rgba(16,24,40,.06);
  --r:16px;
}
/* 11-01 (user): light only -- no dark variant, whatever the phone's setting */
:root{color-scheme:light}
*{box-sizing:border-box}
html,body{margin:0}
body{background:var(--bg);color:var(--ink);
  font:14px/1.55 -apple-system,"PingFang SC","HarmonyOS Sans SC","Microsoft YaHei",system-ui,sans-serif;
  -webkit-font-smoothing:antialiased}
.num{font-variant-numeric:tabular-nums}
button{font:inherit;color:inherit}

/* header */
header{position:sticky;top:0;z-index:20;background:var(--bg);border-bottom:1px solid var(--line)}
@supports (backdrop-filter:blur(1px)){header{background:color-mix(in srgb,var(--bg) 80%,transparent);backdrop-filter:saturate(1.5) blur(14px)}}
.hwrap,.tabs,main{max-width:1200px;margin:0 auto;padding-left:20px;padding-right:20px}
.hwrap{display:flex;align-items:center;gap:14px;padding-top:14px;padding-bottom:12px}
.logo{width:44px;height:44px;border-radius:12px;flex:none;display:grid;place-items:center;overflow:hidden;
  background:var(--surface);border:1px dashed var(--line);color:var(--muted);font-size:10px;letter-spacing:.12em}
.logo.has{border:none;background:transparent}
.logo img{width:100%;height:100%;object-fit:contain}
.brand{min-width:0;display:flex;align-items:center;gap:14px}
.brand h1{margin:0;font-size:17px;font-weight:700;letter-spacing:.02em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.brand p{margin:0;color:var(--muted);font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;
  border-left:1px solid var(--line);padding-left:14px}
.team{margin-left:auto;display:flex;align-items:center;gap:10px;flex:none}
.team .name{font-size:13px;color:var(--ink2);font-weight:600}
/* 11-01: the team's marks (brand/*.png, transparent) */
.mark{display:block;width:auto;flex:none}
.mark[hidden],.brand h1[hidden],.team .name[hidden]{display:none}
.mark.product{height:36px}
.mark.team{height:30px}
@media (max-width:560px){.mark.product{height:28px}.mark.team{height:22px}.brand p{display:none}}
.tabs{padding-bottom:12px}
.seg{display:inline-flex;gap:4px;padding:4px;border-radius:12px;background:var(--surface);border:1px solid var(--line)}
.seg button{border:0;background:transparent;cursor:pointer;padding:8px 20px;border-radius:9px;font-weight:600;color:var(--muted);transition:background .15s,color .15s}
.seg button.on{background:var(--ink);color:var(--surface)}

/* layout */
main{padding-top:20px;padding-bottom:60px}
.view[hidden]{display:none}
.hero{display:grid;grid-template-columns:minmax(0,1.75fr) minmax(0,1fr);gap:18px;align-items:start}
@media (max-width:860px){.hero{grid-template-columns:1fr}}
.card{background:var(--surface);border:1px solid var(--line);border-radius:var(--r);box-shadow:var(--shadow)}
.shot{position:relative;overflow:hidden;border-radius:var(--r);background:#0a0c10;aspect-ratio:16/9;cursor:zoom-in}
.shot img{width:100%;height:100%;object-fit:contain;display:block}
.view.qc .shot{aspect-ratio:auto;min-height:240px}
.view.qc .shot img{height:auto}
.overlay{position:absolute;left:0;right:0;bottom:0;padding:36px 16px 12px;display:flex;align-items:center;gap:10px;
  color:#fff;font-size:13px;background:linear-gradient(transparent,rgba(0,0,0,.62))}
.overlay[hidden]{display:none}
.blank{position:absolute;inset:0;display:grid;place-items:center;color:#7d8596;font-size:13px;padding:20px;text-align:center}
.blank[hidden]{display:none}
.side{padding:18px 18px 20px;display:flex;flex-direction:column;gap:16px}
.row{display:flex;align-items:center;gap:8px}
.label{margin:0;font-size:12px;font-weight:600;color:var(--muted);letter-spacing:.08em}
.live{margin-left:auto;display:inline-flex;align-items:center;gap:6px;font-size:12px;color:var(--muted)}
.dot{width:8px;height:8px;border-radius:50%;background:var(--muted)}
.dot.on{background:#22c55e;box-shadow:0 0 0 3px rgba(34,197,94,.18)}

/* filter tiles */
.tiles{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.tile{cursor:pointer;text-align:left;border:1px solid var(--line);background:var(--bg);border-radius:12px;
  padding:12px 14px 11px;display:flex;flex-direction:column;gap:1px;transition:border-color .15s,background .15s}
.tile:hover{border-color:var(--muted)}
.tile.on{border-color:var(--ink);background:var(--surface)}
.tile i{display:block;width:20px;height:3px;border-radius:2px;margin-bottom:8px}
.tile b{font-size:24px;font-weight:700;letter-spacing:-.01em;line-height:1.1}
.tile span{font-size:12px;color:var(--muted)}
.k-all i{background:var(--ink)} .k-alarm i,.k-fail i{background:var(--alarm)}
.k-staff i,.k-pass i{background:var(--staff)} .k-normal i,.k-none i{background:var(--normal)}

dl.kv{margin:0;display:grid;grid-template-columns:auto 1fr;gap:7px 16px;font-size:13px}
dl.kv dt{color:var(--muted)} dl.kv dd{margin:0;font-weight:600;word-break:break-all}

/* list */
.toolbar{display:flex;align-items:center;gap:10px;margin:30px 0 14px}
.toolbar h2{margin:0;font-size:15px;font-weight:700}
.toolbar .count{color:var(--muted);font-size:12px}
select{margin-left:auto;font:inherit;padding:7px 12px;border-radius:10px;border:1px solid var(--line);background:var(--surface);color:var(--ink)}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:14px}
@media (max-width:560px){.grid{grid-template-columns:1fr 1fr;gap:10px}}
.item{cursor:pointer;display:block;width:100%;padding:0;text-align:left;border:1px solid var(--line);background:var(--surface);
  border-radius:12px;overflow:hidden;transition:transform .15s,box-shadow .15s}
.item:hover{transform:translateY(-2px);box-shadow:var(--shadow)}
.thumb{aspect-ratio:16/9;background:#0a0c10}
.view.qc .thumb{aspect-ratio:16/11}
.thumb img{width:100%;height:100%;object-fit:cover;display:block}
.view.qc .thumb img{object-position:top}
.meta{padding:9px 12px;display:flex;align-items:center;gap:8px;font-size:12px;color:var(--muted);min-width:0}
.meta .cap{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.meta .t{margin-left:auto;flex:none}
.chip{display:inline-flex;align-items:center;gap:5px;padding:2px 9px;border-radius:999px;font-size:11.5px;font-weight:600;flex:none}
.chip::before{content:"";width:6px;height:6px;border-radius:50%;background:currentColor}
.c-alarm,.c-fail{color:var(--alarm);background:var(--alarm-soft)}
.c-staff,.c-pass{color:var(--staff);background:var(--staff-soft)}
.c-normal,.c-none,.c-manual{color:var(--normal);background:var(--normal-soft)}
.overlay .chip{color:#fff;background:rgba(255,255,255,.18)}
.more{display:block;margin:20px auto 0;padding:9px 24px;border-radius:10px;border:1px solid var(--line);background:var(--surface);cursor:pointer}
.more[hidden],.none[hidden]{display:none}
.none{color:var(--muted);text-align:center;padding:48px 0}

/* viewer */
.lb{position:fixed;inset:0;z-index:50;background:rgba(6,8,12,.88);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;padding:20px}
.lb[hidden]{display:none}
.lb img,.lb video{max-width:min(1280px,100%);max-height:80vh;border-radius:10px;box-shadow:0 20px 60px rgba(0,0,0,.5);background:#000}
.lb img[hidden],.lb video[hidden]{display:none}
/* 11-01: alarm clips -- a play mark and the length on the cover */
.thumb{position:relative}
.play,.shot.is-video::after{position:absolute;left:50%;top:50%;width:44px;height:44px;margin:-22px 0 0 -22px;
  border-radius:50%;background:rgba(15,23,38,.55);pointer-events:none}
.play::after,.shot.is-video::before{content:"";position:absolute;left:50%;top:50%;margin:-9px 0 0 -5px;
  border-style:solid;border-width:9px 0 9px 15px;border-color:transparent transparent transparent #fff;z-index:1}
.shot.is-video::after{content:"";width:64px;height:64px;margin:-32px 0 0 -32px}
.shot.is-video::before{margin:-13px 0 0 -7px;border-width:13px 0 13px 21px;z-index:2;pointer-events:none}
.dur{position:absolute;right:8px;bottom:8px;padding:1px 7px;border-radius:6px;font-size:11.5px;
  color:#fff;background:rgba(15,23,38,.6)}
.ev .evimg{position:relative;flex:none}
.ev .evimg img{display:block}
.lbbar{display:flex;align-items:center;gap:10px;flex-wrap:wrap;justify-content:center;color:#e8ebf1;font-size:13px}
.lbbar a,.lbbar button{border:0;border-radius:9px;padding:7px 16px;cursor:pointer;text-decoration:none;background:#fff;color:#0f1726;font-weight:600}
.lbbar button{background:rgba(255,255,255,.14);color:#fff}
footer{max-width:1200px;margin:0 auto;padding:8px 20px 32px;color:var(--muted);font-size:12px;
  display:flex;flex-direction:column;align-items:center;gap:12px;text-align:center}
/* 11-01: 工件记录's own 标准件 | 任意工件 switch, and the 标准件 side card */
#v-qc[hidden]{display:none}
.subtabs{margin:0 0 18px}
.seg.sub{background:var(--bg)}
.seg.sub button{padding:6px 16px;font-size:13px}
.seg.sub button.on{background:var(--surface);color:var(--ink);box-shadow:0 1px 3px rgba(16,24,40,.12)}
.tiles.t1{grid-template-columns:1fr}
.tiles.t3{grid-template-columns:repeat(3,1fr)}
.tiles.t3 .tile b{font-size:20px}
.stdimg{display:block;width:100%;aspect-ratio:4/3;object-fit:cover;border-radius:12px;background:#d4d8de}
.stdimg[hidden]{display:none}
/* 10-31: 质检统计 */
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:12px;margin-bottom:18px}
.stat{padding:14px 16px}
.stat b{display:block;font-size:26px;font-weight:700;line-height:1.15}
.stat span{font-size:12px;color:var(--muted)}
.stat.pass b{color:var(--staff)} .stat.fail b{color:var(--alarm)}
.panel{padding:16px 18px;margin-bottom:16px}
.panel h3{margin:0 0 12px;font-size:14px}
.bars{display:grid;gap:8px}
.bar{display:grid;grid-template-columns:44px 1fr 48px;align-items:center;gap:10px;font-size:13px}
.bar .track{height:12px;border-radius:6px;background:var(--bg);overflow:hidden}
.bar .fill{height:100%;background:var(--alarm);border-radius:6px}
.bar .v{text-align:right;color:var(--muted)}
.spc{display:grid;gap:14px}
.spc svg{width:100%;height:150px;display:block;background:var(--bg);border-radius:10px}
.spc .cap{font-size:12px;color:var(--muted);margin:0 0 4px}
.tools{display:flex;flex-wrap:wrap;align-items:center;gap:10px;margin:4px 0 16px}
.tools select{margin-left:0}
.btn{display:inline-block;padding:7px 16px;border-radius:10px;border:1px solid var(--line);background:var(--surface);
  color:var(--ink);text-decoration:none;font-weight:600;cursor:pointer}
.btn.dark{background:var(--ink);color:var(--surface);border-color:var(--ink)}
.fpga{font-size:12px;color:var(--muted)}

/* 10-31: 事件时间线 */
.tline{position:relative;margin-left:8px;padding-left:22px;border-left:2px solid var(--line)}
.ev{position:relative;display:flex;gap:12px;align-items:flex-start;margin:0 0 14px;padding:10px;cursor:pointer}
.ev::before{content:"";position:absolute;left:-30px;top:18px;width:12px;height:12px;border-radius:50%;
  background:var(--normal);border:2px solid var(--bg)}
.ev.alarm::before{background:var(--alarm)} .ev.staff::before{background:var(--staff)}
.ev img{width:132px;aspect-ratio:16/9;object-fit:cover;border-radius:8px;flex:none;background:#0a0c10}
.ev .body{min-width:0;display:flex;flex-direction:column;gap:4px;font-size:13px}
.ev .when{color:var(--muted);font-size:12px}
@media (max-width:560px){.ev img{width:104px}}

/* 10-31: alarm banner */
.alertbar{position:fixed;left:12px;right:12px;top:12px;z-index:60;display:flex;align-items:center;gap:12px;
  padding:12px 16px;border-radius:12px;background:var(--alarm);color:#fff;font-weight:700;
  box-shadow:0 12px 30px rgba(217,45,58,.4);animation:pulse 1s ease-in-out infinite alternate}
.alertbar[hidden]{display:none}
.alertbar img{width:72px;aspect-ratio:16/9;object-fit:cover;border-radius:6px}
.alertbar button{border:0;border-radius:8px;padding:6px 14px;background:rgba(255,255,255,.2);color:#fff;cursor:pointer}
#alertOpen{margin-left:auto}
@media (max-width:560px){.alertbar img{display:none}}
@keyframes pulse{from{opacity:1}to{opacity:.82}}
.sound{font-size:12px}
/* 10-31: four tabs must not widen the page on a phone */
.seg{max-width:100%;overflow-x:auto;-webkit-overflow-scrolling:touch}
.seg button{flex:none}
@media (max-width:560px){.seg button{padding:7px 11px;font-size:13px}}
.sponsors{display:flex;align-items:center;justify-content:center;flex-wrap:wrap;gap:12px 22px}
.sponsors[hidden]{display:none}
.sponsors span{letter-spacing:.08em}
.sponsors .mark{height:30px}
.sponsors .mark.contest{height:34px}
</style>
</head>
<body>
<header>
  <div class="hwrap">
    <div class="brand">
      <img class="mark product" id="m-product" alt="" hidden><h1 id="title">凤瞳</h1>
      <p id="subtitle"></p>
    </div>
    <div class="team"><img class="mark team" id="m-team" alt="" hidden><span class="name" id="team"></span></div>
  </div>
  <nav class="tabs"><div class="seg" id="tabs">
    <button data-v="sec" class="on">监控抓拍</button><button data-v="tl">事件时间线</button><button data-v="qc">工件记录</button><button data-v="st">质检统计</button>
  </div></nav>
</header>
<main>
  <section class="view sec" id="v-sec"></section>
  <section id="v-qc" hidden>
    <div class="subtabs"><div class="seg sub" id="subtabs">
      <button data-v="std" class="on">标准件</button><button data-v="any">任意工件</button>
    </div></div>
    <section class="view qc" id="v-qcstd" hidden></section>
    <section class="view qc" id="v-qcany" hidden></section>
  </section>
  <section class="view tl" id="v-tl" hidden></section>
  <section class="view st" id="v-st" hidden></section>
</main>
<footer>
  <div class="sponsors" id="sponsors" hidden>
    <span>赛题企业</span><img class="mark company" id="m-company" alt="" hidden>
    <img class="mark contest" id="m-contest" alt="" hidden>
  </div>
  <div id="foot"></div>
</footer>

<div class="alertbar" id="alertbar" hidden><img id="alertImg" alt=""><span id="alertText"></span>
  <button id="alertOpen">查看</button><button id="alertClose">知道了</button></div>
<div class="lb" id="lb" hidden>
  <img id="lbImg" alt="">
  <video id="lbVid" controls playsinline preload="metadata" hidden></video>
  <div class="lbbar"><span id="lbText"></span><a id="lbDl">下载</a><button id="lbClose">关闭</button></div>
</div>
<script>
const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const fmtDay = d => `${d.slice(0,4)}-${d.slice(4,6)}-${d.slice(6)}`;
const stamp = r => (r.time || "").replace("T", " ").slice(0, 19);
const hms = r => (r.time || "").slice(11, 19);
const ago = s => s < 60 ? `${Math.round(s)} 秒前` : s < 3600 ? `${Math.round(s/60)} 分钟前` : `${Math.round(s/3600)} 小时前`;
const no3 = r => "No." + String(r.qc_seq ?? "").padStart(3, "0");
const PAGE = 48, REFRESH_MS = 3000;

async function getJSON(url) {
  const res = await fetch(url, {cache: "no-store"});
  if (res.status === 401) throw Object.assign(new Error("口令失效（服务端重启过）：请重新打开启动时打印的完整链接（带 ?k=）"), {key: true});
  if (!res.ok) throw new Error("HTTP " + res.status);
  return res.json();
}

// ---- what each view knows about its records ------------------------------
const SEC = {
  src: "sec", heading: "抓拍记录", unit: "张",
  kinds: [["all", "全部"], ["alarm", "异常报警"], ["staff", "员工记录"], ["normal", "正常记录"]],
  names: {alarm: "异常报警", staff: "员工记录", normal: "正常记录", manual: "手动"},
  blank: "还没有抓拍 · 请确认接收端带了 --snapshot-dir",
  kindOf(r) {
    const t = r.trigger;
    return (t === "alarm_face" || t === "alarm_motion") ? "alarm" : (t === "staff" || t === "manual") ? t : "normal";
  },
  chip(r) { return this.names[this.kindOf(r)]; },
  caption(r) { return r.event ? "事件 " + r.event.slice(9, 15).replace(/(\d\d)(\d\d)(\d\d)/, "$1:$2:$3") : ""; },
  details(r) {
    const rows = [["时间", stamp(r)], ["类型", this.chip(r)]];
    if (r.level) rows.push(["报警", r.level === 2 ? "识别到人脸" : "运动未见人脸"]);
    if (r.event) rows.push(["事件", r.event.replace("_", " ")]);
    if (r.video) rows.push(["视频", `${r.duration ?? "—"} 秒`]);
    return rows;
  },
};
const QC_BASE = {
  src: "qc", heading: "工件卡片", unit: "件",
  names: {pass: "合格", fail: "不合格", none: "未判定"},
  kindOf(r) { return r.verdict === "pass" ? "pass" : r.verdict === "fail" ? "fail" : "none"; },
  caption(r) { return no3(r) + (r.shape ? " · " + r.shape : ""); },
  stainText(r) { return (r.layout === 3 ? r.stain : r.surface) || "—"; },
};
// 11-01 (user): 工件记录 = two views.  任意: no standard, just the record.
const QC_ANY = {...QC_BASE, mode: "any", heading: "任意工件记录",
  kinds: [["all", "今日记录"]],
  blank: "还没有任意工件记录 · 质检模式选「任意」，放上工件等屏幕显示「稳定」",
  chip() { return "任意"; },
  details(r) {
    return [["编号", no3(r)], ["时间", stamp(r)],
            ["尺寸", `${r.x_mm} × ${r.y_mm} × ${r.z_mm} mm`],
            ["形状", r.shape || "—"], ["颜色", r.colour || "—"], ["污渍", this.stainText(r)]];
  },
};
// 标准件: judged against the 方块 (11-01, user: the 三棱柱 is dropped from the
// PC side; the RTL still has it until the next synthesis).
const QC_STD = {...QC_BASE, mode: "standard", heading: "标准件检测记录",
  kinds: [["all", "全部"], ["pass", "合格"], ["fail", "不合格"]],
  blank: "还没有标准件记录 · 质检模式选「标准件」，放上工件等屏幕显示「稳定」",
  side: "std",
  chip(r) { return this.names[this.kindOf(r)] === "未判定" ? "测量中" : this.names[this.kindOf(r)]; },
  caption(r) { return no3(r) + " · " + ((r.std && r.std.name) || "标准件"); },
  details(r) {
    const k = this.kindOf(r);
    const dev = r.deviation_mm || {};
    const sgn = v => v === undefined ? "" : ` (${v > 0 ? "+" : v < 0 ? "−" : "±"}${Math.abs(v)})`;
    return [["编号", no3(r)], ["时间", stamp(r)], ["标准件", (r.std && r.std.name) || "标准件"],
            ["尺寸", `${r.x_mm}${sgn(dev.x)} × ${r.y_mm}${sgn(dev.y)} × ${r.z_mm}${sgn(dev.z)} mm`],
            ["形状", r.shape || "—"], ["颜色", r.colour || "—"], ["污渍", this.stainText(r)],
            ["判定", k === "none" ? "测量中" : this.names[k] + (r.failed && r.failed.length ? " · " + r.failed.join("、") : "")]];
  },
};
// The standard parts' spec texts (qc_rules / system_top: STD_COLOR_MASK*).
const STD_TEXT = {cube: {shape: "矩形（方块）", colour: "白色 / 灰色"}};

// ---- one view ------------------------------------------------------------
class View {
  constructor(cfg, root) {
    Object.assign(this, {c: cfg, root, day: "", kind: "all", offset: 0, total: 0,
                         shown: null, latest: null, active: false, started: false, busy: false});
    this.build();
  }
  api(path, q = "") { return `/api/${path}?src=${this.c.src}${this.c.mode ? "&mode=" + this.c.mode : ""}${q}`; }
  img(r, dl) { return `/img/${r.day}/${encodeURIComponent(r.file)}?src=${this.c.src}${dl ? "&dl=1" : ""}`; }
  vid(r, dl) { return `/vid/${r.day}/${encodeURIComponent(r.video)}?src=${this.c.src}${dl ? "&dl=1" : ""}`; }

  tilesHtml() {
    const ks = this.c.kinds;
    return `<div class="tiles t${ks.length}" data-r="tiles">${ks.map(([k, n]) =>
      `<button class="tile k-${k}${k === "all" ? " on" : ""}" data-k="${k}"><i></i><b class="num" data-n="${k}">0</b><span>${n}</span></button>`).join("")}</div>`;
  }

  sideHtml() {
    const live = `<span class="live"><span class="dot" data-r="dot"></span><span data-r="state">连接中</span></span>`;
    if (this.c.side === "std") return `
        <div class="card side">
          <div class="row"><p class="label">标准件规格</p>${live}</div>
          <img class="stdimg" data-r="stdimg" alt="标准件" hidden>
          <dl class="kv" data-r="spec"><dt>—</dt><dd></dd></dl>
          <p class="label">今日</p>
          ${this.tilesHtml()}
        </div>`;
    return `
        <div class="card side">
          <div class="row"><p class="label">今日概览</p>${live}</div>
          ${this.tilesHtml()}
          <p class="label">最新一条</p>
          <dl class="kv" data-r="kv"><dt>—</dt><dd></dd></dl>
        </div>`;
  }

  // 11-01: the side card shows the 方块 (the only part the PC offers).
  async loadStd(key) {
    try {
      if (!this.stdParts) this.stdParts = (await getJSON("/api/std")).parts;
      key = this.stdParts[key] ? key : "cube";
      if (key === this.stdKey) return;
      this.stdKey = key;
      const s = this.stdParts[key], t = STD_TEXT[key] || {};
      this.r.stdimg.hidden = !s.image;
      if (s.image) this.r.stdimg.src = "/std/image?part=" + key;
      this.r.spec.innerHTML = [
        ["名称", s.name],
        ["尺寸", `${s.x} × ${s.y} × ${s.z} mm`],
        ["长宽公差", `±${s.tol_xy} mm`],
        ["厚度公差", `±${s.tol_z} mm`],
        ["形状", t.shape || "—"],
        ["颜色", t.colour || "—"],
        ["表面", "有污渍即不合格"],
        ["材料", "3D 打印 PLA"],
      ].map(([a, b]) => `<dt>${esc(a)}</dt><dd>${esc(b)}</dd>`).join("");
    } catch (e) { /* stays empty */ }
  }

  build() {
    const c = this.c;
    this.root.innerHTML = `
      <div class="hero">
        <div class="card" style="padding:0">
          <div class="shot" data-r="shot"><img data-r="limg" alt="">
            <div class="blank" data-r="blank">连接中…</div>
            <div class="overlay" data-r="ov" hidden><span class="chip" data-r="lchip"></span><span class="num" data-r="ltime"></span></div>
          </div>
        </div>
        ${this.sideHtml()}
      </div>
      <div class="toolbar"><h2>${c.heading}</h2><span class="count num" data-r="count"></span>
        <select data-r="day" aria-label="日期"></select></div>
      <div class="grid" data-r="grid"></div>
      <div class="none" data-r="none" hidden>这一天还没有记录</div>
      <button class="more" data-r="more" hidden>加载更多</button>`;
    this.r = {};
    this.root.querySelectorAll("[data-r]").forEach(e => this.r[e.dataset.r] = e);
    if (c.side === "std") this.loadStd("cube");
    this.r.tiles.querySelectorAll(".tile").forEach(b => b.onclick = () => {
      this.kind = b.dataset.k;
      this.r.tiles.querySelectorAll(".tile").forEach(o => o.classList.toggle("on", o === b));
      this.load(true);
    });
    this.r.day.onchange = () => { this.day = this.r.day.value; this.load(true); this.stats(); };
    this.r.more.onclick = () => this.load(false);
    this.r.shot.onclick = () => { if (this.latest) openViewer(this, this.latest); };
  }

  async poll() {
    if (!this.active) return;
    try {
      const {latest} = await getJSON(this.api("latest"));
      this.latest = latest;
      if (!latest) {
        Object.assign(this.r.blank, {hidden: false, textContent: this.c.blank});
        this.r.ov.hidden = true; this.r.limg.removeAttribute("src");
        this.r.dot.className = "dot"; this.r.state.textContent = "暂无数据";
        return;
      }
      const age = Date.now() / 1000 - latest.epoch;
      this.r.dot.className = "dot" + (age < 5 ? " on" : "");
      this.r.state.textContent = age < 5 ? "实时" : ago(age);
      if (latest.file !== this.shown) {
        this.shown = latest.file;
        this.r.limg.src = this.img(latest);
        this.r.shot.classList.toggle("is-video", !!latest.video);
        this.r.blank.hidden = true; this.r.ov.hidden = false;
        this.r.lchip.className = "chip c-" + this.c.kindOf(latest);
        this.r.lchip.textContent = this.c.chip(latest);
        this.r.ltime.textContent = stamp(latest);
        if (this.r.kv)
          this.r.kv.innerHTML = this.c.details(latest).map(([a, b]) => `<dt>${esc(a)}</dt><dd>${esc(b)}</dd>`).join("");
      }
    } catch (e) {
      this.r.dot.className = "dot"; this.r.state.textContent = e.message;
      // 11-01: a restarted server has a new key -- say so where it is seen
      if (e.key) Object.assign(this.r.blank, {hidden: false, textContent: e.message});
    }
  }

  async days() {          // true if the day on screen changed
    const {days} = await getJSON(this.api("days"));
    const keep = this.day;
    this.r.day.innerHTML = days.map(d => `<option value="${d}">${fmtDay(d)}</option>`).join("");
    if (keep && days.includes(keep)) this.r.day.value = keep;
    else if (days.length) this.r.day.value = days[0];
    this.day = this.r.day.value || "";
    return this.day !== keep;
  }

  async stats() {
    if (!this.day) return;
    const {counts} = await getJSON(this.api("stats", `&day=${this.day}`));
    for (const [k] of this.c.kinds) {
      const e = this.r.tiles.querySelector(`[data-n="${k}"]`);
      if (e) e.textContent = counts[k] ?? 0;
    }
  }

  item(r) {
    const b = document.createElement("button");
    b.className = "item";
    b.innerHTML = `<div class="thumb"><img loading="lazy" alt="">${r.video
        ? `<span class="play"></span><span class="dur num">${r.duration ?? ""} s</span>` : ""}</div>
      <div class="meta"><span class="chip c-${this.c.kindOf(r)}"></span><span class="cap"></span><span class="t num"></span></div>`;
    b.querySelector("img").src = this.img(r);
    b.querySelector(".chip").textContent = this.c.chip(r);
    b.querySelector(".cap").textContent = this.c.caption(r);
    b.querySelector(".t").textContent = hms(r);
    b.onclick = () => openViewer(this, r);
    return b;
  }

  showCount() {
    this.r.count.textContent = `${this.total} ${this.c.unit}`;
    this.r.none.hidden = this.total > 0;
    this.r.more.hidden = this.offset >= this.total;
  }

  async load(reset) {
    if (!this.day) { this.r.grid.innerHTML = ""; this.r.none.hidden = false; this.r.more.hidden = true; return; }
    if (reset) { this.offset = 0; this.r.grid.innerHTML = ""; }
    const kind = this.kind;
    const d = await getJSON(this.api("index", `&day=${this.day}&kind=${kind}&offset=${this.offset}&limit=${PAGE}`));
    if (kind !== this.kind) return;
    this.total = d.total;
    const f = document.createDocumentFragment();
    d.records.forEach(r => f.appendChild(this.item(r)));
    this.r.grid.appendChild(f);
    this.offset += d.records.length;
    this.showCount();
  }

  // Every REFRESH_MS while on screen: a new day, new counts, and whatever
  // arrived for the day shown (newest first, so N new records shift every
  // position by N and 加载更多 continues where the grid ends).
  async refresh() {
    if (!this.active || this.busy) return;
    this.busy = true;
    try {
      const changed = await this.days();
      await this.stats();
      if (changed) { await this.load(true); return; }
      if (!this.day) return;
      const kind = this.kind;
      const d = await getJSON(this.api("index", `&day=${this.day}&kind=${kind}&offset=0&limit=${PAGE}`));
      if (kind !== this.kind) return;
      const added = d.total - this.total;
      if (added === 0) return;
      if (added < 0 || added > PAGE) { await this.load(true); return; }
      const f = document.createDocumentFragment();
      d.records.slice(0, added).forEach(r => f.appendChild(this.item(r)));
      this.r.grid.prepend(f);
      this.offset += added; this.total = d.total;
      this.showCount();
    } catch (e) { /* poll() reports a broken connection */ }
    finally { this.busy = false; }
  }

  async show(on) {
    this.active = on;
    this.root.hidden = !on;
    if (!on) return;
    this.poll();
    if (this.started) { this.refresh(); return; }
    this.started = true;
    try { await this.days(); await this.stats(); await this.load(true); }
    catch (e) { this.r.none.hidden = false; this.r.none.textContent = e.message; }
  }
}

// ---- viewer --------------------------------------------------------------
function openViewer(view, r) {
  const v = $("#lbVid"), i = $("#lbImg");
  if (r.video) {
    i.hidden = true; i.removeAttribute("src");
    v.hidden = false; v.poster = view.img(r); v.src = view.vid(r);
    v.play().catch(() => {});
    $("#lbDl").href = view.vid(r, true);
  } else {
    v.pause(); v.hidden = true; v.removeAttribute("src"); v.load();
    i.hidden = false; i.src = view.img(r);
    $("#lbDl").href = view.img(r, true);
  }
  const extra = view.c.src === "qc" ? view.c.details(r).filter(([a]) => a !== "时间" && a !== "编号")
                                        .map(([a, b]) => `${a} ${b}`).join("  ·  ") : "";
  $("#lbText").textContent = `${view.c.chip(r)}  ·  ${stamp(r)}` + (view.c.src === "qc" ? `  ·  ${no3(r)}  ·  ${extra}` : "");
  $("#lb").hidden = false;
}
const closeViewer = () => {
  $("#lb").hidden = true; $("#lbImg").removeAttribute("src");
  const v = $("#lbVid"); v.pause(); v.removeAttribute("src"); v.load();
};
$("#lbClose").onclick = closeViewer;
$("#lb").onclick = e => { if (e.target.id === "lb") closeViewer(); };
document.addEventListener("keydown", e => { if (e.key === "Escape") closeViewer(); });

// ---- brand ---------------------------------------------------------------
async function brand() {
  try {
    const b = await getJSON("/api/brand");
    $("#title").textContent = b.title;
    $("#subtitle").textContent = b.subtitle;
    $("#team").textContent = b.team;
    $("#foot").textContent = `${b.team} · ${b.title}`;
    document.title = `${b.title} · ${b.team}`;
    // 11-01: a mark replaces the text it stands for
    const show = (name, alt) => {
      if (!b[name + "_img"]) return false;
      const e = $("#m-" + name);
      e.src = "/brand/" + name; e.alt = alt; e.hidden = false;
      return true;
    };
    if (show("product", b.title)) $("#title").hidden = true;
    if (show("team", b.team)) $("#team").hidden = true;
    const c1 = show("company", "赛题企业"), c2 = show("contest", "赛事");
    $("#sponsors").hidden = !(c1 || c2);
  } catch (e) { /* the texts stay */ }
}


// ---- 10-31: 质检统计 -------------------------------------------------------
const PARTS = [["all", "全部"], ["any", "任意"], ["cube", "标准件"]];   // 11-01: 三棱柱 dropped
const REASONS = ["颜色", "形状", "尺寸", "污渍", "其他"];
function spcSvg(series, key, tol, W = 600) {   // W = the box width in px: no stretching
  const H = 150, P = 18;
  const pts = series.filter(p => typeof p[key] === "number");
  if (!pts.length) return `<svg viewBox="0 0 ${W} ${H}"><text x="${W/2}" y="${H/2}" text-anchor="middle" fill="currentColor" opacity=".5" font-size="13">还没有标准件记录</text></svg>`;
  const t = tol ?? 5;
  const lim = Math.max(t * 2, ...pts.map(p => Math.abs(p[key]))) * 1.1;
  const y = v => P + (H - 2 * P) * (1 - (v + lim) / (2 * lim));
  const x = i => P + (W - 2 * P) * (pts.length === 1 ? 0.5 : i / (pts.length - 1));
  const band = `<rect x="${P}" y="${y(t)}" width="${W - 2*P}" height="${y(-t) - y(t)}" fill="var(--staff)" opacity=".10"/>`
    + `<line x1="${P}" x2="${W-P}" y1="${y(t)}" y2="${y(t)}" stroke="var(--staff)" stroke-dasharray="4 4"/>`
    + `<line x1="${P}" x2="${W-P}" y1="${y(-t)}" y2="${y(-t)}" stroke="var(--staff)" stroke-dasharray="4 4"/>`
    + `<line x1="${P}" x2="${W-P}" y1="${y(0)}" y2="${y(0)}" stroke="currentColor" opacity=".25"/>`;
  const line = `<polyline fill="none" stroke="var(--ink2)" stroke-width="1.5" points="${pts.map((p, i) => `${x(i)},${y(p[key])}`).join(" ")}"/>`;
  const dots = pts.map((p, i) => `<circle cx="${x(i)}" cy="${y(p[key])}" r="3.2" fill="${Math.abs(p[key]) > t ? "var(--alarm)" : "var(--staff)"}"><title>#${p.n} ${p.time.slice(11,19)} ${p[key] > 0 ? "+" : ""}${p[key]} mm</title></circle>`).join("");
  const lab = `<text x="${W-P}" y="${y(t) - 4}" text-anchor="end" font-size="11" fill="var(--staff)">+${t}</text><text x="${W-P}" y="${y(-t) + 12}" text-anchor="end" font-size="11" fill="var(--staff)">-${t}</text>`;
  return `<svg viewBox="0 0 ${W} ${H}">${band}${line}${dots}${lab}</svg>`;
}
const STATS = {
  root: $("#v-st"), active: false, started: false, day: "all", part: "all",
  build() {
    this.root.innerHTML = `
      <div class="tools">
        <select data-r="day" aria-label="日期"></select>
        <select data-r="part" aria-label="标准件">${PARTS.map(([k, n]) => `<option value="${k}">${n}</option>`).join("")}</select>
        <a class="btn dark" data-r="xlsx">导出 Excel（按日分表）</a><a class="btn" data-r="csv">导出 CSV</a>
        <span class="fpga" data-r="fpga"></span>
      </div>
      <div class="stats">
        <div class="card stat"><b class="num" data-r="total">0</b><span>已检件数</span></div>
        <div class="card stat pass"><b class="num" data-r="pass">0</b><span>合格</span></div>
        <div class="card stat fail"><b class="num" data-r="fail">0</b><span>不合格</span></div>
        <div class="card stat"><b class="num" data-r="rate">—</b><span>合格率（已判定）</span></div>
      </div>
      <p class="cap" data-r="scope"></p>
      <div class="card panel"><h3>平均尺寸与偏差（mm，按当前筛选自动刷新）</h3><div class="stats" data-r="means"></div></div>
      <div class="card panel"><h3>不合格原因（一件可有多个原因）</h3><div class="bars" data-r="bars"></div></div>
      <div class="card panel"><h3>尺寸偏差趋势（实测 − 标称，绿带 = 公差）</h3><div class="spc" data-r="spc"></div></div>`;
    this.r = {};
    this.root.querySelectorAll("[data-r]").forEach(e => this.r[e.dataset.r] = e);
    this.r.day.onchange = () => { this.day = this.r.day.value; this.refresh(); };
    this.r.part.onchange = () => { this.part = this.r.part.value; this.refresh(); };
  },
  async days() {
    const {days} = await getJSON("/api/days?src=qc");
    const keep = this.day;
    this.r.day.innerHTML = `<option value="all">全部日期</option>` + days.map(d => `<option value="${d}">${fmtDay(d)}</option>`).join("");
    this.r.day.value = [...this.r.day.options].some(o => o.value === keep) ? keep : "all";
    this.day = this.r.day.value;
  },
  async refresh() {
    if (!this.active) return;
    try {
      const request = this.request = (this.request || 0) + 1;
      const q = `day=${this.day}&part=${this.part}`;
      const s = await getJSON(`/api/qcstats?${q}`);
      if (request !== this.request || q !== `day=${this.day}&part=${this.part}`) return;
      this.r.xlsx.href = `/api/qcxlsx?${q}`;
      this.r.csv.href = `/api/qccsv?${q}`;
      this.r.total.textContent = s.total;
      this.r.scope.textContent = `记录总数 ${s.records_total}；已检 ${s.total} = 合格 ${s.pass} + 不合格 ${s.fail}；未判定 ${s.unjudged}（任意件或尚无有效判定）。更新于 ${new Date().toLocaleTimeString()}`;
      this.r.means.innerHTML = [["x_mm","平均长"],["y_mm","平均宽"],["z_mm","平均厚"],["dx","平均长偏差"],["dy","平均宽偏差"],["dz","平均厚偏差"]].map(([k,n]) => `<div class="stat"><b class="num">${s.averages[k] == null ? "—" : s.averages[k].toFixed(2)}</b><span>${n}</span></div>`).join("");
      this.r.pass.textContent = s.pass;
      this.r.fail.textContent = s.fail;
      this.r.rate.textContent = s.pass_rate == null ? "—" : (s.pass_rate * 100).toFixed(1) + "%";
      const max = Math.max(1, ...REASONS.map(k => s.reasons[k] || 0));
      this.r.bars.innerHTML = REASONS.map(k => `<div class="bar"><span>${k}</span><div class="track"><div class="fill" style="width:${100 * (s.reasons[k] || 0) / max}%"></div></div><span class="v num">${s.reasons[k] || 0}</span></div>`).join("");
      const tol = s.tol || {xy: 3, z: 5};
      this.r.spc.innerHTML = [["x", "长", tol.xy], ["y", "宽", tol.xy], ["z", "厚", tol.z]]
        .map(([k, n, t]) => `<div><p class="cap">${n}（公差 ±${t} mm）</p>${spcSvg(s.series, k, t, Math.max(300, this.r.spc.clientWidth || 600))}</div>`).join("");
      this.r.fpga.textContent = s.fpga ? `FPGA 计数（板上本批）：已检 ${s.fpga.count}，合格 ${s.fpga.pass}` : "";
    } catch (e) { this.r.fpga.textContent = e.message; }
  },
  async show(on) {
    this.active = on; this.root.hidden = !on;
    if (!on) return;
    if (!this.started) { this.started = true; this.build(); }
    try { await this.days(); } catch (e) {}
    this.refresh();
  },
  async poll() {
    if (!this.active || this.polling) return;
    this.polling = true;
    try { await this.days(); await this.refresh(); }
    catch (e) { this.r.fpga.textContent = e.message; }
    finally { this.polling = false; }
  },
};

// ---- 10-31: 事件时间线 -----------------------------------------------------
const evImg = (e, last) => `/img/${last ? e.last_day : e.day}/${encodeURIComponent(last ? e.last_file : e.file)}?src=sec`;
const span = e => { const a = e.start.slice(11, 19), b = e.end.slice(11, 19); return a === b ? a : `${a} – ${b}`; };
const evChip = e => e.alarm ? "c-alarm" : e.kind === "staff" ? "c-staff" : "c-normal";
const TL = {
  root: $("#v-tl"), active: false, started: false, day: null, shown: 0, total: 0,
  build() {
    this.root.innerHTML = `
      <div class="tools"><select data-r="day" aria-label="日期"></select><span class="count num" data-r="count"></span></div>
      <div class="tline" data-r="list"></div>
      <div class="none" data-r="none" hidden>这一天没有报警或员工记录</div>
      <button class="more" data-r="more" hidden>加载更多</button>`;
    this.r = {};
    this.root.querySelectorAll("[data-r]").forEach(e => this.r[e.dataset.r] = e);
    this.r.day.onchange = () => { this.day = this.r.day.value; this.load(true); };
    this.r.more.onclick = () => this.load(false);
  },
  async days() {
    const {days} = await getJSON("/api/days?src=sec");
    const keep = this.day;
    this.r.day.innerHTML = days.map(d => `<option value="${d}">${fmtDay(d)}</option>`).join("");
    this.day = days.includes(keep) ? keep : days[0] || null;
    if (this.day) this.r.day.value = this.day;
  },
  async load(reset) {
    if (!this.day) { this.r.none.hidden = false; this.r.list.innerHTML = ""; return; }
    const off = reset ? 0 : this.shown;
    const d = await getJSON(`/api/timeline?day=${this.day}&offset=${off}&limit=40`);
    if (reset) { this.r.list.innerHTML = ""; this.shown = 0; }
    for (const e of d.events) {
      const b = document.createElement("div");
      b.className = `card ev ${e.alarm ? "alarm" : e.kind}`;
      b.innerHTML = `<div class="evimg"><img loading="lazy" src="${evImg(e)}" alt="">${e.video ? `<span class="play"></span>` : ""}</div><div class="body">
        <span><span class="chip ${evChip(e)}">${esc(e.label)}</span></span>
        <span class="when num">${esc(span(e))}</span>
        <span class="when">${e.count} ${e.video ? "段报警视频" : "张抓拍"}</span></div>`;
      b.onclick = () => openEvent(e);
      this.r.list.appendChild(b);
    }
    this.shown += d.events.length; this.total = d.total;
    this.r.count.textContent = `共 ${d.total} 个事件`;
    this.r.none.hidden = d.total !== 0;
    this.r.more.hidden = this.shown >= d.total;
  },
  async refresh() {
    if (!this.active) return;
    try {
      const d = await getJSON(`/api/timeline?day=${this.day}&offset=0&limit=1`);
      if (d.total !== this.total) this.load(true);
    } catch (e) {}
  },
  async show(on) {
    this.active = on; this.root.hidden = !on;
    if (!on) return;
    if (!this.started) { this.started = true; this.build(); }
    try { await this.days(); await this.load(true); } catch (e) { this.r.none.hidden = false; this.r.none.textContent = e.message; }
  },
  poll() {},
};
function openEvent(e) {
  // 11-01: a clip event plays its first clip (the alarm's start, with the pre-roll)
  const v = $("#lbVid"), i = $("#lbImg");
  if (e.video) {
    const url = `/vid/${e.day}/${encodeURIComponent(e.video)}?src=sec`;
    i.hidden = true; i.removeAttribute("src");
    v.hidden = false; v.poster = evImg(e); v.src = url;
    v.play().catch(() => {});
    $("#lbDl").href = url + "&dl=1";
  } else {
    v.pause(); v.hidden = true; v.removeAttribute("src"); v.load();
    i.hidden = false; i.src = evImg(e, true);
    $("#lbDl").href = evImg(e, true) + "&dl=1";
  }
  $("#lbText").textContent = `${e.label}  ·  ${e.start.replace("T", " ").slice(0, 19)}  ·  ${e.count} ${e.video ? "段" : "张"}`;
  $("#lb").hidden = false;
}

// ---- 10-31: new-alarm banner, beep, vibration, title flash -------------------
const ALERT = {
  since: Date.now() / 1000, ev: null, flash: null, title: document.title, audio: null,
  beep() {
    try {
      this.audio = this.audio || new (window.AudioContext || window.webkitAudioContext)();
      const t = this.audio.currentTime;
      for (const [dt, f] of [[0, 880], [0.25, 660], [0.5, 880]]) {
        const o = this.audio.createOscillator(), g = this.audio.createGain();
        o.frequency.value = f; o.connect(g); g.connect(this.audio.destination);
        g.gain.setValueAtTime(0.25, t + dt); g.gain.exponentialRampToValueAtTime(0.001, t + dt + 0.22);
        o.start(t + dt); o.stop(t + dt + 0.23);
      }
    } catch (e) {}
  },
  show(e) {
    this.ev = e;
    const img = $("#alertImg");
    if (e.file) { img.src = evImg(e); img.hidden = false; } else { img.removeAttribute("src"); img.hidden = true; }   // 11-01: the alert comes before its video
    $("#alertText").textContent = `${e.label}  ${e.start.slice(11, 19)}`;
    $("#alertbar").hidden = false;
    this.beep();
    try { if (navigator.vibrate) navigator.vibrate([300, 120, 300]); } catch (x) {}
    clearInterval(this.flash);
    let on = false;
    this.flash = setInterval(() => { on = !on; document.title = on ? `【${e.label}】` : this.title; }, 700);
  },
  hide() { $("#alertbar").hidden = true; clearInterval(this.flash); document.title = this.title; },
  async poll() {
    try {
      const d = await getJSON(`/api/alerts?since=${this.since}`);
      if (d.events.length) {
        const e = d.events[d.events.length - 1];
        this.since = Math.max(this.since, e.start_epoch);
        this.show(e);
      }
    } catch (e) {}
  },
};
$("#alertClose").onclick = () => ALERT.hide();
$("#alertOpen").onclick = () => {
  const e = ALERT.ev; ALERT.hide();
  if (!e) return;
  if (e.file) openEvent(e); else select("tl");      // 11-01: no picture yet -> the timeline
};
// browsers only allow sound after a tap: unlock the audio on the first one
document.addEventListener("click", () => { try { ALERT.audio = ALERT.audio || new (window.AudioContext || window.webkitAudioContext)(); ALERT.audio.resume(); } catch (e) {} }, {once: true});
setInterval(() => ALERT.poll(), 2000);

// ---- tabs ----------------------------------------------------------------
// 11-01: 工件记录 has its own 标准件 | 任意工件 below the header.
const views = {sec: new View(SEC, $("#v-sec")), tl: TL, st: STATS,
               std: new View(QC_STD, $("#v-qcstd")), any: new View(QC_ANY, $("#v-qcany"))};
const TOPS = ["sec", "tl", "qc", "st"];
let activeTab = "sec", sub = "std";
function apply() {
  for (const b of document.querySelectorAll("#tabs button")) b.classList.toggle("on", b.dataset.v === activeTab);
  for (const b of document.querySelectorAll("#subtabs button")) b.classList.toggle("on", b.dataset.v === sub);
  $("#v-qc").hidden = activeTab !== "qc";
  const on = activeTab === "qc" ? sub : activeTab;
  for (const [k, v] of Object.entries(views)) v.show(k === on);
  try { localStorage.setItem("evs_tab", activeTab); localStorage.setItem("evs_sub", sub); } catch (e) {}
}
for (const b of document.querySelectorAll("#tabs button")) b.onclick = () => { activeTab = b.dataset.v; apply(); };
for (const b of document.querySelectorAll("#subtabs button")) b.onclick = () => { sub = b.dataset.v; apply(); };

brand();
try {
  const t = localStorage.getItem("evs_tab"), s = localStorage.getItem("evs_sub");
  if (TOPS.includes(t)) activeTab = t;
  if (s === "any" || s === "std") sub = s;
} catch (e) {}
const h = location.hash.slice(1);                  // 10-31: /#st, /#tl ...; 11-01: /#std, /#any
if (TOPS.includes(h)) activeTab = h;
else if (h === "std" || h === "any") { activeTab = "qc"; sub = h; }
apply();
setInterval(() => Object.values(views).forEach(v => v.poll()), 1000);
setInterval(() => Object.values(views).forEach(v => v.refresh()), REFRESH_MS);
</script>
</body>
</html>
"""
