"""The QC workpiece card: the captured frame with a white caption bar below.

    ┌──────────────────────────────────────────────────┐
    │          960 x 540 frame (OSD included)           │
    ├──────────────────────────────────────────────────┤
    │ 工件检测记录   No.012             2026-10-09 21:35:08 │
    │ 长 26 mm    宽 49 mm    厚 28 mm          ┌──────┐ │
    │ 形状 圆形   颜色 ■ 红色   表面 无缺陷      │ 合格 │ │
    │                                          └──────┘ │
    └──────────────────────────────────────────────────┘

Line 3 and the shape / colour / surface checks come from EVQC2's qc_ext
(qc_record.QcExt, 2026-10-09).  A record from an EVQC1 bit has no ext: the
line then shows dashes and only the dimensions can be judged.

2026-10-29, layout-3 records follow the inspection page's two modes:

    任意    ┌──────────────────────────────────────────────────┐
            │ 工件检测记录  任意   No.012          2026-10-29 21:35:08 │
            │ 长 26 mm    宽 49 mm    厚 28 mm                      │
            │ 形状 矩形   颜色 ■ 红色   污渍 无污渍                    │
            └──────────────────────────────────────────────────┘
            (no verdict box: there is no standard to judge against)

    标准件  ┌──────────────────────────────────────────────────┐
            │ 工件检测记录  标准件 60×60×30   No.013   2026-10-29 ... │
            │ 长 61 mm +1   宽 58 mm -2   厚 36 mm +6      ┌──────┐ │
            │ 形状 矩形   颜色 ■ 红色   污渍 无污渍         │不合格│ │
            │ 公差 长宽 ±3 mm  厚 ±5 mm                    │  厚  │ │
            └──────────────────────────────────────────────└──────┘ ┘
            deviations in red when out of tolerance; the verdict is the
            FPGA's (qc_rules.judge_fpga), the same as the OSD 判定 row.

OpenCV's putText has no CJK glyphs, so the bar is drawn with Pillow and a
Windows system font.  The frame itself is pasted untouched: the card is a
view of the measurement, the raw frame is saved alongside it unmodified.
"""
from __future__ import annotations

import functools
import os
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from qc_rules import Verdict

BAR_HEIGHT = 176
BAR_HEIGHT_STD = 216       # layout-3 标准件 card: one more line (the tolerances)
MARGIN = 24
VERDICT_W = 176            # the verdict box, at 960 wide

INK = (25, 25, 25)
MUTED = (110, 110, 110)
RULE = (205, 205, 205)
PASS_GREEN = (0, 140, 60)
FAIL_RED = (205, 30, 30)

# (regular, bold).  Microsoft YaHei first: it is on every Chinese Windows and
# renders cleanly at these sizes; SimHei / SimSun are the fallbacks.
FONT_CANDIDATES = (
    ("msyh.ttc", "msyhbd.ttc"),
    ("simhei.ttf", "simhei.ttf"),
    ("simsun.ttc", "simsun.ttc"),
)


@dataclass(frozen=True)
class Fonts:
    regular: str | None
    bold: str | None

    @property
    def found(self) -> bool:
        return self.regular is not None


def find_fonts(override: str | None = None) -> Fonts:
    if override:
        return Fonts(override, override)
    font_dir = Path(os.environ.get("WINDIR", r"C:/Windows")) / "Fonts"
    for regular, bold in FONT_CANDIDATES:
        r = font_dir / regular
        if r.is_file():
            b = font_dir / bold
            return Fonts(str(r), str(b) if b.is_file() else str(r))
    return Fonts(None, None)


@functools.lru_cache(maxsize=16)
def _font(path: str | None, size: int):
    from PIL import ImageFont
    if path is None:
        try:
            return ImageFont.load_default(size=size)
        except TypeError:          # Pillow < 10.1 has no size argument
            return ImageFont.load_default()
    return ImageFont.truetype(path, size)


def bar_height(width: int, record=None) -> int:
    """Caption bar height for a frame of this width (BAR_HEIGHT px at 960).

    A layout-3 标准件 record (2026-10-29) gets BAR_HEIGHT_STD."""
    ext = getattr(record, "ext", None)
    tall = ext is not None and getattr(ext, "layout", 2) >= 3 and ext.std_mode
    return round((BAR_HEIGHT_STD if tall else BAR_HEIGHT) * width / 960)


def _surface_short(ext) -> tuple[str, tuple]:
    """(text, colour) for the 表面 field."""
    if getattr(ext, "layout", 2) >= 3:
        if not ext.obj:
            return "未检测", MUTED
        return ("有污渍", FAIL_RED) if ext.defect else ("无污渍", PASS_GREEN)
    if not ext.obj:
        return "未检测", MUTED
    if not ext.defect:
        return "无缺陷", PASS_GREEN
    parts = [f"{name}{n}" for name, n in (("孔洞", ext.hole), ("污渍", ext.stain),
                                           ("划痕", ext.edge)) if n]
    return ("有缺陷 " + " ".join(parts)) if parts else "有缺陷", FAIL_RED


def render_card(bgr, record, wall_time: float, verdict: Verdict, fonts: Fonts):
    """BGR ndarray (H + bar_height(W), W, 3); `bgr` itself is not modified.

    Laid out for 960 wide and scaled by W/960, so a 1920x1080 full-resolution
    card is the same card at twice the size.
    """
    import numpy as np
    from PIL import Image, ImageDraw

    height, width = bgr.shape[:2]
    s = width / 960

    def px(v: float) -> int:
        return round(v * s)

    ext = getattr(record, "ext", None)
    v3 = ext is not None and getattr(ext, "layout", 2) >= 3
    std = v3 and ext.std_mode
    bar = bar_height(width, record)

    canvas = Image.new("RGB", (width, height + bar), (255, 255, 255))
    canvas.paste(Image.fromarray(np.ascontiguousarray(bgr[:, :, ::-1])), (0, 0))
    draw = ImageDraw.Draw(canvas)
    # A rectangle, not line(width=2): a wide line is centred on its y and
    # would paint the frame's last row.
    draw.rectangle([(0, height), (width - 1, height + max(1, px(2)) - 1)], fill=RULE)

    title = _font(fonts.bold, px(26))
    small = _font(fonts.regular, px(22))
    label = _font(fonts.regular, px(26))
    value = _font(fonts.bold, px(34))
    value2 = _font(fonts.bold, px(28))
    unit = _font(fonts.regular, px(22))
    big = _font(fonts.bold, px(44))
    margin = px(MARGIN)

    # line 1: title, mode (layout 3), record number, time (right-aligned)
    y1 = height + px(14)
    x = margin
    draw.text((x, y1), "工件检测记录", font=title, fill=INK)
    x += draw.textlength("工件检测记录", font=title) + px(28)
    part = ext.std_part if std else None          # 10-31: 方块 or 三棱柱
    if v3:
        mode = (f"{part['name']} {part['x']}×{part['y']}×{part['z']}"
                if std else "任意")
        draw.text((x, y1 + px(3)), mode, font=small, fill=INK)
        x += draw.textlength(mode, font=small) + px(28)
    draw.text((x, y1 + px(3)), f"No.{record.seq:03d}", font=small, fill=MUTED)
    stamp = datetime.fromtimestamp(wall_time).strftime("%Y-%m-%d %H:%M:%S")
    draw.text((width - margin - draw.textlength(stamp, font=small), y1 + px(3)),
              stamp, font=small, fill=MUTED)

    # line 2: 长 / 宽 / 厚, label muted, number bold; 标准件: the deviation
    y2 = height + px(60)
    x = margin
    devs = None
    if std:
        from qc_record import std_deviations
        devs = std_deviations(record, part)
        tols = {"x": part["tol_xy"], "y": part["tol_xy"], "z": part["tol_z"]}
    for name, mm, key in (("长", record.x_mm, "x"), ("宽", record.y_mm, "y"), ("厚", record.z_mm, "z")):
        draw.text((x, y2 + px(6)), name, font=label, fill=MUTED)
        x += draw.textlength(name, font=label) + px(10)
        text = f"{mm}"
        draw.text((x, y2), text, font=value, fill=INK)
        x += draw.textlength(text, font=value) + px(6)
        draw.text((x, y2 + px(10)), "mm", font=unit, fill=MUTED)
        x += draw.textlength("mm", font=unit) + px(8 if devs else 44)
        if devs:
            d = devs[key]
            dtext = f"{d:+d}" if d else "±0"
            dink = FAIL_RED if abs(d) > tols[key] else PASS_GREEN
            draw.text((x, y2 + px(8)), dtext, font=value2, fill=dink)
            x += draw.textlength(dtext, font=value2) + px(30)

    # line 3: 形状 / 颜色 / 表面 (EVQC2; 污渍 from layout 3), dashes from an EVQC1 bit
    y3 = height + px(116)
    x = margin
    if ext is None:
        fields = (("形状", "—", INK, None), ("颜色", "—", INK, None), ("表面", "—", INK, None))
    else:
        surf, surf_ink = _surface_short(ext)
        swatch = tuple(ext.mean_rgb) if (ext.obj or v3) else None
        fields = (("形状", ext.shape_name, INK, None),
                  ("颜色", ext.colour_name, INK, swatch),
                  ("污渍" if v3 else "表面", surf, surf_ink, None))
    for name, text, ink, swatch in fields:
        draw.text((x, y3 + px(3)), name, font=label, fill=MUTED)
        x += draw.textlength(name, font=label) + px(10)
        if swatch is not None:
            side = px(24)
            top = y3 + px(6)
            draw.rectangle([(x, top), (x + side, top + side)], fill=swatch, outline=MUTED)
            x += side + px(8)
        draw.text((x, y3), text, font=value2, fill=ink)
        x += draw.textlength(text, font=value2) + px(40)

    # line 4 (标准件 only): the tolerances the verdict used
    if std:
        from qc_record import COLOR_NAMES, SHAPE_NAMES
        need = f"{'/'.join(COLOR_NAMES[c] for c in part['colours'])} {SHAPE_NAMES[part['shape']]}"
        tol = (f"公差  长宽 ±{part['tol_xy']} mm   厚 ±{part['tol_z']} mm   "
               f"要求 {need}   有污渍即不合格")
        room = width - margin - px(VERDICT_W) - px(16) - margin
        if draw.textlength(tol, font=small) > room:   # 10-31: drop the last clause first
            tol = f"公差  长宽 ±{part['tol_xy']} mm   厚 ±{part['tol_z']} mm   要求 {need}"
        draw.text((margin, height + px(164)), tol, font=small, fill=MUTED)

    # verdict: a box at the right of lines 2-3, the reasons under the word
    bx1 = width - margin
    bx0 = bx1 - px(VERDICT_W)
    by0, by1 = y2, height + bar - px(14)
    if verdict.status == "none":
        pass                           # 任意: nothing to judge against
    elif verdict.status in ("disabled", "measuring"):
        vtext = verdict.text
        draw.text((bx1 - draw.textlength(vtext, font=small), y2 + px(10)),
                  vtext, font=small, fill=MUTED)
    else:
        ok = verdict.status == "pass"
        colour = PASS_GREEN if ok else FAIL_RED
        draw.rounded_rectangle([(bx0, by0), (bx1, by1)], radius=px(10),
                               outline=colour, width=max(2, px(3)))
        word = "合格" if ok else "不合格"
        items = []
        for f in ([] if ok else verdict.failed):     # 10-31: axes -> 尺寸 (line 2 has them)
            f = "尺寸" if f in ("长", "宽", "厚") else f
            if f not in items:
                items.append(f)
        # Pillow puts the glyph tops a few px below y and textbbox gives the
        # real extent, so centre on the measured ink, not on the font size.
        lines, rfont = [], small
        if items:
            room = px(VERDICT_W - 16)
            one = "、".join(items)
            if draw.textlength(one, font=small) <= room:
                lines = [one]
            else:                                    # 10-31: two lines, smaller
                rfont = _font(fonts.regular, px(16))
                half = (len(items) + 1) // 2
                lines = ["、".join(items[:half]), "、".join(items[half:])]
        wb = draw.textbbox((0, 0), word, font=big)
        rbs = [draw.textbbox((0, 0), t, font=rfont) for t in lines]
        gap = px(6) if lines else 0
        lh = [(b[3] - b[1]) for b in rbs]
        ink_h = (wb[3] - wb[1]) + gap + sum(lh) + px(4) * max(0, len(lines) - 1)
        top = (by0 + by1 - ink_h) / 2
        draw.text(((bx0 + bx1 - (wb[2] - wb[0])) / 2 - wb[0], top - wb[1]),
                  word, font=big, fill=colour)
        y = top + (wb[3] - wb[1]) + gap
        for t, rb in zip(lines, rbs):
            draw.text(((bx0 + bx1 - (rb[2] - rb[0])) / 2 - rb[0], y - rb[1]),
                      t, font=rfont, fill=colour)
            y += (rb[3] - rb[1]) + px(4)

    return np.asarray(canvas)[:, :, ::-1].copy()
