# Windows 上位机接收端

这是 EVS1 UDP 视频协议的 Windows 接收端。它只显示完整的最新预览帧；不完整帧或 CRC 错误包会被丢弃，从而控制显示延迟。

## 首次安装

在本目录打开 PowerShell：

```powershell
py -m pip install -r requirements.txt
```

## 运行

```powershell
py evs_receiver.py --bind 0.0.0.0 --port 6001
```

收到 FPGA 的 `EVS1` RGB565 预览流后会弹出画面窗口，按 `q` 退出。控制台每两秒输出一次实际显示帧率、错误包和丢帧统计。

收包在独立线程里；启动时会打印 EcoQoS / 进程优先级 / 接收缓冲区的实际结果，第一次统计后打印收包线程优先级。

## 定时存图（安防场景，目前无触发）

```powershell
# 每秒存一张 JPEG 到 captures\<日期>\，同目录 index.jsonl 记录每张图；运行中按 s 手动多存一张
py evs_receiver.py --port 6001 --snapshot-dir captures

# 调间隔 / 质量；--snapshot-interval 0 表示只在按 s 时存
py evs_receiver.py --snapshot-dir captures --snapshot-interval 2 --snapshot-quality 85
```

每 2 秒的统计里多一行 `存图: 已存 N，队列满丢弃 M，失败 K`。存图在单独线程，磁盘慢只会丢图、不会拖慢画面。旧图**不会自动删除**（每秒一张约 100 KB，一小时约 360 MB）。

## 工件质检卡片（默认开启）

FPGA 在工件测量稳定时（`qc_trig`，每个工件一次）发一个 `EVQC2` 记录包（48 字节，连发 3 次防丢；2026-10-09 起，旧 bit 发的 32 字节 `EVQC1` 也照收，只是卡片只有尺寸）。接收端照常运行即可，不用加参数：

```powershell
py evs_receiver.py --port 6001
```

每个工件存两张图到 `captures\qc\<日期>\`：`<时间>_No012_card.jpg`（原图 + 下方白底说明栏，三行：工件检测记录 / No. / 时间；长 宽 厚 mm；形状 / 颜色（带色块）/ 表面（无缺陷 或 孔洞 污渍 划痕格数）；右侧一个合格 / 不合格框，不合格时框里写原因）和 `<时间>_No012_raw.jpg`（未加工原图），同目录 `index.jsonl` 每个工件一行（尺寸、顶面/台面距离、框像素、帧号、形状、颜色和平均 RGB、表面与三类缺陷格数、缺陷框、判定）。实时窗口右上角会弹出最新卡片的缩略图 5 秒。

- 卡片取 FPGA 记录所指帧之后的**第 2 帧**完整画面（`--qc-frame-offset` 可调），保证 OSD 已显示「稳定 #n」。那一帧网络丢了就取下一帧；0.5 秒内都没有完整帧则用最新一帧，index 里 `frame_match` 记为 `late`。
- **合格判定**（`qc_rules.json`，运行中修改在下一个工件生效）：默认 `"enabled": true`、`"surface": true` = 表面有缺陷就不合格；尺寸填 `nominal`（标称 mm）、`tol`（公差 ±mm）才判；`"shape"` / `"colour"` 填工件应有的形状（圆形 / 矩形 / 三角形 / 其他）和颜色（红色 橙色 黄色 绿色 青色 蓝色 紫色 白色 灰色 黑色），`null` 不判。`"enabled": false` 时卡片显示「判定：预留」。
- **颜色**：FPGA 现在发的是工件内部（去掉缺陷格后）的平均 RGB，电脑按色相 / 饱和度 / 亮度给出颜色名（`qc_record.colour_name_from_rgb`）。队友的颜色分类接上后，FPGA 会在 `qc_ext[117:113]` 直接给类别，卡片自动改用它。
- 每 2 秒统计多一行 `质检: 工件 N（包 / 重复 / 无效 / 坏包），已存 …`。「重复」是正常的（每条记录 3 份）。
- 中文用系统的微软雅黑；找不到会提示，`--qc-font` 可指定字体文件。`--no-qc` 关闭。
- 没有板子时看效果：`py make_sample_cards.py`，在 `captures\qc_samples\` 生成预留 / 合格 / 尺寸不合格 / 表面缺陷 / 形状颜色不符 / 旧 EVQC1 六张样例。
- 板子测不出工件时测卡片：`py send_fake_qc.py --seq 3 --shape 3 --rgb 30,60,210 --stain 3`（往本机接收端发一条假记录，`--v1` 发旧格式）。

## 手机 / 另一台电脑看抓图（局域网网页）

另开一个 PowerShell 窗口（接收端照常跑着），在本目录：

```powershell
py snapshot_server.py --root captures
```

它会打印一个带口令的链接，例如 `http://192.168.1.23:8080/?k=xxxx`。手机连**同一个 Wi-Fi**，浏览器打开这个链接：上面是每秒自动刷新的最新一张，下面按日期浏览、点开看大图或下载。口令第一次打开后记在浏览器里；每次重启服务口令会变（想固定就加 `--key 自己的口令`）。

- 首次运行 Windows 防火墙会弹窗，勾选「专用网络」允许。若 Wi-Fi 被 Windows 标成「公用网络」，要么在网络设置里改成专用，要么在弹窗里也勾公用。
- 只监听 Wi-Fi 网卡，**绝不**在连 FPGA 的 192.168.137.x 网卡上开服务。
- **不要用 Windows 自带的「移动热点」**：它默认也是 192.168.137.1，会和 FPGA 直连网卡冲突。没有路由器时，改用手机开热点、电脑连上去。
- 它和接收端是两个独立进程，网页挂了、手机刷得再多也不影响实时画面。

可选功能：

```powershell
# 保存未来的 still 图片消息
py evs_receiver.py --record-dir captures

# 同时将收到的预览画面录制为 MP4
py evs_receiver.py --record-video preview.mp4 --record-fps 30

# 首轮硬件联调使用，不依赖 OpenCV
py heartbeat_listener.py --port 6001
```

## 离线自测

```powershell
py -m unittest -v test_evs_receiver.py
py -m unittest -v test_qc.py
```

`test_qc.py` 覆盖 EVQC1 逐字节布局（与 `evs_aux_tx.v` 对照）、16 位帧号扩展、3 份重复去重、取第 2 帧 / 超时兜底、收包线程端到端落盘、合格判定与规则文件热加载、卡片尺寸且原图一个像素不改。

该自测不依赖板卡，覆盖乱序分包重组、CRC 拒收与“新预览帧丢弃旧不完整帧”的低延迟策略，以及收包线程（本机回环）、最新帧槽、定时存图策略和写图线程。
