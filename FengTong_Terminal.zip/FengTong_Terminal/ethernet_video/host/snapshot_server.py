"""LAN viewer for the snapshots evs_receiver.py saves (ETHERNET_V1.md §16.4).

A separate process from the receiver on purpose: it only reads
``<root>/<YYYYMMDD>/*.jpg`` and ``index.jsonl``, so if it hangs, crashes or is
flooded by a phone it cannot touch the video path.  Standard library only.

    py snapshot_server.py --root captures

prints a URL such as ``http://192.168.1.23:8080/?k=Ab3...``; open it on a phone
on the same Wi-Fi.  The key is remembered in a cookie after the first visit.

2026-10-29: ONE page, two independent views -- 监控抓拍 (``--root``) and 工件
记录 (``--qc-root``, default ``<root>/qc``, where evs_receiver's --qc-dir puts
the cards).  Every API call takes ``src=sec`` (default) or ``src=qc``.  The
header has a slot for the contest logo, the team logo and the team's name:
put ``logo.png`` / ``team.png`` (or .jpg / .svg) in ``--brand`` (default
``brand/`` next to this file) and the texts in ``brand/brand.json``::

    {"title": "智能视觉监测平台", "team": "队伍名称", "subtitle": "..."}

Missing files leave a neat placeholder; nothing needs a restart but the page
reload.

2026-10-31 (Anlogic_update): + 质检统计 (/api/qcstats, CSV /api/qccsv; qc_stats.py)
and 事件时间线 (/api/timeline) / new-alarm poll (/api/alerts) for the page's
banner + sound; optional webhook push from push.json next to this file
(sec_events.py header; missing file = off).

2026-11-01: alarms are short clips (clips.py; /vid/<day>/<name>.mp4|.webm with
byte ranges for iPhone Safari); 工件记录 splits into 任意 / 标准件 (``mode=any|
standard``); /api/std + /std/image = the standard part's spec and drawing
(qc_site_assets/, render_std_part.py) for the 标准件 view -- the 方块 only.

Network rules:
* Never serve on the FPGA link (192.168.137.0/24, §8/§14).  The default
  ``--bind auto`` picks the address of the interface that carries the default
  route (normally Wi-Fi) and refuses the FPGA subnet.
* Every request needs the access key, so anyone else on the same Wi-Fi who
  finds the port still sees nothing.
"""
from __future__ import annotations

import argparse
import hmac
import ipaddress
import json
import re
import secrets
import socket
import sys
import threading
import time
from http import HTTPStatus
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

from snapshot_page import PAGE      # 2026-10-29: the page (HTML/CSS/JS) has its own file
import qc_export
import qc_stats                     # 2026-10-31
import sec_events

FPGA_NET = ipaddress.ip_network("192.168.137.0/24")
DAY_RE = re.compile(r"^\d{8}$")
FILE_RE = re.compile(r"^[0-9A-Za-z_.-]+\.jpg$")
VID_RE = re.compile(r"^[0-9A-Za-z_.-]+\.(mp4|webm)$")      # 11-01: alarm clips (clips.py)
VID_TYPES = {"mp4": "video/mp4", "webm": "video/webm"}
RANGE_RE = re.compile(r"^bytes=(\d*)-(\d*)$")
COOKIE = "evs_k"
PAGE_LIMIT_MAX = 200
DEFAULT_BRAND = Path(__file__).with_name("brand")
BRAND_IMAGES = {"logo": "logo", "team": "team", "product": "product", "company": "company", "contest": "contest"}          # url name -> file stem
BRAND_TYPES = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
               ".svg": "image/svg+xml", ".webp": "image/webp"}
BRAND_DEFAULTS = {"title": "智能视觉监测平台", "team": "队伍名称", "subtitle": "FPGA 实时安防与工件质检"}

# 2026-10-09: security pictures by level.  The receiver writes "trigger" as
# alarm_face (level 2) / alarm_motion (level 3) / normal (nobody there) /
# manual (key s); older indexes say "timer" for a periodic picture, shown with
# the normal ones.  2026-10-29: + staff (the green "员工 PASS" picture), and
# the page shows three kinds only: alarm (both levels), staff, normal.  The
# fine-grained names stay accepted by the API.
KINDS = ("all", "alarm", "staff", "normal", "alarm_face", "alarm_motion", "manual")
# 工件记录: by the card's verdict (index "verdict"); "none" = 任意 mode,
# 测量中, or an old record without a verdict.
QC_KINDS = ("all", "pass", "fail", "none")


def record_kind(rec: dict) -> str:
    t = rec.get("trigger", "")
    if t in ("alarm_face", "alarm_motion", "staff", "manual"):
        return t
    return "normal"


def kind_matches(rec: dict, kind: str) -> bool:
    k = record_kind(rec)
    return kind == "all" or k == kind or (kind == "alarm" and k in ("alarm_face", "alarm_motion"))


def qc_kind(rec: dict) -> str:
    v = rec.get("verdict")
    return v if v in ("pass", "fail") else "none"


# 2026-11-01: 工件记录 splits into 任意 / 标准件 (index "mode", layout-3
# records; anything older has no mode and counts as 任意).
QC_MODES = ("all", "any", "standard")


def qc_mode(rec: dict) -> str:
    return "standard" if rec.get("mode") == "standard" else "any"


# The standard part's drawing (render_std_part.py) for the 标准件 view, by
# qc_record.STD_PARTS key.  11-01 (user): only the 方块 -- the 三棱柱 is
# dropped on the PC side (the RTL keeps it until the next synthesis).
# A missing file = the page shows the spec only.
STD_ASSETS = Path(__file__).with_name("qc_site_assets")
STD_IMAGES = {"cube": STD_ASSETS / "std_A01_drawing.png"}


def std_parts() -> dict:
    """/api/std: {"parts": {"cube": {...spec, "image": bool}}}."""
    from qc_record import STD_PARTS
    parts = {}
    for p in STD_PARTS.values():
        if p["key"] not in STD_IMAGES:
            continue
        spec = {k: v for k, v in p.items() if k not in ("shape", "colours")}
        spec["image"] = STD_IMAGES[p["key"]].is_file()
        parts[p["key"]] = spec
    return {"parts": parts, "default": "cube"}


class IndexCache:
    """Per-day index.jsonl, read incrementally.

    At one image a second a day's index reaches ~86400 lines; re-reading it on
    every phone poll would be wasteful, so each file is parsed once and only
    the appended tail is read afterwards.  A line without its trailing newline
    is still being written by the receiver and is left for the next call.
    """

    def __init__(self, root: Path) -> None:
        self.root = root
        self._lock = threading.Lock()
        self._days: dict[str, tuple[int, list[dict]]] = {}   # day -> (offset, records)

    def days(self) -> list[str]:
        if not self.root.is_dir():
            return []
        return sorted((p.name for p in self.root.iterdir()
                       if p.is_dir() and DAY_RE.match(p.name)), reverse=True)

    def records(self, day: str) -> list[dict]:
        path = self.root / day / "index.jsonl"
        with self._lock:
            offset, records = self._days.get(day, (0, []))
            try:
                size = path.stat().st_size
            except FileNotFoundError:
                self._days.pop(day, None)
                return []
            if size < offset:           # file replaced or truncated: start over
                offset, records = 0, []
            if size > offset:
                with open(path, "rb") as f:
                    f.seek(offset)
                    chunk = f.read(size - offset)
                end = chunk.rfind(b"\n") + 1
                for line in chunk[:end].splitlines():
                    try:
                        rec = json.loads(line)
                    except ValueError:
                        continue
                    if isinstance(rec, dict) and FILE_RE.match(str(rec.get("file", ""))):
                        rec["day"] = day
                        records.append(rec)
                offset += end
            self._days[day] = (offset, records)
            return records

    def latest(self, keep=None) -> dict | None:
        """Newest record (of those `keep` accepts, if given)."""
        for day in self.days():
            recs = self.records(day)
            if keep is not None:
                recs = [r for r in recs if keep(r)]
            if recs:
                return recs[-1]
        return None


def pick_bind_address() -> str:
    """Address of the interface carrying the default route (Wi-Fi, normally).

    connect() on a UDP socket only consults the routing table; nothing is
    sent.  Falls back to any non-loopback, non-FPGA address of this host.
    """
    candidates = []
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            candidates.append(s.getsockname()[0])
    except OSError:
        pass
    try:
        candidates += [info[4][0] for info in
                       socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET)]
    except OSError:
        pass
    for addr in candidates:
        ip = ipaddress.ip_address(addr)
        if not ip.is_loopback and ip not in FPGA_NET:
            return addr
    raise SystemExit("找不到可用的局域网地址：请先连上 Wi-Fi，或用 --bind 指定本机地址。")


def check_bind_address(addr: str) -> None:
    try:
        ip = ipaddress.ip_address(addr)
    except ValueError:
        raise SystemExit(f"--bind 需要一个 IPv4 地址：{addr}") from None
    if ip in FPGA_NET:
        raise SystemExit(f"{addr} 属于 FPGA 直连网段 {FPGA_NET}，不能在这张网卡上开网页服务"
                         "（ETHERNET_V1.md §14）。请用 Wi-Fi 网卡的地址。")
    if ip.is_unspecified:
        print("警告：绑定 0.0.0.0 会在所有网卡（含 FPGA 直连网卡）上监听，只建议临时排查用。")


class Handler(BaseHTTPRequestHandler):
    server_version = "EVSSnapshot/1"
    # Set on the class by make_server().
    caches: dict          # "sec" / "qc" -> IndexCache
    brand_dir: Path
    key: str

    @property
    def cache(self) -> IndexCache:             # the 监控 view, as before 10-29
        return self.caches["sec"]

    # ---- plumbing -------------------------------------------------------
    def log_message(self, fmt, *args):  # one short line per request, no noise
        if not getattr(self.server, "quiet", False):
            sys.stderr.write(f"{self.client_address[0]} {fmt % args}\n")

    def _send(self, status: int, body: bytes, ctype: str,
              extra: dict[str, str] | None = None) -> None:
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, obj, status: int = 200) -> None:
        self._send(status, json.dumps(obj, ensure_ascii=False).encode("utf-8"),
                   "application/json; charset=utf-8")

    def _error(self, status: int, text: str) -> None:
        self._send(status, text.encode("utf-8"), "text/plain; charset=utf-8")

    def _authorised(self, query: dict) -> tuple[bool, bool]:
        """(allowed, came_from_query).  Constant-time compare."""
        given = query.get("k", [""])[0]
        if given and hmac.compare_digest(given, self.key):
            return True, True
        cookie = SimpleCookie(self.headers.get("Cookie", ""))
        morsel = cookie.get(COOKIE)
        if morsel and hmac.compare_digest(morsel.value, self.key):
            return True, False
        return False, False

    # ---- routes ---------------------------------------------------------
    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        url = urlsplit(self.path)
        query = parse_qs(url.query)
        ok, from_query = self._authorised(query)
        if not ok:
            self._error(HTTPStatus.UNAUTHORIZED,
                        "需要访问口令：请使用 snapshot_server.py 启动时打印的完整链接。")
            return
        if from_query and url.path == "/":
            # Remember the key and drop it from the address bar.
            self._send(HTTPStatus.SEE_OTHER, b"", "text/plain", {
                "Location": "/",
                "Set-Cookie": f"{COOKIE}={self.key}; Max-Age=2592000; Path=/; "
                              "HttpOnly; SameSite=Strict",
            })
            return

        parts = [p for p in url.path.split("/") if p]
        src = query.get("src", ["sec"])[0]
        if src not in self.caches:
            self._error(HTTPStatus.BAD_REQUEST, "src 只能是 sec / qc")
            return
        cache = self.caches[src]
        mode = query.get("mode", ["all"])[0]
        if mode not in QC_MODES:
            self._error(HTTPStatus.BAD_REQUEST, "mode 只能是 " + " / ".join(QC_MODES))
            return
        keep = (lambda r: qc_mode(r) == mode) if (src == "qc" and mode != "all") else None
        if not parts:
            self._send(200, PAGE.encode("utf-8"), "text/html; charset=utf-8")
        elif parts == ["api", "latest"]:
            self._json({"latest": cache.latest(keep)})
        elif parts == ["api", "days"]:
            self._json({"days": cache.days()})
        elif parts == ["api", "index"]:
            self._index(query, cache, src, keep)
        elif parts == ["api", "stats"]:
            self._stats(query, cache, src, keep)
        elif parts == ["api", "brand"]:
            self._json(self._brand())
        elif parts == ["api", "std"]:                  # 11-01: the 标准件 view's side card
            self._json(std_parts())
        elif parts == ["std", "image"]:
            path = STD_IMAGES.get(query.get("part", ["cube"])[0])
            if path is not None and path.is_file():
                self._send(200, path.read_bytes(), "image/png")
            else:
                self._error(HTTPStatus.NOT_FOUND, "标准件图片还没生成：py render_std_part.py")
        elif parts == ["api", "qcstats"]:              # 10-31: always the 工件 records
            self._qcstats(query)
        elif parts == ["api", "qcxlsx"]:
            self._qcxlsx(query)
        elif parts == ["api", "qccsv"]:
            self._qccsv(query)
        elif parts == ["api", "timeline"]:             # 10-31: always the 监控 records
            self._timeline(query)
        elif parts == ["api", "alerts"]:
            self._alerts(query)
        elif len(parts) == 2 and parts[0] == "brand":
            self._brand_image(parts[1])
        elif len(parts) == 3 and parts[0] == "img":
            self._image(cache, parts[1], parts[2], "dl" in query)
        elif len(parts) == 3 and parts[0] == "vid":
            self._video(cache, parts[1], parts[2], "dl" in query)
        else:
            self._error(HTTPStatus.NOT_FOUND, "not found")

    def _day_arg(self, query: dict) -> str | None:
        day = query.get("day", [""])[0]
        if not DAY_RE.match(day):
            self._error(HTTPStatus.BAD_REQUEST, "day 需要 YYYYMMDD")
            return None
        return day

    def _index(self, query: dict, cache: IndexCache, src: str, keep=None) -> None:
        day = self._day_arg(query)
        if day is None:
            return
        try:
            offset = max(0, int(query.get("offset", ["0"])[0]))
            limit = min(PAGE_LIMIT_MAX, max(1, int(query.get("limit", ["60"])[0])))
        except ValueError:
            self._error(HTTPStatus.BAD_REQUEST, "offset/limit 需要整数")
            return
        kind = query.get("kind", ["all"])[0]
        kinds = QC_KINDS if src == "qc" else KINDS
        if kind not in kinds:
            self._error(HTTPStatus.BAD_REQUEST, "kind 只能是 " + " / ".join(kinds))
            return
        recs = cache.records(day)
        if keep is not None:
            recs = [r for r in recs if keep(r)]
        if kind != "all":
            if src == "qc":
                recs = [r for r in recs if qc_kind(r) == kind]
            else:
                recs = [r for r in recs if kind_matches(r, kind)]
        newest_first = recs[::-1][offset:offset + limit]
        self._json({"day": day, "kind": kind, "total": len(recs), "offset": offset,
                    "records": newest_first})

    def _stats(self, query: dict, cache: IndexCache, src: str, keep=None) -> None:
        """Counts per kind for one day -- the page's filter tiles."""
        day = self._day_arg(query)
        if day is None:
            return
        recs = cache.records(day)
        if keep is not None:
            recs = [r for r in recs if keep(r)]
        if src == "qc":
            counts = {k: 0 for k in QC_KINDS}
            for r in recs:
                counts[qc_kind(r)] += 1
        else:
            counts = {k: 0 for k in ("alarm", "staff", "normal", "manual")}
            for r in recs:
                k = record_kind(r)
                counts["alarm" if k in ("alarm_face", "alarm_motion") else k] += 1
        counts["all"] = len(recs)
        self._json({"day": day, "counts": counts})

    # ---- 10-31: 质检统计 / 时间线 / 报警 -------------------------------------
    def _qc_records(self, query: dict) -> list | None:
        """day=YYYYMMDD, or day=all for every day; None after an error reply."""
        day = query.get("day", [""])[0]
        cache = self.caches["qc"]
        if day == "all":
            recs = []
            for d in sorted(cache.days()):
                recs += cache.records(d)
            return recs
        if not DAY_RE.match(day):
            self._error(HTTPStatus.BAD_REQUEST, "day 需要 YYYYMMDD 或 all")
            return None
        return cache.records(day)

    def _part_arg(self, query: dict) -> str | None:
        part = query.get("part", ["all"])[0]
        if part not in qc_stats.PARTS:
            self._error(HTTPStatus.BAD_REQUEST, "part 只能是 " + " / ".join(qc_stats.PARTS))
            return None
        return part

    def _qcstats(self, query: dict) -> None:
        recs = self._qc_records(query)
        part = self._part_arg(query) if recs is not None else None
        if part is None:
            return
        self._json(qc_stats.summary(recs, part))

    def _qcxlsx(self, query: dict) -> None:
        recs = self._qc_records(query)
        part = self._part_arg(query) if recs is not None else None
        if part is None:
            return
        day = query.get("day", [""])[0]
        self._send(200, qc_export.to_xlsx(recs, part),
                   "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                   {"Content-Disposition": f'attachment; filename="qc_{day}_{part}.xlsx"'})

    def _qccsv(self, query: dict) -> None:
        recs = self._qc_records(query)
        part = self._part_arg(query) if recs is not None else None
        if part is None:
            return
        day = query.get("day", [""])[0]
        name = f"qc_{day}_{part}.csv"
        self._send(200, qc_stats.to_csv(recs, part), "text/csv; charset=utf-8",
                   {"Content-Disposition": f'attachment; filename="{name}"'})

    def _timeline(self, query: dict) -> None:
        day = self._day_arg(query)
        if day is None:
            return
        try:
            limit = min(PAGE_LIMIT_MAX, max(1, int(query.get("limit", ["60"])[0])))
            offset = max(0, int(query.get("offset", ["0"])[0]))
        except ValueError:
            self._error(HTTPStatus.BAD_REQUEST, "offset/limit 需要整数")
            return
        evs = sec_events.events(self.caches["sec"].records(day))
        self._json({"day": day, "total": len(evs), "offset": offset,
                    "events": evs[offset:offset + limit]})

    def _alerts(self, query: dict) -> None:
        """Alarm events that started after `since` (epoch s) on the newest day."""
        try:
            since = float(query.get("since", ["0"])[0])
        except ValueError:
            self._error(HTTPStatus.BAD_REQUEST, "since 需要数字（epoch 秒）")
            return
        fresh = self.feed.fresh(since)
        self._json({"now": time.time(), "events": fresh[-5:]})

    def _brand_file(self, stem: str) -> Path | None:
        for ext in BRAND_TYPES:
            p = self.brand_dir / (stem + ext)
            if p.is_file():
                return p
        return None

    def _brand(self) -> dict:
        texts = dict(BRAND_DEFAULTS)
        try:
            data = json.loads((self.brand_dir / "brand.json").read_text(encoding="utf-8"))
            if isinstance(data, dict):
                texts.update({k: str(v) for k, v in data.items() if k in BRAND_DEFAULTS})
        except (OSError, ValueError):
            pass
        return {**texts, **{name + "_img": self._brand_file(stem) is not None
                            for name, stem in BRAND_IMAGES.items()}}

    def _brand_image(self, name: str) -> None:
        path = self._brand_file(BRAND_IMAGES.get(name, "")) if name in BRAND_IMAGES else None
        if path is None:
            self._error(HTTPStatus.NOT_FOUND, "not found")
            return
        self._send(200, path.read_bytes(), BRAND_TYPES[path.suffix.lower()])

    def _video(self, cache: IndexCache, day: str, name: str, download: bool) -> None:
        """An alarm clip, with byte ranges -- Safari on the iPhone will not play
        a video from a server that ignores Range."""
        m = VID_RE.match(name)
        if not DAY_RE.match(day) or not m:
            self._error(HTTPStatus.BAD_REQUEST, "bad path")
            return
        path = cache.root / day / name
        try:
            size = path.stat().st_size
        except (FileNotFoundError, NotADirectoryError):
            self._error(HTTPStatus.NOT_FOUND, "视频不存在（可能已被删除）")
            return
        ctype = VID_TYPES[m.group(1)]
        extra = {"Accept-Ranges": "bytes"}
        if download:
            extra["Content-Disposition"] = f'attachment; filename="{day}_{name}"'
        rng = RANGE_RE.match(self.headers.get("Range", "").strip())
        if not rng or not (rng.group(1) or rng.group(2)):
            self._send(200, path.read_bytes(), ctype, extra)
            return
        if rng.group(1):
            start = int(rng.group(1))
            end = min(size - 1, int(rng.group(2))) if rng.group(2) else size - 1
        else:                                   # bytes=-N: the last N bytes
            start, end = max(0, size - int(rng.group(2))), size - 1
        if start >= size or start > end:
            self._send(HTTPStatus.REQUESTED_RANGE_NOT_SATISFIABLE, b"", ctype,
                       {"Content-Range": f"bytes */{size}"})
            return
        with open(path, "rb") as f:
            f.seek(start)
            body = f.read(end - start + 1)
        extra["Content-Range"] = f"bytes {start}-{end}/{size}"
        self._send(HTTPStatus.PARTIAL_CONTENT, body, ctype, extra)

    def _image(self, cache: IndexCache, day: str, name: str, download: bool) -> None:
        # Both segments are whitelisted by regex, so no "..", no separators.
        if not DAY_RE.match(day) or not FILE_RE.match(name):
            self._error(HTTPStatus.BAD_REQUEST, "bad path")
            return
        path = cache.root / day / name
        try:
            data = path.read_bytes()
        except (FileNotFoundError, IsADirectoryError):
            self._error(HTTPStatus.NOT_FOUND, "图片不存在（可能已被删除）")
            return
        extra = {"Content-Disposition": f'attachment; filename="{day}_{name}"'} if download else None
        self._send(200, data, "image/jpeg", extra)


def make_server(root: Path, bind: str, port: int, key: str,
                quiet: bool = False, qc_root: Path | None = None,
                brand_dir: Path | None = None) -> ThreadingHTTPServer:
    root = Path(root)
    caches = {"sec": IndexCache(root), "qc": IndexCache(Path(qc_root) if qc_root else root / "qc")}
    handler = type("BoundHandler", (Handler,), {
        "caches": caches, "key": key,
        "feed": sec_events.AlertFeed(root, caches["sec"]),       # 11-01: alarm START notices
        "brand_dir": Path(brand_dir) if brand_dir else DEFAULT_BRAND})
    server = ThreadingHTTPServer((bind, port), handler)
    server.daemon_threads = True
    server.quiet = quiet
    return server




def main() -> None:
    parser = argparse.ArgumentParser(description="局域网看抓图和工件记录（手机浏览器打开）")
    parser.add_argument("--root", default="captures", help="evs_receiver 的 --snapshot-dir，默认 captures")
    parser.add_argument("--qc-root", help="evs_receiver 的 --qc-dir，默认 <root>/qc")
    parser.add_argument("--brand", help="放 logo.png / team.png / brand.json 的目录，默认本脚本旁的 brand/")
    parser.add_argument("--bind", default="auto",
                        help="监听地址；默认 auto = Wi-Fi 网卡地址，绝不用 FPGA 直连网段")
    parser.add_argument("--port", type=int, default=8080, help="TCP 端口，默认 8080")
    parser.add_argument("--key", help="访问口令；不给则每次启动随机生成")
    parser.add_argument("--quiet", action="store_true", help="不打印每个请求")
    parser.add_argument("--push", help="报警推送配置 JSON，默认本脚本旁的 push.json（没有 = 不推送）")
    args = parser.parse_args()

    bind = pick_bind_address() if args.bind == "auto" else args.bind
    check_bind_address(bind)
    key = args.key or secrets.token_urlsafe(9)
    # Relative to this script, not to wherever PowerShell happens to be (10-29:
    # a server started from the home directory found no pictures).
    here = Path(__file__).resolve().parent
    root = Path(args.root)
    if not root.is_absolute():
        root = here / root
    qc_root = Path(args.qc_root) if args.qc_root else root / "qc"
    if not qc_root.is_absolute():
        qc_root = here / qc_root
    brand = Path(args.brand) if args.brand else DEFAULT_BRAND
    for d, what in ((root, "抓拍"), (qc_root, "工件卡片")):
        if not d.is_dir():
            print(f"提示：{d} 还不存在；接收端开始存{what}后网页会自动出现。")
    try:
        server = make_server(root, bind, args.port, key, args.quiet, qc_root, brand)
    except OSError as exc:
        raise SystemExit(f"无法监听 {bind}:{args.port}：{exc}（端口被占用可换 --port 8081）") from None
    # 10-31: optional webhook push (push.json next to this script; missing = off)
    push_path = Path(args.push) if args.push else here / "push.json"
    try:
        push_cfg = sec_events.PushConfig.load(push_path)
    except ValueError as exc:
        raise SystemExit(f"推送配置有误：{exc}") from None
    watcher = None
    if push_cfg.enabled:
        watcher = sec_events.AlarmWatcher(server.RequestHandlerClass.feed,
                                          sec_events.Pusher(push_cfg))
        watcher.start()
        print(f"报警推送：开（{push_cfg.format}，两次至少间隔 {push_cfg.min_interval_s:g} s）")
    else:
        print(f"报警推送：关（要开请写 {push_path}，格式见 sec_events.py 头注释）")
    shown = "本机所有网卡" if bind == "0.0.0.0" else bind
    print(f"监控抓拍：{root}")
    print(f"工件记录：{qc_root}")
    print(f"logo / 队名：{brand}（logo.png、team.png、brand.json）")
    print(f"监听：{shown}:{args.port}")
    print(f"手机（连同一个 Wi-Fi）浏览器打开：\n\n    http://{bind}:{args.port}/?k={key}\n")
    print("首次运行 Windows 防火墙会弹窗，请允许「专用网络」。按 Ctrl+C 停止。")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
