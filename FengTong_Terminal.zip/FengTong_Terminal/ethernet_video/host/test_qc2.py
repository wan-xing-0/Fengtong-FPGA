"""EVQC2 (2026-10-09): qc_ext decode, the extra rules and the card's third line.

    py -m unittest test_qc2
"""
from __future__ import annotations

import time
import unittest

from qc_record import (QC2_SIZE, QcExt, QcRecord, colour_name_from_rgb, is_qc,
                       make_qc_datagram, parse_qc)
from qc_rules import Verdict, judge, parse_rules


def rec_bytes(seq: int, x: int = 26, y: int = 49, z: int = 28) -> bytes:
    r = (1 << 127) | (1 << 126) | (x << 104) | (y << 88) | (z << 72) \
        | (250 << 56) | (278 << 40) | (300 << 28) | (200 << 16) | (seq << 8)
    return r.to_bytes(16, "big")


class Evqc2PacketTest(unittest.TestCase):
    def test_layout_matches_rtl(self):
        """Byte offsets of evs_aux_tx.v's qc_byte() with QC_V2 = 1."""
        raw, ext = rec_bytes(12), QcExt.sample(shape=3, stain=4).to_bytes()
        d = make_qc_datagram(raw, 0xBEEF, repeat=2, ext_raw=ext)
        self.assertEqual(len(d), QC2_SIZE)
        self.assertEqual(d[:5], b"EVQC2")
        self.assertEqual(d[5], 2)
        self.assertEqual(d[6:8], bytes([2, 3]))
        self.assertEqual(d[8:10], b"\xbe\xef")
        self.assertEqual(d[10:12], b"\0\0")
        self.assertEqual(d[12:28], raw)
        self.assertEqual(d[28:44], ext)
        self.assertEqual(d[44:47], b"\0\0\0")
        x = 0
        for b in d[:47]:
            x ^= b
        self.assertEqual(d[47], x)
        self.assertTrue(is_qc(d))

    def test_ext_round_trip_by_bit_position(self):
        """Every field at the bit position system_top's qc_ext concatenation gives it."""
        e = QcExt(True, True, 2, 9, True, True, True, 5, 3, 7, 11, 180,
                  (201, 42, 43), (0x123, 0x456, 0x789, 0xABC))
        v = int.from_bytes(e.to_bytes(), "big")
        self.assertEqual(v >> 127 & 1, 1)
        self.assertEqual(v >> 124 & 3, 2)
        self.assertEqual(v >> 120 & 0xF, 9)
        self.assertEqual(v >> 113 & 0xF, 5)
        self.assertEqual(v >> 112 & 1, 0)            # the spare bit
        self.assertEqual(v >> 104 & 0xFF, 3)
        self.assertEqual(v >> 72 & 0xFFFF, 180)
        self.assertEqual(v >> 64 & 0xFF, 201)
        self.assertEqual(v & 0xFFF, 0xABC)
        self.assertEqual(QcExt.from_bytes(e.to_bytes()), e)

    def test_parse_both_versions(self):
        ext = QcExt.sample(shape=1)
        p2 = parse_qc(make_qc_datagram(rec_bytes(5), 7, ext_raw=ext.to_bytes()))
        self.assertEqual(p2.record.ext, ext)
        self.assertEqual(p2.record.seq, 5)
        p1 = parse_qc(make_qc_datagram(rec_bytes(5), 7))
        self.assertIsNone(p1.record.ext)
        self.assertEqual(p1.record.raw, p2.record.raw)

    def test_bad_xor_and_wrong_version(self):
        d = bytearray(make_qc_datagram(rec_bytes(5), 7, ext_raw=QcExt.sample().to_bytes()))
        d[30] ^= 1
        self.assertIsNone(parse_qc(bytes(d)))
        d = bytearray(make_qc_datagram(rec_bytes(5), 7, ext_raw=QcExt.sample().to_bytes()))
        d[5] = 1
        x = 0
        for b in d[:47]:
            x ^= b
        d[47] = x
        self.assertIsNone(parse_qc(bytes(d)))

    def test_names(self):
        self.assertEqual(QcExt.sample(shape=3).shape_name, "三角形")
        self.assertEqual(QcExt.sample(shape=3, shape_valid=False).shape_name, "未识别")
        self.assertEqual(QcExt.sample(rgb=(200, 40, 40)).colour_name, "红色")
        self.assertEqual(QcExt.sample(obj=False).colour_name, "未知")
        self.assertEqual(QcExt.sample().surface_text, "无缺陷")
        self.assertEqual(QcExt.sample(hole=1, stain=3).surface_text, "有缺陷（孔洞1 污渍3）")
        self.assertEqual(QcExt.sample(obj=False).surface_text, "未检测")
        e = QcExt(True, True, 1, 9, True, False, True, 8, 0, 0, 0, 180, (200, 40, 40), (0, 0, 0, 0))
        self.assertEqual(e.colour_name, "蓝色", "the board's colour class wins over the mean")
        # obj_color_detect's stable_id order (10-11): 0 black 1 gray 2 white
        for cls, name in ((0, "黑色"), (1, "灰色"), (2, "白色"), (3, "红色"), (9, "紫色")):
            e = QcExt(True, True, 1, 9, True, False, True, cls, 0, 0, 0, 180, (200, 40, 40), (0, 0, 0, 0))
            self.assertEqual(e.colour_name, name, cls)
        e = QcExt(True, True, 1, 9, True, False, False, 15, 0, 0, 0, 180, (200, 40, 40), (0, 0, 0, 0))
        self.assertEqual(e.colour_name, "红色", "invalid class (15) falls back to the mean")

    def test_colour_words(self):
        cases = {(20, 20, 20): "黑色", (235, 235, 230): "白色", (128, 128, 128): "灰色",
                 (220, 30, 30): "红色", (230, 130, 20): "橙色", (220, 210, 30): "黄色",
                 (40, 180, 60): "绿色", (30, 190, 200): "青色", (30, 60, 210): "蓝色",
                 (150, 40, 190): "紫色"}
        for rgb, name in cases.items():
            self.assertEqual(colour_name_from_rgb(*rgb), name, rgb)


class Evqc2RulesTest(unittest.TestCase):
    def rec(self, **kw):
        return QcRecord.from_bytes(rec_bytes(3), QcExt.sample(**kw).to_bytes())

    def test_surface_on_by_default(self):
        rules = parse_rules({"enabled": True})
        self.assertEqual(judge(self.rec(), rules).status, "pass")
        v = judge(self.rec(stain=3), rules)
        self.assertEqual((v.status, v.failed), ("fail", ("表面",)))
        self.assertEqual(judge(self.rec(obj=False), rules).failed, ("表面未检测",))

    def test_evqc1_record_falls_back_to_dimensions(self):
        rules = parse_rules({"enabled": True})
        self.assertEqual(judge(QcRecord.from_bytes(rec_bytes(3)), rules).status, "disabled")
        rules = parse_rules({"enabled": True, "checks": {"thickness": {"nominal": 28, "tol": 1}}})
        self.assertEqual(judge(QcRecord.from_bytes(rec_bytes(3)), rules).status, "pass")

    def test_shape_colour_and_dimensions_together(self):
        rules = parse_rules({"enabled": True, "shape": "圆形", "colour": "红色",
                             "checks": {"length": {"nominal": 26, "tol": 2}}})
        self.assertEqual(judge(self.rec(shape=1), rules).status, "pass")
        v = judge(QcRecord.from_bytes(rec_bytes(3, x=40), QcExt.sample(shape=2, rgb=(30, 60, 210),
                                                                        hole=2).to_bytes()), rules)
        self.assertEqual(v.failed, ("长", "表面", "形状", "颜色"))
        self.assertEqual(v.text, "不合格（长、表面、形状、颜色）")

    def test_evqc1_record_cannot_pass_a_shape_rule(self):
        rules = parse_rules({"enabled": True, "shape": "圆形",
                             "checks": {"length": {"nominal": 26, "tol": 2}}})
        v = judge(QcRecord.from_bytes(rec_bytes(3)), rules)
        self.assertEqual((v.status, v.failed), ("fail", ("形状颜色无数据",)))

    def test_surface_can_be_turned_off(self):
        rules = parse_rules({"enabled": True, "surface": False, "shape": "三角形"})
        self.assertEqual(judge(self.rec(shape=3, stain=5), rules).status, "pass")

    def test_bad_types_rejected(self):
        with self.assertRaises(ValueError):
            parse_rules({"enabled": True, "shape": 3})

    def test_shipped_file(self):
        from pathlib import Path
        from qc_rules import RulesFile
        rules = RulesFile(Path(__file__).with_name("qc_rules.json")).rules
        self.assertTrue(rules.enabled and rules.surface)
        self.assertIsNone(rules.shape)
        self.assertEqual(judge(self.rec(), rules).status, "pass")
        self.assertEqual(judge(self.rec(edge=4), rules).status, "fail")


class Evqc2CardTest(unittest.TestCase):
    def test_card_geometry_and_untouched_frame(self):
        try:
            import numpy as np
            import PIL  # noqa: F401
        except ImportError:
            self.skipTest("Pillow not installed")
        from qc_card import bar_height, find_fonts, render_card
        rng = np.random.default_rng(2)
        for w, h in ((960, 540), (1920, 1080)):
            bgr = rng.integers(0, 256, (h, w, 3), dtype=np.uint8)
            before = bgr.copy()
            for rec, verdict in (
                    (QcRecord.from_bytes(rec_bytes(4), QcExt.sample(shape=3, stain=3).to_bytes()),
                     Verdict("fail", ("表面", "形状"))),
                    (QcRecord.from_bytes(rec_bytes(5), QcExt.sample().to_bytes()), Verdict("pass")),
                    (QcRecord.from_bytes(rec_bytes(6)), Verdict("disabled"))):
                card = render_card(bgr, rec, time.time(), verdict, find_fonts())
                self.assertEqual(card.shape, (h + bar_height(w), w, 3))
                self.assertTrue((bgr == before).all(), "render_card modified its input")
                self.assertTrue((card[:h] == bgr).all(), "the frame on the card was altered")


if __name__ == "__main__":
    unittest.main()
