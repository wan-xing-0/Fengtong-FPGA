"""10-31 (Anlogic_update): 三棱柱标准件 + 颜色/形状判定原因, FPGA 计数, 质检统计 /
CSV, 安防事件时间线, 报警推送, 网页新接口.

    py -3.14 -m unittest test_1031
"""
from __future__ import annotations

import json
import tempfile
import threading
import unittest
import urllib.request
from pathlib import Path

import qc_stats
import sec_events
from evs_control import Commander, ControlBar, _buttons
from evs_status import BoardState
from qc_record import (QC3_VERSION, STD_PARTS, QcExt, _ext_fields, make_qc_datagram,
                       std_deviations)
from qc_rules import Rules, judge
from test_qc import parse_qc, rec_bytes


def rec3(x=60, y=60, z=30, **ext):
    ext.setdefault("colour_cls", 2)
    ext.setdefault("shape", 2)
    d = make_qc_datagram(rec_bytes(5, x, y, z), 9, ext_raw=QcExt.sample3(**ext).to_bytes(),
                         version=QC3_VERSION)
    return parse_qc(d).record


OFF = Rules(False, {}, True, None, None)


class PacketTest(unittest.TestCase):
    def test_new_bits_round_trip(self):
        e = QcExt.sample3(std_mode=True, std_kind=3, colour_cls=5, shape=3, fpga_count=123, fpga_pass=99)
        v = int.from_bytes(e.to_bytes(), "big")
        self.assertEqual(v >> 108 & 3, 3)
        self.assertEqual((v >> 86 & 0x3FF, v >> 76 & 0x3FF), (123, 99))
        self.assertEqual(QcExt.from_bytes(e.to_bytes(), 3), e)

    def test_old_bit_with_std_on_is_the_cube(self):
        # a 10-29 bit: [112] set, [109:108] = 0
        v = (1 << 127) | (1 << 112) | (1 << 111) | (1 << 110)
        e = QcExt.from_bytes(v.to_bytes(16, "big"), 3)
        self.assertEqual(e.std_kind, 1)
        self.assertEqual(e.std_part["key"], "cube")
        self.assertEqual((e.fpga_count, e.fpga_pass), (0, 0))

    def test_any_mode_has_no_part(self):
        self.assertIsNone(QcExt.sample3(std_mode=False).std_part)


class VerdictTest(unittest.TestCase):
    def test_triangle_nominal_passes_its_own_part(self):
        r = rec3(60, 52, 30, std_mode=True, std_kind=3, colour_cls=5, shape=3, std_pass=True)
        self.assertEqual(judge(r, OFF).status, "pass")
        self.assertEqual(std_deviations(r), {"x": 0, "y": 0, "z": 0})

    def test_triangle_deviation_uses_52(self):
        r = rec3(60, 52, 30, std_mode=True, std_kind=3, colour_cls=5, shape=3)
        self.assertEqual(std_deviations(r)["y"], 0)
        self.assertEqual(std_deviations(rec3(60, 52, 30, std_mode=True))["y"], -8)   # the cube

    def test_all_four_reasons_in_osd_order(self):
        r = rec3(60, 40, 30, std_mode=True, std_kind=1, colour_cls=3, shape=1, stained=True, std_pass=False)
        self.assertEqual(judge(r, OFF).failed, ("颜色", "形状", "宽", "污渍"))

    def test_colour_rules_per_part(self):
        yellow_on_cube = rec3(std_mode=True, std_kind=1, colour_cls=5, std_pass=False)
        self.assertEqual(judge(yellow_on_cube, OFF).failed, ("颜色",))
        white_on_tri = rec3(60, 52, 30, std_mode=True, std_kind=3, colour_cls=2, shape=3, std_pass=False)
        self.assertEqual(judge(white_on_tri, OFF).failed, ("颜色",))
        gray_cube = rec3(std_mode=True, std_kind=1, colour_cls=1, std_pass=False)
        self.assertNotIn("颜色", judge(gray_cube, OFF).failed)        # 灰 passes on the cube
        orange_tri = rec3(60, 52, 30, std_mode=True, std_kind=3, colour_cls=4, shape=3, std_pass=False)
        self.assertNotIn("颜色", judge(orange_tri, OFF).failed)       # 橙 passes on the triangle

    def test_shape_rule_per_part(self):
        rect_on_tri = rec3(60, 52, 30, std_mode=True, std_kind=3, colour_cls=5, shape=2, std_pass=False)
        self.assertEqual(judge(rect_on_tri, OFF).failed, ("形状",))

    def test_unknown_colour_or_shape_not_blamed(self):
        r = rec3(std_mode=True, std_kind=1, colour_cls=15, shape_valid=False, std_pass=False)
        self.assertEqual(judge(r, OFF).failed, ("见屏幕判定",))

    def test_index_fields(self):
        r = rec3(60, 52, 31, std_mode=True, std_kind=3, colour_cls=5, shape=3, fpga_count=7, fpga_pass=6)
        f = _ext_fields(r.ext, r)
        self.assertEqual((f["std_kind"], f["std"]["name"], f["std"]["y"]), ("tri", "三棱柱", 52))
        self.assertEqual(f["deviation_mm"]["z"], 1)
        self.assertEqual((f["fpga_count"], f["fpga_pass"]), (7, 6))
        json.dumps(f, ensure_ascii=False)                              # JSON-safe (no tuples)


class StatusAndButtonsTest(unittest.TestCase):
    def test_tri_bit(self):
        # system_top eth_ui_state = {staff_pass, tri, face_hide, trk_view, std_on, mode(2)}
        b = BoardState.from_byte(((1 << 5) | (1 << 2) | 2) << 1)
        self.assertEqual((b.std_kind, b.view_text), (2, "三棱柱"))
        self.assertEqual(BoardState.from_byte(((1 << 2) | 2) << 1).std_kind, 1)
        self.assertEqual(BoardState.from_byte(2 << 1).std_kind, 0)

    def test_buttons(self):
        labels = [b.label for b in _buttons(BoardState.from_byte(2 << 1))]
        self.assertEqual(labels, ["原图", "安防", "质检", "任意", "标准件", "去皮"])   # 11-01: 三棱柱 hidden
        self.assertNotIn("人脸", [b.label for b in _buttons(None)])

    def test_tri_hidden_but_the_command_still_works(self):
        """11-01 (user): no 三棱柱 button; the RTL mode stays, so the command
        (arg 2) still encodes, and a board in 三棱柱 lights neither button."""
        sent = []
        cmd = Commander(("127.0.0.1", 9))
        cmd.send = lambda c, a=0: sent.append((c, a)) or True
        bar = ControlBar(cmd)
        bar.act(("std", 2))
        self.assertEqual(sent, [(3, 2)])
        bar.update_state(BoardState.from_byte(((1 << 5) | (1 << 2) | 2) << 1))
        labels = [b.label for b in _buttons(bar.state)]
        self.assertNotIn("三棱柱", labels)
        cube = [b for b in _buttons(bar.state) if b.label == "标准件"][0]
        self.assertFalse(bar._active(cube))
        self.assertFalse(bar.on_key(ord("4")))                         # 人脸 key gone
        cmd.sock.close()


def qrec(i, part="cube", verdict="pass", failed=(), dev=(0, 0, 0), **kw):
    r = {"file": f"c{i}.jpg", "day": "20261031", "epoch": 1000 + i, "time": f"2026-10-31T10:00:{i:02d}.000",
         "qc_seq": i, "x_mm": 60 + dev[0], "y_mm": 60 + dev[1], "z_mm": 30 + dev[2], "verdict": verdict,
         "failed": list(failed), "colour": "白色", "shape": "矩形", "stain": "无污渍"}
    if part == "any":
        r["mode"] = "any"
    else:
        r.update(mode="standard", deviation_mm={"x": dev[0], "y": dev[1], "z": dev[2]},
                 std={"tol_xy": 3, "tol_z": 5})
        if part != "old":
            r["std_kind"] = part
    r.update(kw)
    return r


class StatsTest(unittest.TestCase):
    RECS = [qrec(1), qrec(2, verdict="fail", failed=["长", "厚", "污渍"], dev=(5, 0, -7)),
            qrec(3, part="tri", verdict="fail", failed=["颜色"]), qrec(4, part="any", verdict="none"),
            qrec(5, part="old"), qrec(6, verdict="fail", failed=["见屏幕判定"]),
            qrec(7, fpga_count=12, fpga_pass=9)]

    def test_counts_and_rate(self):
        s = qc_stats.summary(self.RECS)
        self.assertEqual((s["total"], s["pass"], s["fail"], s["judged"]), (6, 3, 3, 6))
        self.assertEqual(s["pass_rate"], 0.5)

    def test_reasons_size_axes_merge(self):
        s = qc_stats.summary(self.RECS)
        self.assertEqual(s["reasons"], {"颜色": 1, "形状": 0, "尺寸": 1, "污渍": 1, "其他": 1})

    def test_part_filter_and_old_records(self):
        self.assertEqual(qc_stats.summary(self.RECS, "tri")["total"], 1)
        self.assertEqual(qc_stats.summary(self.RECS, "cube")["total"], 5)   # incl. the 10-29 record
        self.assertEqual(qc_stats.summary(self.RECS, "any")["pass_rate"], None)
        with self.assertRaises(ValueError):
            qc_stats.summary(self.RECS, "nope")

    def test_series_and_fpga(self):
        s = qc_stats.summary(self.RECS)
        self.assertEqual([p["n"] for p in s["series"]], [1, 2, 3, 5, 6, 7])   # standard records only
        self.assertEqual(s["series"][1]["z"], -7)
        self.assertEqual(s["tol"], {"xy": 3, "z": 5})
        self.assertEqual((s["fpga"]["count"], s["fpga"]["pass"]), (12, 9))

    def test_csv(self):
        data = qc_stats.to_csv(self.RECS)
        self.assertTrue(data.startswith("﻿".encode("utf-8")))
        rows = data.decode("utf-8-sig").splitlines()
        self.assertEqual(len(rows), 1 + 7)
        self.assertTrue(rows[0].startswith("时间,编号,模式"))
        self.assertIn("不合格", rows[2])
        self.assertIn("尺寸、污渍", rows[2])
        self.assertIn("三棱柱标准件", rows[3])


def srec(t, trig, i=0):
    return {"file": f"s{i}.jpg", "day": "20261031", "epoch": t, "time": f"2026-10-31T10:{int(t)//60:02d}:{int(t)%60:02d}.000",
            "trigger": trig}


class EventsTest(unittest.TestCase):
    RECS = [srec(0, "normal", 0), srec(10, "alarm_face", 1), srec(10.3, "alarm_face", 2), srec(15, "alarm_face", 3),
            srec(16, "staff", 4), srec(40, "alarm_face", 5), srec(41, "alarm_motion", 6), srec(60, "timer", 7)]

    def test_grouping(self):
        ev = sec_events.events(self.RECS)
        self.assertEqual([(e["kind"], e["count"]) for e in ev],
                         [("alarm_motion", 1), ("alarm_face", 1), ("staff", 1), ("alarm_face", 3)])
        oldest = ev[-1]
        self.assertEqual((oldest["file"], oldest["last_file"], oldest["end_epoch"]), ("s1.jpg", "s3.jpg", 15))

    def test_gap_splits(self):
        ev = sec_events.events([srec(0, "alarm_face", 1), srec(11, "alarm_face", 2)], gap_s=10)
        self.assertEqual(len(ev), 2)

    def test_new_alarms_since(self):
        self.assertEqual([e["start_epoch"] for e in sec_events.new_alarms(self.RECS, 12)], [40, 41])
        self.assertEqual(sec_events.new_alarms(self.RECS, 100), [])


class PushTest(unittest.TestCase):
    def test_missing_file_is_off(self):
        self.assertFalse(sec_events.PushConfig.load(Path(tempfile.gettempdir()) / "no_such_push.json").enabled)

    def test_load_and_validation(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "push.json"
            p.write_text(json.dumps({"enabled": True, "url": "https://example.invalid/hook", "format": "wecom"}), "utf-8")
            c = sec_events.PushConfig.load(p)
            self.assertTrue(c.enabled and c.format == "wecom")
            p.write_text(json.dumps({"enabled": True, "url": ""}), "utf-8")
            self.assertFalse(sec_events.PushConfig.load(p).enabled)          # no url = off
            p.write_text(json.dumps({"enabled": True, "url": "ftp://x"}), "utf-8")
            with self.assertRaises(ValueError):
                sec_events.PushConfig.load(p)
            p.write_text(json.dumps({"format": "sms"}), "utf-8")
            with self.assertRaises(ValueError):
                sec_events.PushConfig.load(p)

    def test_disabled_sends_nothing(self):
        calls = []
        p = sec_events.Pusher(sec_events.PushConfig(), post=lambda *a: calls.append(a))
        self.assertFalse(p.notify({"label": "陌生人", "start": "2026-10-31T10:00:00"}))
        self.assertEqual(calls, [])

    def test_rate_limit_and_formats(self):
        now = [0.0]
        calls = []
        cfg = sec_events.PushConfig(True, "https://example.invalid/x", "bark", 30.0)
        p = sec_events.Pusher(cfg, post=lambda *a: calls.append(a), clock=lambda: now[0])
        ev = {"label": "陌生人", "start": "2026-10-31T10:00:00.000", "kind": "alarm_face"}
        self.assertTrue(p.notify(ev))
        now[0] = 10
        self.assertFalse(p.notify(ev))
        now[0] = 31
        self.assertTrue(p.notify(ev))
        self.assertEqual((p.sent, p.skipped), (2, 1))
        self.assertEqual(json.loads(calls[0][1])["body"], "陌生人  2026-10-31 10:00:00")
        for fmt, check in (("wecom", lambda b: json.loads(b)["msgtype"] == "text"),
                           ("serverchan", lambda b: b.startswith(b"title=")),
                           ("json", lambda b: json.loads(b)["kind"] == "alarm_face")):
            url, body, hdr = sec_events.build_request(sec_events.PushConfig(True, "https://e.invalid", fmt), ev)
            self.assertTrue(check(body), fmt)

    def test_post_failure_is_swallowed(self):
        def boom(*a):
            raise OSError("down")
        p = sec_events.Pusher(sec_events.PushConfig(True, "https://e.invalid", "json", 0), post=boom)
        self.assertFalse(p.notify({"label": "x", "start": ""}))
        self.assertIn("down", p.last_error)

    def test_watcher_pushes_each_new_alarm_once(self):
        class Cache:
            recs = []
            def days(self): return ["20261031"]
            def records(self, d): return self.recs
        cache, calls = Cache(), []
        w = sec_events.AlarmWatcher(cache, sec_events.Pusher(
            sec_events.PushConfig(True, "https://e.invalid", "json", 0), post=lambda *a: calls.append(a)))
        w.since = 5
        # -30: an event from before since (more than GAP_S before the next one)
        cache.recs = [srec(-30, "alarm_face", 1), srec(10, "alarm_face", 2), srec(10.3, "alarm_face", 3)]
        self.assertEqual(w.check_once(), 1)
        self.assertEqual(w.check_once(), 0)                              # same event: not again
        cache.recs = cache.recs + [srec(30, "alarm_motion", 4)]
        self.assertEqual(w.check_once(), 1)
        self.assertEqual(len(calls), 2)


class ServerTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from snapshot_server import make_server
        cls.tmp = tempfile.TemporaryDirectory()
        root = Path(cls.tmp.name)
        day = root / "20261031"
        day.mkdir()
        (day / "index.jsonl").write_text("".join(json.dumps(r) + "\n" for r in EventsTest.RECS), "utf-8")
        qday = root / "qc" / "20261031"
        qday.mkdir(parents=True)
        (qday / "index.jsonl").write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in StatsTest.RECS), "utf-8")
        cls.srv = make_server(root, "127.0.0.1", 0, "k1", quiet=True)
        cls.base = f"http://127.0.0.1:{cls.srv.server_address[1]}"
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()
        cls.srv.server_close()
        cls.tmp.cleanup()

    def get(self, path):
        # the cookie, as a browser sends it after the first ?k= visit (/?k= itself redirects)
        req = urllib.request.Request(self.base + path, headers={"Cookie": "evs_k=k1"})
        with urllib.request.urlopen(req) as r:
            return r.headers, r.read()

    def test_qcstats(self):
        _, b = self.get("/api/qcstats?day=all&part=all")
        self.assertEqual(json.loads(b)["total"], 6)
        _, b = self.get("/api/qcstats?day=20261031&part=tri")
        self.assertEqual(json.loads(b)["total"], 1)

    def test_qccsv(self):
        h, b = self.get("/api/qccsv?day=20261031&part=cube")
        self.assertIn("attachment", h["Content-Disposition"])
        self.assertEqual(len(b.decode("utf-8-sig").splitlines()), 1 + 5)

    def test_qcxlsx(self):
        import io, zipfile
        h, b = self.get('/api/qcxlsx?day=all&part=all')
        self.assertIn('.xlsx', h['Content-Disposition'])
        with zipfile.ZipFile(io.BytesIO(b)) as z:
            self.assertIn('2026-10-31', z.read('xl/workbook.xml').decode())

    def test_timeline_and_alerts(self):
        _, b = self.get("/api/timeline?day=20261031")
        d = json.loads(b)
        self.assertEqual((d["total"], d["events"][0]["kind"]), (4, "alarm_motion"))
        _, b = self.get("/api/alerts?since=12")
        self.assertEqual([e["start_epoch"] for e in json.loads(b)["events"]], [40, 41])

    def test_page_has_new_tabs(self):
        _, b = self.get("/")
        page = b.decode("utf-8")
        for s in ('data-v="tl"', 'data-v="st"', "/api/qcstats", "/api/alerts", "navigator.vibrate"):
            self.assertIn(s, page)

    def test_bad_args(self):
        import urllib.error
        for p in ("/api/qcstats?day=bad", "/api/qcstats?day=all&part=x", "/api/alerts?since=x"):
            with self.assertRaises(urllib.error.HTTPError) as cm:
                self.get(p)
            self.assertEqual(cm.exception.code, 400)
            cm.exception.close()


if __name__ == "__main__":
    unittest.main()
