"""把一次长时间 evs_receiver 运行的日志判定为 PASS / FAIL。

用途是回归保护：并入队友新版工程、或改动 RTL / 主机程序之后，用同一把尺子
量一次，和基线日志对比，而不是靠肉眼和印象。

验收要求（2026-09-23）：**30 分钟内没有肉眼可见的卡顿和花屏，稳定运行；
之后并入新工程、升级优化时不能恶化。** 所以判据分三组：

- 花屏：错误包、abort 增长、FIFO 触顶 —— 任何一项非零都是硬失败，
  v1.0 基线里它们全为零。
- 卡顿：任何一个 2 秒采样低于 30 fps 就算一次肉眼可见的卡顿（60 fps 下
  掉到 30 以下，2 秒内少了一半画面，看得出来）。单帧丢失不算。
- 不恶化：给了 --baseline 时，丢帧率、p5 帧率、卡顿总时长都不能比基线差。

板侧 frame_sequence 停滞只在「确实收到了新的状态包、序号却没动」时才算
失败。主机接收程序卡住时状态包也会积压，打印出来的是同一份旧遥测 ——
那是主机的问题，不能记到 FPGA 头上。

用法（PowerShell）::

    py evs_receiver.py --port 6001 2>&1 | Tee-Object -FilePath run.log
    py check_stability.py run.log --baseline stability_30min.log

Tee-Object 写出的是 UTF-16，这里自动识别。
"""
from __future__ import annotations

import argparse
import re
import sys

# 每个 "显示:" 采样行代表的秒数，与 evs_receiver.py 的打印周期一致。
SAMPLE_SECONDS = 2.0

# 低于这个帧率视为肉眼可见的卡顿。
STUTTER_FPS = 30.0
# 验收要求的最短运行时长。
MIN_MINUTES = 30.0

# 与基线对比时允许的误差：丢帧率（百分点）、p5 帧率（fps）。
DROP_TOLERANCE_PCT = 0.5
P5_TOLERANCE_FPS = 1.0

STAT_RE = re.compile(
    r"显示:\s*([\d.]+)\s*fps.*?正确\s*(\d+).*?错误\s*(\d+).*?状态\s*(\d+).*?"
    r"完成\s*(\d+).*?丢弃\s*(\d+)"
)
FPGA_RE = re.compile(r"^\s*FPGA:\s*(.*)$")


class Sample:
    __slots__ = ("fps", "ok", "bad", "status", "complete", "dropped", "fpga")

    def __init__(self, fps, ok, bad, status, complete, dropped):
        self.fps = fps
        self.ok = ok
        self.bad = bad
        self.status = status
        self.complete = complete
        self.dropped = dropped
        # 紧跟在这个采样行后面的 FPGA 遥测，没有则为 None。
        self.fpga: dict[str, int] | None = None


def read_text(path: str) -> str:
    raw = open(path, "rb").read()
    if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
        return raw.decode("utf-16", errors="replace")
    # 没有 BOM 的 UTF-16：ASCII 字符的高字节全是 0。
    if raw[1:200:2].count(0) > 50:
        return raw.decode("utf-16-le", errors="replace")
    return raw.decode("utf-8-sig", errors="replace")


def parse(path: str) -> list[Sample]:
    samples: list[Sample] = []
    for line in read_text(path).splitlines():
        hit = STAT_RE.search(line)
        if hit:
            samples.append(Sample(float(hit.group(1)), *(int(hit.group(i)) for i in range(2, 7))))
            continue
        hit = FPGA_RE.match(line)
        if hit and samples:
            fields = {}
            for token in hit.group(1).split():
                if "=" in token:
                    key, _, value = token.partition("=")
                    # bridge=STREAM 这类非数字字段这里不需要，跳过即可。
                    if value.lstrip("-").isdigit():
                        fields[key] = int(value)
            if fields:
                samples[-1].fpga = fields
    return samples


def percentile(values: list[float], pct: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    idx = int(round((len(ordered) - 1) * pct / 100.0))
    return ordered[idx]


def find_stutter_events(samples: list[Sample], stutter_fps: float) -> list[tuple[int, float, float]]:
    """返回 [(起始采样序号, 持续秒数, 该段最低 fps)]，连续低帧率采样合并为一次。"""
    events = []
    run_start = None
    run_min = 0.0
    for i, sample in enumerate(samples):
        if sample.fps < stutter_fps:
            if run_start is None:
                run_start, run_min = i, sample.fps
            else:
                run_min = min(run_min, sample.fps)
        elif run_start is not None:
            events.append((run_start, (i - run_start) * SAMPLE_SECONDS, run_min))
            run_start = None
    if run_start is not None:
        events.append((run_start, (len(samples) - run_start) * SAMPLE_SECONDS, run_min))
    return events


def summarize(samples: list[Sample], stutter_fps: float) -> dict:
    fps_values = [s.fps for s in samples]
    last = samples[-1]
    total_frames = last.complete + last.dropped
    events = find_stutter_events(samples, stutter_fps)
    return {
        "minutes": len(samples) * SAMPLE_SECONDS / 60.0,
        "median": percentile(fps_values, 50),
        "p5": percentile(fps_values, 5),
        "min": min(fps_values),
        "drop_pct": 100.0 * last.dropped / total_frames if total_frames else 0.0,
        "events": events,
        "stutter_s": sum(e[1] for e in events),
    }


def check_fpga(samples: list[Sample], failures: list[str], notes: list[str]) -> None:
    with_fpga = [s for s in samples if s.fpga]
    if not with_fpga:
        notes.append("日志里没有 FPGA 遥测行，无法判断板侧健康度"
                     "（确认 EVDBG1 状态包有到达）")
        return

    aborts = [s.fpga["abort_count"] for s in with_fpga if "abort_count" in s.fpga]
    if aborts and max(aborts) != min(aborts):
        failures.append(f"abort_count 增长了：{min(aborts)} → {max(aborts)}"
                        "（说明板上吞吐余量不够，不再是纯主机问题）")
    elif aborts:
        print(f"abort_count     : 恒为 {aborts[0]}（未增长）")

    if any(s.fpga.get("fifo_full") for s in with_fpga):
        failures.append("fifo_full 被观测到为 1 —— 供应商 FIFO 会静默丢写，"
                        "可能造成整帧字节错位")
    if any(s.fpga.get("fifo_afull") for s in with_fpga):
        notes.append("fifo_afull 出现过 1（未必有害，但说明写侧曾接近高水位）")

    # 只有两次遥测之间确实到了新的状态包，序号不动才是板侧停滞。
    board_stalls = host_stale = 0
    for prev, cur in zip(with_fpga, with_fpga[1:]):
        if cur.fpga.get("frame_sequence") != prev.fpga.get("frame_sequence"):
            continue
        if cur.status > prev.status:
            board_stalls += 1
        else:
            host_stale += 1
    if board_stalls:
        failures.append(f"frame_sequence 有 {board_stalls} 次在收到新状态包后仍没推进（板侧停滞）")
    else:
        seqs = [s.fpga["frame_sequence"] for s in with_fpga if "frame_sequence" in s.fpga]
        if len(seqs) >= 2:
            print(f"frame_sequence  : {seqs[0]} → {seqs[-1]}，板侧全程推进")
    if host_stale:
        notes.append(f"有 {host_stale} 次遥测重复且期间没收到新状态包 —— 主机接收端卡住，"
                     "不是板侧问题")


def main() -> int:
    # 输出到管道（`!` 前缀、重定向）时 Python 在中文 Windows 上默认用 GBK，
    # 接收方按 UTF-8 解就是乱码。控制台本身不受影响。
    if not sys.stdout.isatty():
        sys.stdout.reconfigure(encoding="utf-8")
    parser =argparse.ArgumentParser(description="判定一次 evs_receiver 长测是否通过")
    parser.add_argument("logfile", help="evs_receiver 的输出日志")
    parser.add_argument("--baseline", help="对照日志；给了就检查「不恶化」")
    parser.add_argument("--stutter-fps", type=float, default=STUTTER_FPS)
    parser.add_argument("--min-minutes", type=float, default=MIN_MINUTES)
    args = parser.parse_args()

    samples = parse(args.logfile)
    if not samples:
        print(f"没有解析到任何采样行，确认这是 evs_receiver 的日志：{args.logfile}")
        return 2

    cur = summarize(samples, args.stutter_fps)
    last, first = samples[-1], samples[0]
    print(f"日志            : {args.logfile}")
    print(f"时长            : {cur['minutes']:.1f} 分钟（{len(samples)} 个采样）")
    print(f"帧率 中位/p5/最低: {cur['median']:.1f} / {cur['p5']:.1f} / {cur['min']:.1f} fps")
    print(f"完成 / 丢弃     : {last.complete} / {last.dropped}（丢帧率 {cur['drop_pct']:.1f}%）")
    print(f"正确包 / 错误包 : {last.ok} / {last.bad}")

    failures: list[str] = []
    notes: list[str] = []

    # 验收窗口的最后一个采样可能落在 30 分钟前一点点，留一个采样的余量。
    if cur["minutes"] + SAMPLE_SECONDS / 60.0 < args.min_minutes:
        failures.append(f"只运行了 {cur['minutes']:.1f} 分钟，验收要求至少 {args.min_minutes:.0f} 分钟")

    # --- 花屏：v1.0 基线里这些全为零 ---
    if last.bad != first.bad or last.bad != 0:
        failures.append(f"出现错误包 {last.bad} 个（基线为 0）")
    check_fpga(samples, failures, notes)

    # --- 卡顿 ---
    events = cur["events"]
    if events:
        worst = max(e[1] for e in events)
        failures.append(f"{len(events)} 次肉眼可见的卡顿（2 秒采样低于 {args.stutter_fps:.0f} fps），"
                        f"累计 {cur['stutter_s']:.0f} 秒，最长 {worst:.0f} 秒")
        for start, seconds, low in events[:8]:
            at_min = start * SAMPLE_SECONDS / 60.0
            print(f"  卡顿事件：第 {at_min:.1f} 分钟起，持续 {seconds:.0f} 秒，最低 {low:.1f} fps")
        if len(events) > 8:
            print(f"  （另有 {len(events) - 8} 次未列出）")
    else:
        print(f"卡顿            : 无（判据：任一 2 秒采样低于 {args.stutter_fps:.0f} fps）")

    # --- 不恶化 ---
    if args.baseline:
        base_samples = parse(args.baseline)
        if not base_samples:
            failures.append(f"基线日志解析不到采样行：{args.baseline}")
        else:
            base = summarize(base_samples, args.stutter_fps)
            print(f"基线            : {args.baseline}（{base['minutes']:.1f} 分钟）")
            print(f"  丢帧率  {base['drop_pct']:.1f}% → {cur['drop_pct']:.1f}%")
            print(f"  p5 帧率 {base['p5']:.1f} → {cur['p5']:.1f} fps")
            print(f"  卡顿    {base['stutter_s']:.0f} → {cur['stutter_s']:.0f} 秒")
            if cur["drop_pct"] > base["drop_pct"] + DROP_TOLERANCE_PCT:
                failures.append(f"丢帧率比基线恶化：{base['drop_pct']:.1f}% → {cur['drop_pct']:.1f}%")
            if cur["p5"] < base["p5"] - P5_TOLERANCE_FPS:
                failures.append(f"p5 帧率比基线恶化：{base['p5']:.1f} → {cur['p5']:.1f} fps")
            if cur["stutter_s"] > base["stutter_s"]:
                failures.append(f"卡顿时长比基线恶化：{base['stutter_s']:.0f} → {cur['stutter_s']:.0f} 秒")

    for note in notes:
        print(f"提示            : {note}")

    print()
    if failures:
        print("=== 判定：FAIL ===")
        for item in failures:
            print(f"  - {item}")
        return 1
    print("=== 判定：PASS ===")
    print("  满 30 分钟、无错误包、无 abort 增长、无 FIFO 触顶、板侧帧序号连续、无卡顿"
          + ("、未比基线恶化。" if args.baseline else "。"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
