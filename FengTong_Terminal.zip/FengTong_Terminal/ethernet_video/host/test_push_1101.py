"""11-01: phone push + page banner at the START of an alarm (video mode).

    py -3.14 -m unittest test_push_1101
"""
from __future__ import annotations

import json
import tempfile
import threading
import unittest
import urllib.request
from datetime import datetime
from pathlib import Path

import sec_events
from clips import ClipRecorder


class AlertLogTest(unittest.TestCase):
    def test_add_writes_one_line_in_todays_folder(self):
        with tempfile.TemporaryDirectory() as d:
            log = sec_events.AlertLog(Path(d), clock=lambda: 1793500000.0)
            self.assertTrue(log.add("alarm_face"))
            day = datetime.fromtimestamp(1793500000.0).strftime("%Y%m%d")
            rows = [json.loads(l) for l in (Path(d) / day / "alerts.jsonl").read_text("utf-8").splitlines()]
            self.assertEqual(len(rows), 1)
            self.assertEqual((rows[0]["trigger"], rows[0]["label"], rows[0]["epoch"]),
                             ("alarm_face", "陌生人", 1793500000.0))

    def test_never_raises(self):
        with tempfile.TemporaryDirectory() as d:
            f = Path(d) / "afile"
            f.write_text("x")
            log = sec_events.AlertLog(f)                 # a file where a folder is needed
            self.assertFalse(log.add("alarm_motion"))
            self.assertIn("Error", log.last_error or "")


class FeedTest(unittest.TestCase):
    def mk(self, d, day, rows):
        p = Path(d) / day
        p.mkdir(parents=True, exist_ok=True)
        (p / "alerts.jsonl").write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in rows), "utf-8")

    def test_fresh_after_since_oldest_first(self):
        with tempfile.TemporaryDirectory() as d:
            self.mk(d, "20261101", [
                {"epoch": 10, "time": "2026-11-01T10:00:10.000", "trigger": "alarm_face", "label": "陌生人"},
                {"epoch": 50, "time": "2026-11-01T10:00:50.000", "trigger": "alarm_motion", "label": "人员入侵"},
                {"epoch": 90, "time": "2026-11-01T10:01:30.000", "trigger": "staff", "label": "员工通过"}])
            feed = sec_events.AlertFeed(Path(d))
            got = feed.fresh(20)
            self.assertEqual([(e["kind"], e["start_epoch"]) for e in got], [("alarm_motion", 50)])
            self.assertEqual(got[0]["file"], "")                       # no picture yet
            self.assertEqual([e["start_epoch"] for e in feed.fresh(0)], [10, 50])   # staff is not an alarm

    def test_incremental_and_partial_line(self):
        with tempfile.TemporaryDirectory() as d:
            self.mk(d, "20261101", [{"epoch": 5, "time": "t", "trigger": "alarm_face"}])
            feed = sec_events.AlertFeed(Path(d))
            self.assertEqual(len(feed.fresh(0)), 1)
            with open(Path(d) / "20261101" / "alerts.jsonl", "a", encoding="utf-8") as f:
                f.write('{"epoch": 9, "time": "t", "trigger": "alarm_mo')            # still being written
            self.assertEqual(len(feed.fresh(0)), 1)
            with open(Path(d) / "20261101" / "alerts.jsonl", "a", encoding="utf-8") as f:
                f.write('tion"}\n')
            self.assertEqual([e["start_epoch"] for e in feed.fresh(0)], [5, 9])

    def test_no_alerts_file_falls_back_to_the_index(self):
        with tempfile.TemporaryDirectory() as d:
            day = Path(d) / "20261101"
            day.mkdir()
            (day / "index.jsonl").write_text(json.dumps(
                {"file": "a_clip.jpg", "video": "a_clip.mp4", "time": "2026-11-01T10:00:00.000",
                 "epoch": 100.0, "trigger": "alarm_face"}) + "\n", "utf-8")
            from snapshot_server import IndexCache
            feed = sec_events.AlertFeed(Path(d), IndexCache(Path(d)))
            self.assertEqual([e["start_epoch"] for e in feed.fresh(0)], [100.0])

    def test_alerts_file_wins_over_the_index_on_the_same_day(self):
        with tempfile.TemporaryDirectory() as d:
            day = Path(d) / "20261101"
            day.mkdir()
            (day / "index.jsonl").write_text(json.dumps(
                {"file": "a_clip.jpg", "video": "a_clip.mp4", "time": "t", "epoch": 100.0,
                 "trigger": "alarm_face"}) + "\n", "utf-8")
            self.mk(d, "20261101", [{"epoch": 90, "time": "t", "trigger": "alarm_face"}])
            from snapshot_server import IndexCache
            feed = sec_events.AlertFeed(Path(d), IndexCache(Path(d)))
            self.assertEqual([e["start_epoch"] for e in feed.fresh(0)], [90])      # not 90 AND 100

    def test_newest_day_is_read(self):
        with tempfile.TemporaryDirectory() as d:
            self.mk(d, "20261031", [{"epoch": 1, "time": "t", "trigger": "alarm_face"}])
            self.mk(d, "20261101", [{"epoch": 2, "time": "t", "trigger": "alarm_motion"}])
            self.assertEqual([e["start_epoch"] for e in sec_events.AlertFeed(Path(d)).fresh(0)], [2])


class WatcherTest(unittest.TestCase):
    def test_pushes_each_new_alarm_once_the_moment_it_is_logged(self):
        with tempfile.TemporaryDirectory() as d:
            sent = []
            cfg = sec_events.PushConfig(True, "https://example.invalid/k", "bark", 0.0)
            w = sec_events.AlarmWatcher(sec_events.AlertFeed(Path(d)),
                                        sec_events.Pusher(cfg, post=lambda *a: sent.append(a)))
            w.since = 1000.0
            self.assertEqual(w.check_once(), 0)
            log = sec_events.AlertLog(Path(d), clock=lambda: 1001.0)
            log.add("alarm_face")
            self.assertEqual(w.check_once(), 1)
            self.assertEqual(w.check_once(), 0)                     # not again
            self.assertEqual(len(sent), 1)
            self.assertIn("陌生人", json.loads(sent[0][1])["body"])
            log2 = sec_events.AlertLog(Path(d), clock=lambda: 1050.0)
            log2.add("alarm_motion")
            self.assertEqual(w.check_once(), 1)
            self.assertEqual(len(sent), 2)

    def test_old_alarms_before_start_are_not_pushed(self):
        with tempfile.TemporaryDirectory() as d:
            sent = []
            sec_events.AlertLog(Path(d), clock=lambda: 500.0).add("alarm_face")
            w = sec_events.AlarmWatcher(sec_events.AlertFeed(Path(d)), sec_events.Pusher(
                sec_events.PushConfig(True, "https://e.invalid", "json", 0), post=lambda *a: sent.append(a)))
            w.since = 1000.0
            self.assertEqual(w.check_once(), 0)
            self.assertEqual(sent, [])

    def test_test_command(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "push.json"
            self.assertEqual(sec_events._main(["x", "test", str(p)]), 1)          # no file
            p.write_text(json.dumps({"enabled": False, "url": "https://e.invalid"}), "utf-8")
            self.assertEqual(sec_events._main(["x", "test", str(p)]), 1)          # disabled
            self.assertEqual(sec_events._main(["x"]), 2)


class ClipHookTest(unittest.TestCase):
    def rec(self, hook):
        # hold_s 1.4 = the receiver's ALARM_HOLD_S: bursts come about once a second
        return ClipRecorder(lambda *_: None, fps=15, pre_s=0.0, post_s=0.2, max_s=2.0, hold_s=1.4,
                            on_alarm_start=hook)

    def test_fires_once_per_alarm_not_per_burst(self):
        seen = []
        r = self.rec(lambda k, w: seen.append((k, w)))
        r.on_alarm(0.0, True, 3, None, 100.0)
        r.on_alarm(1.0, True, 3, None, 101.0)                      # same alarm, next burst
        r.on_alarm(2.0, True, 2, None, 102.0)
        self.assertEqual(seen, [("alarm_motion", 100.0)])

    def test_face_level_kind(self):
        seen = []
        r = self.rec(lambda k, w: seen.append(k))
        r.on_alarm(0.0, True, 2, None, 1.0)
        self.assertEqual(seen, ["alarm_face"])

    def test_a_new_alarm_after_the_clip_ended_fires_again(self):
        seen = []
        r = self.rec(lambda k, w: seen.append(w))
        r.on_alarm(0.0, True, 3, None, 100.0)
        r.on_alarm(1.0, False, 3, None, 101.0)
        for i in range(10):                                          # frames run the clip out
            r.on_frame(1.0 + 0.1 * (i + 1), 101.0 + 0.1 * (i + 1), object())
        self.assertIsNone(r.clip)
        r.on_alarm(5.0, True, 3, None, 105.0)
        self.assertEqual(seen, [100.0, 105.0])

    def test_carry_on_clip_of_a_long_alarm_does_not_fire(self):
        seen = []
        r = self.rec(lambda k, w: seen.append(w))
        r.on_alarm(0.0, True, 3, None, 100.0)
        t = 0.0
        for i in range(60):                                          # 4 s of frames, max_s 2
            t += 1 / 15
            r.on_alarm(t, True, 3, None, 100.0 + t) if i % 15 == 14 else None
            r.on_frame(t, 100.0 + t, object())
        self.assertGreaterEqual(r.clips, 1)                          # it did roll over to a second clip
        self.assertEqual(seen, [100.0])

    def test_a_failing_hook_does_not_stop_the_recorder(self):
        def boom(*_):
            raise RuntimeError("disk full")
        r = self.rec(boom)
        r.on_alarm(0.0, True, 3, None, 100.0)
        self.assertIsNotNone(r.clip)

    def test_no_hook_is_fine(self):
        r = self.rec(None)
        r.on_alarm(0.0, True, 3, None, 100.0)
        self.assertIsNotNone(r.clip)


class ReceiverWiringTest(unittest.TestCase):
    """evs_receiver's main loop needs a window and a board, so the wiring is
    checked on its source: the recorder must get AlertLog.add as its hook."""

    def test_recorder_gets_the_alert_log(self):
        src = Path(__file__).with_name("evs_receiver.py").read_text(encoding="utf-8")
        self.assertIn("alert_log = AlertLog(Path(args.snapshot_dir))", src)
        self.assertIn("on_alarm_start=alert_log.add", src)


class ServerAlertsTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from snapshot_server import make_server
        cls.tmp = tempfile.TemporaryDirectory()
        cls.root = Path(cls.tmp.name)
        cls.srv = make_server(cls.root, "127.0.0.1", 0, "k1", quiet=True)
        cls.base = f"http://127.0.0.1:{cls.srv.server_address[1]}"
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()
        cls.srv.server_close()
        cls.tmp.cleanup()

    def get(self, path):
        req = urllib.request.Request(self.base + path, headers={"Cookie": "evs_k=k1"})
        with urllib.request.urlopen(req) as r:
            return r.read()

    def test_api_alerts_serves_an_alarm_with_no_video_yet(self):
        sec_events.AlertLog(self.root, clock=lambda: 2000.0).add("alarm_face")
        d = json.loads(self.get("/api/alerts?since=1999"))
        self.assertEqual([(e["kind"], e["label"], e["file"]) for e in d["events"]], [("alarm_face", "陌生人", "")])
        self.assertEqual(json.loads(self.get("/api/alerts?since=2000"))["events"], [])

    def test_page_handles_an_alert_without_a_picture(self):
        page = self.get("/").decode("utf-8")
        for s in ("img.hidden = true", 'select("tl")', "e.file"):
            self.assertIn(s, page)


if __name__ == "__main__":
    unittest.main()
