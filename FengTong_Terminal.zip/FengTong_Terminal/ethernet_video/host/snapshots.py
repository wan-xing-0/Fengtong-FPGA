"""Still capture for the security use case (ETHERNET_V1.md §16).

2026-10-09: with a full-resolution FPGA bit, SecurityPolicy (below) keeps the
alarm pictures and one normal picture a minute; IntervalPolicy remains the
single-frame fallback for a bit without bursts.  The original stage-B notes:


Stage B is untriggered: one JPEG per interval while the receiver runs.  The
motion detector is not good enough yet, so *when* to capture is a separate
policy object; stage B+ swaps IntervalPolicy for an alarm-driven one without
touching the writer or the files it produces.

The writer never blocks the display path.  JPEG encoding plus a disk write
take several milliseconds and a slow disk can take far longer, so they run on
their own thread behind a short queue; if the queue is full the snapshot is
dropped and counted rather than waited for.

Layout, one directory per day so a remote viewer (stage C) can list cheaply::

    <root>/20260928/143015_123_seq00012345.jpg
    <root>/20260928/index.jsonl     one JSON object per saved image
"""
from __future__ import annotations

import json
import queue
import threading
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Callable

QUEUE_DEPTH = 16     # 10-29: an AlarmBuffer hands over ~4 pictures at once
DEFAULT_JPEG_QUALITY = 90


class IntervalPolicy:
    """Capture at most once per `interval_s`, on the first frame at or after
    each due time.  Missed intervals (receiver stalled) are not made up."""

    trigger = "timer"

    def __init__(self, interval_s: float) -> None:
        if interval_s <= 0:
            raise ValueError("interval_s must be positive")
        self.interval_s = interval_s
        self.next_due: float | None = None

    def should_capture(self, now: float, flags: int = 0) -> bool:
        # `flags` is the EVS1 header flags byte.  Ignored here; an alarm policy
        # will read the reserved motion bit from it (ETHERNET_V1.md §16.3).
        if self.next_due is not None and now < self.next_due:
            return False
        # Anchor to the schedule while keeping up, but never schedule into the
        # past after a stall -- that would fire a burst on recovery.
        due = (now if self.next_due is None else self.next_due) + self.interval_s
        self.next_due = due if due > now else now + self.interval_s
        return True


EVENT_GAP_S = 6.0


class SecurityPolicy:
    """Which security bursts to keep (2026-10-09, the user's rule).

    The FPGA sends one burst a second in security mode, already classified:
    alarm level 2 / 3 while someone is there, normal while nobody is.  Keep:

      * every alarm burst, at most one per `alarm_interval_s` (default 1 s,
        i.e. all of them);
      * one normal burst per `normal_interval_s` (2026-10-29: default 30 min).
        Normal bursts do not exist while an alarm runs, so a record that falls
        due then is taken from the first normal burst after it -- one picture,
        not a catch-up burst (IntervalPolicy never schedules into the past).
      * 2026-10-29: every staff record (the FPGA sends one per staff pass, the
        green "员工 PASS" picture) -- see decide_staff.

    Alarm pictures closer than EVENT_GAP_S to the previous one belong to the
    same EVENT; the event id is the date and time of its first picture.  A
    picture's level is the level at that moment, so one event can start as
    "motion, no face" and continue as "face seen".
    """

    def __init__(self, alarm_interval_s: float = 1.0, normal_interval_s: float = 1800.0,
                 event_gap_s: float = EVENT_GAP_S) -> None:
        self.alarm_interval_s = alarm_interval_s
        self.normal = IntervalPolicy(normal_interval_s)
        self.event_gap_s = event_gap_s
        self._last_alarm: float | None = None
        self._event: str | None = None
        self.events = 0
        self.staff = 0

    def decide_staff(self) -> tuple[bool, None]:
        """A staff record: always kept, not part of an alarm event."""
        self.staff += 1
        return True, None

    def decide(self, now: float, alarm: bool, wall_time: float) -> tuple[bool, str | None]:
        """(keep?, event id or None) for one burst."""
        if not alarm:
            return self.normal.should_capture(now), None
        if self._last_alarm is None or now - self._last_alarm > self.event_gap_s:
            self._event = datetime.fromtimestamp(wall_time).strftime("%Y%m%d_%H%M%S")
            self.events += 1
            self._last_alarm = now
            return True, self._event
        # Slack for frame jitter: bursts arrive once a second, and a 1 s
        # interval must not drop every other one.  2026-10-29: alarm pictures
        # now come from live frames at ~0.3 s, so the slack scales with it.
        if now - self._last_alarm >= self.alarm_interval_s - min(0.2, 0.2 * self.alarm_interval_s):
            self._last_alarm = now
            return True, self._event
        return False, self._event


class AlarmBuffer:
    """Alarm pictures from live frames, kept only once the FPGA confirms them
    (2026-10-29, user: the last few alarm pictures showed an empty room).

    The FPGA says "alarm, someone there" once a second (an alarm burst).
    Live frames taken in between are HELD here; the next alarm burst confirms
    them (they go to the writer), anything else drops them: a normal burst,
    no burst for `hold_s` (the person left -- the FPGA sends nothing while a
    level is up but nobody is there -- or staff verification began).  So
    every saved alarm picture lies between two "someone is there" reports.
    The cost: the pictures reach the disk ~1 s late, and the last <= 1 s of a
    real alarm is not kept.
    """

    def __init__(self, hold_s: float = 1.4) -> None:
        self.hold_s = hold_s
        self.pending: list = []
        self.until = 0.0
        self.src = 2
        self.dropped = 0

    def active(self, now: float) -> bool:
        return now < self.until

    def add(self, snap) -> None:
        self.pending.append(snap)

    def on_burst(self, now: float, alarm: bool, src: int = 2) -> list:
        """A security burst arrived.  Returns the pictures it confirms."""
        if alarm:
            out, self.pending = self.pending, []
            self.until = now + self.hold_s
            self.src = src
            return out
        self.drop()
        self.until = 0.0
        return []

    def expire(self, now: float) -> None:
        if self.pending and now >= self.until:
            self.drop()

    def drop(self) -> None:
        self.dropped += len(self.pending)
        self.pending = []


@dataclass
class Snapshot:
    # BGR ndarray, never mutated after submit() -- or a zero-argument
    # callable that builds one on the writer thread (fullres.StitchedImage:
    # stitching four frames is not the display thread's job).  A callable may
    # carry .resolution / .missing, which go into the index line.
    image: object
    wall_time: float       # time.time() when the frame completed
    sequence: int
    session_id: int
    trigger: str           # timer | manual | normal | alarm_face | alarm_motion | staff
    event: str | None = None   # security alarm event id
    level: int | None = None   # alert_ctrl level 2 / 3 for an alarm picture


def encode_jpeg(image, quality: int) -> bytes:
    import cv2
    ok, buf = cv2.imencode(".jpg", image, [cv2.IMWRITE_JPEG_QUALITY, quality])
    if not ok:
        raise RuntimeError("JPEG 编码失败")
    return buf.tobytes()


def snapshot_name(wall_time: float, sequence: int) -> tuple[str, str]:
    """(day directory, file name) for a snapshot."""
    t = datetime.fromtimestamp(wall_time)
    return (t.strftime("%Y%m%d"),
            f"{t.strftime('%H%M%S')}_{t.microsecond // 1000:03d}_seq{sequence:08d}.jpg")


class SnapshotWriter:
    def __init__(self, root: Path, quality: int = DEFAULT_JPEG_QUALITY,
                 encoder: Callable[[object, int], bytes] = encode_jpeg) -> None:
        self.root = Path(root)
        self.quality = quality
        self.encoder = encoder
        self.queue: queue.Queue[Snapshot | None] = queue.Queue(QUEUE_DEPTH)
        self.saved = 0
        self.dropped = 0      # queue full: writer could not keep up
        self.failed = 0       # encode or disk error
        self.last_error: str | None = None
        self.last_path: Path | None = None
        self._thread = threading.Thread(target=self._run, name="snapshot-writer",
                                        daemon=True)
        self._thread.start()

    def submit(self, snap: Snapshot) -> bool:
        try:
            self.queue.put_nowait(snap)
            return True
        except queue.Full:
            self.dropped += 1
            return False

    def close(self, timeout: float = 5.0) -> None:
        """Flush what is queued, then stop the thread."""
        self.queue.put(None)
        self._thread.join(timeout)

    def _run(self) -> None:
        while True:
            snap = self.queue.get()
            if snap is None:
                return
            try:
                self._write(snap)
                self.saved += 1
            except Exception as exc:  # keep capturing after a bad write
                self.failed += 1
                self.last_error = f"{type(exc).__name__}: {exc}"

    def _write(self, snap: Snapshot) -> None:
        day, name = snapshot_name(snap.wall_time, snap.sequence)
        directory = self.root / day
        directory.mkdir(parents=True, exist_ok=True)
        image = snap.image() if callable(snap.image) else snap.image
        data = self.encoder(image, self.quality)
        # Write under a temporary name and rename, so a viewer polling the
        # directory never serves a half-written JPEG.
        tmp = directory / (name + ".part")
        tmp.write_bytes(data)
        path = directory / name
        tmp.replace(path)
        shape = getattr(image, "shape", (0, 0))
        record = {
            "file": name,
            "time": datetime.fromtimestamp(snap.wall_time).isoformat(timespec="milliseconds"),
            "epoch": round(snap.wall_time, 3),
            "sequence": snap.sequence,
            "session": f"{snap.session_id:08x}",
            "trigger": snap.trigger,
            "width": int(shape[1]),
            "height": int(shape[0]),
            "bytes": len(data),
            "resolution": getattr(snap.image, "resolution", "half"),
        }
        missing = getattr(snap.image, "missing", None)
        if missing:
            record["missing_phases"] = list(missing)
        if snap.event is not None:
            record["event"] = snap.event
        if snap.level is not None:
            record["level"] = snap.level
        with open(directory / "index.jsonl", "a", encoding="utf-8") as index:
            index.write(json.dumps(record, ensure_ascii=False) + "\n")
        self.last_path = path
