"""2026-11-01: security alarm clips (clips.py) and the page's video route.

    py -m unittest test_1101
"""
from __future__ import annotations

import json
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request
from pathlib import Path

from clips import ClipInfo, ClipRecorder, ClipWriter


class FakeSink:
    def __init__(self):
        self.msgs = []

    def __call__(self, msg):
        self.msgs.append(msg)

    def clips(self):
        """[(info, cover, [frames])] from the messages."""
        out, cur = [], None
        for m in self.msgs:
            if m[0] == "start":
                cur = [m[1], m[2], []]
            elif m[0] == "frame":
                cur[2].append(m[1])
            else:
                out.append(tuple(cur))
                cur = None
        return out


def run(rec, t0, t1, fps=60, label=None):
    """Feed live frames t0..t1 (s); each frame is its own timestamp."""
    t = t0
    while t < t1 - 1e-9:
        rec.on_frame(t, 1000.0 + t, label or round(t, 3))
        t += 1.0 / fps


class ClipRecorderTest(unittest.TestCase):
    def make(self, **kw):
        sink = FakeSink()
        return ClipRecorder(sink, fps=15, pre_s=3.0, post_s=1.5, max_s=30.0, hold_s=1.4, **kw), sink

    def test_pre_roll_alarm_and_post(self):
        rec, sink = self.make()
        run(rec, 0.0, 10.0)                       # nobody: only the ring
        self.assertEqual(sink.msgs, [])
        for t in (10.0, 11.0, 12.0):              # alarm bursts once a second
            rec.on_alarm(t, True, 3, "20261101_100010", 1000.0 + t)
            run(rec, t, t + 1.0)
        rec.on_alarm(13.0, False)                 # a normal burst: they left
        run(rec, 13.0, 16.0)
        (info, cover, frames), = sink.clips()
        self.assertEqual(info.event, "20261101_100010")
        self.assertGreaterEqual(frames[0], 6.9)   # 3 s pre-roll
        self.assertLess(frames[0], 7.2)
        self.assertGreaterEqual(frames[-1], 14.4)  # + 1.5 s after the end
        self.assertLess(frames[-1], 14.7)
        self.assertAlmostEqual(len(frames), 7.5 * 15, delta=3)   # ~15 fps, not 60
        self.assertEqual(cover, max(f for f in frames if f < 10.0))   # last pre-roll frame = the alarm's start
        self.assertEqual(rec.clips, 1)

    def test_alarm_lapses_without_a_normal_burst(self):
        rec, sink = self.make()
        rec.on_alarm(0.0, True, 2)
        run(rec, 0.0, 6.0)                        # no more bursts: over at 1.4 s, +1.5 s
        (info, _c, frames), = sink.clips()
        self.assertGreaterEqual(frames[-1], 2.8)
        self.assertLess(frames[-1], 3.1)
        self.assertEqual(info.level_seen, {2})

    def test_long_alarm_is_split_and_keeps_the_event(self):
        rec, sink = self.make()
        t = 0.0
        while t < 70.0:
            rec.on_alarm(t, True, 3 if t < 20 else 2, "E1", 1000.0 + t)
            run(rec, t, t + 1.0)
            t += 1.0
        rec.on_alarm(70.0, False)
        run(rec, 70.0, 75.0)
        clips = sink.clips()
        self.assertEqual(len(clips), 3)            # 30 + 30 + 10 s
        self.assertTrue(all(c[0].event == "E1" for c in clips))
        self.assertEqual(clips[0][0].level_seen, {3, 2})   # a face seen at 20 s
        self.assertIn(2, clips[1][0].level_seen)
        self.assertAlmostEqual(len(clips[0][2]), 30 * 15, delta=3)

    def test_close_finishes_an_open_clip(self):
        rec, sink = self.make()
        rec.on_alarm(0.0, True, 3)
        run(rec, 0.0, 0.5)
        rec.close()
        self.assertEqual(len(sink.clips()), 1)


class FakeVideo:
    def __init__(self, path):
        self.path, self.frames = path, []

    def write(self, f):
        self.frames.append(f)

    def release(self):
        self.path.write_bytes(b"VID" + bytes(len(self.frames)))


class ClipWriterTest(unittest.TestCase):
    def test_files_and_index(self):
        import numpy as np
        with tempfile.TemporaryDirectory() as tmp:
            opened = []

            def open_video(base, fps, size):
                v = FakeVideo(base.with_name(base.name + ".mp4"))
                opened.append((base, size))
                return v, ".mp4"

            w = ClipWriter(Path(tmp), open_video=open_video, encoder=lambda img: b"\xff\xd8cover")
            wall = time.mktime((2026, 11, 1, 10, 0, 10, 0, 0, -1))
            info = ClipInfo(wall, "20261101_100010", {3, 2})
            frame = np.zeros((540, 960, 3), np.uint8)
            w.submit(("start", info, frame))
            for i in range(30):
                info.frames += 1
                info.last_wall = wall + i / 15
                w.submit(("frame", frame))
            w.submit(("end", info))
            w.close()
            day = Path(tmp) / "20261101"
            rec = json.loads((day / "index.jsonl").read_text(encoding="utf-8").strip())
            self.assertEqual((rec["file"], rec["video"]), ("100010_000_clip.jpg", "100010_000_clip.mp4"))
            self.assertEqual((rec["trigger"], rec["level"], rec["event"]), ("alarm_face", 2, "20261101_100010"))
            self.assertEqual(rec["frames"], 30)
            self.assertAlmostEqual(rec["duration"], 2.0, delta=0.1)
            self.assertEqual((day / "100010_000_clip.mp4").read_bytes(), b"VID" + bytes(30))
            self.assertEqual((day / "100010_000_clip.jpg").read_bytes(), b"\xff\xd8cover")
            self.assertFalse(any(p.name.startswith("tmp_") for p in day.iterdir()))
            self.assertEqual(opened[0][1], (960, 540))
            self.assertEqual(w.saved, 1)

    def test_a_failing_encoder_does_not_stop_the_next_clip(self):
        import numpy as np
        with tempfile.TemporaryDirectory() as tmp:
            calls = []

            def open_video(base, fps, size):
                calls.append(base)
                if len(calls) == 1:
                    raise RuntimeError("no codec")
                return FakeVideo(base.with_name(base.name + ".mp4")), ".mp4"

            w = ClipWriter(Path(tmp), open_video=open_video, encoder=lambda img: b"j")
            f = np.zeros((4, 4, 3), np.uint8)
            for k in range(2):
                info = ClipInfo(1_000_000.0 + 100 * k, None, {3})
                w.submit(("start", info, f))
                w.submit(("frame", f))
                info.frames, info.last_wall = 1, info.start_wall
                w.submit(("end", info))
            w.close()
            self.assertEqual((w.failed, w.saved), (1, 1))


class VideoRouteTest(unittest.TestCase):
    def setUp(self):
        from snapshot_server import make_server
        self.tmp = tempfile.TemporaryDirectory()
        day = Path(self.tmp.name) / "20261101"
        day.mkdir()
        self.data = bytes(range(256)) * 40          # 10240 bytes
        (day / "100010_000_clip.mp4").write_bytes(self.data)
        (day / "100010_000_clip.jpg").write_bytes(b"\xff\xd8c")
        (day / "index.jsonl").write_text(json.dumps({
            "file": "100010_000_clip.jpg", "video": "100010_000_clip.mp4", "epoch": 1.0,
            "time": "2026-11-01T10:00:10.000", "trigger": "alarm_face", "level": 2,
            "duration": 4.2}) + "\n", encoding="utf-8")
        self.server = make_server(Path(self.tmp.name), "127.0.0.1", 0, "k", quiet=True)
        self.base = f"http://127.0.0.1:{self.server.server_address[1]}"
        threading.Thread(target=self.server.serve_forever, daemon=True).start()

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.tmp.cleanup()

    def get(self, path, rng=None):
        req = urllib.request.Request(self.base + path, headers={"Cookie": "evs_k=k"})
        if rng:
            req.add_header("Range", rng)
        try:
            with urllib.request.urlopen(req, timeout=5) as res:
                return res.status, res.read(), res.headers
        except urllib.error.HTTPError as err:
            return err.code, err.read(), err.headers

    def test_whole_file_and_ranges(self):
        st, body, h = self.get("/vid/20261101/100010_000_clip.mp4")
        self.assertEqual((st, body, h["Content-Type"], h["Accept-Ranges"]), (200, self.data, "video/mp4", "bytes"))
        st, body, h = self.get("/vid/20261101/100010_000_clip.mp4", "bytes=0-1")      # Safari's probe
        self.assertEqual((st, body, h["Content-Range"]), (206, self.data[:2], "bytes 0-1/10240"))
        st, body, h = self.get("/vid/20261101/100010_000_clip.mp4", "bytes=10000-")
        self.assertEqual((st, body), (206, self.data[10000:]))
        st, body, _ = self.get("/vid/20261101/100010_000_clip.mp4", "bytes=-100")
        self.assertEqual((st, body), (206, self.data[-100:]))
        self.assertEqual(self.get("/vid/20261101/100010_000_clip.mp4", "bytes=99999-")[0], 416)

    def test_bad_paths_and_the_key(self):
        for p in ("/vid/20261101/..%2Fx.mp4", "/vid/20261101/a.exe", "/vid/x/a.mp4"):
            self.assertIn(self.get(p)[0], (400, 404), p)
        self.assertEqual(self.get("/vid/20261101/none.mp4")[0], 404)
        req = urllib.request.Request(self.base + "/vid/20261101/100010_000_clip.mp4")
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            urllib.request.urlopen(req, timeout=5)
        self.assertEqual(ctx.exception.code, 401)

    def test_clip_counts_as_an_alarm(self):
        _, body, _ = self.get("/api/stats?day=20261101")
        self.assertEqual(json.loads(body)["counts"]["alarm"], 1)
        _, body, _ = self.get("/api/latest")
        self.assertEqual(json.loads(body)["latest"]["video"], "100010_000_clip.mp4")

    def test_timeline_event_carries_the_clip(self):
        """Anlogic_update merge: 事件时间线 plays the clip, not just its cover."""
        _, body, _ = self.get("/api/timeline?day=20261101")
        ev, = json.loads(body)["events"]
        self.assertEqual((ev["kind"], ev["video"], ev["file"]),
                         ("alarm_face", "100010_000_clip.mp4", "100010_000_clip.jpg"))

    def test_page_plays_videos(self):
        _, body, _ = self.get("/")
        page = body.decode("utf-8")
        for s in ('id="lbVid"', "playsinline", "/vid/", "is-video"):
            self.assertIn(s, page)

    def test_page_light_only_with_qc_subviews(self):
        """Anlogic_update merge: no dark mode, no 960x540 row, 标准件 | 任意工件."""
        page = self.get("/")[1].decode("utf-8")
        self.assertNotIn("prefers-color-scheme: dark", page)
        self.assertNotIn('"画面"', page)
        for s in ('id="subtabs"', 'data-v="std"', 'data-v="any"', "/api/std", "/std/image?part=",
                  'data-v="tl"', 'data-v="st"'):
            self.assertIn(s, page)


if __name__ == "__main__":
    unittest.main()
