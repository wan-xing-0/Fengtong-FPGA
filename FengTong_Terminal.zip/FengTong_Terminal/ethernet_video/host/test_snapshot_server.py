import json
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from pathlib import Path

from snapshot_server import IndexCache, check_bind_address, make_server

KEY = "test-key-123"


def write_index(day_dir: Path, records, partial: str = "") -> None:
    day_dir.mkdir(parents=True, exist_ok=True)
    with open(day_dir / "index.jsonl", "a", encoding="utf-8") as f:
        for r in records:
            f.write(json.dumps(r) + "\n")
        f.write(partial)


def rec(name, seq, epoch=1.0):
    return {"file": name, "sequence": seq, "epoch": epoch,
            "time": "2026-09-28T14:30:15.123", "trigger": "timer"}


class IndexCacheTest(unittest.TestCase):
    def test_reads_incrementally_and_waits_for_the_newline(self):
        with tempfile.TemporaryDirectory() as tmp:
            day = Path(tmp) / "20260928"
            write_index(day, [rec("a.jpg", 1)], partial='{"file": "b.jpg"')
            cache = IndexCache(Path(tmp))
            self.assertEqual([r["file"] for r in cache.records("20260928")], ["a.jpg"])
            # The receiver finishes the half-written line, then adds another.
            with open(day / "index.jsonl", "a", encoding="utf-8") as f:
                f.write(', "sequence": 2}\n' + json.dumps(rec("c.jpg", 3)) + "\n")
            self.assertEqual([r["file"] for r in cache.records("20260928")],
                             ["a.jpg", "b.jpg", "c.jpg"])
            self.assertEqual(cache.latest()["file"], "c.jpg")

    def test_deleted_day_disappears_and_bad_names_are_ignored(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            write_index(root / "20260928", [rec("ok.jpg", 1), rec("../evil.jpg", 2)])
            (root / "not_a_day").mkdir()
            cache = IndexCache(root)
            self.assertEqual(cache.days(), ["20260928"])
            self.assertEqual([r["file"] for r in cache.records("20260928")], ["ok.jpg"])
            (root / "20260928" / "index.jsonl").unlink()
            self.assertEqual(cache.records("20260928"), [])


class BindAddressTest(unittest.TestCase):
    def test_fpga_subnet_is_refused(self):
        with self.assertRaises(SystemExit):
            check_bind_address("192.168.137.1")

    def test_wifi_address_is_accepted(self):
        check_bind_address("192.168.1.23")


class ServerTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        root = Path(self.tmp.name)
        day = root / "20260928"
        write_index(day, [rec("143015_123_seq00000001.jpg", 1),
                          rec("143016_123_seq00000061.jpg", 61)])
        (day / "143015_123_seq00000001.jpg").write_bytes(b"\xff\xd8one")
        (day / "143016_123_seq00000061.jpg").write_bytes(b"\xff\xd8two")
        self.server = make_server(root, "127.0.0.1", 0, KEY, quiet=True)
        self.base = f"http://127.0.0.1:{self.server.server_address[1]}"
        threading.Thread(target=self.server.serve_forever, daemon=True).start()

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.tmp.cleanup()

    def get(self, path, cookie=None):
        req = urllib.request.Request(self.base + path)
        if cookie:
            req.add_header("Cookie", cookie)
        try:
            with urllib.request.urlopen(req, timeout=5) as res:
                return res.status, res.read(), res.headers
        except urllib.error.HTTPError as err:
            return err.code, err.read(), err.headers

    def test_everything_needs_the_key(self):
        for path in ("/", "/api/latest", "/img/20260928/143015_123_seq00000001.jpg"):
            status, _, _ = self.get(path)
            self.assertEqual(status, 401, path)
        status, _, _ = self.get("/api/latest?k=wrong")
        self.assertEqual(status, 401)

    def test_key_in_link_sets_cookie_and_cookie_works(self):
        # urllib follows the 303 without the cookie, so check the redirect
        # response itself through a no-redirect opener.
        class NoRedirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self, *a, **k):
                return None
        opener = urllib.request.build_opener(NoRedirect)
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            opener.open(self.base + f"/?k={KEY}", timeout=5)
        self.assertEqual(ctx.exception.code, 303)
        self.assertIn(f"evs_k={KEY}", ctx.exception.headers["Set-Cookie"])
        status, body, _ = self.get("/", cookie=f"evs_k={KEY}")
        self.assertEqual(status, 200)
        self.assertIn("监控抓拍", body.decode("utf-8"))
        self.assertIn("工件记录", body.decode("utf-8"))

    def test_latest_index_and_image(self):
        c = f"evs_k={KEY}"
        _, body, _ = self.get("/api/latest", cookie=c)
        self.assertEqual(json.loads(body)["latest"]["sequence"], 61)
        _, body, _ = self.get("/api/index?day=20260928&limit=1", cookie=c)
        data = json.loads(body)
        self.assertEqual(data["total"], 2)
        self.assertEqual([r["sequence"] for r in data["records"]], [61])  # newest first
        status, body, headers = self.get("/img/20260928/143015_123_seq00000001.jpg", cookie=c)
        self.assertEqual((status, body, headers["Content-Type"]), (200, b"\xff\xd8one", "image/jpeg"))
        _, _, headers = self.get("/img/20260928/143015_123_seq00000001.jpg?dl=1", cookie=c)
        self.assertIn("attachment", headers["Content-Disposition"])

    def test_kind_filter(self):
        c = f"evs_k={KEY}"
        day = Path(self.tmp.name) / "20260928"
        extra = [dict(rec("143020_000_seq00000100.jpg", 100), trigger="alarm_face",
                      level=2, event="20260928_143020"),
                 dict(rec("143021_000_seq00000160.jpg", 160), trigger="alarm_motion",
                      level=3, event="20260928_143020"),
                 dict(rec("143022_000_seq00000220.jpg", 220), trigger="normal")]
        write_index(day, extra)

        def seqs(kind):
            _, body, _ = self.get(f"/api/index?day=20260928&kind={kind}", cookie=c)
            data = json.loads(body)
            return data["total"], [r["sequence"] for r in data["records"]]

        self.assertEqual(seqs("all"), (5, [220, 160, 100, 61, 1]))
        self.assertEqual(seqs("alarm_face"), (1, [100]))
        self.assertEqual(seqs("alarm_motion"), (1, [160]))
        # older "timer" pictures are listed with the normal ones
        self.assertEqual(seqs("normal"), (3, [220, 61, 1]))
        self.assertEqual(seqs("manual"), (0, []))
        # 10-29: the page's three kinds -- alarm is both levels
        self.assertEqual(seqs("alarm"), (2, [160, 100]))
        status, _, _ = self.get("/api/index?day=20260928&kind=bogus", cookie=c)
        self.assertEqual(status, 400)
        _, body, _ = self.get("/api/stats?day=20260928", cookie=c)
        self.assertEqual(json.loads(body)["counts"],
                         {"all": 5, "alarm": 2, "staff": 0, "normal": 3, "manual": 0})

    def test_qc_view_is_separate(self):
        """10-29: one page, two views -- src=qc reads <root>/qc."""
        c = f"evs_k={KEY}"
        qc = Path(self.tmp.name) / "qc" / "20261029"
        cards = [{"file": "100000_000_No001_card.jpg", "epoch": 2.0, "time": "2026-10-29T10:00:00.000",
                  "trigger": "qc", "verdict": "pass", "mode": "standard"},
                 {"file": "100100_000_No002_card.jpg", "epoch": 3.0, "time": "2026-10-29T10:01:00.000",
                  "trigger": "qc", "verdict": "fail", "mode": "standard"},
                 {"file": "100200_000_No003_card.jpg", "epoch": 4.0, "time": "2026-10-29T10:02:00.000",
                  "trigger": "qc", "verdict": "none", "mode": "any"}]
        write_index(qc, cards)
        (qc / "100000_000_No001_card.jpg").write_bytes(b"\xff\xd8card")
        _, body, _ = self.get("/api/days?src=qc", cookie=c)
        self.assertEqual(json.loads(body)["days"], ["20261029"])
        _, body, _ = self.get("/api/days", cookie=c)            # the 监控 view is unchanged
        self.assertEqual(json.loads(body)["days"], ["20260928"])
        _, body, _ = self.get("/api/latest?src=qc", cookie=c)
        self.assertEqual(json.loads(body)["latest"]["file"], "100200_000_No003_card.jpg")
        _, body, _ = self.get("/api/index?src=qc&day=20261029&kind=fail", cookie=c)
        self.assertEqual([r["file"] for r in json.loads(body)["records"]], ["100100_000_No002_card.jpg"])
        _, body, _ = self.get("/api/stats?src=qc&day=20261029", cookie=c)
        self.assertEqual(json.loads(body)["counts"], {"all": 3, "pass": 1, "fail": 1, "none": 1})
        status, body, _ = self.get("/img/20261029/100000_000_No001_card.jpg?src=qc", cookie=c)
        self.assertEqual((status, body), (200, b"\xff\xd8card"))
        status, _, _ = self.get("/img/20261029/100000_000_No001_card.jpg", cookie=c)
        self.assertEqual(status, 404)                             # not in the 监控 folder
        status, _, _ = self.get("/api/index?src=qc&day=20261029&kind=alarm", cookie=c)
        self.assertEqual(status, 400)
        status, _, _ = self.get("/api/days?src=evil", cookie=c)
        self.assertEqual(status, 400)
        # 11-01: 任意 / 标准件 views (mode filter; no mode = an old record = 任意)
        write_index(qc, [{"file": "100300_000_No004_card.jpg", "epoch": 5.0,
                          "time": "2026-10-29T10:03:00.000", "trigger": "qc", "verdict": "pass"}])
        _, body, _ = self.get("/api/stats?src=qc&mode=standard&day=20261029", cookie=c)
        self.assertEqual(json.loads(body)["counts"], {"all": 2, "pass": 1, "fail": 1, "none": 0})
        _, body, _ = self.get("/api/index?src=qc&mode=any&day=20261029", cookie=c)
        self.assertEqual([r["file"] for r in json.loads(body)["records"]],
                         ["100300_000_No004_card.jpg", "100200_000_No003_card.jpg"])
        _, body, _ = self.get("/api/latest?src=qc&mode=standard", cookie=c)
        self.assertEqual(json.loads(body)["latest"]["file"], "100100_000_No002_card.jpg")
        self.assertEqual(self.get("/api/index?src=qc&mode=bogus&day=20261029", cookie=c)[0], 400)
        # 11-01: only the 方块 is offered (the 三棱柱 is hidden on the PC side)
        _, body, _ = self.get("/api/std", cookie=c)
        parts = json.loads(body)["parts"]
        self.assertEqual(list(parts), ["cube"])
        cube = parts["cube"]
        self.assertEqual((cube["x"], cube["y"], cube["z"], cube["tol_xy"], cube["tol_z"]), (60, 60, 30, 3, 5))
        self.assertEqual(self.get("/std/image?part=tri", cookie=c)[0], 404)

    def test_brand(self):
        c = f"evs_k={KEY}"
        brand = Path(self.tmp.name) / "brand"
        brand.mkdir()
        self.server.RequestHandlerClass.brand_dir = brand
        _, body, _ = self.get("/api/brand", cookie=c)
        b = json.loads(body)
        self.assertEqual((b["logo_img"], b["team_img"], b["team"]), (False, False, "队伍名称"))
        self.assertEqual(self.get("/brand/logo", cookie=c)[0], 404)
        (brand / "logo.png").write_bytes(b"\x89PNG")
        (brand / "brand.json").write_text('{"team": "测试队", "title": "平台"}', encoding="utf-8")
        _, body, _ = self.get("/api/brand", cookie=c)
        b = json.loads(body)
        self.assertEqual((b["logo_img"], b["team_img"], b["title"], b["team"]), (True, False, "平台", "测试队"))
        status, body, headers = self.get("/brand/logo", cookie=c)
        self.assertEqual((status, body, headers["Content-Type"]), (200, b"\x89PNG", "image/png"))
        self.assertEqual(self.get("/brand/..%2Fsecret", cookie=c)[0], 404)
        self.assertEqual(self.get("/brand/logo")[0], 401)
        # 11-01: the four marks make_brand.py writes
        for name in ("product", "team", "company", "contest"):
            self.assertFalse(json.loads(self.get("/api/brand", cookie=c)[1])[name + "_img"])
            (brand / f"{name}.png").write_bytes(b"\x89PNG" + name.encode())
            self.assertTrue(json.loads(self.get("/api/brand", cookie=c)[1])[name + "_img"])
            self.assertEqual(self.get(f"/brand/{name}", cookie=c)[1], b"\x89PNG" + name.encode())

    def test_path_traversal_and_missing_files_are_rejected(self):
        c = f"evs_k={KEY}"
        for path in ("/img/20260928/..%2F..%2Fsecret.jpg", "/img/../x.jpg",
                     "/img/20260928/index.jsonl", "/api/index?day=../x"):
            status, _, _ = self.get(path, cookie=c)
            self.assertIn(status, (400, 404), path)
        status, _, _ = self.get("/img/20260928/000000_000_seq00000000.jpg", cookie=c)
        self.assertEqual(status, 404)


if __name__ == "__main__":
    unittest.main()
