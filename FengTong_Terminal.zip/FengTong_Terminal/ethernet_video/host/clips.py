"""Security alarm clips (2026-11-01, user: short videos instead of the 0.3 s
alarm stills on the 监控抓拍 page).

While an alarm runs the live 960x540 frames are written to a video, with
PRE_S seconds from before it started (a ring buffer) and POST_S seconds after
it ended; one clip is at most MAX_S long, a longer alarm carries on in the
next clip (same event id).  Normal records and the staff record stay stills.

    <root>/<YYYYMMDD>/<HHMMSS_mmm>_clip.mp4    the video (H.264, Media Foundation)
    <root>/<YYYYMMDD>/<HHMMSS_mmm>_clip.jpg    its cover: the first alarm frame
    index.jsonl  one line per clip, written when it is finished:
        {"file": "..._clip.jpg", "video": "..._clip.mp4", "trigger":
         "alarm_face" | "alarm_motion", "level": 2 | 3, "event": ...,
         "duration": s, "frames": n, ...}

"alarm" is what the FPGA reports: an alarm burst (sec_level 2/3 with someone
there) about once a second.  ClipRecorder.on_alarm(now, True, src) on each
one; the alarm is over at a non-alarm burst or ALARM_HOLD_S without one.
trigger / level: alarm_face (2, a face was seen) if any burst of the clip
said so, else alarm_motion (3).

Codec (codec_check.py on the user's PC, 11-01): H.264 through OpenCV's MSMF
backend plays everywhere; OpenH264 through FFMPEG is not installed; VP8 WebM
is the fallback.  The writer picks the first that really writes.

Threads: ClipRecorder lives on the display thread and only moves references;
ClipWriter encodes on its own thread behind a bounded queue (a full queue
drops the frame and counts it, it never blocks the display).
"""
from __future__ import annotations

import json
import queue
import threading
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable

CLIP_FPS = 15
PRE_S = 3.0
POST_S = 1.5
MAX_S = 30.0
ALARM_HOLD_S = 1.4
QUEUE_DEPTH = 120             # 8 s of frames at 15 fps
SRC_NAMES = {2: "alarm_face", 3: "alarm_motion"}
# (backend name, fourcc, extension); tried in order
CODECS = (("MSMF", "avc1", ".mp4"), ("FFMPEG", "VP80", ".webm"), ("FFMPEG", "VP90", ".webm"))


@dataclass
class ClipInfo:
    start_wall: float
    event: str | None
    level_seen: set = field(default_factory=set)
    frames: int = 0
    last_wall: float = 0.0


class ClipRecorder:
    """Display-thread side.  `sink` gets ("start", ClipInfo, cover_bgr),
    ("frame", bgr), ("end", ClipInfo) -- a ClipWriter's submit in the program."""

    def __init__(self, sink: Callable, fps: float = CLIP_FPS, pre_s: float = PRE_S,
                 post_s: float = POST_S, max_s: float = MAX_S, hold_s: float = ALARM_HOLD_S,
                 on_alarm_start: "Callable | None" = None) -> None:
        self.sink = sink
        # 11-01: called once when an alarm BEGINS (not for the carry-on clip of a
        # long alarm): on_alarm_start("alarm_face" | "alarm_motion", wall_time).
        # The clip's index line only appears when the video is finished.
        self.on_alarm_start = on_alarm_start
        self.period = 1.0 / fps
        self.pre_s, self.post_s, self.max_s, self.hold_s = pre_s, post_s, max_s, hold_s
        self.ring: deque = deque()          # (now, wall, bgr) of the last pre_s seconds
        self.last_take = float("-inf")
        self.alarm_until = 0.0              # alarm on while now < this
        self.alarm_src = 3
        self.clip: ClipInfo | None = None
        self.clip_t0 = 0.0
        self.stop_at: float | None = None   # alarm over: finish at this time
        self.clips = 0

    # -- the FPGA's reports --------------------------------------------------
    def on_alarm(self, now: float, alarm: bool, src: int = 3, event: str | None = None,
                 wall: float | None = None) -> None:
        if alarm:
            self.alarm_until = now + self.hold_s
            self.alarm_src = src
            if self.clip is None:
                self._start(now, event, wall)
                if self.on_alarm_start is not None:
                    try:
                        self.on_alarm_start("alarm_face" if src == 2 else "alarm_motion", wall)
                    except Exception:                  # a notice must never stop the video
                        pass
            self.clip.level_seen.add(src)
            if event and not self.clip.event:
                self.clip.event = event
            self.stop_at = None
        else:
            self.alarm_until = 0.0
            if self.clip is not None and self.stop_at is None:
                self.stop_at = now + self.post_s

    def alarming(self, now: float) -> bool:
        return now < self.alarm_until

    # -- live frames ---------------------------------------------------------
    def on_frame(self, now: float, wall: float, bgr) -> None:
        if now - self.last_take < self.period * 0.9:
            return
        self.last_take = now
        if self.clip is None:
            self.ring.append((now, wall, bgr))
            while self.ring and now - self.ring[0][0] > self.pre_s:
                self.ring.popleft()
            return
        # the alarm lapsed without a non-alarm burst (person gone, staff check)
        if self.stop_at is None and not self.alarming(now):
            self.stop_at = now + self.post_s
        self._emit(wall, bgr)
        if self.stop_at is not None and now >= self.stop_at:
            self._end()
        elif now - self.clip_t0 >= self.max_s:
            event, levels = self.clip.event, set(self.clip.level_seen)
            self._end()
            if self.alarming(now):          # still on: carry on in a new clip
                self._start(now, event, wall, pre=False)
                self.clip.level_seen |= levels

    def close(self) -> None:
        if self.clip is not None:
            self._end()

    # -- internals -----------------------------------------------------------
    def _start(self, now: float, event, wall, pre: bool = True) -> None:
        frames = list(self.ring) if pre else []
        self.ring.clear()
        cover = frames[-1][2] if frames else None
        start_wall = frames[0][1] if frames else (wall or 0.0)
        self.clip = ClipInfo(start_wall, event, {self.alarm_src})
        self.clip_t0 = frames[0][0] if frames else now
        self.stop_at = None
        self.sink(("start", self.clip, cover))
        for _n, w, f in frames:
            self._emit(w, f)

    def _emit(self, wall: float, bgr) -> None:
        self.clip.frames += 1
        self.clip.last_wall = wall
        self.sink(("frame", bgr))

    def _end(self) -> None:
        self.sink(("end", self.clip))
        self.clips += 1
        self.clip = None
        self.stop_at = None


def clip_names(wall: float) -> tuple[str, str]:
    t = datetime.fromtimestamp(wall)
    return t.strftime("%Y%m%d"), f"{t.strftime('%H%M%S')}_{t.microsecond // 1000:03d}_clip"


def encode_jpeg(image, quality: int = 88) -> bytes:
    import cv2
    ok, buf = cv2.imencode(".jpg", image, [cv2.IMWRITE_JPEG_QUALITY, quality])
    if not ok:
        raise RuntimeError("JPEG 编码失败")
    return buf.tobytes()


class ClipWriter:
    """Encoder thread.  open_video(path_without_ext, fps, (w, h)) ->
    (writer with write()/release(), extension); the default probes CODECS."""

    def __init__(self, root: Path, fps: float = CLIP_FPS, open_video: Callable | None = None,
                 encoder: Callable = encode_jpeg) -> None:
        self.root = Path(root)
        self.fps = fps
        self.open_video = open_video or self._open_cv2
        self.encoder = encoder
        self.queue: queue.Queue = queue.Queue(QUEUE_DEPTH)
        self.saved = 0
        self.dropped = 0
        self.failed = 0
        self.codec: str | None = None
        self.last_error: str | None = None
        self._skip = False                 # the current clip failed: swallow its frames
        self._thread = threading.Thread(target=self._run, name="clip-writer", daemon=True)
        self._thread.start()

    def submit(self, msg) -> None:
        # start / end must never be dropped (they bracket a clip): wait for room
        if msg[0] != "frame":
            self.queue.put(msg)
            return
        try:
            self.queue.put_nowait(msg)
        except queue.Full:
            self.dropped += 1

    def close(self, timeout: float = 10.0) -> None:
        self.queue.put(None)
        self._thread.join(timeout)

    # -- encoder -------------------------------------------------------------
    def _open_cv2(self, base: Path, fps: float, size: tuple[int, int]):
        import cv2
        tried = CODECS if self.codec is None else [c for c in CODECS if c[1] == self.codec]
        for api, fourcc, ext in tried:
            path = base.with_name(base.name + ext)
            w = cv2.VideoWriter(str(path), getattr(cv2, "CAP_" + api),
                                cv2.VideoWriter_fourcc(*fourcc), fps, size)
            if w.isOpened():
                self.codec = fourcc
                return w, ext
            w.release()
            path.unlink(missing_ok=True)
        raise RuntimeError("没有可用的视频编码器（codec_check.py 看一下）")

    def _run(self) -> None:
        cur = None                          # (writer, tmp_path, final_path, cover, info, day)
        while True:
            msg = self.queue.get()
            if msg is None:
                if cur:
                    self._finish(cur, cur[4])
                return
            kind = msg[0]
            try:
                if kind == "start":
                    _k, info, cover = msg
                    cur = None
                    self._skip = False
                    self._pending = (info, cover)
                elif kind == "frame":
                    if self._skip:
                        continue
                    if cur is None:
                        cur = self._begin(msg[1])
                    cur[0].write(msg[1])
                elif kind == "end":
                    if cur is not None:
                        self._finish(cur, msg[1])
                    cur = None
            except Exception as exc:      # keep recording the next clip
                self.failed += 1
                self.last_error = f"{type(exc).__name__}: {exc}"
                if cur is not None:
                    try:
                        cur[0].release()
                    except Exception:
                        pass
                cur = None
                self._skip = True

    def _begin(self, first_bgr):
        info, cover = self._pending
        day, stem = clip_names(info.start_wall)
        directory = self.root / day
        directory.mkdir(parents=True, exist_ok=True)
        h, w = first_bgr.shape[:2]
        # written under a temporary name (same extension: MSMF picks the
        # container from it), renamed when done, so the page never sees half a file
        writer, ext = self.open_video(directory / ("tmp_" + stem), self.fps, (w, h))
        tmp = directory / ("tmp_" + stem + ext)
        return (writer, tmp, directory / (stem + ext), cover if cover is not None else first_bgr,
                info, day)

    def _finish(self, cur, info: ClipInfo) -> None:
        writer, tmp, final, cover, _info, day = cur
        writer.release()
        tmp.replace(final)
        stem = final.stem
        jpg = final.with_name(stem + ".jpg")
        part = jpg.with_name(jpg.name + ".part")
        part.write_bytes(self.encoder(cover))
        part.replace(jpg)
        level = 2 if 2 in info.level_seen else 3
        h, w = cover.shape[:2]
        record = {
            "file": jpg.name, "video": final.name,
            "time": datetime.fromtimestamp(info.start_wall).isoformat(timespec="milliseconds"),
            "epoch": round(info.start_wall, 3),
            "trigger": SRC_NAMES[level], "level": level,
            "duration": round(max(0.0, info.last_wall - info.start_wall) + 1.0 / self.fps, 1),
            "frames": info.frames, "width": int(w), "height": int(h),
            "bytes": final.stat().st_size, "resolution": "half",
        }
        if info.event:
            record["event"] = info.event
        with open(self.root / day / "index.jsonl", "a", encoding="utf-8") as index:
            index.write(json.dumps(record, ensure_ascii=False) + "\n")
        self.saved += 1
