"""2026-10-29: qc_ext layout 3 (任意 / 标准件 cards), the staff record, the
30-minute normal record, EVDBG1's board state and the EVCMD control commands.

    py -m unittest test_1029
"""
from __future__ import annotations

import socket
import time
import unittest

from evs_control import (CMD_KEY2, CMD_SET_MODE, CMD_STD_PART, Commander, ControlBar,
                         make_cmd)
from evs_status import BoardState, board_state, decode_status
from fullres import (FLAG_STAFF, SRC_NAMES, SRC_NORMAL, SRC_STAFF, make_flags,
                     parse_flags)
from qc_record import (QC2_SIZE, QC3_VERSION, STD_PART, QcExt, QcRecord, make_qc_datagram,
                       parse_qc, std_deviations)
from qc_rules import Rules, Verdict, judge
from snapshots import SecurityPolicy


def rec_bytes(seq: int, x: int = 60, y: int = 60, z: int = 30) -> bytes:
    r = (1 << 127) | (1 << 126) | (x << 104) | (y << 88) | (z << 72) \
        | (250 << 56) | (278 << 40) | (300 << 28) | (200 << 16) | (seq << 8)
    return r.to_bytes(16, "big")


def rec3(seq: int = 3, x: int = 60, y: int = 60, z: int = 30, **ext) -> QcRecord:
    # 10-31: colour / shape are judged too -- default to a white rectangle, the
    # cube's own, so a test only fails on what it sets.
    ext.setdefault("colour_cls", 2)
    ext.setdefault("shape", 2)
    d = make_qc_datagram(rec_bytes(seq, x, y, z), 9,
                         ext_raw=QcExt.sample3(**ext).to_bytes(), version=QC3_VERSION)
    return parse_qc(d).record


class Layout3PacketTest(unittest.TestCase):
    def test_bits_match_system_top(self):
        """qc_ext layout 3 as system_top latches it (the 10-29 qc_ext block)."""
        e = QcExt.sample3(shape=2, colour_cls=8, rgb=(30, 60, 210), stained=True,
                          std_mode=True, std_valid=True, std_pass=False)
        v = int.from_bytes(e.to_bytes(), "big")
        self.assertEqual(v >> 127 & 1, 1)
        self.assertEqual(v >> 124 & 3, 2)                 # shape
        self.assertEqual(v >> 119 & 1, 1)                 # stain judged
        self.assertEqual(v >> 118 & 1, 1)                 # stained
        self.assertEqual((v >> 117 & 1, v >> 113 & 0xF), (1, 8))
        self.assertEqual((v >> 112 & 1, v >> 111 & 1, v >> 110 & 1), (1, 1, 0))
        self.assertEqual(v >> 108 & 3, 1)                 # 10-31: [109:108] = 1 方块
        self.assertEqual(v >> 104 & 0xF, 0)               # [107:104] zero
        self.assertEqual(v >> 96 & 0xFF, 6)               # hot cells
        self.assertEqual(v >> 72 & 0xFFFFFF, 0)           # [95:72] zero (no FPGA count given)
        self.assertEqual((v >> 64 & 0xFF, v >> 56 & 0xFF, v >> 48 & 0xFF), (30, 60, 210))
        self.assertEqual(v & ((1 << 48) - 1), 0)          # [47:0] zero

    def test_round_trip_and_version_byte(self):
        e = QcExt.sample3(std_mode=True, std_pass=True)
        d = make_qc_datagram(rec_bytes(4), 7, ext_raw=e.to_bytes(), version=QC3_VERSION)
        self.assertEqual((len(d), d[:5], d[5]), (QC2_SIZE, b"EVQC2", 3))
        got = parse_qc(d).record.ext
        self.assertEqual(got, e)
        self.assertEqual(got.layout, 3)

    def test_layout_2_still_reads_the_old_way(self):
        old = QcExt.sample(hole=1, stain=3)
        got = parse_qc(make_qc_datagram(rec_bytes(4), 7, ext_raw=old.to_bytes())).record.ext
        self.assertEqual(got.layout, 2)
        self.assertEqual((got.hole, got.stain), (1, 3))
        self.assertFalse(got.std_mode)

    def test_unknown_version_rejected(self):
        d = bytearray(make_qc_datagram(rec_bytes(4), 7, ext_raw=bytes(16), version=QC3_VERSION))
        d[5] = 4
        x = 0
        for b in d[:-1]:
            x ^= b
        d[-1] = x
        self.assertIsNone(parse_qc(bytes(d)))

    def test_stain_text(self):
        self.assertEqual(rec3().ext.surface_text, "无污渍")
        self.assertEqual(rec3(stained=True).ext.surface_text, "有污渍")
        self.assertEqual(rec3(judged=False).ext.surface_text, "未检测")


class Layout3VerdictTest(unittest.TestCase):
    """The card shows the FPGA's verdict; qc_rules.json does not apply."""

    STRICT = Rules(True, {}, True, "圆形", "蓝色")     # would fail every rec3 below

    def test_any_mode_has_no_verdict(self):
        self.assertEqual(judge(rec3(std_mode=False), self.STRICT).status, "none")
        self.assertEqual(Verdict("none").text, "")

    def test_standard_pass(self):
        self.assertEqual(judge(rec3(std_mode=True, std_pass=True), self.STRICT).status, "pass")

    def test_standard_fail_reason_is_the_axis(self):
        v = judge(rec3(z=36, std_mode=True, std_pass=False), self.STRICT)
        self.assertEqual((v.status, v.failed), ("fail", ("厚",)))

    def test_standard_fail_reason_stain(self):
        v = judge(rec3(stained=True, std_mode=True, std_pass=False), self.STRICT)
        self.assertEqual((v.status, v.failed), ("fail", ("污渍",)))

    def test_size_and_stain_both_listed(self):
        v = judge(rec3(x=64, stained=True, std_mode=True, std_pass=False), self.STRICT)
        self.assertEqual(v.failed, ("长", "污渍"))

    def test_tolerance_edge_is_inside(self):
        # +3 on X/Y and +5 on Z are still 合格 for qc_std (|d| > tol fails)
        v = judge(rec3(x=63, z=35, std_mode=True, std_pass=False), self.STRICT)
        self.assertEqual(v.failed, ("见屏幕判定",))

    def test_not_judged_yet(self):
        v = judge(rec3(std_mode=True, std_valid=False), self.STRICT)
        self.assertEqual(v.status, "measuring")

    def test_deviations(self):
        self.assertEqual(std_deviations(rec3(x=61, y=58, z=36)), {"x": 1, "y": -2, "z": 6})
        self.assertEqual((STD_PART["x"], STD_PART["y"], STD_PART["z"]), (60, 60, 30))


class Layout3CardTest(unittest.TestCase):
    def test_both_cards_render(self):
        try:
            import numpy as np
            import PIL  # noqa: F401
        except ImportError:
            self.skipTest("numpy / Pillow not installed")
        from qc_card import BAR_HEIGHT, BAR_HEIGHT_STD, bar_height, find_fonts, render_card
        bgr = np.full((540, 960, 3), 90, dtype=np.uint8)
        before = bgr.copy()
        cases = ((rec3(std_mode=False), BAR_HEIGHT),
                 (rec3(z=36, std_mode=True, std_pass=False), BAR_HEIGHT_STD),
                 (rec3(std_mode=True, std_pass=True), BAR_HEIGHT_STD))
        for rec, bar in cases:
            v = judge(rec, Rules())
            card = render_card(bgr, rec, time.time(), v, find_fonts())
            self.assertEqual(card.shape, (540 + bar, 960, 3))
            self.assertEqual(bar_height(960, rec), bar)
        self.assertTrue((bgr == before).all(), "render_card modified its input")


class StaffRecordTest(unittest.TestCase):
    def test_flags(self):
        f = make_flags(2, SRC_STAFF, 1)
        self.assertEqual(f & 0x31, 0x10 | FLAG_STAFF)      # wire source 1 + bit 0
        self.assertEqual(parse_flags(f).src, SRC_STAFF)
        self.assertEqual(parse_flags(make_flags(2, SRC_NORMAL, 1)).src, SRC_NORMAL)
        self.assertEqual(SRC_NAMES[SRC_STAFF], "staff")

    def test_policy_keeps_every_staff_record_and_leaves_the_timer_alone(self):
        p = SecurityPolicy(normal_interval_s=1800.0)
        self.assertEqual(p.decide(0.0, False, 0.0), (True, None))
        self.assertEqual(p.decide_staff(), (True, None))
        self.assertEqual(p.decide_staff(), (True, None))
        self.assertEqual(p.staff, 2)
        self.assertFalse(p.decide(60.0, False, 60.0)[0])     # normal still 30 min
        self.assertTrue(p.decide(1800.0, False, 1800.0)[0])

    def test_default_normal_interval_is_30_min(self):
        import evs_receiver
        self.assertEqual(evs_receiver.DEFAULT_NORMAL_INTERVAL_S, 1800.0)
        p = SecurityPolicy()
        self.assertTrue(p.decide(0.0, False, 0.0)[0])
        self.assertFalse(p.decide(1799.0, False, 1799.0)[0])
        self.assertTrue(p.decide(1800.5, False, 1800.5)[0])

    def test_snapshot_server_has_the_staff_kind(self):
        from snapshot_server import KINDS, record_kind
        self.assertIn("staff", KINDS)
        self.assertEqual(record_kind({"trigger": "staff"}), "staff")


class HalfResSecurityTest(unittest.TestCase):
    """10-29 (user): security pictures at the live resolution, no stitching."""

    def test_phase_zero_image_is_the_plain_frame(self):
        from fullres import Burst, PhaseZeroImage
        frames = {p: bytes([p]) * 8 for p in range(4)}
        b = Burst(1, 100, 0, SRC_NORMAL, 2, 2, 0.0, 0.0, frames)
        got = PhaseZeroImage(b, lambda data, w, h: (data, w, h))()
        self.assertEqual(got, (frames[0], 2, 2))
        self.assertEqual(PhaseZeroImage(b, None).resolution, "half")
        del frames[0]                                  # phase 0 lost: any other frame
        self.assertIn(PhaseZeroImage(b, lambda d, w, h: d)()[0], (1, 2, 3))

    def test_alarm_interval_0_3_s(self):
        import evs_receiver
        self.assertEqual(evs_receiver.DEFAULT_ALARM_INTERVAL_S, 0.3)
        p = SecurityPolicy(alarm_interval_s=0.3)
        # live frames every 1/60 s for 1.2 s -> one every ~0.3 s, not every frame
        keep = [t for t in range(72) if p.decide(10.0 + t / 60, True, 0.0)[0]]
        self.assertEqual(len(keep), 5)
        self.assertEqual(p.events, 1)


class BoardStateTest(unittest.TestCase):
    @staticmethod
    def status(byte11: int) -> bytes:
        return b"EVDBG1" + bytes(5) + bytes([byte11]) + b"\x00\r\n\x01"

    def test_byte_11(self):
        # endpoint layout: [1:0] mode, [2] std, [3] single target,
        # [4] face capture, [5] face debug, [6] staff; then << 1 | phy_link
        ui = 2 | (1 << 2) | (1 << 6)
        s = board_state(self.status(ui << 1 | 1))
        self.assertEqual((s.mode, s.std_part, s.staff_pass), (2, True, True))
        self.assertEqual((s.mode_name, s.view_text), ("质检", "标准件"))
        self.assertEqual(decode_status(self.status(ui << 1 | 1))["phy_link"], 1)
        self.assertEqual(decode_status(self.status(ui << 1 | 1))["ui"], ui)

    def test_views(self):
        self.assertEqual(BoardState.from_byte((1 | 1 << 3) << 1).view_text, "单目标")
        self.assertEqual(BoardState.from_byte(1 << 1).view_text, "多目标")
        self.assertEqual(BoardState.from_byte((3 | 1 << 4) << 1).view_text, "采集档")
        self.assertEqual(BoardState.from_byte((3 | 1 << 5) << 1).view_text, "调试档")

    def test_old_bit_reporting_zero_is_not_taken_as_a_state(self):
        bar = ControlBar(Commander(("127.0.0.1", 9)))
        bar.update_state(BoardState.from_byte(1))           # phy_link only
        self.assertIsNone(bar.state)
        bar.update_state(BoardState.from_byte((1 << 1) | 1))
        self.assertEqual(bar.state.mode, 1)
        bar.update_state(BoardState.from_byte(1))           # 原图 after a real state: shown
        self.assertEqual(bar.state.mode, 0)
        bar.commander.close()


class AlarmTailTest(unittest.TestCase):
    """10-29 board: the last alarm pictures showed an empty room."""

    def test_pictures_wait_for_the_next_report(self):
        from snapshots import AlarmBuffer
        b = AlarmBuffer(hold_s=1.4)
        self.assertEqual(b.on_burst(0.0, True, 2), [])       # alarm starts
        b.add("p1"); b.add("p2")
        self.assertEqual(b.on_burst(1.0, True, 3), ["p1", "p2"])   # still someone: kept
        self.assertEqual(b.src, 3)
        b.add("p3"); b.add("p4")
        b.expire(2.3)
        self.assertEqual(b.pending, ["p3", "p4"])            # not yet
        b.expire(2.5)                                        # no report for 1.4 s: they left
        self.assertEqual((b.pending, b.dropped, b.active(2.5)), ([], 2, False))

    def test_a_normal_burst_drops_the_tail_at_once(self):
        from snapshots import AlarmBuffer
        b = AlarmBuffer()
        b.on_burst(0.0, True)
        b.add("p1")
        self.assertEqual(b.on_burst(1.0, False), [])
        self.assertEqual((b.dropped, b.active(1.1)), (1, False))


class CommandTest(unittest.TestCase):
    def test_encoding_matches_evs_cmd_rx(self):
        d = make_cmd(CMD_SET_MODE, 2)
        self.assertEqual(d[:7], b"EVCMD\x01\x02")
        x = 0
        for b in d[:7]:
            x ^= b
        self.assertEqual((len(d), d[7]), (8, x))

    def test_commander_and_keys_send_the_right_datagrams(self):
        rx = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        rx.bind(("127.0.0.1", 0))
        rx.settimeout(1.0)
        bar = ControlBar(Commander(rx.getsockname()))
        try:
            self.assertTrue(bar.on_key(ord("3")))            # 质检
            bar.act(("std", 1))
            bar.act(("key2",))
            self.assertTrue(bar.on_key(ord("1")))            # 原图
            self.assertFalse(bar.on_key(ord("q")))
            got = [rx.recvfrom(64)[0] for _ in range(4)]
            self.assertEqual(got, [make_cmd(CMD_SET_MODE, 2), make_cmd(CMD_STD_PART, 1),
                                   make_cmd(CMD_KEY2, 0), make_cmd(CMD_SET_MODE, 0)])
        finally:
            bar.commander.close()
            rx.close()

    def test_bar_composes_and_maps_clicks(self):
        try:
            import cv2
            import numpy as np
            import PIL  # noqa: F401
        except ImportError:
            self.skipTest("cv2 / numpy / Pillow not installed")
        rx = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        rx.bind(("127.0.0.1", 0))
        rx.settimeout(1.0)
        bar = ControlBar(Commander(rx.getsockname()))
        try:
            bar.update_state(BoardState.from_byte(2 << 1))  # 质检
            out = bar.compose(np.zeros((540, 960, 3), np.uint8))
            self.assertEqual(out.shape[1], 960)
            self.assertGreater(out.shape[0], 540)
            self.assertEqual([b.label for b in bar.buttons],
                             ["原图", "安防", "质检", "任意", "标准件", "去皮"])   # 11-01: 三棱柱 hidden
            b = bar.buttons[1]                                # 安防
            bar.on_mouse(cv2.EVENT_LBUTTONUP, (b.x0 + b.x1) // 2, 560)
            self.assertEqual(rx.recvfrom(64)[0], make_cmd(CMD_SET_MODE, 1))
            # 10-29 board bug: later frames hit the bar's image cache, and the
            # buttons lost their positions -- clicks after frame 1 did nothing.
            frame = np.zeros((540, 960, 3), np.uint8)
            for _ in range(3):
                bar.compose(frame)
            b = bar.buttons[2]                                # 质检
            self.assertGreater(b.x1, b.x0)
            bar.on_mouse(cv2.EVENT_LBUTTONUP, (b.x0 + b.x1) // 2, 560)
            self.assertEqual(rx.recvfrom(64)[0], make_cmd(CMD_SET_MODE, 2))
            # a click on the picture sends nothing
            bar.on_mouse(cv2.EVENT_LBUTTONUP, 100, 100)
            rx.settimeout(0.2)
            with self.assertRaises(socket.timeout):
                rx.recvfrom(64)
        finally:
            bar.commander.close()
            rx.close()


if __name__ == "__main__":
    unittest.main()
