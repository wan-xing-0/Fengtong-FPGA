"""Portable XLSX export: one dated worksheet per day, formula summaries.

Uses Python's standard library so the receiver's existing Python needs no install.
"""
import csv
import io
import re
import zipfile
from xml.sax.saxutils import escape
import qc_stats

NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'

def text(value):
    return escape(re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', '', str(value)))

def cell(col, row, value, style=0, formula=None):
    if row == 3:
        style = {0: 4, 2: 5, 3: 6}.get(style, style)
    ref = f'{col}{row}'
    if formula is not None:
        return f'<c r="{ref}" s="{style}"><f>{text(formula)}</f><v>{value if value is not None else 0}</v></c>'
    if isinstance(value, (int, float)):
        return f'<c r="{ref}" s="{style}"><v>{value}</v></c>'
    return f'<c r="{ref}" s="{style}" t="inlineStr"><is><t xml:space="preserve">{text(value)}</t></is></c>'

def to_xlsx(records, part='all'):
    groups = {}
    for r in sorted(qc_stats.select(records, part), key=lambda r: r.get('epoch', 0)):
        day = r.get('day') or (r.get('time') or '')[:10].replace('-', '')
        name = f'{day[:4]}-{day[4:6]}-{day[6:]}' if re.fullmatch(r'\d{8}', day) else '日期未知'
        groups.setdefault(name, []).append(r)
    if not groups: groups['无记录'] = []
    out = io.BytesIO()
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
        sheets = []
        for idx, (name, recs) in enumerate(sorted(groups.items()), 1):
            sheets.append(f'<sheet name="{name}" sheetId="{idx}" r:id="rId{idx}"/>')
            s = qc_stats.summary(recs)
            end = max(5, 4 + len(recs))
            verdict = f'M5:M{end}'
            rows = []
            rows.append('<row r="1" ht="32" customHeight="1">'+cell('A',1,name+' 质检日报',1)+'</row>')
            labels = ['记录总数','已检件数','未判定','平均长mm','平均宽mm','平均厚mm','平均长偏差','平均宽偏差','平均厚偏差','合格件数','不合格件数','合格率']
            rows.append('<row r="2" ht="28" customHeight="1">'+''.join(cell(chr(65+i),2,v,1) for i,v in enumerate(labels))+'</row>')
            cells = [cell('A',3,len(recs),formula=f'COUNTA(A5:A{end})'), cell('B',3,s['total'],formula='J3+K3'), cell('C',3,s['unjudged'],formula='A3-B3')]
            cells += [cell(c,3,s['averages'][k],2,f'IFERROR(AVERAGE({c}5:{c}{end}),0)') for c,k in zip('DEFGHI',('x_mm','y_mm','z_mm','dx','dy','dz'))]
            cells += [cell('J',3,s['pass'],formula=f'COUNTIF({verdict},"合格")'),cell('K',3,s['fail'],formula=f'COUNTIF({verdict},"不合格")'),cell('L',3,s['pass_rate'],3,f'IFERROR(J3/B3,0)')]
            rows.append('<row r="3" ht="28" customHeight="1">'+''.join(cells)+'</row>')
            rows.append('<row r="4">'+''.join(cell(chr(65+i),4,v,1) for i,v in enumerate(qc_stats.CSV_FIELDS))+'</row>')
            data = list(csv.reader(io.StringIO(qc_stats.to_csv(recs).decode('utf-8-sig'))))[1:]
            for rownum, values in enumerate(data,5):
                values[1] = rownum - 4
                if values[12] not in ("合格", "不合格"): values[12] = "未判定"
                cells = []
                for i,v in enumerate(values):
                    if v and i in (1,3,4,5,6,7,8,14,15):
                        try: v = float(v)
                        except ValueError: pass
                    cells.append(cell(chr(65+i),rownum,v,2 if i in range(3,9) else 0))
                rows.append(f'<row r="{rownum}">'+''.join(cells)+'</row>')
            rows.append(f'<row r="{end+2}">'+cell('A',end+2,'备注：编号按当日导出记录从1开始；已检=合格+不合格；未判定单列；均值忽略空值；汇总统计本页全部记录；文件为导出时快照。')+'</row>')
            widths = [28,14,18,14,14,14,16,16,16,14,14,14,14,20,14,14,48]
            cols = ''.join(f'<col min="{i}" max="{i}" width="{w}" customWidth="1"/>' for i,w in enumerate(widths,1))
            z.writestr(f'xl/worksheets/sheet{idx}.xml',f'<worksheet xmlns="{NS}"><sheetViews><sheetView workbookViewId="0"><pane ySplit="4" topLeftCell="A5" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>{cols}</cols><sheetData>'+''.join(rows)+f'</sheetData><autoFilter ref="A4:Q{end}"/><mergeCells count="1"><mergeCell ref="A1:Q1"/></mergeCells></worksheet>')
        count = len(groups)
        z.writestr('xl/workbook.xml',f'<workbook xmlns="{NS}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>'+''.join(sheets)+'</sheets><calcPr calcId="0" fullCalcOnLoad="1"/></workbook>')
        relns='http://schemas.openxmlformats.org/package/2006/relationships'
        base='http://schemas.openxmlformats.org/officeDocument/2006/relationships/'
        z.writestr('_rels/.rels',f'<Relationships xmlns="{relns}"><Relationship Id="rId1" Type="{base}officeDocument" Target="xl/workbook.xml"/></Relationships>')
        z.writestr('xl/_rels/workbook.xml.rels',f'<Relationships xmlns="{relns}">'+''.join(f'<Relationship Id="rId{i}" Type="{base}worksheet" Target="worksheets/sheet{i}.xml"/>' for i in range(1,count+1))+f'<Relationship Id="rId{count+1}" Type="{base}styles" Target="styles.xml"/></Relationships>')
        z.writestr('xl/styles.xml',f'<styleSheet xmlns="{NS}"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF243B53"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf/></cellStyleXfs><cellXfs count="7"><xf xfId="0"/><xf xfId="0" fontId="1" fillId="2" applyFont="1" applyFill="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf><xf xfId="0" numFmtId="2" applyNumberFormat="1"/><xf xfId="0" numFmtId="10" applyNumberFormat="1"/><xf xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf><xf xfId="0" numFmtId="2" applyNumberFormat="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf><xf xfId="0" numFmtId="10" applyNumberFormat="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>')
        overrides = '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>' + ''.join(f'<Override PartName="/xl/worksheets/sheet{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' for i in range(1,count+1))
        z.writestr('[Content_Types].xml','<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>'+overrides+'</Types>')
    return out.getvalue()
