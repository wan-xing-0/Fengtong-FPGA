"""EVQC1 workpiece records: decode, de-duplicate, pair with a frame, save.

The FPGA (evs_aux_tx.v) sends one 32-byte EVQC1 datagram per workpiece, three
times 100 ms apart, on the same port as the video::

    0..4   b"EVQC1"
    5      version (1)
    6      repeat index 0..2
    7      repeat total (3)
    8..9   video frame_sequence[15:0] when the record reached the Ethernet side
    10..11 0
    12..27 qc_rec[127:0], big-endian -- layout in qc_thick.v's header:
             [127] valid  [126] base known
             [119:104] X mm  [103:88] Y mm  [87:72] Z mm
             [71:56] TOP mm  [55:40] BASE mm
             [39:28] box width px  [27:16] box height px  [15:8] qc_seq
    28..30 0
    31     XOR of bytes 0..30

EVQC2 (2026-10-09, evs_aux_tx QC_V2=1, 48 bytes) is the same record plus
qc_ext, the rest of the card -- shape, surface defects, colour:

    0..4   b"EVQC2"      5  version (2)      6..27  as EVQC1
    28..43 qc_ext[127:0], big-endian -- layout in system_top.v (qc_ext block):
             [127] present  [126] shape valid  [125:124] shape  [123:120] vote
             [119] object seen  [118] surface defect
             [117] colour valid  [116:113] colour class (obj_color_detect,
                   0 black 1 gray 2 white 3 red 4 orange 5 yellow 6 green
                   7 cyan 8 blue 9 purple)
             [111:104] hole  [103:96] stain  [95:88] scratch cells
             [87:72] interior cells  [71:48] mean R, G, B
             [47:36] x0 [35:24] y0 [23:12] x1 [11:0] y1  defect box, px
    44..46 0
    47     XOR of bytes 0..46

  Both are accepted, so an EVQC1 bit still gives a size-only card.

  2026-10-29, LAYOUT 3 (byte 5 = 3, same 48 bytes).  The card follows the
  inspection page's two modes, and the retired qc_defect's fields are gone:

             [127..120] as above
             [119] stain judged  [118] stain (stain_detect, voted)
             [117] colour valid  [116:113] colour class, as above
             [112] standard-part mode (标准件)
             [111] verdict valid  [110] 合格 (qc_std's, the OSD 判定 row)
             [103:96] stain hot cells
             [71:48] mean R, G, B (obj_color_detect)
             everything else 0

  The standard part's nominal sizes and tolerances are not in the packet:
  they are qc_std's parameters, mirrored in STD_PART below.  Layout 2 records
  (a 10-09..10-28 bit) are read and judged exactly as before.

  2026-10-31 (Anlogic_update), still layout 3 -- bits that were 0 before, so
  an older bit reads as 方块 / no count:
             [109:108] standard part: 0 任意, 1 方块 (P1), 3 三棱柱 (P5, yellow)
                       (0 with [112] set = a 10-29..10-30 bit = 方块)
             [95:86]   FPGA count: parts judged in this batch, this one included
             [85:76]   FPGA count: of them passed
  STD_PARTS below has both parts; STD_PART stays the cube.

WHICH FRAME GOES ON THE CARD
  Byte 8..9 is the frame that was streaming when the record arrived, so it
  began before the trigger.  The card uses the first COMPLETE frame at least
  FRAME_OFFSET (2) after it: +1 is the first frame sampled after the trigger,
  and one more makes sure the OSD has redrawn its 稳定 #n row.  If that frame
  never completes (dropped on the network) the record waits at most
  MATCH_TIMEOUT_S and then takes the newest frame it has, marked "late" in
  the index -- qc_stable only rises after the box has held still for many
  frames, so any frame from around then shows the same workpiece.

  2026-10-09, full resolution: qc_trig also starts a four-frame burst on the
  FPGA (fullres.py).  With wait_burst the record waits up to BURST_WAIT_S for
  the first QC burst that starts after the frame it names and the card is
  1920x1080; the frame chosen as above is kept and used only if no burst
  comes ("resolution": "half" in the index).

Everything that costs milliseconds -- RGB565 conversion, card drawing, two
JPEG encodes, disk -- runs on QcWriter's thread.  The receive thread only
parses 32 bytes and compares sequence numbers.
"""
from __future__ import annotations

import json
import queue
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable

QC_MAGIC = b"EVQC1"
QC_SIZE = 32
QC_VERSION = 1
QC2_MAGIC = b"EVQC2"
QC2_SIZE = 48
QC2_VERSION = 2
QC3_VERSION = 3            # 2026-10-29: qc_ext layout 3, same magic and size
QC2_VERSIONS = (QC2_VERSION, QC3_VERSION)

# The one standard part (system_top QC_P1_*, qc_std TOL_XY_MM / TOL_Z_MM).
# W / H / Z as the camera sees it = the record's x / y / z.  Change it
# together with the RTL, or the card's deviations disagree with the OSD.
STD_PART = {"name": "标准件", "x": 60, "y": 60, "z": 30, "tol_xy": 3, "tol_z": 5}
# 2026-10-31: per qc_std mode ([109:108]).  shape = shape_vote class, colours =
# obj_color classes that pass (system_top STD_COLOR_MASK / STD_COLOR_MASK3).
STD_PARTS = {
    1: {**STD_PART, "key": "cube", "shape": 2, "colours": (1, 2)},          # 方块：矩形，白 / 灰
    3: {"name": "三棱柱", "x": 60, "y": 52, "z": 30, "tol_xy": 3, "tol_z": 5,
        "key": "tri", "shape": 3, "colours": (4, 5)},                      # 三角形，黄 / 橙
}

SHAPE_NAMES = ("其他", "圆形", "矩形", "三角形")
# Colour classes of obj_color_detect (qc_ext [116:113], valid [117]; 10-11),
# in its stable_id order: 0 black 1 gray 2 white ... 9 purple, 15 = none.
# While [117] is 0 the PC names the colour from the mean RGB
# (colour_name_from_rgb).
COLOR_NAMES = ("黑色", "灰色", "白色", "红色", "橙色", "黄色", "绿色", "青色",
               "蓝色", "紫色")


def colour_name_from_rgb(r: int, g: int, b: int) -> str:
    """A coarse colour word for the workpiece's mean RGB (gamma-encoded 0..255).

    Interim: the board's colour classifier will replace it (qc_ext [117]).
    Thresholds are for a part lit by the fill light on a dark backdrop.
    """
    import colorsys
    h, s, v = colorsys.rgb_to_hsv(r / 255, g / 255, b / 255)
    if v < 0.20:
        return "黑色"
    if s < 0.20:
        return "白色" if v > 0.75 else "灰色"
    deg = h * 360
    for limit, name in ((15, "红色"), (40, "橙色"), (70, "黄色"), (170, "绿色"),
                        (200, "青色"), (260, "蓝色"), (330, "紫色")):
        if deg < limit:
            return name
    return "红色"


@dataclass(frozen=True)
class QcExt:
    """qc_ext: what EVQC2 adds to the size record (layout in the docstring)."""
    present: bool
    shape_valid: bool
    shape: int
    shape_conf: int
    obj: bool
    defect: bool
    colour_valid: bool
    colour_cls: int
    hole: int
    stain: int
    edge: int
    interior: int
    mean_rgb: tuple
    box: tuple
    # layout 3 (2026-10-29); defaults = a layout-2 record
    layout: int = 2
    std_mode: bool = False
    std_valid: bool = False
    std_pass: bool = False
    # 2026-10-31 (layout 3, bits that were 0 before)
    std_kind: int = 0           # 0 任意, 1 方块, 3 三棱柱
    fpga_count: int = 0         # parts judged in the FPGA's batch, this one included
    fpga_pass: int = 0

    @classmethod
    def from_bytes(cls, raw: bytes, layout: int = 2) -> "QcExt":
        e = int.from_bytes(raw, "big")
        if layout >= 3:
            return cls(
                present=bool(e >> 127 & 1),
                shape_valid=bool(e >> 126 & 1),
                shape=e >> 124 & 0x3,
                shape_conf=e >> 120 & 0xF,
                obj=bool(e >> 119 & 1),
                defect=bool(e >> 118 & 1),
                colour_valid=bool(e >> 117 & 1),
                colour_cls=e >> 113 & 0xF,
                hole=0,
                stain=e >> 96 & 0xFF,
                edge=0,
                interior=0,
                mean_rgb=(e >> 64 & 0xFF, e >> 56 & 0xFF, e >> 48 & 0xFF),
                box=(0, 0, 0, 0),
                layout=3,
                std_mode=bool(e >> 112 & 1),
                std_valid=bool(e >> 111 & 1),
                std_pass=bool(e >> 110 & 1),
                # a 10-29 bit sets [112] and leaves [109:108] at 0: that was the cube
                std_kind=(e >> 108 & 3) or (1 if e >> 112 & 1 else 0),
                fpga_count=e >> 86 & 0x3FF,
                fpga_pass=e >> 76 & 0x3FF,
            )
        return cls(
            present=bool(e >> 127 & 1),
            shape_valid=bool(e >> 126 & 1),
            shape=e >> 124 & 0x3,
            shape_conf=e >> 120 & 0xF,
            obj=bool(e >> 119 & 1),
            defect=bool(e >> 118 & 1),
            colour_valid=bool(e >> 117 & 1),
            colour_cls=e >> 113 & 0xF,
            hole=e >> 104 & 0xFF,
            stain=e >> 96 & 0xFF,
            edge=e >> 88 & 0xFF,
            interior=e >> 72 & 0xFFFF,
            mean_rgb=(e >> 64 & 0xFF, e >> 56 & 0xFF, e >> 48 & 0xFF),
            box=(e >> 36 & 0xFFF, e >> 24 & 0xFFF, e >> 12 & 0xFFF, e & 0xFFF),
        )

    def to_bytes(self) -> bytes:
        """The 16 qc_ext bytes system_top would latch (tests, fake records)."""
        if self.layout >= 3:
            e = (int(self.present) << 127 | int(self.shape_valid) << 126 | (self.shape & 3) << 124
                 | (self.shape_conf & 0xF) << 120 | int(self.obj) << 119 | int(self.defect) << 118
                 | int(self.colour_valid) << 117 | (self.colour_cls & 0xF) << 113
                 | int(self.std_mode) << 112 | int(self.std_valid) << 111 | int(self.std_pass) << 110
                 | (self.std_kind & 3) << 108
                 | (self.stain & 0xFF) << 96
                 | (self.fpga_count & 0x3FF) << 86 | (self.fpga_pass & 0x3FF) << 76
                 | (self.mean_rgb[0] & 0xFF) << 64 | (self.mean_rgb[1] & 0xFF) << 56
                 | (self.mean_rgb[2] & 0xFF) << 48)
            return e.to_bytes(16, "big")
        e = (int(self.present) << 127 | int(self.shape_valid) << 126 | (self.shape & 3) << 124
             | (self.shape_conf & 0xF) << 120 | int(self.obj) << 119 | int(self.defect) << 118
             | int(self.colour_valid) << 117 | (self.colour_cls & 0xF) << 113
             | (self.hole & 0xFF) << 104 | (self.stain & 0xFF) << 96 | (self.edge & 0xFF) << 88
             | (self.interior & 0xFFFF) << 72
             | (self.mean_rgb[0] & 0xFF) << 64 | (self.mean_rgb[1] & 0xFF) << 56
             | (self.mean_rgb[2] & 0xFF) << 48
             | (self.box[0] & 0xFFF) << 36 | (self.box[1] & 0xFFF) << 24
             | (self.box[2] & 0xFFF) << 12 | (self.box[3] & 0xFFF))
        return e.to_bytes(16, "big")

    @classmethod
    def sample(cls, shape: int = 1, rgb=(200, 40, 40), hole: int = 0, stain: int = 0,
               edge: int = 0, shape_valid: bool = True, obj: bool = True) -> "QcExt":
        """A plausible ext for tests and sample cards."""
        bad = obj and (hole + stain + edge) >= 2
        return cls(True, shape_valid, shape, 12 if shape_valid else 2, obj, bad, False, 0,
                   hole, stain, edge, 180 if obj else 0, tuple(rgb) if obj else (0, 0, 0),
                   (800, 400, 880, 464) if bad else (4080, 4080, 16, 16))

    @classmethod
    def sample3(cls, shape: int = 2, colour_cls: int = 3, rgb=(200, 40, 40),
                stained: bool = False, std_mode: bool = False, std_valid: bool = True,
                std_pass: bool = True, shape_valid: bool = True,
                judged: bool = True, std_kind: "int | None" = None,
                fpga_count: int = 0, fpga_pass: int = 0) -> "QcExt":
        """A layout-3 ext (2026-10-29) for tests, sample cards and send_fake_qc.
        std_kind (10-31): 1 方块 / 3 三棱柱; None = 1 when std_mode."""
        kind = (1 if std_mode else 0) if std_kind is None else (std_kind if std_mode else 0)
        return cls(True, shape_valid, shape, 12 if shape_valid else 2, judged,
                   judged and stained, colour_cls < 10, colour_cls & 0xF, 0,
                   (6 if stained else 0) if judged else 0, 0, 0, tuple(rgb), (0, 0, 0, 0),
                   3, std_mode, std_mode and std_valid,
                   std_mode and std_valid and std_pass, kind, fpga_count, fpga_pass)

    @property
    def std_part(self) -> "dict | None":
        """The standard part this record was judged against (10-31), None in 任意."""
        if not self.std_mode:
            return None
        return STD_PARTS.get(self.std_kind, STD_PARTS[1])

    @property
    def stain_text(self) -> str:
        """The 污渍 field (layout 3)."""
        if not self.obj:
            return "未检测"
        return "有污渍" if self.defect else "无污渍"

    @property
    def shape_name(self) -> str:
        return SHAPE_NAMES[self.shape] if self.shape_valid else "未识别"

    @property
    def colour_name(self) -> str:
        if self.colour_valid and self.colour_cls < len(COLOR_NAMES):
            return COLOR_NAMES[self.colour_cls]
        if not self.obj:
            return "未知"
        return colour_name_from_rgb(*self.mean_rgb)

    @property
    def surface_text(self) -> str:
        if self.layout >= 3:
            return self.stain_text
        if not self.obj:
            return "未检测"
        if not self.defect:
            return "无缺陷"
        parts = [f"{name}{n}" for name, n in (("孔洞", self.hole), ("污渍", self.stain),
                                               ("划痕", self.edge)) if n]
        return "有缺陷（" + " ".join(parts) + "）" if parts else "有缺陷"
FRAME_OFFSET = 2
MATCH_TIMEOUT_S = 0.5
# Repeats are 100 ms apart; anything identical within this window is a repeat,
# not a new workpiece.  qc_thick never re-sends the same record on its own
# (a same-workpiece re-rise does not trigger), so the window can be generous.
DEDUP_S = 5.0
QUEUE_DEPTH = 8
DEFAULT_JPEG_QUALITY = 90


@dataclass(frozen=True)
class QcRecord:
    valid: bool
    base_ok: bool
    x_mm: int
    y_mm: int
    z_mm: int
    top_mm: int
    base_mm: int
    box_w_px: int
    box_h_px: int
    seq: int
    raw: bytes                 # the 16 record bytes, the de-duplication key
    ext: "QcExt | None" = None  # EVQC2 only; None from an EVQC1 bit

    @classmethod
    def from_bytes(cls, raw: bytes, ext_raw: "bytes | None" = None,
                   layout: int = 2) -> "QcRecord":
        r = int.from_bytes(raw, "big")
        return cls(
            valid=bool(r >> 127 & 1),
            base_ok=bool(r >> 126 & 1),
            x_mm=r >> 104 & 0xFFFF,
            y_mm=r >> 88 & 0xFFFF,
            z_mm=r >> 72 & 0xFFFF,
            top_mm=r >> 56 & 0xFFFF,
            base_mm=r >> 40 & 0xFFFF,
            box_w_px=r >> 28 & 0xFFF,
            box_h_px=r >> 16 & 0xFFF,
            seq=r >> 8 & 0xFF,
            raw=bytes(raw),
            ext=QcExt.from_bytes(ext_raw, layout) if ext_raw is not None else None,
        )


@dataclass(frozen=True)
class QcPacket:
    record: QcRecord
    repeat: int
    repeat_total: int
    frame_seq16: int


def is_qc(datagram: bytes) -> bool:
    return ((len(datagram) == QC_SIZE and datagram.startswith(QC_MAGIC))
            or (len(datagram) == QC2_SIZE and datagram.startswith(QC2_MAGIC)))


def make_qc_datagram(record_raw: bytes, frame_seq16: int, repeat: int = 0,
                     repeat_total: int = 3, ext_raw: "bytes | None" = None,
                     version: int = QC2_VERSION) -> bytes:
    """Reference encoding, byte-for-byte what evs_aux_tx.v sends.

    ext_raw (16 bytes) given: EVQC2 (QC_V2=1) with byte 5 = `version` (2, or 3
    for the 10-29 layout); otherwise EVQC1.
    """
    if ext_raw is None:
        head, tail = QC_MAGIC + bytes([QC_VERSION]), record_raw + b"\0\0\0"
    else:
        head, tail = QC2_MAGIC + bytes([version]), record_raw + ext_raw + b"\0\0\0"
    body = (head + bytes([repeat, repeat_total]) + frame_seq16.to_bytes(2, "big")
            + b"\0\0" + tail)
    x = 0
    for b in body:
        x ^= b
    return body + bytes([x])


def parse_qc(datagram: bytes) -> QcPacket | None:
    if not is_qc(datagram):
        return None
    v2 = len(datagram) == QC2_SIZE
    if v2 and datagram[5] not in QC2_VERSIONS:
        return None
    if not v2 and datagram[5] != QC_VERSION:
        return None
    x = 0
    for b in datagram[:-1]:
        x ^= b
    if x != datagram[-1]:
        return None
    rec = QcRecord.from_bytes(datagram[12:28], datagram[28:44] if v2 else None,
                              layout=datagram[5] if v2 else 2)
    return QcPacket(rec, datagram[6], datagram[7], int.from_bytes(datagram[8:10], "big"))


def extend_seq16(seq16: int, near: int | None) -> int:
    """The 32-bit sequence closest to `near` whose low 16 bits are `seq16`."""
    if near is None:
        return seq16
    diff = (seq16 - near) & 0xFFFF
    return near + diff if diff < 0x8000 else near - (0x10000 - diff)


def seq_at_or_after(seq: int, target: int) -> bool:
    return ((seq - target) & 0xFFFFFFFF) < 0x80000000


def seq_after(seq: int, ref: int) -> bool:
    return seq != ref and seq_at_or_after(seq, ref)


@dataclass
class Pending:
    record: QcRecord
    repeat: int
    target_seq: int
    arrived: float
    record_seq: int = 0        # the extended frame number the record carried
    # (sequence, image, w, h, wall) of the first frame >= target, kept while
    # waiting for a full-resolution burst in case none arrives.
    fallback: tuple | None = None


@dataclass
class QcJob:
    record: QcRecord
    repeat: int
    frame_seq: int
    image: bytes               # RGB565 frame, immutable (b"" for a burst job)
    width: int
    height: int
    wall_time: float
    match: str                 # "ok" | "late" | "burst"
    burst: object = None       # fullres.Burst -> stitched 1920x1080 on the writer


@dataclass
class QcStats:
    packets: int = 0           # EVQC1 datagrams received
    bad: int = 0               # wrong version / XOR
    duplicates: int = 0        # repeats of a record already taken
    invalid: int = 0           # valid bit clear
    records: int = 0           # distinct workpieces
    late: int = 0
    unmatched: int = 0         # timed out with no frame at all
    fullres: int = 0           # paired with a full-resolution burst
    half: int = 0              # no burst in time, fell back to one 960x540 frame


# How long a record waits for its burst.  The burst starts QC_DELAY_VS (2)
# frames after the trigger and takes four frames: ~100 ms, plus a frame skipped
# here and there.  A second covers that with room; past it the FPGA is an old
# bit without bursts, or the burst was lost, and the card uses one frame.
BURST_WAIT_S = 1.0
RECENT_BURSTS = 4
RECENT_BURST_S = 2.0


class QcTracker:
    """Receive-thread side: turns EVQC1 datagrams + complete frames into jobs.

    With wait_burst (default when full resolution is on) a record is paired
    with the first QC-source burst that starts after the frame it names; the
    burst may complete before the record arrives (its first copy lost on the
    network, the 100 ms-later repeat after the burst), so recent unclaimed
    bursts are kept for RECENT_BURST_S.  Not thread-safe; owned by the
    receive thread.
    """

    def __init__(self, frame_offset: int = FRAME_OFFSET,
                 timeout_s: float = MATCH_TIMEOUT_S, dedup_s: float = DEDUP_S,
                 wait_burst: bool = False, burst_wait_s: float = BURST_WAIT_S) -> None:
        self.frame_offset = frame_offset
        self.timeout_s = timeout_s
        self.dedup_s = dedup_s
        self.wait_burst = wait_burst
        self.burst_wait_s = burst_wait_s
        self.stats = QcStats()
        self.pending: list[Pending] = []
        self._seen: dict[bytes, float] = {}
        self._last_frame: tuple[int, bytes, int, int, float] | None = None
        self._bursts: list[tuple[object, float]] = []   # (Burst, arrived)

    def _burst_job(self, p: Pending, burst) -> QcJob:
        self.stats.fullres += 1
        return QcJob(p.record, p.repeat, burst.base_seq, b"", burst.width, burst.height,
                     burst.wall_time, "burst", burst)

    def on_burst(self, burst, now: float | None = None) -> list[QcJob]:
        """A completed (or timed-out partial) QC-source burst."""
        now = time.monotonic() if now is None else now
        for i, p in enumerate(self.pending):
            if seq_after(burst.base_seq, p.record_seq):
                del self.pending[i]
                return [self._burst_job(p, burst)]
        self._bursts = [(b, t) for b, t in self._bursts if now - t <= RECENT_BURST_S]
        self._bursts.append((burst, now))
        del self._bursts[:-RECENT_BURSTS]
        return []

    def on_datagram(self, datagram: bytes, latest_seq: int | None,
                    now: float | None = None) -> list[QcJob]:
        """Returns a job at once if a matching burst has already arrived."""
        now = time.monotonic() if now is None else now
        self.stats.packets += 1
        pkt = parse_qc(datagram)
        if pkt is None:
            self.stats.bad += 1
            return []
        rec = pkt.record
        if not rec.valid:
            self.stats.invalid += 1
            return []
        for key in [k for k, t in self._seen.items() if now - t > self.dedup_s]:
            del self._seen[key]
        if rec.raw in self._seen:
            self.stats.duplicates += 1
            return []
        self._seen[rec.raw] = now
        self.stats.records += 1
        record_seq = extend_seq16(pkt.frame_seq16, latest_seq) & 0xFFFFFFFF
        p = Pending(rec, pkt.repeat, (record_seq + self.frame_offset) & 0xFFFFFFFF, now,
                    record_seq)
        if self.wait_burst:
            for i, (burst, _t) in enumerate(self._bursts):
                if seq_after(burst.base_seq, record_seq):
                    del self._bursts[i]
                    return [self._burst_job(p, burst)]
        self.pending.append(p)
        return []

    def on_frame(self, sequence: int, image: bytes, width: int, height: int,
                 wall_time: float) -> list[QcJob]:
        frame = (sequence, image, width, height, wall_time)
        self._last_frame = frame
        if not self.pending:
            return []
        if self.wait_burst:
            # Only remember the frame the half-resolution card would have
            # used; the burst decides when the job goes out.
            for p in self.pending:
                if p.fallback is None and seq_at_or_after(sequence, p.target_seq):
                    p.fallback = frame
            return []
        jobs, keep = [], []
        for p in self.pending:
            if seq_at_or_after(sequence, p.target_seq):
                jobs.append(QcJob(p.record, p.repeat, sequence, image, width, height,
                                  wall_time, "ok"))
            else:
                keep.append(p)
        self.pending = keep
        return jobs

    def sweep(self, now: float | None = None) -> list[QcJob]:
        if not self.pending:
            return []
        now = time.monotonic() if now is None else now
        wait = self.burst_wait_s if self.wait_burst else self.timeout_s
        jobs, keep = [], []
        for p in self.pending:
            if now - p.arrived <= wait:
                keep.append(p)
            elif p.fallback is not None:
                seq, image, w, h, wall = p.fallback
                self.stats.half += 1
                jobs.append(QcJob(p.record, p.repeat, seq, image, w, h, wall, "ok"))
            elif self._last_frame is None:
                self.stats.unmatched += 1
            else:
                seq, image, w, h, wall = self._last_frame
                self.stats.late += 1
                if self.wait_burst:
                    self.stats.half += 1
                jobs.append(QcJob(p.record, p.repeat, seq, image, w, h, wall, "late"))
        self.pending = keep
        return jobs


def qc_names(wall_time: float, seq: int) -> tuple[str, str, str]:
    """(day directory, card file, raw file)."""
    t = datetime.fromtimestamp(wall_time)
    stem = f"{t.strftime('%H%M%S')}_{t.microsecond // 1000:03d}_No{seq:03d}"
    return t.strftime("%Y%m%d"), stem + "_card.jpg", stem + "_raw.jpg"


def std_deviations(rec, part: "dict | None" = None) -> dict:
    """measured - nominal for the standard part, mm (x / y / z).  part (10-31):
    the record's own (ext.std_part); default the cube."""
    if part is None:
        ext = getattr(rec, "ext", None)
        part = (ext.std_part if ext is not None else None) or STD_PART
    return {"x": rec.x_mm - part["x"], "y": rec.y_mm - part["y"],
            "z": rec.z_mm - part["z"]}


def _ext_fields(ext: QcExt, rec) -> dict:
    """index.jsonl fields for the ext, by layout."""
    common = {"shape": ext.shape_name, "shape_conf": ext.shape_conf,
              "colour": ext.colour_name, "mean_rgb": list(ext.mean_rgb)}
    if ext.layout >= 3:
        out = {**common, "layout": 3, "stain": ext.stain_text, "stained": ext.defect,
               "stain_cells": ext.stain,
               "mode": "standard" if ext.std_mode else "any"}
        if ext.std_mode:
            part = ext.std_part
            out["std"] = {k: (list(v) if isinstance(v, tuple) else v) for k, v in part.items()}
            out["std_kind"] = part["key"]
            out["deviation_mm"] = std_deviations(rec, part)
            out["fpga_verdict"] = ("pass" if ext.std_pass else "fail") if ext.std_valid else "measuring"
        if ext.fpga_count:
            out["fpga_count"] = ext.fpga_count
            out["fpga_pass"] = ext.fpga_pass
        return out
    return {**common, "surface": ext.surface_text, "defect": ext.defect,
            "hole": ext.hole, "stain": ext.stain, "scratch": ext.edge,
            "defect_box": list(ext.box)}


def _encode_jpeg(image, quality: int) -> bytes:
    import cv2
    ok, buf = cv2.imencode(".jpg", image, [cv2.IMWRITE_JPEG_QUALITY, quality])
    if not ok:
        raise RuntimeError("JPEG 编码失败")
    return buf.tobytes()


@dataclass
class CardNotice:
    """What the display thread needs to show the corner thumbnail."""
    card: object               # BGR ndarray
    record: QcRecord
    shown_at: float = field(default_factory=time.monotonic)


class QcWriter:
    """Writer-thread side: RGB565 -> BGR, card, two JPEGs, index line.

    <root>/<YYYYMMDD>/<HHMMSS_mmm>_No<seq>_card.jpg / _raw.jpg / index.jsonl
    """

    def __init__(self, root: Path, to_bgr: Callable, render: Callable,
                 judge: Callable, quality: int = DEFAULT_JPEG_QUALITY,
                 encoder: Callable[[object, int], bytes] = _encode_jpeg) -> None:
        self.root = Path(root)
        self.to_bgr = to_bgr
        self.render = render          # (bgr, record, wall_time, verdict) -> card bgr
        self.judge = judge            # record -> Verdict
        self.quality = quality
        self.encoder = encoder
        self.queue: queue.Queue[QcJob | None] = queue.Queue(QUEUE_DEPTH)
        self.saved = 0
        self.dropped = 0
        self.failed = 0
        self.last_error: str | None = None
        self.last_card_path: Path | None = None
        self._notice_lock = threading.Lock()
        self._notice: CardNotice | None = None
        self._thread = threading.Thread(target=self._run, name="qc-writer", daemon=True)
        self._thread.start()

    def submit(self, job: QcJob) -> bool:
        try:
            self.queue.put_nowait(job)
            return True
        except queue.Full:
            self.dropped += 1
            return False

    def take_notice(self) -> CardNotice | None:
        with self._notice_lock:
            notice, self._notice = self._notice, None
        return notice

    def close(self, timeout: float = 5.0) -> None:
        self.queue.put(None)
        self._thread.join(timeout)

    def _run(self) -> None:
        while True:
            job = self.queue.get()
            if job is None:
                return
            try:
                card = self._write(job)
                self.saved += 1
                with self._notice_lock:
                    self._notice = CardNotice(card, job.record)
            except Exception as exc:  # keep going after a bad write
                self.failed += 1
                self.last_error = f"{type(exc).__name__}: {exc}"

    def _write_atomic(self, path: Path, data: bytes) -> None:
        tmp = path.with_name(path.name + ".part")
        tmp.write_bytes(data)
        tmp.replace(path)

    def _write(self, job: QcJob):
        if job.burst is not None:
            from fullres import stitch
            bgr, resolution, missing = stitch(job.burst, self.to_bgr)
        else:
            bgr, resolution, missing = self.to_bgr(job.image, job.width, job.height), "half", []
        verdict = self.judge(job.record)
        card = self.render(bgr, job.record, job.wall_time, verdict)
        day, card_name, raw_name = qc_names(job.wall_time, job.record.seq)
        directory = self.root / day
        directory.mkdir(parents=True, exist_ok=True)
        self._write_atomic(directory / raw_name, self.encoder(bgr, self.quality))
        card_data = self.encoder(card, self.quality)
        self._write_atomic(directory / card_name, card_data)
        rec = job.record
        line = {
            "file": card_name,
            "raw": raw_name,
            "time": datetime.fromtimestamp(job.wall_time).isoformat(timespec="milliseconds"),
            "epoch": round(job.wall_time, 3),
            "trigger": "qc",
            "qc_seq": rec.seq,
            "frame_seq": job.frame_seq,
            "frame_match": job.match,
            "resolution": resolution,
            "missing_phases": missing,
            "repeat_used": job.repeat,
            "x_mm": rec.x_mm, "y_mm": rec.y_mm, "z_mm": rec.z_mm,
            "top_mm": rec.top_mm, "base_mm": rec.base_mm,
            "box_w_px": rec.box_w_px, "box_h_px": rec.box_h_px,
            **({} if rec.ext is None else _ext_fields(rec.ext, rec)),
            "verdict": verdict.status,
            "failed": list(verdict.failed),
            "width": int(card.shape[1]),
            "height": int(card.shape[0]),
            "bytes": len(card_data),
        }
        with open(directory / "index.jsonl", "a", encoding="utf-8") as index:
            index.write(json.dumps(line, ensure_ascii=False) + "\n")
        self.last_card_path = directory / card_name
        return card
