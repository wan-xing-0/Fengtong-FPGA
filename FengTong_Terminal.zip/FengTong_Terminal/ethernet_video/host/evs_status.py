"""EVDBG1 状态报文解码。

FPGA 目前把这种 16 字节状态报文和视频包发往同一个 UDP 端口，所以接收端和
心跳监听器都要认识它：接收端必须静默忽略（否则会被计成 CRC 错误包，
2026-09-21 板测就是这样把几千个状态包读成了"视频校验失败"），而监听器要
把它解码出来。两边共用这一份解码，避免位定义漂移。

字节布局（对应 evs_aux_tx.v 的 diag_byte 函数；2026-10-04 前在 eth_a_video_endpoint.v）::

    0..5   b"EVDBG1"
    6..9   evs_video_tx_core 的 O_debug_status，大端
    10     O_debug_counts = {abort_count[3:0], done_count[3:0]}，两者均饱和于 15
    11     bit0 phy_link；bit7:1 = 板子当前模式（2026-10-29，eth_a_video_endpoint 头注释）：
             bit2:1 应用模式 0 原图 / 1 安防 / 2 质检 / 3 人脸
             bit3 质检选了标准件   bit4 安防单目标视图
             bit5 人脸采集档       bit6 人脸调试档   bit7 员工已核验
           2026-10-31（Anlogic_update）：人脸模式已删，bit6 改为「质检选了三棱柱
           标准件」（此时 bit3 也为 1）；老 bit 这一位恒 0 = 方块。
           旧 bit 这 7 位恒 0，读出来就是「原图、任意」——所以界面只在
           收到过非 0 的值以后才显示模式（见 BoardState.known）。
    12     udp_busy
    13..14 CRLF
    15     0x01
"""
from __future__ import annotations

from dataclasses import dataclass

STATUS_MAGIC = b"EVDBG1"
STATUS_SIZE = 16

BRIDGE_STATES = {0: "WAIT_START", 3: "STREAM"}
MODE_NAMES = ("原图", "安防", "质检", "人脸")


@dataclass(frozen=True)
class BoardState:
    """EVDBG1 byte 11 bits 7:1."""
    mode: int            # 0 原图 / 1 安防 / 2 质检 / 3 人脸
    std_part: bool
    single_target: bool
    face_capture: bool
    face_debug: bool
    staff_pass: bool
    raw: int

    @classmethod
    def from_byte(cls, b: int) -> "BoardState":
        u = b >> 1
        return cls(u & 3, bool(u >> 2 & 1), bool(u >> 3 & 1), bool(u >> 4 & 1),
                   bool(u >> 5 & 1), bool(u >> 6 & 1), u)

    @property
    def std_tri(self) -> bool:
        """10-31: the standard part is the 三棱柱 (bit6, was 人脸调试档)."""
        return self.std_part and self.face_debug

    @property
    def std_kind(self) -> int:
        """0 任意 / 1 方块 / 2 三棱柱 -- the EVCMD 3 argument that selects it."""
        return 0 if not self.std_part else (2 if self.std_tri else 1)

    @property
    def mode_name(self) -> str:
        return MODE_NAMES[self.mode]

    @property
    def view_text(self) -> str:
        """What key2 has selected in the current mode, as the OSD would say."""
        if self.mode == 1:
            return "单目标" if self.single_target else "多目标"
        if self.mode == 2:
            return ("三棱柱" if self.std_tri else "标准件") if self.std_part else "任意"
        if self.mode == 3:
            return "调试档" if self.face_debug else ("采集档" if self.face_capture else "识别")
        return ""


def board_state(datagram: bytes) -> BoardState | None:
    if not is_status(datagram):
        return None
    return BoardState.from_byte(datagram[11])


def is_status(datagram: bytes) -> bool:
    """状态报文与视频包的区分依据；视频包最小 33 字节且以 EVS1 开头。"""
    return len(datagram) == STATUS_SIZE and datagram.startswith(STATUS_MAGIC)


def decode_status(datagram: bytes) -> dict[str, int | str] | None:
    if not is_status(datagram):
        return None
    status = int.from_bytes(datagram[6:10], "big")
    counts = datagram[10]
    bridge = (status >> 8) & 0x7
    return {
        "can_eth": status & 1,
        "can_video": (status >> 1) & 1,
        "fifo_empty": (status >> 2) & 1,
        "fifo_afull": (status >> 3) & 1,
        "fifo_full": (status >> 4) & 1,
        "fifo_valid": (status >> 5) & 1,
        # 位 [7:6] 原为 held_valid/read_pending；改用 skid buffer 读通路后
        # 这两个寄存器已不存在，现在是源字节 valid 和"处理过 abort"粘滞位。
        "abort_seen": (status >> 6) & 1,
        "src_valid": (status >> 7) & 1,
        "bridge": BRIDGE_STATES.get(bridge, str(bridge)),
        "packetizer_ready": (status >> 11) & 1,
        "vs_seen": (status >> 12) & 1,
        "de_seen": (status >> 13) & 1,
        "fifo_write_seen": (status >> 14) & 1,
        "packet_start_seen": (status >> 15) & 1,
        "frame_sequence": (status >> 16) & 0xFFFF,
        "abort_count": (counts >> 4) & 0xF,
        "done_count": counts & 0xF,
        "phy_link": datagram[11] & 1,
        "ui": datagram[11] >> 1,
        "udp_busy": datagram[12] & 1,
    }


def describe_status(datagram: bytes) -> str | None:
    fields = decode_status(datagram)
    if fields is None:
        return None
    return " ".join(f"{key}={value}" for key, value in fields.items())
