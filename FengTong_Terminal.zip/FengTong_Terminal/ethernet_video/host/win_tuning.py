"""Keep Windows from throttling the receiver when its window loses focus.

The 2026-09-23 v2 run collapsed from 60 to ~17 fps with receive, convert and
window refresh all slowing by the same 2.2-2.5x -- the whole process got less
CPU, not one stage got slower (ETHERNET_V1.md §15.2).  The user had switched
away from and minimised the window several times.  On Windows 11 a process
whose window is not in the foreground is a candidate for EcoQoS (lower clocks,
efficiency cores) and for having its timer resolution requests ignored, which
matches that signature.  This module opts the process out of both and raises
its priority.  Every call is best effort: on other platforms, or on Windows
builds that do not know a flag, it reports what it could not do and returns.
"""
from __future__ import annotations

import sys

# processthreadsapi.h
_PROCESS_POWER_THROTTLING = 4             # PROCESS_INFORMATION_CLASS
_THROTTLING_VERSION = 1
_THROTTLE_EXECUTION_SPEED = 0x1           # EcoQoS, Windows 10 1709+
_THROTTLE_IGNORE_TIMER_RESOLUTION = 0x4   # Windows 11+
_HIGH_PRIORITY_CLASS = 0x80
_THREAD_PRIORITY_HIGHEST = 2


def _kernel32():
    import ctypes
    return ctypes.WinDLL("kernel32", use_last_error=True)


def _set_power_throttling(kernel32, mask: int) -> bool:
    import ctypes

    class State(ctypes.Structure):
        _fields_ = [("Version", ctypes.c_ulong),
                    ("ControlMask", ctypes.c_ulong),
                    ("StateMask", ctypes.c_ulong)]

    # ControlMask = the policies we take control of, StateMask = 0 -> "off".
    state = State(_THROTTLING_VERSION, mask, 0)
    kernel32.GetCurrentProcess.restype = ctypes.c_void_p
    kernel32.SetProcessInformation.argtypes = [
        ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p, ctypes.c_ulong]
    return bool(kernel32.SetProcessInformation(
        kernel32.GetCurrentProcess(), _PROCESS_POWER_THROTTLING,
        ctypes.byref(state), ctypes.sizeof(state)))


def tune_process() -> list[str]:
    """Apply process-wide settings; returns one human-readable line per item."""
    if sys.platform != "win32":
        return ["非 Windows，跳过节能限流/优先级设置"]
    import ctypes
    report = []
    kernel32 = _kernel32()

    both = _THROTTLE_EXECUTION_SPEED | _THROTTLE_IGNORE_TIMER_RESOLUTION
    if _set_power_throttling(kernel32, both):
        report.append("EcoQoS：已关闭（含后台计时器降精度）")
    elif _set_power_throttling(kernel32, _THROTTLE_EXECUTION_SPEED):
        # Windows 10 rejects the timer flag as a whole-call error.
        report.append("EcoQoS：已关闭（本系统不支持计时器精度项）")
    else:
        report.append(f"EcoQoS：关闭失败，错误码 {ctypes.get_last_error()}")

    kernel32.SetPriorityClass.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
    if kernel32.SetPriorityClass(kernel32.GetCurrentProcess(), _HIGH_PRIORITY_CLASS):
        report.append("进程优先级：HIGH")
    else:
        report.append(f"进程优先级：设置失败，错误码 {ctypes.get_last_error()}")

    # 1 ms scheduler tick so waitKey(1) / Condition.wait wake up on time
    # instead of on the default 15.6 ms tick.  Undone by end_tuning().
    try:
        if ctypes.WinDLL("winmm").timeBeginPeriod(1) == 0:
            report.append("系统计时器精度：1 ms")
    except OSError:
        pass
    return report


def end_tuning() -> None:
    if sys.platform != "win32":
        return
    import ctypes
    try:
        ctypes.WinDLL("winmm").timeEndPeriod(1)
    except OSError:
        pass


def raise_current_thread() -> bool:
    """Call from inside the receive thread."""
    if sys.platform != "win32":
        return False
    import ctypes
    kernel32 = _kernel32()
    kernel32.GetCurrentThread.restype = ctypes.c_void_p
    kernel32.SetThreadPriority.argtypes = [ctypes.c_void_p, ctypes.c_int]
    return bool(kernel32.SetThreadPriority(kernel32.GetCurrentThread(),
                                           _THREAD_PRIORITY_HIGHEST))
