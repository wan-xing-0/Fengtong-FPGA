import json
import socket
import tempfile
import time
import unittest
from pathlib import Path

from evs_receiver import (FrameReassembler, LatestFrame, PacketHeader,
                          PIXEL_RGB565, ReceiveThread, TYPE_PREVIEW,
                          make_datagram, parse_datagram)
from evs_status import decode_status, describe_status, is_status
from snapshots import IntervalPolicy, Snapshot, SnapshotWriter, snapshot_name


def make_status(status: int, counts: int = 0, phy_link: int = 1, udp_busy: int = 0) -> bytes:
    """按 eth_a_video_endpoint.v 的 diag_byte 构造 EVDBG1 报文。"""
    return (b"EVDBG1" + status.to_bytes(4, "big")
            + bytes([counts, phy_link, udp_busy, 0x0D, 0x0A, 0x01]))


class ReceiverTest(unittest.TestCase):
    def header(self, index, count, sequence=7):
        return PacketHeader(TYPE_PREVIEW, 0x12345678, sequence, index, count,
                            2, 1, PIXEL_RGB565, 0, 0, 0)

    def test_reassemble_out_of_order(self):
        receiver = FrameReassembler()
        p0 = make_datagram(self.header(0, 2), b"\xf8\x00")
        p1 = make_datagram(self.header(1, 2), b"\x07\xe0")
        self.assertIsNone(receiver.accept(p1, now=1.0))
        result = receiver.accept(p0, now=1.01)
        self.assertIsNotNone(result)
        self.assertEqual(result[1], b"\xf8\x00\x07\xe0")

    def test_bad_crc_is_rejected(self):
        packet = bytearray(make_datagram(self.header(0, 1), b"\x00\x1f\xff\xff"))
        packet[-1] ^= 1
        self.assertIsNone(parse_datagram(packet))

    def test_new_preview_discards_old_partial(self):
        receiver = FrameReassembler()
        self.assertIsNone(receiver.accept(make_datagram(self.header(0, 2, 8), b"\x00\x00"), now=1.0))
        self.assertIsNone(receiver.accept(make_datagram(self.header(0, 2, 9), b"\x00\x00"), now=1.1))
        self.assertEqual(receiver.stats.frames_dropped, 1)

    def test_partial_frame_still_expires_with_the_same_key_fast_path(self):
        """accept() skips its O(n) sweeps for same-frame packets; expiry must
        still happen.  A frame left incomplete has to be counted as dropped
        once a later frame arrives, otherwise the fast path would leak."""
        receiver = FrameReassembler()
        # Two packets of frame 8 -- the second takes the fast path.
        self.assertIsNone(receiver.accept(make_datagram(self.header(0, 3, 8), b"\x00\x00"), now=1.0))
        self.assertIsNone(receiver.accept(make_datagram(self.header(1, 3, 8), b"\x00\x00"), now=1.001))
        self.assertEqual(receiver.stats.frames_dropped, 0)
        # Frame 8 never completes.  Frame 9 arriving must retire it.
        self.assertIsNone(receiver.accept(make_datagram(self.header(0, 3, 9), b"\x00\x00"), now=1.5))
        self.assertEqual(receiver.stats.frames_dropped, 1)

    def test_completed_frame_clears_the_fast_path_key(self):
        """A completed frame must not leave a stale key behind: the next
        frame's first packet has to run the sweeps again."""
        receiver = FrameReassembler()
        self.assertIsNone(receiver.accept(make_datagram(self.header(0, 2, 8), b"\x00\x00"), now=1.0))
        self.assertIsNotNone(receiver.accept(make_datagram(self.header(1, 2, 8), b"\x00\x00"), now=1.001))
        self.assertIsNone(receiver.last_key)
        self.assertEqual(receiver.stats.frames_complete, 1)


class ColourConversionTest(unittest.TestCase):
    def test_rgb565_matches_reference(self):
        """The fast path must agree with the v1.0 reference on every one of
        the 65536 RGB565 words.  This caught cv2.COLOR_BGR5652BGR being up to
        7 LSB off (plain shift, 5-bit max 248); keep it for any future swap."""
        try:
            import numpy as np
            from evs_receiver import rgb565_to_bgr, rgb565_to_bgr_reference
        except ImportError as exc:
            self.skipTest(f"需要 numpy/opencv：{exc}")
        words = np.arange(65536, dtype=">u2")
        data = words.tobytes()
        fast = rgb565_to_bgr(data, 256, 256)
        slow = rgb565_to_bgr_reference(data, 256, 256)
        self.assertEqual(fast.shape, slow.shape)
        diff = np.abs(fast.astype(int) - slow.astype(int))
        self.assertEqual(diff.max(), 0, "OpenCV 与参考实现不一致，最大偏差 "
                                        f"{diff.max()}")


class StatusDatagramTest(unittest.TestCase):
    """EVDBG1 与视频共用 6001 端口，必须被识别而不是计成坏包。"""

    def test_status_is_not_counted_as_a_bad_video_packet(self):
        receiver = FrameReassembler()
        self.assertIsNone(receiver.accept(make_status(0x0004_0800), now=1.0))
        self.assertEqual(receiver.stats.status_packets, 1)
        self.assertEqual(receiver.stats.packets_bad, 0)
        self.assertEqual(receiver.stats.packets_ok, 0)
        self.assertIsNotNone(receiver.last_status)

    def test_status_does_not_disturb_frame_reassembly(self):
        receiver = FrameReassembler()
        p0 = make_datagram(self.header_pair(0), b"\xf8\x00")
        p1 = make_datagram(self.header_pair(1), b"\x07\xe0")
        self.assertIsNone(receiver.accept(p0, now=1.0))
        self.assertIsNone(receiver.accept(make_status(0), now=1.001))
        result = receiver.accept(p1, now=1.002)
        self.assertIsNotNone(result)
        self.assertEqual(receiver.stats.frames_complete, 1)
        self.assertEqual(receiver.stats.packets_bad, 0)

    def header_pair(self, index):
        return PacketHeader(TYPE_PREVIEW, 0x12345678, 11, index, 2,
                            2, 1, PIXEL_RGB565, 0, 0, 0)

    def test_real_video_packet_is_not_mistaken_for_status(self):
        packet = make_datagram(self.header_pair(0), b"\xf8\x00")
        self.assertFalse(is_status(packet))

    def test_decode_matches_the_rtl_bit_layout(self):
        # frame_sequence=0x1234、packet_start_seen..vs_seen 全 1、
        # packetizer_ready=1、bridge=STREAM(3)、fifo_empty=1、can_video/can_eth=1
        status = (0x1234 << 16) | (0xF << 12) | (1 << 11) | (3 << 8) | (1 << 2) | 0x3
        fields = decode_status(make_status(status, counts=0x25))
        self.assertEqual(fields["frame_sequence"], 0x1234)
        self.assertEqual(fields["bridge"], "STREAM")
        self.assertEqual(fields["packetizer_ready"], 1)
        self.assertEqual(fields["vs_seen"], 1)
        self.assertEqual(fields["packet_start_seen"], 1)
        self.assertEqual(fields["fifo_empty"], 1)
        self.assertEqual(fields["can_eth"], 1)
        self.assertEqual(fields["can_video"], 1)
        self.assertEqual(fields["abort_count"], 2)
        self.assertEqual(fields["done_count"], 5)

    def test_wrong_length_or_magic_is_not_status(self):
        self.assertFalse(is_status(b"EVDBG1"))
        self.assertFalse(is_status(b"EVS1" + bytes(12)))
        self.assertIsNone(describe_status(b"EVDBG1" + bytes(9)))


class LatestFrameTest(unittest.TestCase):
    """收包线程和显示线程之间只留最新一帧：显示慢只能跳帧，不能拖住收包。"""

    def test_unread_frame_is_overwritten_and_counted(self):
        slot = LatestFrame()
        slot.put("a")
        slot.put("b")
        slot.put("c")
        self.assertEqual(slot.get(0.0), "c")
        self.assertEqual(slot.skipped, 2)

    def test_read_frame_is_not_counted_as_skipped(self):
        slot = LatestFrame()
        slot.put("a")
        self.assertEqual(slot.get(0.0), "a")
        slot.put("b")
        self.assertEqual(slot.get(0.0), "b")
        self.assertEqual(slot.skipped, 0)

    def test_empty_slot_times_out_with_none(self):
        slot = LatestFrame()
        start = time.monotonic()
        self.assertIsNone(slot.get(0.05))
        self.assertLess(time.monotonic() - start, 1.0)


class ReceiveThreadTest(unittest.TestCase):
    def test_frame_over_loopback_reaches_the_slot_and_thread_stops(self):
        rx = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        rx.bind(("127.0.0.1", 0))
        rx.settimeout(0.05)
        tx = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        slot = LatestFrame()
        thread = ReceiveThread(rx, FrameReassembler(), slot)
        thread.start()
        try:
            header = lambda i: PacketHeader(TYPE_PREVIEW, 1, 5, i, 2, 2, 1,
                                            PIXEL_RGB565, 0, 0, 0)
            tx.sendto(make_datagram(header(0), b"\xf8\x00"), rx.getsockname())
            tx.sendto(make_datagram(header(1), b"\x07\xe0"), rx.getsockname())
            item = slot.get(2.0)
            self.assertIsNotNone(item, "收包线程没有交出完整帧")
            got_header, image, wall = item
            self.assertEqual(got_header.sequence, 5)
            self.assertEqual(image, b"\xf8\x00\x07\xe0")
            self.assertGreater(wall, 0)
        finally:
            thread.stop_event.set()
            thread.join(2.0)
            tx.close()
            rx.close()
        self.assertFalse(thread.is_alive(), "stop_event 后线程没有退出")
        self.assertIsNone(thread.error)


class IntervalPolicyTest(unittest.TestCase):
    def test_one_capture_per_interval(self):
        policy = IntervalPolicy(1.0)
        # 60 fps 跑 3 秒：应恰好存 3 张（t=0, 1, 2）。
        hits = [i for i in range(180) if policy.should_capture(i / 60)]
        self.assertEqual(hits, [0, 60, 120])

    def test_stall_does_not_cause_a_burst(self):
        policy = IntervalPolicy(1.0)
        self.assertTrue(policy.should_capture(0.0))
        # 接收端卡了 5 秒，恢复后只补一张，下一张在 1 秒后。
        self.assertTrue(policy.should_capture(5.2))
        self.assertFalse(policy.should_capture(5.3))
        self.assertFalse(policy.should_capture(6.1))
        self.assertTrue(policy.should_capture(6.25))


class SnapshotWriterTest(unittest.TestCase):
    class FakeImage:
        shape = (540, 960, 3)

    def test_writes_jpeg_and_index_line(self):
        with tempfile.TemporaryDirectory() as tmp:
            writer = SnapshotWriter(Path(tmp), encoder=lambda img, q: b"JPEGDATA")
            wall = time.time()
            self.assertTrue(writer.submit(Snapshot(self.FakeImage(), wall, 42, 0xABCD, "timer")))
            writer.close()
            day, name = snapshot_name(wall, 42)
            path = Path(tmp) / day / name
            self.assertEqual(path.read_bytes(), b"JPEGDATA")
            self.assertEqual(list(path.parent.glob("*.part")), [])
            record = json.loads((path.parent / "index.jsonl").read_text(encoding="utf-8"))
            self.assertEqual(record["file"], name)
            self.assertEqual(record["sequence"], 42)
            self.assertEqual(record["trigger"], "timer")
            self.assertEqual((record["width"], record["height"]), (960, 540))
            self.assertEqual(writer.saved, 1)

    def test_full_queue_drops_instead_of_blocking(self):
        import threading
        gate = threading.Event()

        def slow_encoder(img, q):
            gate.wait(5.0)
            return b"x"

        with tempfile.TemporaryDirectory() as tmp:
            writer = SnapshotWriter(Path(tmp), encoder=slow_encoder)
            start = time.monotonic()
            results = [writer.submit(Snapshot(self.FakeImage(), time.time(), i, 1, "timer"))
                       for i in range(20)]
            self.assertLess(time.monotonic() - start, 0.5, "submit 被阻塞了")
            self.assertIn(False, results)
            self.assertEqual(writer.dropped, results.count(False))
            gate.set()
            writer.close()
            self.assertEqual(writer.saved, results.count(True))

    def test_encoder_error_is_counted_and_writer_keeps_going(self):
        calls = []

        def flaky(img, q):
            calls.append(1)
            if len(calls) == 1:
                raise OSError("disk full")
            return b"ok"

        with tempfile.TemporaryDirectory() as tmp:
            writer = SnapshotWriter(Path(tmp), encoder=flaky)
            writer.submit(Snapshot(self.FakeImage(), time.time(), 1, 1, "timer"))
            writer.submit(Snapshot(self.FakeImage(), time.time() + 1, 2, 1, "timer"))
            writer.close()
            self.assertEqual((writer.failed, writer.saved), (1, 1))
            self.assertIn("disk full", writer.last_error)


if __name__ == "__main__":
    unittest.main()
