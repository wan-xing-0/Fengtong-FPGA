"""PC -> FPGA mode commands (EVCMD, 2026-10-29) and the receiver's control bar.

The board listens on 192.168.137.2:6002 (eth_a_video_endpoint LOCAL_IP /
LOCAL_PORT) for 8-byte UDP datagrams, decoded by evs_cmd_rx.v::

    0..4  b"EVCMD"
    5     command   1 application mode   arg 0 原图 / 1 安防 / 2 质检 / 3 人脸
                    2 key2 short press   arg 0
                    3 standard part      arg 0 任意 / 1 标准件 / 2 三棱柱 (10-31)
    6     argument
    7     XOR of bytes 0..6

The board answers in every EVDBG1 status packet (byte 11, evs_status.BoardState)
and sends one early, ~100 us after a command, so the bar shows the new mode at
once.  Nothing is acknowledged otherwise: a command lost on the wire simply
does not happen, and the bar keeps showing what the board reports.

The control bar is drawn into the live window under the picture (OpenCV has
no widgets) and driven by the mouse; the number keys do the same.
"""
from __future__ import annotations

import socket
from dataclasses import dataclass

CMD_MAGIC = b"EVCMD"
CMD_SIZE = 8
CMD_SET_MODE = 1
CMD_KEY2 = 2
CMD_STD_PART = 3
BOARD_ADDR = ("192.168.137.2", 6002)

MODE_RAW, MODE_SECURITY, MODE_QC, MODE_FACE = 0, 1, 2, 3


def make_cmd(cmd: int, arg: int = 0) -> bytes:
    body = CMD_MAGIC + bytes([cmd & 0xFF, arg & 0xFF])
    x = 0
    for b in body:
        x ^= b
    return body + bytes([x])


class Commander:
    """Sends EVCMD datagrams.  A separate socket from the receive one: the
    board's reply goes to 6001 whatever port this sends from."""

    def __init__(self, addr: tuple[str, int] = BOARD_ADDR,
                 bind_ip: str | None = None) -> None:
        self.addr = addr
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        if bind_ip and bind_ip != "0.0.0.0":
            # Leave from the FPGA-side NIC even when Wi-Fi has the default route.
            self.sock.bind((bind_ip, 0))
        self.sent = 0
        self.last_error: str | None = None

    def send(self, cmd: int, arg: int = 0) -> bool:
        try:
            self.sock.sendto(make_cmd(cmd, arg), self.addr)
            self.sent += 1
            return True
        except OSError as exc:
            self.last_error = f"{type(exc).__name__}: {exc}"
            return False

    def set_mode(self, mode: int) -> bool:
        return self.send(CMD_SET_MODE, mode)

    def key2(self) -> bool:
        return self.send(CMD_KEY2)

    def std_part(self, kind) -> bool:
        """0 任意 / 1 标准件 (方块) / 2 三棱柱 (10-31).  True / False = 1 / 0 as before."""
        return self.send(CMD_STD_PART, int(kind))

    def close(self) -> None:
        self.sock.close()


# ---------------------------------------------------------------------------
# control bar
# ---------------------------------------------------------------------------

BAR_H = 64                 # px at a 960-wide frame; scaled with the frame


@dataclass
class Button:
    label: str
    action: tuple          # ("mode", n) | ("key2",) | ("std", 0/1/2)
    x0: int = 0
    x1: int = 0


def _buttons(state) -> list[Button]:
    """The bar for the board's current state (None = not reported yet)."""
    # 10-31: no 人脸 button -- the board dropped the mode (system_top FACE_MODE 0)
    out = [Button("原图", ("mode", MODE_RAW)), Button("安防", ("mode", MODE_SECURITY)),
           Button("质检", ("mode", MODE_QC))]
    mode = state.mode if state is not None else None
    if mode == MODE_SECURITY:
        out.append(Button("切换视图", ("key2",)))
    elif mode == MODE_QC:
        # 11-01 (user): the 三棱柱 part is dropped -- the RTL still has it (no
        # time to resynthesise), the PC just no longer offers it.
        out += [Button("任意", ("std", 0)), Button("标准件", ("std", 1)),
                Button("去皮", ("key2",))]
    elif mode == MODE_FACE:
        out.append(Button("切换档位", ("key2",)))
    return out


class ControlBar:
    """Draws the bar under the frame and maps clicks to commands.

    Not thread-safe; the display thread owns it (draw + the mouse callback
    both run inside cv2.waitKey on that thread).
    """

    def __init__(self, commander: Commander, font_path: str | None = None,
                 bold_path: str | None = None) -> None:
        self.commander = commander
        self.font_path = font_path
        self.bold_path = bold_path
        self.state = None              # evs_status.BoardState, once known
        self.buttons: list[Button] = []
        self.scale = 1.0
        self.frame_h = 0
        self.hover: int | None = None
        self.flash: str | None = None  # label of the button just pressed
        self._cache_key = None
        self._cache = None

    # -- state ---------------------------------------------------------------
    def update_state(self, state) -> None:
        if state is not None and state.raw == 0 and self.state is None:
            # An old bit reports 0 forever; do not claim "原图 / 任意" from it.
            return
        self.state = state

    # -- input ---------------------------------------------------------------
    def act(self, action: tuple) -> None:
        if action[0] == "mode":
            self.commander.set_mode(action[1])
        elif action[0] == "key2":
            self.commander.key2()
        elif action[0] == "std":
            self.commander.std_part(action[1])

    def on_key(self, key: int) -> bool:
        """1..3 = 原图 / 安防 / 质检, 5 = key2.  True if consumed.  (10-31: 4 人脸 gone.)"""
        if ord("1") <= key <= ord("3"):
            self.act(("mode", key - ord("1")))
            self.flash = ("原图", "安防", "质检")[key - ord("1")]
            return True
        if key == ord("5"):
            self.act(("key2",))
            return True
        return False

    def on_mouse(self, event: int, x: int, y: int) -> None:
        """x / y as OpenCV reports them: image pixels -- for a WINDOW_NORMAL
        window the Win32 backend maps the window's scaling back itself."""
        import cv2
        inside = y >= self.frame_h
        idx = None
        if inside:
            for i, b in enumerate(self.buttons):
                if b.x0 <= x < b.x1:
                    idx = i
                    break
        self.hover = idx
        if event == cv2.EVENT_LBUTTONUP and idx is not None:
            b = self.buttons[idx]
            self.flash = b.label
            self.act(b.action)

    # -- drawing -------------------------------------------------------------
    def _active(self, b: Button) -> bool:
        s = self.state
        if s is None:
            return False
        if b.action[0] == "mode":
            return s.mode == b.action[1]
        if b.action[0] == "std":
            return s.std_kind == b.action[1]
        return False

    def compose(self, bgr):
        """The frame with the bar appended below it (a new array)."""
        import numpy as np
        h, w = bgr.shape[:2]
        self.frame_h = h
        self.scale = w / 960
        bar = self._bar(w)
        return np.vstack((bgr, bar))

    def _bar(self, width: int):
        """2026-10-29 look (user: the first bar was ugly): a dark strip, the
        four modes as one segmented control, the current mode's own buttons
        as outlined pills, the board's state on the right with a dot."""
        import numpy as np
        buttons = _buttons(self.state)
        key = (width, self.state, self.hover, self.flash, tuple(b.label for b in buttons),
               self.commander.last_error)
        if key == self._cache_key and self._cache is not None:
            # Keep self.buttons: they carry the x0 / x1 the cached image was
            # drawn with.  (Replacing them with the fresh, unplaced list made
            # every click after the first frame miss.)
            return self._cache
        self.buttons = buttons
        from PIL import Image, ImageDraw
        s = self.scale
        px = lambda v: round(v * s)
        h = px(BAR_H)
        img = Image.new("RGB", (width, h), BG)
        draw = ImageDraw.Draw(img)
        draw.line([(0, 0), (width, 0)], fill=EDGE, width=max(1, px(1)))
        f_mode = self._font(self.bold_path or self.font_path, px(17))
        f_act = self._font(self.font_path, px(16))
        f_st = self._font(self.font_path, px(15))

        def centred(text, font, x0, x1, ink):
            bb = draw.textbbox((0, 0), text, font=font)
            draw.text(((x0 + x1 - (bb[2] - bb[0])) / 2 - bb[0],
                       (h - (bb[3] - bb[1])) / 2 - bb[1]), text, font=font, fill=ink)

        y0, y1 = px(11), h - px(11)
        x = px(14)
        modes = [b for b in self.buttons if b.action[0] == "mode"]
        acts = [b for b in self.buttons if b.action[0] != "mode"]
        # segmented control
        seg_w = [int(draw.textlength(b.label, font=f_mode)) + px(30) for b in modes]
        inset = px(3)
        draw.rounded_rectangle([(x, y0), (x + sum(seg_w) + 2 * inset, y1)], radius=px(9), fill=SEG)
        sx = x + inset
        for b, w in zip(modes, seg_w):
            b.x0, b.x1 = sx, sx + w
            i = self.buttons.index(b)
            if self._active(b):
                draw.rounded_rectangle([(sx, y0 + inset), (sx + w, y1 - inset)], radius=px(7), fill=ON)
                ink = ON_INK
            elif i == self.hover:
                draw.rounded_rectangle([(sx, y0 + inset), (sx + w, y1 - inset)], radius=px(7), fill=HOVER)
                ink = INK
            else:
                ink = MUTED
            centred(b.label, f_mode, sx, sx + w, ink)
            sx += w
        x = sx + inset + px(18)
        # this mode's own buttons
        for b in acts:
            w = int(draw.textlength(b.label, font=f_act)) + px(26)
            b.x0, b.x1 = x, x + w
            i = self.buttons.index(b)
            if self._active(b):
                draw.rounded_rectangle([(x, y0), (x + w, y1)], radius=px(9), fill=ACCENT)
                ink = (255, 255, 255)
            else:
                draw.rounded_rectangle([(x, y0), (x + w, y1)], radius=px(9),
                                       fill=HOVER if i == self.hover else None,
                                       outline=LINE, width=max(1, px(1)))
                ink = INK
            centred(b.label, f_act, x, x + w, ink)
            x += w + px(8)
        # right: what the board reports
        st = self.state
        if self.commander.last_error:
            text, dot = "发送失败：" + self.commander.last_error, BAD
        elif st is None:
            text, dot = "等待板子状态（旧 bit 不支持界面切换）", WARN
        else:
            view = st.view_text
            text, dot = st.mode_name + (f" · {view}" if view else ""), GOOD
        right = width - px(16)
        tw = draw.textlength(text, font=f_st)
        bb = draw.textbbox((0, 0), text, font=f_st)
        draw.text((right - tw, (h - (bb[3] - bb[1])) / 2 - bb[1]), text, font=f_st, fill=INK)
        r = px(4)
        cx, cy = right - tw - px(12), h // 2
        draw.ellipse([(cx - r, cy - r), (cx + r, cy + r)], fill=dot)
        if st is not None and st.staff_pass:
            label = "员工已核验"
            lw = int(draw.textlength(label, font=f_st)) + px(20)
            x1 = cx - px(14)
            draw.rounded_rectangle([(x1 - lw, y0 + px(3)), (x1, y1 - px(3))], radius=px(12), fill=STAFF)
            centred(label, f_st, x1 - lw, x1, (255, 255, 255))
        self._cache = np.asarray(img)[:, :, ::-1].copy()
        self._cache_key = key
        return self._cache

    @staticmethod
    def _font(path, size):
        from PIL import ImageFont
        try:
            return ImageFont.truetype(path, size) if path else ImageFont.load_default()
        except OSError:
            return ImageFont.load_default()


# Control bar colours (RGB; the bar is drawn with Pillow, converted at the end)
BG = (17, 19, 24)
EDGE = (36, 40, 49)
SEG = (31, 34, 42)
ON = (238, 240, 244)
ON_INK = (17, 19, 24)
HOVER = (46, 50, 60)
INK = (226, 230, 236)
MUTED = (138, 146, 160)
LINE = (62, 68, 80)
ACCENT = (64, 112, 244)
STAFF = (16, 157, 107)
GOOD = (34, 197, 94)
WARN = (245, 166, 35)
BAD = (239, 68, 68)
