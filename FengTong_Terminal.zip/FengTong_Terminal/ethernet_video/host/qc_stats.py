"""质检统计（2026-10-31）：工件记录 index.jsonl -> 看板数据 / CSV。

纯函数，snapshot_server.py 的 /api/qcstats、/api/qccsv 调用它；输入是
QcWriter 写的 index 行（dict），所以旧记录（没有 std_kind / fpga_count）也能算：

  * 标准件类型：std_kind（"cube" / "tri"，10-31 起）；没有它但 mode=standard 的
    是 10-29 的方块；mode=any 或没有 mode 的是「任意」。
  * 判定：verdict pass / fail；其余（none / measuring / disabled）不进合格率。
  * 不合格原因：failed 里的 长 / 宽 / 厚 归成「尺寸」，颜色 / 形状 / 污渍 原样，
    「见屏幕判定」等归成「其他」。一件可以同时有几个原因。
  * 偏差趋势：只有标准件记录才有（deviation_mm）；公差带按该件的 std。
  * FPGA 计数：最后一条带 fpga_count 的记录（板上本批已检 / 合格）。
"""
from __future__ import annotations

import csv
import io
import math

PARTS = ("all", "any", "cube", "tri")
PART_NAMES = {"any": "任意", "cube": "方块标准件", "tri": "三棱柱标准件"}
REASONS = ("颜色", "形状", "尺寸", "污渍", "其他")
SIZE_AXES = {"长", "宽", "厚"}


def part_of(rec: dict) -> str:
    k = rec.get("std_kind")
    if k in ("cube", "tri"):
        return k
    if rec.get("mode") == "standard":
        return "cube"                    # a 10-29..10-30 record: the only part was the cube
    return "any"


def reasons_of(rec: dict) -> list[str]:
    """The record's failure reasons, in REASONS order, each once."""
    got = set()
    for f in rec.get("failed") or ():
        if f in SIZE_AXES:
            got.add("尺寸")
        elif f in REASONS:
            got.add(f)
        else:
            got.add("其他")
    return [r for r in REASONS if r in got]


def select(records: list[dict], part: str = "all") -> list[dict]:
    if part not in PARTS:
        raise ValueError("part 只能是 " + " / ".join(PARTS))
    return [r for r in records if part == "all" or part_of(r) == part]


def summary(records: list[dict], part: str = "all", series_max: int = 500) -> dict:
    """The dashboard's numbers for these records (oldest first)."""
    recs = sorted(select(records, part), key=lambda r: r.get("epoch", 0))
    passed = sum(1 for r in recs if r.get("verdict") == "pass")
    failed = sum(1 for r in recs if r.get("verdict") == "fail")
    judged = passed + failed
    reasons = {k: 0 for k in REASONS}
    for r in recs:
        if r.get("verdict") == "fail":
            for k in reasons_of(r):
                reasons[k] += 1
    by_part = {k: 0 for k in PART_NAMES}
    for r in recs:
        by_part[part_of(r)] += 1
    series, tol = [], None
    for i, r in enumerate(recs):
        dev = r.get("deviation_mm")
        if not isinstance(dev, dict):
            continue
        std = r.get("std") or {}
        if tol is None and std:
            tol = {"xy": std.get("tol_xy"), "z": std.get("tol_z")}
        series.append({"n": i + 1, "time": r.get("time", ""), "part": part_of(r),
                       "x": dev.get("x"), "y": dev.get("y"), "z": dev.get("z"),
                       "verdict": r.get("verdict", "none")})
    fpga = None
    for r in reversed(recs):
        if r.get("fpga_count"):
            fpga = {"count": r["fpga_count"], "pass": r.get("fpga_pass", 0),
                    "part": part_of(r), "time": r.get("time", "")}
            break
    return {
        "part": part,
        "total": judged,
        "records_total": len(recs),
        "unjudged": len(recs) - judged,
        "averages": averages(recs),
        "judged": judged,
        "pass": passed,
        "fail": failed,
        "pass_rate": round(passed / judged, 4) if judged else None,
        "reasons": reasons,
        "by_part": by_part,
        "series": series[-series_max:],
        "tol": tol,
        "fpga": fpga,
    }


CSV_FIELDS = ("时间", "编号", "模式", "长mm", "宽mm", "厚mm", "长偏差", "宽偏差", "厚偏差",
              "颜色", "形状", "污渍", "判定", "原因", "FPGA已检", "FPGA合格", "卡片")
VERDICT_NAMES = {"pass": "合格", "fail": "不合格", "measuring": "测量中"}


def averages(records):
    result = {}
    for key in ('x_mm', 'y_mm', 'z_mm', 'dx', 'dy', 'dz'):
        values = [(r.get('deviation_mm') or {}).get(key[1:]) if key.startswith('d') else r.get(key) for r in records]
        values = [v for v in values if isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)]
        result[key] = sum(values) / len(values) if values else None
    return result


def to_csv(records: list[dict], part: str = "all") -> bytes:
    """UTF-8 with a BOM, so Excel opens the Chinese headers correctly."""
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\r\n")
    w.writerow(CSV_FIELDS)
    for r in sorted(select(records, part), key=lambda r: r.get("epoch", 0)):
        dev = r.get("deviation_mm") if isinstance(r.get("deviation_mm"), dict) else {}
        w.writerow([
            (r.get("time") or "").replace("T", " "),
            r.get("qc_seq", ""),
            PART_NAMES[part_of(r)],
            r.get("x_mm", ""), r.get("y_mm", ""), r.get("z_mm", ""),
            dev.get("x", ""), dev.get("y", ""), dev.get("z", ""),
            r.get("colour", ""), r.get("shape", ""), r.get("stain", r.get("surface", "")),
            VERDICT_NAMES.get(r.get("verdict"), ""),
            "、".join(reasons_of(r)) if r.get("verdict") == "fail" else "",
            r.get("fpga_count", ""), r.get("fpga_pass", ""),
            f"{r.get('day', '')}/{r.get('file', '')}",
        ])
    return ("﻿" + buf.getvalue()).encode("utf-8")
