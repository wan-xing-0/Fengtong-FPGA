"""Full-resolution bursts: group four phase-shifted 960x540 frames, stitch 1920x1080.

The FPGA (evs_burst_ctrl.v) normally keeps the (even x, even y) pixels of
every 1920x1080 frame.  For a burst it sends four consecutive frames that keep
the four 2x2 sub-grids in turn; the EVS1 header flags byte (offset 25) says
which::

    bit 0     staff record (2026-10-29): the one burst taken on a staff pass,
              with source 1; 0 everywhere else (was "motion alarm, reserved")
    bit 1     member of a full-resolution burst
    bits 3:2  phase: bit 2 = x odd, bit 3 = y odd
    bits 5:4  source: 0 QC (qc_trig)
                      1 security, nobody there ("normal"), or the staff
                        record when bit 0 is set
                      2 security alarm level 2 (a face was seen)
                      3 security alarm level 3 (motion >= 2 s, no face)
    bits 7:6  burst id, +1 per burst

Non-member frames have flags 0.  Phase p of a burst has frame sequence
base + p, where base is the phase-0 frame's sequence -- the FPGA only advances
the phase on a frame it really started, and the bridge numbers exactly those.
So (session, base, id, src) names one burst even if its phase-0 frame was lost.

A burst missing a phase after BURST_TIMEOUT_S is emitted anyway: the missing
sub-grid is filled from the nearest phase that did arrive (a one-pixel
nearest-neighbour shift), and the result says "partial" and which phases.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Callable

FLAG_STAFF = 0x01
FLAG_MEMBER = 0x02
SRC_QC = 0
SRC_NORMAL = 1
SRC_ALARM_FACE = 2
SRC_ALARM_MOTION = 3
SRC_TIMER = SRC_NORMAL          # the 10-09 morning name, kept for the tests
# Not a wire value: the source a staff-record burst (source 1, bit 0) is
# filed under.  > 3 so it can never collide with one.
SRC_STAFF = 4
# The index's "trigger" value for each source; snapshot_server filters on it.
SRC_NAMES = {SRC_QC: "qc", SRC_NORMAL: "normal", SRC_ALARM_FACE: "alarm_face",
             SRC_ALARM_MOTION: "alarm_motion", SRC_STAFF: "staff"}
ALARM_SOURCES = (SRC_ALARM_FACE, SRC_ALARM_MOTION)
BURST_TIMEOUT_S = 0.5
MAX_OPEN = 4


@dataclass(frozen=True)
class BurstFlags:
    member: bool
    phase: int        # 0..3
    src: int          # 0..3 as on the wire, or SRC_STAFF
    burst_id: int

    @property
    def x_odd(self) -> int:
        return self.phase & 1

    @property
    def y_odd(self) -> int:
        return self.phase >> 1


def parse_flags(flags: int) -> BurstFlags:
    src = (flags >> 4) & 3
    if src == SRC_NORMAL and flags & FLAG_STAFF:
        src = SRC_STAFF
    return BurstFlags(bool(flags & FLAG_MEMBER), (flags >> 2) & 3, src, (flags >> 6) & 3)


def make_flags(phase: int, src: int, burst_id: int) -> int:
    """Reference encoding, the same bits evs_burst_ctrl.v drives."""
    staff = src == SRC_STAFF
    wire_src = SRC_NORMAL if staff else src
    return (((burst_id & 3) << 6) | ((wire_src & 3) << 4) | ((phase & 3) << 2) | FLAG_MEMBER
            | (FLAG_STAFF if staff else 0))


@dataclass
class Burst:
    session: int
    base_seq: int
    burst_id: int
    src: int
    width: int                # of one phase frame (960)
    height: int
    first_seen: float
    wall_time: float          # time.time() of the first frame that arrived
    frames: dict[int, bytes] = field(default_factory=dict)   # phase -> RGB565

    @property
    def complete(self) -> bool:
        return len(self.frames) == 4

    @property
    def missing(self) -> list[int]:
        return [p for p in range(4) if p not in self.frames]

    @property
    def src_name(self) -> str:
        return SRC_NAMES.get(self.src, str(self.src))


class BurstAssembler:
    """Receive-thread side.  Not thread-safe; owned by the receive thread."""

    def __init__(self, timeout_s: float = BURST_TIMEOUT_S) -> None:
        self.timeout_s = timeout_s
        self.open: dict[tuple[int, int, int, int], Burst] = {}
        self.complete = 0
        self.partial = 0

    def on_frame(self, header, data: bytes, wall_time: float,
                 now: float | None = None) -> list[Burst]:
        """Feed every complete frame; returns bursts that just completed."""
        f = parse_flags(header.flags)
        if not f.member:
            return []
        now = time.monotonic() if now is None else now
        base = (header.sequence - f.phase) & 0xFFFFFFFF
        key = (header.session_id, base, f.burst_id, f.src)
        burst = self.open.get(key)
        if burst is None:
            burst = self.open[key] = Burst(header.session_id, base, f.burst_id, f.src,
                                           header.width, header.height, now, wall_time)
        burst.frames.setdefault(f.phase, data)
        done: list[Burst] = []
        if burst.complete:
            del self.open[key]
            self.complete += 1
            done.append(burst)
        # A burst that can no longer complete (a later one is already
        # arriving) does not have to wait for its timeout.
        while len(self.open) > MAX_OPEN:
            oldest = min(self.open, key=lambda k: self.open[k].first_seen)
            done.append(self._partial(self.open.pop(oldest)))
        return done

    def sweep(self, now: float | None = None) -> list[Burst]:
        if not self.open:
            return []
        now = time.monotonic() if now is None else now
        old = [k for k, b in self.open.items() if now - b.first_seen > self.timeout_s]
        return [self._partial(self.open.pop(k)) for k in old]

    def _partial(self, burst: Burst) -> Burst:
        self.partial += 1
        return burst


def stitch(burst: Burst, to_bgr: Callable):
    """(1080x1920 BGR ndarray, "full" | "partial", missing phases)."""
    import numpy as np
    w, h = burst.width, burst.height
    phases = {p: to_bgr(data, w, h) for p, data in burst.frames.items()}
    full = np.empty((2 * h, 2 * w, 3), dtype=np.uint8)
    for p in range(4):
        src = phases.get(p)
        if src is None:
            # Nearest sub-grid that did arrive: same row parity first (a
            # one-column shift), then same column parity, then the diagonal.
            for q in (p ^ 1, p ^ 2, p ^ 3):
                if q in phases:
                    src = phases[q]
                    break
        full[p >> 1::2, p & 1::2] = src
    missing = burst.missing
    return full, ("full" if not missing else "partial"), missing


class StitchedImage:
    """A deferred stitch, so the writer thread pays for it, not the caller."""

    def __init__(self, burst: Burst, to_bgr: Callable) -> None:
        self.burst = burst
        self.to_bgr = to_bgr
        self.resolution = "full" if burst.complete else "partial"
        self.missing = burst.missing

    def __call__(self):
        image, self.resolution, self.missing = stitch(self.burst, self.to_bgr)
        return image


class PhaseZeroImage:
    """2026-10-29 (user): security pictures are NOT stitched -- a person who
    moves during the four frames comes out as a ghost.  The burst's phase-0
    frame is an ordinary 960x540 preview frame (even x, even y), so it is the
    picture, at the live view's resolution.  Deferred like StitchedImage."""

    resolution = "half"
    missing: list = []

    def __init__(self, burst: Burst, to_bgr: Callable) -> None:
        self.burst = burst
        self.to_bgr = to_bgr

    def __call__(self):
        frames = self.burst.frames
        data = frames.get(0) or next(iter(frames.values()))
        return self.to_bgr(data, self.burst.width, self.burst.height)
