import json
import os
import socket
import tempfile
import time
import unittest
from pathlib import Path

from evs_receiver import (FrameReassembler, LatestFrame, PacketHeader, PIXEL_RGB565,
                          ReceiveThread, TYPE_PREVIEW, make_datagram)
from qc_record import (QcRecord, QcTracker, QcWriter, extend_seq16, is_qc,
                       make_qc_datagram, parse_qc, qc_names)
from qc_rules import Rules, RulesFile, Verdict, judge, parse_rules


def rec_bytes(seq, x=26, y=49, z=28, top=250, base=278, w=300, h=200, valid=1):
    """Pack exactly as qc_thick.v lays out qc_rec[127:0]."""
    r = (valid << 127) | (valid << 126) | (x << 104) | (y << 88) | (z << 72) \
        | (top << 56) | (base << 40) | (w << 28) | (h << 16) | (seq << 8)
    return r.to_bytes(16, "big")


class QcPacketTest(unittest.TestCase):
    def test_layout_matches_rtl(self):
        """Byte offsets of evs_aux_tx.v's qc_byte(), checked one by one."""
        raw = rec_bytes(12)
        d = make_qc_datagram(raw, 0xBEEF, repeat=1)
        self.assertEqual(len(d), 32)
        self.assertEqual(d[:5], b"EVQC1")
        self.assertEqual(d[5], 1)                 # version
        self.assertEqual(d[6], 1)                 # repeat index
        self.assertEqual(d[7], 3)                 # repeat total
        self.assertEqual(d[8:10], b"\xbe\xef")    # frame_sequence[15:0]
        self.assertEqual(d[10:12], b"\0\0")
        self.assertEqual(d[12:28], raw)
        self.assertEqual(d[28:31], b"\0\0\0")
        x = 0
        for b in d[:31]:
            x ^= b
        self.assertEqual(d[31], x)

    def test_decode_fields(self):
        pkt = parse_qc(make_qc_datagram(rec_bytes(7, x=21, y=42, z=13, top=249,
                                                  base=280, w=301, h=201), 5))
        r = pkt.record
        self.assertTrue(r.valid and r.base_ok)
        self.assertEqual((r.x_mm, r.y_mm, r.z_mm, r.top_mm, r.base_mm), (21, 42, 13, 249, 280))
        self.assertEqual((r.box_w_px, r.box_h_px, r.seq), (301, 201, 7))
        self.assertEqual(pkt.frame_seq16, 5)

    def test_bad_xor_and_version_rejected(self):
        d = bytearray(make_qc_datagram(rec_bytes(1), 0))
        d[20] ^= 0x40
        self.assertIsNone(parse_qc(bytes(d)))
        d = bytearray(make_qc_datagram(rec_bytes(1), 0))
        d[5] = 2
        d[31] ^= 2 ^ 1
        self.assertIsNone(parse_qc(bytes(d)))

    def test_not_confused_with_other_packets(self):
        self.assertFalse(is_qc(b"EVDBG1" + bytes(10)))
        self.assertFalse(is_qc(b"EVS1" + bytes(40)))
        self.assertTrue(is_qc(make_qc_datagram(rec_bytes(1), 0)))

    def test_extend_seq16(self):
        self.assertEqual(extend_seq16(0x2345, 0x12345), 0x12345)
        self.assertEqual(extend_seq16(0x2344, 0x12345), 0x12344)
        # record refers to the frame just ahead of the newest packet seen
        self.assertEqual(extend_seq16(0x2346, 0x12345), 0x12346)
        self.assertEqual(extend_seq16(0xFFFF, 0x10000), 0x0FFFF)
        self.assertEqual(extend_seq16(0x0000, 0x1FFFF), 0x20000)
        self.assertEqual(extend_seq16(0x0010, None), 0x10)


class QcTrackerTest(unittest.TestCase):
    def test_repeats_collapse_to_one_record(self):
        t = QcTracker()
        for rep in range(3):
            t.on_datagram(make_qc_datagram(rec_bytes(4), 100, rep), 100, now=1.0 + rep * 0.1)
        self.assertEqual(t.stats.records, 1)
        self.assertEqual(t.stats.duplicates, 2)
        self.assertEqual(len(t.pending), 1)

    def test_invalid_record_ignored(self):
        t = QcTracker()
        t.on_datagram(make_qc_datagram(rec_bytes(4, valid=0), 100), 100, now=1.0)
        self.assertEqual((t.stats.invalid, t.stats.records, len(t.pending)), (1, 0, 0))

    def test_new_workpiece_is_not_a_duplicate(self):
        t = QcTracker()
        t.on_datagram(make_qc_datagram(rec_bytes(4), 100), 100, now=1.0)
        t.on_datagram(make_qc_datagram(rec_bytes(5, z=30), 300), 300, now=4.0)
        self.assertEqual(t.stats.records, 2)

    def test_card_uses_second_frame_after_record(self):
        t = QcTracker(frame_offset=2)
        t.on_datagram(make_qc_datagram(rec_bytes(4), 100), 100, now=1.0)
        self.assertEqual(t.on_frame(100, b"a", 2, 1, 10.0), [])
        self.assertEqual(t.on_frame(101, b"b", 2, 1, 10.1), [])
        jobs = t.on_frame(102, b"c", 2, 1, 10.2)
        self.assertEqual(len(jobs), 1)
        self.assertEqual((jobs[0].frame_seq, jobs[0].image, jobs[0].match), (102, b"c", "ok"))
        self.assertEqual(t.pending, [])

    def test_skipped_target_frame_takes_the_next_one(self):
        t = QcTracker(frame_offset=2)
        t.on_datagram(make_qc_datagram(rec_bytes(4), 100), 100, now=1.0)
        jobs = t.on_frame(105, b"x", 2, 1, 10.0)       # 102..104 lost on the wire
        self.assertEqual(jobs[0].frame_seq, 105)

    def test_timeout_falls_back_to_newest_frame(self):
        t = QcTracker(frame_offset=2, timeout_s=0.5)
        t.on_frame(99, b"old", 2, 1, 9.0)
        t.on_datagram(make_qc_datagram(rec_bytes(4), 100), 100, now=1.0)
        self.assertEqual(t.sweep(now=1.4), [])
        jobs = t.sweep(now=1.6)
        self.assertEqual((jobs[0].image, jobs[0].match, t.stats.late), (b"old", "late", 1))

    def test_timeout_without_any_frame_is_counted(self):
        t = QcTracker(timeout_s=0.5)
        t.on_datagram(make_qc_datagram(rec_bytes(4), 100), None, now=1.0)
        self.assertEqual(t.sweep(now=2.0), [])
        self.assertEqual(t.stats.unmatched, 1)

    def test_reassembler_does_not_count_qc_as_bad(self):
        r = FrameReassembler()
        self.assertIsNone(r.accept(make_qc_datagram(rec_bytes(1), 0)))
        self.assertEqual((r.stats.qc_packets, r.stats.packets_bad), (1, 0))


class QcRulesTest(unittest.TestCase):
    rec = QcRecord.from_bytes(rec_bytes(1, x=26, y=49, z=28))

    def test_disabled_by_default(self):
        self.assertEqual(judge(self.rec, Rules()).status, "disabled")
        self.assertEqual(Verdict("disabled").text, "判定：预留")

    def test_shipped_file_is_disabled(self):
        rules = RulesFile(Path(__file__).with_name("qc_rules.json")).rules
        self.assertEqual(judge(self.rec, rules).status, "disabled")

    def test_pass_and_fail(self):
        rules = parse_rules({"enabled": True, "checks": {
            "length": {"nominal": 25, "tol": 2},
            "thickness": {"nominal": 25, "tol": 2}}})
        v = judge(self.rec, rules)
        self.assertEqual((v.status, v.failed), ("fail", ("厚",)))
        self.assertEqual(v.text, "不合格（厚）")
        rules = parse_rules({"enabled": True, "checks": {"thickness": {"nominal": 27, "tol": 1}}})
        self.assertEqual(judge(self.rec, rules).status, "pass")

    def test_file_reload_and_bad_edit_keeps_last_rules(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "r.json"
            path.write_text(json.dumps({"enabled": True, "checks": {
                "length": {"nominal": 26, "tol": 1}}}), encoding="utf-8")
            rf = RulesFile(path)
            self.assertEqual(judge(self.rec, rf.refresh()).status, "pass")
            path.write_text("{ not json", encoding="utf-8")
            os.utime(path, (time.time() + 5, time.time() + 5))
            self.assertEqual(judge(self.rec, rf.refresh()).status, "pass")
            self.assertIsNotNone(rf.error)


class QcWriterTest(unittest.TestCase):
    def test_end_to_end_through_receive_thread(self):
        import numpy as np
        rx = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        rx.bind(("127.0.0.1", 0))
        rx.settimeout(0.05)
        tx = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        with tempfile.TemporaryDirectory() as tmp:
            def to_bgr(data, w, h):
                return np.zeros((h, w, 3), np.uint8)
            def render(bgr, rec, wall, verdict):
                return np.zeros((bgr.shape[0] + 3, bgr.shape[1], 3), np.uint8)
            writer = QcWriter(Path(tmp), to_bgr, render, lambda rec: Verdict("disabled"),
                              encoder=lambda img, q: b"JPEG" + bytes(img.shape[0]))
            tracker = QcTracker(frame_offset=2)
            receiver = ReceiveThread(rx, FrameReassembler(), LatestFrame(), tracker, writer)
            receiver.start()
            try:
                def frame(seq):
                    h = PacketHeader(TYPE_PREVIEW, 1, seq, 0, 1, 2, 1, PIXEL_RGB565, 0, 0, 0)
                    tx.sendto(make_datagram(h, b"\x00\x00\x00\x00"), rx.getsockname())
                frame(40)
                time.sleep(0.05)
                for rep in range(3):
                    tx.sendto(make_qc_datagram(rec_bytes(9), 40, rep), rx.getsockname())
                for seq in (41, 42, 43):
                    time.sleep(0.02)
                    frame(seq)
                deadline = time.time() + 2
                while writer.saved < 1 and time.time() < deadline:
                    time.sleep(0.02)
            finally:
                receiver.stop_event.set()
                receiver.join(1)
                writer.close()
                rx.close()
                tx.close()
            self.assertEqual((writer.saved, writer.failed), (1, 0), writer.last_error)
            self.assertEqual((tracker.stats.records, tracker.stats.duplicates), (1, 2))
            day_dirs = list(Path(tmp).iterdir())
            self.assertEqual(len(day_dirs), 1)
            lines = (day_dirs[0] / "index.jsonl").read_text(encoding="utf-8").splitlines()
            self.assertEqual(len(lines), 1)
            entry = json.loads(lines[0])
            self.assertEqual((entry["qc_seq"], entry["frame_seq"], entry["frame_match"]), (9, 42, "ok"))
            self.assertEqual((entry["x_mm"], entry["y_mm"], entry["z_mm"]), (26, 49, 28))
            self.assertEqual(entry["verdict"], "disabled")
            self.assertTrue((day_dirs[0] / entry["file"]).is_file())
            self.assertTrue((day_dirs[0] / entry["raw"]).is_file())
            self.assertEqual(list(day_dirs[0].glob("*.part")), [])
            self.assertIsNotNone(writer.take_notice())

    def test_names(self):
        day, card, raw = qc_names(time.mktime((2026, 10, 4, 21, 35, 8, 0, 0, -1)) + 0.123, 12)
        self.assertEqual((day, card, raw), ("20261004", "213508_123_No012_card.jpg",
                                            "213508_123_No012_raw.jpg"))


class QcCardTest(unittest.TestCase):
    def test_card_geometry_and_untouched_frame(self):
        try:
            import numpy as np
            import PIL  # noqa: F401
        except ImportError:
            self.skipTest("Pillow not installed")
        from qc_card import BAR_HEIGHT, find_fonts, render_card
        rng = np.random.default_rng(1)
        bgr = rng.integers(0, 256, (540, 960, 3), dtype=np.uint8)
        before = bgr.copy()
        card = render_card(bgr, QcRecord.from_bytes(rec_bytes(12)), time.time(),
                           Verdict("disabled"), find_fonts())
        self.assertEqual(card.shape, (540 + BAR_HEIGHT, 960, 3))
        self.assertTrue((bgr == before).all(), "render_card modified its input")
        self.assertTrue((card[:540] == bgr).all(), "the frame on the card was altered")
        self.assertEqual(tuple(card[-2, -2]), (255, 255, 255))


if __name__ == "__main__":
    unittest.main()
